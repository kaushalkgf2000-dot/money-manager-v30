package com.solveya.offline.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LiteRtLmEngine(
    private val context: Context
) {
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    suspend fun initialize(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            LocalModelManager.ensureModelDirectory(context)

            val model = LocalModelManager.modelFile(context)
            require(model.exists() && model.length() > 0L) {
                "Offline model not installed. Add ${LocalModelManager.MODEL_FILE_NAME} to the app model directory first."
            }

            close()

            val config = EngineConfig(
                modelPath = model.absolutePath,
                backend = Backend.CPU(),
                cacheDir = context.cacheDir.absolutePath
            )

            val newEngine = Engine(config)
            newEngine.initialize()

            val newConversation = newEngine.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(
                        """
                        You are Solveya, a focused offline study assistant for students.
                        Primary scope: Class 8-10 Mathematics and Science, with extra care for Class 9-10.
                        Your job is to teach, not merely dump an answer. Be concise but useful.

                        RESPONSE RULES:
                        1. First identify what the student is asking.
                        2. For numerical/math questions, calculate carefully, show the governing formula, substitute values with units, and verify the final value before answering.
                        3. When the student asks for a step-by-step solution, use numbered steps and end with a clearly labelled final answer.
                        4. When the student explicitly asks for “answer only”, return only the final answer, with no explanation.
                        5. For theory/concept questions, give a short definition, key points, and an example when useful.
                        6. Match the student's language: Hindi, English, or Hinglish. Do not switch language unnecessarily.
                        7. Never invent formulas, facts, units, or calculations. If uncertain, say that you are not confident.
                        8. NEVER output LaTeX, Markdown math delimiters, raw backslash commands, or dollar-sign math. Use only plain text and Unicode math symbols. Write fractions as a/b, powers with Unicode when simple (V²), and Greek symbols directly (σ, ρ, γ).
                        9. For Civil Engineering/Physics formulas, prefer standard textbook forms and correct units. For Darcy law, distinguish v = ki from Q = kAi. For Bernoulli, use P/γ + V²/(2g) + z = constant (or an equivalent standard form). For stress, use σ = P/A. Do not invent an equation.
                        """.trimIndent()
                    ),
                    samplerConfig = SamplerConfig(
                        topK = 64,
                        topP = 0.95,
                        temperature = 0.25
                    )
                )
            )

            engine = newEngine
            conversation = newConversation
        }
    }

    suspend fun ask(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val activeConversation = conversation
                ?: error("Offline AI is not initialized.")

            val response = activeConversation.sendMessage(prompt)
            response.toString()
        }
    }

    fun close() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
    }
}
