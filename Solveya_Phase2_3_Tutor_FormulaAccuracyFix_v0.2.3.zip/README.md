# Solveya — Phase 2: Real Offline AI Core

This phase replaces the placeholder AI with the LiteRT-LM Android runtime.

## Product identity

- App: Solveya
- Scope: Class 8–10 Maths + Science
- Priority: Class 9–10
- Architecture: Offline-first
- Current AI candidate: Gemma 4 E2B LiteRT-LM
- Current runtime: LiteRT-LM Android 0.16.1
- Current backend for first validation: CPU

## Phase 2 milestone

Text question
→ local `.litertlm` model
→ on-device conversation
→ response

The model is intentionally NOT bundled in this ZIP because it is a multi-gigabyte model artifact with its own license/distribution terms. The app checks its private model directory for:

`gemma-4-E2B-it.litertlm`

## Important device note

The official LiteRT-LM model registry currently lists Gemma 4 E2B at about 2.59 GB and a minimum device memory requirement of 8 GB. The model is multimodal and supports image input, which will be useful for the later Camera/Gallery milestone.

For the first phone validation we use CPU to avoid GPU-driver-specific failures. GPU/NPU acceleration can be benchmarked after the CPU path is proven.

## Phase 2.3 — Solveya Tutor layer

## Phase 2.3.1 — Math/LaTeX display cleanup

- Converts common `\frac{a}{b}` expressions into readable `a/b` form.
- Converts common Greek symbols and operators to Unicode equivalents.
- Converts simple powers/subscripts to readable Unicode characters.
- Removes leftover Markdown/LaTeX wrappers so students do not see raw commands such as `\frac`, `\text`, or `\sigma`.
- Keeps the implementation dependency-free for offline use.


This build keeps the validated offline model path intact and adds a lightweight tutor/response layer.

- Stronger educational system instruction for Maths + Science.
- Explicit handling for “answer only” requests.
- Phone-friendly plain-text math output.
- Cleanup of common Markdown/LaTeX wrappers such as `$x = 5$`.
- Cleaner answer card in the UI.
- Existing model import/load flow remains unchanged.

## Next milestone

1. Put the model file in the app's model directory.
2. Initialize it.
3. Run `2x + 5 = 15`.
4. Confirm the response with Airplane Mode ON.
5. Then build the deterministic Math Engine and connect it as a tool/router.
6. After that: Camera → Gallery → Science.

## Source

LiteRT-LM Kotlin API documentation:
https://github.com/google-ai-edge/LiteRT-LM/blob/main/docs/api/kotlin/getting_started.md


## Build fix — Phase 2.1

The previous build failed in `LiteRtLmEngine.kt` because `Conversation.sendMessage()` returns a
`Message`, not an object with a `.text` property. The current LiteRT-LM Kotlin API exposes the
message text through `Message.toString()` / its `contents`.

Fixed:
- `response.text` → `response.toString()`
- Root project name → `Solveya`

This change addresses the exact compiler error shown in the supplied build video.


## Phase 2.2 — Model Test Layer

This build adds a safe, explicit local-model workflow:

1. Select a `.litertlm` model file with Android's document picker.
2. Solveya copies it into its private model directory.
3. Press **LOAD MODEL** to initialize LiteRT-LM on a background coroutine.
4. When the status becomes **OFFLINE AI READY**, the text question button becomes active.
5. Test inference with internet disabled.

The model is intentionally not bundled in the APK because the official Gemma 4 E2B LiteRT-LM file is about 2.59 GB and the official model allowlist specifies an 8 GB minimum device-memory requirement.

The first target remains Gemma 4 E2B. The official LiteRT-LM Kotlin documentation shows `Engine(modelPath=...)`, `initialize()`, `createConversation()`, and `sendMessage()` for Android/JVM.

The selected model is copied to private app storage because LiteRT-LM requires a filesystem model path. This also avoids requiring broad storage permissions.

## Phase 2.3 Formula Accuracy Fix — v0.2.3

Changes in this build:
- Stronger offline tutor instruction for numerical verification and standard Civil Engineering formulas.
- Model temperature reduced for more deterministic answers.
- Expanded LaTeX/Markdown sanitisation: dollar delimiters, \frac/\dfrac/\tfrac, \text/\mathrm, roots, Greek symbols, powers, subscripts, and common operators.
- Plain-text/Unicode math is enforced for phone readability.
- Version bumped to 0.2.3 (versionCode 5).
