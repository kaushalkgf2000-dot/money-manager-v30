
(function(){
  'use strict';

  // ---------------- Notes step history ----------------
  var noteHistory=[];
  var noteCurrent='list';
  function notePush(next){
    if(!next)return;
    if(next===noteCurrent)return;
    noteHistory.push(noteCurrent);
    noteCurrent=next;
  }
  function noteReset(){noteHistory=[];noteCurrent='list';}

  if(typeof window.mfnShow==='function'&&!window.__mfV8MfnShow){
    window.__mfV8MfnShow=true;
    var oldShow=window.mfnShow;
    window.mfnShow=function(v){notePush(v);return oldShow.apply(this,arguments);};
  }
  if(typeof window.mfnOpen==='function'&&!window.__mfV8MfnOpen){
    window.__mfV8MfnOpen=true;
    var oldOpen=window.mfnOpen;
    window.mfnOpen=function(id){notePush('detail');return oldOpen.apply(this,arguments);};
  }
  if(typeof window.mfnNew==='function'&&!window.__mfV8MfnNew){
    window.__mfV8MfnNew=true;
    var oldNew=window.mfnNew;
    window.mfnNew=function(){notePush('create');return oldNew.apply(this,arguments);};
  }
  if(typeof window.mfnEdit==='function'&&!window.__mfV8MfnEdit){
    window.__mfV8MfnEdit=true;
    var oldEdit=window.mfnEdit;
    window.mfnEdit=function(){notePush('create');return oldEdit.apply(this,arguments);};
  }
  if(typeof window.mfnUseTemplate==='function'&&!window.__mfV8MfnTemplate){
    window.__mfV8MfnTemplate=true;
    var oldTemplate=window.mfnUseTemplate;
    window.mfnUseTemplate=function(i){notePush('detail');return oldTemplate.apply(this,arguments);};
  }
  if(typeof window.pfOpenNotes==='function'&&!window.__mfV8PfOpenNotes){
    window.__mfV8PfOpenNotes=true;
    var oldOpenNotes=window.pfOpenNotes;
    window.pfOpenNotes=function(){noteReset();return oldOpenNotes.apply(this,arguments);};
  }
  window.mfnBack=function(){
    var prev=noteHistory.length?noteHistory.pop():null;
    if(prev){noteCurrent=prev;if(typeof window.mfnShow==='function')window.mfnShow(prev);return true;}
    noteCurrent='list';
    return false;
  };

  // ---------------- Generic overlay closing ----------------
  function isDisplayed(el){
    if(!el)return false;
    var cs=getComputedStyle(el);
    return cs.display!=='none' && cs.visibility!=='hidden' && el.getAttribute('aria-hidden')!=='true';
  }
  function closeTopOverlay(){
    // Notes' More sheet is above the page and should close before its parent Notes screen.
    var more=document.getElementById('mfnMoreModal');
    if(more&&more.classList.contains('open')){if(typeof window.mfnCloseMore==='function')window.mfnCloseMore();else more.classList.remove('open');return true;}

    // Feature modals (Analytics/Search/Category/Notes/Calculator).
    var features=Array.from(document.querySelectorAll('.pf-feature-modal.open'));
    if(features.length){var m=features[features.length-1];if(typeof window.pfCloseFeature==='function')window.pfCloseFeature(m.id);else m.classList.remove('open');return true;}

    var exp=document.getElementById('pfExportModal');
    if(exp&&exp.classList.contains('open')){if(typeof window.pfCloseExport==='function')window.pfCloseExport();else exp.classList.remove('open');return true;}

    var add=document.getElementById('addTransactionModal');
    if(add&&isDisplayed(add)){if(typeof window.pfCloseAddTransaction==='function')window.pfCloseAddTransaction();else add.style.display='none';return true;}

    // Legacy/application modals. Close functions are used where available so any
    // associated state/scroll-lock is cleaned up as well.
    var legacy=[
      ['editModal','closeEdit'],
      ['historyModal','closeHistory'],
      ['customModal','closeCustomization'],
      ['mfBackupModal','mfCloseBackup'],
      ['mfAccountModal','mfCloseAccount'],
      ['v10ProfileModal','v10CloseProfileModal'],
      ['v10PinModal','v10ClosePinModal'],
      ['v10AddTxPinModal','v10CloseAddTxPinSettings'],
      ['v10AddTxSettingGate','closeSettingGate'],
      ['v10AddTxGate','closeG'],
      ['profilePhotoModal','pfCloseProfilePhotoMenu']
    ];
    for(var i=0;i<legacy.length;i++){
      var el=document.getElementById(legacy[i][0]);
      if(el&&isDisplayed(el)){
        var fn=window[legacy[i][1]];
        if(typeof fn==='function')fn();else el.style.display='none';
        document.body.style.overflow='';
        return true;
      }
    }

    // Dynamically-created biometric/security overlays.
    var v10s=Array.from(document.querySelectorAll('.v10modal')).filter(isDisplayed);
    if(v10s.length){v10s[v10s.length-1].style.display='none';document.body.style.overflow='';return true;}

    // The old menu panel is a non-modal step.
    var menu=document.getElementById('menuPanel');
    if(menu&&isDisplayed(menu)){if(typeof window.closeMenu==='function')window.closeMenu();else menu.style.display='none';return true;}

    return false;
  }

  // ---------------- Android system Back contract ----------------
  // Return true when the WebView consumed the back press. Return false only when
  // the user is already at Home with no overlay/inner step; the native Activity
  // then closes. This gives Android a deterministic one-step-at-a-time sequence.
  window.mfHandleAndroidBack=function(){
    if(closeTopOverlay())return true;

    var notes=document.getElementById('pfNotesModal');
    if(notes&&notes.classList.contains('open')){
      if(window.mfnBack&&window.mfnBack())return true;
      if(typeof window.pfCloseFeature==='function')window.pfCloseFeature('pfNotesModal');else notes.classList.remove('open');
      document.body.style.overflow='';
      return true;
    }

    // Category history is a transaction sub-step, so Back returns to Category.
    if(window.__pfCategoryHistoryFilter){
      window.__pfCategoryHistoryFilter='';
      if(typeof window.pfOpenCategory==='function')window.pfOpenCategory();
      return true;
    }

    var tx=document.getElementById('pfTransactionsPage');
    if(tx&&getComputedStyle(tx).display!=='none'){
      var homeBtn=document.querySelector('.pf-bottom-nav button:nth-child(1)');
      if(typeof window.pfNav==='function')window.pfNav('home',homeBtn);
      else{
        tx.style.display='none';
        document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(function(x){x.style.display='';});
      }
      if(typeof window.pfSetNav==='function')window.pfSetNav(homeBtn);
      window.scrollTo({top:0,behavior:'smooth'});
      return true;
    }

    // Home is the root. Returning false tells the native Activity to finish.
    return false;
  };
})();
