MoneyFlow V21 — isolated patch architecture

1. Transaction form state controller: final event/open-state module only. Existing save core remains intact.
2. Profile photo/mode isolation: dedicated V21 picker stores by active Profile/Mode ID and schedules cloud sync.
3. Analytics export: public window.pfExportAnalyticsImage API is explicitly exposed so the button can invoke it.
4. Manual Google Drive sync: cloud-only guard prevents the local native recovery snapshot from being written during manual cloud sync. Sign-out backup path remains unchanged.
5. Existing UID restore/merge and profile cloud payload are preserved.
