
(function(){
  const pad=n=>String(n).padStart(2,'0');
  const today=()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
  const monthBounds=ym=>{const [y,m]=String(ym).split('-').map(Number);return {from:y+'-'+pad(m)+'-01',to:y+'-'+pad(m)+'-'+pad(new Date(y,m,0).getDate())};};
  const arr=()=>{try{return Array.isArray(txs)?txs:[]}catch(e){return[]}};
  const norm=v=>String(v==null?'':v).toLowerCase().trim();

  /* 1) Transactions opens as Daily + TODAY. */
  function selectToday(){
    const s=window.__pfTxFinalState;if(!s)return;
    const td=today();s.view='daily';s.month=td.slice(0,7);s.weekAnchor=td;
    const dp=document.getElementById('pfTxDayPicker');if(dp){dp.value=td;dp.min=monthBounds(s.month).from;dp.max=monthBounds(s.month).to;}
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view==='daily'));
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');
    if(d)d.style.display='flex';if(w)w.style.display='none';if(c)c.style.display='none';
  }
  const nav0=window.pfNav;
  window.pfNav=function(name,btn){if(name==='transactions'){window.__pfCategoryHistoryFilter='';selectToday();}return typeof nav0==='function'?nav0.apply(this,arguments):undefined;};

  /* 2) Fast, reliable search with a cached index. */
  let sKey='',sIndex=[];
  function index(){
    const a=arr();const key=a.length+'|'+a.map(t=>String(t.id||'')+':'+String(t.updatedAt||t.createdAt||t.date||'')).join(',');
    if(key===sKey)return sIndex;sKey=key;
    sIndex=a.map(t=>({t,text:[t.date,t.type,t.amount,t.category,t.description,t.desc,t.remark,t.remarks,t.note,t.mode,t.paymentMode,t.payment_mode,t.other,t.otherInfo,t.other_info].map(norm).join(' ')}));return sIndex;
  }
  function renderSearch(q){
    const list=document.getElementById('pfSearchResults');if(!list)return;const query=norm(q);const rows=query?index().filter(x=>x.text.includes(query)):index();
    if(!rows.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}
    list.innerHTML=rows.slice(0,150).map(({t})=>{const credit=t.type==='CREDIT';const meta=[t.date,t.mode||t.paymentMode||'',t.description||t.desc||'',t.remark||t.remarks||t.note||''].filter(Boolean).join(' • ');return `<div class="pf-search-result" data-search-id="${escapeHtml(String(t.id))}"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(meta)}</small></div><strong style="color:${credit?'#2fa65b':'#e3483d'}">${credit?'+':'-'}${money(t.amount)}</strong></div>`;}).join('');
  }
  window.pfOpenSearch=function(){openFeatureFixed('pfSearchModal');const i=document.getElementById('pfSearchInput');if(i){i.value='';requestAnimationFrame(()=>i.focus());}renderSearch('');};
  if(!document.__mfSearchBound){document.__mfSearchBound=true;document.addEventListener('input',e=>{if(e.target&&e.target.id==='pfSearchInput')renderSearch(e.target.value);});}

  /* 3) Category -> transaction history. */
  function openCategoryHistory(category,range,type){
    window.__pfCategoryHistoryFilter=String(category||'');
    window.__pfCategoryHistoryRange=range||null;
    window.__pfCategoryHistoryType=type||'';
    const s=window.__pfTxFinalState;if(s){s.view='monthly';s.month=today().slice(0,7);s.weekAnchor=today();}
    document.querySelectorAll('.pf-feature-modal.open').forEach(m=>m.classList.remove('open'));
    const page=document.getElementById('pfTransactionsPage');if(page){document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(x=>x.style.display='none');page.style.display='block';}
    const btn=document.querySelector('.pf-tx-tabs button[data-view="monthly"]');document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===btn));
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');if(d)d.style.display='none';if(w)w.style.display='none';if(c)c.style.display='none';
    renderCategoryHistory();
    if(typeof window.pfSetNav==='function')window.pfSetNav(document.querySelector('.pf-bottom-nav button:nth-child(2)'));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  function categoryRange(){const r=window.__pfCategoryHistoryRange;if(r&&r.from&&r.to)return r;const s=window.__pfTxFinalState||{},b=monthBounds(s.month||today().slice(0,7));return {from:b.from,to:b.to};}
  function renderCategoryHistory(){
    const q=categoryRange(),cat=String(window.__pfCategoryHistoryFilter||'');let data=arr().filter(t=>String(t.date||'')>=q.from&&String(t.date||'')<=q.to&&String(t.category||'')===cat&&(!window.__pfCategoryHistoryType||String(t.type||'')===String(window.__pfCategoryHistoryType))).slice().sort(compareTransactionsLatestFirst);
    const list=document.getElementById('pfTransactionsList'),sum=document.getElementById('pfTransactionsSummary');if(!list||!sum)return;
    let inc=0,exp=0;data.forEach(t=>t.type==='CREDIT'?inc+=Number(t.amount)||0:exp+=Number(t.amount)||0);sum.textContent=`Category: ${cat} • ${q.from} → ${q.to} • ${data.length} transaction(s) • Income ${money(inc)} • Expense ${money(exp)} • Balance ${money(inc-exp)}`;
    list.innerHTML='';if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this category.</div>';return;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));const credit=t.type==='CREDIT',sign=credit?'+':'-',icon=credit?'↓':'↑';
      const desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',mode=t.mode||t.paymentMode||'Not specified',other=t.other||t.otherInfo||t.other_info||'';
      row.innerHTML=`<div class="pf-detail-main"><div class="pf-swipe-icon ${credit?'income':'expense'}">${icon}</div><div class="pf-detail-summary"><div class="pf-detail-title">${escapeHtml(t.category||'Uncategorized')}</div><div class="pf-detail-meta">${escapeHtml(t.date||'')} • ${escapeHtml(mode)}</div><div class="pf-detail-secondary">${desc?escapeHtml(desc):'No description'}${remark?' • Remark: '+escapeHtml(remark):''}</div></div><div class="pf-swipe-amount ${credit?'income':'expense'}">${sign}${money(t.amount)}</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-field"><span>Date</span><b>${escapeHtml(t.date||'—')}</b></div><div class="pf-detail-field"><span>Type</span><b>${credit?'Credit':'Expense'}</b></div><div class="pf-detail-field"><span>Amount</span><b>${sign}${money(t.amount)}</b></div><div class="pf-detail-field"><span>Category</span><b>${escapeHtml(t.category||'Uncategorized')}</b></div><div class="pf-detail-field"><span>Payment Mode</span><b>${escapeHtml(mode)}</b></div><div class="pf-detail-field"><span>Description</span><b>${escapeHtml(desc||'—')}</b></div><div class="pf-detail-field"><span>Remark</span><b>${escapeHtml(remark||'—')}</b></div><div class="pf-detail-field"><span>Other</span><b>${escapeHtml(other||'—')}</b></div><div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>`;
      const main=row.querySelector('.pf-detail-main'),panel=row.querySelector('.pf-detail-panel'),expBtn=row.querySelector('.pf-expand-btn'),edit=row.querySelector('.pf-swipe-edit');
      expBtn.addEventListener('click',()=>{const open=row.classList.toggle('expanded');panel.style.display=open?'block':'none';expBtn.textContent=open?'⌃':'⌄';expBtn.setAttribute('aria-expanded',open?'true':'false');});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      let sx=0,sy=0,moved=false;main.addEventListener('touchstart',e=>{sx=e.touches[0]?.clientX||0;sy=e.touches[0]?.clientY||0;moved=false},{passive:true});main.addEventListener('touchmove',e=>{if(!e.touches[0])return;const dx=e.touches[0].clientX-sx,dy=e.touches[0].clientY-sy;if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){moved=true;e.preventDefault();main.style.transition='none';main.style.transform=`translateX(${Math.max(-92,Math.min(0,dx))}px)`;}},{passive:false});main.addEventListener('touchend',e=>{if(!moved)return;const dx=(e.changedTouches[0]?.clientX||sx)-sx;main.style.transition='transform .18s ease';if(dx<-45){main.style.transform='translateX(-92px)';row.classList.add('open');}else{main.style.transform='translateX(0)';row.classList.remove('open');}});
      list.appendChild(row);
    });
  }
  if(!document.__mfCategoryHistoryBound){document.__mfCategoryHistoryBound=true;document.addEventListener('click',e=>{const r=e.target.closest?.('.pf-category-row');if(r){const c=r.querySelector('.pf-category-name')?.textContent?.trim();if(c){let range=null;let type='';const modal=document.getElementById('pfCategoryModal');if(modal&&modal.classList.contains('open')){type=document.getElementById('pfCatIncome')?.classList.contains('active')?'CREDIT':'EXPENSE';const active=modal.querySelector('[data-cat-period].active')?.getAttribute('data-cat-period')||'all';if(active==='month'){range=monthBounds((window.__pfTxFinalState||{}).month||today().slice(0,7));}else if(active==='year'){const y=Number(((window.__pfTxFinalState||{}).month||today().slice(0,7)).slice(0,4));range={from:y+'-01-01',to:y+'-12-31'};}else if(active==='custom'){range={from:document.getElementById('pfCatFrom')?.value||today(),to:document.getElementById('pfCatTo')?.value||today()};}}openCategoryHistory(c,range,type);}}});}

  /* 4) Analytics: fast category aggregation + category click-through. */
  let aCache={key:'',data:null};
  function analyticsData(){
    const s=window.__pfTxFinalState||{};const q=typeof window.pfTxFinalFiltered==='function'?window.pfTxFinalFiltered():{data:arr()};
    const key=[s.view,s.month,s.weekAnchor,document.getElementById('pfTxDayPicker')?.value||'',document.getElementById('pfTxFrom')?.value||'',document.getElementById('pfTxTo')?.value||'',arr().length].join('|');
    if(key!==aCache.key)aCache={key,data:q.data||[]};return aCache.data;
  }
  let analyticsType='EXPENSE';
  function drawAnalytics(){
    const data=analyticsData().filter(t=>t.type===analyticsType),by=Object.create(null);for(const t of data){const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0);}const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((s,x)=>s+x[1],0),donut=document.getElementById('pfDonut'),legend=document.getElementById('pfAnalyticsLegend');if(!donut||!legend)return;
    document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}
    const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;donut.style.background='conic-gradient('+entries.map((x,i)=>{const end=start+x[1]/total*100,z=pal[i%pal.length]+' '+start+'% '+end+'%';start=end;return z}).join(',')+')';legend.innerHTML=entries.map((x,i)=>`<button type="button" class="pf-legend-row" data-analytics-category="${escapeHtml(x[0])}"><i class="pf-legend-dot" style="background:${pal[i%pal.length]}"></i><b>${escapeHtml(x[0])}</b><span>${money(x[1])} · ${(x[1]/total*100).toFixed(1)}%</span></button>`).join('');
  }
  window.pfOpenAnalytics=function(){window.__pfCategoryHistoryFilter='';openFeature('pfAnalyticsModal');analyticsType='EXPENSE';document.getElementById('pfAnalyticsExpense')?.classList.add('active');document.getElementById('pfAnalyticsIncome')?.classList.remove('active');drawAnalytics();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense')?.classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome')?.classList.toggle('active',type==='CREDIT');drawAnalytics();};
  if(!document.__mfAnalyticsCategoryBound){document.__mfAnalyticsCategoryBound=true;document.addEventListener('click',e=>{const b=e.target.closest?.('[data-analytics-category]');if(b)openCategoryHistory(b.getAttribute('data-analytics-category'),null,analyticsType);});}

  /* Period/view changes remove a previous category drill-down. */
  const sv=window.pfTxSetView;window.pfTxSetView=function(){window.__pfCategoryHistoryFilter='';return typeof sv==='function'?sv.apply(this,arguments):undefined;};
  const sm=window.pfTxShiftMonth;window.pfTxShiftMonth=function(){window.__pfCategoryHistoryFilter='';return typeof sm==='function'?sm.apply(this,arguments):undefined;};
  const sw=window.pfTxShiftWeek;window.pfTxShiftWeek=function(){window.__pfCategoryHistoryFilter='';return typeof sw==='function'?sw.apply(this,arguments):undefined;};

  function boot(){selectToday();sKey='';aCache.key='';}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

