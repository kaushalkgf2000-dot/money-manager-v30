
(function(){
  'use strict';
  const STORE='moneyflow_notes_v1';
  const CATS=['Shopping','Wish List','Personal','Work'];
  const TEMPLATES=[
    {name:'Shopping List',cat:'Shopping',type:'Checklist',icon:'🛒',items:['Groceries','Notebook','Shoes','Water Bottle','Backpack'],text:'',estimate:3500},
    {name:'To Do List',cat:'Personal',type:'Checklist',icon:'✓',items:['Task 1','Task 2','Task 3'],text:'',estimate:0},
    {name:'Wish List',cat:'Wish List',type:'Checklist',icon:'♥',items:['Item 1','Item 2'],text:'',estimate:0},
    {name:'Do Not Buy List',cat:'Shopping',type:'Checklist',icon:'−',items:['Item to avoid'],text:'',estimate:0},
    {name:'Travel Checklist',cat:'Personal',type:'Checklist',icon:'✈',items:['Tickets','ID','Hotel','Packing'],text:'',estimate:0},
    {name:'Project Ideas',cat:'Work',type:'Text Note',icon:'💡',items:[],text:'Write your project idea here.',estimate:0},
    {name:'Personal Notes',cat:'Personal',type:'Both',icon:'▤',items:['Important item'],text:'Add your personal note here.',estimate:0}
  ];
  let notes=[];
  let view='list', editId=null, filter='All', search='', draftType='Checklist';
  function uid(){return 'n_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8)}
  function load(){try{notes=JSON.parse(localStorage.getItem(STORE)||'[]')}catch(e){notes=[]}if(!Array.isArray(notes))notes=[];if(!notes.length){notes=[seed()];save()}}
  function seed(){return {id:uid(),title:'Shopping List',category:'Shopping',type:'Checklist',items:[{id:uid(),text:'Groceries',done:true},{id:uid(),text:'Notebook',done:false},{id:uid(),text:'Shoes',done:false},{id:uid(),text:'Water Bottle',done:true},{id:uid(),text:'Backpack',done:false}],text:'Buy only if needed. Compare prices online.',estimate:3500,pinned:true,created:Date.now(),updated:Date.now()}}
  function save(){localStorage.setItem(STORE,JSON.stringify(notes))}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function fmtDate(ts){return new Date(ts||Date.now()).toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'})}
  function icon(cat){return cat==='Shopping'?'🛒':cat==='Wish List'?'♥':cat==='Work'?'▣':'▤'}
  function get(id){return notes.find(n=>n.id===id)}
  function filtered(){let q=search.trim().toLowerCase();return notes.filter(n=>(filter==='All'||n.category===filter)&&(!q||[n.title,n.category,n.type,n.text,(n.items||[]).map(x=>x.text).join(' ')].join(' ').toLowerCase().includes(q))).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||((b.updated||0)-(a.updated||0)))}
  function ensureShell(){
    const m=document.getElementById('pfNotesModal');if(!m)return null;
    const sheet=m.querySelector('.pf-feature-sheet');if(!sheet)return null;
    if(sheet.dataset.mfn==='1')return sheet;
    sheet.dataset.mfn='1';
    sheet.innerHTML=`
      <div class="pf-feature-head"><div><span class="pf-feature-kicker">PERSONAL ORGANIZER</span><h2>Notes</h2></div><div class="mfn-head-actions"><button class="mfn-icon-btn" type="button" onclick="mfnToggleSearch()">⌕</button><button class="mfn-icon-btn" type="button" onclick="mfnShow('templates')">⋮</button><button class="pf-feature-close" type="button" onclick="pfCloseFeature('pfNotesModal')">✕</button></div></div>
      <div id="mfnRoot"></div>`;
    return sheet;
  }
  function show(){ensureShell();const m=document.getElementById('pfNotesModal');if(m){m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden'}render()}
  function render(){ensureShell();const root=document.getElementById('mfnRoot');if(!root)return;
    if(view==='list')renderList(root);else if(view==='create')renderCreate(root);else if(view==='detail')renderDetail(root);else if(view==='categories')renderCategories(root);else renderTemplates(root);
  }
  function renderList(root){
    const data=filtered();
    root.innerHTML=`<div class="mfn-filter-row">${['All'].concat(CATS).map(c=>`<button type="button" class="mfn-filter ${filter===c?'active':''}" onclick="mfnFilter(${JSON.stringify(c)})">${esc(c)}</button>`).join('')}</div>
      <div id="mfnSearchBox" style="display:${search?'block':'none'}"><input id="mfnSearchInput" class="mfn-search" value="${esc(search)}" placeholder="Search title, category, item or note..." oninput="mfnSearch(this.value)"></div>
      <div class="mfn-topbar"><h3>All Notes</h3><button type="button" class="mfn-back" onclick="mfnShow('categories')">Category-wise</button></div>
      <div class="mfn-list">${data.length?data.map(card).join(''):`<div class="mfn-empty">No notes found.<br>Create a note or change the filter.</div>`}</div>
      <button type="button" class="mfn-primary" onclick="mfnNew()">＋ New Note</button>
      <button type="button" class="mfn-secondary" onclick="mfnShow('templates')">▤ Note Templates</button>`;
    const inp=document.getElementById('mfnSearchInput');if(inp&&search){inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)}
  }
  function card(n){const count=(n.items||[]).length,done=(n.items||[]).filter(x=>x.done).length;const meta=(n.type==='Text Note'?'Text note':n.type)+(count?` • ${done}/${count} checked`:'')+` • ${fmtDate(n.updated||n.created)}`;const preview=n.text||((n.items||[]).map(x=>x.text).filter(Boolean).join(' • '));return `<div class="mfn-card" onclick="mfnOpen(${JSON.stringify(n.id)})"><div class="mfn-card-icon">${icon(n.category)}</div><div class="mfn-card-main"><div class="mfn-card-title">${esc(n.title||'Untitled')} ${n.pinned?'<span class="mfn-pin">📌</span>':''}</div><div class="mfn-card-meta">${esc(n.category)} • ${esc(meta)}</div>${preview?`<div class="mfn-card-preview">${esc(preview)}</div>`:''}</div><button type="button" class="mfn-more" onclick="event.stopPropagation();mfnCardMenu(${JSON.stringify(n.id)})">⋮</button></div>`}
  function renderCreate(root){const n=editId?get(editId):null;const d=n||{title:'',category:'Shopping',type:draftType,items:[],text:'',estimate:0};draftType=d.type||'Checklist';
    root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Back</button><h3>${n?'Edit Note':'Create Note'}</h3><button class="mfn-back" type="button" onclick="mfnSaveForm()">Save</button></div>
      <div class="mfn-form">
        <div class="mfn-field"><label>Title</label><input id="mfnTitle" value="${esc(d.title)}" placeholder="Note title"></div>
        <div class="mfn-field"><label>Category</label><select id="mfnCategory">${CATS.map(c=>`<option ${d.category===c?'selected':''}>${c}</option>`).join('')}</select></div>
        <div class="mfn-field"><label>Type</label><div class="mfn-type">${['Checklist','Text Note','Both'].map(t=>`<button type="button" class="${d.type===t?'active':''}" onclick="mfnSetType(${JSON.stringify(t)})">${t}</button>`).join('')}</div></div>
        <div id="mfnItemsWrap" class="mfn-field" style="display:${d.type==='Text Note'?'none':'grid'}"><label>Items</label><div id="mfnItems" class="mfn-items">${(d.items||[]).map(itemEditor).join('')}</div><button class="mfn-add-item" type="button" onclick="mfnAddItem()">＋ Add Item</button></div>
        <div id="mfnTextWrap" class="mfn-field" style="display:${d.type==='Checklist'?'none':'grid'}"><label>Notes</label><textarea id="mfnText" placeholder="Write your note...">${esc(d.text||'')}</textarea></div>
        <div class="mfn-field"><label>Estimated Total (optional)</label><input id="mfnEstimate" type="number" min="0" step="0.01" value="${Number(d.estimate||0)||''}" placeholder="0"></div>
      </div><button type="button" class="mfn-primary" onclick="mfnSaveForm()">✓ ${n?'Save Changes':'Create Note'}</button>`;
  }
  function itemEditor(it){return `<div class="mfn-item-editor" data-item-id="${esc(it.id)}"><span style="color:#9a9185;text-align:center">☷</span><input class="mfn-item-input" value="${esc(it.text)}" placeholder="Item"><button type="button" onclick="mfnRemoveItem(this)">×</button></div>`}
  function renderDetail(root){const n=get(editId);if(!n){view='list';render();return}const items=n.items||[];const done=items.filter(x=>x.done).length;
    root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><div style="display:flex;gap:4px"><button class="mfn-icon-btn" type="button" onclick="mfnEdit()">✎</button><button class="mfn-icon-btn mfn-danger" type="button" onclick="mfnDelete()">⌫</button><button class="mfn-icon-btn" type="button" onclick="mfnTogglePin()">${n.pinned?'📌':'☆'}</button></div></div>
      <h3 class="mfn-detail-title">${esc(n.title||'Untitled')}</h3><div class="mfn-detail-sub">${esc(n.category)} • ${esc(n.type)} • ${fmtDate(n.updated||n.created)}</div>
      ${items.length?`<div class="mfn-detail-section"><h4>Checklist <span style="font-weight:400;color:#8b8378">${done}/${items.length}</span></h4><div class="mfn-checklist">${items.map((it,i)=>`<label class="mfn-check-row ${it.done?'done':''}"><input type="checkbox" ${it.done?'checked':''} onchange="mfnToggleItem(${i},this.checked)"><span>${esc(it.text)}</span></label>`).join('')}</div><button class="mfn-add-item" style="margin-top:10px!important" type="button" onclick="mfnAddDetailItem()">＋ Add Item</button></div>`:''}
      ${n.estimate?`<div class="mfn-detail-section"><h4>Estimated Total</h4><div class="mfn-estimate"><strong>${money(n.estimate)}</strong><button type="button" class="mfn-secondary" style="width:auto;margin:0!important" onclick="pfOpenCalculator()">Open Calculator</button></div></div>`:''}
      ${n.text?`<div class="mfn-detail-section"><h4>Notes</h4><div class="mfn-text-note">${esc(n.text)}</div></div>`:''}
      ${!items.length&&!n.text&&!n.estimate?'<div class="mfn-empty">This note is empty. Tap Edit to add content.</div>':''}`;
  }
  function renderCategories(root){const counts=CATS.map(c=>({c,n:notes.filter(x=>x.category===c).length}));root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><h3>Category</h3></div><div class="mfn-cat-grid">${counts.map(x=>`<div class="mfn-cat-card" onclick="mfnFilter(${JSON.stringify(x.c)});mfnShow('list')"><b>${esc(x.c)}</b><span>${x.n} note${x.n===1?'':'s'}</span></div>`).join('')}</div><button type="button" class="mfn-secondary" onclick="mfnFilter('All');mfnShow('list')">View All Notes</button>`}
  function renderTemplates(root){root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><h3>Templates</h3></div><div class="mfn-template-list">${TEMPLATES.map((t,i)=>`<div class="mfn-template" onclick="mfnUseTemplate(${i})"><div class="mfn-template-icon">${t.icon}</div><div><b>${esc(t.name)}</b><small>${esc(t.type)} • ${esc(t.cat)}</small></div></div>`).join('')}</div>`}
  function money(v){return '₹'+Number(v||0).toLocaleString('en-IN',{maximumFractionDigits:2})}
  window.mfnShow=function(v){view=v;render()};
  window.mfnFilter=function(v){filter=v;render()};
  window.mfnSearch=function(v){search=v;render()};
  window.mfnToggleSearch=function(){view='list';const box=document.getElementById('mfnSearchBox');if(box){box.style.display='block';const x=document.getElementById('mfnSearchInput');if(x)x.focus();}else{render();setTimeout(function(){const y=document.getElementById('mfnSearchInput');if(y)y.focus()},0)}};
  window.mfnNew=function(){editId=null;draftType='Checklist';view='create';render()};
  window.mfnOpen=function(id){editId=id;view='detail';render()};
  window.mfnEdit=function(){view='create';render()};
  window.mfnSetType=function(t){draftType=t;document.querySelectorAll('.mfn-type button').forEach(function(b){b.classList.toggle('active',b.textContent.trim()===t)});const iw=document.getElementById('mfnItemsWrap'),tw=document.getElementById('mfnTextWrap');if(iw)iw.style.display=t==='Text Note'?'none':'grid';if(tw)tw.style.display=t==='Checklist'?'none':'grid';};
  window.mfnAddItem=function(){const wrap=document.getElementById('mfnItems');if(!wrap)return;const div=document.createElement('div');div.className='mfn-item-editor';div.dataset.itemId=uid();div.innerHTML='<span style="color:#9a9185;text-align:center">☷</span><input class="mfn-item-input" placeholder="Item"><button type="button" onclick="mfnRemoveItem(this)">×</button>';wrap.appendChild(div);div.querySelector('input').focus()};
  window.mfnRemoveItem=function(btn){const row=btn.closest('.mfn-item-editor');if(row)row.remove()};
  window.mfnSaveForm=function(){const title=(document.getElementById('mfnTitle')?.value||'').trim();if(!title){alert('Please enter a note title.');return}const category=document.getElementById('mfnCategory')?.value||'Personal';const type=draftType;const items=Array.from(document.querySelectorAll('#mfnItems .mfn-item-editor')).map(r=>({id:r.dataset.itemId||uid(),text:(r.querySelector('input')?.value||'').trim(),done:false})).filter(x=>x.text);const text=document.getElementById('mfnText')?.value||'';const estimate=Math.max(0,Number(document.getElementById('mfnEstimate')?.value||0));let n=editId?get(editId):null;if(n){n.title=title;n.category=category;n.type=type;n.items=items.map(x=>{const old=(n.items||[]).find(o=>o.id===x.id);return old?{...x,done:old.done}:x});n.text=text;n.estimate=estimate;n.updated=Date.now()}else{n={id:uid(),title,category,type,items,text,estimate,pinned:false,created:Date.now(),updated:Date.now()};notes.unshift(n);editId=n.id}save();view='detail';render()};
  window.mfnToggleItem=function(index,checked){const n=get(editId);if(!n)return;if(n.items&&n.items[index])n.items[index].done=!!checked;n.updated=Date.now();save();render()};
  window.mfnAddDetailItem=function(){const text=prompt('Item name');if(!text||!text.trim())return;const n=get(editId);if(!n)return;n.items=n.items||[];n.items.push({id:uid(),text:text.trim(),done:false});n.updated=Date.now();save();render()};
  window.mfnTogglePin=function(){const n=get(editId);if(!n)return;n.pinned=!n.pinned;n.updated=Date.now();save();render()};
  window.mfnDelete=function(){const n=get(editId);if(!n)return;if(!confirm('Delete this note?'))return;notes=notes.filter(x=>x.id!==editId);save();editId=null;view='list';render()};
  window.mfnCardMenu=function(id){const n=get(id);if(!n)return;const action=prompt('Type: pin, edit, or delete');if(!action)return;const a=action.toLowerCase();editId=id;if(a==='pin'){n.pinned=!n.pinned;n.updated=Date.now();save();render()}else if(a==='edit'){view='create';render()}else if(a==='delete'){mfnDelete()}};
  window.mfnUseTemplate=function(i){const t=TEMPLATES[i];if(!t)return;editId=null;draftType=t.type;const n={id:uid(),title:t.name,category:t.cat,type:t.type,items:(t.items||[]).map(x=>({id:uid(),text:x,done:false})),text:t.text||'',estimate:t.estimate||0,pinned:false,created:Date.now(),updated:Date.now()};notes.unshift(n);save();editId=n.id;view='detail';render()};
  window.pfOpenNotes=function(){load();filter='All';search='';view='list';show();if(typeof window.pfSetNav==='function')window.pfSetNav(document.getElementById('notesNavBtn'))};
  load();
})();
