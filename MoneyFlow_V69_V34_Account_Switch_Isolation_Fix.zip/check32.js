
(function(){
  'use strict';
  const PROFILE_KEY='money_manager_profiles_v10';
  const ACTIVE_KEY='money_manager_active_profile_v10';
  const FALLBACK='👤';
  const esc=function(s){return String(s==null?'':s).replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]})};
  function activeProfile(){
    try{
      const a=JSON.parse(localStorage.getItem(PROFILE_KEY)||'[]');
      const id=localStorage.getItem(ACTIVE_KEY);
      return Array.isArray(a)?(a.find(function(p){return p&&p.id===id})||a[0]||null):null;
    }catch(e){return null;}
  }
  function photo(p){
    const src=p&&typeof p.profilePhoto==='string'&&/^data:image\//i.test(p.profilePhoto)?p.profilePhoto:'';
    return src;
  }
  function closeEverythingBeforeOpen(){
    try{if(typeof window.mfnCloseMore==='function')window.mfnCloseMore();}catch(e){}
    try{if(typeof window.closeMenu==='function')window.closeMenu();}catch(e){}
  }
  function runAction(fn){
    return function(){
      closeEverythingBeforeOpen();
      setTimeout(function(){try{if(typeof fn==='function')fn();}catch(e){}},0);
    };
  }
  function legacyMarkup(){
    return ''+
      '<div class="mf-v10-more-profile" id="mfV10MoreProfile" role="button" tabindex="0" aria-label="Open Profile / Mode">'+
        '<div class="mf-v10-more-avatar" id="mfV10MoreAvatar">'+FALLBACK+'</div>'+
        '<div class="mf-v10-more-profile-main"><b id="mfV10MoreProfileName">Profile / Mode</b><small id="mfV10MoreProfileSub">Manage your account</small></div>'+
        '<span class="mf-v10-more-arrow">›</span>'+
      '</div>'+
      '<div class="mf-v10-legacy-menu">'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMorePin"><span class="mf-v10-icon">🔢</span><span class="mf-v10-label">PIN Setup / Change</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreAddPin"><span class="mf-v10-icon">➕</span><span class="mf-v10-label">Add Transaction PIN</span><span class="mf-v10-state" id="mfMoreAddPinState">OFF</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreBio"><span class="mf-v10-icon">🔐</span><span class="mf-v10-label">Fingerprint / Biometric</span><span class="mf-v10-state" id="mfMoreBioState">OFF</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreWidgets"><span class="mf-v10-icon">▦</span><span class="mf-v10-label">Widgets</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreExport"><span class="mf-v10-icon">⇩</span><span class="mf-v10-label">Transaction Export</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreNotes"><span class="mf-v10-icon">▤</span><span class="mf-v10-label">Notes</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreCalculator"><span class="mf-v10-icon">▦</span><span class="mf-v10-label">Calculator</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreCustom"><span class="mf-v10-icon">⚙</span><span class="mf-v10-label">Customisation</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreBackup"><span class="mf-v10-icon">☁️</span><span class="mf-v10-label">Backup &amp; Restore</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreHistory"><span class="mf-v10-icon">📊</span><span class="mf-v10-label">Transaction History</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreHelp"><span class="mf-v10-icon">?</span><span class="mf-v10-label">Help &amp; Feedback</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreAccount"><span class="mf-v10-icon">👤</span><span class="mf-v10-label">Account / Login</span><span class="mf-v10-arrow">›</span></button>'+
      '</div>';
  }
  function updateProfileVisual(){
    const p=activeProfile(),src=photo(p),name=p&&p.name?p.name:'Profile / Mode';
    const av=document.getElementById('mfV10MoreAvatar'),nm=document.getElementById('mfV10MoreProfileName'),sub=document.getElementById('mfV10MoreProfileSub');
    if(av)av.innerHTML=src?'<img alt="Profile photo" src="'+esc(src)+'">':FALLBACK;
    if(nm)nm.textContent=name;
    if(sub)sub.textContent='Manage your account';
    const bioState=document.getElementById('mfMoreBioState');
    try{
      const s=p&&p.security;
      if(bioState)bioState.textContent=(s&&s.bioEnabled)?'ON':'OFF';
    }catch(e){}
    const addState=document.getElementById('mfMoreAddPinState');
    try{if(addState)addState.textContent=(p&&p.security&&p.security.addProtection)?'ON':'OFF';}catch(e){}
  }
  function updateProfileModal(){
    const modal=document.getElementById('v10ProfileModal'); if(!modal)return;
    const box=modal.querySelector('.v10box'); if(!box)return;
    let head=box.querySelector('.mf-v10-profile-modal-head');
    if(!head){
      head=document.createElement('div');head.className='mf-v10-profile-modal-head';
      box.insertBefore(head,box.firstChild);
    }
    const p=activeProfile(),src=photo(p),name=p&&p.name?p.name:'My Money';
    head.innerHTML='<div class="mf-v10-profile-modal-avatar">'+(src?'<img alt="Profile photo" src="'+esc(src)+'">':FALLBACK)+'</div><div><b>'+esc(name)+'</b><small>Active Profile / Mode</small></div>';
  }
  function bindLegacy(){
    const ids={
      mfMoreProfileMode:function(){if(typeof window.v10OpenProfiles==='function')window.v10OpenProfiles();},
      mfMoreAccount:function(){if(typeof window.mfOpenAccount==='function')window.mfOpenAccount();},
      mfMoreBackup:function(){if(typeof window.mfOpenBackup==='function')window.mfOpenBackup();},
      mfMorePin:function(){if(typeof window.v10OpenPin==='function')window.v10OpenPin();},
      mfMoreAddPin:function(){if(typeof window.v10AddTxPinSettings==='function')window.v10AddTxPinSettings();},
      mfMoreHistory:function(){if(typeof window.openHistory==='function')window.openHistory();},
      mfMoreExport:function(){if(typeof window.pfOpenExport==='function')window.pfOpenExport();},
      mfMoreWidgets:function(){if(typeof window.pfOpenWidgets==='function')window.pfOpenWidgets();},
      mfMoreCustom:function(){if(typeof window.openCustomization==='function')window.openCustomization();},
      mfMoreBio:function(){if(typeof window.v30OpenBiometricSettings==='function')window.v30OpenBiometricSettings();},
      mfMoreCalculator:function(){if(typeof window.pfOpenCalculator==='function')window.pfOpenCalculator();},
      mfMoreNotes:function(){if(typeof window.pfOpenNotes==='function')window.pfOpenNotes();},
      mfMoreHelp:function(){try{alert('Money Flow Help\n\nNotes are saved locally on this device. Transactions are backed up/restored separately. Use Profile / Mode for profiles and security settings.');}catch(e){} }
    };
    Object.keys(ids).forEach(function(id){const el=document.getElementById(id);if(el&&!el.__mfV10Bound){el.__mfV10Bound=true;el.addEventListener('click',function(e){e.preventDefault();closeEverythingBeforeOpen();setTimeout(ids[id],0);});}});
    const prof=document.getElementById('mfV10MoreProfile');
    if(prof&&!prof.__mfV10Bound){prof.__mfV10Bound=true;['click','keydown'].forEach(function(ev){prof.addEventListener(ev,function(e){if(ev==='keydown'&&e.key!=='Enter'&&e.key!==' ')return;e.preventDefault();closeEverythingBeforeOpen();setTimeout(function(){if(typeof window.v10OpenProfiles==='function')window.v10OpenProfiles();},0);});});}
    updateProfileVisual();
  }
  function patchBuild(){
    const old=window.mfnOpenMore;
    if(typeof old!=='function'||window.__mfV10MorePatched)return;
    window.__mfV10MorePatched=true;
    window.mfnOpenMore=function(){
      old();
      const modal=document.getElementById('mfnMoreModal'); if(!modal)return;
      const sheet=modal.querySelector('.mfn-more-sheet'); if(sheet)sheet.classList.add('mf-v10-more-sheet');
      const existing=sheet&&sheet.querySelector('.mfn-more-menu');
      if(sheet&&!sheet.querySelector('.mf-v10-legacy-menu')){
        sheet.innerHTML='<div class="pf-feature-head"><div><span class="pf-feature-kicker">QUICK ACCESS</span><h2>More</h2></div><button class="pf-feature-close" type="button" id="mfMoreSheetClose">✕</button></div>'+legacyMarkup();
        const close=document.getElementById('mfMoreSheetClose');if(close)close.onclick=function(){window.mfnCloseMore&&window.mfnCloseMore();};
      }
      bindLegacy();
      setTimeout(function(){
        const sh=document.getElementById('mfnMoreModal')?.querySelector('.mfn-more-sheet');
        if(sh)sh.scrollTop=0;
      },0);
    };
    window.mfnOpenMore.__mfV10More='1';
    const origClose=window.mfnCloseMore;
    if(typeof origClose==='function'&&!window.__mfV10ClosePatched){
      window.__mfV10ClosePatched=true;
      window.mfnCloseMore=function(){return origClose.apply(this,arguments);};
    }
  }
  function patchProfile(){
    const old=window.v10OpenProfiles;
    if(typeof old!=='function'||window.__mfV10ProfilePatched)return;
    window.__mfV10ProfilePatched=true;
    window.v10OpenProfiles=function(){
      closeEverythingBeforeOpen();
      old.apply(this,arguments);
      setTimeout(updateProfileModal,0);
    };
  }
  function watch(){patchBuild();patchProfile();updateProfileModal();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',watch);else watch();
  setTimeout(watch,250);setTimeout(watch,800);setTimeout(watch,1500);
  window.addEventListener('storage',function(){updateProfileVisual();updateProfileModal();});
})();
