
/* V30 — FINAL ADD TRANSACTION CORE
   Fixes the actual failure point by making one function responsible for:
   form validation -> transaction creation -> active-profile persistence ->
   legacy-store persistence -> render.
   It intentionally does not alter PIN/profile UI or Edit logic.
*/
(function(){
  function mm30Profiles(){
    try{
      const ps = JSON.parse(localStorage.getItem("money_manager_profiles_v10") || "[]");
      return Array.isArray(ps) ? ps : [];
    }catch(e){ return []; }
  }

  function mm30Active(ps){
    const id = localStorage.getItem("money_manager_active_profile_v10");
    return ps.find(p => p && p.id === id) || ps[0] || null;
  }

  function mm30Save(ps){
    localStorage.setItem("money_manager_profiles_v10", JSON.stringify(ps));
  }

  function mm30Today(){
    if(typeof localToday === "function") return localToday();
    return new Date().toISOString().slice(0,10);
  }

  function mm30Sort(a,b){
    const d = String(b.date||"").localeCompare(String(a.date||""));
    if(d) return d;
    const ca = new Date(a.createdAt || 0).getTime();
    const cb = new Date(b.createdAt || 0).getTime();
    return cb-ca || Number(b.id||0)-Number(a.id||0);
  }

  function mm30Read(id){
    const e = document.getElementById(id);
    return e ? e.value : "";
  }

  function mm30AddCore(){
    try{
      const dateEl = document.getElementById("date");
      const typeEl = document.getElementById("type");
      const amountPresetEl = document.getElementById("amountPreset");
      const customAmountEl = document.getElementById("customAmount");
      const categoryEl = document.getElementById("categorySelect");
      const customCategoryEl = document.getElementById("customCategory");

      if(!dateEl || !typeEl || !amountPresetEl || !categoryEl){
        alert("Add Transaction form is not ready.");
        return false;
      }

      const today = mm30Today();
      dateEl.max = today;

      const date = dateEl.value;
      const type = typeEl.value;
      const preset = amountPresetEl.value;
      const amount = preset === "CUSTOM"
        ? Number(customAmountEl && customAmountEl.value)
        : Number(preset);

      const selectedCategory = categoryEl.value;
      const category = selectedCategory === "CUSTOM"
        ? String(customCategoryEl && customCategoryEl.value || "").trim()
        : selectedCategory;

      if(!date || date > today){
        dateEl.value = today;
        alert("Please select today or an earlier date.");
        return false;
      }

      if(type!=="CREDIT" && type!=="EXPENSE"){
        alert("Please select Credit or Expense.");
        return false;
      }

      if(!Number.isFinite(amount) || amount <= 0){
        alert("Please enter a valid amount.");
        return false;
      }

      if(!category){
        alert("Please select or enter a category.");
        return false;
      }

      const ps = mm30Profiles();
      const p = mm30Active(ps);

      if(!p){
        alert("Profile is not ready. Please open Profile / Mode once and try again.");
        return false;
      }

      p.transactions = Array.isArray(p.transactions) ? p.transactions : [];

      // Active profile is authoritative. This prevents stale/old global txs
      // from replacing the current profile's transaction list.
      const current = p.transactions.map(t => ({...t}));

      const tx = {
        id: Date.now() + Math.floor(Math.random()*1000),
        createdAt: new Date().toISOString(),
        date: date,
        type: type,
        amount: amount,
        category: category,
        description: mm30Read("description").trim(),
        remark: mm30Read("remark").trim(),
        mode: mm30Read("mode").trim(),
        other: mm30Read("other").trim()
      };

      current.push(tx);
      current.sort(mm30Sort);

      // Save to the active profile first.
      p.transactions = current;
      const index = ps.findIndex(x => x && x.id === p.id);
      if(index < 0){
        alert("Active profile could not be saved.");
        return false;
      }
      ps[index] = p;
      mm30Save(ps);

      // Keep the legacy transaction store and in-memory list synchronized.
      txs = current.map(t => ({...t}));
      localStorage.setItem(
        typeof KEY !== "undefined" ? KEY : "money_manager_v1",
        JSON.stringify(txs)
      );

      // Render only after persistence succeeds.
      if(typeof render === "function") render();

      // Reset the complete Add Transaction form after a successful save.
      // Only today's date is preselected for the next transaction.
      if(typeof window.pfResetAddTransactionForm === "function") window.pfResetAddTransactionForm();
      if(typeof v10RefreshAddTxSecurityUI === "function") v10RefreshAddTxSecurityUI();

      // Close the actual Add Transaction sheet only after the final save succeeds.
      // This is inside the authoritative save core, so it also works after PIN verification.
      if(typeof window.pfCloseAddTransaction === "function") window.pfCloseAddTransaction();

      return true;
    }catch(err){
      console.error("V30 Add Transaction error:", err);
      alert("Transaction could not be saved. Please try again.");
      return false;
    }
  }

  // Replace only the transaction-writing core. Existing PIN/recovery gate
  // remains responsible for authentication before this function is called.
  window.v109RealAdd = mm30AddCore;

  // Final request handler: OFF -> direct save; ON -> existing common PIN gate.
  window.v109RequestAddTransaction = function(){
    try{
      const ps = mm30Profiles();
      const p = mm30Active(ps);

      if(!p){
        alert("Profile is not ready.");
        return false;
      }

      p.security = p.security || {};
      const protection = !!p.security.addProtection;

      if(!protection){
        return mm30AddCore();
      }

      // Reuse the existing unified PIN gate from V26/V19.
      if(typeof window.v26AskPin === "function"){
        return window.v26AskPin(
          function(){ mm30AddCore(); },
          function(){}
        );
      }

      alert("PIN security interface is unavailable.");
      return false;
    }catch(err){
      console.error("V30 Add Transaction request error:", err);
      alert("Add Transaction could not be started.");
      return false;
    }
  };

  console.log("Money Manager V30: Add Transaction core loaded.");
})();
