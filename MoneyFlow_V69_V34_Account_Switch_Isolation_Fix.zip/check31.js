
(function(){
  'use strict';
  function build(){
    if(document.getElementById('mfnMoreModal'))return;
    const d=document.createElement('div');d.id='mfnMoreModal';d.className='mfn-more-modal';d.setAttribute('aria-hidden','true');
    d.innerHTML='<div class="mfn-more-sheet"><div class="pf-feature-head"><div><span class="pf-feature-kicker">QUICK ACCESS</span><h2>More</h2></div><button class="pf-feature-close" type="button" onclick="mfnCloseMore()">✕</button></div><div class="mfn-more-profile" onclick="v10OpenProfiles()"><div class="mfn-more-avatar">👤</div><div><b>Profile</b><small>Manage your account</small></div><span style="margin-left:auto;color:#8b8378;font-size:20px">›</span></div><div class="mfn-more-menu"><button class="mfn-more-item" type="button" onclick="pfOpenCalculator();mfnCloseMore()"><span>▦</span>Calculator<small>›</small></button><button class="mfn-more-item" type="button" onclick="pfOpenNotes();mfnCloseMore()"><span>▤</span>Notes<small>›</small></button><button class="mfn-more-item" type="button" onclick="mfOpenBackup();mfnCloseMore()"><span>☁</span>Backup &amp; Sync<small>›</small></button><button class="mfn-more-item" type="button" onclick="openCustomization();mfnCloseMore()"><span>⚙</span>Settings<small>›</small></button><button class="mfn-more-item" type="button" onclick="mfnHelp()"><span>?</span>Help &amp; Feedback<small>›</small></button></div><div class="mfn-help" id="mfnHelpBox" style="display:none"><b>Money Flow Help</b><br>Notes are saved locally on this device. You can create, edit, pin, search, filter, complete checklist items, and use templates. Backup &amp; Sync remains available from this screen.</div></div>';
    d.addEventListener('click',function(e){if(e.target===d)mfnCloseMore()});document.body.appendChild(d);
  }
  window.mfnOpenMore=function(){build();const m=document.getElementById('mfnMoreModal');m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';if(typeof window.pfSetNav==='function')window.pfSetNav(document.getElementById('moreNavBtn'))};
  window.mfnCloseMore=function(){const m=document.getElementById('mfnMoreModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow=''};
  window.mfnHelp=function(){const b=document.getElementById('mfnHelpBox');if(b)b.style.display=b.style.display==='none'?'block':'none'};
  function wire(){const b=document.getElementById('moreNavBtn');if(b&&!b.__mfnMore){b.__mfnMore=true;b.onclick=function(e){if(e)e.preventDefault();mfnOpenMore()}}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wire);else wire();setTimeout(wire,300);setTimeout(wire,1000);
})();
