
(function(){
  const originalAdd=window.v109RequestAddTransaction;
  window.pfOpenAddTransaction=function(){
    closeMenu();
    const m=document.getElementById("addTransactionModal"); if(!m)return;
    const d=document.getElementById("date"); if(d)d.value=localToday();
    m.style.display="block"; document.body.style.overflow="hidden";
  };
  window.pfCloseAddTransaction=function(){const m=document.getElementById("addTransactionModal");if(m)m.style.display="none";document.body.style.overflow="";};
  window.v109RequestAddTransaction=function(){
    const result=originalAdd?originalAdd():false;
    if(result)window.pfCloseAddTransaction();
    return result;
  };
  function pfShowScreen(name){
    const homeSections=document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)');
    const txPage=document.getElementById('pfTransactionsPage');
    if(name==='transactions'){
      homeSections.forEach(el=>el.style.display='none');
      if(txPage)txPage.style.display='block';
      pfRenderTransactionsPage();
      window.scrollTo({top:0,behavior:'smooth'});
    }else{
      if(txPage)txPage.style.display='none';
      homeSections.forEach(el=>el.style.display='');
      window.scrollTo({top:0,behavior:'smooth'});
    }
  }
  const pfTxState={view:'monthly',month:(new Date()).toISOString().slice(0,7),weekOffset:0};
  function pfTxPad(n){return String(n).padStart(2,'0')}
  function pfTxMonthLabel(ym){
    const [y,m]=ym.split('-').map(Number);
    return new Date(y,m-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  }
  function pfTxMonthBounds(ym){
    const [y,m]=ym.split('-').map(Number);
    const first=new Date(y,m-1,1);
    const last=new Date(y,m,0);
    return {from:`${y}-${pfTxPad(m)}-01`,to:`${y}-${pfTxPad(m)}-${pfTxPad(last.getDate())}`};
  }
  function pfTxShiftMonth(delta){
    const [y,m]=pfTxState.month.split('-').map(Number);
    const d=new Date(y,m-1+delta,1);
    pfTxState.month=`${d.getFullYear()}-${pfTxPad(d.getMonth()+1)}`;
    pfTxState.weekOffset=0;
    pfTxSyncControls();
    pfTxRender();
  }
  function pfTxOpenMonthPicker(){
    const el=document.getElementById('pfTxMonthPicker');
    if(!el)return;
    el.value=pfTxState.month;
    if(typeof el.showPicker==='function'){try{el.showPicker();return}catch(e){}}
    el.style.display='block';el.focus();
  }
  window.pfTxSetMonth=function(value){
    if(!/^\d{4}-\d{2}$/.test(value))return;
    pfTxState.month=value;pfTxState.weekOffset=0;
    const el=document.getElementById('pfTxMonthPicker');if(el)el.style.display='none';
    pfTxSyncControls();pfTxRender();
  };
  function pfTxWeekStart(){
    const b=pfTxMonthBounds(pfTxState.month);
    const base=new Date(b.from+'T00:00:00');
    const day=base.getDay();
    base.setDate(base.getDate()-day+(pfTxState.weekOffset*7));
    return base;
  }
  function pfTxShiftWeek(delta){pfTxState.weekOffset+=delta;pfTxSyncControls();pfTxRender();}
  function pfTxDateString(d){return `${d.getFullYear()}-${pfTxPad(d.getMonth()+1)}-${pfTxPad(d.getDate())}`}
  function pfTxSyncControls(){
    const b=pfTxMonthBounds(pfTxState.month);
    const mb=document.getElementById('pfTxMonthButton');if(mb)mb.innerHTML=`${pfTxMonthLabel(pfTxState.month)} <span>⌄</span>`;
    const dp=document.getElementById('pfTxDayPicker');if(dp){if(!dp.value||dp.value.slice(0,7)!==pfTxState.month)dp.value=b.from;dp.min=b.from;dp.max=b.to;}
    const from=document.getElementById('pfTxFrom'),to=document.getElementById('pfTxTo');
    if(from&&!from.value)from.value=b.from;if(to&&!to.value)to.value=b.to;
    if(from){from.max='9999-12-31';}if(to){to.min='0001-01-01';}
    const ws=pfTxWeekStart(),we=new Date(ws);we.setDate(we.getDate()+6);
    const wl=document.getElementById('pfTxWeekLabel');if(wl)wl.textContent=`${pfTxDateString(ws)} → ${pfTxDateString(we)}`;
  }
  window.pfTxSetView=function(view,btn){
    pfTxState.view=view;pfTxState.weekOffset=0;
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.remove('active'));
    if(btn)btn.classList.add('active');
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');
    if(d)d.style.display=view==='daily'?'flex':'none';
    if(w)w.style.display=view==='weekly'?'flex':'none';
    if(c)c.style.display=view==='custom'?'grid':'none';
    pfTxSyncControls();pfTxRender();
  };
  function pfTxFiltered(){
    const b=pfTxMonthBounds(pfTxState.month);
    let from=b.from,to=b.to;
    if(pfTxState.view==='daily'){
      from=to=document.getElementById('pfTxDayPicker')?.value||b.from;
    }else if(pfTxState.view==='weekly'){
      const ws=pfTxWeekStart(),we=new Date(ws);we.setDate(we.getDate()+6);
      from=pfTxDateString(ws);to=pfTxDateString(we);
    }else if(pfTxState.view==='custom'){
      from=document.getElementById('pfTxFrom')?.value||b.from;to=document.getElementById('pfTxTo')?.value||b.to;
      if(from>to){const tmp=from;from=to;to=tmp;}
    }else if(pfTxState.view==='history'){
      const dates=txs.map(t=>t.date).filter(Boolean).sort();
      from=dates[0]||b.from;to=dates[dates.length-1]||b.to;
    }
    return {from,to,data:txs.filter(t=>t.date>=from&&t.date<=to).slice().sort(compareTransactionsLatestFirst)};
  }
  window.pfTxRender=function(){
    const summary=document.getElementById('pfTransactionsSummary'),list=document.getElementById('pfTransactionsList');
    if(!summary||!list)return;
    const q=pfTxFiltered();let income=0,expense=0;
    q.data.forEach(t=>{if(t.type==='CREDIT')income+=Number(t.amount)||0;else expense+=Number(t.amount)||0});
    const viewLabel={daily:'Daily',weekly:'Weekly',monthly:'Monthly',custom:'Custom',history:'History'}[pfTxState.view]||'Transactions';
    summary.textContent=`${viewLabel} • ${q.from} → ${q.to} • ${q.data.length} transaction(s) • Income ${money(income)} • Expense ${money(expense)} • Balance ${money(income-expense)}`;
    list.innerHTML='';
    if(!q.data.length){list.innerHTML='<div class="pf-empty">No transactions found for this view.</div>';return;}
    q.data.forEach(t=>{
      const div=document.createElement('div');div.className='pf-swipe-row';
      const title=escapeHtml(t.category||'Uncategorized');
      const meta=escapeHtml(`${t.date} • ${t.mode||''}${t.description?' • '+t.description:''}`);
      const amt=(t.type==='CREDIT'?'+':'-')+money(t.amount);
      const icon=t.type==='CREDIT'?'↓':'↑';
      div.innerHTML=`<div class="pf-swipe-content"><div class="pf-swipe-icon ${t.type==='CREDIT'?'income':'expense'}">${icon}</div><div class="pf-swipe-main"><div class="pf-swipe-title">${title}</div><div class="pf-swipe-meta">${meta}</div></div><div class="pf-swipe-amount ${t.type==='CREDIT'?'income':'expense'}">${amt}</div></div><div class="pf-swipe-actions"><button class="pf-swipe-edit" type="button">Edit</button></div>`;
      const content=div.querySelector('.pf-swipe-content'),edit=div.querySelector('.pf-swipe-edit');
      let sx=0,sy=0,moved=false;
      content.addEventListener('touchstart',e=>{if(!e.touches[0])return;sx=e.touches[0].clientX;sy=e.touches[0].clientY;moved=false},{passive:true});
      content.addEventListener('touchmove',e=>{if(!e.touches[0])return;const dx=e.touches[0].clientX-sx,dy=e.touches[0].clientY-sy;if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){moved=true;e.preventDefault();content.style.transition='none';const x=Math.max(-92,Math.min(0,dx));content.style.transform=`translateX(${x}px)`;}},{passive:false});
      content.addEventListener('touchend',e=>{if(!moved)return;content.style.transition='transform .18s ease';const dx=(e.changedTouches[0]?.clientX||sx)-sx;if(dx<-45){document.querySelectorAll('.pf-swipe-row.open').forEach(r=>{if(r!==div){r.classList.remove('open');const c=r.querySelector('.pf-swipe-content');if(c)c.style.transform='translateX(0)';}});div.classList.add('open');content.style.transform='translateX(-92px)';}else{div.classList.remove('open');content.style.transform='translateX(0)';}});
      edit.addEventListener('click',()=>{div.classList.remove('open');content.style.transform='translateX(0)';if(canEditTransaction(t))v10RequestEdit(t.id);else alert('This transaction is locked. Editing is allowed only within 5 days of adding it.');});
      list.appendChild(div);
    });
  };
  window.pfRenderTransactionsPage=function(){
    pfTxSyncControls();
    const active=document.querySelector('.pf-tx-tabs button[data-view="'+pfTxState.view+'"]');
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===active));
    document.getElementById('pfTxDailyControls').style.display=pfTxState.view==='daily'?'flex':'none';
    document.getElementById('pfTxWeeklyControls').style.display=pfTxState.view==='weekly'?'flex':'none';
    document.getElementById('pfTxCustomControls').style.display=pfTxState.view==='custom'?'grid':'none';
    pfTxRender();
  };
  window.pfNav=function(name,btn){
    pfShowScreen(name==='transactions'?'transactions':'home');
    pfSetNav(btn);
  };
  window.pfSetNav=function(btn){document.querySelectorAll('.pf-bottom-nav button').forEach(b=>b.classList.remove('active'));if(btn)btn.classList.add('active');};
  function boot(){
    const el=document.getElementById("pfTodayLabel"); if(el){const d=new Date();el.textContent=d.toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"});}
    render();
    pfTxSyncControls();
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,500);
  document.addEventListener("click",function(e){const m=document.getElementById("addTransactionModal");if(e.target===m)pfCloseAddTransaction();});
})();
