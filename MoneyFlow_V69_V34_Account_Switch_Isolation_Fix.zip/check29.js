
(function(){
  'use strict';
  function resolveOriginalId(raw){
    if(raw===null||raw===undefined||raw==='') return raw;
    const list=(typeof txs!=='undefined'&&Array.isArray(txs))?txs:[];
    const hit=list.find(function(t){ return String(t && t.id)===String(raw); });
    return hit ? hit.id : raw;
  }

  /* Keep the already-working Edit/PIN/security path untouched; only normalize
     IDs arriving from swipe DOM elements before forwarding to it. */
  function normalizeSwipeEditButton(btn,row){
    if(!btn||btn.dataset.swipeIdFix==='1') return;
    btn.dataset.swipeIdFix='1';
    let lastTouch=0;
    function forward(e){
      if(e){e.preventDefault();e.stopPropagation();}
      const now=Date.now();
      /* Android WebView can emit touchend followed by a synthetic click. */
      if(e && e.type==='click' && now-lastTouch<700) return;
      if(e && e.type==='touchend') lastTouch=now;
      const raw=row && row.getAttribute ? row.getAttribute('data-tx-id') : null;
      const id=resolveOriginalId(raw);
      if(id!==null&&id!==''&&typeof window.v10RequestEdit==='function'){
        window.v10RequestEdit(id);
      }
    }
    btn.addEventListener('click',forward,true);
    btn.addEventListener('touchend',forward,{capture:true,passive:false});
  }

  function patchRows(root){
    const list=root||document.getElementById('pfTransactionsList');
    if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(function(row){
      const btn=row.querySelector('.pf-swipe-reveal');
      if(btn) normalizeSwipeEditButton(btn,row);
    });
  }

  const list=document.getElementById('pfTransactionsList');
  if(list){
    new MutationObserver(function(){patchRows(list);}).observe(list,{childList:true,subtree:true});
    patchRows(list);
  }
})();
