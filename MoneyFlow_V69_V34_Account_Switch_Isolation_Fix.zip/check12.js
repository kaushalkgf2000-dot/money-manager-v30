
(function(){
  'use strict';
  var stack=[], current='home';
  function setScreen(s, push){
    if(push && s!==current) stack.push(current);
    current=s;
  }
  function resetHome(){stack=[];current='home';}

  // Track the two real page-level screens. Existing calls continue to work normally.
  if(typeof window.pfNav==='function'&&!window.__mfV8NavWrap){
    window.__mfV8NavWrap=true;
    var nav=window.pfNav;
    window.pfNav=function(name,btn){
      if(name==='transactions')setScreen('transactions',true);
      else if(name==='home')setScreen('home',true);
      return nav.apply(this,arguments);
    };
  }

  // Notes has its own internal sequence: list → detail/create/categories/templates.
  var noteCurrent='list', noteStack=[];
  function notePush(next){if(next&&next!==noteCurrent){noteStack.push(noteCurrent);noteCurrent=next;}}
  function noteReset(){noteCurrent='list';noteStack=[];}
  function noteBack(){
    var prev=noteStack.length?noteStack.pop():null;
    if(prev){noteCurrent=prev;if(typeof window.mfnShow==='function')window.mfnShow(prev);return true;}
    noteCurrent='list';return false;
  }
  function wrap(name,next){
    if(typeof window[name]!=='function'||window['__mfV8W_'+name])return;
    window['__mfV8W_'+name]=true;
    var old=window[name];
    window[name]=function(){var r=next.apply(null,arguments);return old.apply(this,arguments);};
  }
  // Dedicated wrappers are installed directly because the earlier Notes script
  // is loaded before this final coordinator.
  if(typeof window.mfnShow==='function'&&!window.__mfV8W_mfnShow){
    window.__mfV8W_mfnShow=true;var os=window.mfnShow;
    window.mfnShow=function(v){notePush(v);return os.apply(this,arguments);};
  }
  if(typeof window.mfnOpen==='function'&&!window.__mfV8W_mfnOpen){
    window.__mfV8W_mfnOpen=true;var oo=window.mfnOpen;
    window.mfnOpen=function(id){notePush('detail');return oo.apply(this,arguments);};
  }
  if(typeof window.mfnNew==='function'&&!window.__mfV8W_mfnNew){
    window.__mfV8W_mfnNew=true;var on=window.mfnNew;
    window.mfnNew=function(){notePush('create');return on.apply(this,arguments);};
  }
  if(typeof window.mfnEdit==='function'&&!window.__mfV8W_mfnEdit){
    window.__mfV8W_mfnEdit=true;var oe=window.mfnEdit;
    window.mfnEdit=function(){notePush('create');return oe.apply(this,arguments);};
  }
  if(typeof window.mfnUseTemplate==='function'&&!window.__mfV8W_mfnUseTemplate){
    window.__mfV8W_mfnUseTemplate=true;var ot=window.mfnUseTemplate;
    window.mfnUseTemplate=function(i){notePush('detail');return ot.apply(this,arguments);};
  }
  if(typeof window.mfnSaveForm==='function'&&!window.__mfV8W_mfnSaveForm){
    window.__mfV8W_mfnSaveForm=true;var sf=window.mfnSaveForm;
    window.mfnSaveForm=function(){var r=sf.apply(this,arguments);noteCurrent='detail';return r;};
  }
  if(typeof window.mfnDelete==='function'&&!window.__mfV8W_mfnDelete){
    window.__mfV8W_mfnDelete=true;var md=window.mfnDelete;
    window.mfnDelete=function(){var r=md.apply(this,arguments);noteCurrent='list';noteStack=[];return r;};
  }
  if(typeof window.pfOpenNotes==='function'&&!window.__mfV8W_pfOpenNotes){
    window.__mfV8W_pfOpenNotes=true;var pon=window.pfOpenNotes;
    window.pfOpenNotes=function(){noteReset();return pon.apply(this,arguments);};
  }

  function displayed(el){
    if(!el)return false;
    var cs=getComputedStyle(el);
    return cs.display!=='none'&&cs.visibility!=='hidden';
  }
  function closeOverlay(){
    var more=document.getElementById('mfnMoreModal');
    if(more&&more.classList.contains('open')){window.mfnCloseMore&&window.mfnCloseMore();return true;}

    // Notes is a modal, but its internal views must be traversed before closing it.
    var notes=document.getElementById('pfNotesModal');
    if(notes&&notes.classList.contains('open')){
      if(noteBack())return true;
      window.pfCloseFeature&&window.pfCloseFeature('pfNotesModal');
      document.body.style.overflow='';
      return true;
    }

    var fs=Array.from(document.querySelectorAll('.pf-feature-modal.open'));
    if(fs.length){var f=fs[fs.length-1];window.pfCloseFeature?window.pfCloseFeature(f.id):f.classList.remove('open');return true;}
    var ex=document.getElementById('pfExportModal');
    if(ex&&ex.classList.contains('open')){window.pfCloseExport?window.pfCloseExport():ex.classList.remove('open');return true;}

    var maps=[
      ['addTransactionModal','pfCloseAddTransaction'],['editModal','closeEdit'],['historyModal','closeHistory'],
      ['customModal','closeCustomization'],['mfBackupModal','mfCloseBackup'],['mfAccountModal','mfCloseAccount'],
      ['v10ProfileModal','v10CloseProfileModal'],['v10PinModal','v10ClosePinModal'],
      ['v10AddTxPinModal','v10CloseAddTxPinSettings'],['v10AddTxSettingGate','closeSettingGate'],
      ['v10AddTxGate','closeG'],['profilePhotoModal','pfCloseProfilePhotoMenu']
    ];
    for(var i=0;i<maps.length;i++){
      var el=document.getElementById(maps[i][0]);
      if(el&&displayed(el)){
        var fn=window[maps[i][1]];if(typeof fn==='function')fn();else el.style.display='none';
        document.body.style.overflow='';return true;
      }
    }
    var vm=Array.from(document.querySelectorAll('.v10modal')).filter(displayed);
    if(vm.length){vm[vm.length-1].style.display='none';document.body.style.overflow='';return true;}
    var menu=document.getElementById('menuPanel');
    if(menu&&displayed(menu)){window.closeMenu?window.closeMenu():menu.style.display='none';return true;}
    return false;
  }

  window.mfHandleAndroidBack=function(){
    if(closeOverlay())return true;

    // Category history is a sub-step of Transactions.
    if(window.__pfCategoryHistoryFilter){
      window.__pfCategoryHistoryFilter='';
      if(typeof window.pfOpenCategory==='function')window.pfOpenCategory();
      return true;
    }

    var tx=document.getElementById('pfTransactionsPage');
    if(tx&&getComputedStyle(tx).display!=='none'){
      var hb=document.querySelector('.pf-bottom-nav button:nth-child(1)');
      if(typeof window.pfNav==='function')window.pfNav('home',hb);
      else tx.style.display='none';
      if(typeof window.pfSetNav==='function')window.pfSetNav(hb);
      window.scrollTo({top:0,behavior:'smooth'});
      return true;
    }

    // Home is the root. Native Activity will close here.
    return false;
  };
})();
