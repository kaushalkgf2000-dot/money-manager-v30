
(function(){
  'use strict';
  const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
  function read(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=read(),id=localStorage.getItem(AK);return a.find(p=>p&&String(p.id)===String(id))||a[0]||null}
  function refresh(){
    const p=active();if(!p)return;
    const badge=document.getElementById('profileBadge');if(badge)badge.textContent=p.name||'My Money';
    const btn=document.getElementById('profilePhotoBtn');
    if(btn){const src=typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0?p.profilePhoto:'';if(src)btn.innerHTML='<img alt="Money Flow profile" src="'+src+'">';}
    const backup=document.getElementById('mfBackupAccount');if(backup)backup.textContent=p.name||'My Money';
    try{if(typeof window.v10RefreshAddTxSecurityUI==='function')window.v10RefreshAddTxSecurityUI()}catch(e){}
    try{if(typeof window.render==='function')window.render()}catch(e){}
    try{if(typeof window.pfRenderTransactionsPage==='function')window.pfRenderTransactionsPage()}catch(e){}
    try{if(typeof window.pfRenderAnalytics==='function')window.pfRenderAnalytics()}catch(e){}
  }
  const old=window.v10SwitchProfile;
  if(typeof old==='function'&&!window.__mfV18SwitchWrapped){
    window.__mfV18SwitchWrapped=true;
    window.v10SwitchProfile=function(id){const r=old.apply(this,arguments);setTimeout(refresh,0);setTimeout(refresh,60);setTimeout(refresh,220);return r;};
  }
  window.mfRefreshActiveProfileUI=refresh;
  window.addEventListener('load',function(){setTimeout(refresh,0);setTimeout(refresh,250)});
})();
