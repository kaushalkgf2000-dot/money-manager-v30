
/* FINAL TRANSACTIONS FUNCTIONALITY FIX
   - Analytics/Search/Category operate on the same active transaction data.
   - Weekly navigation uses a real week anchor and crosses month boundaries correctly.
   - Transaction rows expose all stored details with an expand/collapse control.
   - Edit uses type-specific categories and requires category re-selection after type changes.
   - Existing Sign-Out/Drive backup and unrelated app logic are untouched.
*/
(function(){
  function pfReadTx(){
    try{
      if(typeof txs!=='undefined' && Array.isArray(txs)) return txs.slice().sort(compareTransactionsLatestFirst);
    }catch(e){}
    return [];
  }
  function pad(n){return String(n).padStart(2,'0')}
  function dateStr(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
  function monthBounds(ym){
    const [y,m]=String(ym).split('-').map(Number);
    const first=new Date(y,m-1,1), last=new Date(y,m,0);
    return {from:dateStr(first),to:dateStr(last)};
  }
  function currentMonth(){return new Date().getFullYear()+'-'+pad(new Date().getMonth()+1)}

  // --- Transaction period state (fixes Weekly Previous/Next) ---
  const state=window.__pfTxFinalState||{view:'monthly',month:currentMonth(),weekAnchor:dateStr(new Date())};
  window.__pfTxFinalState=state;
  function ensureWeekAnchor(){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(state.weekAnchor)) state.weekAnchor=monthBounds(state.month).from;
    const d=new Date(state.weekAnchor+'T00:00:00');
    if(Number.isNaN(d.getTime())) state.weekAnchor=monthBounds(state.month).from;
  }
  function weekBounds(){
    ensureWeekAnchor();
    const d=new Date(state.weekAnchor+'T00:00:00');
    const day=d.getDay();
    d.setDate(d.getDate()-day);
    const e=new Date(d);e.setDate(e.getDate()+6);
    return {from:dateStr(d),to:dateStr(e)};
  }
  function filtered(){
    const b=monthBounds(state.month);let from=b.from,to=b.to;
    if(state.view==='daily'){
      const v=document.getElementById('pfTxDayPicker')?.value;from=to=v||b.from;
    }else if(state.view==='weekly'){
      const w=weekBounds();from=w.from;to=w.to;
    }else if(state.view==='custom'){
      from=document.getElementById('pfTxFrom')?.value||b.from;
      to=document.getElementById('pfTxTo')?.value||b.to;
      if(from>to){const x=from;from=to;to=x;}
    }
    return {from,to,data:pfReadTx().filter(t=>String(t.date||'')>=from&&String(t.date||'')<=to)};
  }
  function syncControls(){
    const b=monthBounds(state.month);
    const mb=document.getElementById('pfTxMonthButton');
    if(mb){const [y,m]=state.month.split('-').map(Number);mb.innerHTML=new Date(y,m-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'})+' <span>⌄</span>';}
    const dp=document.getElementById('pfTxDayPicker');
    if(dp){if(!dp.value||dp.value.slice(0,7)!==state.month)dp.value=b.from;dp.min=b.from;dp.max=b.to;}
    const f=document.getElementById('pfTxFrom'),t=document.getElementById('pfTxTo');
    if(f&&!f.value)f.value=b.from;if(t&&!t.value)t.value=b.to;
    const w=weekBounds(),wl=document.getElementById('pfTxWeekLabel');if(wl)wl.textContent=w.from+' → '+w.to;
  }
  function renderRows(data){
    const list=document.getElementById('pfTransactionsList');if(!list)return;
    list.innerHTML='';
    if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this view.</div>';return;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));
      const type=t.type==='CREDIT'?'income':'expense';
      const sign=t.type==='CREDIT'?'+':'-';
      const fields=[
        ['Date',t.date||'—'],['Type',t.type==='CREDIT'?'Credit':'Expense'],['Amount',sign+money(t.amount)],
        ['Category',t.category||'Uncategorized'],['Payment Mode',t.mode||t.paymentMode||'Not specified'],
        ['Description',t.description||t.desc||'—'],['Remark',t.remark||t.remarks||t.note||'—'],['Other',t.other||t.otherInfo||t.other_info||'—']
      ];
      row.innerHTML=`<div class="pf-detail-main"><div class="pf-swipe-icon ${type}">${t.type==='CREDIT'?'↓':'↑'}</div><div class="pf-detail-summary"><div class="pf-detail-title">${escapeHtml(t.category||'Uncategorized')}</div><div class="pf-detail-meta">${escapeHtml(t.date||'')} • ${escapeHtml(t.mode||'Not specified')}</div><div class="pf-detail-secondary">${t.description?escapeHtml(t.description):'No description'}${t.remark?' • Remark: '+escapeHtml(t.remark):''}</div></div><div class="pf-swipe-amount ${type}">${sign}${money(t.amount)}</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-panel-title">Transaction Details</div>${fields.map(([k,v])=>`<div class="pf-detail-field"><span>${k}</span><b class="${k==='Amount'?type:''}">${escapeHtml(String(v))}</b></div>`).join('')}<div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>`;
      const main=row.querySelector('.pf-detail-main'),exp=row.querySelector('.pf-expand-btn'),panel=row.querySelector('.pf-detail-panel'),edit=row.querySelector('.pf-swipe-edit');
      exp.addEventListener('click',()=>{const open=row.classList.toggle('expanded');exp.textContent=open?'⌃':'⌄';exp.setAttribute('aria-expanded',open?'true':'false');panel.style.display=open?'block':'none';});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      list.appendChild(row);
    });
  }
  function render(){
    syncControls();const q=filtered();let income=0,expense=0;q.data.forEach(t=>t.type==='CREDIT'?income+=Number(t.amount)||0:expense+=Number(t.amount)||0);
    const lab={daily:'Daily',weekly:'Weekly',monthly:'Monthly',custom:'Custom'}[state.view]||'Monthly';
    const sum=document.getElementById('pfTransactionsSummary');if(sum)sum.textContent=`${lab} • ${q.from} → ${q.to} • ${q.data.length} transaction(s) • Income ${money(income)} • Expense ${money(expense)} • Balance ${money(income-expense)}`;
    renderRows(q.data);
  }
  window.pfTxFinalFiltered=filtered;
  window.pfTxRender=render;
  window.pfTxShiftMonth=function(delta){const [y,m]=state.month.split('-').map(Number);const d=new Date(y,m-1+delta,1);state.month=d.getFullYear()+'-'+pad(d.getMonth()+1);state.weekAnchor=state.month+'-01';syncControls();render();};
  window.pfTxSetMonth=function(v){if(/^\d{4}-\d{2}$/.test(v)){state.month=v;state.weekAnchor=v+'-01';const el=document.getElementById('pfTxMonthPicker');if(el)el.style.display='none';syncControls();render();}};
  window.pfTxShiftWeek=function(delta){ensureWeekAnchor();const d=new Date(state.weekAnchor+'T00:00:00');d.setDate(d.getDate()+delta*7);state.weekAnchor=dateStr(d);state.month=state.weekAnchor.slice(0,7);syncControls();render();};
  window.pfTxSetView=function(view,btn){state.view=view;document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===btn));if(view==='weekly'){if(!state.weekAnchor)state.weekAnchor=dateStr(new Date());}else if(view==='daily'){const b=monthBounds(state.month);const dp=document.getElementById('pfTxDayPicker');if(dp&&!dp.value)dp.value=b.from;}document.getElementById('pfTxDailyControls').style.display=view==='daily'?'flex':'none';document.getElementById('pfTxWeeklyControls').style.display=view==='weekly'?'flex':'none';document.getElementById('pfTxCustomControls').style.display=view==='custom'?'grid':'none';syncControls();render();};
  window.pfRenderTransactionsPage=function(){syncControls();const active=document.querySelector('.pf-tx-tabs button[data-view="'+state.view+'"]');document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===active));document.getElementById('pfTxDailyControls').style.display=state.view==='daily'?'flex':'none';document.getElementById('pfTxWeeklyControls').style.display=state.view==='weekly'?'flex':'none';document.getElementById('pfTxCustomControls').style.display=state.view==='custom'?'grid':'none';render();};

  // --- Analytics/Search/Category: no dependency on the private IIFE helpers ---
  function openFeature(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  function closeFeature(id){const m=document.getElementById(id);if(m)m.classList.remove('open');if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow='';}
  window.pfCloseFeature=closeFeature;
  let analyticsType='EXPENSE',catType='EXPENSE',catPeriod='all';
  function analyticsData(){return filtered().data.filter(t=>t.type===analyticsType);}
  function renderAnalytics(){const data=analyticsData(),by={};data.forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,x)=>a+x[1],0),donut=document.getElementById('pfDonut'),legend=document.getElementById('pfAnalyticsLegend');if(!donut||!legend)return;document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;donut.style.background='conic-gradient('+entries.map((x,i)=>{const end=start+x[1]/total*100;const z=palette[i%palette.length]+' '+start+'% '+end+'%';start=end;return z}).join(',')+')';legend.innerHTML=entries.map((x,i)=>`<div class="pf-legend-row"><i class="pf-legend-dot" style="background:${palette[i%palette.length]}"></i><b>${escapeHtml(x[0])}</b><span>${money(x[1])} · ${(x[1]/total*100).toFixed(1)}%</span></div>`).join('');}
  window.pfOpenAnalytics=function(){openFeature('pfAnalyticsModal');renderAnalytics();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense').classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome').classList.toggle('active',type==='CREDIT');renderAnalytics();};
  function renderSearch(q){const list=document.getElementById('pfSearchResults');if(!list)return;const query=String(q||'').trim().toLowerCase();let data=pfReadTx();if(query)data=data.filter(t=>[t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other].some(v=>String(v??'').toLowerCase().includes(query)));list.innerHTML=data.length?data.slice(0,100).map(t=>`<div class="pf-search-result"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(t.date||'')} • ${escapeHtml(t.mode||'')}${t.description?' • '+escapeHtml(t.description):''}${t.remark?' • Remark: '+escapeHtml(t.remark):''}</small></div><strong style="color:${t.type==='CREDIT'?'#2fa65b':'#e3483d'}">${t.type==='CREDIT'?'+':'-'}${money(t.amount)}</strong></div>`).join(''):'<div class="pf-empty">No matching transactions found.</div>';}
  window.pfOpenSearch=function(){openFeature('pfSearchModal');const input=document.getElementById('pfSearchInput');if(input){input.value='';setTimeout(()=>input.focus(),80);}renderSearch('');};
  window.pfOpenCategory=function(){openFeature('pfCategoryModal');const b=monthBounds(state.month);const f=document.getElementById('pfCatFrom'),t=document.getElementById('pfCatTo');if(f)f.value=b.from;if(t)t.value=b.to;renderCategory();};
  function catRange(){const b=monthBounds(state.month);if(catPeriod==='month')return b;if(catPeriod==='year'){const y=Number(state.month.slice(0,4));return {from:y+'-01-01',to:y+'-12-31'};}if(catPeriod==='custom'){let f=document.getElementById('pfCatFrom')?.value||b.from,t=document.getElementById('pfCatTo')?.value||b.to;if(f>t){const x=f;f=t;t=x;}return {from:f,to:t};}return {from:'0000-01-01',to:'9999-12-31'};}
  function renderCategory(){const r=catRange(),by={};pfReadTx().filter(t=>t.type===catType&&String(t.date||'')>=r.from&&String(t.date||'')<=r.to).forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,x)=>a+x[1],0),list=document.getElementById('pfCategoryList');if(!list)return;document.getElementById('pfCategoryTotal').textContent=money(total);list.innerHTML=entries.length?entries.map(x=>`<div class="pf-category-row"><div class="pf-category-avatar">${escapeHtml(x[0].charAt(0).toUpperCase())}</div><div class="pf-category-name">${escapeHtml(x[0])}</div><div class="pf-category-amount">${money(x[1])}</div></div>`).join(''):'<div class="pf-empty">No transactions in this category view.</div>';}
  window.pfCategorySetType=function(type){catType=type;document.getElementById('pfCatIncome').classList.toggle('active',type==='CREDIT');document.getElementById('pfCatExpense').classList.toggle('active',type==='EXPENSE');renderCategory();};
  window.pfCategorySetPeriod=function(period,btn){catPeriod=period;document.querySelectorAll('[data-cat-period]').forEach(b=>b.classList.toggle('active',b===btn));document.getElementById('pfCatCustom').style.display=period==='custom'?'grid':'none';renderCategory();};
  document.addEventListener('input',e=>{if(e.target?.id==='pfSearchInput')renderSearch(e.target.value);if(e.target?.id==='pfCatFrom'||e.target?.id==='pfCatTo')renderCategory();});

  // --- Edit category/type consistency ---
  function profileConfig(){try{return JSON.parse(localStorage.getItem('money_manager_config')||'null')||{}}catch(e){return {}}}
  function getConfig(){const c=profileConfig();return {credit:Array.isArray(c.creditCategories)&&c.creditCategories.length?c.creditCategories:['Salary','Income','Gift'],expense:Array.isArray(c.expenseCategories)&&c.expenseCategories.length?c.expenseCategories:['Food','Travel','Grocery','Other']};}
  function editType(){return document.getElementById('editType')?.value||'CREDIT'}
  function editCats(){const c=getConfig();return editType()==='CREDIT'?c.credit:c.expense}
  let editCategoryNeedsSelection=false;
  function fillEditCategories(keep){const sel=document.getElementById('editCategory');if(!sel)return;const cats=editCats();const old=keep===undefined?sel.value:keep;sel.innerHTML='<option value="">Select category</option>'+cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')+'<option value="CUSTOM">Custom</option>';if(old&&cats.includes(old))sel.value=old;else if(old==='CUSTOM')sel.value='CUSTOM';else sel.value='';const custom=document.getElementById('editCustomCategory');if(custom){custom.style.display=sel.value==='CUSTOM'?'block':'none';if(sel.value==='CUSTOM'&&!custom.value)custom.focus();}}
  window.pfEditCategoryChanged=function(){const sel=document.getElementById('editCategory'),custom=document.getElementById('editCustomCategory'),notice=document.getElementById('editCategoryNotice');if(!sel)return;if(sel.value==='CUSTOM'){if(custom){custom.style.display='block';} }else if(custom){custom.style.display='none';custom.value='';}if(notice){notice.style.display='none';notice.textContent='';}editCategoryNeedsSelection=false;};
  window.pfGetEditCategoryValue=function(){const sel=document.getElementById('editCategory');if(!sel)return '';if(sel.value==='CUSTOM')return (document.getElementById('editCustomCategory')?.value||'').trim();return sel.value.trim();};
  function typeChanged(){fillEditCategories('');editCategoryNeedsSelection=true;const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='Transaction type changed. Please select a new category for this type.';}}
  function setupEditType(){const t=document.getElementById('editType');if(!t||t.__pfFinalBound)return;t.__pfFinalBound=true;t.addEventListener('change',typeChanged);}
  const originalV10Edit=window.v10RequestEdit;
  window.v10RequestEdit=function(id){
    if(typeof originalV10Edit==='function')originalV10Edit(id);
    setTimeout(function(){
      setupEditType();const t=pfReadTx().find(x=>String(x.id)===String(id));const sel=document.getElementById('editCategory'),custom=document.getElementById('editCustomCategory');if(!sel||!t)return;
      const cats=editCats();if(cats.includes(t.category)){fillEditCategories(t.category);editCategoryNeedsSelection=false;}else{fillEditCategories('');editCategoryNeedsSelection=true;const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='This saved category belongs to a different transaction type. Please select a new category before saving.';}}
      if(custom)custom.value='';
    },30);
  };
  // Keep direct openEdit callers consistent too.
  const originalOpenEdit=window.openEdit;
  window.openEdit=function(id){if(typeof originalOpenEdit==='function')originalOpenEdit(id);setTimeout(()=>{setupEditType();const t=pfReadTx().find(x=>String(x.id)===String(id));if(t){const c=getConfig(),cats=t.type==='CREDIT'?c.credit:c.expense;fillEditCategories(cats.includes(t.category)?t.category:'');}},30);};
  // Wrap saveEdit to enforce a valid category after a type change.
  const originalSaveEdit=window.saveEdit;
  window.saveEdit=function(){const cat=window.pfGetEditCategoryValue();if(!cat){alert('Please select a category for the selected transaction type.');return;}const cats=editCats();if(document.getElementById('editCategory')?.value==='CUSTOM' && !cat){alert('Please enter a custom category.');return;}if(!document.getElementById('editCategory')?.value || (document.getElementById('editCategory').value!=='CUSTOM'&&!cats.includes(cat))){alert('Please select a valid category for the selected transaction type.');return;}if(typeof originalSaveEdit==='function')return originalSaveEdit();};

  function boot(){try{setupEditType();syncControls();}catch(e){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(boot,300);setTimeout(boot,900);
})();
