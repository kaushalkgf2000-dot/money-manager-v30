# MoneyFlow V24 — Android Build Workflow Fix

The repository's active workflow is `.github/workflows/main.yml`. The previous workflow failed during Android SDK setup because `sdkmanager tools` was being requested, but the legacy `tools` SDK package is not available on the current runner repositories.

V24 replaces the active `main.yml` workflow with a self-contained Android SDK setup:

- Does not use `android-actions/setup-android`.
- Does not request/install the legacy `tools` package.
- Downloads Android Command-line Tools 20.0 (build 14742923) directly from Google.
- Accepts SDK licenses using that installed sdkmanager.
- Installs only platform-tools, Android 35 platform, and Build Tools 35.0.0.
- Uses JDK 17 and Gradle 8.11.1.
- Builds `:app:assembleDebug` and uploads the APK.

No MoneyFlow application logic was changed for this build-infrastructure fix.
