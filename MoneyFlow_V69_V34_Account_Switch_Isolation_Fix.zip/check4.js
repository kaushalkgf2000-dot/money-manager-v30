
(function(){
  const pfFeatureState={analyticsType:'EXPENSE',catType:'EXPENSE',catPeriod:'all'};
  function pfOpenFeature(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  window.pfCloseFeature=function(id){const m=document.getElementById(id);if(m)m.classList.remove('open');if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow='';};
  window.pfOpenAnalytics=function(){pfOpenFeature('pfAnalyticsModal');pfRenderAnalytics();};
  function pfAnalyticsData(){const q=pfTxFiltered();return q?q.data:[];}
  window.pfAnalyticsSetType=function(type){pfFeatureState.analyticsType=type;document.getElementById('pfAnalyticsExpense').classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome').classList.toggle('active',type==='CREDIT');pfRenderAnalytics();};
  function pfRenderAnalytics(){const data=pfAnalyticsData().filter(t=>t.type===pfFeatureState.analyticsType),by={};data.forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]);const total=entries.reduce((a,[,v])=>a+v,0);const donut=document.getElementById('pfDonut');const legend=document.getElementById('pfAnalyticsLegend');document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=pfFeatureState.analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;const stops=[];entries.forEach(([,v],i)=>{const end=start+(v/total)*100;stops.push(`${palette[i%palette.length]} ${start}% ${end}%`);start=end});donut.style.background=`conic-gradient(${stops.join(',')})`;legend.innerHTML=entries.map(([c,v],i)=>`<div class="pf-legend-row"><i class="pf-legend-dot" style="background:${palette[i%palette.length]}"></i><b>${escapeHtml(c)}</b><span>${money(v)} · ${((v/total)*100).toFixed(1)}%</span></div>`).join('');}
  window.pfOpenSearch=function(){pfOpenFeature('pfSearchModal');const input=document.getElementById('pfSearchInput');if(input){input.value='';setTimeout(()=>input.focus(),80);}pfRenderSearch('');};
  function pfRenderSearch(q){const list=document.getElementById('pfSearchResults');if(!list)return;const query=String(q||'').trim().toLowerCase();let data=txs.slice().sort(compareTransactionsLatestFirst);if(query)data=data.filter(t=>[t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other].some(v=>String(v??'').toLowerCase().includes(query)));if(!data.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}list.innerHTML=data.slice(0,100).map(t=>`<div class="pf-search-result"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(t.date)} • ${escapeHtml(t.mode||'')}${t.description?' • '+escapeHtml(t.description):''}</small></div><strong style="color:${t.type==='CREDIT'?'#2fa65b':'#e3483d'}">${t.type==='CREDIT'?'+':'-'}${money(t.amount)}</strong></div>`).join('');}
  window.pfOpenCategory=function(){pfOpenFeature('pfCategoryModal');const b=pfTxMonthBounds(pfTxState.month);document.getElementById('pfCatFrom').value=b.from;document.getElementById('pfCatTo').value=b.to;pfRenderCategory();};
  window.pfCategorySetType=function(type){pfFeatureState.catType=type;document.getElementById('pfCatIncome').classList.toggle('active',type==='CREDIT');document.getElementById('pfCatExpense').classList.toggle('active',type==='EXPENSE');pfRenderCategory();};
  window.pfCategorySetPeriod=function(period,btn){pfFeatureState.catPeriod=period;document.querySelectorAll('[data-cat-period]').forEach(b=>b.classList.toggle('active',b===btn));document.getElementById('pfCatCustom').style.display=period==='custom'?'grid':'none';pfRenderCategory();};
  function pfCategoryRange(){const now=new Date(),b=pfTxMonthBounds(pfTxState.month);if(pfFeatureState.catPeriod==='month')return b;if(pfFeatureState.catPeriod==='year'){const y=now.getFullYear();return {from:`${y}-01-01`,to:`${y}-12-31`};}if(pfFeatureState.catPeriod==='custom'){return {from:document.getElementById('pfCatFrom').value||b.from,to:document.getElementById('pfCatTo').value||b.to};}return {from:'0000-01-01',to:'9999-12-31'};}
  function pfRenderCategory(){const r=pfCategoryRange(),by={};txs.filter(t=>t.type===pfFeatureState.catType&&t.date>=r.from&&t.date<=r.to).forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,[,v])=>a+v,0),list=document.getElementById('pfCategoryList');document.getElementById('pfCategoryTotal').textContent=money(total);if(!entries.length){list.innerHTML='<div class="pf-empty">No transactions in this category view.</div>';return;}list.innerHTML=entries.map(([c,v])=>`<div class="pf-category-row"><div class="pf-category-avatar">${escapeHtml((c||'?').charAt(0).toUpperCase())}</div><div class="pf-category-name">${escapeHtml(c)}</div><div class="pf-category-amount">${money(v)}</div></div>`).join('');}
  document.addEventListener('input',e=>{if(e.target&&e.target.id==='pfSearchInput')pfRenderSearch(e.target.value);if(e.target&&(e.target.id==='pfCatFrom'||e.target.id==='pfCatTo'))pfRenderCategory();});
  document.addEventListener('click',e=>{document.querySelectorAll('.pf-feature-modal.open').forEach(m=>{if(e.target===m)pfCloseFeature(m.id);});});

  window.pfOpenExport=function(){
    closeMenu();
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.add('open'); m.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden';
  };
  window.pfCloseExport=function(){
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.remove('open'); m.setAttribute('aria-hidden','true'); document.body.style.overflow='';
  };
  document.addEventListener('click',function(e){const m=document.getElementById('pfExportModal');if(m&&e.target===m)pfCloseExport();});
})();
