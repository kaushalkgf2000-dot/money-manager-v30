
(function(){
  'use strict';
  function today(){
    return typeof localToday==='function' ? localToday() : new Date().toISOString().slice(0,10);
  }
  function hide(el,yes){ if(el) el.style.display=yes?'block':'none'; }
  function resetForm(){
    const d=document.getElementById('date');
    const type=document.getElementById('type');
    const amount=document.getElementById('amountPreset');
    const customAmount=document.getElementById('customAmount');
    const category=document.getElementById('categorySelect');
    const customCategory=document.getElementById('customCategory');
    const mode=document.getElementById('mode');
    if(d){d.max=today();d.value=today();}
    if(type) type.value='';
    if(amount){amount.innerHTML='<option value="" selected>Select amount</option>';amount.value='';}
    if(customAmount){customAmount.value='';customAmount.style.display='none';}
    if(category){category.innerHTML='<option value="" selected>Select category</option>';category.value='';}
    if(customCategory){customCategory.value='';customCategory.style.display='none';}
    if(mode) mode.value='';
    ['description','remark','other'].forEach(function(id){const el=document.getElementById(id);if(el)el.value='';});
  }
  window.pfResetAddTransactionForm=resetForm;

  // Fresh state whenever Add Transaction is opened. Date is the only default.
  const oldOpen=window.pfOpenAddTransaction;
  if(typeof oldOpen==='function' && !window.__mfV17OpenPatched){
    window.__mfV17OpenPatched=true;
    window.pfOpenAddTransaction=function(){
      try{if(typeof closeMenu==='function')closeMenu();}catch(e){}
      resetForm();
      const m=document.getElementById('addTransactionModal');
      if(!m)return;
      m.style.display='block';
      document.body.style.overflow='hidden';
    };
  }

  // Keep dependent choices empty until Type is explicitly selected.
  function applyTypeState(){
    const type=document.getElementById('type');
    if(!type)return;
    const value=type.value;
    if(!value){
      resetForm();
      return;
    }
    // Populate type-specific choices, but do not restore a previous transaction's selection.
    if(typeof window.updateCategories==='function') window.updateCategories();
  }
  const type=document.getElementById('type');
  if(type && !type.__mfV17Bound){
    type.__mfV17Bound=true;
    type.addEventListener('change',applyTypeState);
  }

  // After any successful save, the wrapper also guarantees a clean next-entry state.
  const oldRequest=window.v109RequestAddTransaction;
  if(typeof oldRequest==='function' && !window.__mfV17RequestPatched){
    window.__mfV17RequestPatched=true;
    window.v109RequestAddTransaction=function(){
      const result=oldRequest.apply(this,arguments);
      if(result) resetForm();
      return result;
    };
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',resetForm);
  else resetForm();
})();
