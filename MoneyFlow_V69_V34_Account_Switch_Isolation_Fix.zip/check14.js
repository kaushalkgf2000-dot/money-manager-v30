
(function(){
'use strict';
const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
const sets={
 male:[
  ['M1','#c9e5ff','#253b57','#111827'],['M2','#d8f0e4','#384a3b','#172116'],['M3','#f4ddc7','#5a4030','#20150f'],['M4','#e4d9ff','#463b62','#17131e'],
  ['M5','#d9edf7','#3e5568','#171d23'],['M6','#f0dfc9','#31483b','#101814'],['M7','#e6e7ea','#4b3d35','#171513'],['M8','#d8e9ff','#5c4851','#151218']
 ],
 female:[
  ['F1','#ffdce8','#55394a','#24151c'],['F2','#e5ddff','#4b4164','#17141f'],['F3','#ffe4cf','#6a4b37','#21160f'],['F4','#dff1ea','#3f554d','#18201d'],
  ['F5','#dce9ff','#47556a','#171c25'],['F6','#f5e2d2','#5d3f48','#21151a'],['F7','#e9e0d3','#4a443e','#161513'],['F8','#e4dcff','#4c3a57','#18111c']
 ],
 other:[
  ['O1','#dff4ff','#315267','#111b22'],['O2','#eee2ff','#57416d','#1a1221'],['O3','#e6f1d8','#40543b','#151c13'],['O4','#ffe6d5','#5d493a','#20170f'],
  ['O5','#dce6ef','#42525e','#141b20'],['O6','#f0dff2','#5c415c','#1c121c'],['O7','#e7e7e7','#444','#111'],['O8','#dff1ee','#3c5750','#111b18']
 ]
};
function svgAvatar(kind,bg,shirt,hair){
 const female=kind[0]==='F', other=kind[0]==='O';
 const face=female?'#e2aa86':other?'#c99a7c':'#c78d69';
 const skin2=female?'#b9785c':other?'#a8735b':'#a8664d';
 const eye='#27211e', hair2=hair;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${bg}"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs><rect width="200" height="200" rx="100" fill="url(#g)"/><ellipse cx="100" cy="188" rx="69" ry="50" fill="${shirt}"/><path d="M82 130h36v25c-7 8-29 8-36 0z" fill="${skin2}"/><ellipse cx="100" cy="89" rx="48" ry="57" fill="${face}"/>
 ${female
 ? `<path d="M49 95c-8-42 10-78 51-80 39-2 57 29 51 77l-15-10-9-29c-18 17-38 25-69 26z" fill="${hair2}"/><path d="M52 82c-10 30-3 70 17 89l-12 4c-24-24-27-63-14-94zM148 82c10 30 3 70-17 89l12 4c24-24 27-63 14-94z" fill="${hair2}"/><path d="M73 79q10-8 19 0M108 79q10-8 19 0" fill="none" stroke="${hair2}" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="4.5" ry="6" fill="${eye}"/><ellipse cx="119" cy="93" rx="4.5" ry="6" fill="${eye}"/><path d="M87 117q13 9 26 0" fill="none" stroke="#a35f52" stroke-width="4" stroke-linecap="round"/>`
 : other
 ? `<path d="M52 82c0-43 20-66 48-66 34 0 52 25 48 69-10-5-18-12-27-22-17 19-39 28-69 28z" fill="${hair2}"/><circle cx="100" cy="51" r="8" fill="#6b8cff"/><path d="M72 79q10-7 19 0M109 79q10-7 19 0" fill="none" stroke="#343943" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="5" ry="6" fill="${eye}"/><ellipse cx="119" cy="93" rx="5" ry="6" fill="${eye}"/><path d="M87 116q13 7 26 0" fill="none" stroke="#865b52" stroke-width="4" stroke-linecap="round"/>`
 : `<path d="M52 84c0-43 20-66 48-66 32 0 51 24 48 64-14-8-25-17-39-29-17 22-35 29-57 31z" fill="${hair2}"/><path d="M67 111q7 24 33 24t33-24q-3 35-33 39t-33-39z" fill="${hair2}"/><ellipse cx="81" cy="92" rx="5" ry="7" fill="${eye}"/><ellipse cx="119" cy="92" rx="5" ry="7" fill="${eye}"/><path d="M87 115q13 8 26 0" fill="none" stroke="#8e5148" stroke-width="4" stroke-linecap="round"/><path d="M73 77q8-7 16 0M111 77q8-7 16 0" fill="none" stroke="${hair2}" stroke-width="5" stroke-linecap="round"/>`}</svg>`;
 return 'data:image/svg+xml;charset=UTF-8,'+encodeURIComponent(svg);
}
function read(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function active(){const a=read(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId');return a.find(p=>p&&String(p.id)===String(id))||null}
function photoKey(id){return 'money_flow_profile_photo_'+String(id||'') }
function save(a){localStorage.setItem(PK,JSON.stringify(a))}
function safeSaveProfilePhoto(id,photo){try{localStorage.setItem(photoKey(id),photo);return true}catch(e){return false}}
function getStoredPhoto(p){try{const x=localStorage.getItem(photoKey(p&&p.id));if(x&&x.startsWith('data:image/'))return x}catch(e){}return p&&typeof p.profilePhoto==='string'&&p.profilePhoto.startsWith('data:image/')?p.profilePhoto:''}
function avatarData(g){return (sets[g]||sets.other).map(x=>({id:x[0],src:svgAvatar(x[0],x[1],x[2],x[3])}))}
function ensureGender(p){if(!p)return 'male';if(!['male','female','other'].includes(p.profileGender))p.profileGender='male';return p.profileGender}
function currentPhoto(p){const stored=getStoredPhoto(p);if(stored)return stored;const g=ensureGender(p),arr=avatarData(g);return arr[0].src}
function ensureModal(){
 if(document.getElementById('mf19PhotoModal'))return document.getElementById('mf19PhotoModal');
 const m=document.createElement('div');m.id='mf19PhotoModal';m.className='mf19-photo-modal';m.innerHTML=`<div class="mf19-photo-box" role="dialog" aria-modal="true" aria-labelledby="mf19Title"><div class="mf19-photo-head"><div><h2 id="mf19Title">Choose Profile Photo</h2><p>Select an avatar or upload from your gallery</p></div><button class="mf19-x" type="button" id="mf19Close">×</button></div><div class="mf19-preview" id="mf19Preview"></div><label class="mf19-gallery" for="mf19GalleryInput"><div class="mf19-gallery-icon">🖼️</div><div><b>Click to upload from Gallery</b><small>Choose your own photo</small></div></label><input id="mf19GalleryInput" class="pf-profile-input" type="file" accept="image/*"><div class="mf19-label">Select default avatar</div><div class="mf19-tabs"><button type="button" data-g="male">♂ Male</button><button type="button" data-g="female">♀ Female</button><button type="button" data-g="other">◈ Other</button></div><div class="mf19-grid" id="mf19Grid"></div><div class="mf19-pager"><button type="button" id="mf19Prev">‹</button><span class="mf19-page" id="mf19Page">1 / 2</span><button type="button" id="mf19Next">›</button></div><button type="button" class="mf19-ok" id="mf19OK">OK</button><div class="mf19-hint">This photo belongs only to the current Profile / Mode.</div></div>`;
 document.body.appendChild(m);
 m.addEventListener('click',e=>{if(e.target===m)close()});
 document.getElementById('mf19Close').onclick=close;
 document.getElementById('mf19OK').onclick=commit;
 document.getElementById('mf19Prev').onclick=()=>{state.page=Math.max(0,state.page-1);renderGrid()};
 document.getElementById('mf19Next').onclick=()=>{state.page=Math.min(1,state.page+1);renderGrid()};
 document.querySelectorAll('#mf19PhotoModal .mf19-tabs button').forEach(b=>b.onclick=()=>{state.gender=b.dataset.g;state.page=0;const p=active();state.photo=currentPhoto(p);renderGrid()});
 document.getElementById('mf19GalleryInput').onchange=function(){const f=this.files&&this.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const src=String(r.result);const im=new Image();im.onload=()=>{const max=720,scale=Math.min(1,max/Math.max(im.naturalWidth||im.width,im.naturalHeight||im.height));const w=Math.max(1,Math.round((im.naturalWidth||im.width)*scale)),h=Math.max(1,Math.round((im.naturalHeight||im.height)*scale));const cv=document.createElement('canvas');cv.width=w;cv.height=h;const cx=cv.getContext('2d');cx.drawImage(im,0,0,w,h);state.photo=cv.toDataURL('image/jpeg',0.82);state.gallery=true;renderPreview()};im.onerror=()=>{state.photo=src;state.gallery=true;renderPreview()};im.src=src};r.readAsDataURL(f)};
 return m;
}
let state={gender:'male',page:0,photo:'',gallery:false};
function renderPreview(){const e=document.getElementById('mf19Preview');if(e)e.innerHTML=state.photo?'<img alt="Selected profile photo" src="'+state.photo+'">':''}
function renderGrid(){const grid=document.getElementById('mf19Grid');if(!grid)return;const arr=avatarData(state.gender),start=state.page*4,items=arr.slice(start,start+4);grid.innerHTML=items.map(x=>`<button type="button" class="mf19-avatar ${state.photo===x.src?'active':''}" data-src="${x.src}"><img alt="${x.id} avatar" src="${x.src}"></button>`).join('');grid.querySelectorAll('button').forEach(b=>b.onclick=()=>{state.photo=b.dataset.src;state.gallery=false;renderGrid();renderPreview()});document.getElementById('mf19Page').textContent=(state.page+1)+' / 2';document.getElementById('mf19Prev').disabled=state.page===0;document.getElementById('mf19Next').disabled=state.page===1;document.querySelectorAll('#mf19PhotoModal .mf19-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.g===state.gender));renderPreview()}
function open(){const m=ensureModal(),p=active();state.gender=ensureGender(p);state.page=0;state.gallery=false;state.photo=currentPhoto(p);m.classList.add('open');m.setAttribute('aria-hidden','false');renderGrid()}
function close(){const m=document.getElementById('mf19PhotoModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}}
function commit(){const a=read(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId'),i=a.findIndex(x=>x&&String(x.id)===String(id));if(i<0)return;const q=a[i],photo=state.photo||avatarData(state.gender)[0].src;q.profileGender=state.gender;q.profilePhoto=photo;try{save(a)}catch(e){return}if(!safeSaveProfilePhoto(q.id,photo))return;close();try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}try{if(typeof window.render==='function')window.render()}catch(e){}}
window.pfOpenProfilePhotoMenu=open;window.pfCloseProfilePhotoMenu=close;
// New Profile / Mode starts with a gender-specific default avatar. The user can change it immediately.
const oldCreate=window.v10CreateProfile;
if(typeof oldCreate==='function'&&!window.__mf19CreateWrapped){window.__mf19CreateWrapped=true;window.v10CreateProfile=function(){const r=oldCreate.apply(this,arguments);setTimeout(()=>{const p=active();if(!p)return;const a=read(),i=a.findIndex(x=>x&&String(x.id)===String(p.id));if(i<0)return;const q=a[i];if(!['male','female','other'].includes(String(q.profileGender||'').toLowerCase()))q.profileGender='male';if(!q.profilePhoto)q.profilePhoto=avatarData(q.profileGender)[0].src;save(a);try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}},0);return r;}}
// Replace the old click target with the new picker.
function bind(){const b=document.getElementById('profilePhotoBtn');if(b&&!b.__mf19){b.__mf19=true;b.onclick=open;b.setAttribute('aria-label','Choose profile photo')}const p=active();if(p&&!p.profileGender){p.profileGender='male';if(!p.profilePhoto)p.profilePhoto=avatarData('male')[0].src;const a=read(),i=a.findIndex(x=>x&&x.id===p.id);if(i>=0){a[i]=p;save(a);if(p.profilePhoto)safeSaveProfilePhoto(p.id,p.profilePhoto)}}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();setTimeout(bind,300);setTimeout(bind,1000);
// Keep photo and gender strictly tied to the active mode.
const oldSwitch=window.v10SwitchProfile;
if(typeof oldSwitch==='function'&&!window.__mf19Switch){window.__mf19Switch=true;window.v10SwitchProfile=function(id){const r=oldSwitch.apply(this,arguments);setTimeout(bind,0);setTimeout(()=>{try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}},80);return r;}}
})();
