
/* V35 — SINGLE SOURCE EXPORT FIX
   Final override: read the exact date controls at click time and use the live
   transaction array rendered by the app. No profile/legacy merging is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function dateKey(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return m[1]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[3]).padStart(2,"0");
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return m[3]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[1]).padStart(2,"0");
    return "";
  }
  function selectedRange(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=dateKey(f&&f.value),to=dateKey(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function liveTransactions(){
    let a=[];
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))a=txs.slice()}catch(e){}
    return a.map(function(x,i){
      return {id:x&&x.id!=null?x.id:i,date:dateKey(x&&x.date),type:text(x&&x.type).toUpperCase(),amount:Number(x&&x.amount)||0,
        balance:Number.isFinite(Number(x&&x.balance))?Number(x.balance):null,category:text(x&&x.category),description:text(x&&x.description||x&&x.desc),remark:text(x&&x.remark||x&&x.remarks||x&&x.note),mode:text(x&&x.mode||x&&x.paymentMode||x&&x.payment_mode),other:text(x&&x.other||x&&x.otherInfo||x&&x.other_info),createdAt:text(x&&x.createdAt)};
    }).filter(function(x){return x.date&&x.amount>0&&(x.type==="CREDIT"||x.type==="EXPENSE"||x.type==="DEBIT");})
      .sort(function(a,b){return a.date.localeCompare(b.date)||(a.createdAt.localeCompare(b.createdAt))||(Number(a.id)||0)-(Number(b.id)||0)});
  }
  function pack(){
    const r=selectedRange(); if(!r)return null;
    const all=liveTransactions();
    const data=all.filter(function(x){return (!r.from||x.date>=r.from)&&(!r.to||x.date<=r.to)});
    return {from:r.from,to:r.to,all:all,data:data};
  }
  function opening(all,from){
    if(!from)return 0;
    const before=all.filter(function(x){return x.date<from;});
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(last.balance!==null)return last.balance;
    let b=0;before.forEach(function(x){b+=x.type==="CREDIT"?x.amount:-x.amount});return b;
  }
  function calc(p){
    let b=opening(p.all,p.from),w=0,d=0;
    const rows=p.data.map(function(t){
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b];
    });
    return {rows:rows,opening:opening(p.all,p.from),withdrawals:w,deposits:d,closing:b};
  }
  function xesc(s){return text(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;")}
  function xtext(v){return '<c t="inlineStr"><is><t>'+xesc(v)+'</t></is></c>'}
  function xnum(v){return '<c t="n"><v>'+String(Number(v)||0)+'</v></c>'}
  function makeXlsx(p){
    const c=calc(p),rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    c.rows.forEach(function(r){rows.push([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8]])});
    rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",c.opening,"TOTAL WITHDRAWALS",c.withdrawals,"TOTAL DEPOSITS",c.deposits,"CLOSING BALANCE",c.closing,"No. of Transactions",p.data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map(function(row,ri){return '<row>'+row.map(function(v,i){const numeric=(ri>0&&ri<=p.data.length&&[6,7,8].indexOf(i)>=0)||(ri===p.data.length+2&&typeof v==="number");return numeric?xnum(v):xtext(v)}).join('')+'</row>'}).join('');
    const sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+xml+'</sheetData></worksheet>';
    const wb='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const rel='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const root='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const ct='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function makePdf(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=function(v){return text(v).replace(/[^\x20-\x7E]/g,"?")},esc=function(v){return pdfEscape(safe(v))};
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";v.split(/\s+/).forEach(function(q){if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}});if(cur)a.push(cur);return a.length?a:[""]}
    function rr(vals){const cells=vals.map(function(v,i){return wrap(v,colW[i])});return {cells:cells,h:Math.max(18,Math.max.apply(null,cells.map(function(z){return z.length}))*lh+4)}}
    const prepared=c.rows.map(function(r){return rr([r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)])});
    const pages=[];let pg=[],y=86;prepared.forEach(function(r){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=function(o){objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach(function(page,pi){let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(p.from+" to "+p.to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,vals,bold){s+="0.75 w\n0 0 0 RG\n"+x+" "+(y-h)+" "+w+" "+h+" re S\nBT\n/F1 "+(bold?7.2:fs)+" Tf\n";vals.forEach(function(t,i){s+="1 0 0 1 "+(x+2.5)+" "+(y-2.5-7-i*lh)+" Tm ("+esc(t)+") Tj\n"});s+="ET\n"}
      let x=M;heads.forEach(function(h,i){cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(function(r){x=M;r.cells.forEach(function(cc,i){cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (ACCOUNT SUMMARY) Tj\nET\n";yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[c.opening.toFixed(2),c.withdrawals.toFixed(2),c.deposits.toFixed(2),c.closing.toFixed(2),String(p.data.length)];x=M;labs.forEach(function(q,i){cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach(function(q,i){cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (******************* END OF REPORT *******************) Tj\nET\n"}
      s+="Q";cids.push(add("<< /Length "+s.length+" >>\nstream\n"+s+"\nendstream"));pids.push(null);
    });
    const pagesId=add("PAGES");pages.forEach(function(_,i){pids[i]=add("<< /Type /Page /Parent "+pagesId+" 0 R /MediaBox [0 0 "+W+" "+H+"] /Resources << /Font << /F1 "+font+" 0 R >> >> /Contents "+cids[i]+" 0 R >>")});objs[pagesId-1]="<< /Type /Pages /Kids ["+pids.map(function(x){return x+" 0 R"}).join(" ")+"] /Count "+pids.length+" >>";const cat=add("<< /Type /Catalog /Pages "+pagesId+" 0 R >>");let pdf="%PDF-1.4\n",offs=[0];objs.forEach(function(o,i){offs[i+1]=pdf.length;pdf+=(i+1)+" 0 obj\n"+o+"\nendobj\n"});const xr=pdf.length;pdf+="xref\n0 "+(objs.length+1)+"\n0000000000 65535 f \n";for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+="trailer\n<< /Size "+(objs.length+1)+" /Root "+cat+" 0 R >>\nstartxref\n"+xr+"\n%%EOF";return new Blob([pdf],{type:"application/pdf"});
  }
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions_"+p.from+"_to_"+p.to+".xlsx")};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(makePdf(p),"money_transactions_"+p.from+"_to_"+p.to+".pdf")};
})();

/* Money Flow V61 — Backup Money Flow V58 — Backup & Restore v5 Restore v6
   Local/offline backup is preserved. Google Drive appDataFolder is the cloud copy.
   Cloud backup is account-scoped and intentionally excludes PIN/recovery/security credentials.
*/
(function(){
  /*
   * V7 FINAL BACKUP ARCHITECTURE
   * ----------------------------
   * Cloud backup contains account-scoped transactions plus Profile/Mode metadata, profile photos and PIN/recovery settings. Notes remain device-local and are never included.
   *
   * Cloud is the synchronized transaction snapshot. Restore NEVER blindly
   * replaces local transaction work: it merges the incoming cloud snapshot
   * against the last successful sync baseline so local unsynced changes survive.
   * The merged transaction set is then recalculated/refreshed and uploaded as
   * the new synchronized snapshot. Existing device-local profile/security data
   * remains local.
   */
  let backupTimer=0, cloudTimer=0;
  let cloudSyncSuppressed=true;
  let autoReloadAfterCloudWrite=false;
  /* Transaction sync state: the last successfully uploaded transaction snapshot
     is the baseline. Local transactions created/edited after that baseline are
     protected from an incoming cloud restore until they are uploaded. */
  const MF_TX_SYNC_KEY='mf_cloud_tx_snapshot_v1';
  const MF_TX_PENDING_KEY='mf_cloud_tx_pending_v1';
  const MF_PROFILE_SYNC_KEY='mf_cloud_profile_snapshot_v1';
  const MF_PROFILE_PENDING_KEY='mf_cloud_profile_pending_v1';
  let cloudUploadBusy=false, cloudUploadQueued=false;

  function mfCloneTxList(list){
    return (Array.isArray(list)?list:[]).map(t=>{
      try{return mfEnsureTransactionUid(JSON.parse(JSON.stringify(t)))}catch(e){return mfEnsureTransactionUid(t)}
    });
  }
  function mfTxId(t){
    /* Stable transaction UID is the primary identity for every cloud/local merge.
       Legacy rows are upgraded deterministically from their old id. */
    if(t&&t.uid!==undefined&&t.uid!==null&&String(t.uid).trim()!=='')return String(t.uid);
    if(t&&t.id!==undefined&&t.id!==null&&String(t.id)!=='')return 'legacy-'+String(t.id);
    try{return 'legacy:'+JSON.stringify([t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other]);}catch(e){return 'legacy:'+String(t);}
  }
  function mfTxEqual(a,b){
    try{return JSON.stringify(a)===JSON.stringify(b)}catch(e){return String(a)===String(b)}
  }
  function mfReadSyncSnapshot(){
    try{
      const x=JSON.parse(localStorage.getItem(MF_TX_SYNC_KEY)||'null');
      return Array.isArray(x)?x:null;
    }catch(e){return null}
  }
  function mfWriteSyncSnapshot(list){
    try{localStorage.setItem(MF_TX_SYNC_KEY,JSON.stringify(mfCloneTxList(list)));}catch(e){}
  }
  function mfWritePendingSnapshot(list){
    try{localStorage.setItem(MF_TX_PENDING_KEY,JSON.stringify(mfCloneTxList(list)));}catch(e){}
  }
  function mfReadPendingSnapshot(){
    try{const x=JSON.parse(localStorage.getItem(MF_TX_PENDING_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}
  }
  function mfClearPendingSnapshot(){try{localStorage.removeItem(MF_TX_PENDING_KEY)}catch(e){} }

  function mfCloneObject(v){try{return JSON.parse(JSON.stringify(v))}catch(e){return v}}
  function mfProfileSecurityForCloud(sec){
    const s=sec&&typeof sec==='object'?sec:{};
    /* PIN/recovery belong to the Profile / Mode and are backed up. WebAuthn
       credential IDs are device-bound and therefore never copied to cloud. */
    return {
      mode:String(s.mode||'NONE'),
      pinHash:String(s.pinHash||''),
      recoveryCode:String(s.recoveryCode||''),
      editPinLost:!!s.editPinLost,
      addProtection:!!s.addProtection,
      bioEnabled:!!s.bioEnabled,
      profileSecurityInitialized:s.profileSecurityInitialized!==false
    };
  }
  function mfProfilesForCloudFrom(list){
    return (Array.isArray(list)?list:[]).map((p,i)=>({
      id:String(p&&p.id||('profile_'+i)),
      name:String(p&&p.name||'My Money'),
      transactions:mfCloneTxList(p&&p.transactions),
      security:mfProfileSecurityForCloud(p&&p.security),
      config:mfCloneObject(p&&p.config||{}),
      profileGender:['male','female','other'].includes(String(p&&p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',
      profilePhoto:(p&&typeof p.profilePhoto==='string'&&/^data:image\//i.test(p.profilePhoto))?p.profilePhoto:''
    }));
  }
  function mfProfilesForCloud(){
    try{return mfProfilesForCloudFrom(mfParseArray(localStorage.getItem('money_manager_profiles_v10')))}catch(e){return[]}
  }
  function mfReadProfileSyncSnapshot(){
    try{const x=JSON.parse(localStorage.getItem(MF_PROFILE_SYNC_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}
  }
  function mfWriteProfileSyncSnapshot(list){try{localStorage.setItem(MF_PROFILE_SYNC_KEY,JSON.stringify(mfProfilesForCloudFrom(list)))}catch(e){}}
  function mfWritePendingProfiles(list){try{localStorage.setItem(MF_PROFILE_PENDING_KEY,JSON.stringify(mfProfilesForCloudFrom(list)))}catch(e){}}
  function mfReadPendingProfiles(){try{const x=JSON.parse(localStorage.getItem(MF_PROFILE_PENDING_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}}
  function mfClearPendingProfiles(){try{localStorage.removeItem(MF_PROFILE_PENDING_KEY)}catch(e){} }
  function mfProfileMeta(p){
    return {name:String(p&&p.name||'My Money'),security:mfProfileSecurityForCloud(p&&p.security),config:mfCloneObject(p&&p.config||{}),profileGender:['male','female','other'].includes(String(p&&p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',profilePhoto:String(p&&p.profilePhoto||'')};
  }
  function mfProfileMetaEqual(a,b){try{return JSON.stringify(mfProfileMeta(a))===JSON.stringify(mfProfileMeta(b))}catch(e){return false}}
  function mfMergeTxLists(cloudList,localList,baselineList){
    const remote=mfCloneTxList(cloudList),local=mfCloneTxList(localList),baseline=Array.isArray(baselineList)?mfCloneTxList(baselineList):null;
    const r=new Map(),l=new Map(),b=new Map();remote.forEach(t=>r.set(mfTxId(t),t));local.forEach(t=>l.set(mfTxId(t),t));if(baseline)baseline.forEach(t=>b.set(mfTxId(t),t));
    const changed=new Set(),deleted=new Set();
    if(baseline){b.forEach((bt,id)=>{if(!l.has(id))deleted.add(id);else if(!mfTxEqual(l.get(id),bt))changed.add(id)});l.forEach((_,id)=>{if(!b.has(id))changed.add(id)})}
    else l.forEach((_,id)=>changed.add(id));
    const out=new Map();r.forEach((t,id)=>{if(!deleted.has(id))out.set(id,t)});l.forEach((t,id)=>{if(changed.has(id))out.set(id,t)});
    return Array.from(out.values()).sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
  }
  function mfMergeProfiles(cloudProfiles){
    const remote=mfProfilesForCloudFrom(cloudProfiles),local=mfProfilesForCloud(),baseline=mfReadProfileSyncSnapshot();
    const lMap=new Map(local.map(p=>[String(p.id),p])),bMap=new Map((Array.isArray(baseline)?baseline:[]).map(p=>[String(p.id),p]));
    const merged=new Map();
    remote.forEach(cp=>{
      const id=String(cp.id),lp=lMap.get(id),bp=bMap.get(id);
      if(lp){
        const localMetaChanged=bp?!mfProfileMetaEqual(lp,bp):true;
        const q=mfCloneObject(cp);
        q.transactions=mfMergeTxLists(cp.transactions,lp.transactions,bp&&bp.transactions);
        if(localMetaChanged){q.name=lp.name;q.security=mfCloneObject(lp.security);q.config=mfCloneObject(lp.config);q.profileGender=['male','female','other'].includes(String(lp.profileGender||'').toLowerCase())?String(lp.profileGender).toLowerCase():'male';q.profilePhoto=lp.profilePhoto||'';}
        if(lp.security&&lp.security.bioCredentialId)q.security.bioCredentialId=lp.security.bioCredentialId;
        merged.set(id,q);
      }else{
        const q=mfCloneObject(cp);q.security=q.security||{};q.security.bioCredentialId='';merged.set(id,q);
      }
    });
    /* Never delete a local-only Mode during restore. */
    local.forEach(lp=>{const id=String(lp.id);if(!merged.has(id))merged.set(id,mfCloneObject(lp))});
    return Array.from(merged.values());
  }
  function mfApplyProfiles(profiles,activeId){
    const ps=Array.isArray(profiles)?profiles.map(p=>{const q=mfCloneObject(p)||{};q.id=String(q.id||('profile_'+Date.now()));q.name=String(q.name||'My Money');q.profileGender=['male','female','other'].includes(String(q.profileGender||'').toLowerCase())?String(q.profileGender).toLowerCase():'male';q.transactions=mfCloneTxList(q.transactions);q.security=q.security||{};if(!q.security.bioCredentialId)q.security.bioCredentialId='';return q;}):[];
    if(!ps.length)return false;
    localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps));
    let aid=String(activeId||'');if(!aid||!ps.some(p=>String(p.id)===aid))aid=String(ps[0].id);
    localStorage.setItem('money_manager_active_profile_v10',aid);
    const ap=ps.find(p=>String(p.id)===aid)||ps[0];
    try{if(typeof txs!=='undefined'&&Array.isArray(txs)){txs.length=0;mfCloneTxList(ap.transactions).forEach(t=>txs.push(t));localStorage.setItem(typeof KEY!=='undefined'?KEY:'money_manager_v1',JSON.stringify(txs));}}catch(e){}
    return true;
  }

  function mfMergeCloudWithLocal(cloudList){
    const remote=mfCloneTxList(cloudList);
    const local=mfTransactionSnapshot();
    const baseline=mfReadSyncSnapshot();
    const rMap=new Map(), lMap=new Map(), bMap=new Map();
    remote.forEach(t=>rMap.set(mfTxId(t),t));
    local.forEach(t=>lMap.set(mfTxId(t),t));
    if(Array.isArray(baseline))baseline.forEach(t=>bMap.set(mfTxId(t),t));

    /* With no prior successful cloud snapshot, treat existing local rows as
       unsynced rather than allowing the cloud to wipe them on first restore. */
    const hasBaseline=Array.isArray(baseline);
    const localChanged=new Set();
    const localDeleted=new Set();
    if(hasBaseline){
      bMap.forEach((b,id)=>{
        if(!lMap.has(id))localDeleted.add(id);
        else if(!mfTxEqual(lMap.get(id),b))localChanged.add(id);
      });
      lMap.forEach((_,id)=>{if(!bMap.has(id))localChanged.add(id)});
    }else{
      lMap.forEach((_,id)=>localChanged.add(id));
    }

    const merged=new Map();
    /* Start with cloud. Local changes/deletions then take precedence. */
    rMap.forEach((t,id)=>{if(!localDeleted.has(id))merged.set(id,t)});
    lMap.forEach((t,id)=>{if(localChanged.has(id))merged.set(id,t)});

    const out=Array.from(merged.values());
    out.sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
    return out;
  }

  function mfCommitCloudUploadSnapshot(snapshot){
    mfWriteSyncSnapshot(snapshot);
    mfClearPendingSnapshot();
  }

  function mfRequestCloudUpload(snapshot,after){
    if(cloudSyncSuppressed)return false;
    const snap=mfCloneTxList(snapshot||mfTransactionSnapshot());
    const profiles=mfProfilesForCloud();
    mfWritePendingSnapshot(snap);mfWritePendingProfiles(profiles);
    if(cloudUploadBusy){cloudUploadQueued=true;return true;}
    try{
      if(!(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup))return false;
      cloudUploadBusy=true;if(typeof after==='function')after();
      AndroidCloudBackup.uploadCloudBackup(JSON.stringify({
        version:5,app:'PaisaFlow',dataType:'transactions-and-profiles',createdAt:new Date().toISOString(),
        accountEmail:(()=>{try{return String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase()}catch(e){return''}})(),
        activeProfileId:mfActiveProfileId(),transactions:snap,profiles:profiles
      }));
      return true;
    }catch(e){cloudUploadBusy=false;return false}
  }

  function mfParseArray(raw){
    try{const x=JSON.parse(raw||'[]');return Array.isArray(x)?x:[]}catch(e){return[]}
  }

  function mfActiveProfileId(){
    try{return localStorage.getItem('money_manager_active_profile_v10')||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId')||''}catch(e){return''}
  }

  function mfReadLocalTransactions(){
    /* The legacy/current transaction store is the first source of truth. */
    try{
      const direct=mfParseArray(localStorage.getItem('money_manager_v1'));
      if(direct.length)return direct;
    }catch(e){}
    /* Fallback for a profile store whose active profile has the transaction list. */
    try{
      const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10'));
      const aid=mfActiveProfileId();
      const ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];
      return ap&&Array.isArray(ap.transactions)?ap.transactions:[];
    }catch(e){return[]}
  }

  function mfTransactionSnapshot(){
    const tx=mfReadLocalTransactions().map(t=>{
      try{return JSON.parse(JSON.stringify(t))}catch(e){return t}
    });
    tx.sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
    return tx;
  }

  function collect(includeSecurity){
    const email=(()=>{try{return String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase()}catch(e){return''}})();
    const profiles=mfProfilesForCloud(),ap=profiles.find(p=>String(p.id)===String(mfActiveProfileId()))||profiles[0]||null;
    return {version:5,app:'PaisaFlow',dataType:'transactions-and-profiles',createdAt:new Date().toISOString(),accountEmail:email,activeProfileId:ap?String(ap.id):'',transactions:ap?mfCloneTxList(ap.transactions):mfTransactionSnapshot(),profiles:profiles};
  }

  function saveNative(){
    if(window.__mfV21CloudOnlyManualBackup)return false;
    try{if(window.AndroidBackup&&AndroidBackup.saveBackupSnapshot){AndroidBackup.saveBackupSnapshot(JSON.stringify(collect(false)));return true}}catch(e){}
    return false;
  }
  function schedule(){clearTimeout(backupTimer);backupTimer=setTimeout(saveNative,900)}
  function scheduleCloud(){
    if(cloudSyncSuppressed)return;
    clearTimeout(cloudTimer);
    cloudTimer=setTimeout(function(){
      try{mfRequestCloudUpload(mfTransactionSnapshot());}catch(e){}
    },250);
  }
  window.pfScheduleCloudSync=function(){try{scheduleCloud()}catch(e){}}
  window.pfCloudSyncNow=function(){
    if(cloudSyncSuppressed)return;
    try{mfRequestCloudUpload(mfTransactionSnapshot());}catch(e){}
  };
  window.mfBackupNow=function(){
    const localOk=saveNative();
    try{
      if(window.AndroidCloudBackup&&window.AndroidCloudBackup.uploadCloudBackup){
        const wasSuppressed=cloudSyncSuppressed;cloudSyncSuppressed=false;
        const started=mfRequestCloudUpload(mfTransactionSnapshot());cloudSyncSuppressed=wasSuppressed;
        if(!started)throw new Error('Cloud backup could not be started.');
      }else alert('Cloud backup service is not available on this build.');
    }catch(e){alert('Cloud backup failed: '+(e&&e.message?e.message:'Unknown error'))}
    /* Sync to Google Drive must not create a Downloads file. */
    return localOk;
  };
  window.mfOpenBackup=function(){
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    try{
      const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10'));
      const aid=mfActiveProfileId();
      const ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];
      const badge=document.getElementById('mfBackupAccount');
      if(badge&&ap)badge.textContent=ap.name||'My Money';
    }catch(e){}
    const m=document.getElementById('mfBackupModal');if(m)m.style.display='block';
    const st=document.getElementById('mfBackupStatus');if(st)st.textContent='Checking cloud backup status…';
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.getCloudStatus)AndroidCloudBackup.getCloudStatus();else if(st)st.textContent='Cloud backup is not available on this build.'}catch(e){if(st)st.textContent='Cloud backup status unavailable.'}
  };
  window.mfCloudStatusResult=function(text){const st=document.getElementById('mfBackupStatus');if(st)st.textContent=text;};
  window.logoutAfterBackup=false;

  window.mfCloudBackupResult=function(ok,backupMsg){
    const st=document.getElementById('mfBackupStatus');
    if(st && !autoReloadAfterCloudWrite)st.textContent=backupMsg;
    if(ok){
      try{if(typeof logAction==='function')logAction('cloud_backup_success')}catch(e){}
      const pending=mfReadPendingSnapshot();
      if(pending)mfCommitCloudUploadSnapshot(pending);
      const pendingProfiles=mfReadPendingProfiles();
      if(pendingProfiles){mfWriteProfileSyncSnapshot(pendingProfiles);mfClearPendingProfiles();}
    }
    cloudUploadBusy=false;
    if(window.logoutAfterBackup){
      window.logoutAfterBackup=false;
      if(ok){
        try{AndroidAuth.signOut()}catch(e){const x=document.getElementById('mfAccountMsg');if(x){x.textContent='Sign-out service unavailable.';x.className='mf-account-msg err';}}
      }else{
        const x=document.getElementById('mfAccountMsg');if(x){x.textContent='Backup failed. You are still signed in.';x.className='mf-account-msg err';}
      }
      return;
    }
    if(cloudUploadQueued && !window.logoutAfterBackup){
      cloudUploadQueued=false;
      setTimeout(function(){try{mfRequestCloudUpload(mfTransactionSnapshot())}catch(e){}},50);
      return;
    }
    if(autoReloadAfterCloudWrite){
      autoReloadAfterCloudWrite=false;
      cloudSyncSuppressed=false;
      setTimeout(function(){location.reload()},120);
    }
  };

  window.mfStartLogoutBackup=function(){
    if(window.logoutAfterBackup)return;
    window.logoutAfterBackup=true;
    cloudSyncSuppressed=true;
    clearTimeout(cloudTimer);
    autoReloadAfterCloudWrite=false;
    try{
      saveNative();
      if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
        mfWritePendingSnapshot(mfTransactionSnapshot());
        cloudUploadBusy=true;
        AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));return;
      }
      throw new Error('Cloud backup service is not available on this build.');
    }catch(e){
      window.logoutAfterBackup=false;
      const x=document.getElementById('mfAccountMsg');
      if(x){x.textContent=e&&e.message==='Cloud backup service is not available on this build.'?e.message:'Cloud backup could not be started.';x.className='mf-account-msg err';}
    }
  };

  window.mfRestoreFromCloud=function(){
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return}}catch(e){}
    alert('Cloud restore is not available on this build.');
  };

  function mfParseCloudPayload(payload){
    try{
      const p=typeof payload==='string'?JSON.parse(payload):payload;if(!p||typeof p!=='object')return null;
      let profiles=Array.isArray(p.profiles)?p.profiles:null,transactions=Array.isArray(p.transactions)?p.transactions:null;
      if(!profiles&&p.storage&&typeof p.storage==='object'){
        const ps=mfParseArray(p.storage.money_manager_profiles_v10);if(ps.length)profiles=ps;
        if(!transactions){const direct=mfParseArray(p.storage.money_manager_v1);if(direct.length||Object.prototype.hasOwnProperty.call(p.storage,'money_manager_v1'))transactions=direct;}
        const aid=p.storage.money_manager_active_profile_v10||p.storage.activeProfileId||p.storage.currentProfileId||'';
        if(!transactions&&profiles&&profiles.length){const ap=profiles.find(x=>x&&String(x.id)===String(aid))||profiles[0];if(ap&&Array.isArray(ap.transactions))transactions=ap.transactions;}
      }
      return {profiles:profiles||[],activeProfileId:String(p.activeProfileId||''),transactions:transactions||[]};
    }catch(e){return null}
  }
  function mfNormalizeCloudTransactions(payload){const p=mfParseCloudPayload(payload);return p?mfCloneTxList(p.transactions):null;}

  function mfApplyTransactionSet(transactions){
    const tx=Array.isArray(transactions)?transactions.map(t=>{try{return mfEnsureTransactionUid(JSON.parse(JSON.stringify(t)))}catch(e){return mfEnsureTransactionUid(t)}}):[];
    try{localStorage.setItem('money_manager_v1',JSON.stringify(tx))}catch(e){throw e}
    try{if(typeof txs!=='undefined'&&Array.isArray(txs)){txs.length=0;tx.forEach(x=>txs.push(x));}}catch(e){}
    try{const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10')),aid=mfActiveProfileId(),ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];if(ap){ap.transactions=tx.map(x=>mfCloneObject(x));localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps));}}catch(e){}
    return tx;
  }
  function mfRecalculateAfterRestore(){
    try{if(typeof sortTransactionsLatestFirst==='function')sortTransactionsLatestFirst()}catch(e){}
    try{if(typeof render==='function')render()}catch(e){}
    try{if(typeof window.pfRenderTransactionsPage==='function'&&document.getElementById('pfTransactionsPage')?.style.display!=='none')window.pfRenderTransactionsPage()}catch(e){}
    try{if(typeof window.pfRenderAnalytics==='function')window.pfRenderAnalytics()}catch(e){}
    try{if(typeof window.pfRenderAnalyticsFixed==='function')window.pfRenderAnalyticsFixed()}catch(e){}
    try{if(typeof window.pfRenderCategory==='function')window.pfRenderCategory()}catch(e){}
    try{if(typeof window.pfRenderSearch==='function')window.pfRenderSearch('')}catch(e){}
    try{window.dispatchEvent(new CustomEvent('moneyflow:transactions-restored',{detail:{count:mfReadLocalTransactions().length}}))}catch(e){}
  }

  let autoSync=false;
  window.mfAutoSyncAfterAuth=function(){
    let syncMarker='pf_tx_cloud_sync_done_signed_in';
    try{
      const em=String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase();
      syncMarker='pf_tx_cloud_sync_done_'+(em||'signed_in');
      if(sessionStorage.getItem(syncMarker)==='1')return;
      sessionStorage.setItem(syncMarker,'1');
    }catch(e){}
    clearTimeout(cloudTimer);cloudSyncSuppressed=true;autoSync=true;autoReloadAfterCloudWrite=false;
    try{
      if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return}
    }catch(e){}
    autoSync=false;cloudSyncSuppressed=false;
    try{
      autoReloadAfterCloudWrite=true;
      mfRequestCloudUpload(mfTransactionSnapshot());
    }catch(e){autoReloadAfterCloudWrite=false}
  };

  function mfShowCloudMessage(text){const st=document.getElementById('mfBackupStatus');if(st)st.textContent=text;}

  window.mfCloudRestoreResult=function(ok,payload){
    if(!ok){
      if(autoSync){
        autoSync=false;
        try{if(window.AndroidCloudBackup&&window.AndroidCloudBackup.uploadCloudBackup){autoReloadAfterCloudWrite=true;cloudSyncSuppressed=false;mfRequestCloudUpload(mfTransactionSnapshot());return;}}catch(e){}
      }
      cloudSyncSuppressed=false;mfShowCloudMessage(payload||'No cloud backup was found. Your current local data has not been changed.');return;
    }
    try{
      const cloud=mfParseCloudPayload(payload);if(!cloud)throw new Error('Invalid cloud backup.');
      if(Array.isArray(cloud.profiles)&&cloud.profiles.length){
        let mergedProfiles=mfMergeProfiles(cloud.profiles);
        const local=mfProfilesForCloud();
        /* On a brand-new install, discard only the untouched placeholder Mode. */
        if(local.length===1&&!local[0].transactions.length&&!local[0].profilePhoto&&(!local[0].security||!local[0].security.pinHash)&&local[0].name==='My Money'){
          const remoteIds=new Set(cloud.profiles.map(p=>String(p.id)));
          if(!remoteIds.has(String(local[0].id)))mergedProfiles=mfProfilesForCloudFrom(cloud.profiles);
        }
        mfApplyProfiles(mergedProfiles,cloud.activeProfileId);
      }else{
        const mergedTransactions=mfMergeCloudWithLocal(mfCloneTxList(cloud.transactions));mfApplyTransactionSet(mergedTransactions);
      }
      mfRecalculateAfterRestore();saveNative();cloudSyncSuppressed=false;
      if(autoSync){autoSync=false;autoReloadAfterCloudWrite=true;mfRequestCloudUpload(mfTransactionSnapshot());return;}
      autoReloadAfterCloudWrite=true;
      if(mfRequestCloudUpload(mfTransactionSnapshot()))mfShowCloudMessage('✓ Cloud restored. Profiles/Modes, profile photos and PIN settings were restored; local unsynced transactions were preserved. Syncing merged data…');
      else{autoReloadAfterCloudWrite=false;mfShowCloudMessage('✓ Cloud restored. Profiles/Modes, profile photos and PIN settings were restored; local unsynced transactions were preserved.');setTimeout(function(){location.reload()},120);}
    }catch(e){cloudSyncSuppressed=false;autoSync=false;autoReloadAfterCloudWrite=false;mfShowCloudMessage('Cloud restore failed: '+(e&&e.message?e.message:'Invalid backup.'));}
  };

  window.mfCloseBackup=function(){const m=document.getElementById('mfBackupModal');if(m)m.style.display='none'};
  window.mfRestoreFromFile=function(){try{if(window.AndroidBackup&&AndroidBackup.openBackupFile){AndroidBackup.openBackupFile();return}}catch(e){}alert('Backup file picker is not available on this build.');};
  window.mfApplyBackup=function(json){
    try{
      const cloud=mfParseCloudPayload(json);if(!cloud)throw new Error('Invalid backup file');
      if(!confirm('Restore this backup? Profiles/Modes, profile photos and PIN settings will be restored, while local unsynced transactions will be preserved and merged. Notes remain local to this device.'))return;
      if(Array.isArray(cloud.profiles)&&cloud.profiles.length)mfApplyProfiles(mfMergeProfiles(cloud.profiles),cloud.activeProfileId);
      else mfApplyTransactionSet(mfMergeCloudWithLocal(mfCloneTxList(cloud.transactions)));
      mfRecalculateAfterRestore();saveNative();autoReloadAfterCloudWrite=true;
      if(mfRequestCloudUpload(mfTransactionSnapshot()))alert('Backup restored. Profiles/Modes, photos and PIN settings were restored, and local unsynced transactions were preserved and merged. Syncing the merged backup now.');
      else{autoReloadAfterCloudWrite=false;alert('Backup restored. Profiles/Modes, photos and PIN settings were restored, and local unsynced transactions were preserved and merged.');location.reload();}
    }catch(e){alert('Backup restore failed: '+(e&&e.message?e.message:'Unknown error'))}
  };
  // V46 FIX: never auto-restore the legacy device-wide recovery snapshot.
  // That snapshot is not account-scoped, so restoring it at startup can
  // re-introduce another account's transactions into a newly signed-in user.
  // Account-isolated local data is now loaded only by v46Activate(uid).
  // Google Drive account backup is the automatic recovery mechanism.
  window.mfMaybeRestoreNative=function(){ return false; };
  const oldSet=Storage.prototype.setItem;
  Storage.prototype.setItem=function(k,v){
    const r=oldSet.apply(this,arguments);
    /* IMPORTANT: auto cloud sync is transaction-only. Notes, profile/security,
       UI settings and other localStorage writes must never trigger cloud sync. */
    if(this===localStorage && k===KEY){
      schedule();
      if(!cloudSyncSuppressed)scheduleCloud();
    }
    return r;
  };
  window.addEventListener('load',function(){
    setTimeout(function(){
      saveNative();
      mfMaybeRestoreNative();
    },1200);
  });
})();


/* Money Flow Firebase Account / Login */
(function(){
  let mode='login', autoSyncPending=false, authGateActive=false;
  function el(id){return document.getElementById(id)}
  function msg(text,ok){const x=el('mfAccountMsg');if(!x)return;x.textContent=text||'';x.className='mf-account-msg '+(ok?'ok':'err')}
  function showVerification(message,email){
    const panel=el('mfEmailVerificationPanel');
    const text=el('mfEmailVerificationText');
    const signedOut=el('mfAccountSignedOut');
    const note=el('mfAccountRequiredNote');
    if(signedOut)signedOut.style.display='block';
    if(panel)panel.style.display='block';
    if(note)note.style.display='none';
    if(text)text.textContent=(message||'Your email address is not verified yet.')+(email?' Verification email/account: '+email+'.':'');
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').classList.remove('active');
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').classList.remove('active');
    ['mfAccountNameWrap','mfAccountConfirmWrap','mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='none'});
  }
  function hideVerification(){
    const panel=el('mfEmailVerificationPanel');
    if(panel)panel.style.display='none';
    ['mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='block'});
    if(el('mfAccountNameWrap'))el('mfAccountNameWrap').style.display='none';
    if(el('mfAccountConfirmWrap'))el('mfAccountConfirmWrap').style.display='none';
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').style.display='block';
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').style.display='block';
  }
  function signedIn(email,name){
    el('mfAccountSignedOut').style.display='none';
    el('mfAccountSignedIn').style.display='block';
    el('mfAccountEmail').textContent=email||'';
    el('mfAccountName').textContent=name||'Money Flow Account';
    const b=el('mfAccountSignedMsg');if(b)b.textContent='Signed in. Cloud Backup is linked to this account.';
    const badge=el('mfBackupAccount');
    if(badge){
      try{
        const ps=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');
        const aid=localStorage.getItem('money_manager_active_profile_v10') || localStorage.getItem('activeProfileId') || localStorage.getItem('currentProfileId') || '';
        const ap=Array.isArray(ps)?(ps.find(x=>x&&x.id===aid)||ps[0]):null;
        badge.textContent=ap&&ap.name ? ap.name : (email||'Signed in');
      }catch(e){badge.textContent=email||'Signed in';}
    }
    try{localStorage.setItem('mf_account_mode','account');localStorage.setItem('mf_account_email',String(email||'').trim().toLowerCase())}catch(e){}
    if(authGateActive){authGateActive=false;const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}}
  }
  function signedOut(){
    el('mfAccountSignedOut').style.display='block';
    el('mfAccountSignedIn').style.display='none';
    const badge=el('mfBackupAccount');if(badge)badge.textContent='Sign in with Google';
    try{localStorage.removeItem('mf_account_email');for(let i=sessionStorage.length-1;i>=0;i--){const k=sessionStorage.key(i);if(k&&k.indexOf('pf_auto_cloud_sync_done_')===0)sessionStorage.removeItem(k)}}catch(e){}
    if(authGateActive){const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}}
  }
  window.mfAccountMode=function(m){
    hideVerification();
    mode=m;
    const signup=m==='signup';
    el('mfAccountLoginTab').classList.toggle('active',!signup);
    el('mfAccountSignupTab').classList.toggle('active',signup);
    el('mfAccountNameWrap').style.display=signup?'block':'none';
    el('mfAccountConfirmWrap').style.display=signup?'block':'none';
    el('mfAccountPrimary').textContent=signup?'Create Account':'Login';
    el('mfAccountReset').style.display=signup?'none':'block';
    el('mfAccountPasswordInput').autocomplete=signup?'new-password':'current-password';
    msg('');
  };
  window.mfOpenAccount=function(mandatory){
    authGateActive=!!mandatory;
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    const m=el('mfAccountModal');
    if(m){m.classList.toggle('mf-account-modal-mandatory',authGateActive);m.style.display='block';}
    msg('');
    try{if(window.AndroidAuth&&AndroidAuth.getStatus)AndroidAuth.getStatus();}catch(e){}
  };
  window.mfCloseAccount=function(){if(authGateActive)return;const m=el('mfAccountModal');if(m)m.style.display='none'};
  window.mfContinueGuest=function(){
    if(authGateActive)return;
    try{localStorage.setItem('mf_account_mode','guest')}catch(e){}
    msg('Guest mode enabled. Your data remains on this device.',true);
    setTimeout(mfCloseAccount,450);
  };
  window.mfAccountSubmit=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    const password=el('mfAccountPasswordInput').value||'';
    if(!email){msg('Enter your email address.');return}
    if(mode==='signup') {
      const name=(el('mfAccountNameInput').value||'').trim();
      const confirm=el('mfAccountConfirmInput').value||'';
      if(password.length<6){msg('Password must be at least 6 characters.');return}
      if(password!==confirm){msg('Passwords do not match.');return}
      msg('Creating account…',true);
      try{AndroidAuth.signUp(name,email,password)}catch(e){msg('Account service unavailable.')}
    } else {
      msg('Signing in…',true);
      try{AndroidAuth.signIn(email,password)}catch(e){msg('Account service unavailable.')}
    }
  };
  window.mfGoogleLogin=function(){
    msg('Opening Google Sign-In…',true);
    try{AndroidAuth.signInWithGoogle()}catch(e){msg('Google Sign-In service unavailable.')}
  };
  window.mfAccountReset=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    if(!email){msg('Enter your account email first.');return}
    msg('Sending password reset email…',true);
    try{AndroidAuth.resetPassword(email)}catch(e){msg('Account service unavailable.')}
  };
  window.mfCheckEmailVerification=function(){
    msg('Checking email verification status…',true);
    try{AndroidAuth.checkEmailVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfBackToLogin=function(){
    hideVerification();
    try{AndroidAuth.signOut()}catch(e){}
    window.mfAccountMode('login');
    msg('Please verify your email first, then log in.');
  };
  window.mfAccountLogout=function(){
    if(typeof window.mfStartLogoutBackup==='function'){
      window.mfStartLogoutBackup();
      return;
    }
    msg('Cloud backup service is not available on this build.');
  };
  window.mfResendVerification=function(){
    msg('Sending verification email…',true);
    try{AndroidAuth.resendVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfAuthResult=function(ok,action,message,email,name){
    if(action==='status'){
      const onboardingComplete=localStorage.getItem('money_flow_onboarding_complete_v1')==='1';
      if(message==='signed_in'){
        hideVerification();
        signedIn(email,name);
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      } else if(message==='verify_required'){
        authGateActive=true;
        showVerification('Your email address is not verified yet. Open the verification email and tap its verification link.',email);
        const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      } else if(onboardingComplete){
        authGateActive=true;
        signedOut();
      } else {
        signedOut();
      }
      return;
    }
    if(ok && action==='verify_required'){
      authGateActive=true;
      showVerification(message,email);
      const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      msg(message,true);
      return;
    }
    if(ok && (action==='login'||action==='google'||action==='signup')){
      signedIn(email,name);
      msg(message,true);
      if(action==='login'||action==='google'){
        autoSyncPending=true;
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      }
      return;
    }
    if(ok && action==='logout'){
      signedOut();msg(message,true);return;
    }
    if(ok && action==='reset'){msg(message,true);return}
    if(ok && action==='verify_sent'){msg(message,true);return}
    if(ok && action==='verified'){
      hideVerification();
      authGateActive=false;
      const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}
      msg(message,true);
      try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      return;
    }
    if(!ok && action==='verify_check'){msg(message,false);return}
    msg(message||'Authentication failed.');
  };
  window.addEventListener('load',function(){
    try{
      if(localStorage.getItem('money_flow_onboarding_complete_v1')==='1' && window.AndroidAuth&&AndroidAuth.getStatus) AndroidAuth.getStatus();
    }catch(e){}
  });
})();
