
(function(){
  'use strict';
  function bindSwipeEdit(root){
    const list=root||document.getElementById('pfTransactionsList');
    if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(function(row){
      const main=row.querySelector('.pf-detail-main');
      if(!main)return;
      let btn=row.querySelector('.pf-swipe-reveal');
      if(!btn){
        btn=document.createElement('button');
        btn.type='button';
        btn.className='pf-swipe-reveal';
        btn.textContent='Edit';
        btn.setAttribute('aria-label','Edit transaction');
        row.insertBefore(btn,main);
      }
      if(btn.dataset.finalSwipeEdit==='1')return;
      btn.dataset.finalSwipeEdit='1';
      function doEdit(e){
        if(e){e.preventDefault();e.stopPropagation();}
        const id=row.getAttribute('data-tx-id');
        row.classList.remove('open');
        main.style.transition='transform .15s ease';
        main.style.transform='translateX(0)';
        if(id!==null && id!=='' && typeof window.v10RequestEdit==='function'){
          setTimeout(function(){window.v10RequestEdit(id);},0);
        }
      }
      btn.addEventListener('click',doEdit,false);
      btn.addEventListener('touchend',doEdit,{passive:false});

      const exp=row.querySelector('.pf-expand-btn');
      if(exp && !exp.dataset.finalSwipeExpand){
        exp.dataset.finalSwipeExpand='1';
        exp.addEventListener('click',function(){
          /* Expanding must always close any active swipe-reveal state first. */
          row.classList.remove('open');
          main.style.transition='transform .15s ease';
          main.style.transform='translateX(0)';
        },true);
      }
    });
  }
  const list=document.getElementById('pfTransactionsList');
  if(list){
    new MutationObserver(function(){bindSwipeEdit(list);}).observe(list,{childList:true,subtree:true});
    bindSwipeEdit(list);
  }
  const oldRender=window.pfTxRender;
  if(typeof oldRender==='function' && !window.__mfFinalSwipeRender){
    window.__mfFinalSwipeRender=true;
    window.pfTxRender=function(){
      const r=oldRender.apply(this,arguments);
      requestAnimationFrame(function(){bindSwipeEdit();});
      return r;
    };
  }
})();
