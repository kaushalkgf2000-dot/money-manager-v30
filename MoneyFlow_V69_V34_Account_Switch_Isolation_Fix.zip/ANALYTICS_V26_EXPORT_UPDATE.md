# MoneyFlow V26 — Analytics Export Update

- Analytics **Save Images** now creates 3 high-resolution PNG parts covering the complete analytics scroll.
- Analytics **Export PDF** now creates a 3-page vector PDF directly from analytics data.
- PDF is not generated from screenshots/canvas images, so zooming remains sharp.
- PDF includes Overview, Expense by Category, Today vs Yesterday, Monthly Comparison, Highlights, Highest Single Expense details, and Category Ranking.
- Existing transaction logic, cloud backup/restore, Sign Out → Backup → Sign Out, profile/mode, notes, calculator, and existing analytics calculations are not replaced by this module.
