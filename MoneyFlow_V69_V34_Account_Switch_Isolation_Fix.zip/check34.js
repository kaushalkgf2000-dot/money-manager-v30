
(function(){
'use strict';

/* ================================================================
   MF V21 — TRANSACTION FORM STATE CONTROLLER
   Isolated module: does not replace the transaction-save core.
   ================================================================ */
(function(){
  const TYPE='type', CAT='categorySelect', AMT='amountPreset';
  function today(){return typeof localToday==='function'?localToday():new Date().toISOString().slice(0,10)}
  function getConfig(){
    try{
      if(typeof config==='object'&&config)return config;
      const x=JSON.parse(localStorage.getItem('money_manager_config')||'null');
      return x||{creditAmounts:[100,500,1000],expenseAmounts:[50,100,500],creditCategories:['Salary','Home Money','Other Income'],expenseCategories:['Food','Transport','Bills','Shopping','Other']};
    }catch(e){return {creditAmounts:[100,500,1000],expenseAmounts:[50,100,500],creditCategories:['Salary','Home Money','Other Income'],expenseCategories:['Food','Transport','Bills','Shopping','Other']}}
  }
  function reset(){
    const d=document.getElementById('date'),t=document.getElementById(TYPE),a=document.getElementById(AMT),c=document.getElementById(CAT);
    if(d){d.max=today();d.value=today()}
    if(t)t.value='';
    if(a){a.innerHTML='<option value="" selected>Select amount</option>';a.value='';}
    const ca=document.getElementById('customAmount');if(ca){ca.value='';ca.style.display='none'}
    if(c){c.innerHTML='<option value="" selected>Select category</option>';c.value='';}
    const cc=document.getElementById('customCategory');if(cc){cc.value='';cc.style.display='none'}
    const m=document.getElementById('mode');if(m)m.value='';
    ['description','remark','other'].forEach(id=>{const e=document.getElementById(id);if(e)e.value=''})
  }
  function populate(){
    const t=document.getElementById(TYPE),a=document.getElementById(AMT),c=document.getElementById(CAT);if(!t||!a||!c)return;
    const v=t.value, cfg=getConfig();
    if(v!=='CREDIT'&&v!=='EXPENSE'){reset();return}
    const amounts=v==='CREDIT'?(cfg.creditAmounts||[]):(cfg.expenseAmounts||[]);
    const cats=v==='CREDIT'?(cfg.creditCategories||[]):(cfg.expenseCategories||[]);
    a.innerHTML='<option value="" selected>Select amount</option>'+amounts.map(n=>'<option value="'+Number(n)+'">₹'+Number(n).toLocaleString('en-IN')+'</option>').join('')+'<option value="CUSTOM">Custom</option>';
    c.innerHTML='<option value="" selected>Select category</option>'+cats.map(x=>'<option value="'+String(x).replace(/"/g,'&quot;')+'">'+String(x).replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]))+'</option>').join('')+'<option value="CUSTOM">Custom</option>';
    a.value='';c.value='';
    const ca=document.getElementById('customAmount');if(ca){ca.value='';ca.style.display='none'}
    const cc=document.getElementById('customCategory');if(cc){cc.value='';cc.style.display='none'}
  }
  window.mfV21ResetTransactionForm=reset;
  window.mfV21RefreshTransactionType=populate;
  document.addEventListener('change',function(e){if(e.target&&e.target.id===TYPE)populate()},true);
  const oldOpen=window.pfOpenAddTransaction;
  if(typeof oldOpen==='function'&&!window.__mfV21AddOpen){
    window.__mfV21AddOpen=true;
    window.pfOpenAddTransaction=function(){reset();return oldOpen.apply(this,arguments)};
  }
  document.addEventListener('click',function(e){
    const b=e.target&&e.target.closest?e.target.closest('#v10AddTxButton'):null;
    if(!b)return;
    setTimeout(function(){
      const m=document.getElementById('addTransactionModal');
      if(m&&getComputedStyle(m).display==='none')reset();
    },80);
  },true);
  function boot(){reset()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

/* ================================================================
   MF V21 — PROFILE PHOTO / MODE ISOLATION
   A completely separate picker controller. Uses the active profile ID
   at both open and commit, so Profile B cannot save into Profile A.
   ================================================================ */
(function(){
  const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
  const sets={
    male:[['M1','#cfe8ff','#263b57','#111827','beard'],['M2','#dff4e7','#29463b','#111a16','beard'],['M3','#ffe3c9','#5b3d2e','#20140e','beard'],['M4','#e7dcff','#403657','#15111c','cap'],['M5','#dcecf7','#344b60','#151b22','beard'],['M6','#f1dfc9','#2f4a3b','#111710','beard'],['M7','#e9e9ea','#4c3a31','#141311','glasses'],['M8','#d9eaff','#51465b','#121016','beard']],
    female:[['F1','#ffdce9','#553246','#24151d','long'],['F2','#e7ddff','#4d4167','#18131f','long'],['F3','#ffe5d0','#704b36','#21150e','long'],['F4','#dff2e9','#3c554a','#151d19','long'],['F5','#dce9ff','#465a70','#161b24','bob'],['F6','#f5e0d2','#613e48','#201318','long'],['F7','#eee3d6','#4a423a','#151311','long'],['F8','#e5dcff','#503c59','#18111b','bob']],
    other:[['O1','#dff3ff','#315267','#121c23','short'],['O2','#eee2ff','#57416d','#191220','hood'],['O3','#e6f1d8','#40553b','#151c13','short'],['O4','#ffe5d5','#5d493a','#20170f','hood'],['O5','#dce7ef','#42525e','#141b20','glasses'],['O6','#f0dff2','#5c415c','#1c121c','short'],['O7','#e8e8e8','#444','#111','short'],['O8','#dff1ee','#3c5750','#111b18','hood']]
  };
  function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  function avatar(kind,bg,shirt,hair,style){
    const g=kind[0],female=g==='F',other=g==='O';
    const skin=female?'#d9a17f':other?'#c79576':'#bd805f';
    const skin2=female?'#a96d55':other?'#9d684f':'#95583f';
    let head='<ellipse cx="100" cy="91" rx="45" ry="56" fill="'+skin+'"/>';
    let hairPath='';
    if(female){
      hairPath=style==='bob'?'<path d="M50 96C44 48 68 16 101 18c35 2 55 29 49 77l-16 9-5-48c-20 17-42 24-71 23l-1 43-10-4z" fill="'+hair+'"/>':'<path d="M48 94C42 43 67 13 101 16c37 3 57 34 50 81l-15 5-7-42c-19 18-42 25-71 25l-1 62-12 4c-10-20-9-35 3-57z" fill="'+hair+'"/>';
    }else if(style==='cap'||style==='hood'){
      hairPath='<path d="M50 78c1-42 23-62 50-62 30 0 51 23 50 65l-17 10-10-31c-17 14-40 22-69 22z" fill="'+hair+'"/>';
      if(style==='cap')hairPath+='<path d="M54 42c15-22 77-26 94 7-26-8-63-7-94-7z" fill="#202733"/><path d="M119 47c23-2 38 1 47 9-17 7-32 5-47-1z" fill="#171c25"/>';
      if(style==='hood')hairPath+='<path d="M46 75c-8-28 1-56 24-67 25-13 53-3 72 21-19-8-37-9-57-2-14 5-26 17-39 48z" fill="'+shirt+'" opacity=".9"/>';
    }else{
      hairPath='<path d="M50 84c0-43 21-67 50-67 32 0 52 24 49 65-14-7-26-16-39-28-17 20-36 28-60 30z" fill="'+hair+'"/>';
    }
    const beard=(!female&&style!=='hood')?'<path d="M70 108c4 29 16 40 30 40s26-11 30-40c-6 13-18 20-30 20s-24-7-30-20z" fill="'+skin2+'"/>':'';
    const glasses=style==='glasses'?'<rect x="66" y="87" width="28" height="18" rx="7" fill="none" stroke="#28313b" stroke-width="5"/><rect x="106" y="87" width="28" height="18" rx="7" fill="none" stroke="#28313b" stroke-width="5"/><path d="M94 94h12" stroke="#28313b" stroke-width="5"/>':'';
    const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="'+bg+'"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><rect width="200" height="200" rx="100" fill="url(#bg)"/><ellipse cx="100" cy="190" rx="70" ry="52" fill="'+shirt+'"/>'+head+hairPath+'<path d="M82 79q9-7 18 0M108 79q9-7 18 0" fill="none" stroke="#352b27" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="5" ry="7" fill="#241e1c"/><ellipse cx="119" cy="93" rx="5" ry="7" fill="#241e1c"/>'+glasses+beard+'<path d="M88 116q12 8 24 0" fill="none" stroke="#8b5148" stroke-width="4" stroke-linecap="round"/></svg>';
    return 'data:image/svg+xml;charset=UTF-8,'+encodeURIComponent(svg);
  }
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=profiles(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId');return a.find(p=>p&&String(p.id)===String(id))||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function getPhoto(p){return p&&typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0?p.profilePhoto:''}
  function data(g){return (sets[g]||sets.other).map(x=>({id:x[0],src:avatar(x[0],x[1],x[2],x[3],x[4])}))}
  let modal,state;
  function ensure(){
    if(modal)return modal;
    modal=document.createElement('div');modal.id='mf21PhotoModal';modal.className='mf19-photo-modal';
    modal.innerHTML='<div class="mf19-photo-box"><div class="mf19-photo-head"><div><h2 id="mf21Title">Choose Profile Photo</h2><p>Select an avatar or upload from your gallery</p></div><button class="mf19-x" id="mf21Close">×</button></div><div class="mf19-preview" id="mf21Preview"></div><label class="mf19-gallery" for="mf21Gallery"><div class="mf19-gallery-icon">🖼️</div><div><b>Click to upload from Gallery</b><small>Choose your own photo</small></div></label><input id="mf21Gallery" class="pf-profile-input" type="file" accept="image/*"><div class="mf19-label">Select default avatar</div><div class="mf19-tabs"><button data-g="male">♂ Male</button><button data-g="female">♀ Female</button><button data-g="other">◈ Other</button></div><div class="mf21-avatar-grid" id="mf21Grid"></div><div class="mf19-pager"><button id="mf21Prev">‹</button><span class="mf19-page" id="mf21Page">1 / 2</span><button id="mf21Next">›</button></div><button class="mf19-ok" id="mf21OK">OK</button><div class="mf19-hint">This photo belongs only to the current Profile / Mode.</div></div>';
    document.body.appendChild(modal);
    document.getElementById('mf21Close').onclick=close;document.getElementById('mf21OK').onclick=commit;
    document.getElementById('mf21Prev').onclick=()=>{state.page=Math.max(0,state.page-1);render()};document.getElementById('mf21Next').onclick=()=>{state.page=Math.min(1,state.page+1);render()};
    modal.querySelectorAll('.mf19-tabs button').forEach(b=>b.onclick=()=>{state.gender=b.dataset.g;state.page=0;const p=active();state.photo=getPhoto(p)||data(state.gender)[0].src;render()});
    document.getElementById('mf21Gallery').onchange=function(){const f=this.files&&this.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const max=640,s=Math.min(1,max/Math.max(im.naturalWidth||im.width,im.naturalHeight||im.height)),w=Math.max(1,Math.round((im.naturalWidth||im.width)*s)),h=Math.max(1,Math.round((im.naturalHeight||im.height)*s));const cv=document.createElement('canvas');cv.width=w;cv.height=h;cv.getContext('2d').drawImage(im,0,0,w,h);state.photo=cv.toDataURL('image/jpeg',.8);renderPreview()};im.onerror=()=>{state.photo=String(r.result);renderPreview()};im.src=String(r.result)};r.readAsDataURL(f)};
    return modal;
  }
  function renderPreview(){const e=document.getElementById('mf21Preview');if(e)e.innerHTML=state.photo?'<img alt="Selected profile photo" src="'+esc(state.photo)+'">':''}
  function render(){const g=document.getElementById('mf21Grid');if(!g)return;const arr=data(state.gender),items=arr.slice(state.page*4,state.page*4+4);g.innerHTML=items.map(x=>'<button type="button" class="mf21-avatar '+(state.photo===x.src?'active':'')+'" data-src="'+esc(x.src)+'"><img alt="'+esc(x.id)+' avatar" src="'+x.src+'"></button>').join('');g.querySelectorAll('button').forEach(b=>b.onclick=()=>{state.photo=b.dataset.src;render()});document.getElementById('mf21Page').textContent=(state.page+1)+' / 2';document.getElementById('mf21Prev').disabled=state.page===0;document.getElementById('mf21Next').disabled=state.page===1;modal.querySelectorAll('.mf19-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.g===state.gender));renderPreview()}
  function open(){const p=active();if(!p)return;state={profileId:String(p.id),gender:['male','female','other'].includes(String(p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',page:0,photo:getPhoto(p)||data(p.profileGender||'male')[0].src};ensure().classList.add('open');modal.setAttribute('aria-hidden','false');render()}
  function close(){if(modal){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}}
  function commit(){
    if(!state||!state.profileId)return;
    const a=profiles(),i=a.findIndex(p=>p&&String(p.id)===String(state.profileId));if(i<0)return;
    const q=a[i],photo=state.photo||data(state.gender)[0].src;q.profileGender=state.gender;q.profilePhoto=photo;a[i]=q;
    try{save(a);localStorage.setItem('money_flow_profile_photo_'+String(q.id),photo)}catch(e){alert('Profile photo could not be saved.');return}
    close();
    try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}
    try{if(typeof window.render==='function')window.render()}catch(e){}
    try{if(typeof window.pfScheduleCloudSync==='function')window.pfScheduleCloudSync()}catch(e){}
  }
  window.mfV21OpenProfilePhoto=open;
  const b=document.getElementById('profilePhotoBtn');
  function bind(){const x=document.getElementById('profilePhotoBtn');if(x&&!x.__mf21){x.__mf21=true;x.onclick=open;x.setAttribute('aria-label','Choose profile photo')}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();setTimeout(bind,250);setTimeout(bind,800);
})();

/* ================================================================
   MF V21 — ANALYTICS EXPORT: expose a real global handler.
   The previous function lived inside an IIFE, so inline onclick could
   not resolve it. This module owns the public export API.
   ================================================================ */
(function(){
  function money(v){return '₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2})}
  function tx(){try{if(typeof window.mfActiveProfileTransactions==='function')return window.mfActiveProfileTransactions()||[];if(typeof txs!=='undefined'&&Array.isArray(txs))return txs;return []}catch(e){return[]}}
  function catTotals(arr,type){const m={};arr.filter(t=>String(t.type||'').toUpperCase()===type).forEach(t=>{const c=t.category||'Uncategorized';m[c]=(m[c]||0)+(Number(t.amount)||0)});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
  window.pfExportAnalyticsImage=function(){
    try{
      const data=tx(),ex=data.filter(t=>String(t.type).toUpperCase()!=='CREDIT'),cr=data.filter(t=>String(t.type).toUpperCase()==='CREDIT'),te=ex.reduce((s,t)=>s+(Number(t.amount)||0),0),tc=cr.reduce((s,t)=>s+(Number(t.amount)||0),0),cats=catTotals(data,'EXPENSE').slice(0,8),W=1200,H=1550,cv=document.createElement('canvas');cv.width=W;cv.height=H;const c=cv.getContext('2d');
      if(!c)throw new Error('Canvas is unavailable on this device.');
      c.fillStyle='#faf8f2';c.fillRect(0,0,W,H);c.fillStyle='#51463a';c.font='700 46px Arial';c.fillText('Money Flow — Analytics',60,70);c.font='22px Arial';c.fillStyle='#8b8378';c.fillText(new Date().toLocaleDateString('en-IN'),60,105);
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Expense by Category',60,165);let y=215;const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];cats.forEach((x,i)=>{c.fillStyle=pal[i%pal.length];c.beginPath();c.arc(75,y-7,9,0,Math.PI*2);c.fill();c.fillStyle='#51463a';c.font='21px Arial';c.fillText(x[0],100,y);c.textAlign='right';c.font='700 20px Arial';c.fillText(money(x[1]),1140,y);c.textAlign='left';y+=45});
      function box(x,yy,w,title,val,sub){c.fillStyle='#fffdf9';c.strokeStyle='#ded8cc';c.lineWidth=2;c.beginPath();c.roundRect?c.roundRect(x,yy,w,110,18):(function(){c.moveTo(x+18,yy);c.lineTo(x+w-18,yy);c.quadraticCurveTo(x+w,yy,x+w,yy+18);c.lineTo(x+w,yy+92);c.quadraticCurveTo(x+w,yy+110,x+w-18,yy+110);c.lineTo(x+18,yy+110);c.quadraticCurveTo(x,yy+110,x,yy+92);c.lineTo(x,yy+18);c.quadraticCurveTo(x,yy,x+18,yy)})();c.fill();c.stroke();c.fillStyle='#51463a';c.font='700 20px Arial';c.fillText(title,x+22,yy+32);c.font='700 30px Arial';c.fillText(money(val),x+22,yy+70);c.fillStyle='#8b8378';c.font='17px Arial';c.fillText(sub,x+22,yy+95)}
      box(60,610,520,'Total Credit',tc,'All time income');box(620,610,520,'Total Expense',te,'All time expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Today vs Yesterday',60,760);box(60,800,330,'Credit Today',0,'Income today');box(435,800,330,'Expense Today',0,'Expense today');box(810,800,330,'Today Net',0,'Credit − Expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Category Ranking',60,980);const ranking=[...catTotals(data,'CREDIT').map(x=>['Cr',x[0],x[1]]),...cats.map(x=>['Exp',x[0],x[1]])].sort((a,b)=>b[2]-a[2]).slice(0,7),rm=Math.max(1,...ranking.map(x=>x[2]));ranking.forEach((x,i)=>{const yy=1025+i*58;c.fillStyle='#51463a';c.font='18px Arial';c.fillText((i+1)+'. '+x[0]+' '+x[1],60,yy);c.fillStyle=x[0]==='Cr'?'#2fa65b':'#e3483d';c.fillRect(430,yy-15,570*(x[2]/rm),18);c.fillStyle='#51463a';c.textAlign='right';c.font='700 18px Arial';c.fillText(money(x[2]),1110,yy);c.textAlign='left'});c.fillStyle='#8b8378';c.font='17px Arial';c.fillText('Generated from Money Flow transaction analytics',60,H-45);
      const b64=cv.toDataURL('image/png').split(',')[1],name='money_flow_analytics_'+Date.now()+'.png';
      if(window.AndroidFile&&typeof window.AndroidFile.saveFile==='function'){window.AndroidFile.saveFile(name,'image/png',b64);alert('Analytics image saved successfully.');return true}
      const a=document.createElement('a');a.href='data:image/png;base64,'+b64;a.download=name;document.body.appendChild(a);a.click();a.remove();return true;
    }catch(e){alert('Export Image failed: '+(e&&e.message?e.message:'Unknown error'));return false}
  };
})();

/* ================================================================
   MF V21 — CLOUD-ONLY MANUAL SYNC
   Manual Google Drive Sync must not create a local backup snapshot.
   Sign-out backup continues to use the existing native snapshot path.
   ================================================================ */
(function(){
  const old=window.mfBackupNow;
  if(typeof old==='function'&&!window.__mfV21CloudOnlyBackup){
    window.__mfV21CloudOnlyBackup=true;
    window.mfBackupNow=function(){
      const prev=!!window.__mfV21CloudOnlyManualBackup;
      window.__mfV21CloudOnlyManualBackup=true;
      try{return old.apply(this,arguments)}finally{window.__mfV21CloudOnlyManualBackup=prev;}
    };
  }
})();
})();
