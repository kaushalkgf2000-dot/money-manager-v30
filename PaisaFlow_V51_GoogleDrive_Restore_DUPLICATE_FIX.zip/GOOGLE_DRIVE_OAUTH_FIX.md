# PaisaFlow Google Drive OAuth fix

The runtime error `UNREGISTERED_ON_API_CONSOLE` was traced to the APK certificate.
The GitHub Actions build was using the runner's temporary debug keystore, so its SHA-1 could differ from the Android OAuth client registered in Google Cloud.

This build uses a fixed debug keystore:
- Package: `com.moneymanager.v30`
- SHA-1: `89:17:AC:2C:60:D5:8A:4F:4E:B4:B9:53:17:BB:95:C2:74:F6:C4:FD`

Before testing this APK, add an Android OAuth client in the same Google Cloud project with exactly this package name and SHA-1.

The existing Drive API / `drive.appdata` implementation is retained; no transaction, PIN, biometric, balance, or local backup logic was changed.
