# Step 42.4 — Exact Subject Card Refinement

## Goal
Match the approved Style-8 subject-card composition without using the reference screenshot as an asset.

## Implementation
- Subject artwork is drawn at runtime with Jetpack Compose Canvas.
- No subject screenshot/crop/bitmap is loaded by `SubjectGlyph`.
- Every subject uses the same fixed icon anchor: 112dp square container and 82dp vector drawing area.
- Card content uses a stable row/column hierarchy so icon size cannot change text positioning.
- Subject names can wrap to two lines instead of being truncated to `Streng...` / `Fluid...`.
- Status badge is constrained to one line and separated from the title.
- Progress percentage is kept on the same row as the progress bar.
- Chapter completion metadata is kept in a single compact row.
- Chevron remains a fixed trailing affordance.

## Verification limits
This environment does not contain the Android Gradle wrapper/SDK, so a device APK build cannot be performed here. Source inspection confirms the subject-card path contains no screenshot subject-image loading.
