# STEP 42.5 — Subject Card Layout Rebuild

## Goal
Rebuild the Study Material subject card around the approved Style-8 reference composition rather than trying to reproduce the reference screenshot itself.

## Runtime implementation
- Subject artwork is drawn with Jetpack Compose Canvas; no subject screenshot/crop is loaded.
- Icon container is a fixed visual anchor (88dp on compact widths, 96dp otherwise).
- Artwork is independently sized (66dp/72dp) so artwork scale cannot move text.
- Card content uses a weighted column and a fixed trailing chevron.
- Status badge is overlaid in the content header and has a bounded compact width.
- Subject title gets the remaining header width and may use two lines; it is not ellipsized.
- Metadata remains two controlled rows.
- Progress bar and percentage share one row.
- Chapter completion and completion percentage share one compact row.
- Card padding and vertical spacing are reduced to avoid the oversized cards seen in device QA.

## Important
The reference image is a visual specification only. It is not bundled or cropped at runtime.
