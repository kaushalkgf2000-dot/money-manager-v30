# Step 49 — Subject Card Final Responsive Fix

## Objective
Match the locked Study Material reference while preventing the previous mobile layout collapse.

## Structural rules
- Fixed artwork rail on the left.
- Independent content rail in the middle.
- Fixed chevron rail on the right.
- Subject title is never reduced to a single character.
- Status badge has an independent overlay position.
- Metadata, progress and chapter-progress rows remain inside the content rail.
- Vector artwork is rendered by `SubjectGlyph`; no screenshot/cropped reference artwork is used.
- Subject-specific accent colours are retained.
- Glass background, border, inner highlight and glow are retained.

## Important regression fixed
The previous implementation allowed the title/status row to collapse under narrow constraints, producing `S`, `F`, missing metadata and white layout artifacts. The final implementation uses a bounded title Box and separate navigation rail so the text column remains measurable.
