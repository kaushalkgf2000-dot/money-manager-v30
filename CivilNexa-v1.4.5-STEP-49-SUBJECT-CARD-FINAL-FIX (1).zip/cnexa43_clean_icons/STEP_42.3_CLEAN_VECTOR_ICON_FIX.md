# STEP 42.3 — Clean Vector-Style Subject Icon Fix

## Root cause
The tested screen showed rectangular pieces of the Style-8 reference sheet inside subject cards. That is a screenshot-crop implementation and is rejected.

## Implementation
- Subject icons are rendered with Jetpack Compose Canvas geometry at runtime.
- No subject icon uses `painterResource`, a cropped reference image, or a screenshot bitmap.
- The card reserves a fixed 96dp icon slot and centers a 72dp vector-style glyph.
- The icon slot has a controlled glass/neon background and border.
- The title/module/progress/chevron layout is independent of the icon asset, so icon scaling cannot shift card content.

## 16 subject mappings
Strength of Materials; Fluid Mechanics; Surveying; Soil Mechanics; RCC Design; Highway Engineering; Railways; Bridges & Tunnels; Irrigation & Water Supply; Waste Water System; Building Construction; Environmental Engineering; Geotechnical Engineering; Construction Management; Estimation & Costing; Engineering Mathematics.

## QA rules
1. No screenshot crop in subject cards.
2. No subject bitmap under `app/src/main/res/drawable`.
3. Every subject name resolves to a Canvas glyph.
4. Icon slot is fixed and consistent across all subjects.
5. Long subject names are text-only and cannot overlap the icon.
