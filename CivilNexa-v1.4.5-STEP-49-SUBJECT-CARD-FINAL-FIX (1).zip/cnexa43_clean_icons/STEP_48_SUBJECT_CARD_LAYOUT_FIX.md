# Step 48 — Subject Card Layout Fix

## Fixed
- Removed the title/badge overlay layout that caused one-character subject titles (`S`, `F`, etc.) on device.
- Subject title and status badge now use independent weighted/fixed layout columns.
- Kept the dedicated left artwork rail with fixed geometry.
- Kept the right chevron in its own fixed slot.
- Kept the two metadata rows, progress bar + percentage, and chapter completion line.
- Preserved subject-specific accent colours, glass gradient, translucent surface, glow/border treatment, and vector `SubjectGlyph` artwork.

## Important
The previous screenshot showed a runtime/device layout result where the title width collapsed. This change addresses that specific Compose measurement/layout problem rather than changing the artwork into a screenshot crop.

## Build note
The supplied project does not include `gradlew`, and the execution environment does not have a system Gradle installation, so an actual Gradle compilation cannot be performed here.
