# Step 42.2 — Vector Subject Icon Architecture

The Study Material subject icons no longer use screenshot crops or raster reference-card images.

## Implementation
- Each subject icon is rendered at runtime with Jetpack Compose `Canvas`.
- Icons use vector geometry: lines, curves, circles, rounded rectangles and paths.
- A two-pass stroke (soft under-stroke + crisp foreground stroke) provides the Style-8 neon/glow appearance.
- The icon slot is fixed at 96dp with a 76dp drawing area, keeping every subject aligned identically.
- The old `res/drawable/subject_icons` screenshot-crop assets were removed.
- Subject-specific accent colors are preserved.

## Why this is better
- No screenshot crop artifacts.
- No pixelation from small source images.
- No accidental background/card borders inside the icon.
- Resolution-independent rendering on different phones/tablets.
- One consistent geometry/layout system for all 16 subjects.

## Scope
This step fixes the icon rendering architecture and card placement. Educational content remains deferred to the final content-entry phase.
