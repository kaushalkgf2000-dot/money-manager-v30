# STEP 45 — Subject Card Responsive Layout Fix

## Problem fixed
The previous Study Material card allowed the title, status badge and chevron to compete for horizontal space on narrow phone screens. This caused titles such as “Strength of Materials” to collapse to a single character/ellipsis-like layout.

## Changes
- Fixed icon rail width on compact screens.
- Reduced compact typography only where necessary while preserving hierarchy.
- Moved the status badge to its own compact row on narrow screens so the subject name cannot be squeezed by the badge.
- Made the chevron an overlay rail inside the content region so it no longer steals title width.
- Kept the approved large-screen layout: icon → title/badge → module metadata → progress → chapter completion.
- Preserved vector subject artwork; no screenshot/image crop is used.
- Preserved premium accent colors, translucent glass surface, border glow and inner highlight.

## Acceptance criteria
1. No subject title collapses to a single character on phone width.
2. Strength of Materials, Fluid Mechanics, Surveying and all other subjects remain readable.
3. Chevron remains fixed at the right edge of the content rail.
4. Icon artwork remains crisp and centered.
5. Card remains clickable as one complete surface.
