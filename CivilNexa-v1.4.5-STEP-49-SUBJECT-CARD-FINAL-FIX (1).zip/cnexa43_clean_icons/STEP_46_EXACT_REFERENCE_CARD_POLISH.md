# STEP 46 — Exact Reference Subject Card Polish

## Locked target
The Study Material subject card now follows the approved reference composition:
- dedicated left artwork rail
- crystal-clear vector subject glyphs (no screenshot crops)
- translucent layered glass surface
- subject-specific accent colour
- two-line subject title area
- top-right In Progress badge
- module metadata rows
- progress bar + percentage
- chapter completion line
- fixed right chevron

## Responsive correction
The title no longer shares a Row with the badge in a way that can collapse the subject name. The badge is layered in a reserved top-right slot and the title receives a dedicated two-line area. The artwork rail is fixed and never shrinks.

## Acceptance criteria
- Strength of Materials renders as a readable two-line title.
- Fluid Mechanics renders as a readable two-line title when required.
- No one-letter title/ellipsis regression on supported phone widths.
- Vector artwork remains crisp and centered.
- Card remains a single clickable surface.
