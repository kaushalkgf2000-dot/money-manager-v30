# STEP 44 — Study Material Glassmorphism & Vector Polish

## Scope
Polish the four locked visual requirements for the Study Material subject cards:
- crystal-clear vector subject artwork
- premium subject-wise accent colours
- proper translucent glassmorphism
- controlled glow, thin glass border, and subtle inner highlight

## Implementation
- Subject artwork remains Canvas/vector based; no screenshot crops are used as runtime artwork.
- Reduced global vector stroke/glow bloom so artwork reads as crisp neon-vector artwork instead of a heavy outline.
- Reduced icon rail dimensions for better balance with text content.
- Reworked card surface to a translucent layered gradient with a subtle white glass highlight.
- Reduced border opacity/thickness and softened icon-container glow.
- Preserved subject-specific accent colours and reusable SubjectMaterialCard architecture.
- Preserved responsive compact/regular sizing.

## Verification
Source changes completed. Local Android Gradle build could not be executed because this package does not contain a Gradle wrapper and the environment does not provide a `gradle` executable.
