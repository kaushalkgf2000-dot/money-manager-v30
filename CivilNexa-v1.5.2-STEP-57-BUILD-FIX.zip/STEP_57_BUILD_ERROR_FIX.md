# STEP 57 — Build Error Fix

Fixed the CI Kotlin compilation issue in the Test Series update.

## Fix
- `ActivityStat` previously used `Modifier.weight(1f)` inside its own helper function. `weight` is a `RowScope` extension and cannot be called there.
- Changed `ActivityStat` to accept a `modifier` parameter and moved `Modifier.weight(1f)` to the two call sites inside the `Row`.
- Removed unused empty Test Series helper declarations.

## Test Series flow retained
- Subject by Test → Subjects → Subject → Test 1/2/3/4... → Live Test
- Chapter by Test → Subjects → Subject → Chapters → Chapter → Test 1/2/3... → Live Test

Dashboard and unrelated sections were not intentionally changed.
