# MoneyFlow V22 build fix

The source build configuration was not the failure shown in the previous screenshot. The failure occurred in the CI runner's **Setup Android SDK** step: the runner had an older preinstalled `sdkmanager` (12.0), while the setup action was downloading/using a newer command-line-tools package. The Node 20 deprecation line is a warning, not the build failure.

This project now includes `.github/workflows/build.yml`, which:

1. Uses Ubuntu 24.04.
2. Uses JDK 17.
3. Uses `android-actions/setup-android@v4` with command-line tools 20.0 (`14742923`) instead of the older v3 setup shown in the failing log.
4. Installs only the required Android 35 platform and build-tools 35.0.0.
5. Uses Gradle 8.11.1 through `gradle/actions/setup-gradle@v6`.
6. Builds `:app:assembleDebug` and uploads the APK as a workflow artifact.

No MoneyFlow application feature code was intentionally changed in this build-only update.
