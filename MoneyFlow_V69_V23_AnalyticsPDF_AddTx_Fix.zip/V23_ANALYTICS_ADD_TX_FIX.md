MoneyFlow V23 - Analytics Full Export + Add Transaction Default Fix

Changes are isolated and appended to index.html; existing transaction/cloud/sign-out logic is not replaced.

1. Analytics
- Replaces the compact analytics PNG export with a full-length analytics report image.
- Includes donut/category breakdown, totals, Today vs Yesterday, six-month Monthly Comparison, maximum expense/credit categories, highest single expense details, and Category Ranking.
- Adds Export PDF · Share option.
- PDF is generated as multi-page A4 pages from the complete analytics report and saved using the existing AndroidFile export path.

2. Add Transaction
- Restores the tested default when opening Add Transaction: Type = Credit.
- Date remains today.
- Amount/category/payment mode remain neutral placeholders.
- Selecting Credit or Expense rebuilds the corresponding type-specific amount/category options.
- Existing save/cloud/profile logic is untouched.

Build version: 33.0 / versionCode 33.
