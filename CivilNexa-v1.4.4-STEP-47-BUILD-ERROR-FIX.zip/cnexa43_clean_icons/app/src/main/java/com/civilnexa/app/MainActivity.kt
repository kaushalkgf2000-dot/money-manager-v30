package com.civilnexa.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF07051A)
private val Surface = Color(0xFF12102A)
private val Surface2 = Color(0xFF181437)
private val Purple = Color(0xFF8B4DFF)
private val Purple2 = Color(0xFFC18BFF)
private val Orange = Color(0xFFFF8A32)
private val Green = Color(0xFF45D483)
private val Red = Color(0xFFFF5C6C)
private val White = Color(0xFFF7F5FF)
private val Muted = Color(0xFFB8B2CC)
private val GlassBorder = Color(0xFF6D55A8).copy(alpha = 0.42f)
private val GlassGlow = Color(0xFF8B4DFF).copy(alpha = 0.12f)

private data class Question(val text: String, val options: List<String>, val answer: Int, val difficulty: String = "Medium", val negativeMarks: Double = 0.25)
private data class TestResult(
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val timeTakenSeconds: Int,
    val totalSeconds: Int
) {
    val attempted: Int get() = correct + wrong
    val marks: Double get() = correct * 4.0 - wrong * 0.25
    val totalQuestions: Int get() = correct + wrong + skipped
    val totalMarks: Int get() = totalQuestions * 4
    val accuracy: Int get() = if (attempted == 0) 0 else (correct * 100 / attempted)
}

private val demoQuestions = listOf(
    Question("The unit of normal stress is:", listOf("N", "N/m²", "N·m", "Pa·s"), 1),
    Question("For a simply supported beam with UDL over the full span, maximum bending moment occurs at:", listOf("Support A", "Midspan", "Support B", "Quarter span"), 1),
    Question("The relation between load, shear force and bending moment is represented by:", listOf("dV/dx = -w", "dM/dx = V", "Both A and B", "Neither"), 2),
    Question("Poisson's ratio is the ratio of:", listOf("Lateral strain to longitudinal strain", "Stress to strain", "Shear stress to shear strain", "Load to area"), 0),
    Question("The SI unit of Young's modulus is:", listOf("N", "N/m", "N/m²", "m/N"), 2),
    Question("A material that undergoes large plastic deformation before failure is generally called:", listOf("Brittle", "Ductile", "Elastic", "Rigid"), 1),
    Question("The centroid of a rectangle lies at:", listOf("One corner", "The midpoint of its diagonal", "One-third height", "The base"), 1),
    Question("Bernoulli's equation is based on conservation of:", listOf("Mass only", "Momentum only", "Energy", "Temperature"), 2),
    Question("Specific gravity is the ratio of density of a substance to:", listOf("Density of air", "Density of water", "Unit weight of soil", "Viscosity of water"), 1),
    Question("The primary purpose of a foundation is to:", listOf("Increase building height", "Transfer load safely to soil", "Reduce concrete strength", "Increase dead load"), 1)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CivilNexaApp() }
    }
}

@Composable
fun CivilNexaApp() {
    val backStack = remember { mutableStateListOf("home") }
    val screen = backStack.last()
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedSubject by remember { mutableStateOf("Strength of Materials") }
    var selectedChapter by remember { mutableStateOf("Simple Stress & Strain") }
    var selectedTopic by remember { mutableStateOf("Introduction") }
    var testResult by remember { mutableStateOf(TestResult(0, 0, demoQuestions.size, 0, 180)) }
    var showTestExitConfirm by remember { mutableStateOf(false) }

    fun navigate(target: String) {
        if (backStack.lastOrNull() != target) backStack.add(target)
    }

    fun navigateRoot(target: String) {
        backStack.clear()
        backStack.add("home")
        if (target != "home") backStack.add(target)
    }

    fun goBack() {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.lastIndex)
        }
        // Root tab selection must always reflect the screen actually visible after Back.
        // This prevents Study/Tests/etc. from remaining highlighted after returning Home.
    }

    // Keep the global bottom-navigation highlight synchronized with the actual root route.
    // Nested routes intentionally preserve the current root context until they are popped.
    LaunchedEffect(screen) {
        when (screen) {
            "home" -> selectedTab = 0
            "study", "chapters", "chapter", "topic" -> selectedTab = 1
            "tests", "test", "result" -> selectedTab = 2
            "pyq" -> selectedTab = 2
            "progress" -> selectedTab = 3
            "profile" -> selectedTab = 4
        }
    }

    // Single app-wide back dispatcher: every nested screen unwinds one level at a time.
    // At Home (root) the handler is disabled so Android performs the normal app-exit action.
    BackHandler(enabled = screen == "test" || backStack.size > 1) {
        if (screen == "test") {
            showTestExitConfirm = true
        } else {
            goBack()
        }
    }
    if (showTestExitConfirm) {
        AlertDialog(
            onDismissRequest = { showTestExitConfirm = false },
            title = { Text("Exit Test?", color = White) },
            text = { Text("Your current answers are saved. You can resume this test later.", color = Muted) },
            confirmButton = {
                TextButton(onClick = { showTestExitConfirm = false; goBack() }) { Text("Exit", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { showTestExitConfirm = false }) { Text("Stay", color = Purple2) }
            },
            containerColor = Surface2
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Surface)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (screen) {
                        "home" -> Home { target -> navigateRoot(target) }
                        "study" -> Study(
                            onBack = { goBack() },
                            onSubject = { selectedSubject = it; navigate("chapters") }
                        )
                        "chapters" -> Chapters(
                            subject = selectedSubject,
                            onBack = { goBack() },
                            onChapter = { selectedChapter = it; navigate("chapter") }
                        )
                        "chapter" -> ChapterContents(
                            subject = selectedSubject,
                            chapter = selectedChapter,
                            onBack = { goBack() },
                            onTopic = { selectedTopic = it; navigate("topic") },
                            onTest = { navigate("test") }
                        )
                        "topic" -> TopicDetail(
                            subject = selectedSubject,
                            chapter = selectedChapter,
                            topic = selectedTopic,
                            onBack = { goBack() },
                            onTopicNavigate = { selectedTopic = it }
                        )
                        "tests" -> Tests(onBack = { goBack() }, onStart = { navigate("test") })
                        "pyq" -> Pyq(onBack = { goBack() })
                        "progress" -> Progress(onBack = { goBack() })
                        "profile" -> Profile(onBack = { goBack() })
                        "test" -> LiveTest(
                            onExit = { showTestExitConfirm = true },
                            onSubmit = { result -> testResult = result; navigate("result") }
                        )
                        "result" -> Result(result = testResult, onBack = { goBack() }, onBackToTests = {
                            while (backStack.size > 2 && backStack.last() != "tests") { backStack.removeAt(backStack.lastIndex) }
                            if (backStack.lastOrNull() != "tests") { navigateRoot("tests") }
                        })
                    }
                }
                // GLOBAL BOTTOM NAVIGATION: root screens ONLY.
                // Never render it inside a nested Study flow, Live Test, or Result.
                // This explicit allow-list prevents the Home/Study/Tests/Progress/Profile
                // bar from leaking into child screens even when the back stack changes.
                val rootScreens = setOf("home", "tests", "pyq", "progress", "profile")
                val nestedScreens = setOf("study", "chapters", "chapter", "topic", "test", "result")
                val showBottomBar = screen in rootScreens && screen !in nestedScreens
                if (showBottomBar) {
                    BottomBar(selectedTab) { tab ->
                        selectedTab = tab
                        navigateRoot(listOf("home", "study", "tests", "progress", "profile")[tab])
                    }
                }
            }
        }
    }
}

@Composable
private fun Top(title: String, back: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Back", tint = White) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = White)
            Text("CivilNexa", color = Purple2, fontSize = 11.sp)
        }
        action?.invoke()
    }
}

@Composable
private fun Home(go: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF0D0924), Bg))).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(com.civilnexa.app.R.drawable.civilnexa_icon),
                    contentDescription = "CivilNexa",
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("CivilNexa", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                    Text("Your Study. Your Success.", color = Purple2, fontSize = 11.sp)
                }
                Box(
                    Modifier.size(40.dp).background(GlassGlow, RoundedCornerShape(14.dp)).border(1.dp, GlassBorder, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.NotificationsNone, "Notifications", tint = Purple2) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Welcome back, Kumar 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
            Text("Let’s prepare for your next target.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            SearchField("Search topics, subjects...") { }
            Spacer(Modifier.height(18.dp))
            Text("Quick Actions", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("Study Material", Icons.Default.MenuBook, Purple2, Modifier.weight(1f)) { go("study") }
                ActionCard("Test Series", Icons.Default.Quiz, Color(0xFF55D7C8), Modifier.weight(1f)) { go("tests") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("PYQ Center", Icons.Default.Description, Orange, Modifier.weight(1f)) { go("pyq") }
                ActionCard("Mock Test", Icons.Default.Computer, Color(0xFF58A6FF), Modifier.weight(1f)) { go("tests") }
            }
            Section("Continue Learning")
            CardBox("Strength of Materials", "Simple Stress & Strain • 65% complete", Icons.Default.MenuBook)
            Section("Performance Snapshot")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("68%", "Progress", Purple2, Modifier.weight(1f))
                StatCard("73%", "Accuracy", Green, Modifier.weight(1f))
                StatCard("48", "Tests", Orange, Modifier.weight(1f))
            }
            Section("Recommended")
            CardBox("Practice SFD & BMD", "Improve weak topics with focused questions", Icons.Default.TrendingUp) { go("tests") }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.82f)),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Study(onBack: () -> Unit, onSubject: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) }
    val filtered = CivilNexaContentRepository.subjects.filter { it.name.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        Top("Study Material", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SearchField("Search subjects...", query) { query = it }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("All Subjects") })
                    FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Semester Wise") })
                }
                Spacer(Modifier.height(10.dp))
                Text("Civil Engineering Subjects", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Structured for chapter-wise learning, practice and PYQs", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            items(filtered) { subject ->
                val avg = subject.chapters.map { it.progress }.average().takeIf { !it.isNaN() }?.toInt() ?: 0
                SubjectMaterialCard(subject.name, subject.chapters.size, avg) { onSubject(subject.name) }
            }
        }
    }
}

@Composable
private fun SubjectGlyph(name: String, modifier: Modifier = Modifier) {
    // STEP 42.4 — TRUE vector subject artwork.
    // No screenshot crops, bitmap subject screenshots, or reference-sheet images.
    val accent = when (name) {
        "Strength of Materials" -> Color(0xFFFF8A32)
        "Fluid Mechanics" -> Color(0xFF42A5FF)
        "Surveying" -> Color(0xFF55E39A)
        "Soil Mechanics" -> Color(0xFFFFA84A)
        "RCC Design" -> Color(0xFFD966FF)
        "Highway Engineering" -> Color(0xFF5BA8FF)
        "Railways" -> Color(0xFFE46CFF)
        "Bridges & Tunnels" -> Color(0xFF55D8C8)
        "Irrigation & Water Supply" -> Color(0xFF4DD8FF)
        "Waste Water System" -> Color(0xFF8C82FF)
        "Building Construction" -> Color(0xFFFFA044)
        "Environmental Engineering" -> Color(0xFF61DE99)
        "Geotechnical Engineering" -> Color(0xFFB58CFF)
        "Construction Management" -> Color(0xFFFFB84D)
        "Estimation & Costing" -> Color(0xFF56A9FF)
        "Engineering Mathematics" -> Color(0xFFB66CFF)
        else -> Purple2
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = (w * 0.050f).coerceAtLeast(2.0f)
        fun line(a: Offset, b: Offset, width: Float = sw) {
            drawLine(accent.copy(alpha = 0.12f), a, b, width * 2.35f, StrokeCap.Round)
            drawLine(accent, a, b, width, StrokeCap.Round)
        }
        fun poly(points: List<Offset>, width: Float = sw) {
            for (i in 0 until points.lastIndex) line(points[i], points[i + 1], width)
        }
        fun rr(l: Float, t: Float, r: Float, b: Float, radius: Float, width: Float = sw) {
            val size = androidx.compose.ui.geometry.Size(r - l, b - t)
            val topLeft = Offset(l, t)
            drawRoundRect(accent.copy(alpha = 0.10f), topLeft, size,
                androidx.compose.ui.geometry.CornerRadius(radius, radius), style = Stroke(width * 2.0f))
            drawRoundRect(accent, topLeft, size,
                androidx.compose.ui.geometry.CornerRadius(radius, radius), style = Stroke(width))
        }
        fun glowCircle(center: Offset, radius: Float, width: Float = sw) {
            drawCircle(accent.copy(alpha = 0.10f), radius, center, style = Stroke(width * 2.0f))
            drawCircle(accent, radius, center, style = Stroke(width))
        }
        when (name) {
            "Strength of Materials" -> {
                // STYLE 8 — dedicated vector 3D I-beam.
                // Deliberately NOT a crop/screenshot: the artwork is reconstructed from
                // geometric paths so it remains sharp at every density.
                fun filled(points: List<Offset>, fill: Color, stroke: Color = accent, width: Float = sw*.55f) {
                    val p = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        for (pt in points.drop(1)) lineTo(pt.x, pt.y)
                        close()
                    }
                    drawPath(p, fill)
                    drawPath(p, stroke, style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                val glow = accent.copy(alpha = .18f)
                // extrusion / shadow behind the beam
                filled(listOf(
                    Offset(w*.22f,h*.25f), Offset(w*.80f,h*.25f), Offset(w*.74f,h*.35f),
                    Offset(w*.61f,h*.37f), Offset(w*.61f,h*.70f), Offset(w*.75f,h*.74f),
                    Offset(w*.69f,h*.84f), Offset(w*.31f,h*.84f), Offset(w*.25f,h*.74f),
                    Offset(w*.39f,h*.70f), Offset(w*.39f,h*.37f), Offset(w*.28f,h*.35f)
                ), glow, glow, sw*.9f)
                // top flange — trapezoidal 3D face
                filled(listOf(
                    Offset(w*.24f,h*.20f), Offset(w*.79f,h*.20f),
                    Offset(w*.69f,h*.31f), Offset(w*.32f,h*.31f)
                ), accent.copy(alpha=.28f), accent, sw*.7f)
                // top flange highlight
                filled(listOf(
                    Offset(w*.27f,h*.20f), Offset(w*.76f,h*.20f),
                    Offset(w*.67f,h*.26f), Offset(w*.34f,h*.26f)
                ), accent.copy(alpha=.70f), accent.copy(alpha=.95f), sw*.45f)
                // central web
                filled(listOf(
                    Offset(w*.39f,h*.29f), Offset(w*.61f,h*.29f),
                    Offset(w*.61f,h*.72f), Offset(w*.39f,h*.72f)
                ), accent.copy(alpha=.34f), accent, sw*.65f)
                // web highlight edge
                line(Offset(w*.43f,h*.33f), Offset(w*.43f,h*.68f), sw*.45f)
                // lower flange
                filled(listOf(
                    Offset(w*.31f,h*.70f), Offset(w*.69f,h*.70f),
                    Offset(w*.78f,h*.80f), Offset(w*.22f,h*.80f)
                ), accent.copy(alpha=.28f), accent, sw*.7f)
                filled(listOf(
                    Offset(w*.28f,h*.77f), Offset(w*.72f,h*.77f),
                    Offset(w*.68f,h*.82f), Offset(w*.32f,h*.82f)
                ), accent.copy(alpha=.62f), accent.copy(alpha=.95f), sw*.42f)
            }
            "Fluid Mechanics" -> {
                val p = Path().apply {
                    moveTo(w*.50f,h*.08f)
                    cubicTo(w*.25f,h*.36f,w*.28f,h*.62f,w*.50f,h*.84f)
                    cubicTo(w*.72f,h*.62f,w*.75f,h*.36f,w*.50f,h*.08f)
                }
                drawPath(p, accent.copy(alpha=.16f), style=Stroke(sw*3f, cap=StrokeCap.Round, join=StrokeJoin.Round))
                drawPath(p, accent, style=Stroke(sw, cap=StrokeCap.Round, join=StrokeJoin.Round))
                poly(listOf(Offset(w*.10f,h*.76f),Offset(w*.27f,h*.67f),Offset(w*.43f,h*.76f),Offset(w*.59f,h*.67f),Offset(w*.76f,h*.76f),Offset(w*.90f,h*.68f)), sw*.75f)
            }
            "Surveying" -> {
                // Total-station silhouette with tripod.
                rr(w*.25f,h*.20f,w*.75f,h*.55f,w*.08f,sw*.85f)
                glowCircle(Offset(w*.50f,h*.38f), w*.14f, sw*.75f)
                line(Offset(w*.50f,h*.10f),Offset(w*.50f,h*.20f),sw*.8f)
                line(Offset(w*.50f,h*.55f),Offset(w*.31f,h*.82f),sw*.8f)
                line(Offset(w*.50f,h*.55f),Offset(w*.50f,h*.84f),sw*.8f)
                line(Offset(w*.50f,h*.55f),Offset(w*.69f,h*.82f),sw*.8f)
                line(Offset(w*.23f,h*.86f),Offset(w*.77f,h*.86f),sw*.85f)
            }
            "Soil Mechanics" -> {
                // Layered soil strata with a small rock/ground profile.
                poly(listOf(Offset(w*.16f,h*.28f),Offset(w*.38f,h*.20f),Offset(w*.58f,h*.27f),Offset(w*.84f,h*.18f)),sw*.85f)
                poly(listOf(Offset(w*.16f,h*.43f),Offset(w*.38f,h*.35f),Offset(w*.58f,h*.42f),Offset(w*.84f,h*.34f)),sw*.8f)
                poly(listOf(Offset(w*.16f,h*.58f),Offset(w*.38f,h*.50f),Offset(w*.58f,h*.57f),Offset(w*.84f,h*.49f)),sw*.8f)
                poly(listOf(Offset(w*.16f,h*.73f),Offset(w*.38f,h*.65f),Offset(w*.58f,h*.72f),Offset(w*.84f,h*.64f)),sw*.8f)
                glowCircle(Offset(w*.66f,h*.20f),w*.055f,sw*.6f)
            }
            "RCC Design" -> {
                // Reinforced concrete frame: columns, beams and rebar grid.
                rr(w*.19f,h*.17f,w*.81f,h*.82f,w*.035f,sw*.8f)
                line(Offset(w*.33f,h*.18f),Offset(w*.33f,h*.81f),sw*.75f)
                line(Offset(w*.52f,h*.18f),Offset(w*.52f,h*.81f),sw*.75f)
                line(Offset(w*.70f,h*.18f),Offset(w*.70f,h*.81f),sw*.75f)
                line(Offset(w*.19f,h*.37f),Offset(w*.81f,h*.37f),sw*.75f)
                line(Offset(w*.19f,h*.59f),Offset(w*.81f,h*.59f),sw*.75f)
            }
            "Highway Engineering" -> {
                // Perspective road with lane divider.
                poly(listOf(Offset(w*.14f,h*.86f),Offset(w*.42f,h*.12f)),sw*1.15f)
                poly(listOf(Offset(w*.86f,h*.86f),Offset(w*.58f,h*.12f)),sw*1.15f)
                line(Offset(w*.50f,h*.17f),Offset(w*.50f,h*.32f),sw*.65f)
                line(Offset(w*.50f,h*.42f),Offset(w*.50f,h*.57f),sw*.65f)
                line(Offset(w*.50f,h*.67f),Offset(w*.50f,h*.82f),sw*.65f)
            }
            "Railways" -> {
                // Train front + rails.
                rr(w*.29f,h*.12f,w*.71f,h*.61f,w*.09f,sw*.9f)
                rr(w*.39f,h*.23f,w*.61f,h*.39f,w*.025f,sw*.65f)
                glowCircle(Offset(w*.40f,h*.53f),w*.045f,sw*.55f)
                glowCircle(Offset(w*.60f,h*.53f),w*.045f,sw*.55f)
                line(Offset(w*.34f,h*.67f),Offset(w*.66f,h*.67f),sw*.8f)
                line(Offset(w*.38f,h*.70f),Offset(w*.28f,h*.88f),sw*.7f)
                line(Offset(w*.62f,h*.70f),Offset(w*.72f,h*.88f),sw*.7f)
            }
            "Bridges & Tunnels" -> {
                line(Offset(w*.12f,h*.27f),Offset(w*.88f,h*.27f),sw*.8f)
                line(Offset(w*.20f,h*.27f),Offset(w*.20f,h*.78f),sw*.8f)
                line(Offset(w*.80f,h*.27f),Offset(w*.80f,h*.78f),sw*.8f)
                val arch=Path().apply{moveTo(w*.20f,h*.76f);quadraticTo(w*.50f,h*.25f,w*.80f,h*.76f)}
                drawPath(arch,accent.copy(alpha=.16f),style=Stroke(sw*3f,cap=StrokeCap.Round))
                drawPath(arch,accent,style=Stroke(sw,cap=StrokeCap.Round))
                line(Offset(w*.12f,h*.82f),Offset(w*.88f,h*.82f),sw*.7f)
            }
            "Irrigation & Water Supply" -> {
                // Reservoir/dam face and water line.
                line(Offset(w*.18f,h*.25f),Offset(w*.82f,h*.25f),sw*.8f)
                line(Offset(w*.27f,h*.25f),Offset(w*.27f,h*.70f),sw*.75f)
                line(Offset(w*.50f,h*.25f),Offset(w*.50f,h*.70f),sw*.75f)
                line(Offset(w*.73f,h*.25f),Offset(w*.73f,h*.70f),sw*.75f)
                line(Offset(w*.15f,h*.70f),Offset(w*.85f,h*.70f),sw*.85f)
                poly(listOf(Offset(w*.18f,h*.80f),Offset(w*.32f,h*.74f),Offset(w*.46f,h*.80f),Offset(w*.60f,h*.74f),Offset(w*.74f,h*.80f),Offset(w*.86f,h*.75f)),sw*.65f)
            }
            "Waste Water System" -> {
                // Circular treatment tank / flow symbol.
                glowCircle(Offset(w*.50f,h*.44f),w*.28f,sw*.75f)
                line(Offset(w*.24f,h*.44f),Offset(w*.76f,h*.44f),sw*.55f)
                line(Offset(w*.50f,h*.16f),Offset(w*.50f,h*.72f),sw*.55f)
                drawCircle(accent,w*.055f,Offset(w*.50f,h*.44f))
                poly(listOf(Offset(w*.28f,h*.79f),Offset(w*.50f,h*.73f),Offset(w*.72f,h*.79f)),sw*.75f)
            }
            "Building Construction" -> {
                // Two-building skyline / elevation.
                poly(listOf(Offset(w*.16f,h*.82f),Offset(w*.16f,h*.31f),Offset(w*.39f,h*.20f),Offset(w*.39f,h*.82f)),sw*.8f)
                poly(listOf(Offset(w*.45f,h*.82f),Offset(w*.45f,h*.40f),Offset(w*.78f,h*.27f),Offset(w*.78f,h*.82f)),sw*.8f)
                line(Offset(w*.23f,h*.43f),Offset(w*.32f,h*.39f),sw*.55f)
                line(Offset(w*.23f,h*.57f),Offset(w*.32f,h*.53f),sw*.55f)
                line(Offset(w*.52f,h*.51f),Offset(w*.67f,h*.45f),sw*.55f)
                line(Offset(w*.52f,h*.64f),Offset(w*.67f,h*.58f),sw*.55f)
                line(Offset(w*.12f,h*.84f),Offset(w*.84f,h*.84f),sw*.7f)
            }
            "Environmental Engineering" -> {
                val leaf=Path().apply{moveTo(w*.25f,h*.72f);quadraticTo(w*.20f,h*.28f,w*.61f,h*.17f);quadraticTo(w*.73f,h*.54f,w*.25f,h*.72f)}
                drawPath(leaf,accent.copy(alpha=.16f),style=Stroke(sw*3f,cap=StrokeCap.Round))
                drawPath(leaf,accent,style=Stroke(sw,cap=StrokeCap.Round))
                line(Offset(w*.27f,h*.69f),Offset(w*.57f,h*.37f),sw*.7f)
                glowCircle(Offset(w*.70f,h*.67f),w*.13f,sw*.7f)
                line(Offset(w*.70f,h*.51f),Offset(w*.70f,h*.83f),sw*.6f)
            }
            "Geotechnical Engineering" -> {
                // Soil profile + bore/retaining section.
                line(Offset(w*.18f,h*.25f),Offset(w*.82f,h*.25f),sw*.8f)
                line(Offset(w*.29f,h*.25f),Offset(w*.29f,h*.61f),sw*.75f)
                line(Offset(w*.71f,h*.25f),Offset(w*.71f,h*.61f),sw*.75f)
                line(Offset(w*.22f,h*.64f),Offset(w*.78f,h*.64f),sw*.8f)
                line(Offset(w*.18f,h*.75f),Offset(w*.82f,h*.75f),sw*.7f)
                line(Offset(w*.26f,h*.84f),Offset(w*.74f,h*.84f),sw*.7f)
            }
            "Construction Management" -> {
                // Hard-hat outline + baseline.
                val hat=Path().apply{moveTo(w*.24f,h*.47f);quadraticTo(w*.30f,h*.19f,w*.50f,h*.15f);quadraticTo(w*.70f,h*.19f,w*.76f,h*.47f)}
                drawPath(hat,accent.copy(alpha=.16f),style=Stroke(sw*3f,cap=StrokeCap.Round))
                drawPath(hat,accent,style=Stroke(sw,cap=StrokeCap.Round))
                line(Offset(w*.18f,h*.48f),Offset(w*.82f,h*.48f),sw*.95f)
                line(Offset(w*.34f,h*.69f),Offset(w*.66f,h*.69f),sw*.75f)
                line(Offset(w*.41f,h*.82f),Offset(w*.59f,h*.82f),sw*.7f)
            }
            "Estimation & Costing" -> {
                rr(w*.22f,h*.13f,w*.78f,h*.85f,w*.055f,sw*.7f)
                line(Offset(w*.32f,h*.30f),Offset(w*.68f,h*.30f),sw*.6f)
                for (r in 0..2) for (c in 0..2) {
                    drawCircle(accent.copy(alpha=.18f),w*.055f,Offset(w*(.34f+c*.16f),h*(.48f+r*.13f)))
                    drawCircle(accent,w*.027f,Offset(w*(.34f+c*.16f),h*(.48f+r*.13f)))
                }
            }
            "Engineering Mathematics" -> {
                // Sigma-style mathematical mark.
                poly(listOf(Offset(w*.72f,h*.18f),Offset(w*.28f,h*.18f),Offset(w*.52f,h*.50f),Offset(w*.28f,h*.82f),Offset(w*.72f,h*.82f)),sw*.9f)
                line(Offset(w*.22f,h*.86f),Offset(w*.78f,h*.86f),sw*.55f)
            }
        }
    }
}

@Composable
private fun SubjectMaterialCard(name: String, chapterCount: Int, progress: Int, onClick: () -> Unit) {
    val accent = when (name) {
        "Strength of Materials" -> Color(0xFFFF8A32)
        "Fluid Mechanics" -> Color(0xFF39A9FF)
        "Surveying" -> Color(0xFF55E39A)
        "Soil Mechanics" -> Color(0xFFFFA84A)
        "RCC Design" -> Color(0xFFD06BFF)
        "Highway Engineering" -> Color(0xFF5BA8FF)
        "Railways" -> Color(0xFFE46CFF)
        "Bridges & Tunnels" -> Color(0xFF55D8C8)
        "Irrigation & Water Supply" -> Color(0xFF4DD8FF)
        "Waste Water System" -> Color(0xFF8C82FF)
        "Building Construction" -> Color(0xFFFFA044)
        "Environmental Engineering" -> Color(0xFF61DE99)
        "Geotechnical Engineering" -> Color(0xFFB58CFF)
        "Construction Management" -> Color(0xFFFFB84D)
        "Estimation & Costing" -> Color(0xFF56A9FF)
        "Engineering Mathematics" -> Color(0xFFB66CFF)
        else -> Purple2
    }
    val data = CivilNexaContentRepository.subject(name)
    val completedChapters = data?.chapters?.count { it.progress >= 100 } ?: 0
    val status = when {
        progress >= 100 -> "Completed"
        progress > 0 -> "In Progress"
        else -> "Not Started"
    }

    Card(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.2.dp, accent.copy(alpha = 0.68f))
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = 0.065f),
                            accent.copy(alpha = 0.055f),
                            Color(0xFF100D26).copy(alpha = 0.88f)
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.075f), RoundedCornerShape(28.dp))
                .padding(horizontal = 18.dp, vertical = 20.dp)
        ) {
            val phone = maxWidth <= 420.dp
            val iconBox = if (phone) 104.dp else 124.dp
            val artwork = if (phone) 76.dp else 92.dp
            val gap = if (phone) 14.dp else 18.dp
            val titleSize = if (phone) 22.sp else 23.sp
            val metaSize = if (phone) 13.sp else 13.sp
            val chevronSize = if (phone) 28.dp else 30.dp
            val badgeWidth = if (phone) 112.dp else 122.dp

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                // Dedicated, non-squeezable artwork rail.
                Box(
                    Modifier
                        .size(iconBox)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.055f),
                                    accent.copy(alpha = 0.16f),
                                    accent.copy(alpha = 0.055f),
                                    Color.Transparent
                                )
                            ),
                            RoundedCornerShape(if (phone) 22.dp else 24.dp)
                        )
                        .border(1.4.dp, accent.copy(alpha = 0.78f), RoundedCornerShape(if (phone) 22.dp else 24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .matchParentSize()
                            .padding(if (phone) 5.dp else 6.dp)
                            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(if (phone) 18.dp else 19.dp))
                    )
                    SubjectGlyph(name, Modifier.size(artwork))
                }

                Spacer(Modifier.width(gap))

                Box(Modifier.weight(1f)) {
                    // The title and badge share the same top row like the locked reference.
                    // Title always gets a real two-line area; it is never reduced to a
                    // one-character ellipsis by the badge or chevron.
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(end = chevronSize + 10.dp)
                    ) {
                        Box(Modifier.fillMaxWidth().heightIn(min = 58.dp)) {
                            Text(
                                name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(end = badgeWidth + 8.dp),
                                color = White,
                                fontWeight = FontWeight.Bold,
                                fontSize = titleSize,
                                lineHeight = if (phone) 27.sp else 28.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                modifier = Modifier.align(Alignment.TopEnd),
                                color = accent.copy(alpha = 0.085f),
                                shape = RoundedCornerShape(18.dp),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.76f))
                            ) {
                                Text(
                                    status,
                                    color = accent,
                                    fontSize = if (phone) 11.sp else 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }

                        Spacer(Modifier.height(if (phone) 7.dp else 10.dp))

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(if (phone) 8.dp else 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            MetaItem(Icons.Default.MenuBook, "$chapterCount Chapters", metaSize)
                            MetaItem(Icons.Default.Description, "Notes", metaSize)
                            MetaItem(Icons.Default.Functions, "Formulas", metaSize)
                        }
                        Spacer(Modifier.height(7.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(if (phone) 8.dp else 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            MetaItem(Icons.Default.CheckCircleOutline, "Practice", metaSize)
                            MetaItem(Icons.Default.Description, "PYQs", metaSize)
                        }

                        Spacer(Modifier.height(if (phone) 16.dp else 18.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f).height(8.dp)) {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(accent.copy(alpha = 0.10f))
                                )
                                Box(
                                    Modifier
                                        .fillMaxWidth(progress.coerceIn(0, 100) / 100f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.72f), accent)))
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "$progress%",
                                color = accent,
                                fontSize = if (phone) 19.sp else 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(
                            "$completedChapters / $chapterCount Chapters  •  $progress% Completed",
                            color = Muted,
                            fontSize = if (phone) 12.sp else 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = "Open $name",
                        tint = White.copy(alpha = 0.94f),
                        modifier = Modifier
                            .size(chevronSize)
                            .align(Alignment.CenterEnd)
                    )
                }
            }
        }
    }
}

@Composable
private fun MetaItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, size: androidx.compose.ui.unit.TextUnit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Purple2, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = Muted, fontSize = size, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Chapters(subject: String, onBack: () -> Unit, onChapter: (String) -> Unit) {
    val data = CivilNexaContentRepository.subject(subject)
    val avg = data?.chapters?.map { it.progress }?.average()?.takeIf { !it.isNaN() }?.toInt() ?: 0
    Column(Modifier.fillMaxSize()) {
        Top(subject, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                CardBox("Overall Progress", "$avg% • Chapter progress tracked automatically", Icons.Default.Insights)
                Section("Chapters")
            }
            itemsIndexed(data?.chapters ?: emptyList()) { index, ch ->
                val status = when { ch.progress >= 100 -> "Completed"; ch.progress > 0 -> "In Progress"; else -> "Not Started" }
                val tint = when { ch.progress >= 100 -> Green; ch.progress > 0 -> Orange; else -> Muted }
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onChapter(ch.name) },
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).background(Purple.copy(alpha = 0.12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Text(String.format("%02d", index + 1), color = Purple2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(ch.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("${ch.topics.size} topics • ${ch.progress}% complete", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(progress = { ch.progress / 100f }, Modifier.fillMaxWidth().height(4.dp), color = tint, trackColor = Surface2)
                            Text(status, color = tint, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterContents(subject: String, chapter: String, onBack: () -> Unit, onTopic: (String) -> Unit, onTest: () -> Unit) {
    val data = CivilNexaContentRepository.chapter(subject, chapter)
    Column(Modifier.fillMaxSize()) {
        Top(chapter, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text(subject, color = Purple2, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                CardBox("Chapter Progress", "${data?.topics?.size ?: 0} topics • ${data?.progress ?: 0}% complete", Icons.Default.Insights)
                Section("Topics")
            }
            itemsIndexed(data?.topics ?: emptyList()) { index, topic ->
                val status = if (topic.completed) "Completed" else if (index == 0) "In Progress" else "Not Started"
                val tint = if (topic.completed) Green else if (index == 0) Purple2 else Muted
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onTopic(topic.name) },
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Purple.copy(alpha = 0.12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Text(String.format("%02d", index + 1), color = Purple2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(topic.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Notes • Formulas • Concepts • Diagrams • Practice • PYQs", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(status, color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
            item {
                Section("Chapter Actions")
                CardBox("Chapter Test", "Timed test • review • auto-evaluation", Icons.Default.Timer, onTest)
                CardBox("Previous Year Questions", "Mapped by exam • year • chapter • topic", Icons.Default.History)
            }
        }
    }
}

@Composable
private fun TopicDetail(
    subject: String,
    chapter: String,
    topic: String,
    onBack: () -> Unit,
    onTopicNavigate: (String) -> Unit
) {
    val chapterData = CivilNexaContentRepository.chapter(subject, chapter)
    val data = CivilNexaContentRepository.topic(subject, chapter, topic)
    val topics = chapterData?.topics ?: emptyList()
    val topicIndex = topics.indexOfFirst { it.name == topic }.coerceAtLeast(0)
    var tab by remember(topic) { mutableIntStateOf(0) }
    var bookmarked by remember(topic) { mutableStateOf(false) }
    var notePage by remember(topic) { mutableIntStateOf(1) }
    val labels = listOf("Notes", "Formulas", "Concepts", "Diagrams", "Practice", "PYQs")
    val moduleIcons = listOf(
        Icons.Default.Description, Icons.Default.Functions, Icons.Default.Lightbulb,
        Icons.Default.AccountTree, Icons.Default.Quiz, Icons.Default.History
    )
    val previousTopic = topics.getOrNull(topicIndex - 1)?.name
    val nextTopic = topics.getOrNull(topicIndex + 1)?.name

    Column(Modifier.fillMaxSize()) {
        Top(topic, onBack, action = {
            IconButton(onClick = { bookmarked = !bookmarked }) {
                Icon(
                    if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    "Bookmark topic",
                    tint = if (bookmarked) Orange else White
                )
            }
        })

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            item {
                Text(subject, color = Purple2, fontSize = 12.sp)
                Text(chapter, color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))

                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp)
                                    .background(Purple.copy(alpha = 0.14f), RoundedCornerShape(15.dp))
                                    .border(1.dp, GlassBorder, RoundedCornerShape(15.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MenuBook, null, tint = Purple2, modifier = Modifier.size(26.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Topic Learning", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("6 learning modules • distraction-free study", color = Muted, fontSize = 11.sp)
                            }
                            Text("${topicIndex + 1}/${topics.size.coerceAtLeast(1)}", color = Purple2, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { if (data?.completed == true) 1f else 0.25f },
                            Modifier.fillMaxWidth().height(5.dp),
                            color = Purple, trackColor = Surface2
                        )
                        Text(if (data?.completed == true) "Completed" else "In Progress", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    labels.forEachIndexed { i, label ->
                        FilterChip(
                            selected = tab == i,
                            onClick = { tab = i },
                            label = { Text(label, fontSize = 11.sp) },
                            leadingIcon = { Icon(moduleIcons[i], null, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            item {
                when (tab) {
                    0 -> {
                        Section("Handwritten Notes")
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Surface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Description, null, tint = Purple2)
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Page $notePage of 3", color = White, fontWeight = FontWeight.Bold)
                                        Text("Read-only • Zoom • Bookmark • No Download", color = Muted, fontSize = 10.sp)
                                    }
                                    IconButton(onClick = { notePage = (notePage - 1).coerceAtLeast(1) }, enabled = notePage > 1) {
                                        Icon(Icons.Default.ChevronLeft, "Previous page", tint = if (notePage > 1) White else Muted)
                                    }
                                    IconButton(onClick = { notePage = (notePage + 1).coerceAtMost(3) }, enabled = notePage < 3) {
                                        Icon(Icons.Default.ChevronRight, "Next page", tint = if (notePage < 3) White else Muted)
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                Box(
                                    Modifier.fillMaxWidth().height(300.dp)
                                        .background(Color(0xFFEEEAF8), RoundedCornerShape(14.dp))
                                        .border(1.dp, GlassBorder, RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(22.dp)) {
                                        Icon(Icons.Default.EditNote, null, tint = Color(0xFF4B3D70), modifier = Modifier.size(44.dp))
                                        Spacer(Modifier.height(12.dp))
                                        Text("Handwritten Note • $topic", color = Color(0xFF211B38), fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(10.dp))
                                        Text(data?.notes ?: "Notes coming soon.", color = Color(0xFF3E3658), fontSize = 14.sp, lineHeight = 21.sp)
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                LinearProgressIndicator(
                                    progress = { notePage.toFloat() / 3f },
                                    Modifier.fillMaxWidth(), color = Purple, trackColor = Surface2
                                )
                            }
                        }
                    }
                    1 -> {
                        Section("Formula Library")
                        ContentCard("Formula", data?.formula ?: "Formula not available.")
                        Spacer(Modifier.height(10.dp))
                        CardBox("Symbols & Units", "Meaning • symbols • units • sign convention • application", Icons.Default.Straighten)
                        CardBox("Worked Example", "Given → Formula → Substitution → Final answer", Icons.Default.Calculate)
                    }
                    2 -> {
                        Section("Important Concepts")
                        ContentCard("Core Concept", data?.concept ?: "Concept not available.")
                        Spacer(Modifier.height(10.dp))
                        CardBox("Key Points", "Definition • assumptions • units • sign convention • application", Icons.Default.Lightbulb)
                    }
                    3 -> {
                        Section("Engineering Diagrams")
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Surface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Diagram / Figure", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Spacer(Modifier.height(12.dp))
                                Box(
                                    Modifier.fillMaxWidth().height(220.dp)
                                        .background(Bg, RoundedCornerShape(16.dp))
                                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.AccountTree, null, tint = Purple2, modifier = Modifier.size(56.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text("Topic diagram area", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Labeled engineering figure", color = Muted, fontSize = 11.sp)
                                    }
                                }
                                data?.let {
                                    if (it.diagrams.isNotEmpty()) {
                                        Spacer(Modifier.height(10.dp))
                                        it.diagrams.forEach { description ->
                                            Text("• $description", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    4 -> {
                        Section("Practice Questions")
                        CardBox("Topic Practice", "MCQ • Numerical • Theory • Easy / Medium / Hard", Icons.Default.Quiz)
                        data?.practice?.forEachIndexed { i, q ->
                            CardBox("Q.${i + 1}", q, Icons.Default.Quiz)
                        }
                    }
                    5 -> {
                        Section("Previous Year Questions")
                        data?.pyq?.forEach { q ->
                            CardBox(q, "Exam → Year → Subject → Chapter → Topic", Icons.Default.History)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { previousTopic?.let(onTopicNavigate) }, enabled = previousTopic != null) {
                        Icon(Icons.Default.ArrowBack, "Previous topic", tint = if (previousTopic != null) White else Muted)
                    }
                    IconButton(onClick = { bookmarked = !bookmarked }) {
                        Icon(if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = if (bookmarked) Orange else White)
                    }
                    IconButton(onClick = { nextTopic?.let(onTopicNavigate) }, enabled = nextTopic != null) {
                        Icon(Icons.Default.ArrowForward, "Next topic", tint = if (nextTopic != null) White else Muted)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ContentCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Text(body, color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
        }
    }
}

@Composable
private fun Tests(onBack: () -> Unit, onStart: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val hasResume = remember { hasSavedTest(context) }
    val tests = listOf("Chapter Test • Strength of Materials", "Topic Test • SFD & BMD", "PYQ Test • Civil Engineering", "Full Mock Test • SSC JE", "Full Mock Test • RRB JE", "Custom Mock Test")
    val filtered = tests.filter { it.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Top("Test Series", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                SearchField("Search tests...", query) { query = it }
                Spacer(Modifier.height(8.dp))
                if (hasResume) {
                    CardBox("Resume Full Mock Test 01", "Saved answers • remaining time • marked questions restored", Icons.Default.PlayArrow, onStart)
                }
            }
            items(filtered) { test -> CardBox(test, "10 Questions • 40 Marks • 10 min • −0.25 marking", if (test.contains("Mock", true)) Icons.Default.Star else Icons.Default.Quiz, onStart) }
        }
    }
}

@Composable
private fun Pyq(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val papers = listOf("SSC JE Civil • 2024", "SSC JE Civil • 2023", "SSC JE Civil • 2022", "RRB JE Civil • Previous Papers", "UPSSSC JE Civil • Previous Papers")
    Column(Modifier.fillMaxSize()) {
        Top("PYQ Center", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item { SearchField("Search year, exam, subject...", query) { query = it }; Spacer(Modifier.height(8.dp)) }
            items(papers.filter { it.contains(query, true) }) { paper -> CardBox(paper, "Exam → Year → Subject → Chapter → Topic", Icons.Default.Description) }
        }
    }
}

@Composable
private fun Progress(onBack: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val prefs = remember(refresh) { context.getSharedPreferences(HISTORY_PREFS, Context.MODE_PRIVATE) }
    val attempts = prefs.getInt("attempts", 0)
    val correct = prefs.getInt("correct", 0)
    val wrong = prefs.getInt("wrong", 0)
    val skipped = prefs.getInt("skipped", 0)
    val answered = correct + wrong
    val accuracy = if (answered == 0) 0 else correct * 100 / answered
    val totalQuestions = correct + wrong + skipped
    val avgScore = if (attempts == 0) 0 else (prefs.getFloat("last_marks", 0f) * 100f / prefs.getInt("last_total", 1).coerceAtLeast(1)).toInt()
    val studyProgress = CivilNexaContentRepository.subjects.flatMap { it.chapters }.map { it.progress }.average().toInt()
    val weak = if (accuracy < 70) "Accuracy needs improvement" else "Keep strengthening your weakest topics"

    Column(Modifier.fillMaxSize()) {
        Top("Progress", onBack, action = {
            IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, "Refresh", tint = Purple2) }
        })
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Overall Content Progress", "$studyProgress% • Based on chapter content", Icons.Default.Insights)
                CardBox("Tests Attempted", "$attempts • Live test history", Icons.Default.Quiz)
                CardBox("Questions Solved", "$answered • $correct correct • $wrong wrong", Icons.Default.CheckCircle)
                CardBox("Accuracy", "$accuracy% • ${if (totalQuestions == 0) "No tests yet" else "$answered/$totalQuestions attempted"}", Icons.Default.BarChart)
                CardBox("Latest Score", "$avgScore% • Calculated from latest submitted test", Icons.Default.EmojiEvents)
                Section("Subject Performance")
                CivilNexaContentRepository.subjects.forEach { subject ->
                    val progress = subject.chapters.map { it.progress }.average().toInt()
                    CardBox(subject.name, "$progress% content progress • ${subject.chapters.size} chapters", Icons.Default.MenuBook)
                }
                Section("Weak Areas")
                CardBox("Performance Focus", weak, Icons.Default.Warning)
                Section("Study Time")
                val totalMinutes = prefs.getLong("time", 0L) / 60
                CardBox("Test Time Recorded", "${totalMinutes / 60}h ${totalMinutes % 60}m across submitted tests", Icons.Default.Schedule)
            }
        }
    }
}

@Composable
private fun Profile(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Profile", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Kumar", "Civil Engineering Aspirant • CivilNexa Learner", Icons.Default.Person)
                Section("Account")
                listOf("Edit Profile", "Change Password", "Linked Email & Mobile", "Bookmarks", "Test History").forEach { CardBox(it, "Open", Icons.Default.ChevronRight) }
                Section("Preferences")
                CardBox("Language", "English • Default", Icons.Default.Language)
                CardBox("Notification Settings", "Manage alerts", Icons.Default.Notifications)
                CardBox("Clear Cache", "Manage local storage", Icons.Default.Delete)
                CardBox("Sync Data", "Cloud sync when connected", Icons.Default.CloudSync)
            }
        }
    }
}

private const val TEST_PREFS = "civilnexa_test_state"
private const val TEST_ID = "mock_01"
private const val HISTORY_PREFS = "civilnexa_test_history"

private data class SavedTestState(
    val current: Int = 0,
    val remaining: Int = 180,
    val answers: Map<Int, Int> = emptyMap(),
    val marked: Set<Int> = emptySet()
)

private fun loadSavedTest(context: Context): SavedTestState {
    val prefs = context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE)
    if (!prefs.getBoolean("has_$TEST_ID", false)) return SavedTestState()
    val answers = prefs.getString("answers_$TEST_ID", "")!!.split(',')
        .filter { it.contains(":") }
        .mapNotNull { pair ->
            val parts = pair.split(":")
            if (parts.size == 2) parts[0].toIntOrNull()?.let { q -> parts[1].toIntOrNull()?.let { a -> q to a } } else null
        }.toMap()
    val marked = prefs.getString("marked_$TEST_ID", "")!!.split(',')
        .mapNotNull { it.toIntOrNull() }.toSet()
    return SavedTestState(
        current = prefs.getInt("current_$TEST_ID", 0).coerceIn(0, demoQuestions.lastIndex),
        remaining = prefs.getInt("remaining_$TEST_ID", 180).coerceIn(0, 180),
        answers = answers,
        marked = marked
    )
}

private fun saveTestState(context: Context, state: SavedTestState) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean("has_$TEST_ID", true)
        .putInt("current_$TEST_ID", state.current)
        .putInt("remaining_$TEST_ID", state.remaining)
        .putString("answers_$TEST_ID", state.answers.entries.joinToString(",") { "${it.key}:${it.value}" })
        .putString("marked_$TEST_ID", state.marked.joinToString(","))
        .apply()
}

private fun clearSavedTest(context: Context) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .remove("has_$TEST_ID")
        .remove("current_$TEST_ID")
        .remove("remaining_$TEST_ID")
        .remove("answers_$TEST_ID")
        .remove("marked_$TEST_ID")
        .apply()
}

private fun hasSavedTest(context: Context): Boolean =
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).getBoolean("has_$TEST_ID", false)

private fun recordTestResult(context: Context, result: TestResult) {
    val prefs = context.getSharedPreferences(HISTORY_PREFS, Context.MODE_PRIVATE)
    val attempts = prefs.getInt("attempts", 0) + 1
    val totalCorrect = prefs.getInt("correct", 0) + result.correct
    val totalWrong = prefs.getInt("wrong", 0) + result.wrong
    val totalSkipped = prefs.getInt("skipped", 0) + result.skipped
    val totalTime = prefs.getLong("time", 0L) + result.timeTakenSeconds
    prefs.edit()
        .putInt("attempts", attempts)
        .putInt("correct", totalCorrect)
        .putInt("wrong", totalWrong)
        .putInt("skipped", totalSkipped)
        .putLong("time", totalTime)
        .putFloat("last_marks", result.marks.toFloat())
        .putInt("last_total", result.totalMarks)
        .apply()
}

@Composable
private fun LiveTest(onExit: () -> Unit, onSubmit: (TestResult) -> Unit) {
    val context = LocalContext.current
    val totalSeconds = 3 * 60
    val saved = remember { loadSavedTest(context) }
    var current by remember { mutableIntStateOf(saved.current) }
    var remaining by remember { mutableIntStateOf(saved.remaining) }
    var showPalette by remember { mutableStateOf(false) }
    var showCalculator by remember { mutableStateOf(false) }
    var showSubmitConfirm by remember { mutableStateOf(false) }
    var answers by remember { mutableStateOf(saved.answers) }
    var marked by remember { mutableStateOf(saved.marked) }
    var submitted by remember { mutableStateOf(false) }

    fun buildResult(): TestResult {
        val correct = answers.count { (q, a) -> demoQuestions[q].answer == a }
        val wrong = answers.size - correct
        val skipped = demoQuestions.size - answers.size
        return TestResult(correct, wrong, skipped, totalSeconds - remaining, totalSeconds)
    }

    fun submit() {
        if (!submitted) {
            submitted = true
            val finalResult = buildResult()
            recordTestResult(context, finalResult)
            clearSavedTest(context)
            onSubmit(finalResult)
        }
    }

    LaunchedEffect(remaining, submitted) {
        if (!submitted && remaining > 0) {
            delay(1000)
            remaining--
        } else if (!submitted && remaining == 0) {
            submit()
        }
    }

    LaunchedEffect(current, remaining, answers, marked, submitted) {
        if (!submitted) {
            saveTestState(context, SavedTestState(current, remaining, answers, marked))
        }
    }

    val q = demoQuestions[current]
    val answeredCount = answers.size
    val paletteStatus = if (marked.contains(current)) "Marked for review" else if (answers.containsKey(current)) "Answered" else "Not answered"

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExit) { Icon(Icons.Default.Close, "Exit", tint = White) }
                Column(Modifier.weight(1f)) {
                    Text("Full Mock Test 01", color = White, fontWeight = FontWeight.Bold)
                    Text("SSC JE Civil", color = Purple2, fontSize = 11.sp)
                    Text("⏱ ${formatTime(remaining)}   •   Q ${current + 1}/${demoQuestions.size}", color = if (remaining <= 30) Red else Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { showPalette = true }) { Text("Questions", color = Purple2) }
            }
            LinearProgressIndicator(progress = { (current + 1f) / demoQuestions.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Purple)
            LazyColumn(Modifier.weight(1f).padding(16.dp)) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(onClick = {}, label = { Text("Q.${current + 1}") })
                        AssistChip(onClick = {}, label = { Text("MCQ") })
                        AssistChip(onClick = {}, label = { Text(q.difficulty) })
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("$answeredCount/${demoQuestions.size} answered   •   Negative marking: −${q.negativeMarks}", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    CardBox("Question", q.text, Icons.Default.Quiz)
                    q.options.forEachIndexed { index, option ->
                        OptionCard(option, selected = answers[current] == index) { answers = answers + (current to index) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { current = (current - 1).coerceAtLeast(0) },
                    enabled = current > 0
                ) {
                    Icon(Icons.Default.ChevronLeft, "Previous question", tint = if (current > 0) White else Muted, modifier = Modifier.size(30.dp))
                }
                IconButton(
                    onClick = {
                        marked = if (marked.contains(current)) marked - current else marked + current
                        saveTestState(context, SavedTestState(current, remaining, answers, marked))
                    }
                ) {
                    Icon(
                        if (marked.contains(current)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        "Save question",
                        tint = if (marked.contains(current)) Orange else White,
                        modifier = Modifier.size(27.dp)
                    )
                }
                IconButton(onClick = { showCalculator = true }) {
                    Icon(Icons.Default.Calculate, "Calculator", tint = Purple2, modifier = Modifier.size(28.dp))
                }
                IconButton(
                    onClick = { if (current < demoQuestions.lastIndex) current++ else showSubmitConfirm = true }
                ) {
                    Icon(
                        if (current == demoQuestions.lastIndex) Icons.Default.Done else Icons.Default.ChevronRight,
                        if (current == demoQuestions.lastIndex) "Submit test" else "Next question",
                        tint = Purple2,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
        if (showPalette) QuestionPalette(current, answers, marked, onClose = { showPalette = false }) { current = it; showPalette = false }
        if (showCalculator) CalculatorOverlay { showCalculator = false }
        if (showSubmitConfirm) SubmitConfirmation(
            answered = answers.size,
            marked = marked.size,
            total = demoQuestions.size,
            onCancel = { showSubmitConfirm = false },
            onSubmit = { showSubmitConfirm = false; submit() }
        )
    }
}

private fun formatTime(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)

@Composable
private fun QuestionPalette(current: Int, answers: Map<Int, Int>, marked: Set<Int>, onClose: () -> Unit, onQuestion: (Int) -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.BottomCenter) {
        Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Questions", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${answers.size}/${demoQuestions.size} answered", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("● Answered ${answers.size}", color = Green, fontSize = 11.sp)
                    Text("★ Marked ${marked.size}", color = Orange, fontSize = 11.sp)
                    Text("○ Not Answered ${demoQuestions.size - answers.size}", color = Muted, fontSize = 11.sp)
                    Text("● Current ${current + 1}", color = Purple, fontSize = 11.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    PaletteStat(answers.size.toString(), "Answered", Green)
                    PaletteStat(marked.size.toString(), "Marked", Orange)
                    PaletteStat((demoQuestions.size - answers.size).toString(), "Not Answered", Muted)
                    PaletteStat(demoQuestions.size.toString(), "Total", White)
                }
                Spacer(Modifier.height(12.dp))
                for (start in 0 until demoQuestions.size step 5) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in start until minOf(start + 5, demoQuestions.size)) {
                            val bg = when {
                                i == current -> Purple
                                marked.contains(i) -> Orange
                                answers.containsKey(i) -> Green
                                else -> Surface
                            }
                            Box(Modifier.size(48.dp).background(bg, RoundedCornerShape(12.dp)).clickable { onQuestion(i) }, contentAlignment = Alignment.Center) {
                                Text("${i + 1}", color = White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun SubmitConfirmation(answered: Int, marked: Int, total: Int, onCancel: () -> Unit, onSubmit: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.68f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(24.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Submit Test?", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Answered: $answered/$total\nMarked for review: $marked\nUnanswered: ${total - answered}", color = Muted)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(onClick = onSubmit, modifier = Modifier.weight(1f)) { Text("Submit Test") }
                }
            }
        }
    }
}

@Composable
private fun PaletteStat(value: String, label: String, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(min = 54.dp)) {
        Text(value, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun CalculatorOverlay(onClose: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "C", "+")
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(22.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Calculator", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) } }
                Box(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(14.dp)).padding(16.dp)) { Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) { Text(expression.ifEmpty { "0" }, color = Muted); Text(result.ifEmpty { "" }, color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.height(12.dp))
                keys.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            Button(onClick = { if (key == "C") { expression = ""; result = "" } else { expression += key; result = "" } }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (key == "C") Color(0xFF5A1C2A) else Surface)) { Text(key) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Button(onClick = { result = simpleCalculate(expression) }, modifier = Modifier.fillMaxWidth()) { Text("=") }
            }
        }
    }
}

private fun simpleCalculate(raw: String): String {
    return try {
        val expression = raw.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "")
        if (expression.isBlank()) return ""
        val parser = ExpressionParser(expression)
        val value = parser.parse()
        if (!value.isFinite()) "Error" else "%.4f".format(value).trimEnd('0').trimEnd('.')
    } catch (_: Exception) {
        "Error"
    }
}

private class ExpressionParser(private val input: String) {
    private var pos = 0

    fun parse(): Double {
        val value = parseExpression()
        if (pos != input.length) throw IllegalArgumentException("Unexpected input")
        return value
    }

    private fun parseExpression(): Double {
        var value = parseTerm()
        while (pos < input.length) {
            value = when (input[pos]) {
                '+' -> { pos++; value + parseTerm() }
                '-' -> { pos++; value - parseTerm() }
                else -> return value
            }
        }
        return value
    }

    private fun parseTerm(): Double {
        var value = parseFactor()
        while (pos < input.length) {
            value = when (input[pos]) {
                '*' -> { pos++; value * parseFactor() }
                '/' -> { pos++; val divisor = parseFactor(); if (divisor == 0.0) throw ArithmeticException(); value / divisor }
                else -> return value
            }
        }
        return value
    }

    private fun parseFactor(): Double {
        if (pos >= input.length) throw IllegalArgumentException("Missing number")
        if (input[pos] == '+') { pos++; return parseFactor() }
        if (input[pos] == '-') { pos++; return -parseFactor() }
        if (input[pos] == '(') {
            pos++
            val value = parseExpression()
            if (pos >= input.length || input[pos] != ')') throw IllegalArgumentException("Missing )")
            pos++
            return value
        }
        val start = pos
        var dots = 0
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
            if (input[pos] == '.') dots++
            if (dots > 1) throw IllegalArgumentException("Invalid number")
            pos++
        }
        if (start == pos) throw IllegalArgumentException("Number expected")
        return input.substring(start, pos).toDouble()
    }
}


@Composable
private fun Result(result: TestResult, onBack: () -> Unit, onBackToTests: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Test Result", onBack)
        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${result.marks} / ${result.totalMarks} Marks", color = White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                        Text("${result.accuracy}% Accuracy", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${result.attempted}/${result.totalQuestions} Questions Attempted", color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Time: ${formatTime(result.timeTakenSeconds)}", color = Muted, fontSize = 12.sp)
                    }
                }
                CardBox("Correct", "${result.correct}", Icons.Default.CheckCircle)
                CardBox("Wrong", "${result.wrong} • Negative marking applied", Icons.Default.Cancel)
                CardBox("Skipped", "${result.skipped}", Icons.Default.RemoveCircleOutline)
                CardBox("Performance", "Result generated from actual answer selections", Icons.Default.BarChart)
                Button(onClick = onBackToTests, modifier = Modifier.fillMaxWidth()) { Text("Back to Tests") }
            }
        }
    }
}

@Composable
private fun SearchField(hint: String, value: String = "", onSearch: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onSearch,
        placeholder = { Text(hint, color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Purple2) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Surface.copy(alpha = 0.55f),
            focusedContainerColor = Surface.copy(alpha = 0.72f),
            unfocusedBorderColor = GlassBorder,
            focusedBorderColor = Purple
        )
    )
}

@Composable
private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier, click: () -> Unit) {
    Card(
        modifier.height(96.dp).clickable { click() },
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(tint.copy(alpha = 0.12f), RoundedCornerShape(15.dp)).border(1.dp, tint.copy(alpha = 0.28f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(27.dp)) }
            Spacer(Modifier.width(10.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun CardBox(title: String, subtitle: String = "", icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.AutoAwesome, click: (() -> Unit)? = null) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).then(if (click != null) Modifier.clickable { click() } else Modifier),
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.84f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Purple.copy(alpha = 0.14f), RoundedCornerShape(14.dp)).border(1.dp, GlassBorder, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Purple2, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); if (subtitle.isNotEmpty()) Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 18.sp) }
            if (click != null) Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun Section(title: String) { Text(title, color = Purple2, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }

@Composable
private fun OptionCard(text: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (selected) Purple.copy(alpha = 0.18f) else Surface.copy(alpha = 0.78f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (selected) Purple else GlassBorder)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Purple2)); Text(text, color = White, fontSize = 15.sp) }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0D0922)) {
        val items = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Quiz, Icons.Default.Insights, Icons.Default.Person)
        val labels = listOf("Home", "Study", "Tests", "Progress", "Profile")
        items.forEachIndexed { i, icon -> NavigationBarItem(selected = i == selected, onClick = { onSelect(i) }, icon = { Icon(icon, null) }, label = { Text(labels[i]) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple2, selectedTextColor = Purple2, indicatorColor = Purple.copy(alpha = 0.16f), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
    }
}
