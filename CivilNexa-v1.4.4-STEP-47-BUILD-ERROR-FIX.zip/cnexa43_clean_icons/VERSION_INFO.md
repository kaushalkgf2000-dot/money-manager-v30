# CivilNexa Version Info

App: CivilNexa
Version: v1.3.4
Version Code: 16
Step: 42.4 — Exact Style-8 Subject Card Refinement
Status: Source-level UI refinement ready for device verification

Changes:
- Removed screenshot/crop-based subject artwork from the subject-card implementation.
- Reworked the 16 subject glyphs as runtime Canvas vector-style artwork.
- Fixed the icon anchor to a consistent 112dp card slot with an 82dp drawing area.
- Fixed title/badge layout so long subject names are not prematurely truncated.
- Refined metadata, progress row, chapter completion row and trailing chevron alignment.
- Preserved the approved dark-purple CivilNexa visual language.
- No chapter-by-chapter content population in this step.


## Step 45
Responsive Subject Card Fix — title/badge/chevron collision removed on narrow screens.


Step 46: Exact reference subject-card responsive/glass polish.
