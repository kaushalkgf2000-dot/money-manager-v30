package com.civilnexa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08051A); private val Card = Color(0xFF12102A); private val Purple = Color(0xFF8B4DFF); private val Purple2 = Color(0xFFB77BFF); private val Orange = Color(0xFFFF8A32); private val White = Color(0xFFF7F5FF); private val Muted = Color(0xFFB8B2CC)

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { CivilNexaApp() } } }

@Composable fun CivilNexaApp() { var tab by remember { mutableStateOf(0) }; var screen by remember { mutableStateOf("home") }; MaterialTheme(colorScheme = darkColorScheme(primary=Purple, background=Bg, surface=Card)) { Surface(Modifier.fillMaxSize(), color=Bg) { Column { Box(Modifier.weight(1f)) { when(screen) { "home" -> Home{screen=it}; "study" -> Study{screen=it}; "tests" -> Tests{screen=it}; "progress" -> Progress(); "profile" -> Profile(); "test" -> LiveTest{screen="result"}; "result" -> Result{screen="tests"}; "pyq" -> Pyq(); else -> Home{screen=it} } }; BottomBar(tab){ tab=it; screen=listOf("home","study","tests","progress","profile")[it] } } } } }

@Composable fun Top(title:String, back:(()->Unit)?=null) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment=Alignment.CenterVertically){ if(back!=null){ IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null,tint=White)} }; Column(Modifier.weight(1f)){ Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold,color=White); Text("CivilNexa",color=Purple2,fontSize=12.sp) } } }
@Composable fun Home(go:(String)->Unit){ LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp)){ item{ Spacer(Modifier.height(12.dp)); Text("Welcome back, Kumar 👋",fontSize=25.sp,fontWeight=FontWeight.Bold,color=White); Text("Let’s prepare for your next target.",color=Muted); Spacer(Modifier.height(18.dp)); Search("Search topics, subjects..."); Spacer(Modifier.height(18.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ Action("Study Material",Icons.Default.MenuBook){go("study")}; Action("Test Series",Icons.Default.Quiz){go("tests")} }; Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ Action("PYQ",Icons.Default.Description){go("pyq")}; Action("Mock Test",Icons.Default.Computer){go("tests")} }; Spacer(Modifier.height(18.dp)); Section("Continue Learning"); CardBox("Strength of Materials","Bending Stress • 65% complete"); Section("Performance"); CardBox("Overall Progress","68% • 48 tests • 73% accuracy"); } } }
@Composable fun Study(go:(String)->Unit){ Top("Study Material"); LazyColumn(Modifier.padding(horizontal=16.dp)){ item{Search("Search subjects, chapters..."); Spacer(Modifier.height(12.dp))}; items(listOf("Engineering Mechanics","Strength of Materials","Fluid Mechanics","Surveying","Building Materials","Concrete Technology","Soil Mechanics","RCC Design","Highway Engineering","Railway Engineering","Bridge Engineering")){ s-> CardBox(s,"Chapter-wise notes • formulas • concepts • practice",{go("test")}) } } }
@Composable fun Tests(go:(String)->Unit){ Top("Test Series"); LazyColumn(Modifier.padding(horizontal=16.dp)){ item{Search("Search tests..."); Spacer(Modifier.height(12.dp))}; items(listOf("Chapter Test • Strength of Materials","Topic Test • SFD & BMD","PYQ Test • Civil Engineering","Full Mock Test • SSC JE","Full Mock Test • RRB JE","Custom Mock Test")){ t-> CardBox(t,"Questions • time • negative marking",{go("test")}) } } }
@Composable fun Progress(){ Top("Progress"); LazyColumn(Modifier.padding(16.dp)){ item{CardBox("Overall Progress","68% completed"); CardBox("Tests Attempted","48 • Average accuracy 73%"); CardBox("Questions Solved","1,245"); Section("Subject Performance"); listOf("Strength of Materials 78%","Fluid Mechanics 65%","Surveying 72%","Soil Mechanics 60%","RCC 80%").forEach{CardBox(it,"Progress tracked automatically")}; Section("Weak Areas"); CardBox("Construction Management","Practice recommended") } } }
@Composable fun Profile(){ Top("Profile"); LazyColumn(Modifier.padding(16.dp)){ item{CardBox("Kumar","Civil Engineering Aspirant • CivilNexa Learner"); Section("Account"); listOf("Edit Profile","Change Password","Linked Email & Mobile","Bookmarks","Test History").forEach{CardBox(it,"Open")}; Section("Preferences"); listOf("Notification Settings","Language • English","Clear Cache","Sync Data").forEach{CardBox(it,"Open")} } } }
@Composable fun Pyq(){ Top("PYQ Center"); LazyColumn(Modifier.padding(16.dp)){ item{Search("Search year, exam, subject..."); Spacer(Modifier.height(12.dp))}; items(listOf("SSC JE Civil • 2024","SSC JE Civil • 2023","SSC JE Civil • 2022","RRB JE Civil • Previous Papers","UPSSSC JE Civil • Previous Papers")){CardBox(it,"Chapter-wise • topic-wise • detailed solutions")} } }
@Composable fun LiveTest(go:(String)->Unit){ Top("Full Mock Test"); Column(Modifier.fillMaxSize().padding(16.dp)){ Text("02:59:39   •   Q 23 / 200",color=White,fontSize=20.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(18.dp)); CardBox("Numerical • Medium","A simply supported beam of span 8 m carries UDL of 15 kN/m."); listOf("60 kN-m","120 kN-m","80 kN-m","160 kN-m").forEach{ Option(it) }; Spacer(Modifier.height(12.dp)); Button(onClick={go("result")},Modifier.fillMaxWidth()){Text("Submit Test")} } }
@Composable fun Result(go:(String)->Unit){ Top("Test Result"); LazyColumn(Modifier.padding(16.dp)){ item{CardBox("176 / 300","58.67% Score • 73.45% Accuracy"); CardBox("Correct / Wrong / Skipped","135 / 49 / 16"); CardBox("Performance","Strength 75% • Fluid 67% • RCC 80%"); Button(onClick={go("tests")},Modifier.fillMaxWidth()){Text("Back to Tests")}; Section("Weak Areas"); CardBox("Construction Management","Practice Now") } } }

@Composable fun Search(h:String){ OutlinedTextField(value="",onValueChange={},placeholder={Text(h,color=Muted)},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true) }
@Composable fun Action(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector,click:()->Unit){ Card(Modifier.width(170.dp).height(90.dp).clickable{click()},colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.Center){Icon(icon,null,tint=Purple2);Text(t,color=White,fontWeight=FontWeight.SemiBold)}} }
@Composable fun CardBox(t:String,sub:String="",click:(()->Unit)?=null){ Card(Modifier.fillMaxWidth().padding(vertical=6.dp).then(if(click!=null) Modifier.clickable{click()} else Modifier),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AutoAwesome,null,tint=Purple2);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(t,color=White,fontWeight=FontWeight.SemiBold,fontSize=16.sp);if(sub.isNotEmpty())Text(sub,color=Muted,fontSize=12.sp)}}; if(click!=null)Icon(Icons.Default.ChevronRight,null,tint=Muted)} }
@Composable fun Section(t:String){Text(t,color=Purple2,fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=16.dp,bottom=4.dp))}
@Composable fun Option(t:String){Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(false,{});Text(t,color=White)}}}
@Composable fun BottomBar(selected:Int,onSelect:(Int)->Unit){NavigationBar(containerColor=Color(0xFF0D0922)){listOf(Icons.Default.Home,Icons.Default.MenuBook,Icons.Default.Quiz,Icons.Default.Insights,Icons.Default.Person).forEachIndexed{i,icon->NavigationBarItem(selected=i==selected,onClick={onSelect(i)},icon={Icon(icon,null)},label={Text(listOf("Home","Study","Tests","Progress","Profile")[i])})}}}
