MoneyFlow V20 – Combined fixes

1. Profile avatars: clearly differentiated Male, Female and Other sets.
2. Profile photo persistence: current Profile/Mode scoped storage, compressed gallery images, and immediate UI refresh.
3. Profile photos remain part of account-scoped cloud profile backup/restore.
4. Analytics Export Image: compatible canvas rounded-rectangle drawing, timestamped PNG filename, native Android save path and browser fallback.
5. Google Drive Sync: no explicit Downloads backup-file export path; BackupBridge no longer exposes exportBackupFile().
6. Existing UID transaction merge, silent auto-sync, manual backup/restore and profile security flows are preserved.
