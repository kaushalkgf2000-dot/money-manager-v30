# MoneyFlow V69 V52 — Profile Workspace / Photo Isolation Fix

Baseline: V51.

## Scope
- Profile photo is canonical per Profile/Mode and is synchronized between the profile object and its per-profile local cache key.
- Home, More, Profile/Account and profile-list avatar surfaces refresh immediately after a photo change or profile switch and use the same active-profile photo source and circular crop rule.
- Before cloud upload, per-profile local photos are synchronized into the profile metadata so each Mode's photo is backed up with that Mode.
- After cloud restore, each restored Mode's photo is synchronized locally and avatar surfaces refresh immediately.
- Profile/Mode switching preserves the selected Mode and schedules the existing cloud sync; all existing Modes remain attached to the signed-in Google account.
- Existing device-local PIN/recovery/biometric security remains excluded from cloud backup.

## Not changed
Transactions, Notes, Calculator, Analytics, PIN implementation, Recovery Code implementation, sign-out backup flow, and existing cloud transport are not intentionally changed.
