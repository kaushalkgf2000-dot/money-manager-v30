# STEP 51 — SUBJECT CARD FINAL REFERENCE FIX

Applied the approved reference layout to the Study Material subject cards.

- Subject names receive the full content rail and render up to two complete lines.
- Removed the `In Progress` badge from subject cards.
- Reduced the subject artwork rail/icon size to give typography more room.
- Kept vector artwork (no screenshot/image crops).
- Preserved premium translucent glassmorphism, subject-wise accent colours, glow, inner highlight and fixed navigation chevron.
- Metadata remains structured in two rows: Chapters/Notes/Formulas and Practice/PYQs.
- Progress percentage and chapter completion remain data-driven.
