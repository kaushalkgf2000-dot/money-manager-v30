# STEP 53 — Test Series Dashboard Rebuild

Base: CivilNexa-v1.5.2 / STEP-52 full Android project.

Implemented only the Test Series destination from the Home dashboard.

## Final structure
- Test Series opens with two tabs:
  1. Chapter by Test
  2. Subject by Test
- Chapter by Test:
  - Subject header first
  - Complete chapter list underneath each subject
  - Each chapter shows available test count, MCQ count, duration and marks
- Subject by Test:
  - Compact subject-wise blocks
  - Subject name, chapter count, test count, available count and total MCQs
- Existing old Test Series list/content was removed from the Test Series screen.
- Quick Start remains available for launching the existing live-test flow.
- Existing Home, Study Material, PYQ Center, Progress, Profile and chapter-tool flows are left intact.
- Existing vector subject-artwork architecture is retained; Soil Mechanics remains a vector layered-soil icon rather than a screenshot crop.

## Packaging rule
This change is made on the full project, not as a standalone HTML prototype.
