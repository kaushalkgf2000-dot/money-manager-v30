# STEP 50 — Subject Card Measurement Fix

## Root cause
The previous card used an overlay title/badge arrangement that reserved an arbitrary end padding. On narrow Android widths this reduced the title's measured width to a tiny value, producing `S`, `F`, `Survey` + broken lines and ellipsized metadata.

## Final layout rule
The card is now measured as three independent rails:

`FIXED ARTWORK RAIL | FLEX CONTENT RAIL | FIXED CHEVRON RAIL`

Inside the content rail:
- Title and status badge are real siblings in a Row.
- Metadata is split into controlled rows to avoid accidental ellipsis.
- Progress and percentage share one row.
- Chapter progress is a dedicated final row.

No screenshot crop or reference-sheet image is used for subject artwork. SubjectGlyph remains vector Canvas artwork.
