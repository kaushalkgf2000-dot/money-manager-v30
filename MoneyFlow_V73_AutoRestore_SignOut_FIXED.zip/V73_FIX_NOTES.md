# Money Flow V73 — Auto Restore + Sign-Out Flow Fix

## Fixed

1. **Existing-user automatic cloud restore**
   - After Firebase/Google authentication, Money Flow still starts the account-scoped Drive restore after ~3 seconds.
   - If the Google Sign-In client session is not available after app restart, the app now reuses the previously authorized Google Drive account saved in `paisaflow_drive/drive_email` and binds the Drive authorization request to the matching device Google account.
   - This removes the dependency on `GoogleSignIn.getLastSignedInAccount()` remaining populated after an app restart and makes automatic restore much more reliable for existing users.

2. **Backup-before-sign-out**
   - Sign Out is now a single flow: tap **Sign Out** → latest Google Drive backup → successful backup → automatic Firebase/Google sign-out.
   - The old second manual confirmation step has been removed.
   - If backup fails, the user remains signed in and can retry.

## Important

- Cloud restore remains account-scoped.
- Local PIN/recovery/security state remains device-local.
- No security credentials are uploaded to Google Drive.
