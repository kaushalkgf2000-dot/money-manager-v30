package com.eduai.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EduAIApp()
        }
    }
}

@androidx.compose.runtime.Composable
fun EduAIApp() {
    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            HomeScreen()
        }
    }
}

@androidx.compose.runtime.Composable
fun HomeScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(Modifier.height(20.dp))

        Text(
            text = "EduAI",
            color = Color.White,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Your Offline AI Study Assistant",
            color = Color(0xFFFFB52E),
            fontSize = 16.sp
        )

        Spacer(Modifier.height(24.dp))

        Text(
            text = "Class 8 • 9 • 10  |  Maths • Science",
            color = Color(0xFFE7E7E7),
            fontSize = 15.sp
        )

        Spacer(Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FeatureButton("📷 Camera", Modifier.weight(1f)) {
                // Camera module will be added in Phase 2.
            }
            FeatureButton("🖼 Gallery", Modifier.weight(1f)) {
                // Gallery module will be added in Phase 2.
            }
        }

        Spacer(Modifier.height(10.dp))

        FeatureButton("⌨ Text Question", Modifier.fillMaxWidth()) {
            // Text input is available below.
        }

        Spacer(Modifier.height(20.dp))

        TextField(
            value = question,
            onValueChange = { question = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask a Maths or Science question…") },
            minLines = 4,
            shape = RoundedCornerShape(18.dp)
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                answer = if (question.isBlank()) {
                    "Please enter a question first."
                } else {
                    OfflineAiPlaceholder.solve(question)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("ASK OFFLINE AI", fontSize = 16.sp)
        }

        Spacer(Modifier.height(20.dp))

        answer?.let {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF151515)
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = it,
                    modifier = Modifier.padding(18.dp),
                    color = Color.White,
                    fontSize = 16.sp
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Text(
            text = "● Offline core",
            color = Color(0xFF9BB56A),
            fontSize = 14.sp
        )
    }
}

@androidx.compose.runtime.Composable
fun FeatureButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(label)
    }
}

/**
 * Temporary adapter used only to verify the UI and project wiring.
 * The real on-device LLM + Math Engine will replace this in the next step.
 */
object OfflineAiPlaceholder {
    fun solve(question: String): String {
        return """
            Offline AI Core connected to the UI.

            Question:
            $question

            Next implementation:
            1. Load the selected on-device language model.
            2. Add the AI abstraction layer.
            3. Add Math Engine routing.
            4. Verify a real offline solution.
        """.trimIndent()
    }
}