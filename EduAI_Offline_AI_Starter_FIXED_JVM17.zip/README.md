# EduAI — Offline Educational AI

Initial Android starter project for an offline-first educational AI assistant.

## Current scope

- Android / Kotlin / Jetpack Compose
- Class 8–10 Maths & Science product direction
- Camera, Gallery and Text input placeholders
- Offline AI abstraction planned
- Math Engine planned
- Science Engine planned
- Future cloud fallback planned

## Phase 1

The first real milestone is:

Text question → on-device model → Math routing → reliable step-by-step answer

The current `OfflineAiPlaceholder` is intentionally not an AI model. It is only a wiring/prototype layer so the UI can be built before the model runtime is integrated.

## Important

The first Gradle sync/build may require internet access to download Android/Compose dependencies. Once the actual model and required runtime assets are bundled/installed, question solving itself is designed to work offline.

## Build fix applied

The Android module now explicitly targets Java 17 for both `javac` and Kotlin.
This fixes the Gradle error:

`Inconsistent JVM-target compatibility detected: compileDebugJavaWithJavac (1.8) and compileDebugKotlin (17)`
