# V25 build workflow fix

The previous GitHub Actions failure happened inside `android-actions/setup-android`, before Gradle or the MoneyFlow app was built. The log showed the action finding the runner's preinstalled `cmdline-tools;12.0`, reporting `Wrong version in preinstalled sdkmanager`, then attempting its own command-line-tools download.

This build-only patch removes that action entirely. GitHub's Ubuntu runner already provides the Android SDK. The workflow now explicitly selects a usable sdkmanager (16.0 when present), installs only the required SDK packages for compileSdk 35, sets JDK 17, and uses Gradle 8.11.1 for AGP 8.9.2.

No MoneyFlow application source files were changed by this patch.

Important: in the GitHub repository, remove/replace any older workflow that still contains `android-actions/setup-android@v3`. If that old workflow remains, GitHub can continue running it and the same Setup Android SDK error will appear.
