PaisaFlow V30 — STEP 15

FINAL SELECTIVE DATE EXPORT FIX

Fixes the repeated export-range issue by making the final export functions read the date inputs directly at click time and use the live `txs` transaction array rendered by the app as the single source of transaction data.

Export pipeline:
Selected From/To -> normalize dates -> filter inclusive range -> determine opening balance from latest transaction before From -> chronological rows -> Withdrawal/Deposit columns -> running balance -> Account Summary -> PDF/XLSX.

PDF and XLSX use the same filtered transaction set and calculation.

No other app functionality is intentionally changed.
