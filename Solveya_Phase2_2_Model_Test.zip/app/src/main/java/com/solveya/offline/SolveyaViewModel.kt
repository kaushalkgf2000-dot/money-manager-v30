package com.solveya.offline

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.solveya.offline.ai.AiModelState
import com.solveya.offline.ai.LiteRtLmEngine
import com.solveya.offline.ai.LocalModelManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SolveyaViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application.applicationContext
    private val engine = LiteRtLmEngine(app)

    private val _modelState = MutableStateFlow<AiModelState>(
        if (LocalModelManager.isInstalled(app)) {
            AiModelState.ModelInstalled
        } else {
            AiModelState.NotConfigured
        }
    )
    val modelState: StateFlow<AiModelState> = _modelState.asStateFlow()

    private val _answer = MutableStateFlow<String?>(null)
    val answer: StateFlow<String?> = _answer.asStateFlow()

    fun importModel(uri: Uri) {
        _modelState.value = AiModelState.Importing
        viewModelScope.launch {
            val result = LocalModelManager.importModel(app, uri)
            _modelState.value = result.fold(
                onSuccess = { AiModelState.ModelInstalled },
                onFailure = {
                    AiModelState.Error(
                        "Model import failed: ${it.message ?: "Unknown error"}"
                    )
                }
            )
        }
    }

    fun initializeModel() {
        _modelState.value = AiModelState.Loading
        viewModelScope.launch {
            val result = engine.initialize()
            _modelState.value = result.fold(
                onSuccess = { AiModelState.Ready },
                onFailure = {
                    AiModelState.Error(
                        "Model initialization failed: ${it.message ?: "Unknown error"}"
                    )
                }
            )
        }
    }

    fun ask(question: String) {
        if (question.isBlank()) return
        _answer.value = "Thinking offline…"
        viewModelScope.launch {
            val result = engine.ask(question)
            _answer.value = result.getOrElse {
                "Offline AI error: ${it.message ?: "Unknown error"}"
            }
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }
}