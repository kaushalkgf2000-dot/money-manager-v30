CivilNexa v1.2.3 — Step 32 Study Material Structure & Icon System
Version code: 6
Content population is intentionally deferred to the final phase.
