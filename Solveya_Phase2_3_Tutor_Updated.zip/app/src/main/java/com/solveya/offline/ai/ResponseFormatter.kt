package com.solveya.offline.ai

/**
 * Converts common model formatting into clean, phone-friendly text.
 * It intentionally does not try to be a full Markdown/LaTeX parser.
 */
object ResponseFormatter {
    fun clean(raw: String): String {
        var text = raw.trim()

        // Remove common response wrappers that are not useful to the student.
        text = text.removePrefix("```text").removePrefix("```markdown").removePrefix("```")
        text = text.removeSuffix("```").trim()

        // Make simple LaTeX math readable without requiring a renderer.
        text = text.replace("\\\\(", "").replace("\\\\)", "")
        text = text.replace("\\\\[", "").replace("\\\\]", "")
        text = text.replace("\\$", "$")
        text = text.replace(Regex("\\$(.*?)\\$", setOf(RegexOption.DOT_MATCHES_ALL))) { it.groupValues[1] }

        // Normalize common Markdown emphasis while preserving readable headings.
        text = text.replace(Regex("\\*\\*(.*?)\\*\\*"), "$1")
        text = text.replace(Regex("__(.*?)__"), "$1")
        text = text.replace(Regex("`([^`]+)`"), "$1")

        // Avoid excessive blank lines from model output.
        text = text.replace(Regex("\\n{3,}"), "\\n\\n").trim()

        return text.ifBlank { "Solveya could not generate an answer." }
    }
}
