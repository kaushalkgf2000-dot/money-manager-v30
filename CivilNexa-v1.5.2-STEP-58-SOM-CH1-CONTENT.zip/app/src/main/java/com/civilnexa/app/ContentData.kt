package com.civilnexa.app

data class TopicContent(
    val name: String,
    val completed: Boolean = false,
    val notes: String,
    val formula: String,
    val concept: String,
    val diagrams: List<String> = emptyList(),
    val practice: List<String>,
    val pyq: List<String>
)

data class ChapterContent(
    val name: String,
    val progress: Int,
    val topics: List<TopicContent>
)

data class SubjectContent(
    val name: String,
    val chapters: List<ChapterContent>
)

object CivilNexaContentRepository {
    private fun chapter(name: String, progress: Int, topics: List<TopicContent>) = ChapterContent(name, progress, topics)
    private fun topic(name: String, notes: String, formula: String, concept: String, diagrams: List<String>, practice: List<String>, pyq: List<String>) =
        TopicContent(name, notes = notes, formula = formula, concept = concept, diagrams = diagrams, practice = practice, pyq = pyq)

    val subjects = listOf(
        SubjectContent("Strength of Materials", listOf(
            chapter("Simple Stress & Strain", 0, listOf(
                topic(
                    "Introduction",
                    "Strength of Materials studies how engineering members carry loads and how they resist deformation and failure. When an external load acts on a body, internal resisting forces develop inside the material. Stress describes this internal resistance per unit area, while strain describes the resulting deformation relative to the original dimension.\n\nThese ideas form the foundation for analysing bars, beams, shafts and structural members. In simple axial loading, the first quantities to identify are load P, original area A, original length L and change in length ΔL.",
                    "σ = P/A\nε = ΔL/L",
                    "Stress is the internal resisting force per unit area. Strain is deformation per unit original dimension. Stress has units of Pa or N/m²; strain is dimensionless. The direction of loading determines whether the member is mainly in tension, compression or shear.",
                    listOf("Axially loaded bar showing P, A, L and elongation ΔL", "Basic load → internal resistance → deformation sequence"),
                    listOf("A bar carries an axial load P over area A. Which quantity represents internal resistance per unit area?", "A 2 m bar elongates by 1 mm. Find its longitudinal strain."),
                    listOf("PYQ-aligned: Direct stress and strain identification", "PYQ-aligned: Longitudinal strain calculation")
                ),
                topic(
                    "Basic Terminology",
                    "Before solving a strength problem, identify the external load, resisting section, cross-sectional area, original dimension and deformation. External load is applied from outside; internal resistance develops within the member. Original length is measured before loading, and deformation is the change produced by loading.\n\nFor an axial member, the most common symbols are P for axial load, A for cross-sectional area, L for original length and ΔL for change in length.",
                    "ΔL = L_final − L_original\nA = cross-sectional area",
                    "Always use the original dimension when defining engineering strain. Keep units consistent before substitution.",
                    listOf("Loaded prismatic bar with labelled P, A and L", "Original and deformed length comparison"),
                    listOf("Which dimension is used in engineering strain: original or final length?", "List the four basic quantities needed for a simple axial stress calculation."),
                    listOf("PYQ-aligned: Basic SOM terminology", "PYQ-aligned: Original length and deformation")
                ),
                topic(
                    "Stress",
                    "Stress is the intensity of internal resistance developed in a material under external loading. For a uniformly distributed axial load over a prismatic section, normal stress is obtained by dividing the axial load by the cross-sectional area.\n\nA smaller area produces greater stress for the same load. Normal stress acts perpendicular to the resisting cross-section. The SI unit is pascal (Pa); in engineering calculations MPa and N/mm² are commonly used, with 1 MPa = 1 N/mm².",
                    "σ = P/A\n1 MPa = 1 N/mm²",
                    "For the same axial load, stress is inversely proportional to area. The simple formula assumes the load is axial and the stress distribution is treated as uniform over the section.",
                    listOf("Axial tensile load on a uniform bar", "Stress distribution over a cross-section"),
                    listOf("A 20 kN load acts on a 200 mm² area. Calculate normal stress.", "If the area is doubled while load remains constant, what happens to stress?"),
                    listOf("PYQ-aligned: Direct stress numerical", "PYQ-aligned: Effect of cross-sectional area on stress")
                ),
                topic(
                    "Types of Stress",
                    "Stress is classified according to the type and direction of loading. Tensile stress develops when a member is pulled and tends to increase its length. Compressive stress develops when a member is pushed and tends to shorten. Shear stress acts tangentially to a resisting area and tends to produce sliding. Bearing or crushing stress develops over a contact area, such as between a bolt and a plate.\n\nThermal stress can also develop when temperature change produces restrained deformation.",
                    "σ_t = P/A\nσ_c = P/A\nτ = V/A (average shear stress)",
                    "The direction of internal force relative to the area is the key to identifying stress type: perpendicular loading gives normal stress; tangential loading gives shear stress.",
                    listOf("Tension and compression comparison", "Shear loading on a block", "Bearing contact between pin and plate"),
                    listOf("Identify the stress in a bar being pulled axially.", "Which stress acts tangentially to the resisting area?"),
                    listOf("PYQ-aligned: Classification of stress", "PYQ-aligned: Tensile, compressive and shear stress")
                ),
                topic(
                    "Strain",
                    "Strain measures deformation relative to the original dimension. For an axially loaded member, longitudinal strain is the change in length divided by the original length. Tensile strain is positive when elongation is taken as positive; compressive strain is negative under the usual sign convention.\n\nStrain is a ratio of two lengths, so it has no physical unit. It is often written as mm/mm or expressed as a percentage or microstrain.",
                    "ε = ΔL/L\nPercentage strain = ε × 100",
                    "Stress describes loading intensity inside the material; strain describes the resulting deformation intensity. Never use the final length in the denominator for engineering strain.",
                    listOf("Original and elongated bar", "Original and shortened bar"),
                    listOf("A 1.5 m bar elongates by 0.75 mm. Find longitudinal strain.", "Why is strain dimensionless?"),
                    listOf("PYQ-aligned: Longitudinal strain calculation", "PYQ-aligned: Unit and nature of strain")
                ),
                topic(
                    "Types of Strain",
                    "Strain may be classified according to the deformation being measured. Longitudinal strain is the change in length divided by original length. Lateral strain is the change in a transverse dimension divided by its original value. Shear strain measures angular distortion. Volumetric strain measures change in volume relative to original volume.\n\nDifferent loading conditions can produce more than one type of strain at the same time.",
                    "ε = ΔL/L\nε_lateral = Δd/d\nγ ≈ θ (small angle)\nε_v = ΔV/V",
                    "Longitudinal and lateral strains are linear strains; shear strain is associated with angular distortion; volumetric strain represents overall volume change.",
                    listOf("Axial elongation with lateral contraction", "Shear deformation and angle change", "Volume before and after loading"),
                    listOf("Which strain represents angular distortion?", "A cube changes volume from V to V + ΔV. Write its volumetric strain."),
                    listOf("PYQ-aligned: Types of strain", "PYQ-aligned: Volumetric and shear strain")
                ),
                topic(
                    "Elasticity",
                    "Elasticity is the property by which a material tends to regain its original shape and dimensions after the deforming load is removed, provided the material has not been taken beyond its elastic range. Engineering design uses this behaviour to keep working members within acceptable limits.\n\nElastic behaviour does not mean that deformation is zero. A material can deform significantly and still recover if the deformation remains within the elastic range.",
                    "Within elastic range: removal of load → recovery toward original dimensions",
                    "Elasticity concerns recovery after unloading. Stiffness is different: stiffness describes resistance to deformation and is related to elastic modulus for a given material and geometry.",
                    listOf("Loading and unloading of an elastic specimen", "Recoverable deformation"),
                    listOf("What happens to an elastic specimen after the load is removed within the elastic range?", "Does elastic behaviour mean zero deformation under load?"),
                    listOf("PYQ-aligned: Definition of elasticity", "PYQ-aligned: Elastic behaviour")
                ),
                topic(
                    "Plasticity",
                    "Plasticity is the property that allows a material to undergo permanent deformation after the stress exceeds its elastic range. When the load is removed after plastic deformation, the material does not return completely to its original dimensions.\n\nPlastic deformation is important in metal forming, but structural members are generally designed to avoid undesirable permanent deformation under service loads.",
                    "Permanent deformation = residual deformation after unloading",
                    "Elastic deformation is recoverable; plastic deformation is permanent. The transition depends on the material and its stress–strain behaviour.",
                    listOf("Elastic versus permanent deformation after unloading", "Stress–strain curve showing elastic and plastic regions"),
                    listOf("Which type of deformation remains after unloading beyond the elastic range?", "Differentiate elastic and plastic deformation in one statement."),
                    listOf("PYQ-aligned: Elasticity versus plasticity", "PYQ-aligned: Permanent deformation")
                ),
                topic(
                    "Elastic Limit",
                    "The elastic limit is the greatest stress level up to which the material can return essentially to its original dimensions after removal of the load. If loading goes beyond this limit, permanent deformation can remain.\n\nThe exact location of the elastic limit depends on the material and its measured stress–strain response. For exam problems, distinguish elastic limit from proportional limit: the proportional limit refers specifically to the range where stress is directly proportional to strain.",
                    "Elastic limit: maximum stress for essentially complete recovery after unloading",
                    "Elastic limit and proportional limit are related but not identical concepts. Do not treat them as interchangeable in a definition-based question.",
                    listOf("Stress–strain curve with proportional and elastic regions", "Loading and unloading near elastic limit"),
                    listOf("What is meant by elastic limit?", "How does elastic limit differ from proportional limit?"),
                    listOf("PYQ-aligned: Elastic limit definition", "PYQ-aligned: Proportional limit versus elastic limit")
                ),
                topic(
                    "Hooke's Law",
                    "Hooke's law states that, within the proportional limit, stress is directly proportional to strain. For a uniaxial elastic material, this relation is written using Young's modulus E. The law is valid only within the range in which the proportional relationship holds.\n\nHooke's law provides the basic connection between load intensity and deformation for many linear-elastic engineering calculations.",
                    "σ ∝ ε\nσ = Eε\nE = σ/ε",
                    "Young's modulus is the slope of the linear stress–strain relation in the applicable elastic range. A higher E indicates greater resistance to elastic axial strain for the same stress.",
                    listOf("Linear stress–strain segment", "Slope representing Young's modulus E"),
                    listOf("If stress doubles within the proportional range, what happens to strain?", "A material has E = 200 GPa and stress = 100 MPa. Find strain."),
                    listOf("PYQ-aligned: Hooke's law", "PYQ-aligned: Young's modulus numerical")
                ),
                topic(
                    "Stress-Strain Relationship",
                    "A stress–strain diagram shows how a material responds as loading increases. The initial linear portion represents proportional behaviour. Within the elastic region, unloading can restore the original dimensions. Beyond the elastic range, plastic deformation develops and permanent strain may remain after unloading.\n\nThe exact curve and characteristic points depend on the material. Always interpret a diagram according to the material behaviour shown rather than memorising one curve for every material.",
                    "Slope of linear elastic portion = E\nε = ΔL/L",
                    "The stress–strain curve is a material response curve. Stress is plotted on the vertical axis and strain on the horizontal axis. The slope of the initial straight portion gives Young's modulus for uniaxial loading.",
                    listOf("Typical engineering stress–strain curve", "Elastic and plastic regions"),
                    listOf("What does the slope of the initial linear portion represent?", "Which axis normally represents strain on a stress–strain curve?"),
                    listOf("PYQ-aligned: Stress–strain curve interpretation", "PYQ-aligned: Slope and Young's modulus")
                ),
                topic(
                    "Important Engineering Concepts",
                    "For quick problem solving, remember the core distinctions: load is an external action, stress is internal resistance per unit area, strain is deformation per unit original dimension, elasticity is recoverability, and plasticity is permanent deformation.\n\nFor the same axial load, increasing area reduces normal stress. For the same material in the linear elastic range, increasing stress increases strain in direct proportion. Unit consistency is essential: N with mm² gives N/mm², which is MPa.",
                    "σ = P/A\nε = ΔL/L\nE = σ/ε",
                    "Most introductory problems can be solved by first identifying load, area, deformation and original dimension, then selecting the appropriate relation. Check units before the final answer.",
                    listOf("Load–stress–strain concept map", "Unit conversion map: N/mm² ↔ MPa"),
                    listOf("For fixed P, how does σ change if A is reduced by half?", "Which quantity is dimensionless: stress or strain?"),
                    listOf("PYQ-aligned: Conceptual stress–strain comparison", "PYQ-aligned: Units and proportionality")
                ),
                topic(
                    "Solved Examples",
                    "Example 1: A steel bar carries an axial tensile load of 50 kN over an area of 500 mm². Stress = P/A = 50,000/500 = 100 N/mm² = 100 MPa.\n\nExample 2: A 2 m bar elongates by 1 mm. Strain = ΔL/L = 1/2000 = 0.0005.\n\nExample 3: If E = 200 GPa and σ = 100 MPa, strain = σ/E = 100/200,000 = 0.0005. Keep both stress and modulus in the same units before division.",
                    "σ = P/A\nε = ΔL/L\nε = σ/E",
                    "A reliable numerical sequence is: write given data → convert units → select formula → substitute → state unit and sign where relevant.",
                    listOf("Worked direct-stress calculation", "Worked strain calculation", "Worked Hooke's-law calculation"),
                    listOf("Calculate stress for P = 80 kN and A = 400 mm².", "Calculate strain for L = 1500 mm and ΔL = 0.6 mm."),
                    listOf("PYQ-aligned: Direct stress numerical", "PYQ-aligned: Hooke's-law numerical")
                ),
                topic(
                    "Quick Revision",
                    "Stress = internal resisting force per unit area. Strain = deformation per unit original dimension. Normal stress acts perpendicular to an area; shear stress acts tangentially. Tensile loading tends to elongate a member, while compressive loading tends to shorten it. Elastic deformation is recoverable; plastic deformation is permanent.\n\nRemember the three foundation relations: σ = P/A, ε = ΔL/L and E = σ/ε in the applicable linear-elastic range. Stress is measured in Pa, MPa or N/mm²; strain is dimensionless.",
                    "σ = P/A\nε = ΔL/L\nE = σ/ε\nτ = V/A (average)",
                    "Exam checklist: identify loading type → identify area → identify deformation → use original dimension for engineering strain → keep units consistent → check whether an elastic relation is applicable.",
                    listOf("One-page formula and concept summary", "Stress, strain and Hooke's-law relationship"),
                    listOf("State the formula for normal stress.", "State the formula for longitudinal strain.", "What is the SI unit of stress?", "Why is strain dimensionless?"),
                    listOf("PYQ-aligned: Rapid revision of Simple Stress & Strain", "PYQ-aligned: Formula and definition recall")
                )
            )) ,
            chapter("Elastic Constants", 55, listOf(
                topic("Young's Modulus", "Ratio of normal stress to longitudinal strain within the applicable elastic range.", "E = σ/ε", "Young's modulus measures axial elastic stiffness of a material.", listOf("Axial stress and strain relationship"), listOf("Calculate E from stress and strain"), listOf("PYQ-aligned: Elastic constants")),
                topic("Poisson's Ratio", "Ratio of lateral strain to longitudinal strain in magnitude under uniaxial loading.", "ν = lateral strain / longitudinal strain", "Poisson's ratio links axial and transverse deformation.", listOf("Axial extension with lateral contraction"), listOf("Find lateral strain from ν"), listOf("PYQ-aligned: Poisson ratio"))
            )),
            chapter("Shear Force & Bending Moment", 40, listOf(
                topic("Shear Force", "Algebraic sum of vertical forces on one side of a beam section.", "dV/dx = −w", "Shear force changes with distributed load intensity.", listOf("Beam section and shear force"), listOf("Draw SFD for UDL"), listOf("PYQ-aligned: SFD")),
                topic("Bending Moment", "Internal moment developed at a beam section due to external loads.", "dM/dx = V", "Maximum or minimum bending moment occurs where shear force is zero, subject to boundary conditions.", listOf("Beam section and bending moment"), listOf("Find maximum BM"), listOf("PYQ-aligned: BMD"))
            ))
        )),
        SubjectContent("Fluid Mechanics", listOf(
            chapter("Properties of Fluids", 60, listOf(
                topic("Density & Specific Gravity", "Density is mass per unit volume; specific gravity compares density with water.", "ρ = m/V; SG = ρ/ρw", "Specific gravity is dimensionless.", listOf("Density and volume relation"), listOf("Calculate SG"), listOf("PYQ-aligned: Fluid properties")),
                topic("Viscosity", "Viscosity represents resistance to relative motion between fluid layers.", "τ = μ du/dy", "Dynamic viscosity links shear stress with velocity gradient for a Newtonian fluid.", listOf("Velocity gradient between fluid layers"), listOf("Find shear stress"), listOf("PYQ-aligned: Viscosity"))
            )),
            chapter("Bernoulli Equation", 50, listOf(
                topic("Bernoulli's Equation", "Energy equation for steady, incompressible flow along a streamline under stated assumptions.", "P/ρg + V²/2g + z = constant", "Pressure, velocity and elevation heads form the ideal-flow energy balance.", listOf("Flow between two sections"), listOf("Apply Bernoulli between two sections"), listOf("PYQ-aligned: Bernoulli equation"))
            ))
        )),
        SubjectContent("Surveying", listOf(
            chapter("Chain Surveying", 45, listOf(
                topic("Principles of Chain Surveying", "Chain surveying is based primarily on linear measurements and triangulation.", "Area by coordinate/offset methods", "Well-conditioned triangles improve survey control.", listOf("Triangulation framework"), listOf("Select suitable triangle"), listOf("PYQ-aligned: Chain surveying"))
            )),
            chapter("Levelling", 35, listOf(
                topic("Rise and Fall Method", "A levelling method for computing reduced levels from consecutive staff readings.", "RL(next) = RL(previous) ± rise/fall", "The arithmetic check helps verify level-book calculations.", listOf("Level book sequence"), listOf("Compute RL from staff readings"), listOf("PYQ-aligned: Levelling"))
            ))
        )),
        SubjectContent("Soil Mechanics", listOf(
            chapter("Index Properties", 50, listOf(
                topic("Void Ratio & Porosity", "Void ratio compares void volume with solid volume; porosity compares void volume with total volume.", "e = Vv/Vs; n = Vv/V; n = e/(1+e)", "For the same soil state, e and n are related by n = e/(1+e).", listOf("Three-phase soil diagram"), listOf("Convert e to n"), listOf("PYQ-aligned: Index properties"))
            ))
        )),
        SubjectContent("RCC Design", listOf(chapter("Limit State Design", 25, listOf(
            topic("Limit States", "Limit state design checks safety against collapse and serviceability requirements.", "Design action ≤ design resistance", "Partial safety factors account for uncertainties in loads and materials.", listOf("Limit-state design concept"), listOf("Identify limit state"), listOf("PYQ-aligned: RCC basics"))
        )))),
        SubjectContent("Highway Engineering", listOf(chapter("Highway Materials", 20, listOf(
            topic("Bitumen Tests", "Common tests assess consistency and temperature susceptibility of bituminous binders.", "Penetration, ductility, softening point", "Material selection depends on climate, traffic and pavement requirements.", listOf("Bitumen test-property map"), listOf("Match test with property"), listOf("PYQ-aligned: Highway materials"))
        )))),
        SubjectContent("Railways", listOf(chapter("Railway Engineering Basics", 0, emptyList()))),
        SubjectContent("Bridges & Tunnels", listOf(chapter("Bridge & Tunnel Fundamentals", 0, emptyList()))),
        SubjectContent("Irrigation & Water Supply", listOf(chapter("Water Resources & Supply", 0, emptyList()))),
        SubjectContent("Waste Water System", listOf(chapter("Wastewater Fundamentals", 0, emptyList()))),
        SubjectContent("Building Construction", listOf(chapter("Building Construction Basics", 0, emptyList()))),
        SubjectContent("Environmental Engineering", listOf(chapter("Environmental Engineering Basics", 0, emptyList()))),
        SubjectContent("Geotechnical Engineering", listOf(chapter("Geotechnical Fundamentals", 0, emptyList()))),
        SubjectContent("Construction Management", listOf(chapter("Construction Management Basics", 0, emptyList()))),
        SubjectContent("Estimation & Costing", listOf(chapter("Estimation Fundamentals", 0, emptyList()))),
        SubjectContent("Engineering Mathematics", listOf(chapter("Engineering Mathematics Basics", 0, emptyList())))
    )

    fun subject(name: String): SubjectContent? = subjects.firstOrNull { it.name == name }
    fun chapter(subject: String, name: String): ChapterContent? = subject(subject)?.chapters?.firstOrNull { it.name == name }
    fun topic(subject: String, chapter: String, name: String): TopicContent? = chapter(subject, chapter)?.topics?.firstOrNull { it.name == name }
}
