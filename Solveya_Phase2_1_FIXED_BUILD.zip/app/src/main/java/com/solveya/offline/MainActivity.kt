package com.solveya.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.solveya.offline.ai.AiModelState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolveyaApp() }
    }
}

@Composable
fun SolveyaApp(vm: SolveyaViewModel = viewModel()) {
    val state by vm.modelState.collectAsState()
    val answer by vm.answer.collectAsState()
    var question by remember { mutableStateOf("") }

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(Modifier.height(20.dp))
                Text("Solveya", color = Color.White, fontSize = 34.sp)
                Text(
                    "Your Offline AI Study Assistant",
                    color = Color(0xFFFFB52E),
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(18.dp))
                Text(
                    "Phase 2 • Real On-Device AI Core",
                    color = Color(0xFF9BB56A),
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(18.dp))

                ModelStatusCard(state)

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { /* Camera in next milestone */ },
                        modifier = Modifier.weight(1f)
                    ) { Text("📷 Camera") }

                    OutlinedButton(
                        onClick = { /* Gallery in next milestone */ },
                        modifier = Modifier.weight(1f)
                    ) { Text("🖼 Gallery") }
                }

                Spacer(Modifier.height(10.dp))

                TextField(
                    value = question,
                    onValueChange = { question = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    placeholder = {
                        Text("Ask a Maths or Science question…")
                    },
                    shape = RoundedCornerShape(18.dp)
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = { vm.ask(question) },
                    enabled = state is AiModelState.Ready && question.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("ASK SOLVEYA OFFLINE")
                }

                Spacer(Modifier.height(18.dp))

                answer?.let {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF151515)
                        ),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text(
                            text = it,
                            modifier = Modifier.padding(18.dp),
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelStatusCard(state: AiModelState) {
    val (title, detail) = when (state) {
        AiModelState.NotConfigured ->
            "Model not installed" to
                "Phase 2 runtime is connected. Install the Gemma 4 E2B LiteRT-LM model file to run real offline AI."
        AiModelState.Loading ->
            "Loading offline AI…" to "The model is initializing. This can take time on first load."
        AiModelState.Ready ->
            "● Offline AI READY" to "Local model is initialized. Internet is not required for inference."
        is AiModelState.Error ->
            "Offline AI error" to state.message
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text(detail, color = Color(0xFFCCCCCC), fontSize = 13.sp)
        }
    }
}
