package com.solveya.offline

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.solveya.offline.ai.AiModelState
import com.solveya.offline.ai.LiteRtLmEngine
import com.solveya.offline.ai.LocalModelManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SolveyaViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = LiteRtLmEngine(application.applicationContext)

    private val _modelState = MutableStateFlow<AiModelState>(
        if (LocalModelManager.isInstalled(application)) AiModelState.NotConfigured
        else AiModelState.NotConfigured
    )
    val modelState: StateFlow<AiModelState> = _modelState.asStateFlow()

    private val _answer = MutableStateFlow<String?>(null)
    val answer: StateFlow<String?> = _answer.asStateFlow()

    fun initializeModel() {
        _modelState.value = AiModelState.Loading
        viewModelScope.launch {
            val result = engine.initialize()
            _modelState.value = result.fold(
                onSuccess = { AiModelState.Ready },
                onFailure = { AiModelState.Error(it.message ?: "Model initialization failed.") }
            )
        }
    }

    fun ask(question: String) {
        if (question.isBlank()) return
        _answer.value = "Thinking offline…"
        viewModelScope.launch {
            val result = engine.ask(question)
            _answer.value = result.getOrElse {
                "Offline AI error: ${it.message ?: "Unknown error"}"
            }
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }
}
