package com.solveya.offline.ai

sealed interface AiModelState {
    data object NotConfigured : AiModelState
    data object Loading : AiModelState
    data object Ready : AiModelState
    data class Error(val message: String) : AiModelState
}
