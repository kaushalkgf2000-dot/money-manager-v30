package com.solveya.offline.ai

import android.content.Context
import java.io.File

object LocalModelManager {
    const val MODEL_FILE_NAME = "gemma-4-E2B-it.litertlm"

    fun modelFile(context: Context): File =
        File(File(context.filesDir, "models"), MODEL_FILE_NAME)

    fun isInstalled(context: Context): Boolean =
        modelFile(context).let { it.exists() && it.length() > 0L }

    fun ensureModelDirectory(context: Context) {
        modelFile(context).parentFile?.mkdirs()
    }
}
