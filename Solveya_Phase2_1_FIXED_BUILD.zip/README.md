# Solveya — Phase 2: Real Offline AI Core

This phase replaces the placeholder AI with the LiteRT-LM Android runtime.

## Product identity

- App: Solveya
- Scope: Class 8–10 Maths + Science
- Priority: Class 9–10
- Architecture: Offline-first
- Current AI candidate: Gemma 4 E2B LiteRT-LM
- Current runtime: LiteRT-LM Android 0.16.1
- Current backend for first validation: CPU

## Phase 2 milestone

Text question
→ local `.litertlm` model
→ on-device conversation
→ response

The model is intentionally NOT bundled in this ZIP because it is a multi-gigabyte model artifact with its own license/distribution terms. The app checks its private model directory for:

`gemma-4-E2B-it.litertlm`

## Important device note

The official LiteRT-LM model registry currently lists Gemma 4 E2B at about 2.59 GB and a minimum device memory requirement of 8 GB. The model is multimodal and supports image input, which will be useful for the later Camera/Gallery milestone.

For the first phone validation we use CPU to avoid GPU-driver-specific failures. GPU/NPU acceleration can be benchmarked after the CPU path is proven.

## Next milestone

1. Put the model file in the app's model directory.
2. Initialize it.
3. Run `2x + 5 = 15`.
4. Confirm the response with Airplane Mode ON.
5. Then build the deterministic Math Engine and connect it as a tool/router.
6. After that: Camera → Gallery → Science.

## Source

LiteRT-LM Kotlin API documentation:
https://github.com/google-ai-edge/LiteRT-LM/blob/main/docs/api/kotlin/getting_started.md


## Build fix — Phase 2.1

The previous build failed in `LiteRtLmEngine.kt` because `Conversation.sendMessage()` returns a
`Message`, not an object with a `.text` property. The current LiteRT-LM Kotlin API exposes the
message text through `Message.toString()` / its `contents`.

Fixed:
- `response.text` → `response.toString()`
- Root project name → `Solveya`

This change addresses the exact compiler error shown in the supplied build video.
