# V69 — Edit Auto-Backup Fix

Base: V68 exactly.

Requested change only: after an existing transaction is edited and saved, cancel the pending debounced cloud-sync timer and immediately invoke the existing `pfCloudSyncNow()` cloud backup entry point. This ensures the edited transaction is uploaded before the user closes the app, so the next automatic cloud restore does not replace the edit with the older Drive copy.

No other feature, authentication, restore, profile, transaction, or UI logic was changed.
