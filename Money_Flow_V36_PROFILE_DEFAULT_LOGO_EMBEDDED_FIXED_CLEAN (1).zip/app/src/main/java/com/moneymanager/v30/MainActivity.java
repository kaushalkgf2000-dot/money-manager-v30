package com.moneymanager.v30;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetHost;
import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.webkit.ValueCallback;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.database.Cursor;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.util.Base64;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private final Handler handler = new Handler();
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int BACKUP_FILE_REQUEST = 4102;
    private final Executor executor = command -> handler.post(command);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
                    startActivityForResult(i,FILE_CHOOSER_REQUEST);
                    return true;
                }catch(Exception e){
                    filePathCallback=null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new BioBridge(this), "AndroidBiometric");
        webView.addJavascriptInterface(new FileBridge(this), "AndroidFile");
        webView.addJavascriptInterface(new WidgetBridge(this), "AndroidWidget");
        webView.addJavascriptInterface(new BackupBridge(this), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==BACKUP_FILE_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
                    while((n=in.read(buf))!=-1)out.write(buf,0,n);
                    String json=out.toString("UTF-8");
                    final String js="window.mfApplyBackup("+org.json.JSONObject.quote(json)+")";
                    webView.post(()->webView.evaluateJavascript(js,null));
                }catch(Exception e){
                    webView.post(()->android.widget.Toast.makeText(this,"Restore failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());
                }
            }
            return;
        }
        if(requestCode!=FILE_CHOOSER_REQUEST)return;
        if(filePathCallback==null)return;
        Uri[] result=null;
        if(resultCode==RESULT_OK && data!=null){
            Uri u=data.getData();
            if(u!=null)result=new Uri[]{u};
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback=null;
    }

    public class FileBridge {
        private final Context ctx; FileBridge(Context c){ctx=c;}
        @JavascriptInterface public void saveFile(String name, String mime, String b64){
            try{
                byte[] data=Base64.getDecoder().decode(b64);
                if(android.os.Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Manager");
                    Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null)throw new Exception("Could not create download file");
                    try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved to Downloads/Money Manager: "+name,android.widget.Toast.LENGTH_LONG).show());
                } else {
                    java.io.File dir=new java.io.File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Money Manager");
                    if(!dir.exists())dir.mkdirs();
                    java.io.File f=new java.io.File(dir,name);
                    try(java.io.FileOutputStream out=new java.io.FileOutputStream(f)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved: "+f.getAbsolutePath(),android.widget.Toast.LENGTH_LONG).show());
                }
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Export failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
    }


    public class BackupBridge {
        private final Context ctx; BackupBridge(Context c){ctx=c;}
        private java.io.File snapshot(){return new java.io.File(ctx.getFilesDir(),"money_flow_backup_snapshot.json");}
        @JavascriptInterface public void saveBackupSnapshot(String json){
            try{java.io.File f=snapshot();try(java.io.FileOutputStream out=new java.io.FileOutputStream(f,false)){out.write(json.getBytes(StandardCharsets.UTF_8));} }
            catch(Exception e){ }
        }
        @JavascriptInterface public String getBackupSnapshot(){
            try{java.io.File f=snapshot();if(!f.exists())return "";return new String(java.nio.file.Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);}catch(Exception e){return "";}
        }
        @JavascriptInterface public String getBackupMeta(){
            try{java.io.File f=snapshot();if(!f.exists())return "No recovery snapshot created yet.";return "✓ Recovery snapshot available • "+new java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a",java.util.Locale.getDefault()).format(new java.util.Date(f.lastModified()));}catch(Exception e){return "Backup status unavailable.";}
        }
        @JavascriptInterface public void exportBackupFile(String json,String name){
            try{
                android.content.ContentValues v=new android.content.ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/json");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Flow Backup");
                Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Could not create backup file");
                try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(json.getBytes(StandardCharsets.UTF_8));}
                webView.post(()->android.widget.Toast.makeText(ctx,"Backup saved to Downloads/Money Flow Backup",android.widget.Toast.LENGTH_LONG).show());
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Backup failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBackupFile(){
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,BACKUP_FILE_REQUEST);}catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"File picker unavailable",android.widget.Toast.LENGTH_SHORT).show());}
        }
    }

    public class WidgetBridge {
        private final Context ctx;
        WidgetBridge(Context c){ctx=c;}

        @JavascriptInterface public void updateStatus(String balance, String expense, String credit){
            ctx.getSharedPreferences(PaisaFlowWidgetProvider.PREFS, Context.MODE_PRIVATE)
                .edit().putString(PaisaFlowWidgetProvider.BALANCE, balance)
                .putString(PaisaFlowWidgetProvider.EXPENSE, expense)
                .putString(PaisaFlowWidgetProvider.CREDIT, credit).apply();
            webView.post(() -> PaisaFlowWidgetProvider.updateAll(ctx));
        }

        @JavascriptInterface public void requestPinWidget(){
            if(android.os.Build.VERSION.SDK_INT < 26){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            AppWidgetManager manager=AppWidgetManager.getInstance(ctx);
            ComponentName provider=new ComponentName(ctx, PaisaFlowWidgetProvider.class);
            if(!manager.isRequestPinAppWidgetSupported()){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            PendingIntent callback=PendingIntent.getBroadcast(ctx, 9321,
                new Intent(ctx, PaisaFlowWidgetProvider.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            boolean requested=manager.requestPinAppWidget(provider, null, callback);
            if(!requested){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Open your Home screen's Widgets panel to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
            }
        }
    }

    public class BioBridge {
        private final Context ctx;
        BioBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean isAvailable(){
            if (android.os.Build.VERSION.SDK_INT < 28) return false;
            BiometricManager bm=(BiometricManager)ctx.getSystemService(Context.BIOMETRIC_SERVICE);
            if(bm==null)return false;
            int r=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return r==BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public void authenticate(final String callback){
            if(android.os.Build.VERSION.SDK_INT<28){send(callback,false);return;}
            if(!isAvailable()){send(callback,false);return;}
            BiometricPrompt prompt=new BiometricPrompt.Builder(MainActivity.this)
                .setTitle("Money Flow")
                .setSubtitle("Verify your identity")
                .setDescription("Use your registered fingerprint or biometric to continue.")
                .setNegativeButton("Use PIN", executor, (d,w)->send(callback,false))
                .build();
            CancellationSignal cs=new CancellationSignal();
            prompt.authenticate(cs, executor, new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){send(callback,true);}
                @Override public void onAuthenticationFailed(){ /* keep prompt open */ }
                @Override public void onAuthenticationError(int e, CharSequence msg){send(callback,false);}
            });
        }
        private void send(String cb, boolean ok){
            final String js="window."+cb+"("+(ok?"true":"false")+")";
            handler.post(()->webView.evaluateJavascript(js,null));
        }
    }
}
