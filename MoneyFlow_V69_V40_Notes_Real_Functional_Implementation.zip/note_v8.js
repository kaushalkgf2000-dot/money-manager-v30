
(function(){
  'use strict';
  const STORE='moneyflow_notes_v1';
  const CATS=['Shopping','Wish List','Personal','Work'];
  let notes=[],view='list',editId=null,filter='All',search='';
  const uid=()=> 'n_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
  function migrate(n){
    n=n||{};
    let text=String(n.text||'');
    if(!text && Array.isArray(n.items)&&n.items.length) text=n.items.map(x=>String(x&&x.text||'')).filter(Boolean).join('\n');
    return {id:String(n.id||uid()),title:String(n.title||'Untitled Note'),category:CATS.includes(n.category)?n.category:'Personal',text,pinned:!!n.pinned,created:Number(n.created)||Date.now(),updated:Number(n.updated)||Number(n.created)||Date.now()};
  }
  function load(){try{const raw=JSON.parse(localStorage.getItem(STORE)||'[]');notes=Array.isArray(raw)?raw.map(migrate):[];save()}catch(e){notes=[]}}
  function save(){try{localStorage.setItem(STORE,JSON.stringify(notes));return true}catch(e){alert('Notes could not be saved on this device.');return false}}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function fmtDate(ts){return new Date(ts||Date.now()).toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'})}
  function icon(cat){return cat==='Shopping'?'🛒':cat==='Wish List'?'♥':cat==='Work'?'▣':'▤'}
  function get(id){return notes.find(n=>String(n.id)===String(id))}
  function filtered(){const q=search.trim().toLowerCase();return notes.filter(n=>(filter==='All'||n.category===filter)&&(!q||[n.title,n.category,n.text].join(' ').toLowerCase().includes(q))).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||(b.updated-a.updated))}
  function ensureShell(){
    const m=document.getElementById('pfNotesModal');if(!m)return null;const sheet=m.querySelector('.pf-feature-sheet');if(!sheet)return null;
    if(sheet.dataset.mfn==='v8')return sheet;sheet.dataset.mfn='v8';
    sheet.innerHTML='<div class="pf-feature-head"><div><span class="pf-feature-kicker">PERSONAL ORGANIZER</span><h2>Notes</h2></div><div class="mfn-head-actions"><button class="mfn-icon-btn" type="button" data-mfn-action="search">⌕</button><button class="pf-feature-close" type="button" onclick="pfCloseFeature(\'pfNotesModal\')">✕</button></div></div><div id="mfnRoot"></div>';
    return sheet;
  }
  function show(){ensureShell();const m=document.getElementById('pfNotesModal');if(m){m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden'}render()}
  function render(){ensureShell();const root=document.getElementById('mfnRoot');if(!root)return;if(view==='list')renderList(root);else if(view==='detail')renderDetail(root);else renderCreate(root)}
  function renderList(root){
    const data=filtered();
    root.innerHTML=`<div class="mfn-filter-row">${['All'].concat(CATS).map(c=>`<button type="button" class="mfn-filter ${filter===c?'active':''}" data-mfn-filter="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <div id="mfnSearchBox" style="display:${search?'block':'none'}"><input id="mfnSearchInput" class="mfn-search" value="${esc(search)}" placeholder="Search notes..."></div>
      <div class="mfn-topbar"><h3>All Notes</h3><span class="mfn-note-hint">Simple &amp; local</span></div>
      <div class="mfn-list">${data.length?data.map(card).join(''):`<div class="mfn-empty">No notes yet.<br>Tap <b>+ New Note</b> to add one.</div>`}</div>
      <button type="button" class="mfn-primary" data-mfn-action="new">＋ New Note</button>`;
    const inp=document.getElementById('mfnSearchInput');if(inp&&search){inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)}
  }
  function card(n){const preview=(n.text||'').replace(/\s+/g,' ').trim();const id=JSON.stringify(n.id);return `<div class="mfn-card" data-mfn-open="${esc(n.id)}"><div class="mfn-card-icon">${icon(n.category)}</div><div class="mfn-card-main"><div class="mfn-card-title">${esc(n.title||'Untitled Note')} ${n.pinned?'<span class="mfn-pin">📌</span>':''}</div><div class="mfn-card-meta">${esc(n.category)} • ${fmtDate(n.updated||n.created)}</div>${preview?`<div class="mfn-card-preview">${esc(preview)}</div>`:''}<div class="mfn-card-actions"><button type="button" data-mfn-edit="${esc(n.id)}">✎ Edit</button><button type="button" data-mfn-delete="${esc(n.id)}">🗑 Delete</button></div></div></div>`}
  function renderDetail(root){const n=get(editId);if(!n){view='list';render();return}const id=JSON.stringify(n.id);root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" data-mfn-action="back">‹ Notes</button><h3>Note</h3></div><h3 class="mfn-detail-title">${esc(n.title||'Untitled Note')}</h3><div class="mfn-detail-sub">${esc(n.category)} • ${fmtDate(n.updated||n.created)} ${n.pinned?'• Pinned':''}</div><div class="mfn-detail-section"><div class="mfn-text-note">${esc(n.text||'No content added.')}</div></div><div class="mfn-detail-actions"><button class="mfn-action-edit" type="button" data-mfn-edit="${esc(n.id)}">✎ Edit</button><button class="mfn-action-delete" type="button" data-mfn-delete="${esc(n.id)}">🗑 Delete</button></div><button type="button" class="mfn-secondary" data-mfn-pin="${esc(n.id)}">${n.pinned?'☆ Unpin Note':'📌 Pin Note'}</button>`}
  function renderCreate(root){
    const n=editId?get(editId):null;const d=n||{title:'',category:'Personal',text:''};
    root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" data-mfn-action="back">‹ Back</button><h3>${n?'Edit Note':'New Note'}</h3><button class="mfn-back" type="button" data-mfn-action="save">Save</button></div><div class="mfn-form"><div class="mfn-field"><label>Title</label><input id="mfnTitle" value="${esc(d.title)}" placeholder="e.g. Grocery list"></div><div class="mfn-field"><label>Category</label><select id="mfnCategory">${CATS.map(c=>`<option ${d.category===c?'selected':''}>${c}</option>`).join('')}</select></div><div class="mfn-field"><label>Note</label><textarea id="mfnText" placeholder="Write anything here...">${esc(d.text||'')}</textarea><div class="mfn-note-hint">Write your note normally. You can use multiple lines.</div></div><button class="mfn-primary mfn-save-note" type="button" data-mfn-action="save">✓ ${n?'Save Changes':'Save Note'}</button></div>`;
  }
  function openEdit(id){if(!get(id))return;editId=String(id);view='create';render()}
  function saveForm(){
    const title=(document.getElementById('mfnTitle')?.value||'').trim();const text=(document.getElementById('mfnText')?.value||'').trim();
    if(!title&&!text){alert('Please enter a title or note.');return false}
    const category=document.getElementById('mfnCategory')?.value||'Personal';let n=editId?get(editId):null;
    if(n){n.title=title||'Untitled Note';n.category=CATS.includes(category)?category:'Personal';n.text=text;n.updated=Date.now()}
    else{n={id:uid(),title:title||'Untitled Note',category:CATS.includes(category)?category:'Personal',text,pinned:false,created:Date.now(),updated:Date.now()};notes.unshift(n);editId=n.id}
    if(!save())return false;view='list';render();return true;
  }
  function deleteNote(id){
    const n=get(id);if(!n)return;
    showDeleteConfirm(id,n.title);
  }
  function showDeleteConfirm(id,title){
    let m=document.getElementById('mfnDeleteConfirm');
    if(!m){m=document.createElement('div');m.id='mfnDeleteConfirm';m.style.cssText='position:fixed;inset:0;z-index:20050;background:rgba(30,24,18,.55);display:flex;align-items:center;justify-content:center;padding:20px';document.body.appendChild(m)}
    m.innerHTML=`<div style="width:min(360px,100%);background:#faf8f2;border-radius:20px;padding:20px;box-shadow:0 16px 50px rgba(0,0,0,.25)"><h3 style="margin:0 0 8px;color:var(--pf-brown)">Delete Note?</h3><p style="margin:0 0 16px;color:#756c60;font:12px/1.5 Arial,sans-serif">Delete “${esc(title||'Untitled Note')}”? This cannot be undone.</p><div style="display:flex;gap:8px"><button type="button" class="mfn-secondary" data-mfn-confirm-cancel>Cancel</button><button type="button" class="mfn-action-delete" data-mfn-confirm-delete="${esc(id)}">Delete</button></div></div>`;
    m.style.display='flex';
  }
  function closeDeleteConfirm(){const m=document.getElementById('mfnDeleteConfirm');if(m)m.style.display='none'}
  function performDelete(id){const before=notes.length;notes=notes.filter(n=>String(n.id)!==String(id));if(notes.length===before){closeDeleteConfirm();return}if(!save())return;if(String(editId)===String(id))editId=null;view='list';closeDeleteConfirm();render()}
  function togglePin(id){const n=get(id);if(!n)return;n.pinned=!n.pinned;n.updated=Date.now();save();render()}
  function openSearch(){view='list';render();setTimeout(()=>document.getElementById('mfnSearchInput')?.focus(),0)}
  function bind(){
    if(window.__mfnV8Bound)return;window.__mfnV8Bound=true;
    document.addEventListener('click',function(e){
      const t=e.target.closest('[data-mfn-action],[data-mfn-filter],[data-mfn-open],[data-mfn-edit],[data-mfn-delete],[data-mfn-pin],[data-mfn-confirm-delete],[data-mfn-confirm-cancel]');if(!t)return;
      if(t.hasAttribute('data-mfn-confirm-cancel')){closeDeleteConfirm();return}
      if(t.hasAttribute('data-mfn-confirm-delete')){e.preventDefault();e.stopPropagation();performDelete(t.getAttribute('data-mfn-confirm-delete'));return}
      if(t.hasAttribute('data-mfn-pin')){e.preventDefault();e.stopPropagation();togglePin(t.getAttribute('data-mfn-pin'));return}
      const root=document.getElementById('mfnRoot');if(!root)return;
      if(t.hasAttribute('data-mfn-edit')){e.preventDefault();e.stopPropagation();openEdit(t.getAttribute('data-mfn-edit'));return}
      if(t.hasAttribute('data-mfn-delete')){e.preventDefault();e.stopPropagation();deleteNote(t.getAttribute('data-mfn-delete'));return}
      if(t.hasAttribute('data-mfn-open')){editId=t.getAttribute('data-mfn-open');view='detail';render();return}
      const f=t.getAttribute('data-mfn-filter');if(f!==null){filter=f;view='list';render();return}
      const a=t.getAttribute('data-mfn-action');if(!a)return;
      if(a==='new'){editId=null;view='create';render()}
      else if(a==='save'){saveForm()}
      else if(a==='back'){editId=null;view='list';render()}
      else if(a==='search'){openSearch()}
    });
    document.addEventListener('input',function(e){if(e.target&&e.target.id==='mfnSearchInput'){search=e.target.value;const pos=e.target.selectionStart;render();const x=document.getElementById('mfnSearchInput');if(x){x.focus();try{x.setSelectionRange(pos,pos)}catch(_){}}}});

    document.addEventListener('click',function(e){if(e.target&&e.target.id==='mfnDeleteConfirm')closeDeleteConfirm()});
  }
  window.mfnShow=function(v){view=v==='create'?'create':'list';render()};
  window.mfnFilter=function(v){filter=v;render()};
  window.mfnSearch=function(v){search=v;render()};
  window.mfnToggleSearch=openSearch;
  window.mfnNew=function(){editId=null;view='create';render()};
  window.mfnOpen=function(id){editId=String(id);view='detail';render()};
  window.mfnEditNote=openEdit;
  window.mfnEdit=function(){if(editId)openEdit(editId)};
  window.mfnSaveForm=saveForm;
  window.mfnDeleteNote=deleteNote;
  window.mfnDelete=function(){if(editId)deleteNote(editId)};
  window.mfnTogglePinNote=togglePin;
  window.mfnTogglePin=function(){if(editId)togglePin(editId)};
  window.mfnCardMenu=function(id){openEdit(id)};
  window.mfnUseTemplate=function(){window.mfnNew()};
  window.pfOpenNotes=function(){load();filter='All';search='';view='list';show();if(typeof window.pfSetNav==='function')window.pfSetNav(document.getElementById('notesNavBtn'))};
  bind();load();
})();
