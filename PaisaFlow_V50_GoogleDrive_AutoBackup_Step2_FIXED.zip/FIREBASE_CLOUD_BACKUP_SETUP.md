# PaisaFlow V44 — Automatic Cloud Sync / Restore

This build keeps the existing Firebase Authentication and local/offline data.
Cloud transaction backup is moved to **Firebase Realtime Database** as the primary
transport. Firestore remains only as a migration fallback so older backups can be
recovered.

## One-time Firebase Console setup

1. Authentication → Sign-in method → keep **Email/Password** enabled.
2. Keep **Google** enabled if Google Sign-In is used.
3. Project settings → Android app → keep the correct SHA-1/SHA-256 fingerprints.
4. Firebase Console → **Realtime Database** → Create Database.
5. Deploy `database.rules.json` as the Realtime Database rules.
6. Keep the existing Firestore database/rules temporarily so V43 and older backups
   can be migrated automatically.

## V44 cloud behavior

- Every transaction/profile change schedules a silent cloud sync.
- The Android Realtime Database client writes locally first and queues writes while
  offline; queued writes are sent automatically when connectivity returns.
- The app does **not** perform a read-before-write for every backup. This removes the
  previous `client is offline` failure path.
- After successful login, the app silently checks the cloud backup.
- If an RTDB backup exists, it is restored automatically.
- If only an older Firestore backup exists, it is restored and then migrated to RTDB.
- If no cloud backup exists, the current local data becomes the first cloud backup.
- PIN, recovery code, PIN hashes and other security credentials are excluded from
  the cloud backup.
- Automatic background sync/restore does not show error popups to the user.

## Important

The Realtime Database must be created once in the Firebase Console. The Android code
already enables disk persistence and uses the authenticated Firebase UID as the
private cloud path: `users/<uid>/backup/latest`.
