# PaisaFlow Google Drive Backup — V49

## Current architecture

- Firebase Authentication remains the identity/authentication layer.
- Firebase Realtime Database and Firestore are no longer used by the Android cloud-backup bridge for financial data.
- Cloud backup uses the Google Drive API `appDataFolder` space.
- The OAuth scope used is `https://www.googleapis.com/auth/drive.appdata`.
- Each Firebase account gets a unique Drive backup filename based on its Firebase UID.
- The backup payload also contains the Firebase UID and account email, so a backup from another PaisaFlow account is rejected during restore.
- Only the currently active account's data keys are sent to Drive; other account namespaces on the same device are excluded.
- PIN, recovery code and security credentials are excluded from cloud backup.
- Local/offline backup remains available.

## Automatic flow

1. User must authenticate before entering the dashboard.
2. After authentication, PaisaFlow checks Google Drive for the current account's backup.
3. If a backup exists, it is restored into the same account workspace and the current account state is synchronized.
4. If no backup exists, the current account workspace is uploaded as the first backup.
5. Later localStorage changes are debounced and automatically synchronized to Drive.

## Google Cloud configuration required before runtime testing

Enable the Google Drive API in the same Google Cloud project used by the Android app. The app must be rebuilt with the current Firebase/Google configuration.

The Drive authorization is requested at runtime. For a Firebase email/password account, Android may ask the user to choose/authorize a Google account for Drive access. This is a one-time authorization; backup operations afterward are automatic.
