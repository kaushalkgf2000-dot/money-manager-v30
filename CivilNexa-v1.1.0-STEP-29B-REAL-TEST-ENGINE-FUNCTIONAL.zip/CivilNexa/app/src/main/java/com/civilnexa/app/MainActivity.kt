package com.civilnexa.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF07051A)
private val Surface = Color(0xFF12102A)
private val Surface2 = Color(0xFF181437)
private val Purple = Color(0xFF8B4DFF)
private val Purple2 = Color(0xFFC18BFF)
private val Orange = Color(0xFFFF8A32)
private val Green = Color(0xFF45D483)
private val Red = Color(0xFFFF5C6C)
private val White = Color(0xFFF7F5FF)
private val Muted = Color(0xFFB8B2CC)

private data class Question(val text: String, val options: List<String>, val answer: Int)
private data class TestResult(
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val timeTakenSeconds: Int,
    val totalSeconds: Int
) {
    val attempted: Int get() = correct + wrong
    val marks: Int get() = correct * 4 - wrong
    val totalMarks: Int get() = (correct + wrong + skipped) * 4
    val accuracy: Int get() = if (attempted == 0) 0 else (correct * 100 / attempted)
}

private val demoQuestions = listOf(
    Question("The unit of normal stress is:", listOf("N", "N/m²", "N·m", "Pa·s"), 1),
    Question("For a simply supported beam with UDL over the full span, maximum bending moment occurs at:", listOf("Support A", "Midspan", "Support B", "Quarter span"), 1),
    Question("The relation between load, shear force and bending moment is represented by:", listOf("dV/dx = -w", "dM/dx = V", "Both A and B", "Neither"), 2),
    Question("Poisson's ratio is the ratio of:", listOf("Lateral strain to longitudinal strain", "Stress to strain", "Shear stress to shear strain", "Load to area"), 0),
    Question("The SI unit of Young's modulus is:", listOf("N", "N/m", "N/m²", "m/N"), 2),
    Question("A material that undergoes large plastic deformation before failure is generally called:", listOf("Brittle", "Ductile", "Elastic", "Rigid"), 1),
    Question("The centroid of a rectangle lies at:", listOf("One corner", "The midpoint of its diagonal", "One-third height", "The base"), 1),
    Question("Bernoulli's equation is based on conservation of:", listOf("Mass only", "Momentum only", "Energy", "Temperature"), 2),
    Question("Specific gravity is the ratio of density of a substance to:", listOf("Density of air", "Density of water", "Unit weight of soil", "Viscosity of water"), 1),
    Question("The primary purpose of a foundation is to:", listOf("Increase building height", "Transfer load safely to soil", "Reduce concrete strength", "Increase dead load"), 1)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CivilNexaApp() }
    }
}

@Composable
fun CivilNexaApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedSubject by remember { mutableStateOf("Strength of Materials") }
    var selectedChapter by remember { mutableStateOf("Simple Stress & Strain") }
    var testResult by remember { mutableStateOf(TestResult(0, 0, demoQuestions.size, 0, 180)) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Surface)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (screen) {
                        "home" -> Home { target -> screen = target }
                        "study" -> Study(
                            onBack = { screen = "home" },
                            onSubject = { selectedSubject = it; screen = "chapters" }
                        )
                        "chapters" -> Chapters(
                            subject = selectedSubject,
                            onBack = { screen = "study" },
                            onChapter = { selectedChapter = it; screen = "chapter" }
                        )
                        "chapter" -> ChapterContents(
                            subject = selectedSubject,
                            chapter = selectedChapter,
                            onBack = { screen = "chapters" },
                            onTest = { screen = "test" }
                        )
                        "tests" -> Tests(onBack = { screen = "home" }, onStart = { screen = "test" })
                        "pyq" -> Pyq(onBack = { screen = "home" })
                        "progress" -> Progress(onBack = { screen = "home" })
                        "profile" -> Profile(onBack = { screen = "home" })
                        "test" -> LiveTest(
                            onExit = { screen = "tests" },
                            onSubmit = { result -> testResult = result; screen = "result" }
                        )
                        "result" -> Result(result = testResult, onBack = { screen = "tests" })
                    }
                }
                BottomBar(selectedTab) { tab ->
                    selectedTab = tab
                    screen = listOf("home", "study", "tests", "progress", "profile")[tab]
                }
            }
        }
    }
}

@Composable
private fun Top(title: String, back: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Back", tint = White) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = White)
            Text("CivilNexa", color = Purple2, fontSize = 11.sp)
        }
        action?.invoke()
    }
}

@Composable
private fun Home(go: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("Welcome back, Kumar 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
            Text("Let’s prepare for your next target.", color = Muted)
            Spacer(Modifier.height(16.dp))
            SearchField("Search topics, subjects...", onSearch = {})
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("Study Material", Icons.Default.MenuBook, Purple2, Modifier.weight(1f)) { go("study") }
                ActionCard("Test Series", Icons.Default.Quiz, Color(0xFF55D7C8), Modifier.weight(1f)) { go("tests") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("PYQ Center", Icons.Default.Description, Orange, Modifier.weight(1f)) { go("pyq") }
                ActionCard("Mock Test", Icons.Default.Computer, Color(0xFF58A6FF), Modifier.weight(1f)) { go("tests") }
            }
            Section("Continue Learning")
            CardBox("Strength of Materials", "Simple Stress & Strain • 65% complete", Icons.Default.MenuBook)
            Section("Performance Snapshot")
            CardBox("Overall Progress", "68% • 48 tests • 73% accuracy", Icons.Default.Insights)
        }
    }
}

@Composable
private fun Study(onBack: () -> Unit, onSubject: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val subjects = listOf(
        "Engineering Mechanics", "Strength of Materials", "Fluid Mechanics", "Surveying",
        "Building Materials", "Building Construction", "Concrete Technology", "Soil Mechanics",
        "RCC Design", "Highway Engineering", "Railway Engineering", "Bridge Engineering", "Tunnel Engineering"
    )
    val filtered = subjects.filter { it.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        Top("Study Material", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item { SearchField("Search subjects, chapters...", query) { query = it }; Spacer(Modifier.height(8.dp)) }
            items(filtered) { subject ->
                CardBox(subject, "Chapter-wise notes • formulas • concepts • practice", Icons.Default.MenuBook) { onSubject(subject) }
            }
        }
    }
}

@Composable
private fun Chapters(subject: String, onBack: () -> Unit, onChapter: (String) -> Unit) {
    val chapters = listOf("Simple Stress & Strain", "Elastic Constants", "Shear Force & Bending Moment", "Bending Stress", "Shear Stress", "Torsion", "Columns", "Principal Stress")
    Column(Modifier.fillMaxSize()) {
        Top(subject, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Overall Progress", "75% • Notes + Practice + Tests", Icons.Default.Insights)
                Section("Chapters")
            }
            itemsIndexed(chapters) { index, chapter ->
                CardBox("Chapter ${index + 1} • $chapter", "Topics, notes, formulas and practice", Icons.Default.MenuBook) { onChapter(chapter) }
            }
        }
    }
}

@Composable
private fun ChapterContents(subject: String, chapter: String, onBack: () -> Unit, onTest: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top(chapter, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                Text(subject, color = Purple2, fontSize = 12.sp)
                CardBox("Chapter Progress", "6 topics • 3 completed • 50%", Icons.Default.Insights)
                Section("Learn")
                CardBox("Handwritten Notes", "Read-only pages • zoom • bookmark", Icons.Default.Description)
                CardBox("Formulas", "Important formulas • symbols • units • applications", Icons.Default.Functions)
                CardBox("Important Concepts", "Definitions • theory • key points • diagrams", Icons.Default.Lightbulb)
                Section("Practice & Test")
                CardBox("Practice Questions", "MCQ • Numerical • Theory • Easy/Medium/Hard", Icons.Default.Quiz)
                CardBox("Chapter Test", "Timed test • review • auto-evaluation", Icons.Default.Timer) { onTest() }
                CardBox("Previous Year Questions", "Mapped by exam • year • topic", Icons.Default.History)
            }
        }
    }
}

@Composable
private fun Tests(onBack: () -> Unit, onStart: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val hasResume = remember { hasSavedTest(context) }
    val tests = listOf("Chapter Test • Strength of Materials", "Topic Test • SFD & BMD", "PYQ Test • Civil Engineering", "Full Mock Test • SSC JE", "Full Mock Test • RRB JE", "Custom Mock Test")
    val filtered = tests.filter { it.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Top("Test Series", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                SearchField("Search tests...", query) { query = it }
                Spacer(Modifier.height(8.dp))
                if (hasResume) {
                    CardBox("Resume Full Mock Test 01", "Saved answers • remaining time • marked questions restored", Icons.Default.PlayArrow, onStart)
                }
            }
            items(filtered) { test -> CardBox(test, "Questions • timer • negative marking • review", Icons.Default.Quiz, onStart) }
        }
    }
}

@Composable
private fun Pyq(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val papers = listOf("SSC JE Civil • 2024", "SSC JE Civil • 2023", "SSC JE Civil • 2022", "RRB JE Civil • Previous Papers", "UPSSSC JE Civil • Previous Papers")
    Column(Modifier.fillMaxSize()) {
        Top("PYQ Center", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item { SearchField("Search year, exam, subject...", query) { query = it }; Spacer(Modifier.height(8.dp)) }
            items(papers.filter { it.contains(query, true) }) { paper -> CardBox(paper, "Exam → Year → Subject → Chapter → Topic", Icons.Default.Description) }
        }
    }
}

@Composable
private fun Progress(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Progress", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Overall Progress", "68% completed • 22% in progress • 10% not started", Icons.Default.Insights)
                CardBox("Tests Attempted", "48 • Average accuracy 73%", Icons.Default.Quiz)
                CardBox("Questions Solved", "1,245", Icons.Default.CheckCircle)
                Section("Subject Performance")
                listOf("Strength of Materials • 78%", "Fluid Mechanics • 65%", "Surveying • 72%", "Soil Mechanics • 60%", "RCC • 80%").forEach { CardBox(it, "Progress tracked automatically", Icons.Default.BarChart) }
                Section("Weak Areas")
                CardBox("Construction Management", "Practice recommended • Accuracy below target", Icons.Default.Warning)
            }
        }
    }
}

@Composable
private fun Profile(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Profile", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Kumar", "Civil Engineering Aspirant • CivilNexa Learner", Icons.Default.Person)
                Section("Account")
                listOf("Edit Profile", "Change Password", "Linked Email & Mobile", "Bookmarks", "Test History").forEach { CardBox(it, "Open", Icons.Default.ChevronRight) }
                Section("Preferences")
                CardBox("Language", "English • Default", Icons.Default.Language)
                CardBox("Notification Settings", "Manage alerts", Icons.Default.Notifications)
                CardBox("Clear Cache", "Manage local storage", Icons.Default.Delete)
                CardBox("Sync Data", "Cloud sync when connected", Icons.Default.CloudSync)
            }
        }
    }
}

private const val TEST_PREFS = "civilnexa_test_state"
private const val TEST_ID = "mock_01"

private data class SavedTestState(
    val current: Int = 0,
    val remaining: Int = 180,
    val answers: Map<Int, Int> = emptyMap(),
    val marked: Set<Int> = emptySet()
)

private fun loadSavedTest(context: Context): SavedTestState {
    val prefs = context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE)
    if (!prefs.getBoolean("has_$TEST_ID", false)) return SavedTestState()
    val answers = prefs.getString("answers_$TEST_ID", "")!!.split(',')
        .filter { it.contains(":") }
        .mapNotNull { pair ->
            val parts = pair.split(":")
            if (parts.size == 2) parts[0].toIntOrNull()?.let { q -> parts[1].toIntOrNull()?.let { a -> q to a } } else null
        }.toMap()
    val marked = prefs.getString("marked_$TEST_ID", "")!!.split(',')
        .mapNotNull { it.toIntOrNull() }.toSet()
    return SavedTestState(
        current = prefs.getInt("current_$TEST_ID", 0).coerceIn(0, demoQuestions.lastIndex),
        remaining = prefs.getInt("remaining_$TEST_ID", 180).coerceIn(0, 180),
        answers = answers,
        marked = marked
    )
}

private fun saveTestState(context: Context, state: SavedTestState) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean("has_$TEST_ID", true)
        .putInt("current_$TEST_ID", state.current)
        .putInt("remaining_$TEST_ID", state.remaining)
        .putString("answers_$TEST_ID", state.answers.entries.joinToString(",") { "${it.key}:${it.value}" })
        .putString("marked_$TEST_ID", state.marked.joinToString(","))
        .apply()
}

private fun clearSavedTest(context: Context) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .remove("has_$TEST_ID")
        .remove("current_$TEST_ID")
        .remove("remaining_$TEST_ID")
        .remove("answers_$TEST_ID")
        .remove("marked_$TEST_ID")
        .apply()
}

private fun hasSavedTest(context: Context): Boolean =
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).getBoolean("has_$TEST_ID", false)

@Composable
private fun LiveTest(onExit: () -> Unit, onSubmit: (TestResult) -> Unit) {
    val context = LocalContext.current
    val totalSeconds = 3 * 60
    val saved = remember { loadSavedTest(context) }
    var current by remember { mutableIntStateOf(saved.current) }
    var remaining by remember { mutableIntStateOf(saved.remaining) }
    var showPalette by remember { mutableStateOf(false) }
    var showCalculator by remember { mutableStateOf(false) }
    var showSubmitConfirm by remember { mutableStateOf(false) }
    var answers by remember { mutableStateOf(saved.answers) }
    var marked by remember { mutableStateOf(saved.marked) }
    var submitted by remember { mutableStateOf(false) }

    fun buildResult(): TestResult {
        val correct = answers.count { (q, a) -> demoQuestions[q].answer == a }
        val wrong = answers.size - correct
        val skipped = demoQuestions.size - answers.size
        return TestResult(correct, wrong, skipped, totalSeconds - remaining, totalSeconds)
    }

    fun submit() {
        if (!submitted) {
            submitted = true
            val finalResult = buildResult()
            clearSavedTest(context)
            onSubmit(finalResult)
        }
    }

    LaunchedEffect(remaining, submitted) {
        if (!submitted && remaining > 0) {
            delay(1000)
            remaining--
        } else if (!submitted && remaining == 0) {
            submit()
        }
    }

    LaunchedEffect(current, remaining, answers, marked, submitted) {
        if (!submitted) {
            saveTestState(context, SavedTestState(current, remaining, answers, marked))
        }
    }

    val q = demoQuestions[current]
    val answeredCount = answers.size
    val paletteStatus = if (marked.contains(current)) "Marked for review" else if (answers.containsKey(current)) "Answered" else "Not answered"

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExit) { Icon(Icons.Default.Close, "Exit", tint = White) }
                Column(Modifier.weight(1f)) {
                    Text("Full Mock Test 01", color = White, fontWeight = FontWeight.Bold)
                    Text("${formatTime(remaining)} • ${current + 1}/${demoQuestions.size}", color = if (remaining <= 30) Red else Purple2, fontSize = 12.sp)
                }
                TextButton(onClick = { showPalette = true }) { Text("Questions", color = Purple2) }
            }
            LinearProgressIndicator(progress = { (current + 1f) / demoQuestions.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Purple)
            LazyColumn(Modifier.weight(1f).padding(16.dp)) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(onClick = {}, label = { Text("Q.${current + 1}") })
                        AssistChip(onClick = {}, label = { Text("MCQ") })
                        Text("$answeredCount/${demoQuestions.size} answered", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBox("Question", q.text, Icons.Default.Quiz)
                    q.options.forEachIndexed { index, option ->
                        OptionCard(option, selected = answers[current] == index) { answers = answers + (current to index) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(paletteStatus, color = if (marked.contains(current)) Orange else Muted, fontSize = 12.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { current = (current - 1).coerceAtLeast(0) }, enabled = current > 0, modifier = Modifier.weight(1f)) { Text("Prev") }
                OutlinedButton(onClick = { marked = if (marked.contains(current)) marked - current else marked + current }, modifier = Modifier.weight(1f)) { Text(if (marked.contains(current)) "Unmark" else "Mark") }
                OutlinedButton(onClick = { answers = answers - current }, enabled = answers.containsKey(current), modifier = Modifier.weight(1f)) { Text("Clear") }
                Button(onClick = { showCalculator = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(3.dp)); Text("Calc") }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (current < demoQuestions.lastIndex) current++ else showSubmitConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text(if (current == demoQuestions.lastIndex) "Review & Submit" else "Next") }
            }
        }
        if (showPalette) QuestionPalette(current, answers, marked, onClose = { showPalette = false }) { current = it; showPalette = false }
        if (showCalculator) CalculatorOverlay { showCalculator = false }
        if (showSubmitConfirm) SubmitConfirmation(
            answered = answers.size,
            marked = marked.size,
            total = demoQuestions.size,
            onCancel = { showSubmitConfirm = false },
            onSubmit = { showSubmitConfirm = false; submit() }
        )
    }
}

private fun formatTime(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)

@Composable
private fun QuestionPalette(current: Int, answers: Map<Int, Int>, marked: Set<Int>, onClose: () -> Unit, onQuestion: (Int) -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.BottomCenter) {
        Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Questions", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${answers.size}/${demoQuestions.size} answered", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("● Answered", color = Green, fontSize = 11.sp)
                    Text("● Review", color = Orange, fontSize = 11.sp)
                    Text("● Current", color = Purple2, fontSize = 11.sp)
                }
                Spacer(Modifier.height(12.dp))
                for (start in 0 until demoQuestions.size step 5) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in start until minOf(start + 5, demoQuestions.size)) {
                            val bg = when {
                                i == current -> Purple
                                marked.contains(i) -> Orange
                                answers.containsKey(i) -> Green
                                else -> Surface
                            }
                            Box(Modifier.size(48.dp).background(bg, RoundedCornerShape(12.dp)).clickable { onQuestion(i) }, contentAlignment = Alignment.Center) {
                                Text("${i + 1}", color = White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun SubmitConfirmation(answered: Int, marked: Int, total: Int, onCancel: () -> Unit, onSubmit: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.68f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(24.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Submit Test?", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Answered: $answered/$total\nMarked for review: $marked\nUnanswered: ${total - answered}", color = Muted)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(onClick = onSubmit, modifier = Modifier.weight(1f)) { Text("Submit Test") }
                }
            }
        }
    }
}

@Composable
private fun CalculatorOverlay(onClose: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "C", "+")
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(22.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Calculator", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) } }
                Box(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(14.dp)).padding(16.dp)) { Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) { Text(expression.ifEmpty { "0" }, color = Muted); Text(result.ifEmpty { "" }, color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.height(12.dp))
                keys.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            Button(onClick = { if (key == "C") { expression = ""; result = "" } else { expression += key; result = "" } }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (key == "C") Color(0xFF5A1C2A) else Surface)) { Text(key) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Button(onClick = { result = simpleCalculate(expression) }, modifier = Modifier.fillMaxWidth()) { Text("=") }
            }
        }
    }
}

private fun simpleCalculate(raw: String): String {
    return try {
        val expression = raw.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "")
        if (expression.isBlank()) return ""
        val parser = ExpressionParser(expression)
        val value = parser.parse()
        if (!value.isFinite()) "Error" else "%.4f".format(value).trimEnd('0').trimEnd('.')
    } catch (_: Exception) {
        "Error"
    }
}

private class ExpressionParser(private val input: String) {
    private var pos = 0

    fun parse(): Double {
        val value = parseExpression()
        if (pos != input.length) throw IllegalArgumentException("Unexpected input")
        return value
    }

    private fun parseExpression(): Double {
        var value = parseTerm()
        while (pos < input.length) {
            value = when (input[pos]) {
                '+' -> { pos++; value + parseTerm() }
                '-' -> { pos++; value - parseTerm() }
                else -> return value
            }
        }
        return value
    }

    private fun parseTerm(): Double {
        var value = parseFactor()
        while (pos < input.length) {
            value = when (input[pos]) {
                '*' -> { pos++; value * parseFactor() }
                '/' -> { pos++; val divisor = parseFactor(); if (divisor == 0.0) throw ArithmeticException(); value / divisor }
                else -> return value
            }
        }
        return value
    }

    private fun parseFactor(): Double {
        if (pos >= input.length) throw IllegalArgumentException("Missing number")
        if (input[pos] == '+') { pos++; return parseFactor() }
        if (input[pos] == '-') { pos++; return -parseFactor() }
        if (input[pos] == '(') {
            pos++
            val value = parseExpression()
            if (pos >= input.length || input[pos] != ')') throw IllegalArgumentException("Missing )")
            pos++
            return value
        }
        val start = pos
        var dots = 0
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
            if (input[pos] == '.') dots++
            if (dots > 1) throw IllegalArgumentException("Invalid number")
            pos++
        }
        if (start == pos) throw IllegalArgumentException("Number expected")
        return input.substring(start, pos).toDouble()
    }
}


@Composable
private fun Result(result: TestResult, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Test Result", onBack)
        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${result.marks} / ${result.totalMarks}", color = White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                        Text("${result.accuracy}% Accuracy", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Time: ${formatTime(result.timeTakenSeconds)}", color = Muted, fontSize = 12.sp)
                    }
                }
                CardBox("Correct", "${result.correct}", Icons.Default.CheckCircle)
                CardBox("Wrong", "${result.wrong} • Negative marking applied", Icons.Default.Cancel)
                CardBox("Skipped", "${result.skipped}", Icons.Default.RemoveCircleOutline)
                CardBox("Attempted", "${result.attempted}/${result.totalMarks / 4}", Icons.Default.Quiz)
                CardBox("Performance", "Result generated from actual answer selections", Icons.Default.BarChart)
                Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to Tests") }
            }
        }
    }
}

@Composable
private fun SearchField(hint: String, value: String = "", onSearch: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onSearch, placeholder = { Text(hint, color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Purple2) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF393254), focusedBorderColor = Purple))
}

@Composable
private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier, click: () -> Unit) {
    Card(modifier.height(92.dp).clickable { click() }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp)); Spacer(Modifier.height(5.dp)); Text(title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
    }
}

@Composable
private fun CardBox(title: String, subtitle: String = "", icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.AutoAwesome, click: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).then(if (click != null) Modifier.clickable { click() } else Modifier), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Purple.copy(alpha = 0.16f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Purple2) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); if (subtitle.isNotEmpty()) Text(subtitle, color = Muted, fontSize = 12.sp) }
            if (click != null) Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun Section(title: String) { Text(title, color = Purple2, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }

@Composable
private fun OptionCard(text: String, selected: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = if (selected) Purple.copy(alpha = 0.22f) else Surface), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Purple2)); Text(text, color = White) }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0D0922)) {
        val items = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Quiz, Icons.Default.Insights, Icons.Default.Person)
        val labels = listOf("Home", "Study", "Tests", "Progress", "Profile")
        items.forEachIndexed { i, icon -> NavigationBarItem(selected = i == selected, onClick = { onSelect(i) }, icon = { Icon(icon, null) }, label = { Text(labels[i]) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple2, selectedTextColor = Purple2, indicatorColor = Purple.copy(alpha = 0.16f), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
    }
}
