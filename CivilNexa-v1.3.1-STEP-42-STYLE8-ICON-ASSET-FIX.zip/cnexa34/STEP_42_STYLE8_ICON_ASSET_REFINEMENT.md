# Step 42 — Style 8 Subject Icon Asset Refinement

## Problem
The previous implementation used cropped pieces of the large Style 8 presentation image. Those crops included surrounding tile/background pixels and inconsistent framing, which caused clipping, blur, and inaccurate placement in the Study Material cards.

## Solution
Each subject now uses a dedicated high-resolution Style 8 icon asset extracted as its own 512px resource. The full icon tile is preserved, and the card renders it with `ContentScale.Fit` at a fixed 94dp × 96dp slot.

The subject card no longer wraps the icon in a second rounded container, avoiding double borders and keeping the icon position consistent across all 16 subjects.

## Intended card order
Icon → Subject Name / Status → Modules → Progress → Chapter Count → Chevron

## Content phase
No chapter-by-chapter educational content is being bulk-loaded in this step. Content population remains the final phase after structure and UI/UX are approved.
