# Money Flow V75 — One-Path Sign-Out Backup Fix

- V74 remains the baseline.
- Sign Out now uses the exact same normal Google Drive upload entry point as Manual Backup.
- The existing successful-backup callback then immediately invokes Sign Out.
- Added the missing native `upload_signout` branch as a compatibility safeguard.
- No transaction/profile/security/restore logic was changed.
