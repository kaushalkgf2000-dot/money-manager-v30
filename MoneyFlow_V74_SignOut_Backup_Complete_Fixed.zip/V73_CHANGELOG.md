MoneyFlow V73 — One-Click Sign-Out Backup

Targeted fix based on the supplied sign-out video:
- Tapping Sign Out now starts the latest Google Drive backup immediately; no second “Backup Now” tap is required.
- After the cloud backup reports success, Money Flow immediately signs the account out.
- Manual Backup & Restore → Sync to Google Drive remains a normal backup-only action and does not sign the user out.
- Existing Drive authorization/race protection from V72 is preserved.
- No unrelated app logic was intentionally changed.
