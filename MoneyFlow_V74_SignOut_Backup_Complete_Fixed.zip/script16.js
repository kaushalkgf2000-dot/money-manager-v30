
/* V31 — COMPLETE EXPORT FIELDS FIX
   Excel and PDF exports now preserve every transaction detail:
   Date, Type, Amount, Balance, Category, Description, Remark,
   Payment Mode and Other.  Export-only patch; transaction/security logic
   remains untouched.
*/
(function(){
  function mm31ReadArray(key){
    try{
      const v=JSON.parse(localStorage.getItem(key)||"[]");
      return Array.isArray(v)?v:[];
    }catch(e){return[]}
  }

  function mm31ProfileTxs(){
    const ps=mm31ReadArray("money_manager_profiles_v10");
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x&&x.id===id);
    return p&&Array.isArray(p.transactions)?p.transactions.slice():[];
  }

  function mm31LegacyTxs(){
    const a=[];
    try{
      if(typeof txs!=="undefined"&&Array.isArray(txs)) a.push(...txs);
    }catch(e){}
    try{
      const legacy=JSON.parse(localStorage.getItem(typeof KEY!=="undefined"?KEY:"money_manager_v1")||"[]");
      if(Array.isArray(legacy)) a.push(...legacy);
    }catch(e){}
    return a;
  }

  function mm31Text(v){return String(v==null?"":v).trim()}
  function mm31First(obj,keys){
    for(const k of keys){
      if(obj&&obj[k]!==undefined&&obj[k]!==null&&mm31Text(obj[k])!=="") return obj[k];
    }
    return "";
  }

  function mm31Normalize(t, fallback){
    const x=Object.assign({},fallback||{},t||{});
    return {
      id:x.id,
      createdAt:x.createdAt||fallback?.createdAt||"",
      date:mm31First(x,["date"]),
      type:mm31First(x,["type"]),
      amount:Number(x.amount)||0,
      category:mm31First(x,["category"]),
      description:mm31First(x,["description","desc"]),
      remark:mm31First(x,["remark","remarks","note"]),
      mode:mm31First(x,["mode","paymentMode","payment_mode"]),
      other:mm31First(x,["other","otherInfo","other_info"])
    };
  }

  function mm31Same(a,b){
    if(a&&b&&a.id!=null&&b.id!=null&&String(a.id)===String(b.id)) return true;
    return a&&b&&String(a.date||"")===String(b.date||"")&&
      String(a.type||"")===String(b.type||"")&&
      Number(a.amount||0)===Number(b.amount||0)&&
      String(a.category||"")===String(b.category||"");
  }

  function mm31ExportData(){
    const profile=mm31ProfileTxs();
    const legacy=mm31LegacyTxs();
    const out=[];
    const used=new Set();

    profile.forEach(p=>{
      let matchIndex=-1;
      for(let i=0;i<legacy.length;i++){
        if(used.has(i))continue;
        if(mm31Same(p,legacy[i])){matchIndex=i;break;}
      }
      const merged=matchIndex>=0?Object.assign({},p,legacy[matchIndex]):p;
      if(matchIndex>=0)used.add(matchIndex);
      // Prefer whichever source contains the actual field value.
      const n=mm31Normalize(merged,p);
      if(matchIndex>=0){
        const l=mm31Normalize(legacy[matchIndex],p);
        ["description","remark","mode","other","category"].forEach(k=>{
          if(!n[k]&&l[k])n[k]=l[k];
        });
      }
      out.push(n);
    });

    // Include legacy transactions only when they are not already represented
    // in the active profile. This also protects older data during migration.
    legacy.forEach((l,i)=>{
      if(used.has(i))return;
      const exists=out.some(o=>mm31Same(o,l));
      if(!exists)out.push(mm31Normalize(l));
    });

    // Preserve the exact transaction order used by the app/Excel export.
    // Do not sort by date or createdAt here: same data, same sequence in
    // both Excel and PDF exports.
    return out;
  }

  function mm31Range(){
    const from=document.getElementById("pdfFrom")?.value||"";
    const to=document.getElementById("pdfTo")?.value||"";
    if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
    if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }

  function mm31Filtered(){
    const r=mm31Range();if(!r)return null;
    return mm31ExportData().filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
  }

  window.exportExcel=function(){
    const data=mm31Filtered();if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    let balance=0;
    const rows=[["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"]];
    data.forEach(t=>{
      balance+=t.type==="CREDIT"?t.amount:-t.amount;
      rows.push([t.date,t.type,t.amount,balance,t.category,t.description,t.remark,t.mode,t.other]);
    });
    const sheetRows=rows.map((r,rowIndex)=>`<row>${r.map((v,i)=>((rowIndex>0)&&(i===2||i===3))?xlsxNumber(Number.isFinite(Number(v))?Number(v):0):xlsxText(v)).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
    const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([
      {name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},
      {name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},
      {name:"xl/worksheets/sheet1.xml",data:sheet}
    ]);
    downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions.xlsx");
  };

  window.exportPDF=function(){
    const data=mm31Filtered();if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const r=mm31Range();
    const from=r.from||data[0].date;
    const to=r.to||data[data.length-1].date;
    let income=0,expense=0,balance=0;
    data.forEach(t=>{
      const a=Number(t.amount)||0;
      if(t.type==="CREDIT")income+=a;else expense+=a;
      balance+=t.type==="CREDIT"?a:-a;
    });
    downloadBlob(window.mm31MakeTransactionTablePDF(data,from,to,income,expense,balance),`money_transactions_${from}_to_${to}.pdf`);
  };
})();
