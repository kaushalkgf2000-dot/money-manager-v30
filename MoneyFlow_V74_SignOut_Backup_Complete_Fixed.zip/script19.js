
/* V35 — SINGLE SOURCE EXPORT FIX
   Final override: read the exact date controls at click time and use the live
   transaction array rendered by the app. No profile/legacy merging is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function dateKey(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return m[1]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[3]).padStart(2,"0");
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return m[3]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[1]).padStart(2,"0");
    return "";
  }
  function selectedRange(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=dateKey(f&&f.value),to=dateKey(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function liveTransactions(){
    let a=[];
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))a=txs.slice()}catch(e){}
    return a.map(function(x,i){
      return {id:x&&x.id!=null?x.id:i,date:dateKey(x&&x.date),type:text(x&&x.type).toUpperCase(),amount:Number(x&&x.amount)||0,
        balance:Number.isFinite(Number(x&&x.balance))?Number(x.balance):null,category:text(x&&x.category),description:text(x&&x.description||x&&x.desc),remark:text(x&&x.remark||x&&x.remarks||x&&x.note),mode:text(x&&x.mode||x&&x.paymentMode||x&&x.payment_mode),other:text(x&&x.other||x&&x.otherInfo||x&&x.other_info),createdAt:text(x&&x.createdAt)};
    }).filter(function(x){return x.date&&x.amount>0&&(x.type==="CREDIT"||x.type==="EXPENSE"||x.type==="DEBIT");})
      .sort(function(a,b){return a.date.localeCompare(b.date)||(a.createdAt.localeCompare(b.createdAt))||(Number(a.id)||0)-(Number(b.id)||0)});
  }
  function pack(){
    const r=selectedRange(); if(!r)return null;
    const all=liveTransactions();
    const data=all.filter(function(x){return (!r.from||x.date>=r.from)&&(!r.to||x.date<=r.to)});
    return {from:r.from,to:r.to,all:all,data:data};
  }
  function opening(all,from){
    if(!from)return 0;
    const before=all.filter(function(x){return x.date<from;});
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(last.balance!==null)return last.balance;
    let b=0;before.forEach(function(x){b+=x.type==="CREDIT"?x.amount:-x.amount});return b;
  }
  function calc(p){
    let b=opening(p.all,p.from),w=0,d=0;
    const rows=p.data.map(function(t){
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b];
    });
    return {rows:rows,opening:opening(p.all,p.from),withdrawals:w,deposits:d,closing:b};
  }
  function xesc(s){return text(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;")}
  function xtext(v){return '<c t="inlineStr"><is><t>'+xesc(v)+'</t></is></c>'}
  function xnum(v){return '<c t="n"><v>'+String(Number(v)||0)+'</v></c>'}
  function makeXlsx(p){
    const c=calc(p),rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    c.rows.forEach(function(r){rows.push([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8]])});
    rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",c.opening,"TOTAL WITHDRAWALS",c.withdrawals,"TOTAL DEPOSITS",c.deposits,"CLOSING BALANCE",c.closing,"No. of Transactions",p.data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map(function(row,ri){return '<row>'+row.map(function(v,i){const numeric=(ri>0&&ri<=p.data.length&&[6,7,8].indexOf(i)>=0)||(ri===p.data.length+2&&typeof v==="number");return numeric?xnum(v):xtext(v)}).join('')+'</row>'}).join('');
    const sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+xml+'</sheetData></worksheet>';
    const wb='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const rel='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const root='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const ct='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function makePdf(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=function(v){return text(v).replace(/[^\x20-\x7E]/g,"?")},esc=function(v){return pdfEscape(safe(v))};
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";v.split(/\s+/).forEach(function(q){if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}});if(cur)a.push(cur);return a.length?a:[""]}
    function rr(vals){const cells=vals.map(function(v,i){return wrap(v,colW[i])});return {cells:cells,h:Math.max(18,Math.max.apply(null,cells.map(function(z){return z.length}))*lh+4)}}
    const prepared=c.rows.map(function(r){return rr([r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)])});
    const pages=[];let pg=[],y=86;prepared.forEach(function(r){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=function(o){objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach(function(page,pi){let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(p.from+" to "+p.to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,vals,bold){s+="0.75 w\n0 0 0 RG\n"+x+" "+(y-h)+" "+w+" "+h+" re S\nBT\n/F1 "+(bold?7.2:fs)+" Tf\n";vals.forEach(function(t,i){s+="1 0 0 1 "+(x+2.5)+" "+(y-2.5-7-i*lh)+" Tm ("+esc(t)+") Tj\n"});s+="ET\n"}
      let x=M;heads.forEach(function(h,i){cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(function(r){x=M;r.cells.forEach(function(cc,i){cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (ACCOUNT SUMMARY) Tj\nET\n";yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[c.opening.toFixed(2),c.withdrawals.toFixed(2),c.deposits.toFixed(2),c.closing.toFixed(2),String(p.data.length)];x=M;labs.forEach(function(q,i){cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach(function(q,i){cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (******************* END OF REPORT *******************) Tj\nET\n"}
      s+="Q";cids.push(add("<< /Length "+s.length+" >>\nstream\n"+s+"\nendstream"));pids.push(null);
    });
    const pagesId=add("PAGES");pages.forEach(function(_,i){pids[i]=add("<< /Type /Page /Parent "+pagesId+" 0 R /MediaBox [0 0 "+W+" "+H+"] /Resources << /Font << /F1 "+font+" 0 R >> >> /Contents "+cids[i]+" 0 R >>")});objs[pagesId-1]="<< /Type /Pages /Kids ["+pids.map(function(x){return x+" 0 R"}).join(" ")+"] /Count "+pids.length+" >>";const cat=add("<< /Type /Catalog /Pages "+pagesId+" 0 R >>");let pdf="%PDF-1.4\n",offs=[0];objs.forEach(function(o,i){offs[i+1]=pdf.length;pdf+=(i+1)+" 0 obj\n"+o+"\nendobj\n"});const xr=pdf.length;pdf+="xref\n0 "+(objs.length+1)+"\n0000000000 65535 f \n";for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+="trailer\n<< /Size "+(objs.length+1)+" /Root "+cat+" 0 R >>\nstartxref\n"+xr+"\n%%EOF";return new Blob([pdf],{type:"application/pdf"});
  }
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions_"+p.from+"_to_"+p.to+".xlsx")};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(makePdf(p),"money_transactions_"+p.from+"_to_"+p.to+".pdf")};
})();

/* Money Flow V72 — targeted Sign-Out backup race fix. V71 baseline preserved.
   Local/offline backup is preserved. Google Drive appDataFolder is the cloud copy.
   Cloud backup is account-scoped and intentionally excludes PIN/recovery/security credentials.
*/
(function(){
  let backupTimer=0, cloudTimer=0;
  let cloudSyncSuppressed=true;
  // Google Drive is the only financial cloud backup provider.
  // Firebase remains only for authentication/analytics.
  let autoReloadAfterCloudWrite=false;
  const CLOUD_EXCLUDE=new Set([
    'money_manager_edit_security_v1','mm_global_pin','globalPin','globalPinHash','pinHash'
  ]);
  function cloudSafeValue(k,v){
    if(k==='money_manager_profiles_v10'){
      try{
        const ps=JSON.parse(v);
        if(Array.isArray(ps)) return JSON.stringify(ps.map(p=>{
          const q={}; Object.keys(p||{}).forEach(x=>{if(x!=='security')q[x]=p[x]}); return q;
        }));
      }catch(e){}
    }
    return v;
  }
  function collect(includeSecurity){
    const data={version:3,app:'PaisaFlow',createdAt:new Date().toISOString(),storage:{}};
    // V49: cloud backup is strictly scoped to the currently authenticated
    // Firebase account. Never upload the device's other account namespaces.
    const ACCOUNT_KEYS=new Set([
      'money_manager_v1','money_manager_profiles_v10','money_manager_active_profile_v10',
      'money_manager_config','activeProfileId','currentProfileId','money_manager_profile_v1'
    ]);
    try{
      ACCOUNT_KEYS.forEach(k=>{
        const v=localStorage.getItem(k);
        if(v!==null && (includeSecurity || !CLOUD_EXCLUDE.has(k)))data.storage[k]=cloudSafeValue(k,v);
      });
    }catch(e){}
    return data;
  }
  function saveNative(){
    try{if(window.AndroidBackup&&AndroidBackup.saveBackupSnapshot){AndroidBackup.saveBackupSnapshot(JSON.stringify(collect(true)));return true}}catch(e){}
    return false;
  }
  function schedule(){clearTimeout(backupTimer);backupTimer=setTimeout(saveNative,900)}
  function scheduleCloud(){
    if(cloudSyncSuppressed)return;
    clearTimeout(cloudTimer);
    // One short debounce groups the several localStorage writes made by a
    // single UI action, while still sending the new transaction promptly.
    cloudTimer=setTimeout(function(){
      try{
        if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
          AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));
        }
      }catch(e){}
    },250);
  }
  // Explicit entry point for transaction/profile changes. Do not rely only on
  // monkey-patching Storage.prototype: WebView/localStorage implementations
  // can differ between Android versions.
  window.pfScheduleCloudSync=function(){try{scheduleCloud()}catch(e){}};
  window.pfCloudSyncNow=function(){
    if(cloudSyncSuppressed)return;
    try{
      if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
        AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));
      }
    }catch(e){}
  };
  window.mfBackupNow=function(){
    const localOk=saveNative();
    try{
      if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
        AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));
      }else alert('Cloud backup service is not available on this build.');
    }catch(e){alert('Cloud backup failed: '+e.message)}
    try{if(window.AndroidBackup&&AndroidBackup.exportBackupFile){AndroidBackup.exportBackupFile(JSON.stringify(collect(true)),'money_flow_backup_'+new Date().toISOString().slice(0,10)+'.json');}}
    catch(e){}
    return localOk;
  };
  window.mfOpenBackup=function(){
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    // Identify the currently selected Profile / Mode only. Never display the
    // name belonging to the profile that originally created the cloud snapshot.
    try{
      const ps=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');
      const aid=localStorage.getItem('money_manager_active_profile_v10') || localStorage.getItem('activeProfileId') || localStorage.getItem('currentProfileId') || '';
      const ap=Array.isArray(ps)?(ps.find(x=>x&&x.id===aid)||ps[0]):null;
      const badge=document.getElementById('mfBackupAccount');
      if(badge&&ap)badge.textContent=ap.name||'My Money';
    }catch(e){}
    const m=document.getElementById('mfBackupModal');if(m)m.style.display='block';
    const st=document.getElementById('mfBackupStatus');
    if(st)st.textContent='Checking cloud backup status…';
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.getCloudStatus){AndroidCloudBackup.getCloudStatus();}else if(st)st.textContent='Cloud backup is not available on this build.';}catch(e){if(st)st.textContent='Cloud backup status unavailable.'}
  };
  window.mfCloudStatusResult=function(text){const st=document.getElementById('mfBackupStatus');if(st)st.textContent=text;};
  window.mfCloudBackupResult=function(ok,msg){
    if(pendingLogoutAfterBackup){
      const logoutStatus=el('mfLogoutBackupStatus');
      const logoutButton=el('mfLogoutBackupAction');
      if(ok){
        clearTimeout(logoutBackupWatchdog);
        // Two-step safety flow: backup success must NOT sign the user out automatically.
        // Keep the account signed in and explicitly require a second tap.
        pendingLogoutAfterBackup=false;
        try{sessionStorage.setItem('mf_logout_backup_confirmed','1')}catch(e){}
        if(logoutStatus)logoutStatus.textContent='✓ Backup completed successfully. Your latest data is safely backed up. You can now sign out.';
        if(logoutButton){logoutButton.disabled=false;logoutButton.textContent='🚪 Sign Out';logoutButton.onclick=window.mfConfirmSignOut;}
      }else{
        clearTimeout(logoutBackupWatchdog);
        pendingLogoutAfterBackup=false;
        try{sessionStorage.removeItem('mf_logout_backup_confirmed')}catch(e){}
        if(logoutStatus)logoutStatus.textContent='Backup could not be completed, so you are still signed in. '+(msg||'Please try again.');
      }
      return;
    }
    const st=document.getElementById('mfBackupStatus');
    // Automatic sync is intentionally silent. Manual Backup & Restore can
    // still show its status inside the backup screen.
    if(st && !autoReloadAfterCloudWrite)st.textContent=msg;
    if(ok) try{if(typeof logAction==='function')logAction('cloud_backup_success')}catch(e){}
    if(autoReloadAfterCloudWrite){
      autoReloadAfterCloudWrite=false;
      cloudSyncSuppressed=false;
      try{
        const em=String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase();
        const mk='pf_auto_cloud_sync_done_'+(em||'signed_in');
        sessionStorage.setItem(mk,'1');
      }catch(e){}
      setTimeout(function(){location.reload()},120);
    }
  };
  window.mfRestoreFromCloud=function(){
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return;}}
    catch(e){}
    alert('Cloud restore is not available on this build.');
  };
  let autoSync=false;
  // Preserve the profile the user was actually using before an automatic
  // post-auth cloud restore. The cloud snapshot must not choose the UI profile
  // on the user's behalf when the app is reopened.
  let autoSyncPreservedProfileId='';
  let autoSyncPreservedProfileIdLegacy='';
  window.mfAutoSyncAfterAuth=function(){
    // Existing Google users get a silent cloud restore/sync shortly after login.
    // A small delay lets Firebase/Google authentication and the WebView settle
    // before Drive authorization is requested.
    try{
      autoSyncPreservedProfileId=localStorage.getItem('money_manager_active_profile_v10')||'';
      autoSyncPreservedProfileIdLegacy=localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId')||'';
    }catch(e){autoSyncPreservedProfileId='';autoSyncPreservedProfileIdLegacy='';}
    let accountMarker='';
    try{
      accountMarker=String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase();
      if(!accountMarker && window.AndroidAuth&&AndroidAuth.getEmail)accountMarker=String(AndroidAuth.getEmail()||'').trim().toLowerCase();
    }catch(e){}
    const markerKey='pf_auto_cloud_sync_done_'+(accountMarker||'signed_in');
    try{if(sessionStorage.getItem(markerKey)==='1')return}catch(e){}

    clearTimeout(cloudTimer);
    cloudSyncSuppressed=true;
    autoSync=true;
    autoReloadAfterCloudWrite=false;

    // Do not mark the operation complete until it has actually reached the
    // cloud success callback. This allows a failed Drive authorization/network
    // attempt to be retried instead of waiting for an app restart.
    const run=function(){
      try{
        if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){
          AndroidCloudBackup.restoreCloudBackup();
          return;
        }
      }catch(e){}
      autoSync=false;
      cloudSyncSuppressed=false;
    };
    // Required post-login automatic synchronization window: about 10 seconds.
    clearTimeout(window.__mfAutoSyncTimer);
    window.__mfAutoSyncTimer=setTimeout(run,10000);
  };
  function mfShowCloudMessage(text){
    const st=document.getElementById('mfBackupStatus');
    if(st)st.textContent=text;
  }
  window.mfCloudRestoreResult=function(ok,payload){
    if(!ok){
      if(autoSync){
        // Only a genuinely missing cloud backup should fall back to publishing
        // the current local state. Network/auth/API failures must NEVER overwrite
        // an existing cloud backup.
        const missing=!payload || /No Google Drive backup found/i.test(String(payload));
        if(missing){
          autoSync=false;
          try{
            if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
              autoReloadAfterCloudWrite=true;
              AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));
              return;
            }
          }catch(e){}
          cloudSyncSuppressed=false;
          return;
        }
        // Keep local data untouched and retry once after a short delay.
        clearTimeout(window.__mfAutoSyncRetryTimer);
        window.__mfAutoSyncRetryTimer=setTimeout(function(){
          try{if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return;}}catch(e){}
          autoSync=false;cloudSyncSuppressed=false;
        },8000);
        return;
      }
      mfShowCloudMessage(payload||'Restore could not be completed. Please try again.');
      return;
    }
    try{
      const p=typeof payload==='string'?JSON.parse(payload):payload;
      if(!p||!p.storage)throw new Error('Invalid cloud backup');
      if(!autoSync && !confirm('Restore this cloud backup? Current transaction/profile data will be replaced. Your existing PIN/security settings will be kept.')){
        cloudSyncSuppressed=false;
        return;
      }
      const keys=Object.keys(p.storage);
      if(!keys.length)throw new Error('Cloud backup is empty');

      // MANUAL RESTORE FIX: restoring a cloud snapshot must NEVER switch the
      // user to the profile that happened to be active when that snapshot was
      // created. Keep the profile/mode the user is currently viewing and only
      // refresh that profile's restored data. Automatic post-auth sync keeps its
      // existing account-scoped behavior.
      const manualActiveProfileId = !autoSync ? (localStorage.getItem('money_manager_active_profile_v10') || '') : '';
      const manualActiveProfileIdLegacy = !autoSync ? (localStorage.getItem('activeProfileId') || localStorage.getItem('currentProfileId') || '') : '';
      // For automatic post-auth restore, keep the profile that was active before
      // the restore as well. Cloud data must never silently switch the UI to the
      // profile that happened to be active when the backup was created.
      const restoreActiveProfileId = !autoSync ? manualActiveProfileId : autoSyncPreservedProfileId;
      const restoreActiveProfileIdLegacy = !autoSync ? manualActiveProfileIdLegacy : autoSyncPreservedProfileIdLegacy;
      // SECURITY PRESERVATION: PIN/recovery/biometric state belongs to the
      // profile currently on this device. It is intentionally NOT stored in
      // Google Drive. Capture the active profile security state before any
      // cloud data is merged so restore can never turn an existing PIN into
      // a fresh "Create PIN" state.
      let preservedActiveSecurity=null;
      try{
        const localProfiles=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');
        const activeForSecurity=restoreActiveProfileId || localStorage.getItem('money_manager_active_profile_v10') || '';
        const localActive=Array.isArray(localProfiles)?localProfiles.find(x=>x&&x.id===activeForSecurity):null;
        if(localActive&&localActive.security){
          preservedActiveSecurity=JSON.parse(JSON.stringify(localActive.security));
        }
      }catch(e){}
      const profileKey='money_manager_profiles_v10';
      if(keys.includes(profileKey)){
        let incoming=[]; let current=[];
        try{incoming=JSON.parse(p.storage[profileKey]||'[]')}catch(e){}
        try{current=JSON.parse(localStorage.getItem(profileKey)||'[]')}catch(e){}
        if(Array.isArray(incoming)){
          const byId={}; current.forEach(x=>{if(x&&x.id!=null)byId[String(x.id)]=x});
          const byName={}; current.forEach(x=>{if(x&&x.name)byName[String(x.name).trim().toLowerCase()]=x});
          const used=new Set();
          const merged=incoming.map(cloudProfile=>{
            const idMatch=cloudProfile&&cloudProfile.id!=null?byId[String(cloudProfile.id)]:null;
            const nameMatch=!idMatch&&cloudProfile&&cloudProfile.name?byName[String(cloudProfile.name).trim().toLowerCase()]:null;
            const localProfile=idMatch||nameMatch;
            if(localProfile)used.add(String(localProfile.id));
            const out={...(cloudProfile||{})};
            if(localProfile&&localProfile.security)out.security=localProfile.security;
            const cloudTx=Array.isArray(out.transactions)?out.transactions.map(t=>({...t})):[];
            const localTx=localProfile&&Array.isArray(localProfile.transactions)?localProfile.transactions:[];
            const txById={}; cloudTx.forEach(t=>{if(t&&t.id!=null)txById[String(t.id)]=t});
            localTx.forEach(t=>{if(t&&t.id!=null&&!txById[String(t.id)])cloudTx.push({...t})});
            cloudTx.sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||(new Date(b.createdAt||0)-new Date(a.createdAt||0)));
            out.transactions=cloudTx;
            if(localProfile&&localProfile.config&&!out.config)out.config=localProfile.config;
            return out;
          });
          current.forEach(localProfile=>{
            if(localProfile&&localProfile.id!=null&&!used.has(String(localProfile.id))){
              // Preserve local-only profiles so a restore cannot silently delete
              // another workspace on the same device.
              merged.push(localProfile);
            }
          });
          // IMPORTANT: the currently selected profile keeps its device-local
          // security state even if the cloud snapshot was created without the
          // security object (which is intentional for privacy) or its profile
          // identity cannot be matched by id/name. Transactions/data come from
          // the cloud; PIN/recovery/biometric settings stay local.
          if(preservedActiveSecurity && restoreActiveProfileId){
            const activeMerged=merged.find(x=>x&&x.id===restoreActiveProfileId);
            if(activeMerged) activeMerged.security=preservedActiveSecurity;
          }
          localStorage.setItem(profileKey,JSON.stringify(merged));
        }else{
          localStorage.setItem(profileKey,p.storage[profileKey]);
        }
      }
      // Final guard: after every restore path, force the active profile's
      // existing device-local security object back into the profile store.
      if(preservedActiveSecurity && restoreActiveProfileId){
        try{
          const ps=JSON.parse(localStorage.getItem(profileKey)||'[]');
          if(Array.isArray(ps)){
            const ap=ps.find(x=>x&&x.id===restoreActiveProfileId);
            if(ap){ap.security=preservedActiveSecurity;localStorage.setItem(profileKey,JSON.stringify(ps));}
          }
        }catch(e){}
      }
      keys.forEach(k=>{
        // IMPORTANT: money_manager_profiles_v10 has already been merged above.
        // Do NOT write the raw cloud profile list back here, because the cloud
        // copy intentionally contains NO security object. Doing so would erase
        // the current device-local PIN/recovery/biometric state immediately
        // after we preserved it in the merged profile list.
        if(k===profileKey)return;
        // Manual restore must not overwrite the current profile pointer from
        // the cloud snapshot. That pointer belongs to the profile used when
        // the backup was created (e.g. Mode 2) and could otherwise switch the
        // UI away from the profile the user is currently on (e.g. Mode 3).
        if(!CLOUD_EXCLUDE.has(k)){
          // The active-profile pointer is device/UI state, not cloud data.
          // Never let a backup created under another profile change the profile
          // that the user is currently using, including automatic post-auth restore.
          if(k==='money_manager_active_profile_v10'||k==='activeProfileId'||k==='currentProfileId')return;
          localStorage.setItem(k,p.storage[k]);
        }
      });

      // Re-align the legacy transaction store with the profile that was active
      // BEFORE this manual restore. Never fall back to the cloud's active
      // profile or to the first profile during a manual restore.
      try{
        const ps=JSON.parse(localStorage.getItem(profileKey)||'[]');
        let aid=restoreActiveProfileId;
        if(!aid) aid=restoreActiveProfileIdLegacy;
        const ap=aid ? ps.find(x=>x&&x.id===aid) : null;
        if(ap){
          // Re-assert the device-selected profile after both manual and automatic
          // restores. Its transactions are the data shown by the dashboard.
          localStorage.setItem('money_manager_active_profile_v10',ap.id);
          localStorage.setItem(typeof KEY!=='undefined'?KEY:'money_manager_v1',JSON.stringify(Array.isArray(ap.transactions)?ap.transactions:[]));
        }else if(restoreActiveProfileId){
          // If the cloud snapshot does not contain the current profile, preserve
          // the current profile pointer instead of falling back to the cloud's profile.
          localStorage.setItem('money_manager_active_profile_v10',restoreActiveProfileId);
        }
        if(restoreActiveProfileIdLegacy){
          localStorage.setItem('activeProfileId',restoreActiveProfileIdLegacy);
          localStorage.setItem('currentProfileId',restoreActiveProfileIdLegacy);
        }
      }catch(e){}
      try{saveNative()}catch(e){}
      if(autoSync){
        // Restore is complete locally. Now publish the merged state and wait
        // for Google Drive's success/failure callback before reloading the UI.
        autoSync=false;
        cloudSyncSuppressed=true;
        try{
          if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
            autoReloadAfterCloudWrite=true;
            AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));
            return;
          }
        }catch(e){}
        autoReloadAfterCloudWrite=false;
        cloudSyncSuppressed=false;
        setTimeout(function(){location.reload()},100);
        return;
      }
      cloudSyncSuppressed=false;
      mfShowCloudMessage('✓ Restore completed successfully. Your current profile and security settings were kept. Refreshing…');
      setTimeout(function(){location.reload()},700);
    }catch(e){
      cloudSyncSuppressed=false;
      if(autoSync)autoSync=false;
      mfShowCloudMessage('Restore could not be completed. Your current data has not been changed. Please try again.');
    }
  };
  window.mfCloseBackup=function(){const m=document.getElementById('mfBackupModal');if(m)m.style.display='none'};
  window.mfRestoreFromFile=function(){try{if(window.AndroidBackup&&AndroidBackup.openBackupFile){AndroidBackup.openBackupFile();return}}catch(e){}alert('Backup file picker is not available on this build.');};
  window.mfApplyBackup=function(json){
    try{
      const p=typeof json==='string'?JSON.parse(json):json;
      if(!p||!p.storage)throw new Error('Invalid backup');
      const keys=Object.keys(p.storage);if(!keys.length)throw new Error('Backup is empty');
      if(!confirm('Restore this Money Flow backup? Current local data will be replaced.'))return;
      keys.forEach(k=>localStorage.setItem(k,p.storage[k]));
      alert('Backup restored successfully. Money Flow will reload.');location.reload();
    }catch(e){alert('Restore failed: '+e.message)}
  };
  // V46 FIX: never auto-restore the legacy device-wide recovery snapshot.
  // That snapshot is not account-scoped, so restoring it at startup can
  // re-introduce another account's transactions into a newly signed-in user.
  // Account-isolated local data is now loaded only by v46Activate(uid).
  // Google Drive account backup is the automatic recovery mechanism.
  window.mfMaybeRestoreNative=function(){ return false; };
  const oldSet=Storage.prototype.setItem;
  Storage.prototype.setItem=function(k,v){
    const r=oldSet.apply(this,arguments);
    if(this===localStorage && k!=='mf_backup_internal'){
      schedule();
      if(!cloudSyncSuppressed)scheduleCloud();
    }
    return r;
  };
  window.addEventListener('load',function(){
    setTimeout(function(){
      saveNative();
      mfMaybeRestoreNative();
    },1200);
  });
})();


/* Money Flow Firebase Account / Login */
(function(){
  let mode='login', autoSyncPending=false, authGateActive=false, pendingLogoutAfterBackup=false;
  function el(id){return document.getElementById(id)}
  function msg(text,ok){const x=el('mfAccountMsg');if(!x)return;x.textContent=text||'';x.className='mf-account-msg '+(ok?'ok':'err')}
  function showVerification(message,email){
    const panel=el('mfEmailVerificationPanel');
    const text=el('mfEmailVerificationText');
    const signedOut=el('mfAccountSignedOut');
    const note=el('mfAccountRequiredNote');
    if(signedOut)signedOut.style.display='block';
    if(panel)panel.style.display='block';
    if(note)note.style.display='none';
    if(text)text.textContent=(message||'Your email address is not verified yet.')+(email?' Verification email/account: '+email+'.':'');
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').classList.remove('active');
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').classList.remove('active');
    ['mfAccountNameWrap','mfAccountConfirmWrap','mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='none'});
  }
  function hideVerification(){
    const panel=el('mfEmailVerificationPanel');
    if(panel)panel.style.display='none';
    ['mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='block'});
    if(el('mfAccountNameWrap'))el('mfAccountNameWrap').style.display='none';
    if(el('mfAccountConfirmWrap'))el('mfAccountConfirmWrap').style.display='none';
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').style.display='block';
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').style.display='block';
  }
  function signedIn(email,name){
    el('mfAccountSignedOut').style.display='none';
    el('mfAccountSignedIn').style.display='block';
    el('mfAccountEmail').textContent=email||'';
    el('mfAccountName').textContent=name||'Money Flow Account';
    const b=el('mfAccountSignedMsg');if(b)b.textContent='Signed in. Cloud Backup is linked to this account.';
    const badge=el('mfBackupAccount');
    if(badge){
      try{
        const ps=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');
        const aid=localStorage.getItem('money_manager_active_profile_v10') || localStorage.getItem('activeProfileId') || localStorage.getItem('currentProfileId') || '';
        const ap=Array.isArray(ps)?(ps.find(x=>x&&x.id===aid)||ps[0]):null;
        badge.textContent=ap&&ap.name ? ap.name : (email||'Signed in');
      }catch(e){badge.textContent=email||'Signed in';}
    }
    try{localStorage.setItem('mf_account_mode','account');localStorage.setItem('mf_account_email',String(email||'').trim().toLowerCase())}catch(e){}
    if(authGateActive){authGateActive=false;const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}}
  }
  function signedOut(){
    el('mfAccountSignedOut').style.display='block';
    el('mfAccountSignedIn').style.display='none';
    const badge=el('mfBackupAccount');if(badge)badge.textContent='Sign in with Google';
    try{localStorage.removeItem('mf_account_email');for(let i=sessionStorage.length-1;i>=0;i--){const k=sessionStorage.key(i);if(k&&k.indexOf('pf_auto_cloud_sync_done_')===0)sessionStorage.removeItem(k)}}catch(e){}
    if(authGateActive){const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}}
  }
  window.mfAccountMode=function(m){
    hideVerification();
    mode=m;
    const signup=m==='signup';
    el('mfAccountLoginTab').classList.toggle('active',!signup);
    el('mfAccountSignupTab').classList.toggle('active',signup);
    el('mfAccountNameWrap').style.display=signup?'block':'none';
    el('mfAccountConfirmWrap').style.display=signup?'block':'none';
    el('mfAccountPrimary').textContent=signup?'Create Account':'Login';
    el('mfAccountReset').style.display=signup?'none':'block';
    el('mfAccountPasswordInput').autocomplete=signup?'new-password':'current-password';
    msg('');
  };
  window.mfOpenAccount=function(mandatory){
    authGateActive=!!mandatory;
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    const m=el('mfAccountModal');
    if(m){m.classList.toggle('mf-account-modal-mandatory',authGateActive);m.style.display='block';}
    msg('');
    try{if(window.AndroidAuth&&AndroidAuth.getStatus)AndroidAuth.getStatus();}catch(e){}
  };
  window.mfCloseAccount=function(){if(authGateActive)return;const m=el('mfAccountModal');if(m)m.style.display='none'};
  window.mfContinueGuest=function(){
    if(authGateActive)return;
    try{localStorage.setItem('mf_account_mode','guest')}catch(e){}
    msg('Guest mode enabled. Your data remains on this device.',true);
    setTimeout(mfCloseAccount,450);
  };
  window.mfAccountSubmit=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    const password=el('mfAccountPasswordInput').value||'';
    if(!email){msg('Enter your email address.');return}
    if(mode==='signup') {
      const name=(el('mfAccountNameInput').value||'').trim();
      const confirm=el('mfAccountConfirmInput').value||'';
      if(password.length<6){msg('Password must be at least 6 characters.');return}
      if(password!==confirm){msg('Passwords do not match.');return}
      msg('Creating account…',true);
      try{AndroidAuth.signUp(name,email,password)}catch(e){msg('Account service unavailable.')}
    } else {
      msg('Signing in…',true);
      try{AndroidAuth.signIn(email,password)}catch(e){msg('Account service unavailable.')}
    }
  };
  window.mfGoogleLogin=function(){
    msg('Opening Google Sign-In…',true);
    try{AndroidAuth.signInWithGoogle()}catch(e){msg('Google Sign-In service unavailable.')}
  };
  window.mfAccountReset=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    if(!email){msg('Enter your account email first.');return}
    msg('Sending password reset email…',true);
    try{AndroidAuth.resetPassword(email)}catch(e){msg('Account service unavailable.')}
  };
  window.mfCheckEmailVerification=function(){
    msg('Checking email verification status…',true);
    try{AndroidAuth.checkEmailVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfBackToLogin=function(){
    hideVerification();
    try{AndroidAuth.signOut()}catch(e){}
    window.mfAccountMode('login');
    msg('Please verify your email first, then log in.');
  };
  window.mfAccountLogout=function(){
    pendingLogoutAfterBackup=false;
    try{sessionStorage.removeItem('mf_logout_backup_confirmed')}catch(e){}
    const m=el('mfLogoutBackupModal');
    const st=el('mfLogoutBackupStatus');
    const b=el('mfLogoutBackupAction');
    if(st)st.textContent='Before signing out, create a fresh Google Drive backup. You will remain signed in until you confirm Sign Out after the backup succeeds.';
    if(b){b.textContent='☁️ Backup Now';b.onclick=window.mfBackupAndLogout;}
    if(m)m.style.display='block';
  };
  window.mfCancelLogout=function(){
    clearTimeout(logoutBackupWatchdog);
    pendingLogoutAfterBackup=false;
    try{sessionStorage.removeItem('mf_logout_backup_confirmed')}catch(e){}
    const m=el('mfLogoutBackupModal');if(m)m.style.display='none';
  };
  let logoutBackupWatchdog=0;
  window.mfBackupAndLogout=function(){
    const st=el('mfLogoutBackupStatus');
    const b=el('mfLogoutBackupAction');
    // After a successful backup, the SAME dialog is used for the explicit second tap.
    try{if(sessionStorage.getItem('mf_logout_backup_confirmed')==='1'){window.mfConfirmSignOut();return}}catch(e){}

    // Isolate the sign-out backup from any post-login/automatic cloud operation.
    // The Drive bridge has one pending operation slot, so an overlapping restore
    // or debounced upload can otherwise replace the sign-out upload.
    clearTimeout(cloudTimer);
    clearTimeout(window.__mfAutoSyncTimer);
    clearTimeout(window.__mfAutoSyncRetryTimer);
    autoSync=false;
    autoReloadAfterCloudWrite=false;
    cloudSyncSuppressed=true;
    pendingLogoutAfterBackup=true;
    try{sessionStorage.removeItem('mf_logout_backup_confirmed')}catch(e){}

    if(st)st.textContent='Creating your latest Google Drive backup… Please wait.';
    if(b){b.disabled=true;b.textContent='☁️ Backing Up…';}

    // Safety watchdog: never leave the user stuck on a disabled button forever.
    clearTimeout(logoutBackupWatchdog);
    logoutBackupWatchdog=setTimeout(function(){
      if(!pendingLogoutAfterBackup)return;
      pendingLogoutAfterBackup=false;
      if(b){b.disabled=false;b.textContent='☁️ Backup Now';}
      if(st)st.textContent='Backup is taking too long and has not been confirmed. You are still signed in. Please try again.';
    },40000);

    try{
      try{if(typeof saveNative==='function')saveNative();}catch(e){}
      const payload=JSON.stringify(collect(false));
      if(window.AndroidCloudBackup&&typeof AndroidCloudBackup.uploadCloudBackup==='function'){
        // Defer one event-loop turn so the modal state and the suppressed sync
        // state are committed before the native Drive request starts.
        setTimeout(function(){
          if(!pendingLogoutAfterBackup)return;
          try{AndroidCloudBackup.uploadCloudBackup(payload);}
          catch(e){
            clearTimeout(logoutBackupWatchdog);
            pendingLogoutAfterBackup=false;
            if(b){b.disabled=false;b.textContent='☁️ Backup Now';}
            if(st)st.textContent='Backup could not be started. You are still signed in. Please try again.';
          }
        },50);
      }else{
        clearTimeout(logoutBackupWatchdog);
        pendingLogoutAfterBackup=false;
        if(b){b.disabled=false;b.textContent='☁️ Backup Now';}
        if(st)st.textContent='Google Drive backup is not available. You are still signed in.';
      }
    }catch(e){
      clearTimeout(logoutBackupWatchdog);
      pendingLogoutAfterBackup=false;
      if(b){b.disabled=false;b.textContent='☁️ Backup Now';}
      if(st)st.textContent='Backup could not be started. You are still signed in. Please try again.';
    }
  };
  window.mfConfirmSignOut=function(){
    clearTimeout(logoutBackupWatchdog);
    let confirmed=false;
    try{confirmed=sessionStorage.getItem('mf_logout_backup_confirmed')==='1'}catch(e){}
    if(!confirmed){return;}
    try{sessionStorage.removeItem('mf_logout_backup_confirmed')}catch(e){}
    const m=el('mfLogoutBackupModal');if(m)m.style.display='none';
    try{AndroidAuth.signOut()}catch(e){msg('Account service unavailable.')}
  };
  window.mfResendVerification=function(){
    msg('Sending verification email…',true);
    try{AndroidAuth.resendVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfAuthResult=function(ok,action,message,email,name){
    if(action==='status'){
      const onboardingComplete=localStorage.getItem('money_flow_onboarding_complete_v1')==='1';
      if(message==='signed_in'){
        hideVerification();
        signedIn(email,name);
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      } else if(message==='verify_required'){
        authGateActive=true;
        showVerification('Your email address is not verified yet. Open the verification email and tap its verification link.',email);
        const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      } else if(onboardingComplete){
        authGateActive=true;
        signedOut();
      } else {
        signedOut();
      }
      return;
    }
    if(ok && action==='verify_required'){
      authGateActive=true;
      showVerification(message,email);
      const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      msg(message,true);
      return;
    }
    if(ok && (action==='login'||action==='google'||action==='signup')){
      signedIn(email,name);
      msg(message,true);
      if(action==='login'||action==='google'){
        autoSyncPending=true;
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      }
      return;
    }
    if(ok && action==='logout'){
      signedOut();msg(message,true);return;
    }
    if(ok && action==='reset'){msg(message,true);return}
    if(ok && action==='verify_sent'){msg(message,true);return}
    if(ok && action==='verified'){
      hideVerification();
      authGateActive=false;
      const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}
      msg(message,true);
      try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      return;
    }
    if(!ok && action==='verify_check'){msg(message,false);return}
    msg(message||'Authentication failed.');
  };
  window.addEventListener('load',function(){
    try{
      if(localStorage.getItem('money_flow_onboarding_complete_v1')==='1' && window.AndroidAuth&&AndroidAuth.getStatus) AndroidAuth.getStatus();
    }catch(e){}
  });
})();
