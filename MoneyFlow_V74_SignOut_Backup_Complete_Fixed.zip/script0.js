
const KEY="money_manager_v1";
let txs=JSON.parse(localStorage.getItem(KEY)||"[]");

// Each new transaction gets an exact creation timestamp. Existing V8 transactions
// without one use their stored transaction date as the safe fallback.
txs=txs.map(t=>t.createdAt? t : {...t, createdAt: new Date((t.date||"1970-01-01")+"T23:59:59").toISOString()});
localStorage.setItem(KEY,JSON.stringify(txs));

function transactionCreatedAt(t){
  const d=new Date(t.createdAt || ((t.date||"1970-01-01")+"T23:59:59"));
  return Number.isNaN(d.getTime()) ? new Date(0) : d;
}
// Single source of truth for transaction ordering:
// latest transaction date first; same-date transactions use creation time.
function compareTransactionsLatestFirst(a,b){
  const byDate=String(b.date||"").localeCompare(String(a.date||""));
  if(byDate!==0) return byDate;
  return transactionCreatedAt(b).getTime()-transactionCreatedAt(a).getTime() || Number(b.id||0)-Number(a.id||0);
}
function sortTransactionsLatestFirst(){
  txs.sort(compareTransactionsLatestFirst);
}
function canEditTransaction(t){
  const age=Date.now()-transactionCreatedAt(t).getTime();
  return age>=0 && age < 5*24*60*60*1000;
}
function editTimeLeft(t){
  const left=5*24*60*60*1000-(Date.now()-transactionCreatedAt(t).getTime());
  if(left<=0) return "Edit locked after 5 days";
  const days=Math.floor(left/86400000);
  const hours=Math.floor((left%86400000)/3600000);
  return days>0 ? `Edit available • ${days}d ${hours}h left` : `Edit available • ${hours}h left`;
}

function money(n){return "₹"+Number(n).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}

const DEFAULT_CONFIG={
  creditAmounts:[500,1000,1500,3000,4000,5000],
  expenseAmounts:[50,100,1000,3000],
  creditCategories:["Home Money","Our Income","Friend Gift"],
  expenseCategories:["Food","Travel","Grocery","Other"]
};
let config=JSON.parse(localStorage.getItem("money_manager_config")||"null")||JSON.parse(JSON.stringify(DEFAULT_CONFIG));
function localToday(){
 const d=new Date();
 return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
const addDateEl=document.getElementById("date");
addDateEl.max=localToday();
const editDateEl=document.getElementById("editDate");
if(editDateEl) editDateEl.max=localToday();
addDateEl.value=localToday();
addDateEl.addEventListener("change",()=>{
 const today=localToday();
 if(addDateEl.value>today) addDateEl.value=today;
});
setThisMonth();
updateCategories();

function toggleMenu(){
 const p=document.getElementById("menuPanel");
 p.style.display=p.style.display==="block"?"none":"block";
}
function closeMenu(){document.getElementById("menuPanel").style.display="none"}
function pfOpenWidgets(){
 closeMenu();
 if(window.AndroidWidget && AndroidWidget.requestPinWidget){
   try{ AndroidWidget.requestPinWidget(); return; }catch(e){}
 }
 alert("To add the Money Flow widget, long-press an empty area on your Home screen, choose Widgets, then select Money Flow.");
}
function openCustomization(){
 closeMenu();
 document.getElementById("creditAmounts").value=config.creditAmounts.join(", ");
 document.getElementById("expenseAmounts").value=config.expenseAmounts.join(", ");
 document.getElementById("creditCategories").value=config.creditCategories.join(", ");
 document.getElementById("expenseCategories").value=config.expenseCategories.join(", ");
 document.getElementById("customModal").style.display="block";
}
function closeCustomization(){document.getElementById("customModal").style.display="none"}
function parseAmounts(id){
 return document.getElementById(id).value.split(",").map(x=>Number(x.trim())).filter(x=>Number.isFinite(x)&&x>0);
}
function parseTextList(id){
 return document.getElementById(id).value.split(",").map(x=>x.trim()).filter(Boolean);
}
function saveCustomization(){
 const c=parseAmounts("creditAmounts"), e=parseAmounts("expenseAmounts");
 const cc=parseTextList("creditCategories"), ec=parseTextList("expenseCategories");
 if(!c.length||!e.length||!cc.length||!ec.length){alert("Please keep at least one option in every list.");return}
 config={creditAmounts:c,expenseAmounts:e,creditCategories:cc,expenseCategories:ec};
 localStorage.setItem("money_manager_config",JSON.stringify(config));
 updateCategories();
 updateAmountOptions();
 closeCustomization();
 alert("Customisation saved.");
}
function resetCustomization(){
 config=JSON.parse(JSON.stringify(DEFAULT_CONFIG));
 localStorage.setItem("money_manager_config",JSON.stringify(config));
 updateCategories(); updateAmountOptions(); openCustomization();
}
function updateAmountOptions(){
 const type=document.getElementById("type").value;
 const select=document.getElementById("amountPreset");
 const amounts=type==="CREDIT"?config.creditAmounts:config.expenseAmounts;
 select.innerHTML=amounts.map(n=>`<option value="${n}">₹${Number(n).toLocaleString("en-IN")}</option>`).join("")
   + '<option value="CUSTOM">Custom</option>';
 select.value=amounts[0];
 toggleCustomAmount();
}
function toggleCustomAmount(){
 const custom=document.getElementById("customAmount");
 const isCustom=document.getElementById("amountPreset").value==="CUSTOM";
 custom.style.display=isCustom?"block":"none";
 if(isCustom) custom.focus();
}

function save(){sortTransactionsLatestFirst();localStorage.setItem(KEY,JSON.stringify(txs));render();try{if(window.pfScheduleCloudSync)window.pfScheduleCloudSync()}catch(e){}}
function updateCategories(){
 const type=document.getElementById("type").value;
 const select=document.getElementById("categorySelect");
 const current=select.value;
 const base=type==="CREDIT"?config.creditCategories:config.expenseCategories;
 const categories=[...base.map(x=>[x,x]),["CUSTOM","Custom"]];
 select.innerHTML=categories.map(([v,t])=>`<option value="${v}">${t}</option>`).join("");
 if(categories.some(([v])=>v===current)) select.value=current;
 else select.value=categories[0][0];
 toggleCustomCategory();
 updateAmountOptions();
}
function toggleCustomCategory(){
 const custom=document.getElementById("customCategory");
 custom.style.display=document.getElementById("categorySelect").value==="CUSTOM"?"block":"none";
 if(custom.style.display==="block") custom.focus();
}
document.getElementById("type").addEventListener("change", updateCategories);
document.getElementById("amountPreset").addEventListener("change", toggleCustomAmount);
function addTx(){
 const dateEl=document.getElementById("date");
 const typeEl=document.getElementById("type");
 const amountPresetEl=document.getElementById("amountPreset");
 const customAmountEl=document.getElementById("customAmount");
 const categoryEl=document.getElementById("categorySelect");
 const customCategoryEl=document.getElementById("customCategory");
 const descriptionEl=document.getElementById("description");
 const remarkEl=document.getElementById("remark");
 const modeEl=document.getElementById("mode");
 const otherEl=document.getElementById("other");
 const date=dateEl.value;
 const type=typeEl.value;
 const preset=amountPresetEl.value;
 const amount=preset==="CUSTOM"?Number(customAmountEl.value):Number(preset);
 const selectedCategory=categoryEl.value;
 const customCategory=customCategoryEl.value.trim();
 const category=selectedCategory==="CUSTOM"?customCategory:selectedCategory;
 const today=localToday();
 dateEl.max=today;
 if(!date||date>today){dateEl.value=today;return false}
 if(!Number.isFinite(amount)||amount<=0){alert("Please enter a valid amount.");return false}
 if(!category){alert("Please select or enter a category.");return false}
 const tx={id:Date.now(),createdAt:new Date().toISOString(),date,type,amount,category,
   description:descriptionEl.value.trim(),remark:remarkEl.value.trim(),mode:modeEl.value,other:otherEl.value.trim()};
 txs.push(tx);
 sortTransactionsLatestFirst();
 localStorage.setItem(KEY,JSON.stringify(txs));
 // Keep the active profile in sync as the single source of truth.
 try{
   const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
   const aid=localStorage.getItem("money_manager_active_profile_v10");
   const ap=ps.find(x=>x.id===aid)||ps[0];
   if(ap){ap.transactions=txs;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps))}
 }catch(e){}
 ["customAmount","customCategory","description","remark","other"].forEach(id=>{const el=document.getElementById(id);if(el)el.value=""});
 updateCategories();
 render();
 // Step 2 fix: close the Add Transaction sheet immediately after a successful save.
 if(typeof window.pfCloseAddTransaction==="function") window.pfCloseAddTransaction();
 // Cloud sync is explicitly requested after the transaction is committed.
 try{if(window.pfScheduleCloudSync)window.pfScheduleCloudSync();}catch(e){}
 return true;
}

function render(){
 // Always derive the visible profile identity from the currently active Profile / Mode.
 // After a cloud restore the data can be correct while the static HTML badge would
 // otherwise fall back to the default "My Money" label after location.reload().
 try{
   const _ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
   const _aid=localStorage.getItem("money_manager_active_profile_v10") || localStorage.getItem("activeProfileId") || localStorage.getItem("currentProfileId") || "";
   const _ap=Array.isArray(_ps)?(_ps.find(x=>x&&x.id===_aid)||_ps[0]):null;
   const _badge=document.getElementById("profileBadge");
   if(_badge&&_ap)_badge.textContent=_ap.name||"My Money";
 }catch(_e){}
 sortTransactionsLatestFirst();
 let income=0,expense=0;
 txs.forEach(t=>{if(t.type==="CREDIT")income+=Number(t.amount)||0;else expense+=Number(t.amount)||0});
 const balance=income-expense;
 if(window.AndroidWidget && AndroidWidget.updateStatus){
   try{ AndroidWidget.updateStatus(money(balance), money(expense), money(income)); }catch(e){}
 }
 document.getElementById("income").textContent=money(income);
 document.getElementById("expense").textContent=money(expense);
 document.getElementById("balance").textContent=money(balance);
 const total=income+expense;
 const ip=total?Math.round(income/total*100):0, ep=total?Math.round(expense/total*100):0;
 const ib=document.getElementById("pfIncomeBar"), eb=document.getElementById("pfExpenseBar");
 if(ib)ib.style.width=ip+"%"; if(eb)eb.style.width=ep+"%";
 const iPct=document.getElementById("pfIncomePct"),ePct=document.getElementById("pfExpensePct"),net=document.getElementById("pfNetText");
 if(iPct)iPct.textContent=ip+"%"; if(ePct)ePct.textContent=ep+"%"; if(net)net.textContent="Net position: "+money(balance);
 const list=document.getElementById("list"); if(!list)return; list.innerHTML="";
 const recent=txs.slice(0,5);
 if(!recent.length){list.innerHTML='<div class="pf-empty">No transactions yet. Add your first transaction to see it here.</div>';return}
 recent.forEach(t=>{
  const div=document.createElement("div");div.className="tx";
  div.innerHTML=`<div><div class="tx-title">${escapeHtml(t.category||"Uncategorized")}</div><div class="tx-meta">${t.date} • ${t.type} • ${escapeHtml(t.mode)}${t.description?" • "+escapeHtml(t.description):""}</div>${t.remark?`<div class="tx-meta">Remark: ${escapeHtml(t.remark)}</div>`:""}</div><div class="tx-amt ${t.type==="CREDIT"?"green":"red"}">${t.type==="CREDIT"?"+":"-"}${money(t.amount)}</div>`;
  list.appendChild(div);
 });
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function txMatchesRange(t,from,to){return (!from||t.date>=from)&&(!to||t.date<=to)}
function openHistory(){closeMenu();document.getElementById("historyModal").style.display="block";const d=new Date();document.getElementById("historyMonth").value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;renderHistory()}
function closeHistory(){document.getElementById("historyModal").style.display="none"}
function updateHistoryControls(){const monthly=document.getElementById("historyMode").value==="MONTH";document.getElementById("historyMonthWrap").style.display=monthly?"block":"none";document.getElementById("historyDateWrap").style.display=monthly?"none":"block"}
function renderHistory(){
 const mode=document.getElementById("historyMode").value;let from="",to="";
 if(mode==="MONTH"){
  const m=document.getElementById("historyMonth").value;if(!m)return;from=m+"-01";const [y,mo]=m.split("-").map(Number);to=new Date(y,mo,0).toISOString().slice(0,10);
 }else{from=document.getElementById("historyFrom").value;to=document.getElementById("historyTo").value;if(from&&to&&from>to){document.getElementById("historySummary").textContent="From date cannot be after To date.";document.getElementById("historyList").innerHTML="";return}}
 const data=txs.filter(t=>txMatchesRange(t,from,to)).sort(compareTransactionsLatestFirst);let income=0,expense=0;data.forEach(t=>t.type==="CREDIT"?income+=t.amount:expense+=t.amount);
 document.getElementById("historySummary").textContent=`${data.length} transaction(s) • Credit ₹${income.toFixed(2)} • Expense ₹${expense.toFixed(2)} • Net ₹${(income-expense).toFixed(2)}`;
 const list=document.getElementById("historyList");list.innerHTML="";
 if(!data.length){list.innerHTML='<div class="empty">No transactions found for this period.</div>';return}
 [...data].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).forEach(t=>{
  const div=document.createElement("div");div.className="tx";
  div.innerHTML=`<div><div class="tx-title">${escapeHtml(t.category||"Uncategorized")}</div><div class="tx-meta">${t.date} • ${t.type} • ${escapeHtml(t.mode)}${t.description?" • "+escapeHtml(t.description):""}</div>${t.remark?`<div class="tx-meta">Remark: ${escapeHtml(t.remark)}</div>`:""}</div><div class="tx-amt ${t.type==="CREDIT"?"green":"red"}">${t.type==="CREDIT"?"+":"-"}${money(t.amount)}</div><div class="tx-actions">${canEditTransaction(t)?`<button class="secondary" onclick="v10RequestEdit(${t.id})">✎ Edit</button>`:`<span class="small" style="text-align:center;width:100%">🔒 ${editTimeLeft(t)}</span>`}</div>`;
  list.appendChild(div);
 });
}
function openEdit(id){
 const t=txs.find(x=>x.id===id); if(!t)return;
 const editDate=document.getElementById("editDate");
 if(editDate) editDate.max=localToday();
 if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");render();return;}
 document.getElementById("editId").value=id;
 document.getElementById("editDate").value=t.date;
 document.getElementById("editType").value=t.type;
 document.getElementById("editAmount").value=t.amount;
 document.getElementById("editCategory").value=t.category||"";
 document.getElementById("editMode").value=t.mode||"UPI";
 document.getElementById("editDescription").value=t.description||"";
 document.getElementById("editRemark").value=t.remark||"";
 document.getElementById("editOther").value=t.other||"";
 document.getElementById("editModal").style.display="block";
}

function v10ActiveSecurity(){
 const p = (typeof v109ActiveProfile === "function") ? v109ActiveProfile() : null;
 if(!p) return null;
 p.security = p.security || {mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
 // Migrate any legacy V10 edit PIN into the active profile once, so Edit and Add Transaction
 // always use exactly the same PIN and recovery code.
 if(false){
   try{
     const legacy=null;
     if(legacy && legacy.pinHash){
       p.security.pinHash=legacy.pinHash;
       p.security.recoveryCode=p.security.recoveryCode||legacy.recoveryCode||"";
       const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
       const q=ps.find(x=>x.id===p.id); if(q){q.security=p.security;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}
     }
   }catch(e){}
 }
 return p.security;
}
function v10EditSec(){return v10ActiveSecurity()}
function v10HashPin(pin){let h=2166136261;for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function v10MakeRecovery(){const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}return s}
function v10SaveEditSec(sec){
 const p=(typeof v109ActiveProfile === "function")?v109ActiveProfile():null; if(!p)return;
 p.security=sec; const ps=v109Profiles(); const q=ps.find(x=>x.id===p.id); if(q)q.security=sec; v109SaveProfiles(ps);
 localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:sec.pinHash,recoveryCode:sec.recoveryCode}));
}
function v10FillEdit(id){openEdit(id)}
function v10RequestEdit(id){
 const t=txs.find(x=>x.id===id); if(!t)return;
 if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return;}
 const s=v10ActiveSecurity();
 if(!s || !s.pinHash){
   document.getElementById("editPinGateBody").innerHTML=`<h3>🔐 Create PIN</h3><p>Create one 4–6 digit PIN. The same PIN will be used for <b>Edit</b> and <b>Add Transaction</b>.</p><input id="v10EditNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10EditConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button onclick="v10FinishEditPin(${id})">Create PIN</button><button class="secondary" onclick="v10CancelEditGate()">Cancel</button>`;
 }else{
   document.getElementById("editPinGateBody").innerHTML=`<h3>🔐 Enter PIN</h3><p>Enter your existing profile PIN to edit this transaction.</p><input id="v10EditPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button onclick="v10CheckEditPin(${id})">Continue</button><button class="secondary" onclick="v10ForgotEditPinDirect(${id})">Forgot PIN?</button><button class="secondary" onclick="v10CancelEditGate()">Cancel</button>`;
 }
 document.getElementById("editPinGate").style.display="block";
 setTimeout(()=>{const el=document.getElementById(s&&s.pinHash?"v10EditPinInput":"v10EditNewPin");if(el)el.focus()},0);
}
function v10FinishEditPin(id){
 const a=document.getElementById("v10EditNewPin")?.value||"",b=document.getElementById("v10EditConfirmPin")?.value||"";
 if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return}
 if(a!==b){alert("PIN and Confirm PIN do not match.");return}
 const sec=v10ActiveSecurity()||{}; sec.pinHash=v10HashPin(a); sec.recoveryCode=sec.recoveryCode||v10MakeRecovery(); sec.editPinLost=false;
 v10SaveEditSec(sec);
 document.getElementById("editPinGateBody").innerHTML=`<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">${sec.recoveryCode}</div><p class="v10small">This is the same PIN for Edit and Add Transaction.</p><button onclick="v10ContinueEdit(${id})">Continue to Edit</button>`;
}
function v10ContinueEdit(id){document.getElementById("editPinGate").style.display="none";openEdit(id)}
function v10CheckEditPin(id){
 const s=v10ActiveSecurity(),p=document.getElementById("v10EditPinInput")?.value||"";
 if(!s||!s.pinHash){alert("PIN is not configured. Please create it first.");return}
 if(v10HashPin(p)!==s.pinHash){alert("Incorrect PIN.");return}
 v10ContinueEdit(id);
}
function v10ForgotEditPinDirect(id){
 const s=v10ActiveSecurity(); if(!s||!s.recoveryCode){alert("No Recovery Code is available. Please use Profile / Mode recovery/reset flow.");return}
 const c=prompt("Enter your Recovery Code:"); if(c===null)return;
 if(c.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
 const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");
 if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
 s.pinHash=v10HashPin(a);s.editPinLost=false;v10SaveEditSec(s);alert("New PIN saved successfully. The same PIN now protects Edit and Add Transaction.");v10ContinueEdit(id);
}
function v10CancelEditGate(){document.getElementById("editPinGate").style.display="none"}

function closeEdit(){document.getElementById("editModal").style.display="none"}
function saveEdit(){const id=Number(document.getElementById("editId").value),t=txs.find(x=>x.id===id);if(!t)return;if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");closeEdit();render();return;}const amount=Number(document.getElementById("editAmount").value),date=document.getElementById("editDate").value,category=document.getElementById("editCategory").value.trim(),today=localToday();if(!date||date>today||!Number.isFinite(amount)||amount<=0||!category){if(date>today)document.getElementById("editDate").value=today;alert(date>today?"Future dates are not allowed. Please select today or an earlier date.":"Please enter a valid date, amount and category.");return}t.date=date;t.type=document.getElementById("editType").value;t.amount=amount;t.category=category;t.mode=document.getElementById("editMode").value;t.description=document.getElementById("editDescription").value.trim();t.remark=document.getElementById("editRemark").value.trim();t.other=document.getElementById("editOther").value.trim();sortTransactionsLatestFirst();save();try{const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");const aid=localStorage.getItem("money_manager_active_profile_v10");const ap=ps.find(x=>x&&x.id===aid)||ps[0];if(ap){ap.transactions=txs.map(x=>({...x}));localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}}catch(e){}closeEdit();if(document.getElementById("historyModal").style.display==="block")renderHistory()}

function exportCSV(){
 if(!txs.length){alert("No transactions to export.");return}
 const rows=[["Date","Type","Amount (₹)","Balance (₹)","Category","Description","Remark","Payment Mode","Other"]];
 let b=0;
 txs.forEach(t=>{b+=t.type==="CREDIT"?t.amount:-t.amount;rows.push([t.date,t.type,t.amount,b,t.category,t.description,t.remark,t.mode,t.other])});
 const csv=rows.map(r=>r.map(x=>`"${String(x??"").replaceAll('"','""')}"`).join(",")).join("\n");
 const blob=new Blob([csv],{type:"text/csv"});
 downloadBlob(blob,"money_manager.csv");
}

function escXml(s){
 return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function downloadBlob(blob,name){
 if(window.AndroidFile && AndroidFile.saveFile){
   blob.arrayBuffer().then(buf=>{
     const bytes=new Uint8Array(buf); let bin="";
     const chunk=0x8000; for(let i=0;i<bytes.length;i+=chunk) bin+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+chunk,bytes.length)));
     AndroidFile.saveFile(name,blob.type||"application/octet-stream",btoa(bin));
   }).catch(()=>alert("File export failed."));
   return;
 }
 const a=document.createElement("a");
 a.href=URL.createObjectURL(blob); a.download=name; a.click();
 setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function getDateRange(){
 const from=document.getElementById("pdfFrom").value;
 const to=document.getElementById("pdfTo").value;
 if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
 if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
 return {from,to};
}
function filteredTransactions(){
 const r=getDateRange(); if(!r)return null;
 return txs.filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
}
function setThisMonth(){
 const d=new Date(), y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0");
 document.getElementById("pdfFrom").value=`${y}-${m}-01`;
 document.getElementById("pdfTo").value=new Date(y,d.getMonth()+1,0).toISOString().slice(0,10);
}
function setAllDates(){
 document.getElementById("pdfFrom").value="";
 document.getElementById("pdfTo").value="";
}
function crc32(bytes){
 let table=crc32.table;
 if(!table){table=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);table[n]=c>>>0;}crc32.table=table;}
 let c=0xFFFFFFFF;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;
}
function u16(n){return [n&255,(n>>>8)&255]}
function u32(n){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]}
function catBytes(arrs){let len=arrs.reduce((s,a)=>s+a.length,0),o=new Uint8Array(len),p=0;for(const a of arrs){o.set(a,p);p+=a.length}return o}
function zipStore(files){
 const enc=new TextEncoder(), locals=[], centrals=[];let offset=0;
 for(const f of files){
   const name=enc.encode(f.name),data=typeof f.data==="string"?enc.encode(f.data):f.data,crc=crc32(data);
   const local=catBytes([
    new Uint8Array([80,75,3,4,20,0,0,0,0,0,0,0,0,0]),
    new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),
    new Uint8Array(u16(name.length)),new Uint8Array([0,0]),name,data
   ]);
   const central=catBytes([
    new Uint8Array([80,75,1,2,20,0,20,0,0,0,0,0,0,0]),
    new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),
    new Uint8Array(u16(name.length)),new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),
    name,new Uint8Array(u32(offset))
   ]);
   locals.push(local);centrals.push(central);offset+=local.length;
 }
 const body=catBytes(locals),cd=catBytes(centrals),count=files.length;
 const eocd=catBytes([
  new Uint8Array([80,75,5,6,0,0,0,0]),new Uint8Array(u16(count)),new Uint8Array(u16(count)),
  new Uint8Array(u32(cd.length)),new Uint8Array(u32(body.length)),new Uint8Array([0,0])
 ]);
 return catBytes([body,cd,eocd]);
}
function xmlEsc(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}
function xlsxText(v){return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`}
function xlsxNumber(v){return `<c><v>${Number(v)}</v></c>`}
function exportExcel(){
 const data=filteredTransactions();if(!data)return;
 if(!data.length){alert("No transactions in the selected date range.");return;}
 let balance=0;
 const rows=[["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"]];
 data.forEach(t=>{balance+=t.type==="CREDIT"?t.amount:-t.amount;rows.push([t.date,t.type,t.amount,balance,t.category,t.description,t.remark,t.mode,t.other])});
 const sheetRows=rows.map((r,rowIndex)=>`<row>${r.map((v,i)=>((rowIndex>0)&&(i===2||i===3))?xlsxNumber(Number.isFinite(Number(v))?Number(v):0):xlsxText(v)).join("")}</row>`).join("");
 const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
 const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
 const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
 const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
 const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
 const bytes=zipStore([
  {name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},
  {name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},
  {name:"xl/worksheets/sheet1.xml",data:sheet}
 ]);
 downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions.xlsx");
}
function pdfEscape(s){
 return String(s).replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
}
function makeSimplePDF(lines){
 const width=595,height=842, margin=36, lineH=15;
 const usable=Math.max(1,Math.floor((height-60)/lineH));
 const pages=[];
 for(let i=0;i<lines.length;i+=usable) pages.push(lines.slice(i,i+usable));
 if(!pages.length) pages.push(["No transactions."]);
 let objs=[];
 function add(o){objs.push(o);return objs.length;}
 const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
 const pageIds=[], contentIds=[];
 pages.forEach(pg=>{
   let y=height-45, stream="BT\n/F1 10 Tf\n";
   pg.forEach((line,idx)=>{
     stream+=`1 0 0 1 ${margin} ${y} Tm (${pdfEscape(line.slice(0,105))}) Tj\n`;
     y-=lineH;
   });
   stream+="ET";
   const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
   contentIds.push(cid);
   pageIds.push(null);
 });
 const pagesId=add("PAGES_PLACEHOLDER");
 pages.forEach((_,i)=>{
   pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`);
 });
 objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;
 const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
 let pdf="%PDF-1.4\n", offsets=[0];
 objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});
 const xref=pdf.length;
 pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
 for(let i=1;i<=objs.length;i++) pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
 pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return new Blob([pdf],{type:"application/pdf"});
}
function exportPDF(){
 const data=filteredTransactions(); if(!data)return;
 if(!data.length){alert("No transactions in the selected date range.");return;}
 let from=document.getElementById("pdfFrom").value||data[0].date;
 let to=document.getElementById("pdfTo").value||data[data.length-1].date;
 let income=0,expense=0,balance=0;
 const lines=["MONEY MANAGER - TRANSACTION REPORT",`Period: ${from} to ${to}`,""];
 lines.push("Date       Type      Amount      Balance     Category");
 lines.push("---------------------------------------------------------------");
 data.forEach(t=>{
   balance+=t.type==="CREDIT"?t.amount:-t.amount;
   if(t.type==="CREDIT")income+=t.amount; else expense+=t.amount;
   lines.push(`${t.date}  ${t.type.padEnd(8)} ${("Rs."+Number(t.amount).toFixed(2)).padStart(10)}  ${("Rs."+Number(balance).toFixed(2)).padStart(10)}  ${t.category}`);
   if(t.description) lines.push(`           Description: ${t.description}`);
 });
 lines.push("","SUMMARY",`Total Credit: Rs.${income.toFixed(2)}`,`Total Expense: Rs.${expense.toFixed(2)}`,`Net Balance: Rs.${(income-expense).toFixed(2)}`);
 downloadBlob(makeSimplePDF(lines),`money_transactions_${from}_to_${to}.pdf`);
}

render();

(function(){
  const PROFILE_KEY="money_manager_profiles_v10";
  const ACTIVE_KEY="money_manager_active_profile_v10";
  const DEFAULT_PROFILE=()=>({
    id:"profile_"+Date.now()+"_"+Math.random().toString(36).slice(2,7),
    name:"My Money", transactions:[],
    security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}
  });

  function getProfiles(){
    try{
      const x=JSON.parse(localStorage.getItem(PROFILE_KEY)||"null");
      return Array.isArray(x)&&x.length?x:[DEFAULT_PROFILE()];
    }catch(e){return [DEFAULT_PROFILE()]}
  }
  function setProfiles(x){localStorage.setItem(PROFILE_KEY,JSON.stringify(x))}
  function activeId(){return localStorage.getItem(ACTIVE_KEY)}
  function current(){
    let ps=getProfiles(), id=activeId(), p=ps.find(x=>x.id===id);
    if(!p){p=ps[0];localStorage.setItem(ACTIVE_KEY,p.id)}
    return p;
  }
  function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
  function hash(pin){
    let h=2166136261;
    for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }

  window.v10OpenProfiles=function(){
    if(typeof closeMenu==="function") closeMenu();
    const ps=getProfiles(), id=activeId()||ps[0].id;
    const list=document.getElementById("v10ProfileList");
    list.innerHTML=ps.map(p=>`<div class="v10row"><div><b>${esc(p.name)}</b><div class="v10small">${p.id===id?"Active profile":"Separate profile"}</div></div>${p.id===id?"":"<button onclick=\"v10SwitchProfile('"+p.id+"')\">Switch</button>"}</div>`).join("");
    document.getElementById("v10ProfileModal").style.display="block";
  };
  window.v10CloseProfileModal=function(){document.getElementById("v10ProfileModal").style.display="none"};
  window.v10CreateProfile=function(){
    const name=(document.getElementById("v10NewProfileName").value||"").trim()||("Mode "+(getProfiles().length+1));
    const ps=getProfiles(), p=DEFAULT_PROFILE();
    // A newly created Mode is a genuinely fresh workspace: no transactions,
    // no PIN, no recovery code and no security state copied from another Mode.
    p.name=name;
    p.transactions=[];
    p.security={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true};
    ps.push(p); setProfiles(ps);
    try{["money_manager_edit_security_v1","mm_global_pin","globalPin","globalPinHash","pinHash"].forEach(k=>localStorage.removeItem(k))}catch(e){}
    localStorage.setItem(ACTIVE_KEY,p.id);
    document.getElementById("v10NewProfileName").value="";
    v10ApplyProfile(p);
  };
  window.v10SwitchProfile=function(id){
    const p=getProfiles().find(x=>x.id===id); if(!p)return;
    localStorage.setItem(ACTIVE_KEY,id); v10ApplyProfile(p);
  };
  function v10ApplyProfile(p){
    // Keep the existing V10 app data isolated per profile without deleting anything.
    localStorage.setItem("money_manager_active_profile_v10",p.id);
    if(typeof txs!=="undefined") { txs=Array.isArray(p.transactions)?p.transactions:[]; localStorage.setItem(typeof KEY!=="undefined"?KEY:"transactions",JSON.stringify(txs)); }
    if(typeof config!=="undefined" && p.config) config=p.config;
    if(typeof render==="function") render();
    const badge=document.getElementById("profileBadge"); if(badge) badge.textContent=p.name;
    v10CloseProfileModal();
    alert("Switched to "+p.name+".");
  }

  function v10PinActionsHtml(title,body,buttons){
    const actions=document.getElementById("v10PinActions");
    if(!actions)return;
    actions.innerHTML=`<div class="v10pin-step"><h3>${title}</h3>${body}${buttons||''}</div>`;
    // Keep the single PIN Security modal as the only security overlay.
    ["v10AddTxSettingGate","v10AddTxPinModal","v10AddTxGate","editPinGate"].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display="none";});
    const modal=document.getElementById("v10PinModal"); if(modal)modal.style.display="block";
    setTimeout(()=>{const first=actions.querySelector('input');if(first)first.focus()},30);
  }
  function v10PinBack(){v10OpenPin()}
  window.v10OpenPin=function(){
    if(typeof closeMenu==="function")closeMenu();
    ["v10AddTxSettingGate","v10AddTxPinModal","v10AddTxGate","editPinGate"].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display="none";});
    const p=current(),s=p.security||{};
    const status=document.getElementById("v10PinStatusText");
    if(s.pinHash){
      if(status)status.textContent="PIN is already created. The same PIN protects all security actions in this Profile / Mode.";
      v10PinActionsHtml("PIN Security","<p class=\"v10small\">Choose how you want to manage the PIN for this Profile / Mode.</p>",'<button type="button" onclick="v10ChangePin()">🔄 Change PIN</button><button type="button" class="secondary" onclick="v10ForgotPin()">🔑 Verify / Recovery</button>');
    }else{
      if(status)status.textContent="No PIN created yet. Create one PIN; it will be used everywhere in this Profile / Mode.";
      v10PinActionsHtml("Create PIN","<p>Create one 4–6 digit PIN. This same PIN will protect every security-related action in this Profile / Mode.</p>",'<button type="button" onclick="v10CreateInitialPin()">🔐 Create PIN</button>');
    }
    const modal=document.getElementById("v10PinModal");if(modal)modal.style.display="block";
  };
  window.v10ClosePinModal=function(){const m=document.getElementById("v10PinModal");if(m)m.style.display="none"};
  function saveUnifiedPin(a,b){
    if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return false}
    if(a!==b){alert("PIN and Confirm PIN do not match.");return false}
    const ps=getProfiles(),p=current();p.security=p.security||{};p.security.pinHash=hash(a);p.security.editPinLost=false;p.security.recoveryCode=p.security.recoveryCode||recovery();p.security.mode=p.security.mode==="BIOMETRIC"?"BOTH":"PIN";setProfiles(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    return p;
  }
  window.v10CreateInitialPin=function(){
    v10PinActionsHtml("Create PIN","<p>Create the PIN for this Profile / Mode. It will be the single PIN used across all security features here.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm PIN\">",'<button type="button" onclick="v10SavePin()">Save PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10ChangePin=function(){
    v10PinActionsHtml("Verify Current PIN","<p>Enter the current PIN for this Profile / Mode. The existing PIN must be verified before it can be changed.</p><input id=\"v10CurrentPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Current PIN\">",'<button type="button" onclick="v10VerifyCurrentForChange()">Continue</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10VerifyCurrentForChange=function(){
    const s=current().security||{},v=document.getElementById("v10CurrentPin")?.value||"";
    if(!s.pinHash){v10PinBack();return}
    if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return}
    v10PinActionsHtml("Create New PIN","<p>Current PIN verified. Create your new 4–6 digit PIN.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm New PIN\">",'<button type="button" onclick="v10SavePin()">Save New PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10SavePin=function(){
    const a=document.getElementById("v10NewPin")?.value||"",b=document.getElementById("v10ConfirmPin")?.value||"";
    const p=saveUnifiedPin(a,b);if(!p)return;
    v10ClosePinModal();alert("PIN changed successfully.\n\nThe same PIN now protects all security features in this Profile / Mode.\n\nRecovery Code:\n"+p.security.recoveryCode);
  };
  window.v10ForgotPin=function(){
    const p=current(),s=p.security||{};
    if(!s.recoveryCode){alert("No Recovery Code is available for this profile.");return}
    v10PinActionsHtml("Recovery Verification","<p>Enter the Recovery Code for this Profile / Mode to create a new PIN.</p><input id=\"v10RecoveryInput\" type=\"text\" autocomplete=\"off\" placeholder=\"Recovery Code\">",'<button type="button" onclick="v10VerifyRecoveryForChange()">Verify Recovery Code</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10VerifyRecoveryForChange=function(){
    const p=current(),s=p.security||{},code=(document.getElementById("v10RecoveryInput")?.value||"").trim().toUpperCase();
    if(!s.recoveryCode||code!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
    v10PinActionsHtml("Create New PIN","<p>Recovery Code verified. Create your new 4–6 digit PIN.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm New PIN\">",'<button type="button" onclick="v10SaveRecoveredPin()">Save New PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10SaveRecoveredPin=function(){
    const a=document.getElementById("v10NewPin")?.value||"",b=document.getElementById("v10ConfirmPin")?.value||"";
    if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return}
    if(a!==b){alert("PIN and Confirm PIN do not match.");return}
    const ps=getProfiles(),p=current();p.security=p.security||{};p.security.pinHash=hash(a);p.security.editPinLost=false;setProfiles(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    v10ClosePinModal();alert("PIN recovered and changed successfully.\n\nThe same PIN now protects all security features in this Profile / Mode.");
  };
  // Expose a helper for future Android/native biometric integration.
  window.v10GetActiveProfile=function(){return current()};
})();


(function(){
function P(){try{return JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]")}catch(e){return[]}}
function S(x){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x))}
function A(){let p=P(),id=localStorage.getItem("money_manager_active_profile_v10");return p.find(x=>x.id===id)||p[0]||null}
function H(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return(h>>>0).toString(16)}
function closeG(){let e=document.getElementById("v10AddTxGate");if(e)e.style.display="none"}
function closeSettingGate(){let e=document.getElementById("v10AddTxSettingGate");if(e)e.style.display="none"}
function v109Profiles(){
  try{
    let ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"null");
    if(!Array.isArray(ps)||!ps.length){
      const legacy=Array.isArray(txs)?txs:[];
      ps=[{id:"profile_"+Date.now()+"_"+Math.random().toString(36).slice(2,7),name:"My Money",transactions:legacy,security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}}];
      localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
    }
    ps.forEach(p=>{
      p.security=p.security||{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
      // Security is profile-local. Never import the old global PIN into a profile.
      if(typeof p.security.addProtection!=="boolean") p.security.addProtection=false;
      if(!Array.isArray(p.transactions)) p.transactions=[];
    });
    localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
    if(!localStorage.getItem("money_manager_active_profile_v10")) localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
    return ps;
  }catch(e){return []}
}
function v109SaveProfiles(x){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x))}
function v109ActiveProfile(){
  const ps=v109Profiles();
  const id=localStorage.getItem("money_manager_active_profile_v10");
  const p=ps.find(x=>x.id===id)||ps[0]||null;
  if(p){localStorage.setItem("money_manager_active_profile_v10",p.id);p.security=p.security||{};if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;}
  return p;
}
function v109CloseAddGate(){const e=document.getElementById("v10AddTxGate");if(e)e.style.display="none"}
function v109RealAdd(){
  v109CloseAddGate();
  try{
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the latest app version.");return false}
    return addTx()!==false;
  }catch(e){alert("Add Transaction failed: "+(e&&e.message?e.message:"Unknown error"));return false}
}
function closeG(){v109CloseAddGate()}
function closeSettingGate(){let e=document.getElementById("v10AddTxSettingGate");if(e)e.style.display="none"}
function settingGateBody(html){document.getElementById("v10AddTxSettingGateBody").innerHTML=html;document.getElementById("v10AddTxSettingGate").style.display="block"}
window.v10AddTxPinSettings=function(){
  if(typeof closeMenu==="function")closeMenu();
  const p=v109ActiveProfile();
  if(!p){alert("Profile is not ready. Please open Profile / Mode once, then try again.");return}
  p.security=p.security||{};
  document.getElementById("v10AddTxPinToggle").checked=!!p.security.addProtection;
  document.getElementById("v10AddTxPinModal").style.display="block";
  v10RefreshAddTxSecurityUI();
};
window.v10CloseAddTxPinSettings=function(){document.getElementById("v10AddTxPinModal").style.display="none"};
window.v10RefreshAddTxSecurityUI=function(){
  const p=v109ActiveProfile(), on=!!(p&&p.security&&p.security.addProtection);
  const t=document.getElementById("v10AddTxPinToggle"); if(t)t.checked=on;
  const st=document.getElementById("v10AddTxPinState"); if(st)st.textContent=on?"ON — PIN required before adding":"OFF — no PIN required";
  const mb=document.getElementById("v10MenuAddTxStatus"); if(mb)mb.textContent=on?"🔒 ON":"🔓 OFF";
  const ab=document.getElementById("v10AddTxButton"); if(ab)ab.textContent=on?"🔒 Add Transaction (PIN)":"Add Transaction";
};
function getStoredActiveProfileFresh(){
  try{
    const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x.id===id)||ps[0]||null;
    if(p){
      p.security=p.security||{};
      if(typeof p.security.addProtection!=="boolean") p.security.addProtection=false;
    }
    return {ps,p};
  }catch(e){ return {ps:[],p:null}; }
}
function persistActiveSecurity(sec){
  const x=getStoredActiveProfileFresh();
  if(!x.p)return false;
  x.p.security=sec||{};
  if(typeof x.p.security.addProtection!=="boolean") x.p.security.addProtection=false;
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  return true;
}
window.v10ChooseAddTxSecurity=function(desired){
  const x=getStoredActiveProfileFresh(), p=x.p;
  if(!p){alert("Profile could not be initialized.");return;}
  const wanted=!!desired;
  const current=!!p.security.addProtection;
  // Do not change the setting until the existing profile PIN is verified.
  if(current===wanted){
    v10RefreshAddTxSecurityUI();
    return;
  }
  v10SaveAddTxPinSetting(wanted);
};
window.v10SaveAddTxPinSetting=function(forcedDesired){
  const desired=!!forcedDesired;
  const x=getStoredActiveProfileFresh(), p=x.p;
  if(!p){alert("Profile could not be initialized.");return;}
  document.getElementById("v10AddTxPinModal").style.display="none";
  if(!p.security.pinHash){
    settingGateBody('<h3>🔐 Create the profile PIN first</h3><p>Create one PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and turning this setting ON/OFF.</p><input id="v10SetNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10SetConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button onclick="v10CreateSettingPin('+JSON.stringify(desired)+')">Create PIN & Continue</button><button class="secondary" onclick="v10CancelSettingGate()">Cancel</button>');
    return;
  }
  settingGateBody('<h3>🔐 Verify Existing PIN</h3><p>Use the same profile PIN. No new PIN is being created.</p><input id="v10SetPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter existing PIN"><button onclick="v10VerifySettingPin('+JSON.stringify(desired)+')">Continue</button><button class="secondary" onclick="v10ForgotSettingPin('+JSON.stringify(desired)+')">Forgot PIN?</button><button class="secondary" onclick="v10CancelSettingGate()">Cancel</button>');
};
window.v10VerifySettingPin=function(desired){
  const x=getStoredActiveProfileFresh(), p=x.p, v=document.getElementById("v10SetPinInput")?.value||"";
  if(!p?.security?.pinHash){alert("PIN is not configured. Please create it first.");return;}
  if(H(v)!==p.security.pinHash){alert("Incorrect PIN.");return;}
  p.security.addProtection=!!desired;
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  // Re-read from storage so the Add button and future checks use exactly the saved value.
  v10RefreshAddTxSecurityUI();
  closeSettingGate();
  document.getElementById("v10AddTxPinModal").style.display="block";
  v10RefreshAddTxSecurityUI();
};
window.v10CreateSettingPin=function(desired){
  const a=document.getElementById("v10SetNewPin")?.value||"",b=document.getElementById("v10SetConfirmPin")?.value||"";
  if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
  if(a!==b){alert("PINs do not match.");return}
  const x=getStoredActiveProfileFresh(),p=x.p;if(!p)return;
  p.security=p.security||{};p.security.pinHash=H(a);p.security.addProtection=!!desired;p.security.recoveryCode=p.security.recoveryCode||recovery();
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI();
  alert("PIN created successfully.\n\nRecovery Code:\n"+p.security.recoveryCode+"\n\nThis same PIN protects Edit and Add Transaction.");
};
window.v10ForgotSettingPin=function(desired){
  const x=getStoredActiveProfileFresh(),p=x.p,s=p&&p.security||{};if(!s.recoveryCode){alert("No Recovery Code is available.");return}
  const code=prompt("Enter your Recovery Code:");if(code===null)return;if(code.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
  const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
  s.pinHash=H(a);p.security=s;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI();alert("New PIN saved. The same PIN now protects Edit and Add Transaction.");
};
window.v10CancelSettingGate=function(){closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI()};
window.v109RequestAddTransaction=function(){
  const x=getStoredActiveProfileFresh(),p=x.p;
  if(!p){alert("Could not initialize the active profile.");return false;}
  // IMPORTANT: read the saved ON/OFF value fresh every time.
  const protection=!!p.security.addProtection;
  if(!protection){ return v109RealAdd(); }
  const gate=document.getElementById("v10AddTxGate"),body=document.getElementById("v10AddTxGateBody");
  if(!gate||!body){alert("Add Transaction security screen is unavailable.");return false}
  if(!p.security.pinHash){
    body.innerHTML='<h3>🔐 Create Profile PIN</h3><p>Create one PIN. The same PIN will protect Edit and Add Transaction.</p><input id="v10AddNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10AddConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" onclick="v10SaveAddPin()">Create PIN & Add</button><button type="button" class="secondary" onclick="v10CancelAddPin()">Cancel</button>';
  }else{
    body.innerHTML='<h3>🔐 Enter PIN</h3><p>Enter the same profile PIN used for Edit.</p><input id="v10AddPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button type="button" onclick="v10VerifyAddPin()">Continue</button><button type="button" class="secondary" onclick="v10CancelAddPin()">Cancel</button>';
  }
  gate.style.display="block";setTimeout(()=>{const el=document.getElementById("v10AddPinInput")||document.getElementById("v10AddNewPin");if(el)el.focus()},0);return false;
};
window.v10VerifyAddPin=function(){
 const p=v109ActiveProfile(),v=document.getElementById("v10AddPinInput")?.value||"";
 if(!p?.security?.pinHash){alert("PIN is not configured. Please create it first.");return}
 if(H(v)!==p.security.pinHash){alert("Incorrect PIN.");return}
 v109RealAdd();
};
window.v10CancelAddPin=function(){v109CloseAddGate()};
window.v10SaveAddPin=function(){
 const a=document.getElementById("v10AddNewPin")?.value||"",b=document.getElementById("v10AddConfirmPin")?.value||"";
 if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
 if(a!==b){alert("PINs do not match.");return}
 const ps=v109Profiles(),p=v109ActiveProfile();if(!p)return;
 p.security=p.security||{};p.security.pinHash=H(a);p.security.addProtection=true;p.security.recoveryCode=p.security.recoveryCode||recovery();
 v109SaveProfiles(ps);v109RealAdd();
};

try{v10RefreshAddTxSecurityUI()}catch(e){}


})();


/* V15 UNIFIED SECURITY OVERRIDE
   One profile PIN + one recovery code for Edit and Add Transaction.
   No per-transaction skip. */
(function(){
  function mmProfiles(){
    try { const x=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]"); return Array.isArray(x)?x:[]; } catch(e){ return []; }
  }
  function mmSaveProfiles(ps){ localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps)); }
  function mmActive(){
    const ps=mmProfiles();
    const id=localStorage.getItem("money_manager_active_profile_v10");
    return ps.find(p=>p.id===id)||ps[0]||null;
  }
  function mmHash(pin){
    let h=2166136261; pin=String(pin||"");
    for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function mmRecovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function mmSec(){
    const ps=mmProfiles(), p=mmActive(); if(!p) return null;
    p.security=p.security||{};
    if(false){
      try{
        const legacy=null;
        if(legacy&&legacy.pinHash){p.security.pinHash=legacy.pinHash;p.security.recoveryCode=p.security.recoveryCode||legacy.recoveryCode||"";}
      }catch(e){}
    }
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    if(p.security.pinHash&&!p.security.recoveryCode)p.security.recoveryCode=mmRecovery();
    const q=ps.find(x=>x.id===p.id); if(q)q.security=p.security;
    mmSaveProfiles(ps);
    if(p.security.pinHash)localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    return p.security;
  }
  function mmClose(id){const e=document.getElementById(id);if(e)e.style.display="none";}
  function mmGate(body){const e=document.getElementById("v10AddTxGate"),b=document.getElementById("v10AddTxGateBody");if(!e||!b)return false;b.innerHTML=body;e.style.display="block";return true;}
  function mmRealAdd(){
    mmClose("v10AddTxGate");
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the app.");return false;}
    try{return addTx()!==false}catch(e){alert("Add Transaction failed: "+(e.message||"Unknown error"));return false;}
  }
  function mmAskPin(onSuccess,onCancel){
    const s=mmSec();
    if(!s){alert("Profile is not ready.");return;}
    if(!s.pinHash){
      mmGate('<h3>🔐 Create PIN</h3><p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p><input id="mmNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="mmConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" id="mmCreatePinBtn">Create PIN</button><button type="button" class="secondary" id="mmCancelPinBtn">Cancel</button>');
      document.getElementById("mmCreatePinBtn").onclick=function(){
        const a=document.getElementById("mmNewPin").value,b=document.getElementById("mmConfirmPin").value;
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PINs do not match.");return}
        const ps=mmProfiles(),p=mmActive();p.security=p.security||{};p.security.pinHash=mmHash(a);p.security.recoveryCode=p.security.recoveryCode||mmRecovery();
        mmSaveProfiles(ps);localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
        mmGate('<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">'+p.security.recoveryCode+'</div><p class="v10small">This is the same PIN for Edit, Add Transaction and security settings.</p><button type="button" id="mmContinuePin">Continue</button>');
        document.getElementById("mmContinuePin").onclick=function(){mmClose("v10AddTxGate");onSuccess();};
      };
      document.getElementById("mmCancelPinBtn").onclick=function(){mmClose("v10AddTxGate");if(onCancel)onCancel();};
      return;
    }
    mmGate('<h3>🔐 Enter PIN</h3><p>Enter your existing profile PIN.</p><input id="mmPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button type="button" id="mmPinContinue">Continue</button><button type="button" class="secondary" id="mmForgotPin">Forgot PIN?</button><button type="button" class="secondary" id="mmPinCancel">Cancel</button>');
    document.getElementById("mmPinContinue").onclick=function(){const v=document.getElementById("mmPinInput").value;if(!mmV19CheckPin(v,mmSec().pinHash,mmHash))return;mmClose("v10AddTxGate");onSuccess();};
    document.getElementById("mmForgotPin").onclick=function(){
      const s2=mmSec(),code=prompt("Enter your Recovery Code:");if(code===null)return;
      if(code.trim().toUpperCase()!==String(s2.recoveryCode||"").toUpperCase()){alert("Incorrect Recovery Code.");return}
      const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");
      if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
      const ps=mmProfiles(),p=mmActive();p.security.pinHash=mmHash(a);mmSaveProfiles(ps);localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
      mmClose("v10AddTxGate");onSuccess();
    };
    document.getElementById("mmPinCancel").onclick=function(){mmClose("v10AddTxGate");if(onCancel)onCancel();};
    setTimeout(()=>document.getElementById("mmPinInput")?.focus(),0);
  }

  // Add Transaction: ON means compulsory PIN; OFF means no PIN. Never a skip button.
  window.v109RequestAddTransaction=function(){
    const s=mmSec(); if(!s){alert("Profile is not ready.");return false;}
    if(!s.addProtection)return mmRealAdd();
    mmAskPin(mmRealAdd,()=>{}); return false;
  };

  // Menu ON/OFF: changing the setting itself always requires the existing profile PIN.
  window.v10SaveAddTxPinSetting=function(forcedDesired){
    const p=mmActive(),s=mmSec(); if(!p||!s)return;
    const desired=!!forcedDesired;
    if(!!s.addProtection===desired){v10RefreshAddTxSecurityUI();return;}
    if(!s.pinHash){
      // First-time setup: create the one common PIN, then apply the requested ON/OFF state.
      const a=prompt("Create one 4–6 digit profile PIN:"),b=prompt("Confirm PIN:");
      if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup cancelled.");v10RefreshAddTxSecurityUI();return;}
      const ps=mmProfiles();p.security.pinHash=mmHash(a);p.security.recoveryCode=p.security.recoveryCode||mmRecovery();p.security.addProtection=desired;mmSaveProfiles(ps);alert("PIN created.\n\nRecovery Code:\n"+p.security.recoveryCode);v10RefreshAddTxSecurityUI();return;
    }
    mmAskPin(function(){const ps=mmProfiles(),q=mmActive();q.security.addProtection=desired;mmSaveProfiles(ps);v10RefreshAddTxSecurityUI();},()=>v10RefreshAddTxSecurityUI());
  };
  window.v10ChooseAddTxSecurity=function(desired){window.v10SaveAddTxPinSetting(!!desired);};

  // Edit: always use the exact same profile PIN/recovery flow.
  window.v10RequestEdit=function(id){
    const t=txs.find(x=>x.id===id); if(!t)return;
    if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return;}
    mmAskPin(function(){
      document.getElementById("editId").value=id;
      const editDate=document.getElementById("editDate");
      if(editDate) editDate.max=localToday();
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },()=>{});
  };

  // Remove any legacy skip entry point as an extra safety measure.
  window.v10SkipAddPin=function(){alert("Skip is disabled. Add Transaction security is controlled only by the ON/OFF setting in Menu.");};
  try{v10RefreshAddTxSecurityUI();}catch(e){}
})();


/* FINAL ADD-TRANSACTION PIN SWITCH FIX
   One profile PIN. Menu switch is authoritative and is persisted immediately after PIN verification.
*/
(function(){
  function getPS(){try{const a=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function getP(){const ps=getPS(),id=localStorage.getItem('money_manager_active_profile_v10');return ps.find(x=>x.id===id)||ps[0]||null}
  function save(ps){localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps))}
  function hash(v){let h=2166136261;v=String(v||'');for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
  function recovery(){const c='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<12;i++){if(i&&i%4===0)s+='-';s+=c[Math.floor(Math.random()*c.length)]}return s}
  function refresh(){const p=getP(),on=!!(p&&p.security&&p.security.addProtection);const t=document.getElementById('v10AddTxPinToggle');if(t)t.checked=on;const st=document.getElementById('v10AddTxPinState');if(st)st.textContent=on?'ON — PIN required before adding':'OFF — no PIN required';const mb=document.getElementById('v10MenuAddTxStatus');if(mb)mb.textContent=on?'🔒 ON':'🔓 OFF';const ab=document.getElementById('v10AddTxButton');if(ab)ab.textContent=on?'🔒 Add Transaction (PIN)':'Add Transaction';}
  function verifyExisting(p){
    const pin=prompt('Enter your existing profile PIN:');
    if(pin===null)return false;
    if(!p.security||!p.security.pinHash){alert('No PIN is created for this profile.');return false;}
    if(hash(pin)!==p.security.pinHash){alert('Incorrect PIN. Setting was not changed.');return false;}
    return true;
  }
  function createPin(p,desired){
    const a=prompt('Create one 4–6 digit profile PIN:');if(a===null)return false;
    const b=prompt('Confirm PIN:');if(b===null)return false;
    if(!/^\d{4,6}$/.test(a)||a!==b){alert('PIN setup failed. PIN must be 4–6 digits and match.');return false;}
    p.security=p.security||{};p.security.pinHash=hash(a);p.security.recoveryCode=p.security.recoveryCode||recovery();p.security.addProtection=desired;return true;
  }
  window.v10ChooseAddTxSecurity=function(desired){
    const ps=getPS(),p=getP(); if(!p){alert('Profile is not ready.');refresh();return;}
    p.security=p.security||{};
    const wanted=!!desired,current=!!p.security.addProtection;
    refresh(); // immediately restore checkbox to the saved state until authorization succeeds
    if(current===wanted)return;
    if(!p.security.pinHash){
      if(!createPin(p,wanted)){refresh();return;}
    }else{
      if(!verifyExisting(p)){refresh();return;}
      p.security.addProtection=wanted;
    }
    const q=ps.find(x=>x.id===p.id);if(q)q.security=p.security;save(ps);
    refresh();
    alert(wanted?'Add Transaction PIN is now ON.':'Add Transaction PIN is now OFF.');
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};
  window.v109RequestAddTransaction=function(){
    const p=getP();if(!p){alert('Profile is not ready.');return false;}
    p.security=p.security||{};const on=!!p.security.addProtection;
    if(!on){if(typeof addTx==='function'){try{return addTx()!==false}catch(e){alert('Add Transaction failed: '+(e.message||e));return false}}alert('Add Transaction function is unavailable.');return false}
    if(!p.security.pinHash){alert('Please create your profile PIN first from Menu → Add Transaction PIN.');return false}
    const pin=prompt('Enter your profile PIN to add this transaction:');if(pin===null)return false;
    if(hash(pin)!==p.security.pinHash){alert('Incorrect PIN. Transaction was not added.');return false}
    if(typeof addTx==='function'){try{return addTx()!==false}catch(e){alert('Add Transaction failed: '+(e.message||e));return false}}
    alert('Add Transaction function is unavailable.');return false;
  };
  refresh();
})();


/* MM_V19_PIN_LOCKOUT
   Common PIN attempt protection:
   - 5 wrong attempts -> 30 second pause
   - successful PIN resets the counter
   - applies to PIN prompts that call mmV19CheckPin()
*/
(function(){
  const KEY="mm_v19_pin_attempts";
  const LOCK="mm_v19_pin_lock_until";

  function state(){
    let n=parseInt(sessionStorage.getItem(KEY)||"0",10);
    let until=parseInt(sessionStorage.getItem(LOCK)||"0",10);
    if(!Number.isFinite(n)||n<0)n=0;
    if(!Number.isFinite(until)||until<0)until=0;
    return {n,until};
  }
  function save(s){
    sessionStorage.setItem(KEY,String(s.n));
    sessionStorage.setItem(LOCK,String(s.until));
  }
  window.mmV19PinLockRemaining=function(){
    const s=state(), left=Math.max(0,s.until-Date.now());
    return left;
  };
  window.mmV19CheckPin=function(pin, expectedHash, hashFn){
    const s=state(), left=Math.max(0,s.until-Date.now());
    if(left>0){
      const sec=Math.ceil(left/1000);
      alert("Too many incorrect PIN attempts. Please wait "+sec+" seconds.");
      return false;
    }
    if(hashFn(pin)!==expectedHash){
      s.n++;
      if(s.n>=5){
        s.n=0;
        s.until=Date.now()+30000;
        save(s);
        alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");
      }else{
        save(s);
        alert("Incorrect PIN. Attempts remaining: "+(5-s.n)+".");
      }
      return false;
    }
    save({n:0,until:0});
    return true;
  };
})();


/* V19 FINAL FIX — ONE UNIFIED PIN GATE FOR EDIT + ADD TRANSACTION
   - Add Transaction uses the exact same custom gate as Edit.
   - No browser prompt/alert is used for PIN entry or recovery.
   - Same profile PIN + Recovery Code for Edit, Add and Add-PIN setting.
   - 5 wrong attempts => 30-second pause on both Edit and Add.
   - No per-transaction Skip.
*/
(function(){
  function profiles(){
    try{
      let ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"null");
      if(!Array.isArray(ps)||!ps.length){
        const legacyTx=Array.isArray(window.txs)?window.txs:[];
        ps=[{id:"profile_"+Date.now()+"_"+Math.random().toString(36).slice(2,7),name:"My Money",transactions:legacyTx,
          security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}}];
        localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
        localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
      }
      ps.forEach(p=>{
        p.security=p.security||{};
        if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
        if(!Array.isArray(p.transactions))p.transactions=[];
      });
      if(!localStorage.getItem("money_manager_active_profile_v10"))localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
      localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      return ps;
    }catch(e){return []}
  }
  function active(){
    const ps=profiles();
    if(!ps.length)return null;
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x.id===id)||ps[0];
    localStorage.setItem("money_manager_active_profile_v10",p.id);
    p.security=p.security||{};
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    return p;
  }
  function save(ps){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}
  function hash(pin){
    if(typeof v10HashPin==="function")return v10HashPin(String(pin||""));
    let h=2166136261,s=String(pin||"");
    for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    if(typeof v10MakeRecovery==="function")return v10MakeRecovery();
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function gate(){return document.getElementById("editPinGate")}
  function body(){return document.getElementById("editPinGateBody")}
  function closeGate(){const e=gate();if(e)e.style.display="none"}
  function showGate(title,html){
    const e=gate(),b=body();if(!e||!b)return false;
    const h=e.querySelector("h2");if(h)h.textContent=title;
    b.innerHTML=html;e.style.display="block";return true;
  }
  function persistSecurity(sec){
    const ps=profiles(),p=active();if(!p)return false;
    p.security=sec;
    const q=ps.find(x=>x.id===p.id);if(q)q.security=sec;
    save(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:sec.pinHash||"",recoveryCode:sec.recoveryCode||""}));
    return true;
  }
  function realAdd(){
    closeGate();
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the app.");return false;}
    try{return addTx()!==false}catch(e){alert("Add Transaction failed: "+(e&&e.message?e.message:"Unknown error"));return false;}
  }
  function recoveryUI(onSuccess,onCancel){
    const p=active(),s=p&&p.security||{};
    if(!s.recoveryCode){alert("No Recovery Code is available for this profile.");return;}
    showGate("🔐 Forgot PIN",`
      <h3>🔑 Recovery Code</h3>
      <p>Enter the Recovery Code saved when your PIN was created.</p>
      <input id="v19RecoveryCode" type="text" autocomplete="off" placeholder="XXXX-XXXX-XXXX">
      <button type="button" id="v19VerifyRecovery">Verify Recovery Code</button>
      <button type="button" class="secondary" id="v19RecoveryCancel">Cancel</button>`);
    document.getElementById("v19VerifyRecovery").onclick=function(){
      const code=(document.getElementById("v19RecoveryCode")?.value||"").trim().toUpperCase();
      if(code!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return;}
      body().innerHTML=`
        <h3>🔐 Create New PIN</h3>
        <p>Create a new 4–6 digit PIN.</p>
        <input id="v19RecoveryNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="v19RecoveryConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="v19RecoverySave">Save New PIN</button>
        <button type="button" class="secondary" id="v19RecoveryBack">Back</button>`;
      document.getElementById("v19RecoverySave").onclick=function(){
        const a=document.getElementById("v19RecoveryNewPin")?.value||"",b=document.getElementById("v19RecoveryConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return;}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return;}
        s.pinHash=hash(a);s.recoveryCode=s.recoveryCode||recovery();s.editPinLost=false;
        if(!persistSecurity(s))return;
        try{sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
        closeGate();onSuccess();
      };
      document.getElementById("v19RecoveryBack").onclick=function(){recoveryUI(onSuccess,onCancel)};
    };
    document.getElementById("v19RecoveryCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
    setTimeout(()=>document.getElementById("v19RecoveryCode")?.focus(),0);
  }
  function requestPin(onSuccess,onCancel,context){
    const p=active();
    if(!p){alert("Unable to initialize the active profile.");return false;}
    const s=p.security||{};
    if(!s.pinHash){
      showGate(context==="add"?"🔐 Add Transaction":"🔐 Edit Security",`
        <h3>🔐 Create PIN</h3>
        <p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p>
        <input id="v19CommonNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="v19CommonConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="v19CommonCreate">Create PIN</button>
        <button type="button" class="secondary" id="v19CommonCancel">Cancel</button>`);
      document.getElementById("v19CommonCreate").onclick=function(){
        const a=document.getElementById("v19CommonNewPin")?.value||"",b=document.getElementById("v19CommonConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return;}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return;}
        s.pinHash=hash(a);s.recoveryCode=s.recoveryCode||recovery();s.editPinLost=false;
        if(!persistSecurity(s))return;
        body().innerHTML=`<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">${s.recoveryCode}</div><p class="v10small">This is the same PIN for Edit, Add Transaction and security settings.</p><button type="button" id="v19CreatedContinue">Continue</button>`;
        document.getElementById("v19CreatedContinue").onclick=function(){closeGate();onSuccess()};
      };
      document.getElementById("v19CommonCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
      setTimeout(()=>document.getElementById("v19CommonNewPin")?.focus(),0);
      return false;
    }
    showGate(context==="add"?"🔐 Add Transaction":"🔐 Edit Security",`
      <h3>🔐 Enter PIN</h3>
      <p>Enter your existing profile PIN.</p>
      <input id="v19CommonPin" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">
      <button type="button" id="v19CommonContinue">Continue</button>
      <button type="button" class="secondary" id="v19CommonForgot">Forgot PIN?</button>
      <button type="button" class="secondary" id="v19CommonCancel">Cancel</button>`);
    document.getElementById("v19CommonContinue").onclick=function(){
      const v=document.getElementById("v19CommonPin")?.value||"";
      if(typeof mmV19CheckPin==="function"){
        if(!mmV19CheckPin(v,s.pinHash,hash))return;
      }else if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return;}
      closeGate();onSuccess();
    };
    document.getElementById("v19CommonForgot").onclick=function(){recoveryUI(onSuccess,onCancel)};
    document.getElementById("v19CommonCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
    setTimeout(()=>document.getElementById("v19CommonPin")?.focus(),0);
    return false;
  }

  // Add Transaction: ON => same custom PIN interface as Edit. OFF => direct add.
  window.v109RequestAddTransaction=function(){
    const p=active();if(!p)return false;
    if(!p.security.addProtection)return realAdd();
    return requestPin(realAdd,()=>{},"add");
  };

  // Menu setting: changing ON/OFF requires the same existing profile PIN.
  window.v10ChooseAddTxSecurity=function(desired){
    const p=active();if(!p)return;
    const wanted=!!desired,current=!!p.security.addProtection;
    if(current===wanted){try{v10RefreshAddTxSecurityUI()}catch(e){}return;}
    requestPin(function(){
      const q=active();if(!q)return;
      q.security.addProtection=wanted;
      const ps=profiles(),r=ps.find(x=>x.id===q.id);if(r)r.security=q.security;
      save(ps);try{v10RefreshAddTxSecurityUI()}catch(e){}
      alert(wanted?"Add Transaction PIN is now ON.":"Add Transaction PIN is now OFF.");
    },()=>{try{v10RefreshAddTxSecurityUI()}catch(e){}},"settings");
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};

  // Keep menu and Add button synchronized with the actual saved profile.
  try{if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI()}catch(e){}
})();


/* V23_PROFILE_ISOLATION
   Each Profile/Mode owns its own security state.
   A newly created/switch-to profile is treated as a fresh install:
   - no PIN inherited from another profile
   - no Recovery Code inherited
   - no failed-attempt counter inherited
   - Add Transaction PIN starts OFF
*/
(function(){
  const V23_PREFIX="mm_v23_profile_security_";
  function profileKey(){
    return localStorage.getItem("money_manager_active_profile_v10")
        || localStorage.getItem("activeProfileId")
        || localStorage.getItem("currentProfileId")
        || "";
  }
  function securityKey(id){ return V23_PREFIX + String(id||""); }

  window.mmV23EnsureProfileIsolation=function(){
    const id=profileKey();
    if(!id) return null;
    const key=securityKey(id);
    let s;
    try{s=JSON.parse(localStorage.getItem(key)||"null")}catch(e){s=null}
    if(!s){
      s={
        initialized:true,
        pinHash:null,
        recoveryCode:null,
        addProtection:false,
        failedAttempts:0,
        lockUntil:0
      };
      localStorage.setItem(key,JSON.stringify(s));
    }
    return s;
  };

  window.mmV23GetProfileSecurity=function(){
    return mmV23EnsureProfileIsolation();
  };

  window.mmV23SaveProfileSecurity=function(s){
    const id=profileKey();
    if(!id) return;
    localStorage.setItem(securityKey(id),JSON.stringify(s||{}));
  };

  // Never allow a legacy/global PIN to become the active profile's PIN.
  window.mmV23ClearLegacySecurity=function(){
    const legacy=[
      "mm_global_pin","globalPin","globalPinHash","pinHash",
      "mm_v19_pin_attempts","mm_v19_pin_lock_until"
    ];
    legacy.forEach(k=>{
      try{localStorage.removeItem(k)}catch(e){}
      try{sessionStorage.removeItem(k)}catch(e){}
    });
    mmV23EnsureProfileIsolation();
  };

  // Initialize immediately and whenever storage changes indicate a profile switch.
  mmV23EnsureProfileIsolation();
  window.addEventListener("storage",function(e){
    if(e.key==="money_manager_active_profile_v10" ||
       e.key==="activeProfileId" ||
       e.key==="currentProfileId"){
      mmV23EnsureProfileIsolation();
    }
  });
})();


(function(){
  function hook(name){
    const f=window[name];
    if(typeof f!=="function" || f.__mmV23Hooked) return;
    const w=function(){
      const r=f.apply(this,arguments);
      try{mmV23EnsureProfileIsolation();mmV23ClearLegacySecurity()}catch(e){}
      return r;
    };
    w.__mmV23Hooked=true;
    window[name]=w;
  }
  setTimeout(function(){
    ["switchProfile","switchMode","selectProfile","activateProfile","setActiveProfile","changeProfile","switchProfileMode"].forEach(hook);
  },0);
})();


window.mmV23ProfileIsolationSelfTest=function(){
  const s=mmV23GetProfileSecurity();
  return {
    profileId: localStorage.getItem("money_manager_active_profile_v10")
      || localStorage.getItem("activeProfileId")
      || localStorage.getItem("currentProfileId") || null,
    hasPin: !!s?.pinHash,
    hasRecoveryCode: !!s?.recoveryCode,
    addProtection: !!s?.addProtection,
    failedAttempts: Number(s?.failedAttempts||0),
    lockUntil: Number(s?.lockUntil||0)
  };
};

