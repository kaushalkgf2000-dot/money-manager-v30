
(function(){
  window.pfOpenExport=function(){
    closeMenu();
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.add('open'); m.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden';
  };
  window.pfCloseExport=function(){
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.remove('open'); m.setAttribute('aria-hidden','true'); document.body.style.overflow='';
  };
  document.addEventListener('click',function(e){const m=document.getElementById('pfExportModal');if(m&&e.target===m)pfCloseExport();});
})();
