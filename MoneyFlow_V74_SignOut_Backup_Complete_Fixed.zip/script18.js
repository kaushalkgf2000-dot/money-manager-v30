
/* V34 — FINAL EXPORT RANGE PIPELINE FIX
   Uses the same active transaction set visible in the app, normalizes every
   stored date before filtering, and applies the selected From/To range only
   at the final export stage. PDF and XLSX share the exact same filtered rows.
*/
(function(){
  function v34Text(v){return String(v==null?"":v).trim()}
  function v34Date(v){
    const s=v34Text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return s.slice(0,10);
  }
  function v34Arr(key){try{const x=JSON.parse(localStorage.getItem(key)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
  function v34Norm(t){
    const x=t||{};
    return {id:x.id,date:v34Date(x.date),type:v34Text(x.type).toUpperCase(),amount:Number(x.amount)||0,
      balance:Number.isFinite(Number(x.balance))?Number(x.balance):null,
      category:v34Text(x.category),description:v34Text(x.description||x.desc),remark:v34Text(x.remark||x.remarks||x.note),
      mode:v34Text(x.mode||x.paymentMode||x.payment_mode),other:v34Text(x.other||x.otherInfo||x.other_info),createdAt:x.createdAt||""};
  }
  function v34Same(a,b){
    if(a&&b&&a.id!=null&&b.id!=null&&String(a.id)===String(b.id))return true;
    return a&&b&&v34Date(a.date)===v34Date(b.date)&&v34Text(a.type).toUpperCase()===v34Text(b.type).toUpperCase()&&Number(a.amount||0)===Number(b.amount||0)&&v34Text(a.category)===v34Text(b.category);
  }
  function v34All(){
    const sources=[];
    let profiles=v34Arr("money_manager_profiles_v10");
    const activeId=localStorage.getItem("money_manager_active_profile_v10");
    const p=profiles.find(x=>x&&String(x.id)===String(activeId)) || profiles[0];
    // txs is the live array currently rendered by the app. Put it first.
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))sources.push(txs.slice())}catch(e){}
    if(p&&Array.isArray(p.transactions))sources.push(p.transactions.slice());
    // Only use legacy storage as a fallback/field-completion source.
    const legacy=v34Arr(typeof KEY!=="undefined"?KEY:"money_manager_v1");
    if(legacy.length)sources.push(legacy);
    const out=[];
    sources.forEach(arr=>arr.forEach(raw=>{
      const n=v34Norm(raw); if(!n.date||!n.type||n.amount<=0)return;
      const old=out.findIndex(o=>v34Same(o,n));
      if(old<0)out.push(n);
      else{
        const q=out[old];
        ["balance","category","description","remark","mode","other","createdAt"].forEach(k=>{
          if((q[k]===null||q[k]===""||q[k]===undefined) && n[k]!==null && n[k]!=="")q[k]=n[k];
        });
      }
    }));
    out.sort((a,b)=>v34Date(a.date).localeCompare(v34Date(b.date)) || (String(a.createdAt).localeCompare(String(b.createdAt))));
    return out;
  }
  function v34Range(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=v34Date(f&&f.value),to=v34Date(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function v34Pack(){
    const r=v34Range();if(!r)return null;
    const all=v34All();
    const data=all.filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
    return {r,all,data};
  }
  function v34Opening(all,from){
    if(!from)return 0;
    const before=all.filter(t=>t.date<from);
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(Number.isFinite(last.balance))return last.balance;
    let b=0;before.forEach(t=>b+=t.type==="CREDIT"?t.amount:-t.amount);return b;
  }
  function v34Rows(data,opening){
    let b=opening,w=0,d=0;
    const rows=data.map(t=>{
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b]
    });
    return {rows,withdrawals:w,deposits:d,closing:b};
  }
  function v34Esc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
  function v34XText(v){return `<c t="inlineStr"><is><t>${v34Esc(v)}</t></is></c>`}
  function v34XNum(v){return `<c t="n"><v>${Number(v)||0}</v></c>`}
  function v34MakeXlsx(pack){
    const {r,all,data}=pack,from=r.from||data[0].date,to=r.to||data[data.length-1].date,opening=v34Opening(all,from),calc=v34Rows(data,opening);
    const rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    rows.push(...calc.rows);rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",opening,"TOTAL WITHDRAWALS",calc.withdrawals,"TOTAL DEPOSITS",calc.deposits,"CLOSING BALANCE",calc.closing,"No. of Transactions",data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map((row,ri)=>`<row>${row.map((v,i)=>{const num=(ri>0&&ri<=data.length&&[6,7,8].includes(i))||(ri===data.length+2&&typeof v==="number");return num?v34XNum(v):v34XText(v)}).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${xml}</sheetData></worksheet>`;
    const wb=`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rel=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const root=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const ct=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
    return {bytes,from,to};
  }
  function v34Pdf(pack){
    const {r,all,data}=pack,from=r.from||data[0].date,to=r.to||data[data.length-1].date,opening=v34Opening(all,from),calc=v34Rows(data,opening);
    const W=842,H=595,M=24,top=38,bottom=34,colW=[58,70,100,78,72,65,78,78,85],headers=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=v=>v34Text(v).replace(/[^\x20-\x7E]/g,"?"); const esc=v=>pdfEscape(safe(v));
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];const a=[];let c="";v.split(/\s+/).forEach(q=>{if((c+" "+q).trim().length<=n)c=(c?c+" ":"")+q;else{if(c)a.push(c);if(q.length>n){for(let i=0;i<q.length;i+=n)a.push(q.slice(i,i+n));c=""}else c=q}});if(c)a.push(c);return a.length?a:[""]}
    function rr(row){const cells=row.map((v,i)=>wrap(v,colW[i]));return {cells,h:Math.max(18,Math.max(...cells.map(c=>c.length))*lh+4)}}
    const prepared=calc.rows.map(x=>rr([x[0],x[1],x[2],x[3],x[4],x[5],x[6]===""?"":Number(x[6]).toFixed(2),x[7]===""?"":Number(x[7]).toFixed(2),Number(x[8]).toFixed(2)]));
    const pages=[];let pg=[],y=top+28;prepared.forEach(x=>{if(y+x.h>H-bottom&&pg.length){pages.push(pg);pg=[];y=top+28}pg.push(x);y+=x.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[];const add=o=>{objs.push(o);return objs.length};const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach((page,pi)=>{let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(from+" to "+to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,texts,bold){s+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fs} Tf\n`;texts.forEach((t,i)=>s+=`1 0 0 1 ${x+2.5} ${y-2.5-7-i*lh} Tm (${esc(t)}) Tj\n`);s+="ET\n"}
      let x=M;headers.forEach((h,i)=>{cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(row=>{x=M;row.cells.forEach((c,i)=>{cell(x,yy,colW[i],row.h,c,false);x+=colW[i]});yy-=row.h});
      if(pi===pages.length-1){yy-=14;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (ACCOUNT SUMMARY) Tj\nET\n`;yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[opening.toFixed(2),calc.withdrawals.toFixed(2),calc.deposits.toFixed(2),calc.closing.toFixed(2),String(data.length)];x=M;labs.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (******************* END OF REPORT *******************) Tj\nET\n`}
      s+="Q";cids.push(add(`<< /Length ${s.length} >>\nstream\n${s}\nendstream`));pids.push(null)
    });
    const pagesId=add("PAGES");pages.forEach((_,i)=>pids[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${cids[i]} 0 R >>`));objs[pagesId-1]=`<< /Type /Pages /Kids [${pids.map(x=>x+" 0 R").join(" ")}] /Count ${pids.length} >>`;const cat=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);let pdf="%PDF-1.4\n",offs=[0];objs.forEach((o,i)=>{offs[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xr=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${cat} 0 R >>\nstartxref\n${xr}\n%%EOF`;return {blob:new Blob([pdf],{type:"application/pdf"}),from,to};
  }
  window.exportExcel=function(){const p=v34Pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}const x=v34MakeXlsx(p);downloadBlob(new Blob([x.bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${x.from}_to_${x.to}.xlsx`)};
  window.exportPDF=function(){const p=v34Pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}const x=v34Pdf(p);downloadBlob(x.blob,`money_transactions_${x.from}_to_${x.to}.pdf`)};
})();
