
/* V64 — PROFILE SWITCH ADD-TRANSACTION SECURITY UI REFRESH
   Scope: UI-state refresh only.
   - Reads security state from the newly active Profile/Mode after switching.
   - Removes stale Add Transaction/PIN overlays from the previous profile.
   - Refreshes the Add Transaction lock/unlock indicator for the destination profile.
   - Does NOT modify PIN hashes, biometric credentials, transactions, backup/restore,
     dashboard data, authentication, or profile data.
*/
(function(){
  const PK="money_manager_profiles_v10";
  const AK="money_manager_active_profile_v10";

  function activeProfileFresh(){
    try{
      const ps=JSON.parse(localStorage.getItem(PK)||"[]");
      if(!Array.isArray(ps)) return null;
      const id=localStorage.getItem(AK);
      return ps.find(p=>p&&p.id===id)||ps[0]||null;
    }catch(e){return null;}
  }

  function refreshAddTransactionForActiveProfile(){
    const p=activeProfileFresh();
    const on=!!(p&&p.security&&p.security.addProtection);

    // Close any security UI belonging to the previous profile. The destination
    // profile must start with a clean Add Transaction security state.
    ["v10AddTxGate","v10AddTxSettingGate","v10AddTxPinModal"].forEach(function(id){
      const el=document.getElementById(id);
      if(el) el.style.display="none";
    });

    // Refresh every visible Add Transaction security indicator directly from
    // the currently selected profile instead of reusing the previous UI state.
    const toggle=document.getElementById("v10AddTxPinToggle");
    if(toggle) toggle.checked=on;

    const state=document.getElementById("v10AddTxPinState");
    if(state) state.textContent=on ? "ON — PIN required before adding" : "OFF — no PIN required";

    const menuStatus=document.getElementById("v10MenuAddTxStatus");
    if(menuStatus) menuStatus.textContent=on ? "🔒 ON" : "🔓 OFF";

    const addButton=document.getElementById("v10AddTxButton");
    if(addButton) addButton.textContent=on ? "🔒 Add Transaction (PIN)" : "Save Transaction";

    // If the app already exposes its normal refresh function, run it once too;
    // this keeps any existing UI elements synchronized without changing logic.
    try{
      if(typeof window.v10RefreshAddTxSecurityUI === "function")
        window.v10RefreshAddTxSecurityUI();
    }catch(e){}
  }

  const previousSwitch=window.v10SwitchProfile;
  if(typeof previousSwitch === "function" && !previousSwitch.__mfV64ProfileRefresh){
    const wrapped=function(id){
      const result=previousSwitch.apply(this,arguments);
      // The active profile ID is changed by previousSwitch first. Refresh only
      // after that change so the UI reads the destination profile's state.
      setTimeout(refreshAddTransactionForActiveProfile,0);
      return result;
    };
    wrapped.__mfV64ProfileRefresh=true;
    window.v10SwitchProfile=wrapped;
  }

  // Also repair the UI once on startup without changing any saved security state.
  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",function(){setTimeout(refreshAddTransactionForActiveProfile,0);});
  }else{
    setTimeout(refreshAddTransactionForActiveProfile,0);
  }
})();
