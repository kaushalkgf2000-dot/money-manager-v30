
/* V30 Android native biometric integration.
   The browser/WebAuthn path remains intact outside APK. In the APK, AndroidBiometric
   uses the real Android BiometricPrompt and falls back to the existing PIN gate. */
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=profiles(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function sec(){const p=active();if(!p)return null;p.security=p.security||{};if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false;return p.security}
  function setStatus(){const s=sec();const on=!!(s&&s.bioEnabled);const item=document.getElementById("v30BioMenuItem");if(item)item.textContent=on?"🔐 Fingerprint / Biometric: ON":"🔐 Fingerprint / Biometric: OFF";const st=document.getElementById("v30BioStatus");if(st)st.textContent=on?"ON — biometric first; PIN fallback":"OFF — PIN is used normally"}
  function nativeAvailable(){try{return !!(window.AndroidBiometric&&AndroidBiometric.isAvailable&&AndroidBiometric.isAvailable())}catch(e){return false}}

  // Override the biometric settings UI only; all existing app data/settings remain untouched.
  // IMPORTANT: biometric setup follows the same PIN prerequisite as the other
  // security actions. If this active Profile X has no PIN yet, show the
  // canonical Create PIN flow first; never jump directly to PIN verification.
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();

    // Use the same canonical active-profile security state used by PIN Setup
    // and Transaction Log. Biometric setup must NEVER request a PIN that does
    // not exist. First create the active Profile / Mode PIN, then return here.
    const current=active();
    const currentSec=(typeof window.v10ActiveSecurity==="function")
      ? (window.v10ActiveSecurity()||{})
      : (current&&current.security||{});
    if(!currentSec.pinHash){
      if(typeof window.mfRequestCommonSecurity==="function"){
        window.mfRequestCommonSecurity(function(){
          window.v30OpenBiometricSettings();
        },null,"biometric");
      }else{
        alert("Please create your Profile PIN first. Biometric setup requires the Profile PIN.");
      }
      return;
    }
    let m=document.getElementById("v30NativeBioModal");
    if(!m){
      m=document.createElement("div");m.id="v30NativeBioModal";m.className="v10modal";
      m.innerHTML='<div class="v10box"><h2>🔐 Fingerprint / Biometric</h2><p id="v30NativeBioStatus" class="v10small"></p><button type="button" id="v30NativeBioToggle">Turn ON</button><button type="button" class="secondary" id="v30NativeBioClose">Close</button></div>';
      document.body.appendChild(m);
      document.getElementById("v30NativeBioToggle").onclick=function(){
        const p=active(),s=sec();if(!p||!s)return;

        // Defensive second check at the moment the user taps Turn ON/OFF.
        // This prevents a stale biometric modal from bypassing the normal
        // first-time Create PIN flow after a Profile / Mode switch.
        if(!s.pinHash){
          m.style.display="none";
          if(typeof window.mfRequestCommonSecurity==="function"){
            window.mfRequestCommonSecurity(function(){
              window.v30OpenBiometricSettings();
            },null,"biometric");
          }else{
            alert("No PIN is created for this Profile / Mode. Please create the PIN first.");
          }
          return;
        }

        if(!nativeAvailable()){alert("Biometric is not available on this Android device. PIN remains available.");return;}
        const pin=prompt(s.bioEnabled?"Enter your current PIN to disable Biometric:":"Enter your current PIN to enable Biometric:");
        if(pin===null)return;
        // Verify against the exact same active-profile PIN used by Edit/Add/security.
        if(typeof window.mmV26VerifyPin!=="function" || !window.mmV26VerifyPin(String(pin||""))){alert("Incorrect PIN.");return;}
        if(s.bioEnabled){s.bioEnabled=false;const ps=profiles();const q=ps.find(x=>x.id===p.id);if(q)q.security=s;save(ps);setStatus();refresh();alert("Biometric is OFF. PIN will be used.");return;}
        window.__v30BioTogglePending=function(ok){
          window.__v30BioTogglePending=null;
          if(!ok){alert("Biometric verification was cancelled or failed. Biometric remains OFF.");return;}
          s.bioEnabled=true;const ps=profiles();const q=ps.find(x=>x.id===p.id);if(q)q.security=s;save(ps);setStatus();refresh();alert("Biometric is ON. Security actions will show the biometric prompt first; PIN is the fallback.");
        };
        AndroidBiometric.authenticate("v30BioToggleResult");
      };
      document.getElementById("v30NativeBioClose").onclick=function(){m.style.display="none"};
    }
    function refresh(){const s=sec(),on=!!(s&&s.bioEnabled);const st=document.getElementById("v30NativeBioStatus");const b=document.getElementById("v30NativeBioToggle");if(st)st.textContent=on?"ON — biometric first; if unavailable/cancelled, PIN is shown.":"OFF — PIN is used normally.";if(b)b.textContent=on?"Turn OFF":"Turn ON / Verify Biometric";setStatus();}
    refresh();m.style.display="block";
  };
  window.v30BioToggleResult=function(ok){if(typeof window.__v30BioTogglePending==="function")window.__v30BioTogglePending(!!ok)};

  // Native biometric-first gate for the unified PIN flow used by Edit/Add/security.
  const original=window.v26AskPin;
  if(typeof original==="function" && !window.__v30NativeBioWrapped){
    window.__v30NativeBioWrapped=true;
    window.v26AskPin=function(ok,cancel){
      const s=sec();
      if(s&&s.bioEnabled&&nativeAvailable()){
        window.__v30PendingGate={ok:ok,cancel:cancel};
        AndroidBiometric.authenticate("v30BioGateResult");
        return false;
      }
      return original(ok,cancel);
    };
  }
  window.v30BioGateResult=function(ok){
    const p=window.__v30PendingGate;window.__v30PendingGate=null;if(!p)return;
    if(ok){if(typeof p.ok==="function")p.ok();return;}
    // Biometric cancelled/unavailable: show the normal PIN gate.
    if(typeof original==="function")original(p.ok,p.cancel);
  };
  function boot(){
    const item=document.getElementById("v30BioMenuItem");
    if(item){item.onclick=window.v30OpenBiometricSettings;setStatus();}
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,300);setTimeout(boot,1000);
})();
