
/* FINAL PROFILE/MODE FRESH-START FIX
   Any Mode created before the profile-security marker existed is treated as a
   fresh workspace on its first switch, so it cannot inherit the old Mode PIN.
*/
(function(){
  const PK='money_manager_profiles_v10', AK='money_manager_active_profile_v10';
  function profiles(){try{const x=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(x)?x:[]}catch(e){return[]}}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function freshSecurity(){return {mode:'NONE',pinHash:'',recoveryCode:'',editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true}}
  const oldSwitch=window.v10SwitchProfile;
  window.v10SwitchProfile=function(id){
    const a=profiles(),p=a.find(x=>x.id===id); if(!p)return;
    // Old inactive Modes may contain a copied legacy/global PIN. Reset only
    // those unmarked Modes; the current/established profile remains untouched.
    if(!p.security || p.security.profileSecurityInitialized!==true){
      p.security=freshSecurity();
      if(!Array.isArray(p.transactions))p.transactions=[];
      save(a);
    }
    if(typeof oldSwitch==='function')return oldSwitch(id);
  };
})();
