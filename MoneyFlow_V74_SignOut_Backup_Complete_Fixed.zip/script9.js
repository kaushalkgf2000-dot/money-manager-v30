
/* Firebase Analytics feature telemetry for Money Flow / PaisaFlow.
   Deliberately logs feature/action names only — never PINs, transaction amounts,
   descriptions, balances, recovery codes, or other financial/user-entered data. */
(function(){
  function logFeature(name){try{if(window.AndroidAnalytics&&AndroidAnalytics.logFeature)AndroidAnalytics.logFeature(name)}catch(e){}}
  function logAction(name){try{if(window.AndroidAnalytics&&AndroidAnalytics.logAction)AndroidAnalytics.logAction(name)}catch(e){}}
  window.pfAnalytics={feature:logFeature,action:logAction};

  var featureMap={
    'v10ProfileModal':'profile_mode',
    'mfBackupModal':'backup_restore',
    'v10PinModal':'pin_security',
    'v10AddTxPinModal':'add_transaction_pin',
    'historyModal':'transaction_history',
    'pfExportModal':'transaction_export',
    'customModal':'customisation'
  };
  document.addEventListener('click',function(e){
    var el=e.target&&e.target.closest?e.target.closest('button'):null;
    if(!el)return;
    var id=el.id||'';
    if(id==='v10AddTxButton'){logAction('transaction_added');return;}
    if(id==='v30BioEnable'){logAction('biometric_enable');return;}
    if(id==='v30BioDisable'){logAction('biometric_disable');return;}
    var t=(el.textContent||'').replace(/\s+/g,' ').trim();
    var low=t.toLowerCase();
    if(low.indexOf('profile / mode')>=0){logFeature('profile_mode');return;}
    if(low.indexOf('backup & restore')>=0){logFeature('backup_restore');return;}
    if(low.indexOf('pin setup / change')>=0){logFeature('pin_security');return;}
    if(low.indexOf('add transaction pin')>=0){logFeature('add_transaction_pin');return;}
    if(low.indexOf('transaction history')>=0){logFeature('transaction_history');return;}
    if(low.indexOf('transaction export')>=0){logFeature('transaction_export');return;}
    if(low.indexOf('widgets')>=0){logFeature('widgets');return;}
    if(low.indexOf('customisation')>=0){logFeature('customisation');return;}
    if(low.indexOf('backup now')>=0){logAction('backup_now');return;}
    if(low.indexOf('restore backup file')>=0){logAction('restore_backup_file');return;}
    if(low==='save changes'){logAction('transaction_edited');return;}
  },true);

  // Track successful/failed native biometric callback without collecting biometric data.
  var oldBio=window.v30BioGateResult;
  if(typeof oldBio==='function'){
    window.v30BioGateResult=function(ok){logAction(ok?'biometric_gate_success':'biometric_gate_failed');return oldBio.apply(this,arguments);};
  }
})();
