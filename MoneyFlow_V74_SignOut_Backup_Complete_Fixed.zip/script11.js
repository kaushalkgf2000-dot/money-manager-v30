
/* V26 — ONE PROFILE SECURITY STATE
   Fixes:
   1) Edit must never create a second PIN if Menu already created one.
   2) Menu/Edit/Add must read/write the SAME active profile.security object.
   3) Legacy global edit PIN storage is no longer authoritative.
*/
(function(){
  const PK="money_manager_profiles_v10";
  const AK="money_manager_active_profile_v10";

  const freshSecurity=()=>({
    mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,
    addProtection:false,bioEnabled:false,
    pinFailedAttempts:0,pinLockUntil:0,
    profileSecurityInitialized:true
  });

  function profiles(){
    try{
      const a=JSON.parse(localStorage.getItem(PK)||"[]");
      return Array.isArray(a)?a:[];
    }catch(e){return[]}
  }
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function active(){
    const a=profiles(),id=localStorage.getItem(AK);
    return a.find(p=>p.id===id)||a[0]||null;
  }
  function activeSecurity(){
    const p=active();
    if(!p)return null;
    if(!p.security||typeof p.security!=="object")p.security=freshSecurity();
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    if(p.security.profileSecurityInitialized!==true){
      // The active profile is the only profile whose pre-existing security
      // can safely be retained; inactive uninitialized profiles are fresh.
      p.security.profileSecurityInitialized=true;
    }
    const a=profiles(),q=a.find(x=>x.id===p.id);
    if(q)q.security=p.security;
    save(a);
    return p.security;
  }

  // Stop the old v109Profiles routine from importing money_manager_edit_security_v1.
  window.v109Profiles=profiles;
  window.v109ActiveProfile=active;
  window.v109SaveProfiles=save;

  // Stop legacy global storage from participating in security decisions.
  try{
    localStorage.removeItem("money_manager_edit_security_v1");
    localStorage.removeItem("mm_global_pin");
    localStorage.removeItem("globalPin");
    localStorage.removeItem("globalPinHash");
    localStorage.removeItem("pinHash");
  }catch(e){}

  function H(v){
    let h=2166136261;v=String(v||"");
    for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }

  function persist(sec){
    const p=active();if(!p)return;
    p.security=sec;
    const a=profiles(),q=a.find(x=>x.id===p.id);
    if(q)q.security=sec;
    save(a);
  }

  // Shared PIN verifier used by both the normal PIN gate and native biometric settings.
  // This prevents the biometric settings screen from using a different/stale PIN source.
  window.mmV26VerifyPin=function(pin){
    const s=activeSecurity();
    if(!s || !s.pinHash) return false;
    return H(String(pin||""))===s.pinHash;
  };

  // Unified PIN gate. It uses the same custom Add/Edit gate already in V25.
  window.v26AskPin=function(ok,cancel){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return false;}

    const gate=document.getElementById("v10AddTxGate");
    const body=document.getElementById("v10AddTxGateBody");
    if(!gate||!body){alert("PIN security screen is unavailable.");return false;}

    if(!s.pinHash){
      body.innerHTML=
        '<h3>🔐 Create PIN</h3>'+
        '<p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p>'+
        '<input id="v26NewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">'+
        '<input id="v26ConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">'+
        '<button type="button" id="v26CreatePin">Create PIN</button>'+
        '<button type="button" class="secondary" id="v26CancelPin">Cancel</button>';
      gate.style.display="block";
      document.getElementById("v26CreatePin").onclick=function(){
        const a=document.getElementById("v26NewPin").value;
        const b=document.getElementById("v26ConfirmPin").value;
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PINs do not match.");return}
        s.pinHash=H(a);
        s.recoveryCode=s.recoveryCode||recovery();
        s.profileSecurityInitialized=true;
        persist(s);
        body.innerHTML=
          '<h3>✅ PIN Created</h3>'+
          '<p>Save this Recovery Code safely:</p>'+
          '<div class="v10code">'+s.recoveryCode+'</div>'+
          '<p class="v10small">This PIN is shared by Edit and Add Transaction.</p>'+
          '<button type="button" id="v26ContinuePin">Continue</button>';
        document.getElementById("v26ContinuePin").onclick=function(){
          gate.style.display="none"; if(typeof ok==="function")ok();
        };
      };
      document.getElementById("v26CancelPin").onclick=function(){
        gate.style.display="none";if(typeof cancel==="function")cancel();
      };
      return false;
    }

    body.innerHTML=
      '<h3>🔐 Enter PIN</h3>'+
      '<p>Enter your existing profile PIN.</p>'+
      '<input id="v26PinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">'+
      '<button type="button" id="v26VerifyPin">Continue</button>'+
      '<button type="button" class="secondary" id="v26CancelVerify">Cancel</button>';
    gate.style.display="block";

    document.getElementById("v26VerifyPin").onclick=function(){
      const pin=document.getElementById("v26PinInput").value;
      const now=Date.now(),until=Number(s.pinLockUntil||0);
      if(until>now){
        alert("Too many incorrect PIN attempts. Please wait "+Math.ceil((until-now)/1000)+" seconds.");
        return;
      }
      if(until&&until<=now){s.pinLockUntil=0;s.pinFailedAttempts=0;persist(s);}
      if(H(pin)!==s.pinHash){
        s.pinFailedAttempts=Number(s.pinFailedAttempts||0)+1;
        if(s.pinFailedAttempts>=5){
          s.pinFailedAttempts=0;s.pinLockUntil=Date.now()+30000;
          persist(s);
          alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");
        }else{
          persist(s);
          alert("Incorrect PIN. Attempts remaining: "+(5-s.pinFailedAttempts)+".");
        }
        return;
      }
      s.pinFailedAttempts=0;s.pinLockUntil=0;persist(s);
      gate.style.display="none";if(typeof ok==="function")ok();
    };
    document.getElementById("v26CancelVerify").onclick=function(){
      gate.style.display="none";if(typeof cancel==="function")cancel();
    };
    return false;
  };

  // Add Transaction always uses the active profile's addProtection.
  window.v109RequestAddTransaction=function(){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return false;}
    if(!s.addProtection){
      return typeof v109RealAdd==="function" ? v109RealAdd() : false;
    }
    return window.v26AskPin(
      function(){ if(typeof v109RealAdd==="function")v109RealAdd(); },
      function(){}
    );
  };

  // Edit always uses the SAME gate/state.
  window.v10RequestEdit=function(id){
    const t=(typeof txs!=="undefined"?txs:[]).find(x=>x.id===id);
    if(!t)return;
    if(typeof canEditTransaction==="function"&&!canEditTransaction(t)){
      alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");
      return;
    }
    window.v26AskPin(function(){
      document.getElementById("editId").value=id;
      const editDate=document.getElementById("editDate");
      if(editDate)editDate.max=localToday();
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },function(){});
  };

  // Menu ON/OFF uses the same active profile security and the same PIN gate.
  window.v10SaveAddTxPinSetting=function(desired){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return;}
    desired=!!desired;
    if(!!s.addProtection===desired){
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
      return;
    }
    window.v26AskPin(function(){
      const ss=activeSecurity();
      if(!ss)return;
      ss.addProtection=desired;
      persist(ss);
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
    },function(){
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
    });
  };
  window.v10ChooseAddTxSecurity=function(desired){window.v10SaveAddTxPinSetting(!!desired);};

  // Expose the same security object to any later V25/V24 compatibility calls.
  window.mmV26ActiveSecurity=activeSecurity;
  window.mmV24ActiveSecurity=activeSecurity;
})();
