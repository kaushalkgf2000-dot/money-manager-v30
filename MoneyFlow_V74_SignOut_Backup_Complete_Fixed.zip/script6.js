
/* FINAL MORE MENU BEHAVIOR FIX
   - Tap More to toggle the menu.
   - Tap anywhere outside the menu to close it.
   - Opening any submenu/modal from More closes More first.
   - Close / X also returns to the dashboard underneath.
*/
(function(){
  function menu(){return document.getElementById('menuPanel')}
  function more(){return document.getElementById('moreNavBtn')}
  document.addEventListener('click',function(e){
    const m=menu(); if(!m || m.style.display!=='block')return;
    if(m.contains(e.target) || (more() && more().contains(e.target)))return;
    if(typeof closeMenu==='function')closeMenu();
  },false);
  window.addEventListener('resize',function(){if(typeof closeMenu==='function')closeMenu()});
  window.addEventListener('scroll',function(){if(typeof closeMenu==='function')closeMenu()},{passive:true});
  const itemIds=['customModal','historyModal','pfExportModal','mfBackupModal','v10ProfileModal','v10PinModal','v10AddTxPinModal','v10AddTxSettingGate','v10AddTxGate'];
  itemIds.forEach(function(id){
    const el=document.getElementById(id);
    if(!el)return;
    el.addEventListener('click',function(e){
      if(e.target===el && typeof closeMenu==='function')closeMenu();
    });
  });
})();
