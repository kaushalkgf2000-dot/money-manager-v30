
/* V35 — DEFINITIVE SELECTED-DATE EXPORT FIX
   The export source is the same live transaction array used by the dashboard.
   The selected From/To values are read directly from the date inputs at the
   moment Export is pressed. No stale filtered array/profile copy is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function normDate(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return "";
  }
  function rawTx(){
    try{if(Array.isArray(txs)&&txs.length)return txs.slice()}catch(e){}
    try{
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x&&String(x.id)===String(id))||ps[0];
      if(p&&Array.isArray(p.transactions))return p.transactions.slice();
    }catch(e){}
    return [];
  }
  function normalize(t){
    return {
      id:t&&t.id,
      date:normDate(t&&t.date),
      type:text(t&&t.type).toUpperCase(),
      amount:Number(t&&t.amount)||0,
      balance:(t&&t.balance!==undefined&&Number.isFinite(Number(t.balance)))?Number(t.balance):null,
      category:text(t&&t.category),description:text(t&&(t.description||t.desc)),
      remark:text(t&&(t.remark||t.remarks||t.note)),mode:text(t&&(t.mode||t.paymentMode||t.payment_mode)),
      other:text(t&&(t.other||t.otherInfo||t.other_info)),createdAt:text(t&&t.createdAt)
    };
  }
  function allTx(){
    return rawTx().map(normalize).filter(t=>t.date&&t.amount>0&&(t.type==="CREDIT"||t.type==="EXPENSE"||t.type==="DEBIT"))
      .sort((a,b)=>a.date.localeCompare(b.date)||a.createdAt.localeCompare(b.createdAt));
  }
  function range(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=normDate(f&&f.value),to=normDate(t&&t.value);
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function pack(){
    const r=range(); if(!r)return null;
    const all=allTx();
    const data=all.filter(t=>t.date>=r.from&&t.date<=r.to);
    // Opening balance is the balance of the last transaction strictly before From Date.
    let opening=0;
    const before=all.filter(t=>t.date<r.from);
    if(before.length){
      const last=before[before.length-1];
      if(last.balance!==null) opening=last.balance;
      else {for(const q of before) opening += q.type==="CREDIT"?q.amount:-q.amount;}
    }
    return {all,data,from:r.from,to:r.to,opening};
  }
  function calc(p){
    let b=p.opening,w=0,d=0;
    const rows=p.data.map(t=>{
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount}
      else {w+=t.amount;b-=t.amount}
      return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.type==="CREDIT"?"":t.amount,t.type==="CREDIT"?t.amount:"",b];
    });
    return {rows,w,d,b};
  }
  function xmlEsc(v){return text(v).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}
  function xText(v){return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`}
  function xNum(v){return `<c><v>${Number(v)||0}</v></c>`}
  function makeXlsx(p){
    const c=calc(p);
    const rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    rows.push(...c.rows); rows.push([]); rows.push(["ACCOUNT SUMMARY"]);
    rows.push(["OPENING BALANCE",p.opening,"TOTAL WITHDRAWALS",c.w,"TOTAL DEPOSITS",c.d,"CLOSING BALANCE",c.b,"No. of Transactions",p.data.length]);
    rows.push([]); rows.push(["******************* END OF REPORT *******************"]);
    const body=rows.map((r,ri)=>`<row>${r.map((v,i)=>{
      const num=(ri>0&&ri<=p.data.length&&i>=6&&i<=8)||(ri===p.data.length+2&&typeof v==="number");
      return num?xNum(v):xText(v);
    }).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
    const wb=`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rel=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const root=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const ct=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function pdfBlob(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=v=>text(v).replace(/[^\x20-\x7E]/g,"?");
    const esc=v=>pdfEscape(safe(v));
    const wrap=(v,w)=>{v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";for(const q0 of v.split(/\s+/)){let q=q0;if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}}if(cur)a.push(cur);return a.length?a:[""]};
    const prep=c.rows.map(r=>{const vals=[r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)];const cells=vals.map((v,i)=>wrap(v,colW[i]));return {cells,h:Math.max(18,Math.max(...cells.map(a=>a.length))*lh+4)}});
    const pages=[];let pg=[],y=86;for(const r of prep){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h}if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=o=>{objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach((page,pi)=>{let s=`q\nBT\n/F1 10 Tf\n1 0 0 1 ${M} 567 Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n/F1 8 Tf\n1 0 0 1 ${M} 555 Tm (${esc("Period: "+p.from+" to "+p.to)}) Tj\nET\n`,yy=540;
      const cell=(x,y,w,h,vals,bold)=>{s+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fs} Tf\n`;vals.forEach((v,i)=>s+=`1 0 0 1 ${x+2.5} ${y-2.5-7-i*lh} Tm (${esc(v)}) Tj\n`);s+="ET\n"};
      let x=M;heads.forEach((h,i)=>{cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;
      page.forEach(r=>{x=M;r.cells.forEach((cc,i)=>{cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (ACCOUNT SUMMARY) Tj\nET\n`;yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[p.opening.toFixed(2),c.w.toFixed(2),c.d.toFixed(2),c.b.toFixed(2),String(p.data.length)];x=M;labs.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (******************* END OF REPORT *******************) Tj\nET\n`}
      s+="Q";cids.push(add(`<< /Length ${s.length} >>\nstream\n${s}\nendstream`));pids.push(null)
    });
    const pagesId=add("PAGES");pages.forEach((_,i)=>pids[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${cids[i]} 0 R >>`));objs[pagesId-1]=`<< /Type /Pages /Kids [${pids.map(x=>x+" 0 R").join(" ")}] /Count ${pids.length} >>`;const cat=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);let pdf="%PDF-1.4\n",offs=[0];objs.forEach((o,i)=>{offs[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xr=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${cat} 0 R >>\nstartxref\n${xr}\n%%EOF`;return new Blob([pdf],{type:"application/pdf"});
  }
  window.filteredTransactions=function(){const p=pack();return p?p.data:null};
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${p.from}_to_${p.to}.xlsx`)};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(pdfBlob(p),`money_transactions_${p.from}_to_${p.to}.pdf`)};
})();
