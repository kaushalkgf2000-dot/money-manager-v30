
/* V33 — STATEMENT-STYLE EXPORT + CORRECT OPENING BALANCE
   Export order: oldest -> latest.
   Opening balance: latest running balance immediately BEFORE the selected From date.
   Financial columns: Withdrawal / Deposit; Type and Amount are not printed.
   Closing balance must reconcile with the full transaction history through the
   selected To date. PDF and XLSX use the same calculation and same rows.
*/
(function(){
  function v33DateKey(v){
    const s=String(v==null?"":v).trim();
    if(!s)return "";
    // Accept the formats used by browser date inputs and older saved data.
    let m=s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return s.slice(0,10);
  }
  function v33ReadArray(key){
    try{const v=JSON.parse(localStorage.getItem(key)||"[]");return Array.isArray(v)?v:[];}catch(e){return[];}
  }
  function v33Normalize(t){
    const x=t||{};
    return {...x,
      date:v33DateKey(x.date),
      type:String(x.type||"").toUpperCase(),
      amount:Number(x.amount)||0,
      category:x.category||"",
      description:x.description||x.desc||"",
      remark:x.remark||x.remarks||x.note||"",
      mode:x.mode||x.paymentMode||x.payment_mode||"",
      other:x.other||x.otherInfo||x.other_info||""
    };
  }
  function v33Same(a,b){
    return a&&b&&String(a.id||"")===String(b.id||"") && a.id!=null && b.id!=null ||
      a&&b&&v33DateKey(a.date)===v33DateKey(b.date)&&String(a.type||"").toUpperCase()===String(b.type||"").toUpperCase()&&Number(a.amount||0)===Number(b.amount||0)&&String(a.category||"")===String(b.category||"");
  }
  function v33All(){
    // Read the active profile first, then legacy/in-memory stores as fallback.
    // This prevents a valid transaction list from disappearing because one
    // storage copy is stale or the date was stored in a different format.
    const sources=[];
    const ps=v33ReadArray("money_manager_profiles_v10");
    const aid=localStorage.getItem("money_manager_active_profile_v10");
    const ap=ps.find(p=>p&&p.id===aid)||ps[0];
    if(ap&&Array.isArray(ap.transactions)) sources.push(ap.transactions);
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))sources.push(txs);}catch(e){}
    const legacy=v33ReadArray(typeof KEY!=="undefined"?KEY:"money_manager_v1");
    if(legacy.length)sources.push(legacy);
    const out=[];
    sources.forEach(arr=>arr.forEach(raw=>{
      const n=v33Normalize(raw);
      if(!n.date||!n.type||!(n.amount>0))return;
      if(!out.some(x=>v33Same(x,n)))out.push(n);
    }));
    return out;
  }
  function v33Range(){
    const from=document.getElementById("pdfFrom")?.value||"";
    const to=document.getElementById("pdfTo")?.value||"";
    if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
    if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function v33Order(data){
    return data.map((t,i)=>({...t,__exportIndex:i})).sort((a,b)=>{
      const d=String(a.date||"").localeCompare(String(b.date||""));
      return d || a.__exportIndex-b.__exportIndex;
    });
  }
  function v33Calc(all, from){
    // Preferred source: a stored running balance from the last transaction
    // immediately before the selected range. This is the exact bank-statement
    // style opening-balance rule. Older records without balance fall back to
    // their cumulative movement rather than inventing a value.
    const before=v33Order(all).filter(t=>!from||String(t.date||"")<from);
    if(before.length){
      const last=before[before.length-1];
      const stored=Number(last.balance);
      if(Number.isFinite(stored))return stored;
    }
    let opening=0;
    before.forEach(t=>{const a=Number(t.amount)||0;opening+=t.type==="CREDIT"?a:-a;});
    return opening;
  }
  function v33Filtered(){
    const r=v33Range(); if(!r)return null;
    const all=v33Order(v33All());
    const data=all.filter(t=>(!r.from||String(t.date||"")>=r.from)&&(!r.to||String(t.date||"")<=r.to));
    return {r,all,data};
  }
  function v33Safe(v){return String(v==null?"":v).trim()}

  function buildRows(data, opening){
    let balance=opening, deposits=0, withdrawals=0;
    const rows=[];
    data.forEach(t=>{
      const a=Number(t.amount)||0;
      let withdrawal="", deposit="";
      if(t.type==="CREDIT"){deposit=a; deposits+=a; balance+=a;}
      else {withdrawal=a; withdrawals+=a; balance-=a;}
      rows.push([
        t.date||"", t.category||"", t.description||"", t.remark||"",
        t.mode||"", t.other||"", withdrawal, deposit, balance
      ]);
    });
    return {rows,deposits,withdrawals,closing:balance};
  }

  window.exportExcel=function(){
    const pack=v33Filtered(); if(!pack)return;
    const {r,all,data}=pack;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const from=r.from||data[0].date, to=r.to||data[data.length-1].date;
    const opening=v33Calc(all,from);
    const calc=buildRows(data,opening);
    const rows=[[
      "Date","Category","Description","Remark","Payment Mode","Other",
      "Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"
    ]];
    rows.push(...calc.rows);
    rows.push([]);
    rows.push(["ACCOUNT SUMMARY"]);
    rows.push(["OPENING BALANCE",opening,"TOTAL WITHDRAWALS",calc.withdrawals,
               "TOTAL DEPOSITS",calc.deposits,"CLOSING BALANCE",calc.closing,
               "No. of Transactions",data.length]);
    rows.push([]);
    rows.push(["******************* END OF REPORT *******************"]);

    const sheetRows=rows.map((row,rowIndex)=>`<row>${row.map((v,i)=>{
      const numeric = (typeof v==="number" && Number.isFinite(v));
      // Transaction financial columns: Withdrawal, Deposit, Balance = 6,7,8.
      if(rowIndex>0 && rowIndex<=data.length && (i===6||i===7||i===8)){
        return xlsxNumber(numeric?v:0);
      }
      if(rowIndex===data.length+2){
        return numeric?xlsxNumber(v):xlsxText(v);
      }
      return xlsxText(v);
    }).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
    const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([{name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},{name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
    downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${from}_to_${to}.xlsx`);
  };

  window.exportPDF=function(){
    const pack=v33Filtered(); if(!pack)return;
    const {r,all,data}=pack;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const from=r.from||data[0].date, to=r.to||data[data.length-1].date;
    const opening=v33Calc(all,from), calc=buildRows(data,opening);
    const width=842,height=595,margin=24,top=38,bottom=34;
    // Date, Category, Description, Remark, Payment Mode, Other, Withdrawal, Deposit, Balance
    const colW=[58,70,100,78,72,65,78,78,85];
    const headers=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"];
    const fontSize=6.8,lineH=9,headerH=20,pad=2.5,maxY=height-bottom;
    function safeText(v){return v33Safe(v).replace(/[^\x20-\x7E]/g,"?")}
    function esc(s){return pdfEscape(safeText(s))}
    function wrap(text,w){
      text=safeText(text); const approx=Math.max(5,Math.floor((w-pad*2)/(fontSize*.52)));
      if(!text)return [""]; const out=[]; let cur="";
      text.split(/\s+/).forEach(word=>{if(!word)return;if(word.length>approx){if(cur){out.push(cur);cur=""}for(let i=0;i<word.length;i+=approx)out.push(word.slice(i,i+approx));}
      else if(!cur)cur=word;else if((cur+" "+word).length<=approx)cur+=" "+word;else{out.push(cur);cur=word;}});
      if(cur)out.push(cur); return out.length?out:[""];
    }
    function rowLines(row){const cells=row.map((v,i)=>wrap(v,colW[i]));return {cells,n:Math.max(...cells.map(c=>c.length)),h:Math.max(18,Math.max(...cells.map(c=>c.length))*lineH+4)}}
    const prepared=calc.rows.map(row=>rowLines([
      row[0],row[1],row[2],row[3],row[4],row[5],
      row[6]===""?"":Number(row[6]).toFixed(2),
      row[7]===""?"":Number(row[7]).toFixed(2),
      Number(row[8]).toFixed(2)
    ]));
    const pages=[];let page=[],y=top+28;
    for(const rr of prepared){if(y+rr.h>maxY&&page.length){pages.push(page);page=[];y=top+28;}page.push(rr);y+=rr.h;}if(page.length||!pages.length)pages.push(page);
    let objs=[];const add=o=>{objs.push(o);return objs.length};
    const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pageIds=[],contentIds=[];
    pages.forEach((pg,pi)=>{
      let stream="q\n";
      stream+=`BT\n/F1 10 Tf\n1 0 0 1 ${margin} ${height-28} Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n`;
      stream+=`/F1 8 Tf\n1 0 0 1 ${margin} ${height-40} Tm (${esc(`Period: ${from} to ${to}`)}) Tj\nET\n`;
      let yy=height-55;
      function cell(x,y,w,h,texts,bold){stream+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fontSize} Tf\n`;texts.forEach((tx,i)=>{const ty=y-pad-7-i*lineH;stream+=`1 0 0 1 ${x+pad} ${ty} Tm (${esc(tx)}) Tj\n`});stream+="ET\n"}
      let x=margin;headers.forEach((h,i)=>{cell(x,yy,colW[i],headerH,[h],true);x+=colW[i]});yy-=headerH;
      pg.forEach(rr=>{x=margin;rr.cells.forEach((cc,i)=>{cell(x,yy,colW[i],rr.h,cc,false);x+=colW[i]});yy-=rr.h});
      if(pi===pages.length-1){
        yy-=14;stream+=`BT\n/F1 9 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("ACCOUNT SUMMARY")}) Tj\nET\n`;yy-=16;
        const sumW=[130,130,130,130,130];
        const labels=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"];
        const vals=[opening.toFixed(2),calc.withdrawals.toFixed(2),calc.deposits.toFixed(2),calc.closing.toFixed(2),String(data.length)];
        let sx=margin;labels.forEach((lab,i)=>{cell(sx,yy,sumW[i],16,[lab],true);sx+=sumW[i]});
        yy-=16;sx=margin;vals.forEach((val,i)=>{cell(sx,yy,sumW[i],16,[val],false);sx+=sumW[i]});
        yy-=27;stream+=`BT\n/F1 9 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("******************* END OF REPORT *******************")}) Tj\nET\n`;
      }
      stream+="Q";const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);contentIds.push(cid);pageIds.push(null);
    });
    const pagesId=add("PAGES_PLACEHOLDER");pages.forEach((_,i)=>{pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`)});objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let pdf="%PDF-1.4\n",offsets=[0];objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xref=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    downloadBlob(new Blob([pdf],{type:"application/pdf"}),`money_transactions_${from}_to_${to}.pdf`);
  };
})();
