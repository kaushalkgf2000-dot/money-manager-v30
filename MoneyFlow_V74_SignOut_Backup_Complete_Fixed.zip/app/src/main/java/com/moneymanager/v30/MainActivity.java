package com.moneymanager.v30;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetHost;
import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;
import android.text.InputType;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.webkit.ValueCallback;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.database.Cursor;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.util.Base64;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;
import android.os.Bundle;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import android.accounts.Account;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    // Holds a Google credential only for the short account-linking flow when
    // the Google email already belongs to an email/password Firebase user.
    private AuthCredential pendingGoogleCredential;
    private String pendingGoogleEmail;
    private WebView webView;
    private FirebaseAnalytics firebaseAnalytics;
    private FirebaseAuth firebaseAuth;
    private ValueCallback<Uri[]> filePathCallback;
    private final Handler handler = new Handler();
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int BACKUP_FILE_REQUEST = 4102;
    private static final int GOOGLE_SIGN_IN_REQUEST = 6201;
    private static final int GOOGLE_DRIVE_AUTH_REQUEST = 6202;
    private static final String DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private String pendingDriveOperation = "";
    private String pendingDriveJson = "";

    private String appSigningSha1() {
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
            android.content.pm.Signature[] sigs = pi.signingInfo.hasMultipleSigners()
                    ? pi.signingInfo.getApkContentsSigners()
                    : pi.signingInfo.getSigningCertificateHistory();
            if (sigs == null || sigs.length == 0) return "unknown";
            byte[] digest = MessageDigest.getInstance("SHA-1").digest(sigs[0].toByteArray());
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                if (i > 0) out.append(':');
                out.append(String.format(java.util.Locale.US, "%02X", digest[i] & 0xff));
            }
            return out.toString();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private CloudBackupBridge cloudBackupBridge;
    private final Executor executor = command -> handler.post(command);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        firebaseAuth = FirebaseAuth.getInstance();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            // Replace the default WebView JavaScript dialogs. Android's default
            // implementation prefixes them with "The page at file:/// says:",
            // which exposes an internal implementation detail to the user.
            @Override public boolean onJsAlert(WebView view, String url, String message, final JsResult result){
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Money Flow")
                    .setMessage(message == null ? "" : message)
                    .setPositiveButton("OK", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, final JsResult result){
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Money Flow")
                    .setMessage(message == null ? "" : message)
                    .setNegativeButton("CANCEL", (dialog, which) -> result.cancel())
                    .setPositiveButton("OK", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result){
                final EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setText(defaultValue == null ? "" : defaultValue);
                String lower = String.valueOf(message == null ? "" : message).toLowerCase(java.util.Locale.US);
                if(lower.contains("pin")){
                    input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                }else{
                    input.setInputType(InputType.TYPE_CLASS_TEXT);
                }
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Money Flow")
                    .setMessage(message == null ? "" : message)
                    .setView(input)
                    .setNegativeButton("CANCEL", (dialog, which) -> result.cancel())
                    .setPositiveButton("OK", (dialog, which) -> result.confirm(input.getText().toString()))
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
                    startActivityForResult(i,FILE_CHOOSER_REQUEST);
                    return true;
                }catch(Exception e){
                    filePathCallback=null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new BioBridge(this), "AndroidBiometric");
        webView.addJavascriptInterface(new FileBridge(this), "AndroidFile");
        webView.addJavascriptInterface(new WidgetBridge(this), "AndroidWidget");
        webView.addJavascriptInterface(new BackupBridge(this), "AndroidBackup");
        cloudBackupBridge = new CloudBackupBridge(this);
        webView.addJavascriptInterface(cloudBackupBridge, "AndroidCloudBackup");
        webView.addJavascriptInterface(new AuthBridge(this), "AndroidAuth");
        webView.addJavascriptInterface(new AnalyticsBridge(this), "AndroidAnalytics");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        // Google Sign-In callback. The previous build started the Google
        // account picker but never consumed its result, so Firebase never
        // received the Google ID token.
        if(requestCode==GOOGLE_SIGN_IN_REQUEST){
            if(resultCode!=RESULT_OK || data==null){
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google','Google Sign-In was cancelled.','','')", null));
                return;
            }
            try{
                GoogleSignInAccount account=GoogleSignIn.getSignedInAccountFromIntent(data)
                    .getResult(ApiException.class);
                if(account==null || account.getIdToken()==null || account.getIdToken().isEmpty()){
                    webView.post(() -> webView.evaluateJavascript(
                        "window.mfAuthResult && window.mfAuthResult(false,'google','Google did not return a valid ID token.','','')", null));
                    return;
                }
                AuthCredential credential=GoogleAuthProvider.getCredential(account.getIdToken(),null);
                FirebaseUser current=firebaseAuth.getCurrentUser();
                if(current!=null && current.getEmail()!=null && account.getEmail()!=null
                    && current.getEmail().equalsIgnoreCase(account.getEmail())){
                    boolean alreadyGoogle=false;
                    for(com.google.firebase.auth.UserInfo info: current.getProviderData()){
                        if("google.com".equals(info.getProviderId())){ alreadyGoogle=true; break; }
                    }
                    if(!alreadyGoogle){
                        current.linkWithCredential(credential)
                            .addOnSuccessListener(authResult -> {
                                pendingGoogleCredential=null;
                                pendingGoogleEmail=null;
                                FirebaseUser u=firebaseAuth.getCurrentUser();
                                String email=u!=null && u.getEmail()!=null?u.getEmail():account.getEmail();
                                String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():account.getDisplayName();
                                String js="window.mfAuthResult && window.mfAuthResult(true,'google','Google Sign-In linked successfully to this Money Flow account.',"
                                    +org.json.JSONObject.quote(email==null?"":email)+","
                                    +org.json.JSONObject.quote(name==null?"":name)+")";
                                webView.post(() -> webView.evaluateJavascript(js,null));
                            })
                            .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript(
                                "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(authErrorForGoogle(e))+",'','')", null)));
                    }else{
                        FirebaseUser u=current;
                        String email=u.getEmail()==null?account.getEmail():u.getEmail();
                        String name=u.getDisplayName()==null?account.getDisplayName():u.getDisplayName();
                        String js="window.mfAuthResult && window.mfAuthResult(true,'google','Google Sign-In is already linked to this account.',"
                            +org.json.JSONObject.quote(email==null?"":email)+","
                            +org.json.JSONObject.quote(name==null?"":name)+")";
                        webView.post(() -> webView.evaluateJavascript(js,null));
                    }
                }else{
                    firebaseAuth.signInWithCredential(credential)
                    .addOnSuccessListener(authResult -> {
                        pendingGoogleCredential=null;
                        pendingGoogleEmail=null;
                        FirebaseUser u=firebaseAuth.getCurrentUser();
                        String email=u!=null && u.getEmail()!=null?u.getEmail():account.getEmail();
                        String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():account.getDisplayName();
                        String js="window.mfAuthResult && window.mfAuthResult(true,'google','Signed in with Google successfully.',"
                            +org.json.JSONObject.quote(email==null?"":email)+","
                            +org.json.JSONObject.quote(name==null?"":name)+")";
                        webView.post(() -> webView.evaluateJavascript(js,null));
                    })
                    .addOnFailureListener(e -> {
                        if(isAccountExistsConflict(e)){
                            pendingGoogleCredential=credential;
                            pendingGoogleEmail=account.getEmail();
                        }
                        String message=authErrorForGoogle(e);
                        webView.post(() -> webView.evaluateJavascript(
                            "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(message)+",'','')", null));
                    });
                }
            }catch(ApiException e){
                String message="Google Sign-In failed (code "+e.getStatusCode()+").";
                if(e.getStatusCode()==10) message="Google Sign-In configuration error (DEVELOPER_ERROR). Check the package name and SHA-1 in Firebase, then rebuild with the latest google-services.json.";
                final String finalMessage=message;
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(finalMessage)+",'','')", null));
            }catch(Exception e){
                String message=e.getMessage()==null?"Google Sign-In failed.":e.getMessage();
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(message)+",'','')", null));
            }
            return;
        }

        if(requestCode==GOOGLE_DRIVE_AUTH_REQUEST){
            try{
                AuthorizationResult ar=Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                if(ar==null || ar.getAccessToken()==null || ar.getAccessToken().isEmpty()){
                    cloudBackupBridge.driveResultError(pendingDriveOperation,"Google Drive authorization was not completed.");
                }else{
                    String op=pendingDriveOperation;
                    String json=pendingDriveJson;
                    pendingDriveOperation=""; pendingDriveJson="";
                    cloudBackupBridge.rememberDriveAccount(ar);
                    cloudBackupBridge.runDriveOperation(op,json,ar.getAccessToken());
                }
            }catch(Exception e){
                String op=pendingDriveOperation;
                pendingDriveOperation=""; pendingDriveJson="";
                cloudBackupBridge.driveResultError(op,e.getMessage()==null?"Google Drive authorization failed.":e.getMessage());
            }
            return;
        }

        if(requestCode==BACKUP_FILE_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
                    while((n=in.read(buf))!=-1)out.write(buf,0,n);
                    String json=out.toString("UTF-8");
                    final String js="window.mfApplyBackup("+org.json.JSONObject.quote(json)+")";
                    webView.post(()->webView.evaluateJavascript(js,null));
                }catch(Exception e){
                    webView.post(()->android.widget.Toast.makeText(this,"Restore failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());
                }
            }
            return;
        }
        if(requestCode!=FILE_CHOOSER_REQUEST)return;
        if(filePathCallback==null)return;
        Uri[] result=null;
        if(resultCode==RESULT_OK && data!=null){
            Uri u=data.getData();
            if(u!=null)result=new Uri[]{u};
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback=null;
    }

    public class FileBridge {
        private final Context ctx; FileBridge(Context c){ctx=c;}
        @JavascriptInterface public void saveFile(String name, String mime, String b64){
            try{
                byte[] data=Base64.getDecoder().decode(b64);
                if(android.os.Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Manager");
                    Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null)throw new Exception("Could not create download file");
                    try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved to Downloads/Money Manager: "+name,android.widget.Toast.LENGTH_LONG).show());
                } else {
                    java.io.File dir=new java.io.File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Money Manager");
                    if(!dir.exists())dir.mkdirs();
                    java.io.File f=new java.io.File(dir,name);
                    try(java.io.FileOutputStream out=new java.io.FileOutputStream(f)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved: "+f.getAbsolutePath(),android.widget.Toast.LENGTH_LONG).show());
                }
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Export failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
    }


    public class BackupBridge {
        private final Context ctx; BackupBridge(Context c){ctx=c;}
        private java.io.File snapshot(){return new java.io.File(ctx.getFilesDir(),"money_flow_backup_snapshot.json");}
        @JavascriptInterface public void saveBackupSnapshot(String json){
            try{java.io.File f=snapshot();try(java.io.FileOutputStream out=new java.io.FileOutputStream(f,false)){out.write(json.getBytes(StandardCharsets.UTF_8));} }
            catch(Exception e){ }
        }
        @JavascriptInterface public String getBackupSnapshot(){
            try{java.io.File f=snapshot();if(!f.exists())return "";return new String(java.nio.file.Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);}catch(Exception e){return "";}
        }
        @JavascriptInterface public String getBackupMeta(){
            try{java.io.File f=snapshot();if(!f.exists())return "No recovery snapshot created yet.";return "✓ Recovery snapshot available • "+new java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a",java.util.Locale.getDefault()).format(new java.util.Date(f.lastModified()));}catch(Exception e){return "Backup status unavailable.";}
        }
        @JavascriptInterface public void exportBackupFile(String json,String name){
            try{
                android.content.ContentValues v=new android.content.ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/json");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Flow Backup");
                Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Could not create backup file");
                try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(json.getBytes(StandardCharsets.UTF_8));}
                webView.post(()->android.widget.Toast.makeText(ctx,"Backup saved to Downloads/Money Flow Backup",android.widget.Toast.LENGTH_LONG).show());
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Backup file could not be saved. Please check your device storage and try again.",android.widget.Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBackupFile(){
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,BACKUP_FILE_REQUEST);}catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"File picker unavailable",android.widget.Toast.LENGTH_SHORT).show());}
        }
    }

    public class CloudBackupBridge {
        private final Context ctx;
        CloudBackupBridge(Context c){ctx=c;}

        private FirebaseUser user(){ return firebaseAuth.getCurrentUser(); }
        private String uid(){ FirebaseUser u=user(); return u==null?"":u.getUid(); }
        private String email(){ FirebaseUser u=user(); return u!=null&&u.getEmail()!=null?u.getEmail():""; }
        private String fileName(){ return "paisaflow_backup_"+uid()+".json"; }

        private void status(String message){
            webView.post(() -> webView.evaluateJavascript(
                "window.mfCloudStatusResult && window.mfCloudStatusResult("+org.json.JSONObject.quote(message)+")",null));
        }
        private void backupResult(boolean ok,String message){
            webView.post(() -> webView.evaluateJavascript(
                "window.mfCloudBackupResult && window.mfCloudBackupResult("+ok+","+org.json.JSONObject.quote(message)+")",null));
        }
        private void restoreResult(boolean ok,String payload){
            webView.post(() -> webView.evaluateJavascript(
                "window.mfCloudRestoreResult && window.mfCloudRestoreResult("+ok+","+org.json.JSONObject.quote(payload==null?"":payload)+")",null));
        }
        private String friendlyDriveError(String operation,String message){
            String m=message==null?"":message.trim();
            String low=m.toLowerCase(java.util.Locale.US);
            boolean network=low.contains("unable to resolve host")
                || low.contains("no address associated with hostname")
                || low.contains("unknownhostexception")
                || low.contains("network is unreachable")
                || low.contains("failed to connect")
                || low.contains("connection refused")
                || low.contains("connection reset")
                || low.contains("timed out")
                || low.contains("timeout")
                || low.contains("socketexception")
                || low.contains("eai_noname")
                || low.contains("eai_again");
            if(network){
                if("restore".equals(operation))
                    return "Restore couldn't be completed because your internet connection is unavailable. Connect to the internet and try again. Your current data has not been changed.";
                if("status".equals(operation))
                    return "We couldn't check your latest backup because your internet connection is unavailable. Connect to the internet and try again.";
                return "Backup couldn't be completed because your internet connection is unavailable. Connect to the internet and try again.";
            }
            if(low.contains("401") || low.contains("unauthorized") || low.contains("invalid credentials") || low.contains("access token")){
                if("restore".equals(operation))
                    return "Restore couldn't be completed because Google Drive needs you to sign in again. Please sign in and try again.";
                if("status".equals(operation))
                    return "We couldn't check your latest backup because Google Drive needs you to sign in again.";
                return "Backup couldn't be completed because Google Drive needs you to sign in again.";
            }
            if(low.contains("403") || low.contains("permission denied") || low.contains("forbidden"))
                return "Google Drive permission is not available for this account. Please sign in again and try.";
            if(low.contains("404") || low.contains("not found")){
                if("restore".equals(operation)) return "No backup was found in your Google Drive for this account.";
                return "The Google Drive backup could not be found. Please try again.";
            }
            if(low.contains("quota"))
                return "Google Drive storage is unavailable for this backup. Please check your Google Drive storage and try again.";
            if(m.isEmpty()) return "Something went wrong. Please try again.";
            if(m.startsWith("Google Drive HTTP ") || m.contains("Exception") || m.contains("java.") || m.contains("www.googleapis.com"))
                return "Google Drive couldn't complete this request. Please try again.";
            return m;
        }

        private void driveResultError(String operation,String message){
            if("restore".equals(operation)) restoreResult(false,message);
            else if("status".equals(operation)) status(message);
            else backupResult(false,message);
        }

        private void rememberDriveAccount(AuthorizationResult ar){
            try{
                GoogleSignInAccount googleAccount=ar==null?null:ar.toGoogleSignInAccount();
                Account a=googleAccount==null?null:googleAccount.getAccount();
                if(a!=null && a.name!=null && !a.name.isEmpty()){
                    getSharedPreferences("paisaflow_drive",MODE_PRIVATE).edit()
                        .putString("drive_email",a.name).apply();
                }
            }catch(Exception ignored){}
        }

        private void requestDriveAuthorization(String operation,String json){
            FirebaseUser u=user();
            if(u==null){
                if("restore".equals(operation))restoreResult(false,"Please sign in to your PaisaFlow account first.");
                else backupResult(false,"Please sign in to your PaisaFlow account first.");
                return;
            }
            pendingDriveOperation=operation;
            pendingDriveJson=json==null?"":json;
            try{
                AuthorizationRequest.Builder builder=AuthorizationRequest.builder()
                    .setRequestedScopes(java.util.Collections.singletonList(new Scope(DRIVE_APPDATA_SCOPE)));
                // When the Firebase account was signed in with Google, prefer the
                // same Google account for Drive authorization. For email/password
                // accounts Google will show the normal account chooser if needed.
                try{
                    GoogleSignInAccount ga=GoogleSignIn.getLastSignedInAccount(MainActivity.this);
                    if(ga!=null && ga.getAccount()!=null) builder.setAccount(ga.getAccount());
                }catch(Exception ignored){}
                AuthorizationRequest request=builder.build();
                Identity.getAuthorizationClient(MainActivity.this).authorize(request)
                    .addOnSuccessListener(ar -> {
                        if(ar.hasResolution()){
                            try{
                                startIntentSenderForResult(ar.getPendingIntent().getIntentSender(),GOOGLE_DRIVE_AUTH_REQUEST,null,0,0,0,null);
                            }catch(Exception e){
                                String op=pendingDriveOperation;
                                pendingDriveOperation=""; pendingDriveJson="";
                                driveResultError(op,"Could not open Google Drive authorization.");
                            }
                        }else if(ar.getAccessToken()!=null && !ar.getAccessToken().isEmpty()){
                            String op=pendingDriveOperation, body=pendingDriveJson;
                            pendingDriveOperation=""; pendingDriveJson="";
                            rememberDriveAccount(ar);
                            runDriveOperation(op,body,ar.getAccessToken());
                        }else{
                            String op=pendingDriveOperation;
                            pendingDriveOperation=""; pendingDriveJson="";
                            driveResultError(op,"Google Drive authorization returned no access token.");
                        }
                    })
                    .addOnFailureListener(e -> {
                        String op=pendingDriveOperation;
                        pendingDriveOperation=""; pendingDriveJson="";
                        String m=e.getMessage()==null?"Google Drive authorization failed.":e.getMessage();
                        if(m.contains("UNREGISTERED_ON_API_CONSOLE"))
                            m="Google Drive sign-in is not configured for this app. Please contact support.";
                        driveResultError(op,m);
                    });
            }catch(Exception e){
                String op=pendingDriveOperation;
                pendingDriveOperation=""; pendingDriveJson="";
                cloudBackupBridge.driveResultError(op,"Google Drive authorization failed: "+(e.getMessage()==null?"unknown error":e.getMessage()));
            }
        }

        private void runDriveOperation(String operation,String json,String token){
            if(operation==null)operation="";
            final String op=operation;
            new Thread(() -> {
                try{
                    if("upload".equals(op)){
                        uploadToDrive(json,token,false);
                    }else if("restore".equals(op)){
                        restoreFromDrive(token);
                    }else if("status".equals(op)){
                        driveStatus(token);
                    }else{
                        throw new Exception("Unknown Google Drive operation.");
                    }
                }catch(Exception e){
                    String m=friendlyDriveError(op,e.getMessage()==null?"Google Drive operation failed.":e.getMessage());
                    webView.post(() -> {
                        if("restore".equals(op)) restoreResult(false,m); else if("status".equals(op)) status(m); else backupResult(false,m);
                    });
                }
            },"PaisaFlow-Drive").start();
        }

        private String http(String method,String url,String token,String contentType,byte[] body) throws Exception{
            java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
            c.setRequestMethod(method); c.setConnectTimeout(20000); c.setReadTimeout(30000);
            c.setRequestProperty("Authorization","Bearer "+token);
            c.setRequestProperty("Accept","application/json");
            if(contentType!=null){c.setRequestProperty("Content-Type",contentType);}
            if(body!=null){c.setDoOutput(true);c.setFixedLengthStreamingMode(body.length);try(OutputStream out=c.getOutputStream()){out.write(body);}}
            int code=c.getResponseCode();
            InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
            String text="";
            if(in!=null){try(InputStream x=in){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=x.read(b))!=-1)out.write(b,0,n);text=out.toString("UTF-8");}}
            if(code<200||code>=300)throw new Exception("Google Drive HTTP "+code+(text.isEmpty()?"":": "+text));
            return text;
        }

        private org.json.JSONObject getBackupFileMetadata(String token) throws Exception{
            String q="'appDataFolder' in parents and name='"+fileName().replace("'","\\'")+"' and trashed=false";
            String url="https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=10&fields=files(id,name,modifiedTime,size)&q="+java.net.URLEncoder.encode(q,"UTF-8");
            String r=http("GET",url,token,null,null);
            org.json.JSONObject o=new org.json.JSONObject(r);
            org.json.JSONArray a=o.optJSONArray("files");
            if(a!=null&&a.length()>0)return a.getJSONObject(0);
            return null;
        }

        private String listBackupFile(String token) throws Exception{
            org.json.JSONObject meta=getBackupFileMetadata(token);
            return meta==null?"":meta.optString("id","");
        }

        private String formatBackupTime(long millis){
            try{
                return new SimpleDateFormat("dd MMM yyyy, hh:mm:ss a",Locale.getDefault()).format(new Date(millis));
            }catch(Exception e){
                return String.valueOf(millis);
            }
        }

        private String formatDriveModifiedTime(String value){
            if(value==null||value.trim().isEmpty())return "";
            try{
                String s=value.trim();
                SimpleDateFormat parser;
                if(s.matches(".*\\.\\d{3,}Z$")){
                    // Drive timestamps are UTC ISO-8601. Keep millisecond precision
                    // internally, but display seconds to the user as requested.
                    s=s.replaceFirst("(\\.\\d{3})\\d*Z$","$1Z");
                    parser=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX",Locale.US);
                }else{
                    parser=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX",Locale.US);
                }
                Date d=parser.parse(s);
                return d==null?"":formatBackupTime(d.getTime());
            }catch(Exception e){return "";}
        }

        private void uploadToDrive(String json,String token) throws Exception{
            uploadToDrive(json,token,false);
        }

        private void uploadToDrive(String json,String token,boolean signOutAfterSuccess) throws Exception{
            if(json==null||json.isEmpty()){backupResult(false,"Google Drive backup failed: empty backup.");return;}
            org.json.JSONObject payload=new org.json.JSONObject(json);
            payload.put("accountUid",uid());
            payload.put("accountEmail",email());
            payload.put("backupProvider","Google Drive appDataFolder");
            payload.put("backupUpdatedAt",System.currentTimeMillis());
            String finalJson=payload.toString();
            String id=listBackupFile(token);
            if(id.isEmpty()){
                org.json.JSONObject meta=new org.json.JSONObject();
                meta.put("name",fileName());
                meta.put("mimeType","application/json");
                meta.put("parents",new org.json.JSONArray().put("appDataFolder"));
                String created=http("POST","https://www.googleapis.com/drive/v3/files?fields=id",token,"application/json; charset=UTF-8",meta.toString().getBytes(StandardCharsets.UTF_8));
                id=new org.json.JSONObject(created).optString("id","");
                if(id.isEmpty())throw new Exception("Google Drive did not return a backup file ID.");
            }
            String url="https://www.googleapis.com/upload/drive/v3/files/"+java.net.URLEncoder.encode(id,"UTF-8")+"?uploadType=media";
            http("PATCH",url,token,"application/json; charset=UTF-8",finalJson.getBytes(StandardCharsets.UTF_8));
            // Google Drive's successful write time is the user-visible backup
            // status. Show the exact local date/time down to seconds for both
            // automatic and manual cloud backups.
            final String msg="☁️ Last backup updated: "+formatBackupTime(System.currentTimeMillis());
            if(signOutAfterSuccess){
                // The sign-out decision is completed natively only after the
                // Google Drive PATCH has returned success. This removes the
                // WebView callback race that could leave the modal stuck at
                // “Backing Up…” even though the Drive file was already updated.
                webView.post(() -> completeSignOutAfterBackup());
            }else{
                webView.post(() -> backupResult(true,msg));
            }
        }

        private void restoreFromDrive(String token) throws Exception{
            String id=listBackupFile(token);
            if(id.isEmpty()){restoreResult(false,"No Google Drive backup found for this account.");return;}
            String url="https://www.googleapis.com/drive/v3/files/"+java.net.URLEncoder.encode(id,"UTF-8")+"?alt=media";
            String json=http("GET",url,token,null,null);
            org.json.JSONObject payload=new org.json.JSONObject(json);
            String backupUid=payload.optString("accountUid","");
            if(!backupUid.isEmpty()&&!backupUid.equals(uid())){
                restoreResult(false,"No Google Drive backup found for this PaisaFlow account.");return;
            }
            restoreResult(true,json);
        }

        private void driveStatus(String token) throws Exception{
            org.json.JSONObject meta=getBackupFileMetadata(token);
            if(meta==null){status("☁️ Google Drive backup not created yet");return;}
            String modified=meta.optString("modifiedTime","");
            String when=formatDriveModifiedTime(modified);
            if(when.isEmpty())when=formatBackupTime(System.currentTimeMillis());
            status("☁️ Last backup updated: "+when);
        }

        @JavascriptInterface public void uploadCloudBackup(String json){
            if(uid().isEmpty()){backupResult(false,"Cloud backup unavailable: Please sign in first.");return;}
            requestDriveAuthorization("upload",json);
        }
        @JavascriptInterface public void uploadCloudBackupAndSignOut(String json){
            if(uid().isEmpty()){backupResult(false,"Cloud backup unavailable: Please sign in first.");return;}
            requestDriveAuthorization("upload_signout",json);
        }
        @JavascriptInterface public void restoreCloudBackup(){
            if(uid().isEmpty()){restoreResult(false,"Cloud restore unavailable: Please sign in first.");return;}
            requestDriveAuthorization("restore","");
        }
        @JavascriptInterface public void getCloudStatus(){
            if(uid().isEmpty()){status("Sign in required for Google Drive backup.");return;}
            requestDriveAuthorization("status","");
        }
    }

    private boolean isAccountExistsConflict(Exception e){
        String m=e==null?"":String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.US);
        return m.contains("account-exists-with-different-credential")
            || m.contains("email already exists")
            || m.contains("credential is already associated");
    }

    private String authErrorForGoogle(Exception e){
        String m=e==null?"Google Sign-In failed.":e.getMessage();
        if(m==null)m="Google Sign-In failed.";
        String low=m.toLowerCase(java.util.Locale.US);
        if(isAccountExistsConflict(e))
            return "This Google email already has a Money Flow email/password account. Log in with that email and password once; Google will then be linked automatically. No new verification is required for an already verified account.";
        if(low.contains("network")) return "Network error. Check your internet connection.";
        if(low.contains("credential")) return "Google account authentication failed. Please try again.";
        return m;
    }

    private void linkPendingGoogleIfApplicable(FirebaseUser fresh, String loginEmail){
        if(pendingGoogleCredential==null || pendingGoogleEmail==null || fresh==null || fresh.getEmail()==null
            || !pendingGoogleEmail.equalsIgnoreCase(loginEmail)
            || !pendingGoogleEmail.equalsIgnoreCase(fresh.getEmail())){
            resultLoginSuccess();
            return;
        }
        AuthCredential credential=pendingGoogleCredential;
        pendingGoogleCredential=null;
        pendingGoogleEmail=null;
        fresh.linkWithCredential(credential)
            .addOnSuccessListener(r -> resultLoginSuccess("Email/password login succeeded and Google Sign-In is now linked to the same Money Flow account."))
            .addOnFailureListener(e -> {
                String m=e.getMessage()==null?"Google could not be linked automatically.":e.getMessage();
                resultLoginSuccess("Signed in successfully. Google could not be linked automatically: "+m);
            });
    }

    private void resultLoginSuccess(){ resultLoginSuccess("Signed in successfully."); }
    private void resultLoginSuccess(String message){
        FirebaseUser u=firebaseAuth.getCurrentUser();
        String email=u!=null&&u.getEmail()!=null?u.getEmail():"";
        String name=u!=null&&u.getDisplayName()!=null?u.getDisplayName():"";
        String uid=u!=null&&u.getUid()!=null?u.getUid():"";
        String js="window.mfAuthResult && window.mfAuthResult(true,'login',"+org.json.JSONObject.quote(message)+","+org.json.JSONObject.quote(email)+","+org.json.JSONObject.quote(name)+","+org.json.JSONObject.quote(uid)+")";
        webView.post(()->webView.evaluateJavascript(js,null));
    }

    private void completeSignOutAfterBackup(){
        pendingGoogleCredential=null;
        pendingGoogleEmail=null;
        firebaseAuth.signOut();
        try{
            int id=getResources().getIdentifier("default_web_client_id","string",getPackageName());
            if(id!=0){
                String clientId=getString(id);
                if(clientId!=null&&!clientId.isEmpty()){
                    GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail().requestIdToken(clientId).build();
                    GoogleSignIn.getClient(MainActivity.this,gso).signOut();
                }
            }
        }catch(Exception ignored){}
        webView.post(() -> webView.evaluateJavascript(
            "window.mfAuthResult && window.mfAuthResult(true,'logout','Backup completed successfully. Signed out successfully.','','','')",null));
    }

    public class AuthBridge {
        private final Context ctx;
        AuthBridge(Context c){ctx=c;}

        private String q(String s){ return org.json.JSONObject.quote(s==null?"":s); }
        private void result(boolean ok, String action, String message){
            com.google.firebase.auth.FirebaseUser u=firebaseAuth.getCurrentUser();
            String email=u!=null && u.getEmail()!=null?u.getEmail():"";
            String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():"";
            String uid=u!=null&&u.getUid()!=null?u.getUid():""; String js="window.mfAuthResult && window.mfAuthResult("+ok+","+q(action)+","+q(message)+","+q(email)+","+q(name)+","+q(uid)+")";
            webView.post(()->webView.evaluateJavascript(js,null));
        }

        @JavascriptInterface public void getStatus(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u==null){ result(true,"status","signed_out"); return; }
            // Google Sign-In is now the only supported Money Flow authentication
            // method. Do not allow an old Email/Password-only session to bypass
            // the Google-only account gate. Accounts that also have google.com
            // linked remain valid.
            u.reload().addOnCompleteListener(task -> {
                FirebaseUser fresh=firebaseAuth.getCurrentUser();
                if(fresh==null){ result(true,"status","signed_out"); return; }
                if(!hasGoogleProvider(fresh)){
                    firebaseAuth.signOut();
                    result(true,"status","signed_out");
                }else{
                    result(true,"status","signed_in");
                }
            });
        }

        @JavascriptInterface public void signUp(String name, String email, String password){
            if(email==null || email.trim().isEmpty()){ result(false,"signup","Email is required."); return; }
            if(password==null || password.length()<6){ result(false,"signup","Password must be at least 6 characters."); return; }
            firebaseAuth.createUserWithEmailAndPassword(email.trim(),password)
                .addOnSuccessListener(r->{
                    FirebaseUser u=firebaseAuth.getCurrentUser();
                    Runnable sendVerification=()->{
                        FirebaseUser current=firebaseAuth.getCurrentUser();
                        if(current==null){result(false,"signup","Account was created, but the verification session is unavailable.");return;}
                        current.sendEmailVerification()
                            .addOnSuccessListener(v->{
                                // Keep the newly created Firebase session alive so the
                                // user can resend/check verification without having
                                // to authenticate twice. Dashboard access is still
                                // blocked until the email is verified.
                                result(true,"verify_required","Account created. We sent a verification link to your email. Verify it, then tap “I Have Verified My Email”. Check Spam/Promotions if you do not see it.");
                            })
                            .addOnFailureListener(e->{
                                result(false,"signup","Account created, but the verification email could not be sent: "+authError(e));
                            });
                    };
                    if(u!=null && name!=null && !name.trim().isEmpty()){
                        com.google.firebase.auth.UserProfileChangeRequest req=new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build();
                        u.updateProfile(req).addOnCompleteListener(x->sendVerification.run());
                    }else sendVerification.run();
                })
                .addOnFailureListener(e->result(false,"signup",authError(e)));
        }

        @JavascriptInterface public void signIn(String email, String password){
            if(email==null || email.trim().isEmpty() || password==null || password.isEmpty()){ result(false,"login","Enter your email and password."); return; }
            firebaseAuth.signInWithEmailAndPassword(email.trim(),password)
                .addOnSuccessListener(r->{
                    FirebaseUser u=firebaseAuth.getCurrentUser();
                    if(u==null){ result(false,"login","Authentication succeeded but the account session was unavailable."); return; }
                    // Always refresh before deciding whether an email/password
                    // account is allowed into the dashboard. An unverified email
                    // remains signed in only so the user can resend verification
                    // or check verification status; dashboard access is blocked.
                    u.reload().addOnCompleteListener(reload -> {
                        FirebaseUser fresh=firebaseAuth.getCurrentUser();
                        if(fresh==null){
                            result(false,"login","Authentication succeeded but the account session was unavailable.");
                            return;
                        }
                        if(isEmailPasswordProvider(fresh) && !fresh.isEmailVerified()){
                            result(true,"verify_required","Your email address is not verified yet. Please verify it from your email, then tap “I Have Verified My Email”. You can also resend the verification email.");
                            return;
                        }
                        linkPendingGoogleIfApplicable(fresh, email.trim());
                    });
                })
                .addOnFailureListener(e->result(false,"login",authError(e)));
        }

        @JavascriptInterface public void signInWithGoogle(){
            try{
                int id=getResources().getIdentifier("default_web_client_id","string",getPackageName());
                if(id==0){ result(false,"google","Google Sign-In is not configured in this Firebase Android app yet. Enable Google provider and add the Firebase-generated OAuth client, then rebuild."); return; }
                String clientId=getString(id);
                if(clientId==null || clientId.trim().isEmpty()){ result(false,"google","Google Sign-In is not configured yet. Enable Google provider in Firebase and rebuild with the updated google-services.json."); return; }
                GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail().requestProfile().requestIdToken(clientId).build();
                Intent intent=GoogleSignIn.getClient(MainActivity.this,gso).getSignInIntent();
                startActivityForResult(intent,GOOGLE_SIGN_IN_REQUEST);
            }catch(Exception e){ result(false,"google","Google Sign-In failed to start: "+e.getMessage()); }
        }

        @JavascriptInterface public void resendVerification(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u!=null){
                u.reload().addOnCompleteListener(reload -> {
                    FirebaseUser fresh=firebaseAuth.getCurrentUser();
                    if(fresh==null){
                        result(false,"verify_sent","Please log in again to resend the verification email.");
                        return;
                    }
                    if(!isEmailPasswordProvider(fresh)){
                        result(true,"verify_sent","This account uses Google Sign-In, so a separate email verification step is not required.");
                        return;
                    }
                    if(fresh.isEmailVerified()){
                        result(true,"verify_sent","Your email is already verified. Tap “I Have Verified My Email” to continue.");
                        return;
                    }
                    fresh.sendEmailVerification()
                        .addOnSuccessListener(v->result(true,"verify_sent","Verification email sent successfully. Please check Inbox, Spam and Promotions."))
                        .addOnFailureListener(e->result(false,"verify_sent",authError(e)));
                });
                return;
            }
            result(false,"verify_sent","Please log in with your email and password first, then resend the verification email.");
        }

        @JavascriptInterface public void checkEmailVerification(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u==null){ result(false,"verify_check","Please log in with your email and password first."); return; }
            u.reload().addOnCompleteListener(reload -> {
                FirebaseUser fresh=firebaseAuth.getCurrentUser();
                if(fresh==null){ result(false,"verify_check","Your account session expired. Please log in again."); return; }
                if(isEmailPasswordProvider(fresh) && !fresh.isEmailVerified()){
                    result(false,"verify_check","Your email is still not verified. Please open the verification email, tap its link, then try again.");
                    return;
                }
                result(true,"verified","Email verified successfully. You can now enter Money Flow.");
            });
        }

        @JavascriptInterface public void signOut(){
            completeSignOutAfterBackup();
        }

        @JavascriptInterface public void resetPassword(String email){
            if(email==null || email.trim().isEmpty()){ result(false,"reset","Enter your account email first."); return; }
            String address=email.trim();
            firebaseAuth.sendPasswordResetEmail(address)
                .addOnSuccessListener(v->result(true,"reset","Password reset email sent successfully to "+address+". Open that email and use the reset link to create a new password. If you do not see it within a few minutes, check Spam, Promotions and All Mail."))
                .addOnFailureListener(e->result(false,"reset",authError(e)));
        }

        private boolean isEmailPasswordProvider(FirebaseUser u){
            if(u==null) return false;
            for(com.google.firebase.auth.UserInfo info : u.getProviderData()){
                if(info!=null && "password".equalsIgnoreCase(info.getProviderId())) return true;
            }
            return false;
        }

        private boolean hasGoogleProvider(FirebaseUser u){
            if(u==null) return false;
            for(com.google.firebase.auth.UserInfo info : u.getProviderData()){
                if(info!=null && "google.com".equalsIgnoreCase(info.getProviderId())) return true;
            }
            return false;
        }

        private String authError(Exception e){
            String m=e==null?"Authentication failed.":e.getMessage();
            if(m==null)m="Authentication failed.";
            if(m.contains("password is invalid") || m.contains("INVALID_LOGIN_CREDENTIALS")) return "Incorrect email or password.";
            if(m.contains("email address is badly formatted")) return "Please enter a valid email address.";
            if(m.contains("email address is already in use")) return "This email is already registered. Please log in.";
            if(m.contains("password should be at least 6 characters")) return "Password must be at least 6 characters.";
            if(m.contains("network error") || m.contains("unable to resolve host") || m.contains("no address associated with hostname")) return "Internet connection is unavailable. Please connect to the internet and try again.";
            if(m.contains("too many requests")) return "Too many attempts. Please wait a little while and try again.";
            if(m.contains("user not found")) return "No Money Flow account was found for this email address.";
            if(m.contains("expired action code")) return "This password reset link has expired. Please request a new reset email.";
            if(m.contains("invalid action code")) return "This password reset link is invalid. Please request a new reset email.";
            return "Authentication could not be completed. Please try again.";
        }
    }

    public class WidgetBridge {
        private final Context ctx;
        WidgetBridge(Context c){ctx=c;}

        @JavascriptInterface public void updateStatus(String balance, String expense, String credit){
            ctx.getSharedPreferences(PaisaFlowWidgetProvider.PREFS, Context.MODE_PRIVATE)
                .edit().putString(PaisaFlowWidgetProvider.BALANCE, balance)
                .putString(PaisaFlowWidgetProvider.EXPENSE, expense)
                .putString(PaisaFlowWidgetProvider.CREDIT, credit).apply();
            webView.post(() -> PaisaFlowWidgetProvider.updateAll(ctx));
        }

        @JavascriptInterface public void requestPinWidget(){
            if(android.os.Build.VERSION.SDK_INT < 26){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            AppWidgetManager manager=AppWidgetManager.getInstance(ctx);
            ComponentName provider=new ComponentName(ctx, PaisaFlowWidgetProvider.class);
            if(!manager.isRequestPinAppWidgetSupported()){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            PendingIntent callback=PendingIntent.getBroadcast(ctx, 9321,
                new Intent(ctx, PaisaFlowWidgetProvider.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            boolean requested=manager.requestPinAppWidget(provider, null, callback);
            if(!requested){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Open your Home screen's Widgets panel to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
            }
        }
    }

    public class AnalyticsBridge {
        private final Context ctx;
        AnalyticsBridge(Context c){ctx=c;}
        @JavascriptInterface public void logFeature(String feature){
            if(feature==null)return;
            String f=feature.trim().toLowerCase(java.util.Locale.US);
            if(f.length()==0)return;
            if(f.length()>40)f=f.substring(0,40);
            Bundle params=new Bundle();
            params.putString("feature_name", f);
            firebaseAnalytics.logEvent("feature_used", params);
        }
        @JavascriptInterface public void logAction(String action){
            if(action==null)return;
            String a=action.trim().toLowerCase(java.util.Locale.US);
            if(a.length()==0)return;
            if(a.length()>40)a=a.substring(0,40);
            Bundle params=new Bundle();
            params.putString("action_name", a);
            firebaseAnalytics.logEvent("app_action", params);
        }
    }

    public class BioBridge {
        private final Context ctx;
        BioBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean isAvailable(){
            if (android.os.Build.VERSION.SDK_INT < 28) return false;
            BiometricManager bm=(BiometricManager)ctx.getSystemService(Context.BIOMETRIC_SERVICE);
            if(bm==null)return false;
            int r=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return r==BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public void authenticate(final String callback){
            if(android.os.Build.VERSION.SDK_INT<28){logBiometric("biometric_unavailable");send(callback,false);return;}
            if(!isAvailable()){logBiometric("biometric_unavailable");send(callback,false);return;}
            BiometricPrompt prompt=new BiometricPrompt.Builder(MainActivity.this)
                .setTitle("Money Flow")
                .setSubtitle("Verify your identity")
                .setDescription("Use your registered fingerprint or biometric to continue.")
                .setNegativeButton("Use PIN", executor, (d,w)->{logBiometric("biometric_fallback_pin");send(callback,false);})
                .build();
            CancellationSignal cs=new CancellationSignal();
            prompt.authenticate(cs, executor, new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){logBiometric("biometric_success");send(callback,true);}
                @Override public void onAuthenticationFailed(){ /* keep prompt open */ }
                @Override public void onAuthenticationError(int e, CharSequence msg){logBiometric("biometric_error");send(callback,false);}
            });
        }
        private void logBiometric(String event){
            try{Bundle p=new Bundle();p.putString("action_name",event);firebaseAnalytics.logEvent("app_action",p);}catch(Exception ignored){}
        }
        private void send(String cb, boolean ok){
            final String js="window."+cb+"("+(ok?"true":"false")+")";
            handler.post(()->webView.evaluateJavascript(js,null));
        }
    }
}
