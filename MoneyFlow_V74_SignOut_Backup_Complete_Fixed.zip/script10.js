
/* V24 PROFILE/MODE ISOLATION FINAL
   A Profile/Mode is a separate app environment for security.
   Switching profiles NEVER asks for the previous profile PIN.
   Security belongs only to the active profile object.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function ps(){try{const x=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
  function active(){const a=ps(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function ensure(p){
    if(!p)return null;
    if(!p.security || typeof p.security!=="object") p.security={};
    const d={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
    for(const k in d) if(p.security[k]===undefined) p.security[k]=d[k];
    return p;
  }
  // Remove only legacy GLOBAL security storage. Per-profile security is retained.
  try{
    ["money_manager_edit_security_v1","mm_global_pin","globalPin","globalPinHash","pinHash"].forEach(k=>localStorage.removeItem(k));
  }catch(e){}
  let p=ensure(active()); if(p){const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=p.security;save(a)}}

  // Replace the security getter used by the final flows so it can never migrate
  // a PIN from another profile.
  window.mmV24ActiveSecurity=function(){
    const a=ps(),p=ensure(active());
    if(!p)return null;
    const q=a.find(x=>x.id===p.id); if(q){q.security=p.security;save(a)}
    return p.security;
  };

  // Profile switch is deliberately security-free. The destination profile's
  // own security is loaded only after the switch.
  window.v10SwitchProfile=function(id){
    const a=ps(),p=a.find(x=>x.id===id);if(!p)return;
    ensure(p);
    localStorage.setItem(AK,id);
    localStorage.setItem("money_manager_active_profile_v10",id);
    // Clear only transient attempt/lock state; destination profile starts with its own.
    try{sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
    if(typeof txs!=="undefined"){
      txs=Array.isArray(p.transactions)?p.transactions:[];
      try{localStorage.setItem(typeof KEY!=="undefined"?KEY:"transactions",JSON.stringify(txs))}catch(e){}
    }
    if(typeof config!=="undefined" && p.config) config=p.config;
    if(typeof render==="function") render();
    const badge=document.getElementById("profileBadge");if(badge)badge.textContent=p.name;
    const m=document.getElementById("v10ProfileModal");if(m)m.style.display="none";
  };

  // Profile-aware 5-attempt protection. Each profile gets its own counter.
  window.mmV19CheckPin=function(pin, expectedHash, hashFn){
    const p=active(); if(!p)return false; ensure(p);
    const s=p.security;
    const now=Date.now();
    const until=Number(s.pinLockUntil||0);
    if(until>now){alert("Too many incorrect PIN attempts. Please wait "+Math.ceil((until-now)/1000)+" seconds.");return false;}
    if(until && until<=now){s.pinLockUntil=0;s.pinFailedAttempts=0;}
    if(hashFn(pin)!==expectedHash){
      s.pinFailedAttempts=Number(s.pinFailedAttempts||0)+1;
      if(s.pinFailedAttempts>=5){s.pinFailedAttempts=0;s.pinLockUntil=Date.now()+30000;}
      const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=s;save(a)}
      if(s.pinLockUntil){alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");}
      else alert("Incorrect PIN. Attempts remaining: "+(5-s.pinFailedAttempts)+".");
      return false;
    }
    s.pinFailedAttempts=0;s.pinLockUntil=0;
    const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=s;save(a)}
    return true;
  };

  // Prevent the older v10ActiveSecurity/mmSec implementations from importing
  // the legacy global PIN into the current profile.
  const cleanSecurity=function(){return window.mmV24ActiveSecurity()};
  window.mmV24CleanSecurity=cleanSecurity;

  // Add/edit gate wrappers use the active profile's security only.
  const oldAsk=window.mmAskPin;
  window.mmV24AskPin=function(onSuccess,onCancel){
    const s=cleanSecurity();
    if(!s){alert("Profile is not ready.");return;}
    if(!s.pinHash){
      // Delegate to existing custom gate, but its PIN creation is stored on active profile.
      if(typeof oldAsk==="function") return oldAsk(onSuccess,onCancel);
      return;
    }
    if(typeof oldAsk==="function") return oldAsk(onSuccess,onCancel);
  };
})();
