
(function(){
  const originalAdd=window.v109RequestAddTransaction;
  window.pfOpenAddTransaction=function(){
    closeMenu();
    const m=document.getElementById("addTransactionModal"); if(!m)return;
    const d=document.getElementById("date"); if(d)d.value=localToday();
    m.style.display="block"; document.body.style.overflow="hidden";
  };
  window.pfCloseAddTransaction=function(){const m=document.getElementById("addTransactionModal");if(m)m.style.display="none";document.body.style.overflow="";};
  window.v109RequestAddTransaction=function(){
    const result=originalAdd?originalAdd():false;
    if(result)window.pfCloseAddTransaction();
    return result;
  };
  window.pfNav=function(name,btn){
    if(name==="home"){window.scrollTo({top:0,behavior:"smooth"});pfSetNav(btn);}
    if(name==="transactions"){document.querySelector(".pf-recent")?.scrollIntoView({behavior:"smooth",block:"start"});pfSetNav(btn);}
  };
  window.pfSetNav=function(btn){document.querySelectorAll(".pf-bottom-nav button").forEach(b=>b.classList.remove("active"));if(btn)btn.classList.add("active");};
  function boot(){
    const el=document.getElementById("pfTodayLabel"); if(el){const d=new Date();el.textContent=d.toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"});}
    render();
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,500);
  document.addEventListener("click",function(e){const m=document.getElementById("addTransactionModal");if(e.target===m)pfCloseAddTransaction();});
})();
