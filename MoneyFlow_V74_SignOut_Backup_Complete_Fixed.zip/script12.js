
/* V27 — EXPORT/PRINT ALWAYS READS THE ACTIVE PROFILE'S TRANSACTIONS */
(function(){
  function activeProfileTransactions(){
    try{
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x.id===id);
      if(p && Array.isArray(p.transactions)) return p.transactions.slice();
    }catch(e){}
    return (typeof txs!=="undefined" && Array.isArray(txs)) ? txs.slice() : [];
  }

  // Make date-range filtering use the active profile, not a stale global txs array.
  window.v27FilteredTransactions=function(){
    const r=typeof getDateRange==="function"?getDateRange():{from:"",to:""};
    if(!r)return null;
    return activeProfileTransactions()
      .filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to))
      .sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  };

  // Replace the function used by Excel/PDF export.
  window.filteredTransactions=function(){
    return window.v27FilteredTransactions();
  };

  // Keep global txs synchronized whenever export is opened/used.
  window.v27SyncTransactions=function(){
    const data=activeProfileTransactions();
    try{
      if(typeof txs!=="undefined"){
        txs.length=0;
        data.forEach(t=>txs.push(t));
      }
    }catch(e){}
    return data;
  };

  // Ensure profile data is persisted immediately before export.
  window.v27PersistCurrentTransactions=function(){
    try{
      if(typeof txs==="undefined"||!Array.isArray(txs))return;
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x.id===id);
      if(p){
        p.transactions=txs.slice();
        localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      }
    }catch(e){}
  };

  // Patch the existing export functions without changing their UI.
  const oldCSV=window.exportCSV;
  if(typeof oldCSV==="function"){
    window.exportCSV=function(){
      v27SyncTransactions();
      v27PersistCurrentTransactions();
      return oldCSV.apply(this,arguments);
    };
  }
  const oldExcel=window.exportExcel;
  if(typeof oldExcel==="function"){
    window.exportExcel=function(){
      v27SyncTransactions();
      return oldExcel.apply(this,arguments);
    };
  }
  const oldPDF=window.exportPDF;
  if(typeof oldPDF==="function"){
    function makeTransactionTablePDF(data, from, to, income, expense, finalBalance){
    // Spreadsheet-style PDF: same 9-column order as Excel.
    const width=842, height=595, margin=28, top=38, bottom=30;
    const colW=[60,58,70,70,80,125,100,100,90];
    const headers=["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"];
    const fontSize=7.2, lineH=10, headerH=18, pad=3;
    const usableW=colW.reduce((a,b)=>a+b,0);
    const maxY=height-bottom;
    const rows=[];
    let bal=0;
    data.forEach(t=>{
      const amount=Number(t.amount)||0;
      bal += t.type==="CREDIT" ? amount : -amount;
      rows.push([
        t.date||"", t.type||"", amount.toFixed(2), bal.toFixed(2), t.category||"",
        t.description||"", t.remark||"", t.mode||"", t.other||""
      ]);
    });

    // Conservative wrapping for Helvetica so long values never overlap adjacent columns.
    function safeText(v){
      return String(v??"").replace(/[^\x20-\x7E]/g,"?");
    }
    function wrap(text, w){
      text=safeText(text);
      const approx=Math.max(5,Math.floor((w-pad*2)/(fontSize*0.52)));
      if(!text)return [""];
      const out=[];
      let cur="";
      text.split(/\s+/).forEach(word=>{
        if(!word)return;
        if(word.length>approx){
          if(cur){out.push(cur);cur="";}
          for(let i=0;i<word.length;i+=approx) out.push(word.slice(i,i+approx));
        }else if(!cur) cur=word;
        else if((cur+" "+word).length<=approx) cur+=" "+word;
        else {out.push(cur);cur=word;}
      });
      if(cur)out.push(cur);
      return out.length?out:[""];
    }

    function rowLines(row){
      const cells=row.map((v,i)=>wrap(v,colW[i]));
      return {cells,n:Math.max(...cells.map(c=>c.length)),h:Math.max(18,Math.max(...cells.map(c=>c.length))*lineH+4)};
    }
    const prepared=rows.map(rowLines);
    const pages=[]; let page=[]; let y=top+28;
    for(const r of prepared){
      if(y+r.h>maxY && page.length){pages.push(page);page=[];y=top+28;}
      page.push(r); y+=r.h;
    }
    if(page.length||!pages.length)pages.push(page);

    let objs=[]; const add=o=>{objs.push(o);return objs.length;};
    const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    const pageIds=[], contentIds=[];

    function esc(s){return pdfEscape(safeText(s));}
    pages.forEach((pg,pi)=>{
      let stream="q\n";
      // Title / period
      stream+=`BT\n/F1 10 Tf\n1 0 0 1 ${margin} ${height-28} Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n`;
      stream+=`/F1 8 Tf\n1 0 0 1 ${margin} ${height-40} Tm (${esc(`Period: ${from} to ${to}`)}) Tj\nET\n`;

      const tableTop=height-55;
      let yy=tableTop;
      function drawCell(x,y,w,h,texts,bold){
        stream+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\n`;
        stream+=`BT\n/F1 ${bold?7.5:fontSize} Tf\n`;
        texts.forEach((tx,i)=>{
          const ty=y-pad-7-i*lineH;
          stream+=`1 0 0 1 ${x+pad} ${ty} Tm (${esc(tx)}) Tj\n`;
        });
        stream+="ET\n";
      }
      // Header row
      let x=margin;
      headers.forEach((h,i)=>{drawCell(x,yy,colW[i],headerH,[h],true);x+=colW[i];});
      yy-=headerH;

      pg.forEach(r=>{
        x=margin;
        r.cells.forEach((cell,i)=>{drawCell(x,yy,colW[i],r.h,cell,false);x+=colW[i];});
        yy-=r.h;
      });

      if(pi===pages.length-1){
        yy-=12;
        stream+=`BT\n/F1 8.5 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("SUMMARY")}) Tj\n`;
        yy-=12; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Total Credit: Rs.${income.toFixed(2)}`)}) Tj\n`;
        yy-=11; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Total Expense: Rs.${expense.toFixed(2)}`)}) Tj\n`;
        yy-=11; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Net Balance: Rs.${finalBalance.toFixed(2)}`)}) Tj\nET\n`;
      }
      stream+="Q";
      const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
      contentIds.push(cid); pageIds.push(null);
    });
    const pagesId=add("PAGES_PLACEHOLDER");
    pages.forEach((_,i)=>{
      pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`);
    });
    objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;
    const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let pdf="%PDF-1.4\n", offsets=[0];
    objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});
    const xref=pdf.length;
    pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
    for(let i=1;i<=objs.length;i++)pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
    pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return new Blob([pdf],{type:"application/pdf"});
  }
  window.mm31MakeTransactionTablePDF=makeTransactionTablePDF;

  window.exportPDF=function(){
    const data=mm31Filtered();
    if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const r=mm31Range();
    const from=r.from||data[0].date;
    const to=r.to||data[data.length-1].date;
    let income=0,expense=0,balance=0;
    data.forEach(t=>{
      const amount=Number(t.amount)||0;
      if(t.type==="CREDIT") income+=amount; else expense+=amount;
      balance+=t.type==="CREDIT"?amount:-amount;
    });
    downloadBlob(
      makeTransactionTablePDF(data,from,to,income,expense,balance),
      `money_transactions_${from}_to_${to}.pdf`
    );
  };
}
})();
