
/* V30.1 FINAL PATCH
   - Excel: header cells remain text; only data Amount/Balance cells are numeric.
   - PDF: use ASCII-safe "Rs." so Android PDF viewers never show â‚¹/garbled ₹.
   - Biometric/Fingerprint: optional WebAuthn platform authenticator. When ON,
     security gates attempt biometric first; if unavailable/cancelled, PIN is shown.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  const b64u = bytes => {
    let s=""; for(const b of bytes)s+=String.fromCharCode(b);
    return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
  };
  const fromB64u = s => {
    s=String(s||"").replace(/-/g,"+").replace(/_/g,"/");
    while(s.length%4)s+="=";
    const raw=atob(s), a=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i);
    return a;
  };
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function active(){const a=profiles(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function sec(){const p=active(); if(!p)return null; p.security=p.security||{}; if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false; return p.security}
  function persist(){const a=profiles(),p=active();if(!p)return;const i=a.findIndex(x=>x.id===p.id);if(i>=0){a[i]=p;save(a)}}
  function randomBytes(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a}
  function canBio(){return !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create && navigator.credentials.get && window.isSecureContext)}
  async function registerBio(){
    if(!canBio()) throw new Error("Biometric is not available in this local/browser environment.");
    const p=active(); if(!p) throw new Error("Profile is not ready.");
    const challenge=randomBytes(32), userId=randomBytes(16);
    const cred=await navigator.credentials.create({publicKey:{
      challenge,
      rp:{name:"Money Manager"},
      user:{id:userId,name:p.id,displayName:p.name||"My Money"},
      pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],
      authenticatorSelection:{authenticatorAttachment:"platform",userVerification:"required",residentKey:"preferred"},
      timeout:60000,
      attestation:"none"
    }});
    if(!cred) throw new Error("Biometric setup was cancelled.");
    p.security=p.security||{};
    p.security.bioEnabled=true;
    p.security.bioCredentialId=b64u(new Uint8Array(cred.rawId));
    persist();
    return true;
  }
  async function verifyBio(){
    const s=sec();
    if(!s||!s.bioEnabled||!s.bioCredentialId) return false;
    if(!canBio()) return false;
    const challenge=randomBytes(32);
    try{
      const cred=await navigator.credentials.get({publicKey:{
        challenge,
        allowCredentials:[{type:"public-key",id:fromB64u(s.bioCredentialId)}],
        userVerification:"required",timeout:60000
      }});
      return !!cred;
    }catch(e){return false}
  }
  function addBioMenu(){
    const panel=document.getElementById("menuPanel"); if(!panel||document.getElementById("v30BioMenuItem"))return;
    const b=document.createElement("button"); b.id="v30BioMenuItem"; b.className="menuItem"; b.type="button";
    b.textContent="🔐 Fingerprint / Biometric"; b.onclick=window.v30OpenBiometricSettings;
    const close=[...panel.querySelectorAll("button")].find(x=>x.textContent.includes("Close"));
    if(close)panel.insertBefore(b,close); else panel.appendChild(b);
  }
  function refreshBioText(){
    const s=sec(), item=document.getElementById("v30BioMenuItem");
    if(item)item.textContent=(s&&s.bioEnabled)?"🔐 Fingerprint / Biometric: ON":"🔐 Fingerprint / Biometric: OFF";
  }
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();
    let m=document.getElementById("v30BioModal");
    if(!m){
      m=document.createElement("div");m.id="v30BioModal";m.className="v10modal";
      m.innerHTML='<div class="v10box"><h2>🔐 Fingerprint / Biometric</h2><p id="v30BioStatus" class="v10small"></p><button type="button" id="v30BioEnable">Turn ON / Register Fingerprint</button><button type="button" class="danger" id="v30BioDisable">Turn OFF</button><button type="button" class="secondary" id="v30BioClose">Close</button></div>';
      document.body.appendChild(m);
      document.getElementById("v30BioEnable").onclick=async function(){
        try{await registerBio();refreshBioText();updateBioStatus();alert("Fingerprint / biometric is ON. The biometric prompt will appear directly when security is required.");}
        catch(e){alert(e&&e.message?e.message:"Fingerprint setup failed. PIN security remains available.");}
      };
      document.getElementById("v30BioDisable").onclick=function(){const s=sec();if(s){s.bioEnabled=false;s.bioCredentialId="";persist();refreshBioText();updateBioStatus();}};
      document.getElementById("v30BioClose").onclick=function(){m.style.display="none"};
    }
    function updateBioStatus(){const s=sec();const e=document.getElementById("v30BioStatus");if(e)e.textContent=(s&&s.bioEnabled)?"ON — biometric will be requested first; if unavailable/cancelled, PIN is shown.":"OFF — PIN is used normally."}
    updateBioStatus();m.style.display="block";
  };
  // Preserve the existing unified PIN gate and put biometric first when enabled.
  const originalAsk=window.v26AskPin;
  if(typeof originalAsk==="function"){
    window.v26AskPin=async function(ok,cancel){
      const s=sec();
      if(s&&s.bioEnabled&&s.bioCredentialId){
        const success=await verifyBio();
        if(success){if(typeof ok==="function")ok();return false;}
        // biometric unavailable/cancelled -> continue to the normal PIN UI.
      }
      return originalAsk(ok,cancel);
    };
  }
  // Install menu item after the page has loaded; repeat once after current UI setup.
  function boot(){addBioMenu();refreshBioText()}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,300);
})();
