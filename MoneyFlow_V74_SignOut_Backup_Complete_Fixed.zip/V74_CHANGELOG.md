# Money Flow V74 — Sign-Out Backup Completion Fix

- V73 remains the baseline; only the Sign-Out/backup completion path was changed.
- Sign Out now requests a dedicated native `upload_signout` Drive operation.
- Firebase/Google sign-out is performed natively only after the Google Drive PATCH returns success.
- This avoids the WebView callback race that could leave the Sign-Out modal stuck on “Backing Up…” even when the Drive backup was already updated.
- Manual Backup & Restore → Backup remains unchanged.
- No transaction/profile/security/restore logic was changed.
