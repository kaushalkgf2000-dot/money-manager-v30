
/* V24 — FINAL COMMON PIN / PROFILE SECURITY
   One canonical PIN per active Profile/Mode.
   - First security action with no PIN => Create PIN.
   - After creation, that exact PIN is used everywhere in the active profile.
   - Switching Profile/Mode never carries PIN or recovery state across profiles.
   - Biometric is an authentication method only; it never owns a second PIN.
   - Backup & Restore is protected by the same profile PIN.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){
    const ps=profiles(), id=localStorage.getItem(AK);
    const p=ps.find(x=>x&&x.id===id)||ps[0]||null;
    if(p){
      p.security=p.security||{};
      if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
      if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false;
    }
    return p;
  }
  function save(ps){localStorage.setItem(PK,JSON.stringify(ps))}
  function hash(v){
    v=String(v||"");let h=2166136261;
    for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function persistSecurity(s){
    const ps=profiles(),p=active();if(!p)return false;
    p.security=s||{};
    const q=ps.find(x=>x.id===p.id);if(q)q.security=p.security;
    save(ps);
    try{localStorage.removeItem("money_manager_edit_security_v1")}catch(e){}
    return true;
  }
  function gate(){return document.getElementById("editPinGate")}
  function body(){return document.getElementById("editPinGateBody")}
  function closeGate(){const e=gate();if(e)e.style.display="none"}
  function show(title,markup){
    const e=gate(),b=body();if(!e||!b){alert("Security screen is unavailable.");return false}
    const h=e.querySelector("h2");if(h)h.textContent=title;
    b.innerHTML=markup;e.style.display="block";return true;
  }
  function ask(onSuccess,onCancel,context){
    const p=active();if(!p){alert("Active profile is unavailable.");return}
    const s=p.security||{};
    if(!s.pinHash){
      show("🔐 Create Security PIN",`
        <h3>🔐 Create PIN</h3>
        <p>Create one 4–6 digit PIN for this Profile / Mode. This same PIN will protect all Money Flow security actions in this profile.</p>
        <input id="mfCommonNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="mfCommonConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="mfCommonCreatePin">Create PIN</button>
        <button type="button" class="secondary" id="mfCommonCancelPin">Cancel</button>`);
      document.getElementById("mfCommonCreatePin").onclick=function(){
        const a=document.getElementById("mfCommonNewPin")?.value||"",b=document.getElementById("mfCommonConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return}
        p.security=p.security||{};
        p.security.pinHash=hash(a);
        p.security.recoveryCode=p.security.recoveryCode||recovery();
        p.security.editPinLost=false;
        if(!persistSecurity(p.security))return;
        body().innerHTML=`<h3>✅ PIN Created</h3><p>Your security PIN is now active for this Profile / Mode.</p><p><b>Recovery Code:</b></p><div class="v10code">${p.security.recoveryCode}</div><p class="v10small">The same PIN will be used for Edit, Add Transaction security, security settings, biometric setup and Backup & Restore in this profile.</p><button type="button" id="mfCommonContinue">Continue</button>`;
        document.getElementById("mfCommonContinue").onclick=function(){closeGate();if(typeof onSuccess==="function")onSuccess()};
      };
      document.getElementById("mfCommonCancelPin").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
      setTimeout(()=>document.getElementById("mfCommonNewPin")?.focus(),0);
      return;
    }
    show("🔐 Security Verification",`
      <h3>🔐 Enter PIN</h3>
      <p>Enter the PIN for <b>${String(p.name||"this Profile / Mode").replace(/[<>&"]/g,"")}</b>.</p>
      <input id="mfCommonPin" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">
      <button type="button" id="mfCommonVerify">Continue</button>
      <button type="button" class="secondary" id="mfCommonForgot">Forgot PIN?</button>
      <button type="button" class="secondary" id="mfCommonCancel">Cancel</button>`);
    document.getElementById("mfCommonVerify").onclick=function(){
      const v=document.getElementById("mfCommonPin")?.value||"";
      if(typeof mmV19CheckPin==="function"){
        if(!mmV19CheckPin(v,s.pinHash,hash))return;
      }else if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return}
      closeGate();if(typeof onSuccess==="function")onSuccess();
    };
    document.getElementById("mfCommonForgot").onclick=function(){
      if(!s.recoveryCode){alert("No Recovery Code is available for this Profile / Mode.");return}
      const code=prompt("Enter your Recovery Code:");
      if(code===null)return;
      if(code.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
      body().innerHTML=`<h3>🔐 Create New PIN</h3><p>Create a new 4–6 digit PIN for this Profile / Mode.</p><input id="mfRecoveryNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="mfRecoveryConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" id="mfRecoverySave">Save New PIN</button><button type="button" class="secondary" id="mfRecoveryCancel">Cancel</button>`;
      document.getElementById("mfRecoverySave").onclick=function(){
        const a=document.getElementById("mfRecoveryNewPin")?.value||"",b=document.getElementById("mfRecoveryConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return}
        s.pinHash=hash(a);s.editPinLost=false;persistSecurity(s);closeGate();if(typeof onSuccess==="function")onSuccess();
      };
      document.getElementById("mfRecoveryCancel").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
    };
    document.getElementById("mfCommonCancel").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
    setTimeout(()=>document.getElementById("mfCommonPin")?.focus(),0);
  }

  window.mfRequestCommonSecurity=function(onSuccess,onCancel,context){ask(onSuccess,onCancel,context||"security")};

  /* PIN Setup / Change — single canonical profile PIN.
     Important UI rule: PIN Security modal is closed before the verification gate opens.
     Change PIN verifies current PIN first; Verify/Recovery verifies Recovery Code first.
     Both paths then create one new PIN for the active Profile / Mode. */
  function pinSecurityModalClose(){
    const m=document.getElementById("v10PinModal"); if(m)m.style.display="none";
  }
  function showNewPinAfterVerification(successTitle, successText){
    show("🔐 Create New PIN",`
      <h3>🔐 Create New PIN</h3>
      <p>Create a new 4–6 digit PIN for this Profile / Mode.</p>
      <input id="mfChangeNewPin2" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
      <input id="mfChangeConfirmPin2" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
      <button type="button" id="mfSaveNewPin2">Save New PIN</button>
      <button type="button" class="secondary" id="mfCancelNewPin2">Cancel</button>`);
    document.getElementById("mfSaveNewPin2").onclick=function(){
      const a=document.getElementById("mfChangeNewPin2")?.value||"",b=document.getElementById("mfChangeConfirmPin2")?.value||"";
      if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
      if(a!==b){alert("PIN and Confirm PIN do not match.");return}
      const q=active();if(!q)return;
      q.security=q.security||{};
      q.security.pinHash=hash(a);
      q.security.recoveryCode=q.security.recoveryCode||recovery();
      q.security.editPinLost=false;
      persistSecurity(q.security);
      closeGate();
      alert(successTitle||"PIN changed successfully.");
      if(typeof v10OpenPin==="function")v10OpenPin();
    };
    document.getElementById("mfCancelNewPin2").onclick=function(){closeGate();if(typeof v10OpenPin==="function")v10OpenPin()};
    setTimeout(()=>document.getElementById("mfChangeNewPin2")?.focus(),0);
  }
  window.v10OpenPin=function(){
    if(typeof closeMenu==="function")closeMenu();
    const p=active();if(!p)return;
    const s=p.security||{},actions=document.getElementById("v10PinActions"),status=document.getElementById("v10PinStatusText");
    if(s.pinHash){
      status.textContent="One PIN protects all security actions in this Profile / Mode.";
      actions.innerHTML='<button type="button" id="mfPinChangeBtn">🔄 Change PIN</button><button type="button" id="mfPinRecoveryBtn">🔑 Verify / Recovery</button>';
      document.getElementById("mfPinChangeBtn").onclick=function(){
        pinSecurityModalClose();
        mfRequestCommonSecurity(function(){showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.")},function(){if(typeof v10OpenPin==="function")v10OpenPin()},"change");
      };
      document.getElementById("mfPinRecoveryBtn").onclick=function(){
        pinSecurityModalClose();
        const q=active();
        if(!q || !q.security || !q.security.recoveryCode){alert("No Recovery Code is available for this Profile / Mode.");v10OpenPin();return;}
        show("🔑 Recovery Verification",`
          <h3>🔑 Verify Recovery Code</h3>
          <p>Enter the Recovery Code for <b>${String(q.name||"this Profile / Mode").replace(/[<>&"]/g,"")}</b>.</p>
          <input id="mfRecoveryCode2" type="text" autocomplete="off" placeholder="Enter Recovery Code">
          <button type="button" id="mfVerifyRecovery2">Verify & Continue</button>
          <button type="button" class="secondary" id="mfCancelRecovery2">Cancel</button>`);
        document.getElementById("mfVerifyRecovery2").onclick=function(){
          const code=document.getElementById("mfRecoveryCode2")?.value.trim().toUpperCase()||"";
          if(code!==String(q.security.recoveryCode||"").toUpperCase()){alert("Incorrect Recovery Code.");return}
          showNewPinAfterVerification("PIN recovered and changed successfully. The new PIN now works everywhere in this Profile / Mode.");
        };
        document.getElementById("mfCancelRecovery2").onclick=function(){closeGate();v10OpenPin()};
        setTimeout(()=>document.getElementById("mfRecoveryCode2")?.focus(),0);
      };
    }else{
      status.textContent="No PIN created for this Profile / Mode. Create it now.";
      actions.innerHTML='<button type="button" id="mfPinCreateBtn">🔐 Create PIN</button>';
      document.getElementById("mfPinCreateBtn").onclick=function(){
        pinSecurityModalClose();
        mfRequestCommonSecurity(function(){if(typeof v10OpenPin==="function")v10OpenPin()},function(){if(typeof v10OpenPin==="function")v10OpenPin()},"create");
      };
    }
    document.getElementById("v10PinModal").style.display="block";
  };
  /* Keep the old public function name for compatibility, but route it through the real change flow. */
  window.v10ShowChangePin=function(){
    pinSecurityModalClose();
    mfRequestCommonSecurity(function(){showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.")},function(){v10OpenPin()},"change");
  };
  window.mfSaveChangedPin=function(){
    /* Compatibility fallback: the canonical flow above owns PIN changes. */
    showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.");
  };

  /* Edit always uses the common profile PIN. */
  window.v10RequestEdit=function(id){
    const t=Array.isArray(window.txs)?window.txs.find(x=>x.id===id):null;if(!t)return;
    if(typeof canEditTransaction==="function"&&!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return}
    ask(function(){
      document.getElementById("editId").value=id;
      const d=document.getElementById("editDate");if(d)d.max=typeof localToday==="function"?localToday():"";
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },null,"edit");
  };

  /* Add Transaction: only requires PIN when its protection setting is ON.
     If ON and no PIN exists, the same first-time Create PIN flow is used. */
  window.v109RequestAddTransaction=function(){
    const p=active();if(!p)return false;
    if(!p.security.addProtection){
      if(typeof addTx==="function")return addTx()!==false;
      return false;
    }
    ask(function(){
      if(typeof addTx==="function")return addTx()!==false;
      return false;
    },null,"add");
    return false;
  };

  /* Add Transaction security ON/OFF uses the same common PIN. */
  window.v10ChooseAddTxSecurity=function(desired){
    const wanted=!!desired,p=active();if(!p)return;
    const current=!!p.security.addProtection;
    if(current===wanted){try{v10RefreshAddTxSecurityUI()}catch(e){};return}
    ask(function(){
      const q=active();if(!q)return;
      q.security.addProtection=wanted;persistSecurity(q.security);
      try{v10RefreshAddTxSecurityUI()}catch(e){}
      alert(wanted?"Add Transaction PIN is now ON.":"Add Transaction PIN is now OFF.");
    },function(){try{v10RefreshAddTxSecurityUI()}catch(e){}}, "settings");
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};

  /* Biometric: no separate PIN. Register/disable it only after common profile PIN verification.
     If there is no PIN yet, the common Create PIN flow runs first. */
  const oldBio=window.v30OpenBiometricSettings;
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();
    mfRequestCommonSecurity(function(){
      if(typeof oldBio==="function"){try{oldBio()}catch(e){alert(e&&e.message?e.message:"Biometric settings unavailable.")}}
    },null,"biometric");
  };

  /* Backup & Restore: opening the backup area is a protected security action. */
  const oldBackup=window.mfOpenBackup;
  window.mfOpenBackup=function(){
    if(typeof closeMenu==="function")closeMenu();
    mfRequestCommonSecurity(function(){
      if(typeof oldBackup==="function")oldBackup();
      else {const m=document.getElementById("mfBackupModal");if(m)m.style.display="block";}
    },null,"backup");
  };

  /* Profile switch: canonical security always comes from the selected profile only.
     Clear legacy/global PIN artifacts so another Mode can never inherit them. */
  const oldSwitch=window.v10SwitchProfile;
  if(typeof oldSwitch==="function"){
    window.v10SwitchProfile=function(id){
      oldSwitch(id);
      try{localStorage.removeItem("money_manager_edit_security_v1");sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
      const p=active();
      if(p&&p.security){p.security.pinHash=p.security.pinHash||"";p.security.recoveryCode=p.security.recoveryCode||"";persistSecurity(p.security)}
    };
  }

  /* New profile: force a completely independent security object. */
  const oldCreate=window.v10CreateProfile;
  if(typeof oldCreate==="function"){
    window.v10CreateProfile=function(){
      oldCreate();
      const p=active();
      if(p){
        p.security={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true};
        persistSecurity(p);
      }
    };
  }
})();
