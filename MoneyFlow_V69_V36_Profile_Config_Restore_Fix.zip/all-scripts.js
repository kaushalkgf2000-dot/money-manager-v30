
const KEY="money_manager_v1";

// Keep the app from behaving like a browser on long-press. Text selection/copy
// remains available only inside actual editable controls.
document.addEventListener('contextmenu', function(e){
  const t=e.target;
  if(t && (t.matches('input, textarea, select, [contenteditable="true"], [contenteditable=""]') || t.closest('input, textarea, select, [contenteditable="true"], [contenteditable=""]'))) return;
  e.preventDefault();
}, {capture:true});
document.addEventListener('selectstart', function(e){
  const t=e.target;
  if(t && (t.matches('input, textarea, select, [contenteditable="true"], [contenteditable=""]') || t.closest('input, textarea, select, [contenteditable="true"], [contenteditable=""]'))) return;
  e.preventDefault();
}, {capture:true});
function mfNewTransactionUid(){
  try{if(window.crypto&&typeof crypto.randomUUID==='function')return crypto.randomUUID()}catch(e){}
  return 'tx_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2)+'_'+Math.random().toString(36).slice(2);
}
function mfEnsureTransactionUid(t){
  if(!t||typeof t!=='object')return t;
  if(t.uid!==undefined&&t.uid!==null&&String(t.uid).trim()!=='')return t;
  /* Existing transactions are upgraded once. The legacy id is retained for
     compatibility, while uid becomes the stable merge identity. */
  return {...t,uid:'legacy-'+String(t.id!==undefined?t.id:mfNewTransactionUid())};
}
let txs=JSON.parse(localStorage.getItem(KEY)||"[]");
txs=Array.isArray(txs)?txs.map(mfEnsureTransactionUid):[];

// Each new transaction gets an exact creation timestamp. Existing V8 transactions
// without one use their stored transaction date as the safe fallback.
txs=txs.map(t=>t.createdAt? t : {...t, createdAt: new Date((t.date||"1970-01-01")+"T23:59:59").toISOString()});
localStorage.setItem(KEY,JSON.stringify(txs));

function transactionCreatedAt(t){
  const d=new Date(t.createdAt || ((t.date||"1970-01-01")+"T23:59:59"));
  return Number.isNaN(d.getTime()) ? new Date(0) : d;
}
// Single source of truth for transaction ordering:
// latest transaction date first; same-date transactions use creation time.
function compareTransactionsLatestFirst(a,b){
  const byDate=String(b.date||"").localeCompare(String(a.date||""));
  if(byDate!==0) return byDate;
  return transactionCreatedAt(b).getTime()-transactionCreatedAt(a).getTime() || Number(b.id||0)-Number(a.id||0);
}
function sortTransactionsLatestFirst(){
  txs.sort(compareTransactionsLatestFirst);
}
function canEditTransaction(t){
  const age=Date.now()-transactionCreatedAt(t).getTime();
  return age>=0 && age < 5*24*60*60*1000;
}
function editTimeLeft(t){
  const left=5*24*60*60*1000-(Date.now()-transactionCreatedAt(t).getTime());
  if(left<=0) return "Edit locked after 5 days";
  const days=Math.floor(left/86400000);
  const hours=Math.floor((left%86400000)/3600000);
  return days>0 ? `Edit available • ${days}d ${hours}h left` : `Edit available • ${hours}h left`;
}

function money(n){return "₹"+Number(n).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}

const DEFAULT_CONFIG={
  creditAmounts:[500,1000,1500,3000,4000,5000],
  expenseAmounts:[50,100,1000,3000],
  creditCategories:["Home Money","Our Income","Friend Gift"],
  expenseCategories:["Food","Travel","Grocery","Other"]
};
let config=JSON.parse(localStorage.getItem("money_manager_config")||"null")||JSON.parse(JSON.stringify(DEFAULT_CONFIG));
function localToday(){
 const d=new Date();
 return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
const addDateEl=document.getElementById("date");
addDateEl.max=localToday();
const editDateEl=document.getElementById("editDate");
if(editDateEl) editDateEl.max=localToday();
addDateEl.value=localToday();
addDateEl.addEventListener("change",()=>{
 const today=localToday();
 if(addDateEl.value>today) addDateEl.value=today;
});
setThisMonth();
updateCategories();

function toggleMenu(){
 const p=document.getElementById("menuPanel");
 p.style.display=p.style.display==="block"?"none":"block";
}
function closeMenu(){document.getElementById("menuPanel").style.display="none"}
function pfOpenWidgets(){
 closeMenu();
 if(window.AndroidWidget && AndroidWidget.requestPinWidget){
   try{ AndroidWidget.requestPinWidget(); return; }catch(e){}
 }
 alert("To add the Money Flow widget, long-press an empty area on your Home screen, choose Widgets, then select Money Flow.");
}
function openCustomization(){
 closeMenu();
 document.getElementById("creditAmounts").value=config.creditAmounts.join(", ");
 document.getElementById("expenseAmounts").value=config.expenseAmounts.join(", ");
 document.getElementById("creditCategories").value=config.creditCategories.join(", ");
 document.getElementById("expenseCategories").value=config.expenseCategories.join(", ");
 document.getElementById("customModal").style.display="block";
}
function closeCustomization(){document.getElementById("customModal").style.display="none"}
function parseAmounts(id){
 return document.getElementById(id).value.split(",").map(x=>Number(x.trim())).filter(x=>Number.isFinite(x)&&x>0);
}
function parseTextList(id){
 return document.getElementById(id).value.split(",").map(x=>x.trim()).filter(Boolean);
}
function saveCustomization(){
 const c=parseAmounts("creditAmounts"), e=parseAmounts("expenseAmounts");
 const cc=parseTextList("creditCategories"), ec=parseTextList("expenseCategories");
 if(!c.length||!e.length||!cc.length||!ec.length){alert("Please keep at least one option in every list.");return}
 config={creditAmounts:c,expenseAmounts:e,creditCategories:cc,expenseCategories:ec};
 localStorage.setItem("money_manager_config",JSON.stringify(config));
 updateCategories();
 updateAmountOptions();
 closeCustomization();
 alert("Customisation saved.");
}
function resetCustomization(){
 config=JSON.parse(JSON.stringify(DEFAULT_CONFIG));
 localStorage.setItem("money_manager_config",JSON.stringify(config));
 updateCategories(); updateAmountOptions(); openCustomization();
}
function updateAmountOptions(){
 const type=document.getElementById("type").value;
 const select=document.getElementById("amountPreset");
 if(!select)return;
 if(!type){
   select.innerHTML='<option value="" selected>Select amount</option>';
   select.value="";
   toggleCustomAmount();
   return;
 }
 const amounts=type==="CREDIT"?config.creditAmounts:config.expenseAmounts;
 select.innerHTML='<option value="" selected>Select amount</option>'+amounts.map(n=>`<option value="${n}">₹${Number(n).toLocaleString("en-IN")}</option>`).join("")
   + '<option value="CUSTOM">Custom</option>';
 // Type selection unlocks the type-specific amount list, but does not carry
 // the previous transaction's amount into the new transaction.
 select.value="";
 toggleCustomAmount();
}
function toggleCustomAmount(){
 const custom=document.getElementById("customAmount");
 const isCustom=document.getElementById("amountPreset").value==="CUSTOM";
 custom.style.display=isCustom?"block":"none";
 if(isCustom) custom.focus();
}

function save(){sortTransactionsLatestFirst();txs=txs.map(mfEnsureTransactionUid);localStorage.setItem(KEY,JSON.stringify(txs));render();try{if(window.pfRenderTransactionsPage&&document.getElementById('pfTransactionsPage')?.style.display!=='none')window.pfRenderTransactionsPage()}catch(e){}try{if(window.pfScheduleCloudSync)window.pfScheduleCloudSync()}catch(e){}}
function updateCategories(){
 const type=document.getElementById("type").value;
 const select=document.getElementById("categorySelect");
 if(!select)return;
 if(!type){
   select.innerHTML='<option value="" selected>Select category</option>';
   select.value="";
   toggleCustomCategory();
   updateAmountOptions();
   return;
 }
 const base=type==="CREDIT"?config.creditCategories:config.expenseCategories;
 const categories=[...base.map(x=>[x,x]),["CUSTOM","Custom"]];
 select.innerHTML='<option value="" selected>Select category</option>'+categories.map(([v,t])=>`<option value="${v}">${t}</option>`).join("");
 // Do not inherit the previous transaction's category.
 select.value="";
 toggleCustomCategory();
 updateAmountOptions();
}
function toggleCustomCategory(){
 const custom=document.getElementById("customCategory");
 custom.style.display=document.getElementById("categorySelect").value==="CUSTOM"?"block":"none";
 if(custom.style.display==="block") custom.focus();
}
document.getElementById("type").addEventListener("change", updateCategories);
document.getElementById("amountPreset").addEventListener("change", toggleCustomAmount);
function addTx(){
 const dateEl=document.getElementById("date");
 const typeEl=document.getElementById("type");
 const amountPresetEl=document.getElementById("amountPreset");
 const customAmountEl=document.getElementById("customAmount");
 const categoryEl=document.getElementById("categorySelect");
 const customCategoryEl=document.getElementById("customCategory");
 const descriptionEl=document.getElementById("description");
 const remarkEl=document.getElementById("remark");
 const modeEl=document.getElementById("mode");
 const otherEl=document.getElementById("other");
 const date=dateEl.value;
 const type=typeEl.value;
 const preset=amountPresetEl.value;
 const amount=preset==="CUSTOM"?Number(customAmountEl.value):Number(preset);
 const selectedCategory=categoryEl.value;
 const customCategory=customCategoryEl.value.trim();
 const category=selectedCategory==="CUSTOM"?customCategory:selectedCategory;
 const today=localToday();
 dateEl.max=today;
 if(!date||date>today){dateEl.value=today;return false}
 if(!Number.isFinite(amount)||amount<=0){alert("Please enter a valid amount.");return false}
 if(!category){alert("Please select or enter a category.");return false}
 const tx={id:Date.now(),uid:mfNewTransactionUid(),createdAt:new Date().toISOString(),date,type,amount,category,
   description:descriptionEl.value.trim(),remark:remarkEl.value.trim(),mode:modeEl.value,other:otherEl.value.trim()};
 txs.push(tx);
 sortTransactionsLatestFirst();
 localStorage.setItem(KEY,JSON.stringify(txs));
 // Keep the active profile in sync as the single source of truth.
 try{
   const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
   const aid=localStorage.getItem("money_manager_active_profile_v10");
   const ap=ps.find(x=>x.id===aid)||ps[0];
   if(ap){ap.transactions=txs;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps))}
 }catch(e){}
 if(typeof window.pfResetAddTransactionForm === "function") window.pfResetAddTransactionForm();
 render();
 // Step 2 fix: close the Add Transaction sheet immediately after a successful save.
 if(typeof window.pfCloseAddTransaction==="function") window.pfCloseAddTransaction();
 // Cloud sync is explicitly requested after the transaction is committed.
 try{if(window.pfScheduleCloudSync)window.pfScheduleCloudSync();}catch(e){}
 return true;
}

function render(){
 // Always derive the visible profile identity from the currently active Profile / Mode.
 // After a cloud restore the data can be correct while the static HTML badge would
 // otherwise fall back to the default "My Money" label after location.reload().
 try{
   const _ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
   const _aid=localStorage.getItem("money_manager_active_profile_v10") || localStorage.getItem("activeProfileId") || localStorage.getItem("currentProfileId") || "";
   const _ap=Array.isArray(_ps)?(_ps.find(x=>x&&x.id===_aid)||_ps[0]):null;
   const _badge=document.getElementById("profileBadge");
   if(_badge&&_ap)_badge.textContent=_ap.name||"My Money";
 }catch(_e){}
 sortTransactionsLatestFirst();
 let income=0,expense=0;
 txs.forEach(t=>{if(t.type==="CREDIT")income+=Number(t.amount)||0;else expense+=Number(t.amount)||0});
 const balance=income-expense;
 if(window.AndroidWidget && AndroidWidget.updateStatus){
   try{ AndroidWidget.updateStatus(money(balance), money(expense), money(income)); }catch(e){}
 }
 document.getElementById("income").textContent=money(income);
 document.getElementById("expense").textContent=money(expense);
 document.getElementById("balance").textContent=money(balance);
 const total=income+expense;
 const ip=total?Math.round(income/total*100):0, ep=total?Math.round(expense/total*100):0;
 const ib=document.getElementById("pfIncomeBar"), eb=document.getElementById("pfExpenseBar");
 if(ib)ib.style.width=ip+"%"; if(eb)eb.style.width=ep+"%";
 const iPct=document.getElementById("pfIncomePct"),ePct=document.getElementById("pfExpensePct"),net=document.getElementById("pfNetText");
 if(iPct)iPct.textContent=ip+"%"; if(ePct)ePct.textContent=ep+"%"; if(net)net.textContent="Net position: "+money(balance);
 const list=document.getElementById("list"); if(!list)return; list.innerHTML="";
 const recent=txs.slice(0,5);
 if(!recent.length){list.innerHTML='<div class="pf-empty">No transactions yet. Add your first transaction to see it here.</div>';return}
 recent.forEach(t=>{
  const div=document.createElement("div");div.className="tx";
  div.innerHTML=`<div><div class="tx-title">${escapeHtml(t.category||"Uncategorized")}</div><div class="tx-meta">${t.date} • ${t.type} • ${escapeHtml(t.mode)}${t.description?" • "+escapeHtml(t.description):""}</div>${t.remark?`<div class="tx-meta">Remark: ${escapeHtml(t.remark)}</div>`:""}</div><div class="tx-amt ${t.type==="CREDIT"?"green":"red"}">${t.type==="CREDIT"?"+":"-"}${money(t.amount)}</div>`;
  list.appendChild(div);
 });
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function txMatchesRange(t,from,to){return (!from||t.date>=from)&&(!to||t.date<=to)}
function openHistory(){closeMenu();document.getElementById("historyModal").style.display="block";const d=new Date();document.getElementById("historyMonth").value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;renderHistory()}
function closeHistory(){document.getElementById("historyModal").style.display="none"}
function updateHistoryControls(){const monthly=document.getElementById("historyMode").value==="MONTH";document.getElementById("historyMonthWrap").style.display=monthly?"block":"none";document.getElementById("historyDateWrap").style.display=monthly?"none":"block"}
function renderHistory(){
 const mode=document.getElementById("historyMode").value;let from="",to="";
 if(mode==="MONTH"){
  const m=document.getElementById("historyMonth").value;if(!m)return;from=m+"-01";const [y,mo]=m.split("-").map(Number);to=new Date(y,mo,0).toISOString().slice(0,10);
 }else{from=document.getElementById("historyFrom").value;to=document.getElementById("historyTo").value;if(from&&to&&from>to){document.getElementById("historySummary").textContent="From date cannot be after To date.";document.getElementById("historyList").innerHTML="";return}}
 const data=txs.filter(t=>txMatchesRange(t,from,to)).sort(compareTransactionsLatestFirst);let income=0,expense=0;data.forEach(t=>t.type==="CREDIT"?income+=t.amount:expense+=t.amount);
 document.getElementById("historySummary").textContent=`${data.length} transaction(s) • Credit ₹${income.toFixed(2)} • Expense ₹${expense.toFixed(2)} • Net ₹${(income-expense).toFixed(2)}`;
 const list=document.getElementById("historyList");list.innerHTML="";
 if(!data.length){list.innerHTML='<div class="empty">No transactions found for this period.</div>';return}
 [...data].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).forEach(t=>{
  const div=document.createElement("div");div.className="tx";
  div.innerHTML=`<div><div class="tx-title">${escapeHtml(t.category||"Uncategorized")}</div><div class="tx-meta">${t.date} • ${t.type} • ${escapeHtml(t.mode)}${t.description?" • "+escapeHtml(t.description):""}</div>${t.remark?`<div class="tx-meta">Remark: ${escapeHtml(t.remark)}</div>`:""}</div><div class="tx-amt ${t.type==="CREDIT"?"green":"red"}">${t.type==="CREDIT"?"+":"-"}${money(t.amount)}</div><div class="tx-actions">${canEditTransaction(t)?`<button class="secondary" onclick="v10RequestEdit(${t.id})">✎ Edit</button>`:`<span class="small" style="text-align:center;width:100%">🔒 ${editTimeLeft(t)}</span>`}</div>`;
  list.appendChild(div);
 });
}
function openEdit(id){
 const t=txs.find(x=>x.id===id); if(!t)return;
 const editDate=document.getElementById("editDate");
 if(editDate) editDate.max=localToday();
 if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");render();return;}
 document.getElementById("editId").value=id;
 document.getElementById("editDate").value=t.date;
 document.getElementById("editType").value=t.type;
 document.getElementById("editAmount").value=t.amount;
 document.getElementById("editCategory").value=t.category||"";
 document.getElementById("editMode").value=t.mode||"UPI";
 document.getElementById("editDescription").value=t.description||"";
 document.getElementById("editRemark").value=t.remark||"";
 document.getElementById("editOther").value=t.other||"";
 document.getElementById("editModal").style.display="block";
}

function v10ActiveSecurity(){
 const p = (typeof v109ActiveProfile === "function") ? v109ActiveProfile() : null;
 if(!p) return null;
 p.security = p.security || {mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
 // Migrate any legacy V10 edit PIN into the active profile once, so Edit and Add Transaction
 // always use exactly the same PIN and recovery code.
 if(false){
   try{
     const legacy=null;
     if(legacy && legacy.pinHash){
       p.security.pinHash=legacy.pinHash;
       p.security.recoveryCode=p.security.recoveryCode||legacy.recoveryCode||"";
       const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
       const q=ps.find(x=>x.id===p.id); if(q){q.security=p.security;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}
     }
   }catch(e){}
 }
 return p.security;
}
function v10EditSec(){return v10ActiveSecurity()}
function v10HashPin(pin){let h=2166136261;for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function v10MakeRecovery(){const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}return s}
function v10SaveEditSec(sec){
 const p=(typeof v109ActiveProfile === "function")?v109ActiveProfile():null; if(!p)return;
 p.security=sec; const ps=v109Profiles(); const q=ps.find(x=>x.id===p.id); if(q)q.security=sec; v109SaveProfiles(ps);
 localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:sec.pinHash,recoveryCode:sec.recoveryCode}));
}
function v10FillEdit(id){openEdit(id)}
function v10RequestEdit(id){
 const t=txs.find(x=>x.id===id); if(!t)return;
 if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return;}
 const s=v10ActiveSecurity();
 if(!s || !s.pinHash){
   document.getElementById("editPinGateBody").innerHTML=`<h3>🔐 Create PIN</h3><p>Create one 4–6 digit PIN. The same PIN will be used for <b>Edit</b> and <b>Add Transaction</b>.</p><input id="v10EditNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10EditConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button onclick="v10FinishEditPin(${id})">Create PIN</button><button class="secondary" onclick="v10CancelEditGate()">Cancel</button>`;
 }else{
   document.getElementById("editPinGateBody").innerHTML=`<h3>🔐 Enter PIN</h3><p>Enter your existing profile PIN to edit this transaction.</p><input id="v10EditPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button onclick="v10CheckEditPin(${id})">Continue</button><button class="secondary" onclick="v10ForgotEditPinDirect(${id})">Forgot PIN?</button><button class="secondary" onclick="v10CancelEditGate()">Cancel</button>`;
 }
 document.getElementById("editPinGate").style.display="block";
 setTimeout(()=>{const el=document.getElementById(s&&s.pinHash?"v10EditPinInput":"v10EditNewPin");if(el)el.focus()},0);
}
function v10FinishEditPin(id){
 const a=document.getElementById("v10EditNewPin")?.value||"",b=document.getElementById("v10EditConfirmPin")?.value||"";
 if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return}
 if(a!==b){alert("PIN and Confirm PIN do not match.");return}
 const sec=v10ActiveSecurity()||{}; sec.pinHash=v10HashPin(a); sec.recoveryCode=sec.recoveryCode||v10MakeRecovery(); sec.editPinLost=false;
 v10SaveEditSec(sec);
 document.getElementById("editPinGateBody").innerHTML=`<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">${sec.recoveryCode}</div><p class="v10small">This is the same PIN for Edit and Add Transaction.</p><button onclick="v10ContinueEdit(${id})">Continue to Edit</button>`;
}
function v10ContinueEdit(id){document.getElementById("editPinGate").style.display="none";openEdit(id)}
function v10CheckEditPin(id){
 const s=v10ActiveSecurity(),p=document.getElementById("v10EditPinInput")?.value||"";
 if(!s||!s.pinHash){alert("PIN is not configured. Please create it first.");return}
 if(v10HashPin(p)!==s.pinHash){alert("Incorrect PIN.");return}
 v10ContinueEdit(id);
}
function v10ForgotEditPinDirect(id){
 const s=v10ActiveSecurity(); if(!s||!s.recoveryCode){alert("No Recovery Code is available. Please use Profile / Mode recovery/reset flow.");return}
 const c=prompt("Enter your Recovery Code:"); if(c===null)return;
 if(c.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
 const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");
 if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
 s.pinHash=v10HashPin(a);s.editPinLost=false;v10SaveEditSec(s);alert("New PIN saved successfully. The same PIN now protects Edit and Add Transaction.");v10ContinueEdit(id);
}
function v10CancelEditGate(){document.getElementById("editPinGate").style.display="none"}

function closeEdit(){document.getElementById("editModal").style.display="none"}
function saveEdit(){const id=Number(document.getElementById("editId").value),t=txs.find(x=>x.id===id);if(!t)return;if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");closeEdit();render();return;}const amount=Number(document.getElementById("editAmount").value),date=document.getElementById("editDate").value,category=pfGetEditCategoryValue(),today=localToday();if(!date||date>today||!Number.isFinite(amount)||amount<=0||!category){if(date>today)document.getElementById("editDate").value=today;alert(date>today?"Future dates are not allowed. Please select today or an earlier date.":"Please enter a valid date, amount and category.");return}t.date=date;t.type=document.getElementById("editType").value;t.amount=amount;t.category=category;t.mode=document.getElementById("editMode").value;t.description=document.getElementById("editDescription").value.trim();t.remark=document.getElementById("editRemark").value.trim();t.other=document.getElementById("editOther").value.trim();sortTransactionsLatestFirst();save();try{const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");const aid=localStorage.getItem("money_manager_active_profile_v10");const ap=ps.find(x=>x&&x.id===aid)||ps[0];if(ap){ap.transactions=txs.map(x=>({...x}));localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}}catch(e){}closeEdit();if(document.getElementById("historyModal").style.display==="block")renderHistory()}

function exportCSV(){
 if(!txs.length){alert("No transactions to export.");return}
 const rows=[["Date","Type","Amount (₹)","Balance (₹)","Category","Description","Remark","Payment Mode","Other"]];
 let b=0;
 txs.forEach(t=>{b+=t.type==="CREDIT"?t.amount:-t.amount;rows.push([t.date,t.type,t.amount,b,t.category,t.description,t.remark,t.mode,t.other])});
 const csv=rows.map(r=>r.map(x=>`"${String(x??"").replaceAll('"','""')}"`).join(",")).join("\n");
 const blob=new Blob([csv],{type:"text/csv"});
 downloadBlob(blob,"money_manager.csv");
}

function escXml(s){
 return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function downloadBlob(blob,name){
 if(window.AndroidFile && AndroidFile.saveFile){
   blob.arrayBuffer().then(buf=>{
     const bytes=new Uint8Array(buf); let bin="";
     const chunk=0x8000; for(let i=0;i<bytes.length;i+=chunk) bin+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+chunk,bytes.length)));
     AndroidFile.saveFile(name,blob.type||"application/octet-stream",btoa(bin));
   }).catch(()=>alert("File export failed."));
   return;
 }
 const a=document.createElement("a");
 a.href=URL.createObjectURL(blob); a.download=name; a.click();
 setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function getDateRange(){
 const from=document.getElementById("pdfFrom").value;
 const to=document.getElementById("pdfTo").value;
 if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
 if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
 return {from,to};
}
function filteredTransactions(){
 const r=getDateRange(); if(!r)return null;
 return txs.filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
}
function setThisMonth(){
 const d=new Date(), y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0");
 document.getElementById("pdfFrom").value=`${y}-${m}-01`;
 document.getElementById("pdfTo").value=new Date(y,d.getMonth()+1,0).toISOString().slice(0,10);
}
function setAllDates(){
 document.getElementById("pdfFrom").value="";
 document.getElementById("pdfTo").value="";
}
function crc32(bytes){
 let table=crc32.table;
 if(!table){table=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);table[n]=c>>>0;}crc32.table=table;}
 let c=0xFFFFFFFF;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;
}
function u16(n){return [n&255,(n>>>8)&255]}
function u32(n){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]}
function catBytes(arrs){let len=arrs.reduce((s,a)=>s+a.length,0),o=new Uint8Array(len),p=0;for(const a of arrs){o.set(a,p);p+=a.length}return o}
function zipStore(files){
 const enc=new TextEncoder(), locals=[], centrals=[];let offset=0;
 for(const f of files){
   const name=enc.encode(f.name),data=typeof f.data==="string"?enc.encode(f.data):f.data,crc=crc32(data);
   const local=catBytes([
    new Uint8Array([80,75,3,4,20,0,0,0,0,0,0,0,0,0]),
    new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),
    new Uint8Array(u16(name.length)),new Uint8Array([0,0]),name,data
   ]);
   const central=catBytes([
    new Uint8Array([80,75,1,2,20,0,20,0,0,0,0,0,0,0]),
    new Uint8Array(u32(crc)),new Uint8Array(u32(data.length)),new Uint8Array(u32(data.length)),
    new Uint8Array(u16(name.length)),new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),
    name,new Uint8Array(u32(offset))
   ]);
   locals.push(local);centrals.push(central);offset+=local.length;
 }
 const body=catBytes(locals),cd=catBytes(centrals),count=files.length;
 const eocd=catBytes([
  new Uint8Array([80,75,5,6,0,0,0,0]),new Uint8Array(u16(count)),new Uint8Array(u16(count)),
  new Uint8Array(u32(cd.length)),new Uint8Array(u32(body.length)),new Uint8Array([0,0])
 ]);
 return catBytes([body,cd,eocd]);
}
function xmlEsc(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}
function xlsxText(v){return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`}
function xlsxNumber(v){return `<c><v>${Number(v)}</v></c>`}
function exportExcel(){
 const data=filteredTransactions();if(!data)return;
 if(!data.length){alert("No transactions in the selected date range.");return;}
 let balance=0;
 const rows=[["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"]];
 data.forEach(t=>{balance+=t.type==="CREDIT"?t.amount:-t.amount;rows.push([t.date,t.type,t.amount,balance,t.category,t.description,t.remark,t.mode,t.other])});
 const sheetRows=rows.map((r,rowIndex)=>`<row>${r.map((v,i)=>((rowIndex>0)&&(i===2||i===3))?xlsxNumber(Number.isFinite(Number(v))?Number(v):0):xlsxText(v)).join("")}</row>`).join("");
 const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
 const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
 const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
 const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
 const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
 const bytes=zipStore([
  {name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},
  {name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},
  {name:"xl/worksheets/sheet1.xml",data:sheet}
 ]);
 downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions.xlsx");
}
function pdfEscape(s){
 return String(s).replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
}
function makeSimplePDF(lines){
 const width=595,height=842, margin=36, lineH=15;
 const usable=Math.max(1,Math.floor((height-60)/lineH));
 const pages=[];
 for(let i=0;i<lines.length;i+=usable) pages.push(lines.slice(i,i+usable));
 if(!pages.length) pages.push(["No transactions."]);
 let objs=[];
 function add(o){objs.push(o);return objs.length;}
 const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
 const pageIds=[], contentIds=[];
 pages.forEach(pg=>{
   let y=height-45, stream="BT\n/F1 10 Tf\n";
   pg.forEach((line,idx)=>{
     stream+=`1 0 0 1 ${margin} ${y} Tm (${pdfEscape(line.slice(0,105))}) Tj\n`;
     y-=lineH;
   });
   stream+="ET";
   const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
   contentIds.push(cid);
   pageIds.push(null);
 });
 const pagesId=add("PAGES_PLACEHOLDER");
 pages.forEach((_,i)=>{
   pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`);
 });
 objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;
 const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
 let pdf="%PDF-1.4\n", offsets=[0];
 objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});
 const xref=pdf.length;
 pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
 for(let i=1;i<=objs.length;i++) pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
 pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return new Blob([pdf],{type:"application/pdf"});
}
function exportPDF(){
 const data=filteredTransactions(); if(!data)return;
 if(!data.length){alert("No transactions in the selected date range.");return;}
 let from=document.getElementById("pdfFrom").value||data[0].date;
 let to=document.getElementById("pdfTo").value||data[data.length-1].date;
 let income=0,expense=0,balance=0;
 const lines=["MONEY MANAGER - TRANSACTION REPORT",`Period: ${from} to ${to}`,""];
 lines.push("Date       Type      Amount      Balance     Category");
 lines.push("---------------------------------------------------------------");
 data.forEach(t=>{
   balance+=t.type==="CREDIT"?t.amount:-t.amount;
   if(t.type==="CREDIT")income+=t.amount; else expense+=t.amount;
   lines.push(`${t.date}  ${t.type.padEnd(8)} ${("Rs."+Number(t.amount).toFixed(2)).padStart(10)}  ${("Rs."+Number(balance).toFixed(2)).padStart(10)}  ${t.category}`);
   if(t.description) lines.push(`           Description: ${t.description}`);
 });
 lines.push("","SUMMARY",`Total Credit: Rs.${income.toFixed(2)}`,`Total Expense: Rs.${expense.toFixed(2)}`,`Net Balance: Rs.${(income-expense).toFixed(2)}`);
 downloadBlob(makeSimplePDF(lines),`money_transactions_${from}_to_${to}.pdf`);
}

render();

(function(){
  const PROFILE_KEY="money_manager_profiles_v10";
  const ACTIVE_KEY="money_manager_active_profile_v10";
  /* V35: an automatic/default Profile is allowed to exist only after a
     real authenticated account is present.  This prevents startup/login
     code from manufacturing a second local "My Money" before cloud restore. */
  function profileAccountReady(){
    try{return !!String(localStorage.getItem("mf_account_email")||"").trim()}catch(e){return false}
  }
  const DEFAULT_PROFILE=()=>({
    id:"auto_default_profile_v35",
    name:"My Money", transactions:[], createdManually:false, autoGeneratedProfile:true,
    security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}
  });

  function getProfiles(){
    try{
      const x=JSON.parse(localStorage.getItem(PROFILE_KEY)||"null");
      if(Array.isArray(x)&&x.length)return x;
      /* Before authentication/cloud restore there must be NO synthetic
         Profile object in localStorage. The authenticated restore path
         will provide the real profile, or create exactly one fallback. */
      if(!profileAccountReady())return [];
      const p=DEFAULT_PROFILE();
      localStorage.setItem(PROFILE_KEY,JSON.stringify([p]));
      localStorage.setItem(ACTIVE_KEY,p.id);
      return [p];
    }catch(e){return []}
  }
  function setProfiles(x){localStorage.setItem(PROFILE_KEY,JSON.stringify(x))}
  function activeId(){return localStorage.getItem(ACTIVE_KEY)}
  function current(){
    let ps=getProfiles(), id=activeId(), p=ps.find(x=>x.id===id);
    if(!p){p=ps[0];localStorage.setItem(ACTIVE_KEY,p.id)}
    return p;
  }
  function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
  function hash(pin){
    let h=2166136261;
    for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }

  window.v10OpenProfiles=function(){
    if(typeof closeMenu==="function") closeMenu();
    const ps=getProfiles(), id=activeId()||ps[0].id;
    const list=document.getElementById("v10ProfileList");
    if(!list)return;
    const photo=p=>{const src=(p&&typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0)?p.profilePhoto:'';return src?`<img class="mf-v33-profile-list-photo" alt="Profile photo" src="${esc(src)}">`:'<div class="mf-v33-profile-list-photo mf-v33-profile-placeholder">👤</div>'};
    list.innerHTML=ps.map(p=>`<div class="v10row mf-v33-profile-row">${photo(p)}<div class="mf-v33-profile-info"><b>${esc(p.name||'My Money')}</b><div class="v10small">${p.id===id?'Active profile':'Separate profile'}</div></div><div class="mf-v33-profile-actions"><button type="button" class="secondary mf-v33-edit-name" onclick="v33EditProfileName('${String(p.id).replace(/'/g,"\\'")}')">✎ Edit Name</button><button type="button" class="mf-v33-switch-btn" onclick="v10SwitchProfile('${String(p.id).replace(/'/g,"\\'")}')">${p.id===id?'Active':'Switch'}</button></div></div>`).join("");
    document.getElementById("v10ProfileModal").style.display="block";
  };
  window.v10CloseProfileModal=function(){document.getElementById("v10ProfileModal").style.display="none"};
  window.v10CreateProfile=function(){
    const name=(document.getElementById("v10NewProfileName").value||"").trim()||("Mode "+(getProfiles().length+1));
    const ps=getProfiles(), p=DEFAULT_PROFILE();
    // A newly created Mode is a genuinely fresh workspace: no transactions,
    // no PIN, no recovery code and no security state copied from another Mode.
    p.name=name;
    p.createdManually=true;
    p.transactions=[];
    p.security={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true};
    ps.push(p); setProfiles(ps);
    try{["money_manager_edit_security_v1","mm_global_pin","globalPin","globalPinHash","pinHash"].forEach(k=>localStorage.removeItem(k))}catch(e){}
    localStorage.setItem(ACTIVE_KEY,p.id);
    document.getElementById("v10NewProfileName").value="";
    v10ApplyProfile(p);
  };
  window.v10SwitchProfile=function(id){
    const p=getProfiles().find(x=>x.id===id); if(!p)return;
    localStorage.setItem(ACTIVE_KEY,id); v10ApplyProfile(p);
  };
  function v10ApplyProfile(p){
    // Keep the existing V10 app data isolated per profile without deleting anything.
    localStorage.setItem("money_manager_active_profile_v10",p.id);
    if(typeof txs!=="undefined") { txs=Array.isArray(p.transactions)?p.transactions:[]; localStorage.setItem(typeof KEY!=="undefined"?KEY:"transactions",JSON.stringify(txs)); }
    if(typeof config!=="undefined" && p.config) config=p.config;
    if(typeof render==="function") render();
    const badge=document.getElementById("profileBadge"); if(badge) badge.textContent=p.name;
    v10CloseProfileModal();
    alert("Switched to "+p.name+".");
  }

  function v10PinActionsHtml(title,body,buttons){
    const actions=document.getElementById("v10PinActions");
    if(!actions)return;
    actions.innerHTML=`<div class="v10pin-step"><h3>${title}</h3>${body}${buttons||''}</div>`;
    // Keep the single PIN Security modal as the only security overlay.
    ["v10AddTxSettingGate","v10AddTxPinModal","v10AddTxGate","editPinGate"].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display="none";});
    const modal=document.getElementById("v10PinModal"); if(modal)modal.style.display="block";
    setTimeout(()=>{const first=actions.querySelector('input');if(first)first.focus()},30);
  }
  function v10PinBack(){v10OpenPin()}
  window.v10OpenPin=function(){
    if(typeof closeMenu==="function")closeMenu();
    ["v10AddTxSettingGate","v10AddTxPinModal","v10AddTxGate","editPinGate"].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display="none";});
    const p=current(),s=p.security||{};
    const status=document.getElementById("v10PinStatusText");
    if(s.pinHash){
      if(status)status.textContent="PIN is already created. The same PIN protects all security actions in this Profile / Mode.";
      v10PinActionsHtml("PIN Security","<p class=\"v10small\">Choose how you want to manage the PIN for this Profile / Mode.</p>",'<button type="button" onclick="v10ChangePin()">🔄 Change PIN</button><button type="button" class="secondary" onclick="v10ForgotPin()">🔑 Verify / Recovery</button>');
    }else{
      if(status)status.textContent="No PIN created yet. Create one PIN; it will be used everywhere in this Profile / Mode.";
      v10PinActionsHtml("Create PIN","<p>Create one 4–6 digit PIN. This same PIN will protect every security-related action in this Profile / Mode.</p>",'<button type="button" onclick="v10CreateInitialPin()">🔐 Create PIN</button>');
    }
    const modal=document.getElementById("v10PinModal");if(modal)modal.style.display="block";
  };
  window.v10ClosePinModal=function(){const m=document.getElementById("v10PinModal");if(m)m.style.display="none"};
  function saveUnifiedPin(a,b){
    if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return false}
    if(a!==b){alert("PIN and Confirm PIN do not match.");return false}
    const ps=getProfiles(),p=current();p.security=p.security||{};p.security.pinHash=hash(a);p.security.editPinLost=false;p.security.recoveryCode=p.security.recoveryCode||recovery();p.security.mode=p.security.mode==="BIOMETRIC"?"BOTH":"PIN";setProfiles(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    return p;
  }
  window.v10CreateInitialPin=function(){
    v10PinActionsHtml("Create PIN","<p>Create the PIN for this Profile / Mode. It will be the single PIN used across all security features here.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm PIN\">",'<button type="button" onclick="v10SavePin()">Save PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10ChangePin=function(){
    v10PinActionsHtml("Verify Current PIN","<p>Enter the current PIN for this Profile / Mode. The existing PIN must be verified before it can be changed.</p><input id=\"v10CurrentPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Current PIN\">",'<button type="button" onclick="v10VerifyCurrentForChange()">Continue</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10VerifyCurrentForChange=function(){
    const s=current().security||{},v=document.getElementById("v10CurrentPin")?.value||"";
    if(!s.pinHash){v10PinBack();return}
    if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return}
    v10PinActionsHtml("Create New PIN","<p>Current PIN verified. Create your new 4–6 digit PIN.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm New PIN\">",'<button type="button" onclick="v10SavePin()">Save New PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10SavePin=function(){
    const a=document.getElementById("v10NewPin")?.value||"",b=document.getElementById("v10ConfirmPin")?.value||"";
    const p=saveUnifiedPin(a,b);if(!p)return;
    v10ClosePinModal();alert("PIN changed successfully.\n\nThe same PIN now protects all security features in this Profile / Mode.\n\nRecovery Code:\n"+p.security.recoveryCode);
  };
  window.v10ForgotPin=function(){
    const p=current(),s=p.security||{};
    if(!s.recoveryCode){alert("No Recovery Code is available for this profile.");return}
    v10PinActionsHtml("Recovery Verification","<p>Enter the Recovery Code for this Profile / Mode to create a new PIN.</p><input id=\"v10RecoveryInput\" type=\"text\" autocomplete=\"off\" placeholder=\"Recovery Code\">",'<button type="button" onclick="v10VerifyRecoveryForChange()">Verify Recovery Code</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10VerifyRecoveryForChange=function(){
    const p=current(),s=p.security||{},code=(document.getElementById("v10RecoveryInput")?.value||"").trim().toUpperCase();
    if(!s.recoveryCode||code!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
    v10PinActionsHtml("Create New PIN","<p>Recovery Code verified. Create your new 4–6 digit PIN.</p><input id=\"v10NewPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"New 4–6 digit PIN\"><input id=\"v10ConfirmPin\" type=\"password\" inputmode=\"numeric\" maxlength=\"6\" placeholder=\"Confirm New PIN\">",'<button type="button" onclick="v10SaveRecoveredPin()">Save New PIN</button><button type="button" class="secondary" onclick="v10PinBack()">Back</button>');
  };
  window.v10SaveRecoveredPin=function(){
    const a=document.getElementById("v10NewPin")?.value||"",b=document.getElementById("v10ConfirmPin")?.value||"";
    if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4 to 6 digits.");return}
    if(a!==b){alert("PIN and Confirm PIN do not match.");return}
    const ps=getProfiles(),p=current();p.security=p.security||{};p.security.pinHash=hash(a);p.security.editPinLost=false;setProfiles(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    v10ClosePinModal();alert("PIN recovered and changed successfully.\n\nThe same PIN now protects all security features in this Profile / Mode.");
  };
  // Expose a helper for future Android/native biometric integration.
  window.v10GetActiveProfile=function(){return current()};
})();


(function(){
function P(){try{return JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]")}catch(e){return[]}}
function S(x){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x))}
function A(){let p=P(),id=localStorage.getItem("money_manager_active_profile_v10");return p.find(x=>x.id===id)||p[0]||null}
function H(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return(h>>>0).toString(16)}
function closeG(){let e=document.getElementById("v10AddTxGate");if(e)e.style.display="none"}
function closeSettingGate(){let e=document.getElementById("v10AddTxSettingGate");if(e)e.style.display="none"}
function v109Profiles(){
  try{
    let ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"null");
    if(!Array.isArray(ps)||!ps.length){
      /* Never manufacture a Profile before authentication/cloud restore. */
      try{if(!String(localStorage.getItem("mf_account_email")||"").trim())return []}catch(e){return []}
      const legacy=Array.isArray(txs)?txs:[];
      ps=[{id:"auto_default_profile_v35",name:"My Money",transactions:legacy,createdManually:false,autoGeneratedProfile:true,security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}}];
      localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
    }
    ps.forEach(p=>{
      p.security=p.security||{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
      // Security is profile-local. Never import the old global PIN into a profile.
      if(typeof p.security.addProtection!=="boolean") p.security.addProtection=false;
      if(!Array.isArray(p.transactions)) p.transactions=[];
    });
    localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
    if(!localStorage.getItem("money_manager_active_profile_v10")) localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
    return ps;
  }catch(e){return []}
}
function v109SaveProfiles(x){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x))}
function v109ActiveProfile(){
  const ps=v109Profiles();
  const id=localStorage.getItem("money_manager_active_profile_v10");
  const p=ps.find(x=>x.id===id)||ps[0]||null;
  if(p){localStorage.setItem("money_manager_active_profile_v10",p.id);p.security=p.security||{};if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;}
  return p;
}
function v109CloseAddGate(){const e=document.getElementById("v10AddTxGate");if(e)e.style.display="none"}
function v109RealAdd(){
  v109CloseAddGate();
  try{
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the latest app version.");return false}
    return addTx()!==false;
  }catch(e){alert("Add Transaction failed: "+(e&&e.message?e.message:"Unknown error"));return false}
}
function closeG(){v109CloseAddGate()}
function closeSettingGate(){let e=document.getElementById("v10AddTxSettingGate");if(e)e.style.display="none"}
function settingGateBody(html){document.getElementById("v10AddTxSettingGateBody").innerHTML=html;document.getElementById("v10AddTxSettingGate").style.display="block"}
window.v10AddTxPinSettings=function(){
  if(typeof closeMenu==="function")closeMenu();
  const p=v109ActiveProfile();
  if(!p){alert("Profile is not ready. Please open Profile / Mode once, then try again.");return}
  p.security=p.security||{};
  document.getElementById("v10AddTxPinToggle").checked=!!p.security.addProtection;
  document.getElementById("v10AddTxPinModal").style.display="block";
  v10RefreshAddTxSecurityUI();
};
window.v10CloseAddTxPinSettings=function(){document.getElementById("v10AddTxPinModal").style.display="none"};
window.v10RefreshAddTxSecurityUI=function(){
  const p=v109ActiveProfile(), on=!!(p&&p.security&&p.security.addProtection);
  const t=document.getElementById("v10AddTxPinToggle"); if(t)t.checked=on;
  const st=document.getElementById("v10AddTxPinState"); if(st)st.textContent=on?"ON — PIN required before adding":"OFF — no PIN required";
  const mb=document.getElementById("v10MenuAddTxStatus"); if(mb)mb.textContent=on?"🔒 ON":"🔓 OFF";
  const ab=document.getElementById("v10AddTxButton"); if(ab)ab.textContent=on?"🔒 Add Transaction (PIN)":"Add Transaction";
};
function getStoredActiveProfileFresh(){
  try{
    const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x.id===id)||ps[0]||null;
    if(p){
      p.security=p.security||{};
      if(typeof p.security.addProtection!=="boolean") p.security.addProtection=false;
    }
    return {ps,p};
  }catch(e){ return {ps:[],p:null}; }
}
function persistActiveSecurity(sec){
  const x=getStoredActiveProfileFresh();
  if(!x.p)return false;
  x.p.security=sec||{};
  if(typeof x.p.security.addProtection!=="boolean") x.p.security.addProtection=false;
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  return true;
}
window.v10ChooseAddTxSecurity=function(desired){
  const x=getStoredActiveProfileFresh(), p=x.p;
  if(!p){alert("Profile could not be initialized.");return;}
  const wanted=!!desired;
  const current=!!p.security.addProtection;
  // Do not change the setting until the existing profile PIN is verified.
  if(current===wanted){
    v10RefreshAddTxSecurityUI();
    return;
  }
  v10SaveAddTxPinSetting(wanted);
};
window.v10SaveAddTxPinSetting=function(forcedDesired){
  const desired=!!forcedDesired;
  const x=getStoredActiveProfileFresh(), p=x.p;
  if(!p){alert("Profile could not be initialized.");return;}
  document.getElementById("v10AddTxPinModal").style.display="none";
  if(!p.security.pinHash){
    settingGateBody('<h3>🔐 Create the profile PIN first</h3><p>Create one PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and turning this setting ON/OFF.</p><input id="v10SetNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10SetConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button onclick="v10CreateSettingPin('+JSON.stringify(desired)+')">Create PIN & Continue</button><button class="secondary" onclick="v10CancelSettingGate()">Cancel</button>');
    return;
  }
  settingGateBody('<h3>🔐 Verify Existing PIN</h3><p>Use the same profile PIN. No new PIN is being created.</p><input id="v10SetPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter existing PIN"><button onclick="v10VerifySettingPin('+JSON.stringify(desired)+')">Continue</button><button class="secondary" onclick="v10ForgotSettingPin('+JSON.stringify(desired)+')">Forgot PIN?</button><button class="secondary" onclick="v10CancelSettingGate()">Cancel</button>');
};
window.v10VerifySettingPin=function(desired){
  const x=getStoredActiveProfileFresh(), p=x.p, v=document.getElementById("v10SetPinInput")?.value||"";
  if(!p?.security?.pinHash){alert("PIN is not configured. Please create it first.");return;}
  if(H(v)!==p.security.pinHash){alert("Incorrect PIN.");return;}
  p.security.addProtection=!!desired;
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  // Re-read from storage so the Add button and future checks use exactly the saved value.
  v10RefreshAddTxSecurityUI();
  closeSettingGate();
  document.getElementById("v10AddTxPinModal").style.display="block";
  v10RefreshAddTxSecurityUI();
};
window.v10CreateSettingPin=function(desired){
  const a=document.getElementById("v10SetNewPin")?.value||"",b=document.getElementById("v10SetConfirmPin")?.value||"";
  if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
  if(a!==b){alert("PINs do not match.");return}
  const x=getStoredActiveProfileFresh(),p=x.p;if(!p)return;
  p.security=p.security||{};p.security.pinHash=H(a);p.security.addProtection=!!desired;p.security.recoveryCode=p.security.recoveryCode||recovery();
  localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));
  closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI();
  alert("PIN created successfully.\n\nRecovery Code:\n"+p.security.recoveryCode+"\n\nThis same PIN protects Edit and Add Transaction.");
};
window.v10ForgotSettingPin=function(desired){
  const x=getStoredActiveProfileFresh(),p=x.p,s=p&&p.security||{};if(!s.recoveryCode){alert("No Recovery Code is available.");return}
  const code=prompt("Enter your Recovery Code:");if(code===null)return;if(code.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
  const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
  s.pinHash=H(a);p.security=s;localStorage.setItem("money_manager_profiles_v10",JSON.stringify(x.ps));closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI();alert("New PIN saved. The same PIN now protects Edit and Add Transaction.");
};
window.v10CancelSettingGate=function(){closeSettingGate();document.getElementById("v10AddTxPinModal").style.display="block";v10RefreshAddTxSecurityUI()};
window.v109RequestAddTransaction=function(){
  const x=getStoredActiveProfileFresh(),p=x.p;
  if(!p){alert("Could not initialize the active profile.");return false;}
  // IMPORTANT: read the saved ON/OFF value fresh every time.
  const protection=!!p.security.addProtection;
  if(!protection){ return v109RealAdd(); }
  const gate=document.getElementById("v10AddTxGate"),body=document.getElementById("v10AddTxGateBody");
  if(!gate||!body){alert("Add Transaction security screen is unavailable.");return false}
  if(!p.security.pinHash){
    body.innerHTML='<h3>🔐 Create Profile PIN</h3><p>Create one PIN. The same PIN will protect Edit and Add Transaction.</p><input id="v10AddNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="v10AddConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" onclick="v10SaveAddPin()">Create PIN & Add</button><button type="button" class="secondary" onclick="v10CancelAddPin()">Cancel</button>';
  }else{
    body.innerHTML='<h3>🔐 Enter PIN</h3><p>Enter the same profile PIN used for Edit.</p><input id="v10AddPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button type="button" onclick="v10VerifyAddPin()">Continue</button><button type="button" class="secondary" onclick="v10CancelAddPin()">Cancel</button>';
  }
  gate.style.display="block";setTimeout(()=>{const el=document.getElementById("v10AddPinInput")||document.getElementById("v10AddNewPin");if(el)el.focus()},0);return false;
};
window.v10VerifyAddPin=function(){
 const p=v109ActiveProfile(),v=document.getElementById("v10AddPinInput")?.value||"";
 if(!p?.security?.pinHash){alert("PIN is not configured. Please create it first.");return}
 if(H(v)!==p.security.pinHash){alert("Incorrect PIN.");return}
 v109RealAdd();
};
window.v10CancelAddPin=function(){v109CloseAddGate()};
window.v10SaveAddPin=function(){
 const a=document.getElementById("v10AddNewPin")?.value||"",b=document.getElementById("v10AddConfirmPin")?.value||"";
 if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
 if(a!==b){alert("PINs do not match.");return}
 const ps=v109Profiles(),p=v109ActiveProfile();if(!p)return;
 p.security=p.security||{};p.security.pinHash=H(a);p.security.addProtection=true;p.security.recoveryCode=p.security.recoveryCode||recovery();
 v109SaveProfiles(ps);v109RealAdd();
};

try{v10RefreshAddTxSecurityUI()}catch(e){}


})();


/* V15 UNIFIED SECURITY OVERRIDE
   One profile PIN + one recovery code for Edit and Add Transaction.
   No per-transaction skip. */
(function(){
  function mmProfiles(){
    try { const x=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]"); return Array.isArray(x)?x:[]; } catch(e){ return []; }
  }
  function mmSaveProfiles(ps){ localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps)); }
  function mmActive(){
    const ps=mmProfiles();
    const id=localStorage.getItem("money_manager_active_profile_v10");
    return ps.find(p=>p.id===id)||ps[0]||null;
  }
  function mmHash(pin){
    let h=2166136261; pin=String(pin||"");
    for(let i=0;i<pin.length;i++){h^=pin.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function mmRecovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function mmSec(){
    const ps=mmProfiles(), p=mmActive(); if(!p) return null;
    p.security=p.security||{};
    if(false){
      try{
        const legacy=null;
        if(legacy&&legacy.pinHash){p.security.pinHash=legacy.pinHash;p.security.recoveryCode=p.security.recoveryCode||legacy.recoveryCode||"";}
      }catch(e){}
    }
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    if(p.security.pinHash&&!p.security.recoveryCode)p.security.recoveryCode=mmRecovery();
    const q=ps.find(x=>x.id===p.id); if(q)q.security=p.security;
    mmSaveProfiles(ps);
    if(p.security.pinHash)localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
    return p.security;
  }
  function mmClose(id){const e=document.getElementById(id);if(e)e.style.display="none";}
  function mmGate(body){const e=document.getElementById("v10AddTxGate"),b=document.getElementById("v10AddTxGateBody");if(!e||!b)return false;b.innerHTML=body;e.style.display="block";return true;}
  function mmRealAdd(){
    mmClose("v10AddTxGate");
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the app.");return false;}
    try{return addTx()!==false}catch(e){alert("Add Transaction failed: "+(e.message||"Unknown error"));return false;}
  }
  function mmAskPin(onSuccess,onCancel){
    const s=mmSec();
    if(!s){alert("Profile is not ready.");return;}
    if(!s.pinHash){
      mmGate('<h3>🔐 Create PIN</h3><p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p><input id="mmNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="mmConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" id="mmCreatePinBtn">Create PIN</button><button type="button" class="secondary" id="mmCancelPinBtn">Cancel</button>');
      document.getElementById("mmCreatePinBtn").onclick=function(){
        const a=document.getElementById("mmNewPin").value,b=document.getElementById("mmConfirmPin").value;
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PINs do not match.");return}
        const ps=mmProfiles(),p=mmActive();p.security=p.security||{};p.security.pinHash=mmHash(a);p.security.recoveryCode=p.security.recoveryCode||mmRecovery();
        mmSaveProfiles(ps);localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
        mmGate('<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">'+p.security.recoveryCode+'</div><p class="v10small">This is the same PIN for Edit, Add Transaction and security settings.</p><button type="button" id="mmContinuePin">Continue</button>');
        document.getElementById("mmContinuePin").onclick=function(){mmClose("v10AddTxGate");onSuccess();};
      };
      document.getElementById("mmCancelPinBtn").onclick=function(){mmClose("v10AddTxGate");if(onCancel)onCancel();};
      return;
    }
    mmGate('<h3>🔐 Enter PIN</h3><p>Enter your existing profile PIN.</p><input id="mmPinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN"><button type="button" id="mmPinContinue">Continue</button><button type="button" class="secondary" id="mmForgotPin">Forgot PIN?</button><button type="button" class="secondary" id="mmPinCancel">Cancel</button>');
    document.getElementById("mmPinContinue").onclick=function(){const v=document.getElementById("mmPinInput").value;if(!mmV19CheckPin(v,mmSec().pinHash,mmHash))return;mmClose("v10AddTxGate");onSuccess();};
    document.getElementById("mmForgotPin").onclick=function(){
      const s2=mmSec(),code=prompt("Enter your Recovery Code:");if(code===null)return;
      if(code.trim().toUpperCase()!==String(s2.recoveryCode||"").toUpperCase()){alert("Incorrect Recovery Code.");return}
      const a=prompt("Create new 4–6 digit PIN:"),b=prompt("Confirm new PIN:");
      if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup failed.");return}
      const ps=mmProfiles(),p=mmActive();p.security.pinHash=mmHash(a);mmSaveProfiles(ps);localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:p.security.pinHash,recoveryCode:p.security.recoveryCode}));
      mmClose("v10AddTxGate");onSuccess();
    };
    document.getElementById("mmPinCancel").onclick=function(){mmClose("v10AddTxGate");if(onCancel)onCancel();};
    setTimeout(()=>document.getElementById("mmPinInput")?.focus(),0);
  }

  // Add Transaction: ON means compulsory PIN; OFF means no PIN. Never a skip button.
  window.v109RequestAddTransaction=function(){
    const s=mmSec(); if(!s){alert("Profile is not ready.");return false;}
    if(!s.addProtection)return mmRealAdd();
    mmAskPin(mmRealAdd,()=>{}); return false;
  };

  // Menu ON/OFF: changing the setting itself always requires the existing profile PIN.
  window.v10SaveAddTxPinSetting=function(forcedDesired){
    const p=mmActive(),s=mmSec(); if(!p||!s)return;
    const desired=!!forcedDesired;
    if(!!s.addProtection===desired){v10RefreshAddTxSecurityUI();return;}
    if(!s.pinHash){
      // First-time setup: create the one common PIN, then apply the requested ON/OFF state.
      const a=prompt("Create one 4–6 digit profile PIN:"),b=prompt("Confirm PIN:");
      if(!/^\d{4,6}$/.test(a||"")||a!==b){alert("PIN setup cancelled.");v10RefreshAddTxSecurityUI();return;}
      const ps=mmProfiles();p.security.pinHash=mmHash(a);p.security.recoveryCode=p.security.recoveryCode||mmRecovery();p.security.addProtection=desired;mmSaveProfiles(ps);alert("PIN created.\n\nRecovery Code:\n"+p.security.recoveryCode);v10RefreshAddTxSecurityUI();return;
    }
    mmAskPin(function(){const ps=mmProfiles(),q=mmActive();q.security.addProtection=desired;mmSaveProfiles(ps);v10RefreshAddTxSecurityUI();},()=>v10RefreshAddTxSecurityUI());
  };
  window.v10ChooseAddTxSecurity=function(desired){window.v10SaveAddTxPinSetting(!!desired);};

  // Edit: always use the exact same profile PIN/recovery flow.
  window.v10RequestEdit=function(id){
    const t=txs.find(x=>x.id===id); if(!t)return;
    if(!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return;}
    mmAskPin(function(){
      document.getElementById("editId").value=id;
      const editDate=document.getElementById("editDate");
      if(editDate) editDate.max=localToday();
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },()=>{});
  };

  // Remove any legacy skip entry point as an extra safety measure.
  window.v10SkipAddPin=function(){alert("Skip is disabled. Add Transaction security is controlled only by the ON/OFF setting in Menu.");};
  try{v10RefreshAddTxSecurityUI();}catch(e){}
})();


/* FINAL ADD-TRANSACTION PIN SWITCH FIX
   One profile PIN. Menu switch is authoritative and is persisted immediately after PIN verification.
*/
(function(){
  function getPS(){try{const a=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function getP(){const ps=getPS(),id=localStorage.getItem('money_manager_active_profile_v10');return ps.find(x=>x.id===id)||ps[0]||null}
  function save(ps){localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps))}
  function hash(v){let h=2166136261;v=String(v||'');for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
  function recovery(){const c='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<12;i++){if(i&&i%4===0)s+='-';s+=c[Math.floor(Math.random()*c.length)]}return s}
  function refresh(){const p=getP(),on=!!(p&&p.security&&p.security.addProtection);const t=document.getElementById('v10AddTxPinToggle');if(t)t.checked=on;const st=document.getElementById('v10AddTxPinState');if(st)st.textContent=on?'ON — PIN required before adding':'OFF — no PIN required';const mb=document.getElementById('v10MenuAddTxStatus');if(mb)mb.textContent=on?'🔒 ON':'🔓 OFF';const ab=document.getElementById('v10AddTxButton');if(ab)ab.textContent=on?'🔒 Add Transaction (PIN)':'Add Transaction';}
  function verifyExisting(p){
    const pin=prompt('Enter your existing profile PIN:');
    if(pin===null)return false;
    if(!p.security||!p.security.pinHash){alert('No PIN is created for this profile.');return false;}
    if(hash(pin)!==p.security.pinHash){alert('Incorrect PIN. Setting was not changed.');return false;}
    return true;
  }
  function createPin(p,desired){
    const a=prompt('Create one 4–6 digit profile PIN:');if(a===null)return false;
    const b=prompt('Confirm PIN:');if(b===null)return false;
    if(!/^\d{4,6}$/.test(a)||a!==b){alert('PIN setup failed. PIN must be 4–6 digits and match.');return false;}
    p.security=p.security||{};p.security.pinHash=hash(a);p.security.recoveryCode=p.security.recoveryCode||recovery();p.security.addProtection=desired;return true;
  }
  window.v10ChooseAddTxSecurity=function(desired){
    const ps=getPS(),p=getP(); if(!p){alert('Profile is not ready.');refresh();return;}
    p.security=p.security||{};
    const wanted=!!desired,current=!!p.security.addProtection;
    refresh(); // immediately restore checkbox to the saved state until authorization succeeds
    if(current===wanted)return;
    if(!p.security.pinHash){
      if(!createPin(p,wanted)){refresh();return;}
    }else{
      if(!verifyExisting(p)){refresh();return;}
      p.security.addProtection=wanted;
    }
    const q=ps.find(x=>x.id===p.id);if(q)q.security=p.security;save(ps);
    refresh();
    alert(wanted?'Add Transaction PIN is now ON.':'Add Transaction PIN is now OFF.');
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};
  window.v109RequestAddTransaction=function(){
    const p=getP();if(!p){alert('Profile is not ready.');return false;}
    p.security=p.security||{};const on=!!p.security.addProtection;
    if(!on){if(typeof addTx==='function'){try{return addTx()!==false}catch(e){alert('Add Transaction failed: '+(e.message||e));return false}}alert('Add Transaction function is unavailable.');return false}
    if(!p.security.pinHash){alert('Please create your profile PIN first from Menu → Add Transaction PIN.');return false}
    const pin=prompt('Enter your profile PIN to add this transaction:');if(pin===null)return false;
    if(hash(pin)!==p.security.pinHash){alert('Incorrect PIN. Transaction was not added.');return false}
    if(typeof addTx==='function'){try{return addTx()!==false}catch(e){alert('Add Transaction failed: '+(e.message||e));return false}}
    alert('Add Transaction function is unavailable.');return false;
  };
  refresh();
})();


/* MM_V19_PIN_LOCKOUT
   Common PIN attempt protection:
   - 5 wrong attempts -> 30 second pause
   - successful PIN resets the counter
   - applies to PIN prompts that call mmV19CheckPin()
*/
(function(){
  const KEY="mm_v19_pin_attempts";
  const LOCK="mm_v19_pin_lock_until";

  function state(){
    let n=parseInt(sessionStorage.getItem(KEY)||"0",10);
    let until=parseInt(sessionStorage.getItem(LOCK)||"0",10);
    if(!Number.isFinite(n)||n<0)n=0;
    if(!Number.isFinite(until)||until<0)until=0;
    return {n,until};
  }
  function save(s){
    sessionStorage.setItem(KEY,String(s.n));
    sessionStorage.setItem(LOCK,String(s.until));
  }
  window.mmV19PinLockRemaining=function(){
    const s=state(), left=Math.max(0,s.until-Date.now());
    return left;
  };
  window.mmV19CheckPin=function(pin, expectedHash, hashFn){
    const s=state(), left=Math.max(0,s.until-Date.now());
    if(left>0){
      const sec=Math.ceil(left/1000);
      alert("Too many incorrect PIN attempts. Please wait "+sec+" seconds.");
      return false;
    }
    if(hashFn(pin)!==expectedHash){
      s.n++;
      if(s.n>=5){
        s.n=0;
        s.until=Date.now()+30000;
        save(s);
        alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");
      }else{
        save(s);
        alert("Incorrect PIN. Attempts remaining: "+(5-s.n)+".");
      }
      return false;
    }
    save({n:0,until:0});
    return true;
  };
})();


/* V19 FINAL FIX — ONE UNIFIED PIN GATE FOR EDIT + ADD TRANSACTION
   - Add Transaction uses the exact same custom gate as Edit.
   - No browser prompt/alert is used for PIN entry or recovery.
   - Same profile PIN + Recovery Code for Edit, Add and Add-PIN setting.
   - 5 wrong attempts => 30-second pause on both Edit and Add.
   - No per-transaction Skip.
*/
(function(){
  function profiles(){
    try{
      let ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"null");
      if(!Array.isArray(ps)||!ps.length){
        /* Never manufacture a Profile before authentication/cloud restore. */
        try{if(!String(localStorage.getItem("mf_account_email")||"").trim())return []}catch(e){return []}
        const legacyTx=Array.isArray(window.txs)?window.txs:[];
        ps=[{id:"auto_default_profile_v35",name:"My Money",transactions:legacyTx,createdManually:false,autoGeneratedProfile:true,
          security:{mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false}}];
        localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
        localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
      }
      ps.forEach(p=>{
        p.security=p.security||{};
        if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
        if(!Array.isArray(p.transactions))p.transactions=[];
      });
      if(!localStorage.getItem("money_manager_active_profile_v10"))localStorage.setItem("money_manager_active_profile_v10",ps[0].id);
      localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      return ps;
    }catch(e){return []}
  }
  function active(){
    const ps=profiles();
    if(!ps.length)return null;
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x.id===id)||ps[0];
    localStorage.setItem("money_manager_active_profile_v10",p.id);
    p.security=p.security||{};
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    return p;
  }
  function save(ps){localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));}
  function hash(pin){
    if(typeof v10HashPin==="function")return v10HashPin(String(pin||""));
    let h=2166136261,s=String(pin||"");
    for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    if(typeof v10MakeRecovery==="function")return v10MakeRecovery();
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function gate(){return document.getElementById("editPinGate")}
  function body(){return document.getElementById("editPinGateBody")}
  function closeGate(){const e=gate();if(e)e.style.display="none"}
  function showGate(title,html){
    const e=gate(),b=body();if(!e||!b)return false;
    const h=e.querySelector("h2");if(h)h.textContent=title;
    b.innerHTML=html;e.style.display="block";return true;
  }
  function persistSecurity(sec){
    const ps=profiles(),p=active();if(!p)return false;
    p.security=sec;
    const q=ps.find(x=>x.id===p.id);if(q)q.security=sec;
    save(ps);
    localStorage.setItem("money_manager_edit_security_v1",JSON.stringify({pinHash:sec.pinHash||"",recoveryCode:sec.recoveryCode||""}));
    return true;
  }
  function realAdd(){
    closeGate();
    if(typeof addTx!=="function"){alert("Add Transaction function is unavailable. Please reopen the app.");return false;}
    try{return addTx()!==false}catch(e){alert("Add Transaction failed: "+(e&&e.message?e.message:"Unknown error"));return false;}
  }
  function recoveryUI(onSuccess,onCancel){
    const p=active(),s=p&&p.security||{};
    if(!s.recoveryCode){alert("No Recovery Code is available for this profile.");return;}
    showGate("🔐 Forgot PIN",`
      <h3>🔑 Recovery Code</h3>
      <p>Enter the Recovery Code saved when your PIN was created.</p>
      <input id="v19RecoveryCode" type="text" autocomplete="off" placeholder="XXXX-XXXX-XXXX">
      <button type="button" id="v19VerifyRecovery">Verify Recovery Code</button>
      <button type="button" class="secondary" id="v19RecoveryCancel">Cancel</button>`);
    document.getElementById("v19VerifyRecovery").onclick=function(){
      const code=(document.getElementById("v19RecoveryCode")?.value||"").trim().toUpperCase();
      if(code!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return;}
      body().innerHTML=`
        <h3>🔐 Create New PIN</h3>
        <p>Create a new 4–6 digit PIN.</p>
        <input id="v19RecoveryNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="v19RecoveryConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="v19RecoverySave">Save New PIN</button>
        <button type="button" class="secondary" id="v19RecoveryBack">Back</button>`;
      document.getElementById("v19RecoverySave").onclick=function(){
        const a=document.getElementById("v19RecoveryNewPin")?.value||"",b=document.getElementById("v19RecoveryConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return;}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return;}
        s.pinHash=hash(a);s.recoveryCode=s.recoveryCode||recovery();s.editPinLost=false;
        if(!persistSecurity(s))return;
        try{sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
        closeGate();onSuccess();
      };
      document.getElementById("v19RecoveryBack").onclick=function(){recoveryUI(onSuccess,onCancel)};
    };
    document.getElementById("v19RecoveryCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
    setTimeout(()=>document.getElementById("v19RecoveryCode")?.focus(),0);
  }
  function requestPin(onSuccess,onCancel,context){
    const p=active();
    if(!p){alert("Unable to initialize the active profile.");return false;}
    const s=p.security||{};
    if(!s.pinHash){
      showGate(context==="add"?"🔐 Add Transaction":"🔐 Edit Security",`
        <h3>🔐 Create PIN</h3>
        <p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p>
        <input id="v19CommonNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="v19CommonConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="v19CommonCreate">Create PIN</button>
        <button type="button" class="secondary" id="v19CommonCancel">Cancel</button>`);
      document.getElementById("v19CommonCreate").onclick=function(){
        const a=document.getElementById("v19CommonNewPin")?.value||"",b=document.getElementById("v19CommonConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return;}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return;}
        s.pinHash=hash(a);s.recoveryCode=s.recoveryCode||recovery();s.editPinLost=false;
        if(!persistSecurity(s))return;
        body().innerHTML=`<h3>✅ PIN Created</h3><p>Save this Recovery Code safely:</p><div class="v10code">${s.recoveryCode}</div><p class="v10small">This is the same PIN for Edit, Add Transaction and security settings.</p><button type="button" id="v19CreatedContinue">Continue</button>`;
        document.getElementById("v19CreatedContinue").onclick=function(){closeGate();onSuccess()};
      };
      document.getElementById("v19CommonCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
      setTimeout(()=>document.getElementById("v19CommonNewPin")?.focus(),0);
      return false;
    }
    showGate(context==="add"?"🔐 Add Transaction":"🔐 Edit Security",`
      <h3>🔐 Enter PIN</h3>
      <p>Enter your existing profile PIN.</p>
      <input id="v19CommonPin" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">
      <button type="button" id="v19CommonContinue">Continue</button>
      <button type="button" class="secondary" id="v19CommonForgot">Forgot PIN?</button>
      <button type="button" class="secondary" id="v19CommonCancel">Cancel</button>`);
    document.getElementById("v19CommonContinue").onclick=function(){
      const v=document.getElementById("v19CommonPin")?.value||"";
      if(typeof mmV19CheckPin==="function"){
        if(!mmV19CheckPin(v,s.pinHash,hash))return;
      }else if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return;}
      closeGate();onSuccess();
    };
    document.getElementById("v19CommonForgot").onclick=function(){recoveryUI(onSuccess,onCancel)};
    document.getElementById("v19CommonCancel").onclick=function(){closeGate();if(onCancel)onCancel()};
    setTimeout(()=>document.getElementById("v19CommonPin")?.focus(),0);
    return false;
  }

  // Add Transaction: ON => same custom PIN interface as Edit. OFF => direct add.
  window.v109RequestAddTransaction=function(){
    const p=active();if(!p)return false;
    if(!p.security.addProtection)return realAdd();
    return requestPin(realAdd,()=>{},"add");
  };

  // Menu setting: changing ON/OFF requires the same existing profile PIN.
  window.v10ChooseAddTxSecurity=function(desired){
    const p=active();if(!p)return;
    const wanted=!!desired,current=!!p.security.addProtection;
    if(current===wanted){try{v10RefreshAddTxSecurityUI()}catch(e){}return;}
    requestPin(function(){
      const q=active();if(!q)return;
      q.security.addProtection=wanted;
      const ps=profiles(),r=ps.find(x=>x.id===q.id);if(r)r.security=q.security;
      save(ps);try{v10RefreshAddTxSecurityUI()}catch(e){}
      alert(wanted?"Add Transaction PIN is now ON.":"Add Transaction PIN is now OFF.");
    },()=>{try{v10RefreshAddTxSecurityUI()}catch(e){}},"settings");
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};

  // Keep menu and Add button synchronized with the actual saved profile.
  try{if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI()}catch(e){}
})();


/* V23_PROFILE_ISOLATION
   Each Profile/Mode owns its own security state.
   A newly created/switch-to profile is treated as a fresh install:
   - no PIN inherited from another profile
   - no Recovery Code inherited
   - no failed-attempt counter inherited
   - Add Transaction PIN starts OFF
*/
(function(){
  const V23_PREFIX="mm_v23_profile_security_";
  function profileKey(){
    return localStorage.getItem("money_manager_active_profile_v10")
        || localStorage.getItem("activeProfileId")
        || localStorage.getItem("currentProfileId")
        || "";
  }
  function securityKey(id){ return V23_PREFIX + String(id||""); }

  window.mmV23EnsureProfileIsolation=function(){
    const id=profileKey();
    if(!id) return null;
    const key=securityKey(id);
    let s;
    try{s=JSON.parse(localStorage.getItem(key)||"null")}catch(e){s=null}
    if(!s){
      s={
        initialized:true,
        pinHash:null,
        recoveryCode:null,
        addProtection:false,
        failedAttempts:0,
        lockUntil:0
      };
      localStorage.setItem(key,JSON.stringify(s));
    }
    return s;
  };

  window.mmV23GetProfileSecurity=function(){
    return mmV23EnsureProfileIsolation();
  };

  window.mmV23SaveProfileSecurity=function(s){
    const id=profileKey();
    if(!id) return;
    localStorage.setItem(securityKey(id),JSON.stringify(s||{}));
  };

  // Never allow a legacy/global PIN to become the active profile's PIN.
  window.mmV23ClearLegacySecurity=function(){
    const legacy=[
      "mm_global_pin","globalPin","globalPinHash","pinHash",
      "mm_v19_pin_attempts","mm_v19_pin_lock_until"
    ];
    legacy.forEach(k=>{
      try{localStorage.removeItem(k)}catch(e){}
      try{sessionStorage.removeItem(k)}catch(e){}
    });
    mmV23EnsureProfileIsolation();
  };

  // Initialize immediately and whenever storage changes indicate a profile switch.
  mmV23EnsureProfileIsolation();
  window.addEventListener("storage",function(e){
    if(e.key==="money_manager_active_profile_v10" ||
       e.key==="activeProfileId" ||
       e.key==="currentProfileId"){
      mmV23EnsureProfileIsolation();
    }
  });
})();


(function(){
  function hook(name){
    const f=window[name];
    if(typeof f!=="function" || f.__mmV23Hooked) return;
    const w=function(){
      const r=f.apply(this,arguments);
      try{mmV23EnsureProfileIsolation();mmV23ClearLegacySecurity()}catch(e){}
      return r;
    };
    w.__mmV23Hooked=true;
    window[name]=w;
  }
  setTimeout(function(){
    ["switchProfile","switchMode","selectProfile","activateProfile","setActiveProfile","changeProfile","switchProfileMode"].forEach(hook);
  },0);
})();


window.mmV23ProfileIsolationSelfTest=function(){
  const s=mmV23GetProfileSecurity();
  return {
    profileId: localStorage.getItem("money_manager_active_profile_v10")
      || localStorage.getItem("activeProfileId")
      || localStorage.getItem("currentProfileId") || null,
    hasPin: !!s?.pinHash,
    hasRecoveryCode: !!s?.recoveryCode,
    addProtection: !!s?.addProtection,
    failedAttempts: Number(s?.failedAttempts||0),
    lockUntil: Number(s?.lockUntil||0)
  };
};


/* ================================================================
   MF V26 — ANALYTICS VECTOR PDF + MULTI-PAGE HIGH-RES IMAGE EXPORT
   Isolated module: does not replace transaction, backup, restore,
   sign-out, calculator, profile/mode, or analytics calculation logic.
   ================================================================ */
(function(){
  'use strict';
  function tx(){try{if(typeof window.mfActiveProfileTransactions==='function')return window.mfActiveProfileTransactions()||[];if(typeof window.txs!=='undefined'&&Array.isArray(window.txs))return window.txs;if(typeof txs!=='undefined'&&Array.isArray(txs))return txs;return []}catch(e){return[]}}
  function money(v){return 'Rs. '+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function num(v){return Number(v)||0}
  function type(t){return String(t&&t.type||'').toUpperCase()==='CREDIT'?'CREDIT':'EXPENSE'}
  function dateKey(v){let s=String(v||'').trim();let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);if(m)return m[1]+'-'+String(m[2]).padStart(2,'0')+'-'+String(m[3]).padStart(2,'0');return s.slice(0,10)}
  function isoToday(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
  function addDaysKey(s,n){const d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
  function monthKey(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')}
  function monthList(anchor){const [y,m]=anchor.split('-').map(Number),a=[];for(let i=5;i>=0;i--){const d=new Date(y,m-1-i,1);a.push(monthKey(d))}return a}
  function monthTotal(arr,ym){let c=0,e=0;arr.forEach(t=>{if(dateKey(t.date).slice(0,7)!==ym)return;type(t)==='CREDIT'?c+=num(t.amount):e+=num(t.amount)});return {credit:c,expense:e}}
  function catTotals(arr,k){const m=Object.create(null);arr.filter(t=>type(t)===k).forEach(t=>{const c=String(t.category||'Uncategorized');m[c]=(m[c]||0)+num(t.amount)});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
  function pct(v,p){return p===0?'0.0':((v/p)*100).toFixed(1)}
  function change(a,b){if(b===0)return a===0?0:100;return ((a-b)/Math.abs(b))*100}
  function data(){return tx().map(t=>({...t,date:dateKey(t.date)})).filter(t=>t.date&&num(t.amount)>0)}
  function analytics(){
    const all=data(),today=isoToday(),yesterday=addDaysKey(today,-1),credit=all.filter(t=>type(t)==='CREDIT'),expense=all.filter(t=>type(t)==='EXPENSE');
    const totalC=credit.reduce((s,t)=>s+num(t.amount),0),totalE=expense.reduce((s,t)=>s+num(t.amount),0);
    const day=(d)=>all.reduce((o,t)=>{if(t.date===d){type(t)==='CREDIT'?o.credit+=num(t.amount):o.expense+=num(t.amount)}o.net=o.credit-o.expense;return o},{credit:0,expense:0,net:0});
    const td=day(today),yd=day(yesterday),ex=catTotals(all,'EXPENSE'),cr=catTotals(all,'CREDIT');
    const highest=expense.slice().sort((a,b)=>num(b.amount)-num(a.amount))[0]||null;
    let anchor=today.slice(0,7);try{const s=JSON.parse(localStorage.getItem('money_flow_profile_state_v1')||'null');if(s&&/^\d{4}-\d{2}$/.test(s.month))anchor=s.month}catch(e){}
    const months=monthList(anchor),mt=months.map(m=>({m,...monthTotal(all,m)})),top=[...cr.map(x=>({kind:'Credit',name:x[0],value:x[1]})),...ex.map(x=>({kind:'Expense',name:x[0],value:x[1]}))].sort((a,b)=>b.value-a.value).slice(0,8);
    return {all,today,yesterday,td,yd,totalC,totalE,ex,cr,highest,months,mt,top,maxE:ex[0]||null,maxC:cr[0]||null}
  }
  function saveBytes(name,mime,bytes){
    let bin='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)bin+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+chunk,bytes.length)));
    const b64=btoa(bin);if(window.AndroidFile&&typeof window.AndroidFile.saveFile==='function'){window.AndroidFile.saveFile(name,mime,b64);return true}
    const a=document.createElement('a');a.href='data:'+mime+';base64,'+b64;a.download=name;document.body.appendChild(a);a.click();a.remove();return true
  }
  function saveCanvas(canvas,name){return saveBytes(name,'image/png',null||new Uint8Array(atob(canvas.toDataURL('image/png').split(',')[1]).split('').map(c=>c.charCodeAt(0))))}
  function drawImagePage(a,pageIndex,totalPages){
    const S=2,W=1200,H=1700,cv=document.createElement('canvas');cv.width=W*S;cv.height=H*S;const c=cv.getContext('2d');c.scale(S,S);c.fillStyle='#faf8f2';c.fillRect(0,0,W,H);
    const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];
    const text=(s,x,y,size,bold=false,color='#51463a')=>{c.fillStyle=color;c.font=(bold?'700 ':'')+size+'px Arial';c.fillText(String(s),x,y)};
    const box=(x,y,w,h,title,val,sub)=>{c.fillStyle='#fffdf9';c.strokeStyle='#ded8cc';c.lineWidth=2;c.beginPath();c.roundRect(x,y,w,h,18);c.fill();c.stroke();text(title,x+22,y+32,20,true);text(val,x+22,y+70,30,true);text(sub,x+22,y+95,17,false,'#8b8378')};
    text('Money Flow - Analytics',60,62,40,true);text(new Date().toLocaleDateString('en-IN'),60,95,20,false,'#8b8378');text('Part '+(pageIndex+1)+' of '+totalPages,1010,62,18,false,'#8b8378');
    if(pageIndex===0){
      text('Total Overview',60,150,28,true);box(60,180,520,110,'Total Credit',money(a.totalC),'All time income');box(620,180,520,110,'Total Expense',money(a.totalE),'All time expense');
      text('Expense by Category',60,355,28,true);const cx=260,cy=610,r=180,ir=105;let ang=-Math.PI/2;if(a.totalE){a.ex.slice(0,8).forEach((x,i)=>{const da=x[1]/a.totalE*Math.PI*2;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r,ang,ang+da);c.closePath();c.fillStyle=pal[i%pal.length];c.fill();ang+=da})}else{c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.fillStyle='#e8e3d9';c.fill()}c.beginPath();c.arc(cx,cy,ir,0,Math.PI*2);c.fillStyle='#faf8f2';c.fill();text(money(a.totalE),cx-65,cy-5,26,true);text('Total Expense',cx-58,cy+25,17,false,'#8b8378');
      let ly=410;a.ex.slice(0,8).forEach((x,i)=>{c.fillStyle=pal[i%pal.length];c.beginPath();c.arc(555,ly-7,8,0,Math.PI*2);c.fill();text(x[0],580,ly,19);c.textAlign='right';text(money(x[1]),1120,ly,19,true);c.textAlign='left';text(pct(x[1],a.totalE)+'%',1125,ly,17,false,pal[i%pal.length]);ly+=43});
      text('Today vs Yesterday',60,860,28,true);text(a.today+' compared with '+a.yesterday,60,890,17,false,'#8b8378');box(60,920,330,110,'Credit Today',money(a.td.credit),'Yesterday '+money(a.yd.credit)+'  ('+change(a.td.credit,a.yd.credit).toFixed(1)+'%)');box(435,920,330,110,'Expense Today',money(a.td.expense),'Yesterday '+money(a.yd.expense)+'  ('+change(a.td.expense,a.yd.expense).toFixed(1)+'%)');box(810,920,330,110,'Today Net',money(a.td.net),'Yesterday '+money(a.yd.net)+'  ('+change(a.td.net,a.yd.net).toFixed(1)+'%)');
      text('Category summary continues on next page',60,1110,17,false,'#8b8378');
    } else if(pageIndex===1){
      text('Monthly Comparison',60,150,30,true);text('Six-month trend ending '+a.months[a.months.length-1]+' - green = Credit, red = Expense',60,180,17,false,'#8b8378');const max=Math.max(1,...a.mt.flatMap(x=>[x.credit,x.expense]));let y=235;a.mt.forEach(x=>{text(x.m,60,y+8,18,true);c.fillStyle='#ece7dd';c.fillRect(150,y-5,720,16);c.fillStyle='#2fa65b';c.fillRect(150,y-5,720*x.credit/max,16);c.fillStyle='#ece7dd';c.fillRect(150,y+20,720,16);c.fillStyle='#e3483d';c.fillRect(150,y+20,720*x.expense/max,16);text(money(x.credit),900,y+8,17,true,'#2fa65b');text(money(x.expense),900,y+33,17,true,'#e3483d');y+=88});
      text('Highlights',60,800,30,true);
      const hcard=(x,title,item,sub,color)=>{rect(x,835,330,128);txt(x+14,864,9,title,true);if(item){txt(x+14,890,11,String(item.name||'Uncategorized').slice(0,30),true);txt(x+14,920,14,money(item.value),true,color);txt(x+14,945,8,sub,false,'#8b8378')}else{txt(x+14,900,10,'No data available',false,'#8b8378')}};
      hcard(60,'Maximum Expense Category',a.maxE?{name:a.maxE[0],value:a.maxE[1]}:null,'Highest expense category',[.89,.28,.24]);
      hcard(435,'Maximum Credit Category',a.maxC?{name:a.maxC[0],value:a.maxC[1]}:null,'Highest income category',[.16,.65,.36]);
      hcard(810,'Highest Single Expense',a.highest?{name:a.highest.category||'Uncategorized',value:a.highest.amount}:null,a.highest?'Date '+a.highest.date:'',[.89,.28,.24]);
      text('Monthly lanes are separate: Credit and Expense',60,1015,18,false,'#8b8378');
    } else {
      text('Highest Single Expense - Details',60,150,30,true);if(a.highest){box(60,185,1080,135,'Amount',money(a.highest.amount),'Category: '+(a.highest.category||'Uncategorized'));text('Date: '+(a.highest.date||'-'),85,355,19);text('Payment Mode: '+(a.highest.mode||a.highest.paymentMode||'-'),85,390,19);text('Description: '+(a.highest.description||a.highest.desc||'-'),85,425,19);text('Remark: '+(a.highest.remark||a.highest.remarks||a.highest.note||'-'),85,460,19);text('Other: '+(a.highest.other||a.highest.otherInfo||a.highest.other_info||'-'),85,495,19)}else text('No expense data available.',60,220,20);
      text('Category Ranking',60,580,30,true);const rm=Math.max(1,...a.top.map(x=>x.value));let y=630;a.top.forEach((x,i)=>{text((i+1)+'. '+x.kind+' - '+x.name,60,y,18,true);c.fillStyle=x.kind==='Credit'?'#2fa65b':'#e3483d';c.fillRect(360,y-16,600*x.value/rm,18);text(money(x.value),980,y,18,true);y+=55});
    }
    return cv;
  }
  window.pfExportAnalyticsImage=function(){try{const a=analytics(),stamp=Date.now(),parts=3;for(let i=0;i<parts;i++){const cv=drawImagePage(a,i,parts);saveCanvas(cv,'money_flow_analytics_part_'+(i+1)+'_'+stamp+'.png')}alert('Analytics saved as 3 high-resolution PNG images covering the full scroll.');return true}catch(e){alert('Export Image failed: '+(e&&e.message?e.message:'Unknown error'));return false}};

  function pdfEsc(s){return String(s==null?'':s).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)').replace(/[^\x20-\x7E]/g,'?')}
  function makePdf(a){
    const W=595,H=842,M=36,objs=[],add=o=>{objs.push(o);return objs.length},font=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'),pages=[];
    const esc=pdfEsc;
    function pageContent(pi){let s='q\n';const txt=(x,y,size,str,bold=false,color=[0.318,0.275,0.227])=>{s+=color[0]+' '+color[1]+' '+color[2]+' rg\nBT\n/F1 '+size+' Tf\n1 0 0 1 '+x+' '+y+' Tm ('+esc(str)+') Tj\nET\n'};const rect=(x,y,w,h,fill=[1,.992,.976],stroke=[.87,.847,.8])=>{s+=fill.join(' ')+' rg\n'+stroke.join(' ')+' RG\n1 w\n'+x+' '+y+' '+w+' '+h+' re B\n'};const line=(x1,y1,x2,y2,color=[.87,.847,.8])=>{s+=color.join(' ')+' RG\n1 w\n'+x1+' '+y1+' m '+x2+' '+y2+' l S\n'};const bar=(x,y,w,h,frac,color)=>{s+=color.join(' ')+' rg\n'+x+' '+y+' '+Math.max(0,w*frac)+' '+h+' re f\n'};const moneyP=v=>money(v);
      txt(M,H-50,22,'Money Flow - Analytics',true);txt(500,H-50,9,'Page '+(pi+1)+' / 3');
      if(pi===0){txt(M,H-115,16,'Total Overview',true);rect(M,H-240,250,90);rect(309,H-240,250,90);txt(50,H-180,10,'Total Credit',true);txt(50,H-205,18,moneyP(a.totalC),true,[.16,.65,.36]);txt(50,H-225,8,'All time income');txt(323,H-180,10,'Total Expense',true);txt(323,H-205,18,moneyP(a.totalE),true,[.89,.28,.24]);txt(323,H-225,8,'All time expense');
        /* Keep the expense chart completely below the overview cards and keep its legend adjacent to the chart. */
        txt(M,H-275,15,'Expense by Category',true);let cy=H-392,cx=145,r=82,ir=49,ang=-Math.PI/2;const pal=[[.15,.54,.9],[.16,.65,.36],[.89,.28,.24],[.70,.59,.35],[.49,.46,.33],[.56,.42,.71],[.82,.55,.27],[.35,.55,.62]];if(a.totalE){a.ex.slice(0,8).forEach((x,i)=>{const da=x[1]/a.totalE*Math.PI*2,pts=[[cx,cy]];for(let k=0;k<=24;k++){const q=ang+da*k/24;pts.push([cx+r*Math.cos(q),cy+r*Math.sin(q)])}s+=pal[i%pal.length].join(' ')+' rg\n'+pts[0][0]+' '+pts[0][1]+' m '+pts.slice(1).map(p=>p[0]+' '+p[1]+' l').join(' ')+' h f\n';ang+=da})}else{const pts=[];for(let k=0;k<=48;k++){const q=2*Math.PI*k/48;pts.push([cx+r*Math.cos(q),cy+r*Math.sin(q)])}s+='0.91 0.89 0.85 rg\n'+pts[0][0]+' '+pts[0][1]+' m '+pts.slice(1).map(p=>p[0]+' '+p[1]+' l').join(' ')+' h f\n'}{const hole=[];for(let k=0;k<=48;k++){const q=2*Math.PI*k/48;hole.push([cx+ir*Math.cos(q),cy+ir*Math.sin(q)])}s+='0.98 0.97 0.95 rg\n'+hole[0][0]+' '+hole[0][1]+' m '+hole.slice(1).map(p=>p[0]+' '+p[1]+' l').join(' ')+' h f\n';}txt(112,cy+5,11,moneyP(a.totalE),true);txt(103,cy-13,7,'Total Expense');
        let ly=cy+48;a.ex.slice(0,8).forEach((x,i)=>{s+=pal[i%pal.length].join(' ')+' rg\n320 '+ly+' 6 6 re f\n';txt(332,ly+1,8,String(x[0]).slice(0,24));txt(500,ly+1,7,moneyP(x[1]),true);txt(505,ly-11,6,pct(x[1],a.totalE)+'%',false,pal[i%pal.length]);ly-=38});
        txt(M,H-625,15,'Today vs Yesterday',true);txt(M,H-645,8,a.today+' compared with '+a.yesterday);const boxes=[['Credit Today',a.td.credit,a.yd.credit,[.16,.65,.36]],['Expense Today',a.td.expense,a.yd.expense,[.89,.28,.24]],['Today Net',a.td.net,a.yd.net,[.2,.45,.7]]];boxes.forEach((b,i)=>{const x=M+i*174;rect(x,H-790,160,105);txt(x+12,H-720,9,b[0],true);txt(x+12,H-750,15,moneyP(b[1]),true,b[3]);txt(x+12,H-775,7,'Yesterday '+moneyP(b[2])+' ('+change(b[1],b[2]).toFixed(1)+'%)')});
      } else if(pi===1){txt(M,H-115,16,'Monthly Comparison',true);txt(M,H-132,8,'Six-month trend ending '+a.months[a.months.length-1]+' - green Credit, red Expense');const max=Math.max(1,...a.mt.flatMap(x=>[x.credit,x.expense]));let y=H-175;a.mt.forEach(x=>{txt(M,y+3,9,x.m,true);s+='0.92 0.90 0.86 rg\n90 '+y+' 360 9 re f\n0.92 0.90 0.86 rg\n90 '+(y-18)+' 360 9 re f\n';bar(90,y,360,9,x.credit/max,[0.16,.65,.36]);bar(90,y-18,360,9,x.expense/max,[.89,.28,.24]);txt(458,y+3,7,moneyP(x.credit),true,[.16,.65,.36]);txt(458,y-15,7,moneyP(x.expense),true,[.89,.28,.24]);y-=82});txt(M,H-680,15,'Highlights',true);const hcardP=(x,title,name,value,sub,color)=>{rect(x,H-790,160,96);txt(x+10,H-720,7,title,true);const nm=String(name||'Uncategorized');txt(x+10,H-744,8,nm.slice(0,24),true);if(nm.length>24)txt(x+10,H-733,8,nm.slice(24,48),true);txt(x+10,H-765,10,value,true,color);txt(x+10,H-782,6,sub||'No data',false,[.55,.51,.47])};hcardP(M,'Maximum Expense Category',a.maxE?a.maxE[0]:'No data',a.maxE?moneyP(a.maxE[1]):'-','Highest expense category',[.89,.28,.24]);hcardP(M+174,'Maximum Credit Category',a.maxC?a.maxC[0]:'No data',a.maxC?moneyP(a.maxC[1]):'-','Highest income category',[.16,.65,.36]);hcardP(M+348,'Highest Single Expense',a.highest?(a.highest.category||'Uncategorized'):'No data',a.highest?moneyP(a.highest.amount):'-',a.highest?'Date '+a.highest.date:'No expense data',[.89,.28,.24]);
      } else {txt(M,H-115,16,'Highest Single Expense - Details',true);if(a.highest){rect(M,H-245,523,105);txt(M+12,H-175,10,'Amount',true);txt(M+12,H-205,20,moneyP(a.highest.amount),true,[.89,.28,.24]);txt(M+270,H-175,9,'Category',true);txt(M+270,H-205,12,a.highest.category||'Uncategorized',true);txt(M+12,H-225,8,'Date: '+(a.highest.date||'-')+'   Payment Mode: '+(a.highest.mode||a.highest.paymentMode||'-'))}else txt(M,H-155,10,'No expense data available.');txt(M,H-285,8,'Description: '+(a.highest?.description||a.highest?.desc||'-'));txt(M,H-305,8,'Remark: '+(a.highest?.remark||a.highest?.remarks||a.highest?.note||'-'));txt(M,H-325,8,'Other: '+(a.highest?.other||a.highest?.otherInfo||a.highest?.other_info||'-'));txt(M,H-370,16,'Category Ranking',true);const rm=Math.max(1,...a.top.map(x=>x.value));let y=H-400;a.top.forEach((x,i)=>{txt(M,y,8,(i+1)+'. '+x.kind+' - '+x.name,true);bar(250,y-7,230,9,x.value/rm,x.kind==='Credit'?[.16,.65,.36]:[.89,.28,.24]);txt(490,y,8,moneyP(x.value),true);y-=38});}
      s+='Q';return s}
    for(let i=0;i<3;i++){const s=pageContent(i);const cid=add('<< /Length '+s.length+' >>\nstream\n'+s+'\nendstream');pages.push(cid)}
    const pagesId=add('PAGES'),kids=pages.map(cid=>add('<< /Type /Page /Parent '+pagesId+' 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 '+font+' 0 R >> >> /Contents '+cid+' 0 R >>'));objs[pagesId-1]='<< /Type /Pages /Kids ['+kids.map(x=>x+' 0 R').join(' ')+'] /Count 3 >>';const cat=add('<< /Type /Catalog /Pages '+pagesId+' 0 R >>');let pdf='%PDF-1.4\n',offs=[0];objs.forEach((o,i)=>{offs[i+1]=pdf.length;pdf+=(i+1)+' 0 obj\n'+o+'\nendobj\n'});const xr=pdf.length;pdf+='xref\n0 '+(objs.length+1)+'\n0000000000 65535 f \n';for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,'0')+' 00000 n \n';pdf+='trailer\n<< /Size '+(objs.length+1)+' /Root '+cat+' 0 R >>\nstartxref\n'+xr+'\n%%EOF';return new TextEncoder().encode(pdf)
  }
  window.pfExportAnalyticsPDF=function(){try{const a=analytics(),bytes=makePdf(a);saveBytes('money_flow_analytics_'+a.today+'.pdf','application/pdf',bytes);alert('Analytics PDF successfully saved to device.');return true}catch(e){alert('Export PDF failed: '+(e&&e.message?e.message:'Unknown error'));return false}};
  function installButtons(){const host=document.getElementById('pfAnalyticsBody');if(!host)return;const old=host.querySelector('.mf15-export');if(!old)return;if(host.querySelector('.mf26-export-row'))return;const row=document.createElement('div');row.className='mf26-export-row';row.style.cssText='display:flex;gap:10px;flex-wrap:wrap;margin-top:12px';const img=document.createElement('button');img.type='button';img.className='mf15-export';img.textContent='▣ Save Images · 3 HD Parts';img.onclick=window.pfExportAnalyticsImage;const pdf=document.createElement('button');pdf.type='button';pdf.className='mf15-export';pdf.textContent='▤ Export PDF';pdf.onclick=window.pfExportAnalyticsPDF;old.remove();row.appendChild(img);row.appendChild(pdf);host.appendChild(row)}
  const obs=new MutationObserver(installButtons);function boot(){const host=document.getElementById('pfAnalyticsBody');if(host)obs.observe(host,{childList:true,subtree:true});installButtons()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();setTimeout(boot,300);setTimeout(boot,1000);
})();




/* V31 ANALYTICS PDF EXPORT FIX
   - Fixes vector PDF export crash caused by incorrect bar() arguments.
   - Keeps highlight amount visible and prevents category text from colliding with amount.
*/

/* V30.1 FINAL PATCH
   - Excel: header cells remain text; only data Amount/Balance cells are numeric.
   - PDF: use ASCII-safe "Rs." so Android PDF viewers never show â‚¹/garbled ₹.
   - Biometric/Fingerprint: optional WebAuthn platform authenticator. When ON,
     security gates attempt biometric first; if unavailable/cancelled, PIN is shown.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  const b64u = bytes => {
    let s=""; for(const b of bytes)s+=String.fromCharCode(b);
    return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
  };
  const fromB64u = s => {
    s=String(s||"").replace(/-/g,"+").replace(/_/g,"/");
    while(s.length%4)s+="=";
    const raw=atob(s), a=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i);
    return a;
  };
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function active(){const a=profiles(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function sec(){const p=active(); if(!p)return null; p.security=p.security||{}; if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false; return p.security}
  function persist(){const a=profiles(),p=active();if(!p)return;const i=a.findIndex(x=>x.id===p.id);if(i>=0){a[i]=p;save(a)}}
  function randomBytes(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a}
  function canBio(){return !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create && navigator.credentials.get && window.isSecureContext)}
  async function registerBio(){
    if(!canBio()) throw new Error("Biometric is not available in this local/browser environment.");
    const p=active(); if(!p) throw new Error("Profile is not ready.");
    const challenge=randomBytes(32), userId=randomBytes(16);
    const cred=await navigator.credentials.create({publicKey:{
      challenge,
      rp:{name:"Money Manager"},
      user:{id:userId,name:p.id,displayName:p.name||"My Money"},
      pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],
      authenticatorSelection:{authenticatorAttachment:"platform",userVerification:"required",residentKey:"preferred"},
      timeout:60000,
      attestation:"none"
    }});
    if(!cred) throw new Error("Biometric setup was cancelled.");
    p.security=p.security||{};
    p.security.bioEnabled=true;
    p.security.bioCredentialId=b64u(new Uint8Array(cred.rawId));
    persist();
    return true;
  }
  async function verifyBio(){
    const s=sec();
    if(!s||!s.bioEnabled||!s.bioCredentialId) return false;
    if(!canBio()) return false;
    const challenge=randomBytes(32);
    try{
      const cred=await navigator.credentials.get({publicKey:{
        challenge,
        allowCredentials:[{type:"public-key",id:fromB64u(s.bioCredentialId)}],
        userVerification:"required",timeout:60000
      }});
      return !!cred;
    }catch(e){return false}
  }
  function addBioMenu(){
    const panel=document.getElementById("menuPanel"); if(!panel||document.getElementById("v30BioMenuItem"))return;
    const b=document.createElement("button"); b.id="v30BioMenuItem"; b.className="menuItem"; b.type="button";
    b.textContent="🔐 Fingerprint / Biometric"; b.onclick=window.v30OpenBiometricSettings;
    const close=[...panel.querySelectorAll("button")].find(x=>x.textContent.includes("Close"));
    if(close)panel.insertBefore(b,close); else panel.appendChild(b);
  }
  function refreshBioText(){
    const s=sec(), item=document.getElementById("v30BioMenuItem");
    if(item)item.textContent=(s&&s.bioEnabled)?"🔐 Fingerprint / Biometric: ON":"🔐 Fingerprint / Biometric: OFF";
  }
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();
    let m=document.getElementById("v30BioModal");
    if(!m){
      m=document.createElement("div");m.id="v30BioModal";m.className="v10modal";
      m.innerHTML='<div class="v10box"><h2>🔐 Fingerprint / Biometric</h2><p id="v30BioStatus" class="v10small"></p><button type="button" id="v30BioEnable">Turn ON / Register Fingerprint</button><button type="button" class="danger" id="v30BioDisable">Turn OFF</button><button type="button" class="secondary" id="v30BioClose">Close</button></div>';
      document.body.appendChild(m);
      document.getElementById("v30BioEnable").onclick=async function(){
        try{await registerBio();refreshBioText();updateBioStatus();alert("Fingerprint / biometric is ON. The biometric prompt will appear directly when security is required.");}
        catch(e){alert(e&&e.message?e.message:"Fingerprint setup failed. PIN security remains available.");}
      };
      document.getElementById("v30BioDisable").onclick=function(){const s=sec();if(s){s.bioEnabled=false;s.bioCredentialId="";persist();refreshBioText();updateBioStatus();}};
      document.getElementById("v30BioClose").onclick=function(){m.style.display="none"};
    }
    function updateBioStatus(){const s=sec();const e=document.getElementById("v30BioStatus");if(e)e.textContent=(s&&s.bioEnabled)?"ON — biometric will be requested first; if unavailable/cancelled, PIN is shown.":"OFF — PIN is used normally."}
    updateBioStatus();m.style.display="block";
  };
  // Preserve the existing unified PIN gate and put biometric first when enabled.
  const originalAsk=window.v26AskPin;
  if(typeof originalAsk==="function"){
    window.v26AskPin=async function(ok,cancel){
      const s=sec();
      if(s&&s.bioEnabled&&s.bioCredentialId){
        const success=await verifyBio();
        if(success){if(typeof ok==="function")ok();return false;}
        // biometric unavailable/cancelled -> continue to the normal PIN UI.
      }
      return originalAsk(ok,cancel);
    };
  }
  // Install menu item after the page has loaded; repeat once after current UI setup.
  function boot(){addBioMenu();refreshBioText()}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,300);
})();



/* V35 — DEFINITIVE SELECTED-DATE EXPORT FIX
   The export source is the same live transaction array used by the dashboard.
   The selected From/To values are read directly from the date inputs at the
   moment Export is pressed. No stale filtered array/profile copy is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function normDate(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return "";
  }
  function rawTx(){
    try{if(Array.isArray(txs)&&txs.length)return txs.slice()}catch(e){}
    try{
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x&&String(x.id)===String(id))||ps[0];
      if(p&&Array.isArray(p.transactions))return p.transactions.slice();
    }catch(e){}
    return [];
  }
  function normalize(t){
    return {
      id:t&&t.id,
      date:normDate(t&&t.date),
      type:text(t&&t.type).toUpperCase(),
      amount:Number(t&&t.amount)||0,
      balance:(t&&t.balance!==undefined&&Number.isFinite(Number(t.balance)))?Number(t.balance):null,
      category:text(t&&t.category),description:text(t&&(t.description||t.desc)),
      remark:text(t&&(t.remark||t.remarks||t.note)),mode:text(t&&(t.mode||t.paymentMode||t.payment_mode)),
      other:text(t&&(t.other||t.otherInfo||t.other_info)),createdAt:text(t&&t.createdAt)
    };
  }
  function allTx(){
    return rawTx().map(normalize).filter(t=>t.date&&t.amount>0&&(t.type==="CREDIT"||t.type==="EXPENSE"||t.type==="DEBIT"))
      .sort((a,b)=>a.date.localeCompare(b.date)||a.createdAt.localeCompare(b.createdAt));
  }
  function range(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=normDate(f&&f.value),to=normDate(t&&t.value);
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function pack(){
    const r=range(); if(!r)return null;
    const all=allTx();
    const data=all.filter(t=>t.date>=r.from&&t.date<=r.to);
    // Opening balance is the balance of the last transaction strictly before From Date.
    let opening=0;
    const before=all.filter(t=>t.date<r.from);
    if(before.length){
      const last=before[before.length-1];
      if(last.balance!==null) opening=last.balance;
      else {for(const q of before) opening += q.type==="CREDIT"?q.amount:-q.amount;}
    }
    return {all,data,from:r.from,to:r.to,opening};
  }
  function calc(p){
    let b=p.opening,w=0,d=0;
    const rows=p.data.map(t=>{
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount}
      else {w+=t.amount;b-=t.amount}
      return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.type==="CREDIT"?"":t.amount,t.type==="CREDIT"?t.amount:"",b];
    });
    return {rows,w,d,b};
  }
  function xmlEsc(v){return text(v).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}
  function xText(v){return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`}
  function xNum(v){return `<c><v>${Number(v)||0}</v></c>`}
  function makeXlsx(p){
    const c=calc(p);
    const rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    rows.push(...c.rows); rows.push([]); rows.push(["ACCOUNT SUMMARY"]);
    rows.push(["OPENING BALANCE",p.opening,"TOTAL WITHDRAWALS",c.w,"TOTAL DEPOSITS",c.d,"CLOSING BALANCE",c.b,"No. of Transactions",p.data.length]);
    rows.push([]); rows.push(["******************* END OF REPORT *******************"]);
    const body=rows.map((r,ri)=>`<row>${r.map((v,i)=>{
      const num=(ri>0&&ri<=p.data.length&&i>=6&&i<=8)||(ri===p.data.length+2&&typeof v==="number");
      return num?xNum(v):xText(v);
    }).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
    const wb=`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rel=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const root=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const ct=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function pdfBlob(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=v=>text(v).replace(/[^\x20-\x7E]/g,"?");
    const esc=v=>pdfEscape(safe(v));
    const wrap=(v,w)=>{v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";for(const q0 of v.split(/\s+/)){let q=q0;if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}}if(cur)a.push(cur);return a.length?a:[""]};
    const prep=c.rows.map(r=>{const vals=[r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)];const cells=vals.map((v,i)=>wrap(v,colW[i]));return {cells,h:Math.max(18,Math.max(...cells.map(a=>a.length))*lh+4)}});
    const pages=[];let pg=[],y=86;for(const r of prep){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h}if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=o=>{objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach((page,pi)=>{let s=`q\nBT\n/F1 10 Tf\n1 0 0 1 ${M} 567 Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n/F1 8 Tf\n1 0 0 1 ${M} 555 Tm (${esc("Period: "+p.from+" to "+p.to)}) Tj\nET\n`,yy=540;
      const cell=(x,y,w,h,vals,bold)=>{s+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fs} Tf\n`;vals.forEach((v,i)=>s+=`1 0 0 1 ${x+2.5} ${y-2.5-7-i*lh} Tm (${esc(v)}) Tj\n`);s+="ET\n"};
      let x=M;heads.forEach((h,i)=>{cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;
      page.forEach(r=>{x=M;r.cells.forEach((cc,i)=>{cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (ACCOUNT SUMMARY) Tj\nET\n`;yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[p.opening.toFixed(2),c.w.toFixed(2),c.d.toFixed(2),c.b.toFixed(2),String(p.data.length)];x=M;labs.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (******************* END OF REPORT *******************) Tj\nET\n`}
      s+="Q";cids.push(add(`<< /Length ${s.length} >>\nstream\n${s}\nendstream`));pids.push(null)
    });
    const pagesId=add("PAGES");pages.forEach((_,i)=>pids[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${cids[i]} 0 R >>`));objs[pagesId-1]=`<< /Type /Pages /Kids [${pids.map(x=>x+" 0 R").join(" ")}] /Count ${pids.length} >>`;const cat=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);let pdf="%PDF-1.4\n",offs=[0];objs.forEach((o,i)=>{offs[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xr=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${cat} 0 R >>\nstartxref\n${xr}\n%%EOF`;return new Blob([pdf],{type:"application/pdf"});
  }
  window.filteredTransactions=function(){const p=pack();return p?p.data:null};
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${p.from}_to_${p.to}.xlsx`)};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(pdfBlob(p),`money_transactions_${p.from}_to_${p.to}.pdf`)};
})();



(function(){
  const PROFILE_KEY="money_manager_profiles_v10", ACTIVE_KEY="money_manager_active_profile_v10";
  function profiles(){try{const x=JSON.parse(localStorage.getItem(PROFILE_KEY)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
  function active(){const a=profiles(),id=localStorage.getItem(ACTIVE_KEY);return a.find(p=>p.id===id)||a[0]||null}
  function save(a){localStorage.setItem(PROFILE_KEY,JSON.stringify(a))}
  function validPhoto(src){
    return typeof src==="string" && (src.indexOf("data:image/")===0 || src.indexOf("blob:")===0);
  }
  const DEFAULT_PROFILE_IMAGE="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdsAAAHbCAYAAACDejA0AAEAAElEQVR4nMz9d8Atx1EnDP+qZ8558o3SVQ6WZCs7ybZkSc44gzHGZLPsLuy7vMuy8BGWDAYWWGCBXb4N7MIuYMDggLMk2wqWLVvRilbOOV7d/IRzzkzX90en6p7uOeeRzft+Y+s+c2Y6VHdX16+qurqHJpMxAwBAAAD2d/HF4p6YMykAFs+JyJfKFEpk9y8D5GviqFJZPFFCjXvpy+eINndPLO4T+t0zk97SYstjZlF2WgZ3CmLRbiJK6mLkuoqIojzMHNc/4yV6r/MsU2lCOGef5+onZMbv/+Erbde3ngLyXRH3AXW6ztPgxlBS1yFUcFBpcFhyTP/74jjm3s14fav6Np2rm+Hl//++qDx0L7y3ouHKz7u0LuSFWfKYCOCEZmY2vzs8YmQUWXqE+AuFpeVI+VgADIobF7chQ3uSOZOqfEW4kyuH43FK8Yt9exI5R+aOOGCjrIQidIhSIEdRLarsDNCmryCtpiW0aChGijFjJ4c6DLUkHnfB0BUdVQ2yDxkEBRBDawd+pmx2JNmHTqw6xYC1qFown0/FnHR4HlAd874QwZRTJnK8b5pamMxs25PrN2Y7cV2ZoaaYzdyExaYmSlkAxJPaqVTfDG92hEjnpewDjtKzUMYkff4i8ZuFAuVLs/8mfRwJwyJpqXYX/86NdfTMDYxUPnvG6JuBx1hpfMGFRKDRaWFBSQTKhsI3R4NXs1P46q+NGUwZeWrLdsAmJ2/M8wVjIau8x/3NVrbJPiL5MlLwCcryr+Rzf5+kd/3h+MmVwQh85sWrfdMhMO0SfJPj5oSU7BwBtFMvQXOXjrgPo2p6iM4aQuPJJMGifElRokLH9VpVnNhEHQ09X5DUQvxjgQC+8RZs/VwUxZIHS07Gg8AWZCOLNhKeYXLnlMrYuilrcCmgRiBLZNqZWLxR+URZyzrqnCmMlZY97XJ9loqMabwwa/lB8OSBbOZyclfC7SUZ3afkzF7/DJ3/Aq6SkvStuHoB91vR/y/gylp3KW8knqg07zdL8yw0bKacXN4UVHPpO4q5lRF+vmxy7qTC3wOpt2jzApiIvDIZW7QxsJFE2k55oUySMpLFb6lkpEpC3j3YfU4IKnnqnYp+e8vA/QrpPA1SE6Ls9E5pT72scdkdsJXWw7cIbAVjdFJHiqLQKwpgG4pMOykBr4ieUE/EADlmyDGJA2Fn5XGhTPGny7yCbjGG3pdAkv5y/pKG2O++6wGCnOYty4kL7Um5yStTbz+wzAZm0wFkdlAsleWVo1I9rpakuj55vVlQfSFLDiZjECcz1TmFP9yVKytSjDvphdI4ZUi6YJsWFo/H5hWUF6oodZcX8nWXlyFMnq4B0EcaR/Io8YhlLWlEcs3JHPIA2aUndgHD800QP44GkUDSLJ6UILdjFUkaZgBbdn3QeZ6pFLCuYPeCC3wZlAkQd56LBzadYGISL7pJTarxeMIS9/rEnUkQCE2ZqzjBcp3l0gsNw71gMWBFf7xL7gfdZhYaoMkTg2hange5tFxpUTLHbcjMssDM3SRSW3WAqhQh1WJf6PVC18ooJTS5poFtdjxeYL3fivW9Way1qWWYgqaWU0xnlaikxH6BOyttpUKyvMnu/2V6O7SKYnLpS1dGmY5yfov5M0z3MEe7JH0LlcPCNUu95THL931fv/e1KY37kPIu/R3XR7Hyn6nbg3KWLBLjEMGDa2Yo078j8V7yrqgv9YR2a81eXZklATRXkKQlFBBZ4K4ER583rKaDraySxuMxzzKpioJ1FrDNuD8TfSjkScG2VIekwfakB88kjc6BvZioqVY86zSVyplnMiIoZUpUSol1jlB2ynBxY/KvNpXmm726WNGTNkPQN0nbP4Ubs1hmyb+8ictbi8J6yNY1y/VPML6dQK4+LemflK86sz5cnYmdCrLSe0xJly9/JndxKa+VZ/0g1HNlBczm+LBDf2rVOgD1nrcYPLTWUTkmZoUFaAtjADEoBlDN05pbUguGhrGs+6A0uLg3CbbOaOq0mXI2XdJnTjmN0CD+5fqjCLZdiiWdNTmkSJL2Bu34SmM1JnQPSyvca2uyIyLElyQKeljkBZAdAMcOjBhoi7QLMAcla6ROC0wI67qnTecqZVwxEahKzMm4ebzA6ZE7/29eHcH8T0jn/1trg9/qq3ctPUr4zQP7t6SczYzpt4hmzsz72TMXf8TPgyb7rblizCiTsIn+zEawv4CrI1tyJqVIK36AYAwBSRMzg7VGK2JYTPnx2rAMpArryaG+3O4KUt1YFEKyU0P0YW90cQ6EBT5kDbie9GlFAVxlo2JKvDHos8vg4nhcmcOTusxR8ZXlp5wFW8jrQSZZd4zAFAWQlBOeOabYupFLIBsxitXcHIAKArz169I7DUwzg1mDKICqssBKymqABbdIFBAFE0JutLq8u6Z45YaoMMHDmtz0MZX90u8HLF1d1V9MpehNOq+yLkCh3MhnxHliyi5QsvpMGQTJaf7fCuEsZV4fGPiKp5dTTtNNVAoA7KSf0tQ8H3sTqUN7ie+zZUfrcCKUxGXr8LNj+n8abS8FhXLC3KPMwxnIjGSDEM9xom4/F0lL5GaOhCDnEiBOjAIiApRCZctxYKu1Nr+12H7RNfUjOghBfrqdH6n3xxfDCT+UGxv+JgYMpeXOUk6a3ilq7H8goL94VSq297mVdZPJJFIxulYjOu+KwSN2ssfiPpmgGbCNLElYCzNHA8XvZJms3cS0tPRp5JkyZICV1NqUUgFkhTY4i8bfXR+R8JSdxbHmS918adnSlZUFWhYj0bMek2X2pOK0Thfu321LFIaTx4AMTbLNPk1B+512TQsiSgVV8coyonhdsM5nqbdTTyrDBI9R/CLDdxmdPMejifbjhKJ/l1G65Dj00u9vxfxOAbrkMZtSbwrE1DcuqRyl6ZsaJV29IOxshpkUDVeeoFvQnJO1vs3pmE+5chaz37CUFESOplkrYIZmsz3SgC97L2JuHnkbT85tCVaCz+SaMTw0pP3fZUz5tohZBdkf/eymgCTJ8FoeH2X5xbMnfBKS+2ynX3KeUnQD0XmpVpwQ19dYDk+yfFBYT2Vrq3uTnWyQFKVDYsE6sZQhBLPT8qqq8uAq11xzV14z60qP7vEb3QlLEVcKxgWQCrG0zs7vGdy0HboFWQQyIfASsAXNjgZntXtCwzRHSR8sihI3TDmEFpNy2uV4Ii/cKSoml8aPqR/6zHYNZIR4n/qbtMVZAFOSFR6mHZEIBCuw43wlK8B3eufqeor625zjwZkUm7Q/XPNKUrXnkltjfOHi3SxWUJHNMspl2TKTSkzi4vSyKs1BVkwFueTmURnSu3PT00XdPcK++T1zKXLlEqBIwYjDKoAua7/2a9LFPMQs509J8YLtGzfYOpRDfX075fJeu9DWbhhs4UqUHYlmZYlWJCTcma0/otdz/vKs1u4YKUzUbgSXKYUE1V3hzl0tTmSIWFRqGCV3Govm5Pz7jgHcnLZtIUWoVGX+VpV/5zWtpC5GHsQ6IOFnFMfu0BJglEYyp6T1FPOCroKO1CGFy0Av3fPh8JCkmsxaj8xbUKmSfu0Ba1c2hOacLa48bdJJVbRUZeEU5/Lcl0zenhLQR1WEOyzTJtaL6yrR9Jkt+b7LLwVNS4Pi+JSs9Y6bMVW4Cv3X7T37b2cOZmgpvIqBJgZqzzc9k2+q1RvRFgrKutcTGqREy3nB0nI6sSaiTG/JFyz/vshqZ6dobQC3bdtAYARUscfQ0eHtF1GWLDdYvGFOJWiQpUu6iVk+830Fjzmm7aJyqeBkLXZE4x5tUSp5h0WaevMSuzxRy5qXrTj3smh1BabzSeygRWuhYhCjaFCHqcmk44RQVVWoqiqsWyCALJEN1C5t3sqSnaRNK5x2ueypWpWvDLJXX7AW6Cr1E8AqIL054rqKdfd0XcdKYtjN5AUae32HuXrkjE6T9ffTC+1FiH6YbVrJXugH/9xTyr2cgoezWnfpFY616y28t4xorkYgMgWUcmWVtahMQZsZjbQeSQ7HDwtlOPr65qSRU6mbN54wXmGlkCtOTdn7UppOmYzNa+0Cn5wHsKoqD7qsOSh7ArxilaEzIc0tO94AFJQ3VsIs4eDB7MzvALTRxZuZj+nFfgxTBTZONf0y+2xjNSrcRqVJ5PZmA8gyjPltWu3bziFHp8SE4ojYnEblNBU7SYOw4Oz8SjW64GpmEClUlfIWbBAAjv+S0qisQXddarEQ6TTQd50Tr5JO0XQSE7+r7EZl+N+UUN8DdIY3u9pbek8JP0Qbv52WL+spaNjR1YOnnXKIsushfczthIl0A8seT/P3utstM6eBHTlXar9lnrkiV2FCT3Z9HXleoOR+xupnDdLrteo9EsXhPzEjWKLiThdDnfBY1AYHbiJN7CqLk8ZCy1WV0J1UlnaDKLBrVTryOeKDaF0bOVoDX6R5XeFpLERUIWXmU/I+e0Vs28+fJXd0b/mZS2uNtmnhA1IRWMDcB/xw3SYVQOdByPWdKyxmeZFOHIqf7pYJZU1vVlAsDb5JHqPowItAU+7yaMjY3JptUkpKXveV62D/dxYVKiNYbURcqTkxSiXCgeHXLRQR6ro2AU9ygNh0SlgfjQd5Vo3RkVO8BNDmGD6azOBOPwZ+7XHBRVK7hxbLADma++et+DeSeZYyK7x612QzpJTeka9ICM5iH4vVLVlm35gUgmF8jdkhTh+S9VRxb11RM0uW5TSLk+w/kfIreFSyfqFts76XVabY1+lf4Y5z80m69OKK43LjOWbH0AtNJ5E5FrLpElG227qM1Wltb/OlAIsBIeVxudYa+yoy8iMzPyIXdaE9riwP2um4F5WGDNBm0s7iGSPk9siGGFsiQqUUqmEFzcbSbdtWnD0f+tTBQS6gKm23jKdJKYpuS9PK8meUOxND1K3b/CvbLV3evbotuzoMbSYaOcF67tzFJUbuJLmOUwx+kBpcSatyJcbv5absYDlk3nfujQbCDO/mcJZspxCgqwhk1J9p7rfZxJYrXrCsXHsRVUf9T/6fDo05i2pqBGkfCHF3NJz2mU8uJ1JMm/9JOTUhpO0IJer2B0SbzFqQoxLRfez1kAIx5I2u1JtDaTlANMMkjSz6XtDW1b5dMQljUfxeTmYA0WH2MgBlFuu5My4Z5YrKvdK5KCkjPQCgh5BOQRRzty8mV2JKfrbs3PzwSQTYZjx3MRRztp9mvnJ5O7JG3KbrwFG26cqSLwOyjOCa7oCsnD+S+Xp4IxusKGiM2lKgs2kav77rQLOzliut20TBkTEhRAqAWAv2dCdKaGENNiEuvvcdl1izSXs7ukpBxkoJlrVs+3iss740oysqZIkBNbb0e5jLqLtFkVCKsBzUFao608zNqbjFOiMh/wJKEWpL9Iw75WVK9rIhMGjkCnKaNoczmOMGdIv1zDuV6qAs5KyquJqerRccp+uK/64iF9xxQbu0WosBOT/nHJ2EmOtIlIKuu8kXLCZvwpfSFZZXwOJWZ7sm2yVdSvNXVzHtKIMEpApMzFgzgqVLleWjGfImbuSSg6vjbe5nq1R4vKCL018zTOLiskMpbzpUnq17TlJKxy6l2c9TCuU5d2eHrAC02foiBS6utU8F6wRFCrpTZX8wGICZvaVbMpJk2X7HhS0zmo6u3XGnxHN2xmu6bhVSdGddklMWlkwvmoizkTtwJbVGj9KRdINb83AMIKv29RIh1axEJfCaWCTbul/JCe0JAxlZMQiaUlVVqHMgO8OVanJTLbq+2UniLws3p+iOKEmUd1qoksgtJmefJhrRnlaYWGOegTuNSa5Iiw7TM2dRlNxQMcf3S7tIphXA0JciBLKv11WXtndKzdOmcBS1uBkQSKeUozsphwQabU6cILKKRSXhNrkD3NTuKoKZlLabU1pFO1zKpF2xYA/pS+OTlpPWWYw9CIkKJZZANC9eHcVh5YA6ABl5moSiUvIm5NMgUuh6gV6SXGpfSmMis1PPTUcZFvO0P4SyfElLNw5wDdXneKnDw5Zcr5QnV8RbJV6KYgfiglmkiVNwJ32p++Xz2oNUjhCRI98UNv/lggxsmtAZyPIs2b2sfsuOvbTWncH0lHJXG3I/HciSd6j30Jcfo5muXmvNFw5RgQCiqDssEVbRoOR5L3kR1ibngk65UsGUVSgcMXkJi8iK9q/7hJMsTnopKDoPW1Yv8+WeR+uCSRvya5LlaOFvCmgx3SNQ6Mb8GyrQOSvKRrwtOtd3uRPe5YJzQJurnjMnfMXBLjGASvo4zhRTIt2ACZXevZiMcSfQRtAy7SIrYGXXefmeLSLM6XgFheP7RBGJW+J+dvm3qNv2KnJWjhIlfcZ55ZJiKzSu2s5LaVSQUApmvFJjM1i6GpNJE39L3NGczl0pTkVf6VniDqwm6457CZ6VUr5U8uTTbRY+/AlSeV4STCzX8ZK1Ux8tKtI7Bu2uO4p3ZDc1dzRAOeEE8xIAzdHeKDeRlFIh+KlHwzVkkqUtDjYwVWSk/hSQiQuPAXXqxEgqy+ssYk8cEEXnZqMlMxM3t948i3WQzJKetnSv0h6/TXFoKnAFuHKUTNZl/xU6Vp+4deV2+ETW0WcRifQhc38jqSfNLHEBqbLthbrg3+nrsU4wy5KTetzvHHBxWrJV+XIWrqc5zNtIDZ2lv9A/jlOvF8DLabu766N99QlZEfUJfNeXaCq2dwYJH3gkRdBCxlhgibql63Z6z5fXxpPlP9t+97xtNSaTSaDdAbp1d5LjZa/8uwJiFPeKnbSELen5tWUnU4V8iTyojlZhTqQiO6NIUkKXu7yftaS1Zi/r+vXCzPer4AQJDkl203Ec8nD8VpAv9BH4jnblOa3GBT8ppaI1yuKEiLSkzPseoHX0M+Kow5C83JPdNzNM+B6h0O3XMuDmgDZVBIKrd/NCrSMckrXDUHGhgB53cCdr2pYOMemY5K+I5gzQznrJcnpHNHFpl/VnMQJJwqCoxu2KeJI6o1Ggx5XdD7SG9KBgRoILqQUuy/LSsdOsbIWF64XwY74g6syL6ApCxsu2lDck6MptJsUqM40riaQ0ZZquqLxG9Ym8qdDvXePOKO1IgvVcGUBHdpTc2+kOD+NkNBzj+KaqFJQaomlatE0Dsz4rFEXXOdxteRpUJZc+Ar2U9szsF3duEhaP8S56nsqU9GzkqOhIO0l7Pa0MUXviCZm5pBsIsetH7s/yVQofq5vgLso4OrPYvU01EAgtM3V75Qjk7vtZQuM71pGkS3RVqXpOB88qF0VrMy0r8Tr00TjTPss+ayCnweXcufZ59DQR8inwxSyWpzMXzMU96dPrBU4/T1PJU9CXp48OmygiKIqbAPy7eJwLyl2C2R03reBJ+wvwQxqrvKnQdKV2avbD74SrJKCb1tPZfYxQShf4c4ph//7w7lXaXTCLbhjP5wC60sUayYuonxOanVwrEOpk8VSuzsxHGcQZGS2WEEdpGnTYJYA7c3bqMpTMP9uUhG61X8/1S4GAN2y8V1Ip3xC5lut5OFEIYxUiXHIepQo2h0SR/PLYL/s70Sl9PnEpzHyRJzsmqMtMhY+0xPnkviuneLhOimaW/0f8YVRVhcFgkACtTcQutDymmOz/Oi6NEo3gKO30ddrcFbQqRtw0Qyv7514gJsDaEerFquS2rR6KqMuQM105YE1/zwJ0JDXN5JV9X05hq+p7lwO9tF9FGZsd0Vwd01y/vVs4+ipKO8IUhrAdopA7Vx2RHx9ynMzhF8O1I+a/0hIAZ0YpNFPM2VIDXfaCHp/NXpoLlvfSvZjFXp9F8Zl2ZdpVXi7JqBAcv8qyLQzvzERXkSd7pUHPmw56xO9Td20vbdOTACbmZjgcoKqqyOjqBoxpOwcg5gKEARepBVPrnYVPot7MZegwb/yAxuMx9+1B8hVk0yTimuW4CM3brcNK926BxnSvLEQnAkajGdi12TzNsnWlZgmgL105PpXgnfr2O9ltHT7yJ6N10iYnt8tXEOxxCH5+gqZrbhH1U1zWUrCl2vbMfUrx3BWHsKWMMJWmLG2iKvcuLbNjKWTa0XfN0tacMi8145SmbjtNq7JbdwQNcmtEl6ZARWfcvRwN/ByrlaLaZP1NoHSHhdyPOGgu0JyNLBXWuy+VHZk9k6RnTdKtm3kF1o1xYR1PNDCeEslAFk4RjpqSxaa0qr5pwrZizxpdkPPtijJh6nzpMZcCnUmSTok9HoHQDyyT+/HsFpWULhI1bYOmaUIZBbCP7oW+X/LylYYlt9YaA2xcf4f9svwU8ky1bMsWhtRcKQbaNL+cYBF4xRpoGtQUPKrmeVVVHmidBhPXRYHgnASGYa1U+802LW04WVtAWEj9Sjt1GLu0jcL/EJZH9KpEKyX/RW1g20ddurqFYCZQ80XHOQONhUkoq8r1QBSJ7qR3pi/6KMy1qrdFBe9BHNDTbYsDjGnafAlouwmF8hbVl5FOM1oH0xJ3QaYweXuLJnHvngeaw9wQKkapjs5Yu9+BYbKyZYp1ysmDoCwW6JjyzoiF7qyPy+Vu/25q3AI4+ew5izW3FjvDHJbUpZRyYYzySkl3bkpl3D2TikcXtDNdI+RZXdfee9krVojCewHKueXI3qtnSSFVblIEmGX60GQyiarI6wLySU4TiSs0CgI5BBXapU2aCGUCwsfbBZBJAK7r2u+bzUYXZygu9XO851MyrUyUzxvSxh0/a5ndgKpNzkSI9hP88Yippj7LmlVfe/uU8jRdrBnnvSFeG48KjPupRL99EOiaZQI5rVZas9LCEe9614Qz4NtxU05TMkIBnrbcmERGhU9aUnXz9UWBJV6a9dPWAaeUphnnBWdf57kvv45W5FTzVoxpH819dHX2wdqXsTBNvR6Ch0oVOPIhxoZFSaJp8is7jn9sw2LASi2pjAIm6YxfCCXOF1neJlPyOk4rP5qPwuOVFJ7UJsfA/NvrJeJ4X66pgvzflGuIusuFfd5b/y61bJ3sEG3tfrbVyfz8ZdaBTZ5NrNnGBLjKo2Z67co0Pyw4C26074PbyzFn+M9pbu5bicPh0OydjSsOJPUpB73CIeOmC+TPdOUEZh9tZWfdJuvzikspYSrISgX11JPxHuSuABCxRhtpzZE2zkgJSL/206mWu8FQvVfiViOEienpthZqnwWLJL2ckClo+7yYzj65oaPiD/HMy+4MrKXWIc9CSaA3skRElZxLXCCv+6CreOb2z6d3ud/pvtpZ+rgTRFfodMcfKc3U+TdTSdJx0qslgdf/zvB2n0tcljvzlSuz5+p4HV0xpfKYkwTIA+20el3dglc7Q0RmX648pIinyDe5PbM0x7P9kyzFdddsJVbNOiKWlslkLJdG+y/y/4RHUwY07RTXcL9VwbqLWbO3bsGAZg2lFAbDgfnOrOgwR3C66bkDXgX1N7cXMev6kcWLTursbeXCcYhJ+3PaFaPch0V9UCyCcDLJi4XIbQq5tQchdDpIUFgP8ngv3ncA1ldZ1qhlmrDWjSy/pXX3TZhZdabSIQj9Sw3TheO0q8OeThkIEg59W8ki/k38U4REsStZNclY59bXMkZWtx0F3vZzQ5Q1XUV1pQbxJj0SzkvSqVFYhix4siu8Xa0Uj0EEJmnaLsn5PbRlL0dJwcryca8FmkkjPTily4Jadg048Sxm68gVKWmD5GnBt5xP7z1ChJnb37YtJpMGqfz3uGKst0iRlnujw9quBUuxKB9EjlDmevpDklw2nEOiGS1bq7qlYcapVicYU0urKONyYNbw1grHqweaNaqqwtzcHBRlSKSMIMw9C8pStjkmSWGNJS3egVFpHXGarKUuP+UmGSX31HluC/JSBeV2WrpNH1N4UEhTbEvGJRXRP+N6Uan+UB4LpTGiKF+UJz4d94zgmaIUphO3T2hC1ruZtsvsyAybd8OhV9EI6csvcksZs6wlStZyv3MA4aw36mu/H0eZuVBgeiXtTxXSXBZO/paieJ2Rls61TgXU7Q9ZQYjong0oikCby5PztuTonFJH533OWzND3067QjtgFJxMIX5I3Y1oUI8ICwooh2hlQG4XTZRNEnKdBD9EeShSLCPeEW7xnpYKqnNMkmnHeDzx3y0RTettdRfRY2GsRYNK+0Nzi/4Mc0xjPagxqAcdzWSWK5eegeg0oOCjR7fvRMPcJ4vjoaBs1j56XPpZhHKkKZaEfWEtpxM1Kt51Cu+jIaMxm7L6aU7fb2Y/b6p4FNdRSvmF+UXhYULo5sTIzPsIXRqXL32WtSjLiwheFnU61GrnoPJY5sba5gvZUpjpKlHTWjuNF/x94i2Iy7D8kXyZyc82MU1LdYSHZeUoKlPIh27LBUgIL1sIHErn1xRlLLk6PJ6W0ONC8MOaAUYu1OfLLNCUenKi9KmiklEGUj7J9UZ2jTxtgKPBW6UJ3RCMYCtlZozHY0s7RcPTiVIOTYqr9vji6BOzQ/BT3A/2H4bYQ15etZVrvOKk/pKuaFtY9KeI5wIcY8aPOzmnxTBMBw4GAwwGg1B6h4kyg+DeFIC5b1qUD6rwO7dE+YA7jk70TFJayNlDaoGW8tWHlwRxmo0fjkybCpO5syUjJYo7t7nXUXnZsnqu4hh511BplODblRP0fdukNhOpmOUtWW8PqGQK8zQW+zM3QSCEVw4RBZPkg11mgi3/NBWk5j/jsdJW6XYil8AgUlC2PxRIyIwSCBYAaQqFcu5JxSq3JSbq45xnJnkiRLcgYnNKmq9rirUayZApvnpK8sgyXuiVV4BmnLeJEpyXh0E57ItPiZaOXGEeOVOF2fxRpDAcDjEeT0xsDxX4SeARkYrAmgpt7T06NNqvuTm+sJZtV3PrIoWjsivIpYaU7pM1r9gfYuEEYPDVh3JkxHGnjWLtJ9JURQHTIto66Sho1VLr6px649JlcCi9kxGOUd0JMziNy9OfR618Y0qaeSF5qjTki8xovYzoIHJXd8QlmwCsPrUpLSu/hy7ZqlDwGkjBVNLsS2VG5WY8JH7pI1NmlA7d9iaVFPMHmin5k/BqJquMRyhHr+b1cBIdF20DEdOBmdGyhmbdKUOBoEhBqdzGNyQ0C+7NPU/aJy1JPw5ybU00QgKwTB83ctpF4t9uM2RRnm+dlpQorp05krMeBdj61AWvToevge58cXw9A6CWFN1O/2bK6iBGjyVtXrs525WnrhAJzqnYdflcOVozJpMJtG798o+kP6xykXgm5zA5gzrfD5T4MErzrmAMSHpqkpNKMLlnqMxaX0cIyYocccxQ5AA40JkdfGvR1nUdGFMwYrcDkoeFtRlZfu4ybct0UkdAFRgjypITHI48uw+Mwu8oT6ZOW3GXrgzgT4O7IGD7tcs4kMXuJ01zSaGwCaAFYvK7GnCHYHNbqKsTZRpny5bfFf4BrGN26n79xZffmazf4qsHaKdFr+f2dWeDBovFxODMzPA6sv1PEYFIQcP1EXvjQ0FB2SYwjPXr6JACz9eFiJ1i8qj7zvFwqlzFTQjbTxzoENCxVoqyJaEvN/E9jakuQ930WaBNlzssvZw2uMct3ue1kdT3vfd9kAH1mbYOZokLSmynTgm0xezJnlkpN9EtWynCcDjEZDJG27ZJOe4kKdXxuHqFQwpmxHxBrq6UQUOLLInu60jFZpmsbp+txNv4kkDqmpzuYWVLU/IVH6FdBZeTyGULMUBbAejuv/VaOHHvIGWp5q5iUFJNUm3ZPYwi2CD6naM/4nfskp0GSCUFBBDMRUBsbHMnVaqtyhrypTOiRTE5bi/EbeaoEXlnBuOMVliKnC16MpxQ7WbJpg9N5n7FLktuAGlb8Ay5XtjVWfPqSTPtvVeiI/q75TPCfHX3CgRSBGaN2/c8hs88ehseGe3BwckGtAIW1QDn7DwO333Cy3HM3OHQCLEbylKQddl1ADVN4BsRWuJkbgftZJvj7KUrp8zJdXGynZbWFfG5iPTPS5dEOSwtdSVu2VxdqUyZZa947sp6jgp50nkl2xLllaAtlB7Xnq6ym9Bk/2GZIenzPoVzMpmgaRpBk1XyIu0931cyUCyVpzkg7ZQg+SFKZ+UsATSeTDg9kiy9vMs3V5pP4/q6ywgAQ2v2Y8EAyGrNZo22e1iFtybFZIvImCLfOntoJfGmJ+PmpEArk1O3uqj/BdACYZByE2MaY8d1xOKwMBXDXcZyyP/qewh0zqib8Uo1dWB2wE2Vjrxglu+TGgv1dHoqdcEn0j7q6wwSON5NCPknu6QakFMnZrF4ZTlSWeuCrdkJYNZjbRpmQBmF97bdj+FP7rgMn3vuDqzxIVBlbFmqlZ9S26pl/PiJF+KnTn8btlZzfrpF+x4T2kKQyix9SR05000R2jPLlQKun6dWUOfqihSYVOYVllqmKmcFsJU09rqmM7zd1welOI3eOWvLlEFmtpDOHJza/yVFyRdl5ZDv6jKvuzaPx8bCDfTFwju3JUi+c210hBDgLf+cMp8b0wzpJkmIRnaZ5XQUzXA9kPRpcU+Z5ogRu+u53WAo97xz0ISlPuBuYQAYKFk+XeYnoUVNB8lcORHd5CkrXrNombYZADj+OhF134NTZurur5Q6ZSfQKNXWkv6Qk6p4EXnwyYJXKsiQMGBKhk3Q0a6ngG9JG8wrUGWw7ICtSMNJmnKt3avYj2kbomQM5hhuY1opPOdumk6MgKMxqcYtAzEDFmrNPLQCaVWP8Ue3fhF/9MAXMaYRhnNLUKigiKCIAOWAqQJrxnh0CKfvPBlfuPD/xmH1ErTWaC1dishaugmnijkZaA7dU1Kei7sVkrGTz6Nx3JSyFHPv1DXZTPkdpbJAw6aDDFMavgVKoLdgEw8SJ8qEVy4K4B6VIdLklgwBiCMBUkV4NsUyBVx3KUWOGuFm7oKxpS7MLweBSJTt1Kr3l1/sMHhq29MB26zISNcR7CzQ6QDLUoQ7AYj33ZaA1tfuJpAE9XSy+T4qgW2818vfWvpTyqNplGhpZbANAmOm7S0zgq1MLzXo7HvpMgHQAVpDnK8ncodx1GrRJDtOUxSIbJBRhhE77vREC7eUdtrWqacnjWcIr1b25+1cTost0FnMhjLt3cjupC9z/JB6J8TsnEXQFIPMBDCndJmAJ/b8ZocdAHDDvgfxk9d8GLfsuReDlW1QbeUdH0QMUsp87owChNJggPX1A/iO41+FD7/yR8Ca0cKcBqdIobZRyym9chKmgrXXYswA6masx9l4JJ5L8iouFxXoiNKKNkleKioRRfLKAP9CrizQinfmVQw20fzJtD1VZItyU7KEwMKchEsvJ7od4Eo65d/Ic+rqsOPoP3Jj5aNcJij2rLRsI/kWllxpMh4z/EREGLRE+/U+bZLRxN2TR2J1NACt61y3j3ZuOFfsMJZWHTnKEsGRALFLG2n2kv8gshDFA993cW54uyJWui06QiKXjfpgzGf29Eb1THEPyXqn7smk+GfJHZudeDnX0SwaeVajjZl6FrBN68zSnRMWyPB2TzmzrL3L/Gl5HQ9LFmhygjlWGIs0CL6aGtHtyhIat3MdO+29UhUOtev4T3degv9888XYWACqegGqVSDWgNtBoeDdcvYHCApgAtcKk/0H8dG3/Ru8c8cZGLctSBEqIgO2UGVNS9IYP4jbHL3jKEnHRYiEv4Wl3+n1RK7luE9ad2nsQLcduQK6c7t09XnaChmmK8iinA6fZoAwqzCL+tIra7X2eZSEcRW3L5H9Lh+JuKHOIJrRHo1G9ru48Akk4Cpy0cpWZicy2ctaCqhMaS0J36Vtc5YtAHNco/ctIQGrqFSnCYgB6oBtWE9xTBpcVOy1hrm5uYIQtINecJ+GR3mwjbYrAJ0tWnGZ5G/9JJwJMKVkk48zebNAHacvXgWteBow+MAw9PdhVspkyu0k6aE7Z32kVSLxUETgIxhzM2Cbo7sv72ashpwbHCK/5J+Oe03kc+0Mc6ogvHJCKFOefD9Lv6Xr+a31TLn1UvIaPeHy57+Bf3/Nx3DPgftRbd0K1vPgCVstXYfpQ2aumqJVaBcUmICRHuOIucNx1zt/GQswZZPvg6BIUGS9x3KnLwiqc0lAyvHhLJ6KDLB1xlSklX9TOrgwplmaC2n65ntHLmWV2OllzjIfZlkrBmKFpujeL/GlpyeUJkwGm2EKPb5csy1oNBpFykTWyqXuGi6z9dpYhvRjLusQ8r0MtqFBNBlPgkrrMwUNx0kTr4QmAyyDoIJBGwbR9a3RMAjz8/Mdhg7rSbOBbad1iYbshXqJgWQTkpvSvGan2WTqjSzxNB8V3gmmKWmMRpD6HzG9Ni3HP30LpKYY8XNIEk3K6dtK4r6RkypqkmBijipjIUnj8RU6XHz58RR8mEyWPi0/Z1lOs7zTSTfTulxIHOXLuUhjyMvVDchUOas6157NXIzgOgYzKmWszT3tKj5402fxV/dchnbLEMO5FeiNxqziagZYe6o7iqzYIsgEaDCaSoEPreLHX/pO/OnZ74NmDavru6Ri/Va0J5JoQbmOeTQO+TJ5w29O50vJS5R5l7Mi+8DIz1M5d5NyOkqUuM+NYF99HYs0LT9nbeXSFeotgnDaX+l9mm6GS9YXi3EBvDnZB1jDBlGu9GrbFuPx2NeV+5u7TwE6pRFevvZR4Ci09Xk3MoVFXZfVCcGoE1JNJgLWRKOzAOwGbW5urvzRd3nl1Ijc+9CmzrvOlh2ZrTAHpomtDqhG/N0N4ChHRCMI3mnCPOtuCezo29Uh3ioHKZ3dJD5dH+Am+owgM8OECMybA+Wi1Z5rBuK+kRZlse9S2vomv7QICnlIpOt2sxiLPrCVZbmsZap6y/AFzYCzctxaF2kMo9AqmKCRMVp88omb8Gs3fgaPrz6O4fYdAA/AbQMwQzHArGE23Vqlmm3bLfMFOWH335IBvKpSaPat44r3/Txes/VktFqbd8yoSKFy67du3nq+T9sqGhzkV6J8ii6ZIaKekrH3xRSeF8tAhgdZnGjVlx+ZYZximWZd3BmwBaKu6qZLCEkjrze1JNRXdpp2E2A8mxeqbzIQmqbBeDy2wGmr56AkZUHYdlxH+c7ROIUa78sZj8fsBb9fjTY1SVdwqWDzkDvfo3WWrAPhubk5DAaDrpbu9dPuIKdpuq11ky8I4ChnJhtDTiSxJkZ5oZ21UDIXJ/uA032+kW7mBlIUlpu0Eqhya1BRwrhZUydBqjh4iypCg66GXALdWd77d4my4AiQ95ue9Mj3oXw3kxXI5cCN7Bj1jU+u3xPrRxSeoUXwCHd5TKbJuzTDflnN4T/AAp2q8PjBZ/Art34an37062gWKtRziwAUNGsQNKANbpEDVnZgy/aexTNRMxleUqQwRoOzV07Al9/+s6g46FpZsJWI2Ys4LklXfqR5+xScWYSnT5to5p3T1fy7ACqe56WSXPCeyLyzQX1cZyT/cvwrlMWccuhoi4udTkluDstcXimgcCZAqrh2LOiZ5mqgQLasO3cJ48kYzaSxYCvdxmI5g1S4t7Kw6D1I2msbGsjiOA2DzUKLjSEULQgTVw5OKgRdriiNryMArfsebbSmRwmIIlMIkjSd5CkF+cnjUnTZOK0sP7unBTLlLNhunrgdJaaO1hXcb/s+pVzwWkIQx++KfJu+kNIyP+ldvaV+zuUp1QY4oTwFREGZCZQpqwR8WSDrUsNs110LdUnvDRDmRHm5IkEgQ003XZo/zeZANyfXi4EJpvqWGROt0dgPb1cE1KrCBo/x/739Urzm83+Ajz15PXjLMgaDFUArwJ8PZUiL7LMcpjFZQIYHYdj6TEDkPG575m7857suRqUUKrggKQGUJEpMGMmPPyUVW4VVBkjmiGR0uzQk7xk7FmV3E5QBwdEq5mF3isYK2wtZDshQVLxyYiAFRAdAKQjPGt/g2lsC2piggDEp0M5YmxOQAKad6MYY1AMoZU6S8kcH23fRfSICHe9J5cTV1Vunh9TAAcaN7BqbESRsP+BuXstDnU2nmEOgyX/oXbqQtTZBFwsLC71dkXKBEyC+24WWkJc44lnWL8ye25gQRTp39m4JJSAr4CK5I0B+E64RWY4RNEmUW8YKYwTNNNSVrFpEpq0E47ygnmpZmUIzGbv77OL6A83eMs+XHtU7y1pkpNxl3MszX9NcWptwJUraQvEcly0nqh97mTfQk/WkzNA8J9S8dwkcbesxViRw5TN34xdu+CS+se8e1CsrqNQ8vFeLACIDMu5reKzNfbBoLWHuXnMEGJGiRxV0RcAQqPZu4Lr3/RpOXz7WWreEsPgrt8AIPkgYN7dU4+9j106hj/L8JtP3ghZZ0c75lDPtBZUgXHBRpsFVWUUysZbds5KaL8VhJxB2yjxM3ftx7EoyJqlnsk+2lCz8XHkifbIJbFqPAzBYtbGxAWY23pQM4BtcC/epfPaymYDs134cfwjaHE/QZDJJJGSXcDaSPgiJSBjEg6G1jrSbxfl5E9WFeGtHXIG83eT+MkEDgF6wDfwYBiw3TL3BN36WcFxtWvdUmt2f8iTJ52M47Z+kUPHj5rRqWU2ZFYNBMYP1lwoG10+5tFExAnBTOShBqAS20SSTpMWt24wGnrYlpb7IAxKEJV2JwhoCfaRwtGMWjb1rV7jnePBmA1pBb8sGZB1gug8DPD0+gN+75XP4q/u+jLYGhvOLgCYwmaAmktq4YzM3mZ3Fal87K9Y8du7kQDQ7ukkBiqAqhfF4Ha897CX44lt+BspojXC2EIHsF4PCOOfP7CmD8Wwuz5SHfZMSEdlXhqC9K2t78xpRmp9XKdima74pO8y8NJKhLVrvFTSEnzH/d5f2ynmz6Tvem4LMTtNKPBKyr18lK19N02A0HnmLVdYXedAInfcxjwQOTa/8V4PYBUiho0H5tqH7yTzpcmAxCR3QghmtZiwszmNQd9dpTakJo/o2FrSbQFD3IhIMTKFHMuW/kKtoZRU0uqkamqUnt/5m/sTlUGYKc7bvOkUlvwun8HQKRBf8OdbwOAGX9MoNQdBTpMKQpzcmkOMJxkAuwHsa6JcExDel3KFAe44fI1oKUh4F0VGQ4qngd9Zsq03kcEUVNGl85IHr8Ru3fg5PrT+JenErlFYgMDSxze/6gQU/GcWCIHjbjZ0HYCcP4p5wYEtQZgsuAD2o0Ty/B//tzf8SP/Ki16Nt7YIwTFRyRSpy1XXOpPV6aaKUJO9Lcz1d7nHtg61LKp6xgHe3aXRuQl9qb5HMH5TzojWboTnXBd+EKMtevo6O52y2vO6aHfaTenNlOp7MeXnse/8o/Uqbf59Thgij8QiTySQK1qXA9LGVm1niITW9f9K2ESDA1jcwIdBrNghaYDK50ohkZkZVVZifn+8QIfTeqJ5pA9wXlUkJw/s/3wKw7dMc+0C1BMS9eSO+io8SS0MPfPcnc79QXO+VgtSmwSdzlUB0M8LC0bVZenrHzN98E2Br6QJKfZzRBvoAFzEQlLwtHfcyheeRNYvwdZ67157Az1/3UXzpkZtBi0uo1NBEFxMAciueBjylVi9JlrJMbtJ3TCjwJFi09q/yE5TAijBRDZbbOdz23t/GDjXvy6oggqVccTlPWAlQpwCtpdQmSZTYKC9lA5+k4dF3UdJ50yzPCOAL3hz5LLt/eNq7KfXH4r7fYEjzAqU58MLzSppihV8+CP1c3ItN1nfJSR4A6xvrYO32jAv+p+SvmBeOLreEWlo+yykgBIDGoxFHgkcI+OAe8ipZB1jdla7ZLi4uZgesZH3kXLvFdQhOfkirJ6on3friRFEov7yeICbnCxT2s+abxSHSJ4gzFIQcs7qaMu2Vrv+ZQFJ4GNLJUmpV71QV47+Zq39cu9q7d9dtwiUHZKh3Zbs5lBbX0ww5vnIOxsV36WObp9UaLZs5WCmFCY/xx3ddij+96YvYp9ZRzy2i0hWgNaA4uI0t3ZLAmbtbuCIdjEWUEcJ3oImgGeCaMFrbj/ef+nr89St/xAg8Mt/BrWCiQaVQixrqb2ebI73LQe69fxXS5MDHlc9JSzu8ZApGOmNiGsK7otD2Frfz5tiaC4DaiXJPACK9AsgkvSnnekdfzMnz2Y2R2LOXj+RFQi/JZRuZnCw9PIUGyKXCUGPbttgYbQDMUKRCXbbcNCDP0+HqTazeyC3v5QCi/d40GY+5JJxYZMxOdAG42kYfModtPn1Xqo04AZOC7TQL0KoeUzSlPFAVZfkmhGSHtE1aYrMw8ExBFyK3lQAmb2YJIOcaEZWFW6lcSQDPlOueddZYKHaCx/WHsPhv1TVT/wurwU+ITQKtu3zbuDuho0RTy+lItvxlhQvDHrPI5ruxBLPNpuEGn3/iZvzmDRfhjn0PoVrZghpDE+jI1m2bWE0USVYhtPsmhs+TbnkL70nQC5DnIF0RJvv34dPv+UW8ZftLQBogu67shV1a/xSw7Zsj0TuBgQGMkwpcPVM9JJQ+iMcxIj/Iu3QrjCVmap0+7ybWSEtyMVGLNnEFaTpTXifTSwZWQYG0CeyDJI1vVH8rfGBSwhuOBcbjMSaTiXcXR/znwNTOFWem+THz702JjoVkoGNKFY1HY3aklKJggXC+cdjSY8qTFq3WGkpVWFzMRx+XXGHZK8aMoCV3KMs/yW3HkQVLodARdX2cWWCAYmRswu3ZdVpKtuok6TqMmuFwyfqzuuRzCk7vmCRXn45impWbJBQljgR9NLxpYEScxGn5Ud0Zj0IabJG7Irp9GSlBoQ4pIPNWhvgxrS99P5R5xneZ8Bowm8P9datNABIRHjrwFH7ruk/jU4/cgGZYoV5cAloHriYnu/IEP7qmhmpLWqitXbibo74Q80pazRz1iRFSbbuO4xePwDXv/mVswZz5TIFQECtnXST9FH5251tJqex1riZ9G+6paOHbKSuKCP2xOUVALh38E1w9nqG4VsoMHCJ3ulEQKMmPDn9Pa0c8LoWrBLI+U1DqnUIXyZZcvV5CsmVhk3ZjYwNt2/r121zglJ8vQknLKjOibYGkQJMyL8igt5ssZBM5S4XZFSesWRHq78dUYX5hLvi00z5CWfPrPPS9KFpDmXT2VQq04IKW6IWM+69/nYNFO80D7gXaLAJN0co7HqaoulmA1mTKLuhnLskQuUJnjXBMyU4KiZ+R63H3Oy0pr+Tl6sy9MyxLXcHixmtamzxfuz4sCCiyQqjgCeJOBvkzw21ittpZlTTKvGTbny1rNLpFwxpgYFBVGKPBn33jMlzw2T/AR5+4Drx1BdVwGdzCBEApDuVmhKOZLyHewjdEc6b/hGCWj5PxZtkZbNsABhODoVHNzeOhvQ/h12/9NIgUtNZo2PynWW8KfEzfcNSXs2fuppfDm5MTcTXixKxiFfmo1X9SoAUKylJMQSRvpynpgoeY+tscasgpTD25EqBlJEPkNLfs0mLIE70SbYsijmG+pw4yXiLD+uF/viSLPQF80zkcwLnD9jLZeDzhoPkGzcNNboI50FmCbeiLAESt1pgbDjE3Nxd3VgckXZM7j0Ln9KyxhD1OmQSurmydtowsCEy/nOZiSKVO+ZFlWLiKsD6FZkb5mMipV+Iy7K0/ymbbWgCVjtUq32Uszth1XOikZA0kqisHooL5O+Mqi0V5WMw7doQn5HTpydFMfWnIjvtmJGrO2oKZphrazEcybuNrnrsXv3DDR3Hj03eCVraCMGdPewpzNqfomn4FYsIyqCPbIGlLnrt/4zVN1/MGbjxvkKmclUK1Zx1Xfvcv4ewtJ6Dx67eEmqooWCoAdkLmDHMh5kfONjNWFPqXIoLgJ3RFQTqRujREfdhRpjkYOZk2FLfFFImNvWbpOJaGPH1V8txFxaTLE16ZyLTR5XWKf8GapaTcXHspedGNTXQSJ99bo/EYk/E4jk52rmX7nxPPXb4ga5eaOV44It+kDN+zZUFQ8jUfFm/d4In3xn2ssLi42O2EXBO9gtQFLS+XEl+c4b9vXgdMjywD8oCSu7wrJZN8U3v80tk9pfrI7TtD+jSvZOosXXk+zwCle254Ii0xBdrouajMT6ASIcj3Zwk0S4EwnfQFxSNbLqHzAYmpoi23BrUZsE0UTgdTcs4RDMjunhzA7976WfzFPZejmQPUYBlolZ2v2s9bShQ1LwDtu+7lJ6doVpfvsmMKMac6JVpgIoL9Cp/JNxnhjJVjcNXbf9kESEHSGm6idb/S3CkwyFSlSRDvvWIIaoJsLznhKtSMuO2Z8jmWdcXzBqI8cWk5sJ0qc1IPnCmgLD7cnJbKgL1jFi1N9AZPqWeKRGktgJ1UoktxEzkZ05dGOmC6NGSAnAhaM9bW1rySFRxkFmyV6shBf8/obgXK9DED4as/8ZqFocS5lYgIrIMrSgZGObCdn5/PB0UVOtF1gNe8NgkgnXIQOki8SCzS0PC4vC6PbIqpMV0b9uVkVEc5kfrWjtL1Bpk3toJQ7vPSemZUZ/TAJY4lbCIM+sr8f+rK1czpfUb5KNHciS/wtbi295xxK/IUQTpCrKhoUQPEp/AIDI1PPXoDfuOmT+GR9ceApS0gnoNuLW855dhat2TVbe+JSOMepP7h6+cQ7WkaZl/lhZW/93Q78UqhOivBiAisjHBlAANVg/ftwQfP/y78zCnv8TJbQ/s2KwtzSed0+7yPAbxCmcyvrOJslRwAbF3aTtFWSvnDN0iQlFERiuA/TWlzyqgDx+hdQS7NFI08g5fLv43kckJDNC3iDraj7ojt0l30iJVUaVFONB9DW2SgVawa+cKT8oJcZdvIyWSCjY0Ne7KUSebXcZPluchLV8CMbDOyYIsweHL9k8Rzd4CF1hp1XReOZMwgS/QumTwzyWlOjV6vuUd8QfntHCXA9Q87SopjorI2OmsEctjKFBORA9sMKZ6OjhBMxi52qcZMLK2U3iCsXioQ9Ws0HD0A/q0G4hJ1fVxnCbIJu9ZCnCwHtu5nt02bAtsMz3OS0gldR+ct+x/FB7/+CVz+5I3Awjyq4Rx0Q9CKzNfv3FgzPOhGZxb7toePjERXkLTxZCIIkA69HuKLkRmIILS8FUsEKAO6WpncFQClgJWNBle991fxosGRaHWL1sokRfawC1DCyTH/pn0ZmspxWqdMiLHRrr2ujdYFbyyWGEadPmMeSIpsBHUBbH2vuWDIPrwVCmGfMtsJCAuJfPVRVZsBW5s+expSKNA2saDl5IBalg0hX6eAcVx03A4J5MXcPaLMvV9bX4fWrS9Pgq2Tl9JDkQZQubOXSwYmjUdji0niiGQIsGXHmOwH1B/JyOb846WlRVRVNUu/RNZnCugSAIrRvXH/AODOOZ0pk3XA0E0Sny/+nVosJbpyICK1ylJ6WWVf+17I5Qa7u6ZK0R9zKxQJlx+I8kZBAVJ7FIpDNNlS5aZv7Aog/EKWC6ZZ7L2TeIb6nRXUH04niiwoMoa3TAr5zGOkA3GG2Q5DhH3jg/idmz+H/33fVVijddSLW4CGQcQ+UCUGCjvv2IwlMYHtt2Sh7V9vuUieFDMnEiTBEWiSp7An2pOCtLMUCBHYsgI0wX/qjzYO4YLDT8VFb/pZu2fY9Lc5WYqgoLp1dc1K/1uef56OQ5BnVsGheC47WD/YruLOPY/i0dW92NdsYMfcMi488sU4ZrgzyMiAcN69LCqMTqZiaRTYGzkPcluCgohK8iLhU47HcSqXFsAtN0vS0ZbA3gm29LpHTpssy3SJhWldKS1pfsOS3f4pg2+uJnOU4/r6emTJKiVONev8NWMaRCR1vJMSAGuQAFoByIF0jp5rDpoZM2M4HBigzcw/qUzHY9vVsFIBFAVDFS5XpdS1Edt+ghYBoB1hyhnaxfosZwAYXYahkFk2Kn9xcm8nagx8pe1L5UtGxCUqQESp66kuXZxl/L4AJJfQeZolLUU60enyKN+mAbfLZEWBElGRkJjWK70Rmx0LWY2jw/G5G2sG+zlFIikpwgQtPnz/VfjdWy/Co/ufAC2toFIrwMQgqVuXVWJ+xtPL8A+R/ZCA1nbCtN4mcTXH67Keioj8wFhSmHRuuo33oEtBMeOg6jVao1pYwpcfuAV/dfyl+GcnfZsBYNtTYIivGxES9U4wqfidGVenzGjf5/ZjC951SBjxBPceeAL/8MANuPyJO/DAgd1oAGhFQAUcNr+EH3rROfjJ09+GI4fb7ccaCE6OyvXYKPacGWK3ZvlKQUTkT98Xu0BYpNnUs1iRor5YVGUU0WwBuZodnlBuiDrlFNS5Dn2d3yxzlErpUl3XNaq6Rtu21tMc5FAK7q53yfK2pM25tcPUMG2m0Wjk16a9kGMpdOy6kT1rVet4vXZpaanzQfgQ0BM641vlSswKYpbM5rqiy5xSi0zBPU5jyymk6b2E0O8DlHxecU+ZfuwU1lVaYjpM7oi9nHBIpo3bOhG729DbfO+mS9LmQGnaGnhuvbrkkqaQKSGmW1eUN/u0/8rRUWwLZ9KQ7ducXmPzazPhQGCQUmAwbnjyXnzwxk/hy0/fClpcBqoaoNpYqpYVnILs4CeSMfZGWV4mrc2ZFq1xk2mrlbdgAMpsArSAGOsgDHKfJGNko9ANX4lMbt44QaTIW7QeeGGh3saCkAa41Vhca/D17/0tHLdweL7vUwXAV5soToXJ54C21eaADweUz48O4EuP3YWPP3QDvvLcfTjYbGAwN4e6qqHq2uwDVmaLSDsZ4bjFnfiHN/woXrFyktkiRQRtlRcPshSDbQ5eelSUXmXUFBnPF2TrRDxPckArZHMO8ChXTpQ3VRA4oqO3LVG+zCW8aUXjRuSPpZ2bKPHSo587mattW6ytpdat5TDn9XBTW6Rxv5ltemFpetrG9gSpbhtj97Fcq3V/S2u1JYtMTh4fKu1IyfHiLFcHdwvCWNDg6y8V2YNh0+mJM2/KSksZol+3QxFsOWb2qOis0C/0STomhVkzi8s/fd9xD83QT05Zmgq29l1K/gsB2/SaKagMYtKLue/Ehjv1CWKeuEn80MFn8Ac3fA4ffuBqjAcNBvPLgK7B7huzhOgLPQRYq89ajSQbTVDWBUyswaxBVEGvjsEbG8DcAtrFOVDbwnydhwEl1mAZAGuQDg3wBiYb+juWmgNT/5c6v32XMIfP87VGNkzW9+Ftx74cH3vzT5nYZKEAilnlmykFoFdKbdktMzTsEZb27GVROSbc4t69T+IfHrkRH33kZjy89hRYAYN6HkpXdguVBqqgLJACaFBjxCNsUyu49q0/hxMGOwwIW7BV1u2dbl2KDQL/OMM76H3v04k5U4wbmcXLFtlquTq5jFAZJcJ4yzkat2lzr5gmcY/L9PlSkuwSXyDHIE0eKFhbW0fbNsaIJITjHBF7gCSWySW5CICl8TUajYIc5nC0lRxEh85OC2VmtK3G8vISKlV12jhrwFDUSN8Z5by5LTAd1ysnFtq02nNWSg/wTwOEnBXkQCL3Pl1XkFaQFCKdWvvQU9QTly21VPlQar7w612pG78YLJbpr2ng+U2v03Iq5jMiys6ofq057qe4KxIaZ4XrSNERwTi22zTMMYsAQ4GhVI2xnuB/3fkl/M4tn8He0R7zZR6u4ddaLaz5YCMLvIa/2H8mTwoBkLJj2VpwYvCe/XjHrpfh3736nfjpK/4ad472Q60sgbkBlDkL2wkiYgpgyyw+Du/aFawOz6iOPoJxZUbWrIvgJVuOBloGswa3ZCzEGhg/vxv//Z3/Gj988hsA+01s15++Cvc/qbwnY9WyUWwIwEApkBWaB9oNXPHk3fjYozfi0qdvx4HJIaCuUKsh0AIkvHeeJ5xlrqwXoFaYjFfxtmNfjc+8+kfRtA1aOxaKFOr0owoQikrXQkjFIEqK9CyyNburgcoSsaNTF5RYkaDo0QnCqqCAFxQEpyhJWdmpPwVb6lRlHG25hrLDFp87lOT42VbRNA3W1tb8eq3/zykPKnBjpAyS2GdOLng1kE2j0dieyuUmjmA0y6yuMZrD+cdKKSwuLdrJnISJbwpsZWeEnuvNL7gjBdsXfBHF65IZ85bTgZ9i0ZUAJ7d2nKYy60kBbHNp0jJ8+UAnitD1bRwPkwCRm5AsAHWTwyjLNuT1jE2uHzJKSaqwwJFVKjsRcr1XKjNEf3/TYCsmsf+IOwJgKAuQX9t9N379uk/g6qe/gWphGZWaM9FDCGuAfiikckR2OxBZKJZg6/5jMiDTjDG3OsZPnvZ2/Pp534lKDXHvnifwlk/+DvYtDtDUDFYsFDJnPRo3MjEDGoB2Y+SUcNFHSgKr+etP77FC2PetO52qZTC3QGuFHmlMqMVQDXDD+38bJwy3gTRQkaAHQviRi1Fwa7K+a6AIqKjyHXfH/qfw8UduwqeevAkPrD6NttZQ1RyIa7SNtjS1nhnCkoUDWvEfmSGqD7X4wrt/Gucun4Cx1jCWUPdQjkRvRY4zAzs7ZTGTYwpwzjLvOmAMtnwiE1kO6JRDFp+424QC/b7YhLYUbPvkG4u2FdOzeDnD81yAqLtW19ag2xaK4gApM61UmGeckf32p0qe03g0EtgaKtUsvuLDMdBqrbG4uIjBYOCZKCV4pu0UssmUTxd3cAysfZ2VlpV3scT1RqCWuF/CJM5rWvLKW8t5TTWaPL3WYJgM3SjEGJQl+dF8oS79pYkAWMDPTetCv8nXL+gSYBRpsTmNN8kXXTMoerHtWUrjhEJSXTaHiEoUZZrAHOfSNABTKePSfGz0HP7D9Z/BPzz4VWxgjHpxGzBx9RLcJ/DInV7OcdnBBBXKFcGukZo2Kq6B9XWctnQU/uiC78cbjjzdEqYBUrjuqbvx7Z/6Q2zsWEY7MF8OMvWJZVwHjBr2CEcJuM6SEEAb0eUJ9cqCiZBmU5a1bEnDeM4I4LrCaOMA3n3aefjwBf8aNZu9tspa9KapZjuQD8IW/Q0Y11+tFA40a/jiU3fhow9ej6t234PVdhWYmwMNhsYb0Gho7cCQAdZGIdWI+ty7wJXbJ2z6nA6O8N6TXo0PnfsjmLQNyFq0VWINeQXWEev7hQPPZGROh5NLlt4Unk/XdLtgK4t145WXr+n8jGVWUNQkndn5O4s3S+TNgq2TGRQoLszOuC1FdDdlTSbWuhVgq5STswSyVq/DPxcUZV03pp/tf96rOdoYsRHIQtuwdKRrtcwmoIEUYXl5Oem3zYNtNCRZmc55zUHWIwDYm/CpDll04cq6Re+XgNG985V30/S6R3PlJs+8K6LIh3lbvjsp4S0199tppCGwM2hsKa2dvk8s+XzwyuaANlJuetLM9FWeGZSguN5+sI0USDmEaWqK+U22qeXw2TuwM4oUJmjx53dejD+69Yt4ev0p0Lad4EltQI50ACVfv4JTfYz71SGAQbogri3QVQBIQbUa8xPGD518Pn7zte/D1noJ42YEZkJd1aiVgoLCxQ9fjx/8xz8BH3sYGtJmHZUMYEMB/lCM1oJkBLb+MyZg5QSaEzhu7Cx1FmQNmFkGdV8jcoHSpjq0NUEfPIS/eNe/xg8ef4FpPalkbpieN/1K3optmXHb/ofwuUdvxccfvhkPjp+EVoRquAR3RIZxvbsDQ8yhPaZLbeS28Og5l7VTZDTBBpgxVANsmwxw4/t/A4erRbitIN69KEGABT91NFS3TDBdUUyvmYG29B5xW3u1Z/nati0F0hRoszTMArQpGcI4kLJmmoU8q1EmMgAMHDq0aj4BqYQr2QEo4D1IniYrp/x7pax4t7J0NBqx074JiXtBrNG6/5qmxcLCPObn57vrArLSUodZQREJKBHJmHZIb/DJjJeLtM3lTVbXZiis0E7hEo0+4izcINJalr9Tl6mnxmN/V6vzZYpnEfVCI5fbV2YZp82k6QvKiOjrser9+8IEnGWK+BqFIE7lRs6a7eOkmY7Vi8pmP64abs3QBuhYi+drz9yJX7j247j56TuBnduhuAK3CkBr6bKWm3Pleh4I/AU7X42VaMGN4F22rCpgfRVHzO/EH1z4A/iBE18FgDGajDFmDVCFWikMVIXarmP+7W1X4Ccu/q/QRx8Bmq+h2wm4UtCVBRpmkLZj5M5KT+UnYA+IcEKIwLoFMUFzC2JlwNYDrStHw5mobs8rK6BBi3nM4+4f+F0cOb/VrnM7ZdRUrohQqQqKgGcnB/H5x27HRx+6Cdc/cw/WaR28MATqBcB9KByAP0HI9qfDVX9WtEN9P7Z2hF3/gtGSDRKlAbD3EH7/9T+I//ukN0C3RjhLedOnCMf8KX+IXyVgKliMZU9QDuURyQcpi7uXU8BN4s3DZXzJamLZVW5vuC17AXPr9x1eLXk7xTUajbCxsYGqqoR12z1VijoyLPCKHAva2NjgNKrN/ZX38nu1KysrWQtuFg0rG8rPbq51O69oCW/iKgVdZSOmp7FQwWVZmiizRNgGIRAEgHsX3CTxgPpSLWDFYOs7tGMHR274TJ90PBRJe3wamjIakZVcqE9a9UnbU4t/1onNktnF1VVVcpnFa49t/TXL/jERsMaadcan2zbw6Mbz+M1r/xEfv/sqNAsV6qWt0C0ArVGROXQiVVHC5GVzQpQHA6eIMUgbq1cra422DHXgAN71kvPwn97wwzhx8TC03EA3GlTX0NB4dPwcjps7HAs0FPURLrr/6/i/Lvsf2Ic10LZtwEBBKwE+rAJQwgVMQSiRdmtNM4EeTzBcbbG0sIQNNJjMD8CN2d9rANf1t/GWiUaHwahq6LUDeNfpr8XH3/xvPR0hYAXY0Bv44u778Q8P3IArH7sbe9aeA80r1POLYFWDW0CxBpMLNJMDF0CXHfp5O70wxjatCdBmKACTtsFpS8fi2nf8HAZQACnfr2lEdZ+W5+ZwUfFM50QpXap5J14fSvKWvJLkAVXKYFPeC7HAUxLltRmwTedcsY4eQJ7lYtY4dGjVl+UsWZWzcCMSw/Mg22HANhSeB1qjTGu0bYvBYND54IBLN5PwjkAD8OLfydgesToL2EYug57kOUYqXZ3AKHSLjrQ0YeW+kMuLmymuUSOrehizZ2IbZS8/Npu+Mpa8oy+pMquF+3uZJ9fnm7V+naYu0ri50BtNmRaTKk9CeLrfZo4wGtZotbFS66qC1hP8r7uuxB98/SI8vfEs6i3boNTArk8aaysY0BzGxFqGZOceOynPMOubng6DQJoIeuMQdmIRv/f6H8YHTrsAiipMJhMwKVRVBU0af//wV/CRR6/CW48/G//2Rd+JOdQW7Mx65NPru/Hr134CH7vrKqwvtsDcItSwBqEG2ehmaQEal7CG1g0m4w20o1UMxsBZS0fjVy74Hrzy2NPwzz/xJ7h676OgpQW0ujFtFmNMOkRSW2QC2fOTVaXQ7tmLv37XT+D7XvJGACaa+/49T+CSR+7AJx+5ATcdfAIjjKEW5lBVA4AJ3NqtTtGQkv/jsNUJ7hSfohzSknO6h5WLpI3LWx0Y4bPv+km8YdfpaO3Xi8DW8gYlfC5B3ws+88fxOgfQj+ZNj7s0ezmiE+WYO2mAlPcjRTuS1TMo0uJ9r1SRfZ8r1z+IFQ2X17/LpSvIC+cqn7qrgoD1tTVMJmMoVdmcZNduY8A11WXA1/5mCLBNXcJhrdaBrgHbpaUl1HXdaUDp6gNbp527hvaBXx7iplxTk09n2VnXooMGszltqtcdK9Oh2xzHoFMoKvbDrK7/Wa9Zoqw79ZqM/j4HyGXr1xcg6uIkG3WJ6APbUFzyKB/1zjDBg9rPGfaupq89eTd+6dp/xI3P3QFeXEQ1WLFyT8PFzrozlTii3gpyT7tb0GRAw2/BMXqEAnMLHDyAN53yGvzXN/4Qjl84Aq0eo2k0BvUAlapxx4GH8df3XIr7m8extGMF+/btx3m7zsBPv+i7zcfb7aE1StUgBdy99xH83b1X4+KHbsWT67ux3o7RqtA5RMquuxIUGHM0xIlbduCcI07Ce055DV53xEswoCGICfc8/zje+qFfx/6VGloZq9aDiW0DCH4/K9sgJChjRWgCdk5WcNl3/xye3rsH//WOK3HV/gdwsFkFDRSqwbxZRNUMNu4C05PW5e6Gk2yPeyNTgK3ko+xlwdPxp3Zls3G1txur+MAJ5+F/Xvgv7YEZJltFZLYBJbAf+CwW+Oy4jeD5vKOAlmRoaGRcYNAxknrETZbnRXoJXJKuaR6uGa+pQZDuXZ+csl6tMOC2M5LuQWEud4kCmskEa2trwZtCFPbdui1p9h9nyXa8tw5s19fXPdgSwbiriAXIwruRiYCVlWWUmLLXh94zqKFDMlwRpfKsKPoj4yb1PCmZsiBcCdm8Hfq7D7PWnCyegZmil00RCegmWlnWvdtXppgQveuulGjaPZcERk4mXkpHr/KRmzRJOSV2iQRAYRxjwyH8KE0wuWYlKw/8kyrPHPVDC+3X6hQR7jvwFD54zSfxmYevQTMHVPPbwEzGKvS+11hFkKpC5Op3AUjuYAkNeDAhgt5Yw1a9iN+98PvxI2e+3gRgNRNoALUaQkPjIw9eiU8/ehWqFaCq5zBuNaq6xurGGo4eHIafOO09eOn88bY9xiqrqxpEwIZexyMHn8XD+57F0+sH8PzGKjb0BC0Dg6rGlmoRx61sw4lbjsDJW3dhSAMwgEY3MJhjhNNf3vwl/PQX/wf4iO1QbRuaXRkQIkVApQzQVsqDLdl3qmlxxMJhWB0fxMHhCHW9CEAZOdUyYLcnMXOInob4a4VwiGB22xUF0BanQSQk4OJYjLKhwMTgGlherXDz9/w6ds1vhbaBpAZsk21Afmzlr4zoKVh9Bcos0Np2ZNJH0yUCpoKyWshryEnklSe524kR/RzPQhnYVJJlqSHYK61SeRZZ5t3y4qQ5Q4lx8NAhcKuhqsqDaRokBcC7l129buw8UG9sbPgAKXAgREYhA+YYq7m5OczPz0/tkGzjhYbl2ugHVwJtctt39QU3RdtWSAitmDRHQZIXEbN291GVgTYqT7iCXL6+K3LFJ8R1rMFpZUqmzgDqLGvs6ZUF0IIykSrY30y9XRpYKKz9Ctq0ALgO3yZ9lbqQdVR3ACcA2D05iD++6RL89298ARu8inplmxHGbKJoY8GSCtvgQo6FovmWJrTlX9Km/9sxcGgdb3vJufiT878XJy4eaQHOWrNU457Vx/E/b/ksHmgfwZatK+AJodUttAIabkFVhY1mgtGowfeceAF+8Ji3YJEGIBB022LSNkBlwNJsgVCZbnb9YT5qT2Qirplh3KlWoDdo8f6P/SEuf+YO1EuL5pxmIrBiEFV2U6wy/wnLFiBAAZU913m4vAAmBW7t+cZam8Atra0OYgDWRROHWGnHnmFfrrSApD0QMUPaVAvezq1PdmwxV2Gy9wD+8LXfj39zxtugtUal3Jal7mlS4ZbTqd6lYgarj6IbCqAkBJCUSzG45S29CGwLLtnSfM7FZ6Rt8KSl1nGSN9v2vuUzT39GKHAy9knaXD+MRhvY2BiZQCkA7nAUckse3uo15Zv98+SVdG/xSss2uCTMvbbRgqwZrW6xZcuWzjnI2cvJYduoOPI4SSQ0K/Gg2PDSNQvDhoKlWCM/4N39qz5zdG8URzFJpLblJkZUT5eG4HKdrZ0+8Cd+6svplMCelUXqHgWiU5dNFzIUdaAs9QUlpKTBptT6dBlNM9bEZXWpEEnANproec3c56NuPgeHztvjeHvCE/zNXVfht276DJ459BhoeTuIBlaEMUAqmnSxXmnnHemuAgELtt5CM6/atYM4YrgNf/jGf4b3nvBK1FBo2jE0FOpqiDEafPTeL+Gix65CtVJhMJhDM9ZQitCaECY0WqMxkgFaKew/cBCnrByB7z3pjXj99rMxTwO0WqNhDc0tmNkDhmmH61kXAGQAZYQG968+gy3VAo4dbgdrNl/3UYSHDzyH1/75z2G0bS70Sw2YoyLJbJVQ1solC7hstBJlR6Cqa9RzAzRtWMemFtayhVl/FqBIEIDm5ooViizORg4WUIA/928k7K1F60Slj96tCON2hFPnj8Y13/UrmIOxZlXUV/CKv+dCcZhEb7xKjh+li7wgB4JnLWK6Yk0d8MzM+xeyC0Vk8OVGdLrXhWzTSvbynNPUciwzBTlecHkzFbVti0OHDoUTpZAESEVnJ9tiBU46EI7A1hPO2n9wwPCWhiJlXcgzXInmZtpEkbljjpvLdWFhbazgtohzxtpbJHQzzBqlIeqeIBUyF+vLMU8JbHP0lzSqzhphUpBnTspxiH2WKoNTAMaQnNCRWKvFfPnC8okLmqsUiDNM27jOSKuRt3nQTJXAmLzwXDP7oxWdY8grZwC+9uzt+PfXfBw3PvYN0JYVc/oTTHQxlKsz+oaNoC9YH5w2gAGDNoD5lB5BTzZQrY/xA2e9CR8877twRL0NLU+gmxaDwRAV1bhp3/34s1s/jaf109i2fSv0OCgIIG3PpTDn+GowGtsnqlIYtxOsrW/g1JWjce7Os3HOkafhmOEO7KxXxLpj3N0T1ljTIzy6uhvf2PcQrn72Ntw7fgrDEeM3z/kXOGPheDu2Bnj+6PrP4Tev+GvQsbsA3YAHJvAEZAWUAz6yR0d6UPQaPOYWF4xsch9XcFuSbEPZNzhQGx28gcxc8GAV5k6080uUH+pwcs0k1sMK2LeGT3z7v8M7jno5tHbR6AHwKALb6NVUpdsDqgTbXoBze+pjoJXVRql7ZGzOxbppL1VGVsrc00yOmeRPxsgweSl+LIeAA2/lKmFmrK6uom1bKKU6239SI6r725RNa2trLAt1f71Vy9aFPD+Hhbl5OHdYbmBKLjsW/+a+PcuIt2pEQpFRtoYcDel79pmiRqf50qs0mCUAzkHc9CujfVFat5j4mULd4Ml+TXVDFzzhjUNKy3iBYfHCAkhaEVHj02TAM1rzTKiH/J2hW245iHipVJAopG+tJqJN5HRLLM6KMOf0Eh5ffQq/cP2n8Znbr8LGcg01mIPiCkb6szPIEEZJJRNe9B/LX5Ze7WhTYGjoQ/vx4u3H4vdf/31429EvBwFo2gkYFZRSaNDgw/ddiU89/CXMbakxrOb8yYPuJCrAHLTBcF+/adH6NgJUEVRVYzwZYzKeYK4a4AjaiuO2HInDBtuxY2krRs0E680YB0ZrqIYKe9f2Y+9kH55b34PRoEE9N0Q1N4f10Sq2rA/x3877WWyheaA17rUJN3jtX/4i7h09j2r7Elq0gFIm8lhYA84mJauIkO0Q1oxK1RguDNE29ugnpkhgOiWYgWhLYWfapdZgpK1bsGX3TIC4AHNzEAkMPw8U2rVVfMexr8LH3voT/gAgr6wRWS6I5WTu27vuHWxbpi1BdbxAUgZmZW7U8qwsmEUpT4ElXYa0FAQaM3U4ZTtbfoGezicEM/VKwdoxaqzSw0kfpG12z0ajDaytraN2e26JfIBUCrDKHWZhnVKRGznd8sOCuYyVq7G8vJx8IN7l6Q5KyVqLwNP0XicPKAbbacE7soOiuSIEda4Dc9dMYPsCtbJuoQmSZAA3TLZSXxRUMdfJhUkMdLXkzV7/1H2VLV+66IG8iywpgDn0Ww5sIwC0Atp9lYfhjiwMAmrP5AD+yy1fwP+45XIcaPej2rIdpG1EsBNwzEETYBt4yNa6jcA2nH8dOsZGmCoCM4E3VjHfAj/28rfgV1/9nVipVtDqMbQGqmoABcJtq4/g/9z9edy7+iC2rCxBtZUJErJAoznmI0b48pD9cKYLLAYAq70TlK4AZmi7FgzrSh5UA3NsoWazLllX1h1doWknxlVdA2sbG3j74a/Cvz3hvaigwMwYqArXPf0A3v13v4zxrq3QFQBVm972YGs35jllxVqT7pu8BMJwfggw+bPbuTAXpMs4YpUIdGQGeR/6LeBeoMtZjQwGK2X4nTTm1xg3/OB/wMkLh9l+NksExq1sPQRCYY5YQtoMsg8KMiwKAs0p51LOROJm9q2PfVckfxOwjSjejAUcV9BV2BMvIkHM7YxcDTc9bXUytkBn27Y4ePCgB1alCG7t1ingoBh4XX84+VFHTATBXxzAl0hl1mrDYHmB5gQcXAUkJkIYYP87JysjeRhrTSFNgHFKOl5kFslzjCkai8xQZCw4TsGjoJXFxcR0x3RyVA/LeuOOgHMrSzoj8I14zNLljglL+5ETzTMsGoWx2QQYz5RG3GcnYa4MStonJzBRVBIn/RVug+LXG5Vt0zDbrTyiPFI1RnqMj9x5DX7z+k/j8QOPgZZXUM/vAE80gMYzs1vLDUNLQveR0tWhGwWlwVmYpMBNCxw8hAuPOwO/9brvwbk7TwYBGLcjAAqqGmCVx/jIfV/GpU9fi3Y4xrblZfCEXEsCTzkrjzm8sy121pui0H60LVibvqqIMKiH9gQsaZcxUJEH6rbVaHVjDsEgw631sMLH7rkMp+qdeMfJbwCYMGomeO0xL8bPvO4H8B+v/jvQUbvArMXcolQImdOfONCv2xbNOlAPBoAOedl1OgXeSUGYIVjOW4Nm7dSjn0wtgFZMPDPciowHQihrqhpgbbIHH7vvWvziS7/dnCmfUiGaKmWZJNBtCTPsE2jLyb1QrJDBwmUbW/0hjYOwkvu6A54Fy9STnrNmU1oL1q9MVwTpjKzI9YL7Q8m453+EbDnDzsnLqjIepLZtzZ51zVDKnrpoFVtFKgLt1Dqn9bU1TickwwRFMZuPLM8Nh/nv1nLG2pIWQ5zaK2nuV+hc6qZMNQ3ntk3cfHICxGVkH2/afRqB8CzunFI5dmJ7cHYzKb2m1pFoblMfT/cOFIHVaf+F513lofssF5WYrpP1KSshTfo8fuZBrpNMgG22H8yYmJOf2AO6idFR0AR85em78cGvfQbXPX4zaH4OarAIhgJXDCgdKwFCdJETypQ0UehTxAK8CGAotGsHcfhgC37l/PfhX5z6egxpgEabM41VVQNQuOb5u/A3d16KJ5qnsLK8BLaHTRjA1J4SHwoYKRSmLi3Gyu9IcJo7jOZe2cAnZR2g5nkAdA1tDtRQjLYCJtxifbyGSgPH1Dtw3vYz8YZdL8VJK8dCUeX5RlcKr/vwL+G29aeBlWW0rd2bavcREzsXMdvzk00+/wEDBgZzQ5PEKl7+YAzx9SF2QpQkX4agyOB+tLDjFCNp1ULehwH0w2gBkYiM0tJMcPzc4bjx/b+JIRQae8hJZT+O4PZpynHx5XfkZzLHCvJhVu9daEEXZLNGSQKMRddyOpcLQFoCWz8eQHaW5mSFlPFBrsoy8rjSLTvbovgVEdbW1rC+voG6Nh5eZ9HKs5NdW6N7W1DNyYQDYE+UsS5lzcF9nLoGc27gQsM6oJcRT/4Zd9PEQpwBDhMmdbd26itoX0jTiDooqi+QlRXXfa6UHJAlFnJah3OFeP6M0kQ6o3/jIyuTtpSAtkRbpMEWLP/wTdwCWFJSa6HtXa0+k66DUqngk/lFMsT3Hf4UQsGsXxqQYjAqZdZl7jnwNH792s/i0/deiZbGqLfsADUAdAsobawhC5hs1xSdvA/GiAUmcgRaPuGQyJ9p3IxQrY3x3adcgA++7jvxooWjwTzGpNmAqipUaoAnJ3vwt3dfgauevgn1EmFpsADdBDAJM4SD4iz4UYIvi9TheE+hiXtA9QT7YwqNIgxzTKTSmOgGB1dH2KLn8ZbtZ+GcXafi7B0vwY5qBZX5mgHuX30ccxhi13ArFqtF/MHbfgzf+aFfxWRpyXgS/NYdOz4OaLX20cbmY/MAWKMdNyClfLQziKCtJWKUBrbbhwIzOA4K88y03w2PB1wLsoH9ktlPPhfcpw5dKjU3j0f3PIavPH0X3nrUWaZcFfNf9uoKSVNHx6Mj03RlpHncL/PStUpXliw9my+xcHOyIkpPidqQodE/lzI3tWhT8E7qkecZRHwtHyLul6JAR+ifIFLYeFLW18GaoSpCTobK3x4LvBvZUc5AqnE4y9KD7SasOoKfvygpFKUGglIIimDFd1Knr6TM2Qy9ROjWOC1LPkgsdc/2ReylT+XAZNNYAeC1NwqPIq1YgFif+yd9F+RKqIPTd7KqWS39WdKkkzVr/RdGKAey6NHC7eW/ymM7sSICqQpPj/bhP9/yBfzZrZdiY+15VEvbUdEyuAF0ZejyH2r3MsKH9IRx8c+CACELzubrORru9CR98ACOWTkSf/Se78d3HHuOOXO3WQWRQl0P0YDxmSevxT/cexn2YT+WtyyZgCzNgGLYTwAIIcHhG+3+uXMvO3riielPxmGILSumsdrzHvsvAjXtBKsbG9CtxnH1Drxj13l447Evw0kLu4xXABoPrz+Na568G3ceeAz3PH03vuvk1+GHT30X9qwewBsOewl+6JXvxl/fejHqndvAbQOG4Uvn4iUN840GAcSuz/W4haqBaqhAZA4XAQ3M+LiPvVseIi+QhLIWDY59yHGf+BzSze3+OiWJbF3KzikF6PkK/+eur+CtR52FgTLnJZOlRRoXOQszGB0zSKRU8ZXPc9ZuAVA7cTepBzBVoGWe3NwVNE1rhevj4mwt9EMs+wXodfoiZIg8XNQjHxO6mc3xq0opq8C6eW6UxFSZSnre5HdzKARHBcBlzVDKVtADGhL4Uu0la2n6dKIIYca5L5lIt07I1WlGgabUEQPfrqxmFjfHl1GqeTOu6A5DE8WWc4nhJf2ZSZVdd0Xc3mmAkwaYeS1ySvvk+c8p0/fllEKv1K6INk9YnnZHuJxA2YAomc++C9t6gFoprOsx/vftV+IPbrwIz+57DLRlC6qVHVBNZazeysTEupgmcsxpmdk8dyvr8JPZvKZQufWVEgiYbGBurPFjL3snfu4134HDB9vAegON1qjrIYhq3L/xNP78ts/jhj13YGnLPJawDN0ApLSx6qDh1jN9FbaHtbduNUSv+z4wulugjVz/CZD22/SUWc9eHW1gfWOCI6oteOvOM3HOkWfgrB0nYcdgC8CMCU9w654H8fknbsY1z38DB6tVDDHEwkqF29cfxgYmGA4qrE7W8duv+x5cce+NePzAHvDiPNq2sTxE/txlarXf22qcPmwPw2Bj+a+NsKVdxsqWHdgzOYDR8gBMGkyVPwlSzBTPc8zsLVhXOGv2U8Cndx0m55hTtgjiw7/mr9YaNL+ISx+8HY+c/zxOnj8MWrBKYJvAvxD1dd2dRSkXaJK87gAnZw1KRTojd7wMSKvJ1NtZc7Xly0hhM92TPhfvI9ksCysBrATwnAxKPJTuWSS7I25wvB4UoCB0kvaRiZhvmgYuIhk24txFnkuDUQZwMgBaW11lBot9taFTmrbF/Nxc/OGBkgrSpS1o99xNk3alBNvyCCT1RckSwZG5SuD0zVx96xylOjvrt+ZhSOfyhkJ6J0CpL3MBCDMpCbMqEhKkC7T48mTbM7SVaXF1IbICshr5FKBluM/eOWWCraaq8YXHbsGvXPcZ3PnULaClFSg1DwKgW21OLNLwJxu5oAmyiiH8RBV0WknjPo1nt2KabiA2QUirG3jliafhT87/XrzmsNMA1pg0ayBVQ6kB1niMj93/VfzjA1dgPNzAwuISuLH1kwEbU41VhhEUHecwDkFREOPKgu1cjwXLywkgEJnzJhRhbTzC6voGtuhFnL3teJx/1Jl41VGnYke9BYoqaGZs6BG+uvtufOaBr+LWPXdjNNdgZX4ZQzVnDr5SBL3R4kdOfRvef9ybMJ6MsXW4hMuevgvf/Re/jsnR29DaAzQYAGlG1bJ13WtjqSuAlQnGIs04evlofOCU8/CBM16HE7bvwvd85k9wxb77gC32E6AVvPwh6/Y3ZrEdN7ZKk3cB5ICNoj9wgtaCKyuZhkDaAEqzZy9++fz34zfOfq897lZ1BH1RCnHnxiFX8iwVhGXltXjJ+ZmUG0X5Tikz+zYjD3Oyd1Z5ME1uy97pNRBd+uQ41wjMO2ALrK6adVsTMGVnX8/3bqMo5dVDh9gokNoT6BreNA2WlpYwNzeHTN2hdWkjTUGCSCoywdSFdwHu0r3Cou7Omu8s1yaYUrpLIj1gBvCe2r5cfUj6sNg33UnSAV6ZfLP1ps8LEzsX/GBeSxDKTLCEPifsjRDsaFP2j7AGIhrjSROldXYEW9exPee7UgpPru3GL1z7UXzyzq+ima9A9ZJZY2xba8mZr8zE/Rxr7lZKR9a1FL5O8/bRimsHsH1uBb984Xfih099M7aqRehmAoY5QlGD8OXnvoG/ufMKPDR6Alu3zAON2RLEBBAxnAJOkhr2Z1aJHpCgG/elIU8EPdlJpZQyrlBorG5sYGNjjFPnj8Jbjj8H5x55Bo5d2AmFyiovLQ41a7jy6TvxmQevxi377sVgWWGxXsIAQ6DRUAqgClCDGgqEreN5/My5H8CZ88djtL6GLUtb8JvXfAJ/cOlfg044Gryxaj8pyFBMUPZIRNYN2tEaKgZOP+Ik/Pgr3453vfg1OGK41RyLqAjXPnEf3vr3vwo65VjodgO6orBnmZX/iAPc+cnut7By466iwGsSbEHhrBIYpcTbV7a8ZjTCrvow3P/9v4OhGx/BIiHYLDM0HFfrZWuC+9krkVOBbKmYFo5c9e3r1iPje+LkYlZQd3kt5r1+HOi+i/k2bTcDM8lW6rSXIuU8d+XUrvF4ggMHDvhv3PpTpUgETFFctg+gOnToEEO40xzouu/XbtmyBXVVh6oz0tyhdzQYEojiVk/tGNFaqWpBOihnAY6p6SxYpUwi381SZglQZ9GsptE2a5ppYDub3ijKBTxQhMK69FBCZ1RPlFdSE/NIp48cT3U62nJhEWjFWrUVmuzIdvOMjDK5e7IP//nWS/E/b7kcq/ogML8ERm2/SKMDP1ufH3vtLiZKMQByYtZaZC4tGYB0GjCPVjHXML7r9HPxK+e9Fy9ZOQHgFi1rKKrARHhs9Cz+4vYv4Kpnb8HCVoVhtQA9sbSQVF5cP5n2u3VM125HC4u/rsvJdgoBIA5gqyoTyDSajLC2vo4VLOJVh5+KbzvxXJyz88WYxxDaAmyDBg+sP4NLHrkOX378Fjxy8BkMFhXmF+ahuAI1drsEmUAlVZkoXFVVQKtx8vwR+ImX/SB2qRXQeAI1HODbP/Yfcf3j30C9shW8MQIrBU2MtlkFjxrsWtmJ1x99Bn74zDfiwuPPxFANLQib7YmVUhhUNb7vk7+PS5+7E+rInRhPNsDKnQ9glB1oBsmzlN33dJkzI2xOsnL95d9JwPWD4piP7TGVBLX7EP7uu34K7zvmHHPEpB1DRcrECKAbL+LkbG72937bXdTvyxGk9W3B6ZPRqQzp27IzTc5IkR4pETk5Izsi1bETedKpp8/jGMnNzYGt1hp79+4z+9At0AbApQC2sm5l59rBgwfZESf/0/abjFu3brWZwhpqdJVoTRL6gS+4W+MiM4UKMKfY3PVPYpU0ASLJQFlXUUp+RlmQvv8M/SUmdPe5KOXORMtYg/nJaAVAj1YKly7Nm6HPvZta3pSrk9pqkamhmiVKygJhUcRjkS9IBvW5IiOXnW3HarOKv73jq/iDmy/B4wefBK0sg9Sc+WoPuKsg+DET7fED4hS1dO3PJCAiEw07maBaX8frTzobv3L+d+KCXWeCQNBtAyIFUjU29AY+9eDX8I8PXIUD9QEsLC6ANZlToIj9vl/hRPD1OzJZzE+23gETTSx6wikClgdrIlT2lKq10TqajRanLx+Pd5xwHi489izsHOzw3aG5xRpv4Ko9d+NT93wVNz9/Dw6OD2Lr0gJqGgJkDpkgAqo6aP5VpawL3fCBUgQaa7z6sNPwL0//btBkgq2DeTwy2Y+3/fnPYd94DYQK7fo6BtUA573kbHzHSa/Bu1/8Khy3cBgICq1u0bbGEwCYoyArUhiqGnvW9uO8v/op7NmxhGZIaMDQbruNB1sLstqNWRIfYBUSls8oehnxtDxOEmyX5QDQ2gZevetUXPGdv+C/pEYwYJtuA3LsE8bJ1R3KjnYdIJnDAkw4ohe9ynvWWOjxqvV66wTQvzBDQ3ZCqN9LfKfNRmdKZ2gT8sP/LhlriTbh13GjaNtw7d27F1pr1HUNAkFVdlOccCN7l7Q1HLxlGwDWiigG2rbBcDjE8vKM5yGnV8Y6kgPQC7bepZV2hpd44SFlgDatXxQxiwXbC5qinFzanDWbulNC4E8+iCulv5TGtTulqXNNcf9k60UA/LJiwl4oRSQUMkxTcNywUjxLIANGIletkEzM9ghCC5hhLZIBUphwi8/c93X8zo0X4c7n7wPm50GDBQMObCDJAEIs2Jx2HYGt7xyYSW9PCAqBfe49gzdWcdSWXfiN89+HHzrlQtQYApgAbL4dywC+tvdOfOjWy/DA6BEsbVmA4grcsnVNWgXYTV5wrPSJNTxnxYKdokE2QMomtd+RJRsZSwoYN2NsjEbYxiu48Igz8e6TzseZW18EBRWN6+5mPz756DW45N7rcO+Bx8B1g8WlISoMQC3ZQBGAalN2VVXW1WYjmxlmzdtaiaoiVE2NC446HR84/h1o2zF21tvw4ce+gp/+89/GMUcdjze++FV470suwBuOOQtDNQSgofXEgngNoMLzo/1YHCxiS71g9gJbkq999C6863O/ivGRu9AQoK0AhYZZU23Zu5KLCiYJXhNC33e9VLBgAZcBarU5p8Ba3Nizii/8yK/i3J0vgW7ZWEUg1Cr+9F6KM54cCCXSKnvxHLG/RDuycy2VdRzKLcqCjELuaOrSKLPG2yG9AjCrx84X3CPTCnK76ylL+odDEFe+bNO/JbA9eOAgxuMx6rqyyjIFC9dUGICWnFJgwda4jA2xzp3cNBMsLi5icWGh6A5No+ZI/pUdvFnriApHj4nOKFnUkWUYCswCVg6kc9t4pkUv9y3ul9Z73bOUvkzhRYaX5fo+R1eRSfvETxghVFKBw4K2PFk9GiTFaTpXBBZxw3JrstPWw11AjYu+BQAFF/wEfOWpO/Db11+Eqx6/CTw/BA0WzcfGme1h90EhJFE/W+CWfBJH15Mph6zg9ihLQHMIw3aAH37lW/CL57wLxw53gd3Xc5RCRRV2twfw59+4GJc//XUMlwjD4RzaMdsujycWg/0BGVKBdYNvHAjBdQ4Eo80uWZpjAllDo8XaZB0YE85eOgnvOuE1eNOxL8OWeqvNZ3IoIty9+gQ+8sCXceUjN+OZ0fOYnx9gfm6ItoX9wk4b3GdKmc/h1cZdW1UV6soEb1WkvCWonYVbVZhvhjhryzE4Z+sZeOWuU7BUzeHyB76Os456EV68dCwUCG3bgrVGVRsrGQQ8O96LLz/7Dfyv2z6BxXoeH3/bH2KZhhF//MVdX8RPX/nf0R59jDk0w3VGGyxbHxwFxCBLsNs55DqrCECzHc0symAzRtRqoLUKWl2jWTuEHzj9dfjzN/0r6EYbRYTInsgllfGuWEulRikOoig/Eo8aXH0FGSrjayIZkqaR9UpFpOitjOl36aP1XnF5moWsiAMkU6p6aJMyUub1dDMi9YVdm/JtWV1dw/ramrFsicz3lpU4ulEqGQJ469B4Fv8ZUuXXDWRjQp54HVVevdFlVjPLpZktYpZFh3TzZ6rLW4VT8uY0pKiMDJ19wQEdOiQQlwB3BkWlk6IwSYq9KgE9VZAKmqjcLtJRdz0oiHdekkjmz2vZURmS8ExXtKz99hbz7VD7PVUC7l99Gr917SfxifuuQtNMUC1uBWsF3bK1sCS4xuBlJamo3050J6isYPXJyOy3pEkDWl/HuSe/DP/x9d+Dc7aeDAJj0m5Y1+EADTQuefxqfOjuL+J57MXy9hXoRqNtzJpeYG32dSMak0QpRCALAKABc4qU1c4VoYHGwdEqeMw4vN6Gdx3xcrz7xHPx8q2ngCDPPDcg+5Xdd+DD91yBrz5zByb1BCsrc9i6sgV6wmhabSqxn8Dz1pa1WjWbNVpWQAsG1cp8zo/cQfyG6NX1Q1gfK7Q4BqcccySOqLYC0Hj/yW8AgzGZTMDKnJpFdYWDeh3XPnMrLn3selyz++t4lp/BYNsWHDy0Dz96/a/gI+f+ITQzRs0Ymhg/ctqbsdFq/NJX/jdoxw7oQWWjmGE8B9oqMa7hVpEhv0fX/cd+KALImsd+6cEeKQnN5mtETkS1LWhxARffezOePO95HL9wGLwAtsyWtVaZk6WXONzPpeko6r2WY3C9FoG2A+/l6ZfSEZNR2MMvfpeojOVPnNABroTo4IHKiI3U+MoYER3JO0Xk1nUdlHFHU49HE7CetgMHDjDA0Sf13Cf2tm5zwVH5i4HIIqKYV0IaMcJxmmmg2k0z1fJEooUJWmW+MMGmg1lUv83Tob3PEkwBuPC+k1+2S6aZwc3Sae+UdkrwlNNNWriyhI4+mpk93XLyCkXolww/pMAiJpaGOU7UbeWpKoWaFPY3q/jTmy7Cf7n1Yuxfew7V0uFQbQVmgq4AXQW+NLI0eFLMntJATYS3km844LPJ0EIf2oedC0fgt9/4A/jAi89DTUO07QY0E+q6QqUq3H7wIXzozstw4567sLjFuD6ZCeYj9K7gULGR/ypUw64XhfJik0vLHlYBGbUT7Ftfwzbegrcf/wqcd+RpOGPb8dhZ70AFZdtrwmoP8QYuevQGfO7Ba/D13feiXlJm2x8ptM0E0nqDOwyEg+BTikAVAcq41lRlLbfafthAEdrJBKPRGCuTIc7ZcSbe++LX4RXLJwMgaN2i1S0AhqIKFdVo0OK21ftx0f1X4WtP3YAH1h8GzQPD4RCD4RDcEFQ9xOpz+/B9p78Vv332z2DUTMBaY1jVmK8GuOjRm/AjX/gzHBxugBeXgFYDjfaBUZ4rlQJV1n1utDZnR4VBt4CqNdtgOhNsxXYdmK1rmtkdm6xAAwU6cBC/eeF349+/8v1GGbFeF6e/+cAaz2+Bzw3fp9Mrfh9ds8g0soUiBvrOspjjsFQOZ+pKZc40AlJDzcuByLoObJ5KjyCbYqUY1BVHiWoqK4V8FQUS5rqRgVa32Ltvn1HuKxskRYZ3CE6uJFuAHNi6iD5nXrdtCyKFbdu3FsQjAhOy7PjwJwe2nbW4xNXZBwjT9mf15c1pOuFlP2PK9dWeRFPLIUdrDxgXaXJAN4Ny4l0jOddRT570uDNP19R2pSKA4/7uFNopIConBdx4O41pT3ryk4l4VRjxBH939xX4/es+g8d3Pwi1Yzug56C5MoqkUsZypNAsghGIiajwmmvYzkFWsJrXrIxQICbw6CAW9AD/4hVvw8+++t04vN4K5jFggygUDfD45Dl89P6rcNnj1wHzLebqBWitTWBWrezYuhpjrVu65o2xRZYV7F/nRieGVoxxO8GhtREGbY2TFg7Htx37CrzluFdg13AH3N5c0+oBGIQ715/Epx+4Bpc+egOeHD+H5aUh5geL1mDTYMVGGWCIjwKEL9mQBWtSZA6RUGT251YKlf0Y/Gg0Rt0ovGT+OLz5iFfgDce8HEfObUfDLVrdGDdxVXvF4unJ87j4oa/hkvu/gjv23471ahXLK8sY1nPe/QoyY8CqQlVXePbpZ/Hjr/g+/PpLfhLMjKaZ+G1bD609g1+89h/xxQeuRzskoB4GC9Z0nlE6FMxH7CtlvkJECoAGtQ24baHX1qGqeXA9ALVmWYDa1h8piWg8ACKzbs00wouqnbjph/8Qc9XQjJ1JBWXPn+6ArZw3WcFfmFSbNCCirM4bkhZdkFFpTV4tmUVWRfmFNpGCbSIj3Iug6wp6C23PPpXWs//DXo8pdiMDe/eZIKlKVeZTe8oCLglwtXUosiG9+/fvZwdCLlqubRqoSmHbtm39QjohMgXTkCB9TkhHs7Q+OuugpWSla5AdwHSuTD+ShXXOnLnu6pDlZyzSTVm/olxPb0K/1Pg672S5PX1WHM9M22NaxZiV1EaObsWGcRaadAKoqV4BRPMmAL+TYxZsdQuAUCsDlBc9ciM+eN2ncftjtwIrW1DTApQFC10RtEqjR+G1ZRIcHDXC86ohhJyrkAhaKfB4HfWkwXtffD5+7bz34NRtx6PRGpPJBkhVqKsBxrSOTzx0NT7z4FexrzqIhYV5kFZoJ9ruGwJAHJZ8O2ALwK/tWWtIOY3fHhWIFswao2aM0foExw534g1HvBSvPfYsHL9wBJbUAqwfwAQxUYU97Sq+8uxduOT+G3Hb7nswojGWVhbBqrIg23pL2yt6GgDLL/AYQWK/2mCAUgGqJqgK5tN8kwaHVdtx4baX4t0nXoAztx1vz0oGJu0EYz3x5RCA2w7eh0/cdSkueujLeJKew8LcACtzJmiMwIAygViorXBWBA0yxzNWCvse34sfOes78Htn/zwYjPXJhtlapSqAgK88fiv+222X46qHbsc6jdASgwZDQFVQgwpU10YWgMHcgscM0hPUTNhRr+Cso07Go/uex0P7ngMGCrptQdDgVvsPQbj5YaxRo4ioAQHPHsDfvu+n8L5TX49J09ptQ2y3Aak4WMpNovQiEXFulc2Ou7ZkhUpAE1ZcJBsFiMr14VIMRyf4KUN6GUNE4GHqDhflBAwWykjURidfCvRFBUaUZV5x+jh77du3D82kQVXV3ro1QVIms1eeHA3OsjWHsLP/ZmXTthgOBti6ZUsMSLme8Lc5sPXGR8f6TRuZqyK37jnzNUUT88whOqTPGvT5XBpZtCy/D2hfoMbZVU36n89WaGatx9wI7RSxVYUwnmFQE+aOBj5/yR6cZZN++FAAew+HsgLx6mfvwgev/RSufvBW6BpQc8sAKnDrY5PhtuCkI+dcyMZcteNm13IdQUqrcNiBIjAr8GQEdWgN5xx/Fn73wu/Ga48+HZqBphlBwZxlzMT48u5b8OG7LsXj7TMYzNdQVJsToOCUdxZ84iS0WM92Xc8qBOvAbJ0xf4G1yQjjZozlZgFnbT0RFx75Mpx/5BlYqZZN+Wjt2b3ACA1uOvggLn7wOlz3xJ14duN5DOcqzM/Pg2hgt6vYqGIjYY1rFPbIRmvVuy4kq7ErspGYlQKTxkazjqEe4mXbXoy3H/tqXHDkWdihlkEgVEQGbG08yFhP8PDG0/j8I1fj4ge+hDufvwvNcISFlUWoagAaGZ1EkXFRUwVjfVYWYC2oaXtkV11V2PfU8zj3+HPwH8/79zhR7QJrYDwZQRODqALAeHD/k7j5+Ydw9ZP34JGDz+OZg/uwQSMcHI+wMBhiy3AJR207HEcuHY4zdh6D07YfgdO2HIkT53fhyufuw/s+9BsYryyBJxOrBIovLXn+IQ+gqqqgN9bxxiNOx0Xf+2vQmu3n9/JfA0pY1U+SF7T0Jhk+FUsOcCXYzuhBS2UiMrIxKrtLaLgV5RW3SfaBraArT26pXbG8KkUgp9fBgwcxGo0M2NpvGSv7n7sPdopwI2u7RusAt20azM8vYGVlORDqSUu0gZxU7TwSg+BltwSlQFjfmmxuAHLvI0D9FlyyxanVlxp56RUFSOXc4En+aF1XrBFKkC/riYGuWWA9Uj8Ek3kNrwOksi7PnVGCGGxFGSTzhooiKzbqW/ePsfq0bqERgPbe3Y/j9677DD5531cxrgEM5qBoCGoZTOZ7tDrDU5J2ggNbpzi45+TbQszWyWzWFHltFadsOx4ffO178f7TzwehxkYzwqRtQVWNgVK4d+0x/M0dX8TNB27H3PIQhAqN/eStATFpYQRntesyFvULE9xaZ4xGN9gYjTBoK7x82yl443GvxBlbj8ex84dBsTk6sdUtQAotNB6Z7MGVj92Cyx+9Cd/Y+yCaaoLFQY1hNQRr66ZWLjDI0WiJsYfc2EVhAOT5g5SCqk3iSTvBpGmwvVrBm456Od7zotfh1dtfAth+W29HYDDmqiEGaoC97X5c+eRN+OwDX8bXn7sNe8d7MLdEGKoaxJUJFmM2H+0R7mkHtCGIyZDn9iEzM1StcGjPGrZU2/ETr/wh/Mhx346KK4zaCSbNBFVVYaBq64423KDRYKwbrDUjLNZDLNYLGNJcxDdat5joBlAK7/j7X8PVTz8INTcEtwFk/TGdZPhOMQUrp1IY7F/Dl//5f8BZh52E8aQBKeqCretqxPOhFFSaXjljIQ1JlJG908pJy/LGBcclZOvNLP91QNqVN+WSUi3yQvrvdtvSsx9KjwiFACI4JbeT3LbRTwdxra6tYn113e8nJwpLAQZ8XT8IbDtwYD8bLUuCbYuVlWUszM93OmLzYMvRXX7dFQJsTS25wKgS2OaubzXgekJjojaRtcuI7jnFje/VLLNbm+Dk4Gwg6y4q/AjWazk9pzceU0XPd/y25nnfmLjI4riskO/J1b34z9dchL+4/XKs6QNQy1sBGsCvrdu1RCP0bFmpNi+FCNt/3Mk+bAQk2XFhMmtYen0Vh6/swi+95jvwo2e9EUOah+bWLLkMagCEZ5u9+Ovbv4Arn74RtNRgbm4OHOKKOm3xbRR9E8AMFkzM+qfWjPVmA9RWOGlhF87Z/mK87thX4LTl40E20MkJBWZgb7uKLz9zJ77wwHW4+Zl78Ox4P+YXK8zVcyZ9a7YYmUAm6wK2wObVPVsYM0yErSOzMgJtrEdYnYyxTPM4c+VEvOPE8/DWY1+BYwe7unODgXXewE377sZFD3wZX3rsajw+fhI0T1io51FxbRSlNliIvl+Maev7AsoKMHF6k/bVmD5URNBjwuredZy241T8y7Pei7cddQHmaeDbx6zBLdtv9apwxi2sImZ71IAxQKTQMqNSCh+791r86Md+H7x9C7gNa+YGaIMiUJE5+tIFSvH+/fiJV74bf/CGf4GJPdDeWETKKBZ+qSX8W7pcDEhuXmblg7QSRdvclW657APblLI+eCvKa2kJT5NdhOgcY0Omze8PlcF0mZwDWt/gQgMy12g0xsGDB6GU4Rv4MXSuZPL7bw1ZBNq3bx8DiC3btsHWrVuNsJAdxXF7/IeZo4Z4keEpZ/+OZm6MyfJNHHdoCc1qUVGSHPiXmdwI9LgjNgPofdHVabpZXTs567jjnnTvSvk7SoB7I8p14zdzgzmZhSZ/aUK7GmVwiNlOorDabODPbrwc/+nrn8Geg0+Ctm4DVXMZd31cEsS/LN+5IbST1nc1GxmubDo9XsM8zeNHX/ZW/OJ578Fh8zvAYLTNBGyDI9Z4hI/cfzkufvxrOEj7sbC4CD0JCgPB6QCcWANWrKuw/QMMuwYEMLfYaMdoJy12YBvefNQr8YajX4azt58AhTlo1mjaBhrmG7wNGtyy/yFc9sjNuPKRm/HA2pOA0lgezoO48uDpvvPqMcEJBS8cLF9ru7TkrDVmtJjg0HgVumGcseU4fNvR5+DNJ7wKZ6ycgAHmAlDZIxJbtLj54D24/KFr8dUnvo479t+HZjjC4sIQigZoxwy0Zqz8oSJOOfFg61iHYtB14Iag15kxNl/eUZqgdI2NZoz1g6s4eeuJePuL3oDXH/tqvHjpWGyrV1ChsodhUCSiFCm//qYZaLkFmP0e5JEe4w1/8bO4c2MPaDBn+8mAH7u+VDa8zSozpAhoxjhML+HmH/1j7KgXoLXzqKfLOuK+TwQm66Rmmk2XmV1voFdBRNFuknSNLFl3wLmyLPN1RJpBKL8rKgJIdeiRlSYPercbFQweSc+0tjgKJ5MJ9u3b5w9ucRatiypXyi39WKB1YMuwwVFsNrQ3TYPt27Z5sJXUO5kJOAYXw1AABPl0VgA1BkeC7p0mh3f9+3qtwJsCdLO4aGRbnUa22SunkXqlQJQflb2JtRQA0TdtS+vFFOURylEGaE36zba1QK9wQTHb4wTFRFB2UhIIY27wsfu+ht/56qdw37P3mi/yzC0AbCOL7QYLJ2Tjqcbd9iQgTzooUJ6fFKCbVdRa4R0veTV+7TXfhZcfdhIIBN00ZnsIFA7pDXzsoavwqcevwl7ajeWleVBTAY1rC8L3boXuwxT6mdnssVbWRapbA7CsCUcNt+OMlePx6sNPx2t2nY7DBjvtGqAr0ERK7dVr+PQjV+NzD1yDb+x9ECOaYH5ugKGqgQbG8uJAk//YuRMCKt6Mb1Zo2VsPmjX2jw9hPJlg12Ab3nTsWXjXiefh/J1nYkBzXkybqNoBWrS47dD9uPyx63HFI1fj7kP3YaI2sLQ4j9q6iXliQKvV7vStgiCl8Jec21j8xz5N+AhDsMYZ1MJucVIYTUY4tHEIlaqxq96Jk7adgONWjsUph78IR8/vwrb5JUzaMdaadRxqRlhtN7DabuCxA0/hiOFW/MxZ/xzEhFZr1KTwxzd8Fr9x+V8C27ZD68awtVVeoBRgA2dQW7AFzKlgzzyP//Xen8U/e/HrPW862g0vZmYaJX+jqcVJn/XP09SCLV4F8IlISMF+M/IwI8/S+mYCWzslvLowi3WbTRMbJlHhydU0Dfbs2YuqUtEZyUCYS25rof9O9L69+9gt1LuPEDRNg507dmAwGCQNDGgbdT3105/TlnqjjjmsMER2QE+eacFUHY0vw0jT1oRdPtG0QKt3z+R5uPTc04aYeVPGncrEM7iebUGiXglNOcZ37hny6X06OfmzVacvQgCdxx3bd5rNGquxKAiVqqBZ49JHb8Jvf/mTuOGJb0DP11CLW82HxJ2wBcCkDfB2Jgoj3n/HAaMkWdpAi8UgcDMCRiOce9JL8RsXvh+vO/oM1KjAurUCv8aEG3zq4a/io/dfhqdoNxZWFswH4VszEZSc/Gz7mU0PuLrd+jMUwFpjo93AZDLBTlrBqw47HW846mV4xa6XYHu1DWBlz8zXdnsBgaFx64GHcNED1+NLT9yEhw49geHSELUagLiCdttRoMH24AkPpQQDtHa7AioyRpkNvDKyQaOZTHBofRXzPMRrd52Gt7/4PJy363QcUe20vGCsPaUGAAiPTXbjC49ci0sf/ipu2XMnRvUa5uZqo7S3tg4Hrpa/tDzmymjECRuFzowsIwJir6LRbDx4aTu21uBkv6e2MmdO6wajdowNHpm1/QYYVEM0GEOTiWGhqoLiGuPBGMNDQ1z1A3+Lk+aPQ9ua7WbPrh/Aef/tJ/DsnAFU5YRgRUBVmX5VCqhhzVdz6Io+cAivOfIMfOV9vwHFQuG0zGHtI9/WDvQGjT/iZTfGUQ9GCju8K7Yz37NzuAC2QvFPo5RTAO7Lm9YrRE02f1G2R3p0jn+SelMjruSpLBhpANC2LZ7fsycEB1ovRlUZj45SIbrcAW9t2kd2M7x1v5BCVVXdShzjM2IXMmf6KNMvAZBjBnA0hMG1v7JanCuLO79do4rReJaAXN5c+Q6gO6CegpdblKPgPN8M4PpnnGWX/msGb8ILuYLm2w/IxUplVJ/EQdtfcq8swbpuLaNeu/tu/M6VH8GV912PZqChduwEtbVxxaoAGr4qaTYCPv6I3T8U9ssq5vCFHIPuAMw2HmyMcNrhJ+GXz38vvv3UczGgAdA2aNFCqQpjNLj06Rvw9/d9AQ9uPIKl5XkstgvQY8CcqEQAabuNx/GC8pR5V7ECGBqjSYON9QlW6kW8ZssZeMPRZ+Ocw0/FUcMjYE51YrDWIGJ7VnGFfe1BXPLoDfj0fV/FjfvuxUbdYGlhiOVtS9ANTBQ2t2asbEPdljEXtGOUBtN+7b6JqwhcaWitcWhjA3qkcfLi0fjnZ7wD7zzh1Thl6RizDooGJvK2ArjG881eXPX0zbj0getwzbM34/n2GSwuL2B+ywLmsQVoNXjEgDy0w/JSsOocy2QkLQeeiR5bnmI3zl6Z8tqMOc2JAVjXrz9ZiwiqYizUAyyqIfy5VsRgNQ/Y7xczCLoFJgPC/vU9+PiDn8fPn/FjABn+3bWwBW8447X4yO1XQG1bhprYc7aJoCsrD1xkN4W1Xywv4OYn7sGt+x7FK7YdbyKTYRROBSqfJuc6pBTCT+Kc+JxyzrGETbfgpQFYfbO9BOg5mdm55HgmUJCVj4mBllt6KtaDbjelNEvQ5czvnFOxqsxXphxdzn0MwG9jc5jm+LT2MjXVVJAfM2/c2oGT4CnX2vzTTk+IDvCNcvI47u40/7R1VweQkebl8jkGnsVVnJSXSZC1qmWH+fY5d2lP3W6Ac66absJod1xMVsEtQ6Jby5M4qQbUna9+eMU2rwhgCwUSPNjBavFyK0+tKlRK4cFDz+K3rvo4PnbbZWjqFtXOXaAJgycIwTAQ3UhO2lrJ6xmGol5iKNs3YsyUtTqaCWjtEM7Ydjx+6s3vxntOPw9L9TLAGqxb+7EAjS89eys+dM/ncfvaA1jaMo/FxWXwxFpmCiY4Rsf9b+aKNoBrrdhJO8FofQN1q3DS4jF40ymvxgVHvxTHzx+OmmqrSWswa5AagKjGOm/gxufvweWP3IIvPnw9npjsxnBhDnPbFlGx2Z4zadroQ/bsFEC7gTeE/Th+NNHErABGi43JGONDG9iiF/Duo16Bb3/R+Tj36LOwqBZNb/LEK9h79D58+ZlbcMUjN+HqR27FM+vPop4nLC3OY6s6DMQMPWaAGj9E3rUr2STSkSg/PaIDC2J+YwEe6ZZud8AEO63KCS5ytFjXOhtuodA9/jnYbCnSrcb88hz+/uaL8aMv/l5sr1fMIUAK+NfnvB0fvelSUw5RdH61OzyFfeFGbqiqxoQP4m9u/zJeccEPm73gNpjPu0DlXIraHVRNaf1GbuGCF8zIM5s/2eKSg/dcEJUrJyQSMmsayJrMJo9YSollfqwESC9jyaBKoyDiNnRpjryEEisSwykuJW1XDPwmcp58XuO1Y7N2b3nCzW5Hta9f/k0vKWxZ/JvSk9c/qJDArbeIts0AjHkCI6q6FOSYInUpIBmUUr6kDBL3ORo6pObq6RbbmWzdggo1CTnTd8kqugwbK1PpxOy49JNSnHhv2AaY2KSVDRp5YrIPf/L1i/GXN3wBa2u7UW3diYrmwOMWLdzRdiyEoNNArZWqEoEMht/Ow+ajBH6XbUVAZT4OTwf34vjFXfilt/4g3nfWhRiqBTC3aJsx6moAKOD6vXfhw/dejq/vvR31coWtW1YM+LO2ez6NA1w5xnWgQrBuJEKjx9gYTwANHDfchdccfT4uPOqlOHPbizBHc2arTttA0xg1VVBUoaEWtx+8F5+9/2pc9fQ3cP/Bp9DWDRaWFrBQLYMnQDNp4b9x631pfhOM7w8V9ZntFiKMJhtYHa1jWc3hlVtPwbtPPx+vP+ZlOHbxcC/0tFWO1jDBtXtvx6fvvQJfefRmPH3wGVTzjKXFBSwvzoNY2SMMDcDCBjezV0A4FTPJjwL/snwTQXUAWiDi/1ivcmdaq+BscZ4OCvm9asayDMNzqgXmqjk8ve8JXPzApfjAS97nXe2vPvJFeOlxp+Ab+x4Dzc8behUZV7JS5p7JLDMwQzFAEwbml/CRu6/DL5/3PmxXc2g5KEFwrexZOsrN0ezJT75PMsI5EsVhbicxyhYiOJZvvpPQfd6pPCHYCyQhddwfikd7ajs8ldnEXnmZxcgwCbuyrVC0AVXrPXFKpeuraF3c9k8deI6DJdcjnCMrTqSK8ECiZkCfTn9DMpbPyn4cnCvOZ8gNalYT6VSUa0gMrBmA3sxiv7OmI3pTUmy9OW2rU6fnQY76ytBKmQHK0xopsHHRsdWQK07QMO1K17XTw8E1G5eo1sbdWpHCgWYNH7r5CvyXWy7B43ueAC0vo9p6pDkgnhuwDQuOv8cagmDCZ2T8S9lMOKtFOfqYzBaW1QPYNdyGf3f+D+Bfv/qdWJnbgknbYNxM7NFrCjfsvQt/f99l+PruuzDcWmNx6xLQABgZ8PYfCrLjrltzq+yXbzRrrLcjTCYTbFcrePXWM/Dm48/Dqw47GdvUCggmzWQyhlYERcaF/vRkLy55+AZcfN91+Mb++9BWDeaX57CwZQCoebAG9MR9ace1Ed5SM/ck9sIEDdt8F7fF+toauCGctf1EvOuU1+KtJ56Hk5ePQAVjxbv/NvQEdxx6CJc8dg2ueOB63L3vATTVGCuLc9ixfQWkFfTEfpSALE2u83Uishmx9RVd3edSnnD2aTp/JI8U6hAC0ckYCdQdPDKMa2gfaQznF/G3t1yE73/xe1Aps8w2UDV+7NXvxE9/8r+Al5fMOnll5md6RoVZswao1SBVY+/+Z/CJB67Bj73kzeBJG6KXCUKecV6EFdYTQ674bxE0kBxGBHQtZku7i7HwOIkw3qnCQ+TVW3iXhqPQi15BO3WpCTZXv/yRiknHBs1Z4aIv2IMdZfPklxhdvRTmnTM4KHyUwPWJj+fZu3cvuy0/WpsgKVUpHLZzR6eSbq2BRrLQHtBcdETaAdkH9rH4OHI04frAtuB+zfModRgjrSuXJypzE3llntI2IxlcldPcO/RE6WLNEMj8FGMxHTYLF8vbngAyuEnp3IZ2yrnzCImw3o7w97d8Bf/ppovw0O4HQUvLoHoB/oxiClZY9Nk4q1jJeUqeOPauZgIZC8KxhqrMJFg/gMMXduLHX/4W/KuXfxt2LRxmLDdtPuLOAO5efQz/5/aL8JVnbsTcNsLi3BJ0Q37ZL7ictLdEHMhoaIyaEdYnIyzxIl6+/cV441GvxKt2nYYj6x0wgVwa0Nocz2c/8jHiBrfueQD/8I3LcNmjN2F3sxcLK0MsLsyZU6esXuEih73i6mUYx9/T0wTN2na3CcoZjcfYmGxga72Ctx/zSnz3aW/Bqw87FUP7WTq25uCYx7h/9TFc8sjX8PmHrsGtz92DCW1guDiHxeE8qFXm83SsA+BTGAzPCpI9M0pdrJxzeNrh4zRjUPa74J1yeA+3U/d9WOqAGW/3V9uDVRRh7fmD+Nj3/iku2HUOtGYMqhr7Jxs467/+G+xZbIC6Mlu5vHVLMFojoGzAlgvKazfW8KLtJ+GOH/gduzYfto7MouaXPG1FmTtLmcne+LA0mAIjzVyP9KwRgo48yzXLDhEAkQztYk1yvn0krwJY5WR7niZTxL59+/13bUEw5ySTO8TErueKvdu1X7uw1XnhL/i/07AESb2LD908Tmh6V2RQC5DV2gRQy7OAixFtqaB3nc6cZ9is+poZoAyAyHeU5hX0iCZ4WkpXCuRRrTJbVKDIUwiWyLadELV/6r6zTIFlTToIPgm0ISiI0HCDz951PX776n/EXc/cCywvAlu3A7o2lhAZ89A3yWucgmZ5x+6BfaoduhpJSdqAN4/XsFQt4Mdf9d346XPfgcPndxp8ahsTjKIqPLbxLP7qjktw2RPXQi832HrkErgF2kmIEnV6PRHsRw0A5gbjdoz1yTrm2yHOXDoRrzv25XjFEafhtOXjUaGG5hbjdoxGmzN6azUEEeGZ0X586r6v4VMPfAW3Pn8fMNRYXp7HtnoFaAltw9DKbDVygU3eZSVkoOkC49IyFi2DKnPi0dpkA+16i5cvvQjvOev1ePsp5+L4xV0mCtm6ulpucc+hh/GPD16Byx+4Bg8cfBSr+hAWVhawtG0A4gVzlvOIATJf5YkEseMFiX3+o/YxgHYsL5YP8vNEhFBFGYJ1lBP7suDM5GB5E02uSEmUeK4AqAHj43dcgguPeJWPOt8xXMJ3nf16/PltnwMdvsVHzKfhku6gFZA510AP5/HQY/fjumfvwfm7TjNueFsoC3rMtBVPxBpm3FFBHjkB3wm24mTcouklv8PDUdfEPSjkT+IhlDSG/bVR9ZGcmLrFR5QXXSV8yrm6kyW9UlvSdnToz7mYI/61txbblPQtE1DHA2fuOwdiJ1fk38/wcqdVboA7i9tWcHU01KhFeW0j85xRALYCMHeeFbTELFMTxSQXrOvwjqOBn+nKyZB05sgB3+T1Qg4MIdFuqS36gCe4Mwgs01cKDbe46tFb8Vtf+xSufvhm8NwQtG0nwArM9qsyjh4KbcxZ9rIrwRZcmO0HvAHAWFxcA5PJQQy4xrtPew1++4Lvxxk7TzCF26MMVVXjydEe/PXdX8RFj16FZmEVS7uWzZeCJi3ItsspAMpavxqMcTvG2ngDC3qAkxePxoXHvxyvO+blOGnhaBDMB9Nb3ULrEUgpDKohqoqw1m7ga0/djM/edzUue+R6PNPuxvzKPJZ2zKNCBT0xH1lQlThfld3GKNOrzvfDMHNJM/wHEqAYo8kGDqyPsNjO4U27Xo7vPfdNeNtx52Cg5ny/HtKruOvQo7jyyZtx2SPX4ranbsekOoSF+UUMV4bYju3gVkNPGBoTOK9EAn32y0cImOqnWkYKITPX/UHCFiiyAiXKnXKEfZV5R+K9fOz6ykrCKF9KtlBQNQOD5UV8/qFr8OzoeRw5f5g58YoUfvJVb8eHbr4Ik8oxqM2XKPNGDrL/+lRbM/7bbZfhvLecaqKROSh3Zs85/L3rn+JZBUIm5oAl6ynrNF6gL6WJKE5WGqcObd0xTb1jQFfOeplQujYpvqYmj/X6rFLjpwGcLOROWoVk/QCm3Nol8Foi81SwdZn9YrbN65TFOJqXBGgEwJWTw3xP1Bck6uh+3i6yxIUV6zoiG/iUWKJh837UnEiDyfVAGhmXzRuVbyadpdJ2k00tNcZ0DcEW6vLFM8ZMRvdO5uykTctMckRXSemhkCfV9Fx7nAWrrSuSYQ9pIIU7dj+AX/vK3+Oiu69HOyDQ8hYQKnDLAIUvn8ABreszr0OwcDvZfb/MdlsHW/euBlj774tyswHVTvDG016L33z9+3HuEaehApkvtNg12WdGe/Hx+76MTz9yJfbWB7B0+BIG2GqCjriF1q0/XB9k1pvXJiM0kwbLmMOZS8fgvGNehlfuOg2nrRyHeRvoNNZjjJoxiIBhNYe6Vphwi5v33ocvPvB1XP7w9bjnwKNo6xaLy0vYRjuMJTTR0Nz605KM4kJgjt11RKaNmsOeSgKj5TH2ra+CV4GT547BPzvxFfjOs1+Pl215MRQqaDR4buMZfH3PfbjiqRvxtSduwUMHnsDG6BAWl+ewuDKEUrvQThpgzGaLDwEmCM19BScwZth/Hbv1Z7kCHwmFWYBMJofgN8eXCYxkvUeJ9PSPRb2U0OPb2Z3XzIxqMMDz+57HJ+/9Iv7NS3/IHOUJxmk7jsV5x5+Fr+2/B7S44L+gVtpWyMzmqMj5BVxy29fx6IW7cezcTjRa+6YpS6uUl85Y6ZwFABcI1iO7O+JVzmcnkDh63zEhLMgG2Y08uHLSd3kJ36HF/gjpOh7NmJwOzwgmSVSHqPzu5c0Dob8FvCjZe7J0NyZaayhl9sYrcs8VaO+ePWzWrTSYgaZpsbg4jy0rK53Gdq6IKQsDLTHAmyVJER0BH9hcAmB/QFEymIkVSeI5Z9rVXTsNaWR4t69PapHsNHkxWCmpEYBk6Bd0uELyPd/VErOXSOJduUDnfNE+KzKmE/G4MaNl910d9uuj7gsYj60+hf9y9Sfwl9dehkODNdBwO1CZIwb92io5ALEI487lJcBZSq5atoqgCTBhUKPFAfBsLOTJOmi9wRnHnY7/8Pr34y2nvMIcOM/2+D1S2Nus4qMPXImP3/9F7Kn2YmXrFlRVbdykzNDKrHW2ukXDLTY2JoDW2KW24PTtJ+GcHafinMNPxQlLR6PGAACgoMFta08OquAO2Xhk/Rl84cEbcMmD1+CW3fdgo1rDcGERC4N5kCYwm4AxqgLfUXq6E5TdCywGwa0DtYSN0QSrGxvY3izidUedhved+Xp82zGvwgDz0NzgybVHcfXjt+NLT38DX3vuNjxx8AmoirE0t4DhwHwkgdmsIzNzUKCFIi3nqOMeQXH0ImLnWCuLX6SarhtlFmnCy34Y5uhXAE1ZjC82kQlxNfZeyBoGoLVbmABXhI3JCKcMT8QV3/d/MDS7JzFQFa546Ba85+9+DXTc4dCTFqzMOi8D0JbZ3TeBWTMwbqFQQ+3Zj1//9g/g51/2PjS69TO/UoSKKm/8lNcvuzHEobmJfMkp1MKbECm5HKSQ6yuGUL5lP7qbgmfRPY3e5oyaHus2FzyaXun20U3ogLHELRkf4lpdXcWhQ6uoBzXIGhjh5CgKp7KRWLONLw+d092MTiu0uBPPMzsgJL9oEqOsn6qUsIqbQVP8+NHz1K0saY802QI4yzIz6TplRmsoQNR6KQHiBciIMaO1bi+zcnXEPdsNGik0wlct+lHmpbS+OE28jiLLDntltY0kqZRCpSrsGe/DH1/7afzZ9V/AgfW9UCtbUWEr0LYBaLXrFucmNcwQ9BUSgpJgtk64r8+4j3TbfaKaoccj0OoaTjzyBPz8O78LH3jp6zCkOQPAbD6rtr9dw8WPXIePP3ApHm2fxOL2JSyprWZdVDdwhxqM2wlWR+vAqMWu+a149bbT8JYTzsNLt52EYwY7MaQazIyJnmDcjsAAhlWNuhqCyHwA4Nqn7sBn7/kqvvTkzdjd7Mf84gBzW+Ywp5bAbQtu2Jx8RQxUgFvsNP1Nvs0mjEaDtJmw5jGD2wYbGyMMVxXOWDoObznzVfjB096MIxeOhOYGj64+iCsfvQVfeOIm3PD8Pdg72g0FwuL8ArYtb4GCMpHhEw2Q9gArhkJoOpKPUz5K5nOqTAoJK53PlOTzJUb8LgVmae6nTxzocJLGNsY3MICxjNb3y2IS9D0jOjnHGC4u4s6n78alj12P7zj+QnMsJAhvedHLcNjcDjy/3kANCK0EJefls8sdyga0UduCl+fxF1//Gv7N2d+OOSgfesAcTYruPE4UBP9aygNO+09EEMeTWvQXIZIMqXwjhj9SUsiZyCItyM2++BWXVo5+1BTHnIniH7NT5sWUpcJUYXQappmOZUXHxw7ZPuh6cl1Cw091AKLQAjfpA4BmiJYV2kZG/T6LdpEBiRTkZ9ZM0s4Qlq0D9Chd4oKeWl6e3O7lu1ECPBCjX2bwOOnegDbT6ytdHPdl+g5AvLldKE9RRLhtk4aNWrfuYoL5eDsTYXezH//j2ovw3792MfYfehZqeQeqLbvALQw4u72N/mB7AhQbN2llanJNJrdHVsF8Ao60CXhrDWOzMkCk1w4A6w1OOeoE/OTbvx0fOPsNWK4XDbHMUFTjQLuGzz1yLT75wGV4uH0Sw+1zWBpuASYtgBZMGqNmgvWNDaiGcPz8kXjXUa/FKw57Cc7eeTIOV9tQi9OcNtp1Q35VYVDPAWDsaQ7iqqe+gUvuvw7XPXEbnhs9D8wRFpcWsUVtMWclM4C2AYkPxjOsR8AKSqe0ie/32Chk48odNxOM1ibY2S7gzce+Et/3hrfjDYe/FBqMh9cewz/e/g/44kNmy9D+yT5U88B8NYeVhXkwK6A1B+pras1H2B0f+GAmWJD3I5+IaS+SxUP2gp4d/qZ87JkIae7kR8Zdl1Fk4yRxhfJIzM6n1li4P6P2uSAkQRKL9gBg8qHuqECot9T4q/s+je884fWwn8gFSOH/Ovcd+N1rPwIcucN4C23bXV+T3TNGLUDaKJHtsMajux/C5x69Bt9z4uug7XGQQfkSrS1YjkUPZApMnQHKA1uUP/ktlzbid0Lm/VNdafHF6gqYlaMxSpIqguW+9TEmsgc91gZcVGw/ubdnzx5mK0CZgcmkwfLyEpaXl6MsEWUzoU5G+4LQlyjWnLJMJDsmAc9If5FWZpo/+Z2Ca7r2Ksvvgj5H8zfaEUaCjXPrNGl5kQs6IVMMVCTX5FpwenUmVfK6zxWVamKZd8xmX2irTQAPKUKtKqyN1/C/b7kMf3r1xXhszyNQW1ZQ14vAmMHcgisDju7bsgynnZLlAbLWnf2t3D1M8A0ZhUi1GtQA0Iz2wAGoCXDuiWfj3577DrzjJa/EnHKWLFBVNZ7Z2IPPP3Y9LnnwKjysn8Bg6xDVknFjk9YYjTewvr6BekPh6OEOnLPtNLztRRfgrK0nYWtlPnSuoTFuJhi3LQBgUCvzvVUijLnFbfsfxj/edSW++NB1eOTAU1DzhIX5oTkQA+YrO145Dsjm7x3G2U8vhP4mc0ABEaC5xeqBVSyOhzhl+1F47UmvwA+e9iacPH8Unhs9i4sfuh4XPXwtbnnuARzgvaABsFDPodLKeAC0VWMcEYJlLTR1BltAPZxlZDT2HIomucV6Q1GIp/Is+pEKjBRs0jR+toZCWLzz2QOwhn+7Cq+8d8BNYPvZPIDtx+uVIrQHga9+4MM4ae5In23fxgGc8sc/gtVjtqIF2+Bwt10K9rxmswxCjYkzaGtATzZwzq5TceUPfNAqXwoVkf3mrlDEMkp6aJAQAlJLlp1XAA6PK1HXJeNdoiFbYLzuSuI5iedRE6i7k8Nk4ehvSpt0ohdPipLl9nhAo+WDKTi3vr6O/fv3ox7U9itRZuuW/BABAO9erh0ThvrZd0hYcPeSskxI5ll2JWFGoO5cDngzgJseqBDdJ+9KbCKP8E6BMSI7x6yUpCmQX6rZkCmBXTKDJysPsjNevRPE1U8hLbs8zuthZ2OlFOpKYa0Z4cM3X4n/eM2n8fBzDwLz86i3HwG0gHZuUnuMYX4dWtCjTTq403ZkwzWDocAtQR/aj3pU451nno//z2u+Axcce6rJ7k59qucwphZ/8+Al+Pu7LsbTajeWty9gfmEOPGqxvrYHaxsb2KqXcMb8CbjgmLPxysPOwKnbTsCCWkTLAHOLyWRkBCIRKqWwOJwHA2jQ4q7Vx3Dp/dfj8/dei9v23ouRGmF+cQHL2xZBrMzn4hgAaXvQP8FGdZkW225ma+GYD47bFUGnfICxvjFBszbGjnoR7z71jfieU1+HM7ccj+fH+3Dt4zfi9x/4Oq577l483TwPNUeYm5/DEhaAFuaEIg6fxpNARGGQHfTHjJA8iwJbosRdhmZbLpBMu07K8DCInfLMjNNlkkTeOSGr/NyRbWDLzhIAwl9Zjw/bpJDPP60UNnAQH7rrs/jgy/+VJ2Xb/Ba866zz8dGHrgFtXwEa9nNA+fOazXiz+ySfZtDcPG687zZ8/am78dqjz/Lrpd516jUzivtKKsrpeeSis4oGiXyW6i3pVTy7On0m1RqnuHV1eneOdIfGnuXLrlwup02DyPLK3wyomiVElGk9JmzHQPpLyPEkA7R7924GwqeuJpMJlpeWsGVLPkDKA6gfTKFh9FleOXqFIJjpGK6ctpQwHwuAlRO5zD8klAtJG/m/RdpI9kWGcurh28iiDmXMsh2nZKVO26s2rXyvQcIBLiMIT6Ntr+sRPnbbVfiDqz+Fe5+5D7y0ABougybauHnhAMSjiuAHCrqb/Y+g7HIgWQtXiQ/Kmo+c86FDqDeAt556Ln7twvfhnKNPNkaCNraDUhUatPjys7fj7+68BN8Y3Q29g0ALhPHqCGrc4HC9grOXTsB5O1+KC495DY5bOAYKlW23xqgdY9w2Zk1OVRiS+TBbQ4y7Vp/ExfdfiysfuQG37L4Hq7yG+bka8/UcWJtjCt2hE+5D7ESuzwIfsFjUNAfiG/e6Y5LRaIJmvcGyrnHK4UfjgtPPxAVHvwxbaYAbHrsDlz/0ddz03EM4oA9ADxiLQ/PRdbQAazZHRjpsd+vAQiqEsfeqNBKuB5Jnsdic/UrZbAqW2ttZlcmUnkgjLSaN1m87NMh5HItwuSWNK/MfVQq6abFDH4FbfuhvMbDBcgBwx+6Hcd7/+LeYHLMDbWs+L+BOonLxBqy12w4OwFg/zYH9eN/pF+Ij3/XvzZeFKuUTKKuIdU5qS9sAYR1mhy2sR4eAUIree/7wsjGFpwyIU9JnEN2ZGDndPbMh0lqm6TMQ5Nood+R/PwiT7CtKaA0kJU8JlKyfr62tYd++fRgMhn6uKyW+a2stWmXva0A0SqB1XgsQNocbTQ4EbMbyIt8W7jJFwd3R6RBBnwThmNoAqF0iwvPZKU+qKWbsMmmxLMs4LBbbqdSnhDwTvgDlLKKWZcCT08psO5XCWE/wyTuvxe9+7ZO4+7G7gIV5qO2Hma+jNCYfOXBlgjhySdYS4mxchC2z/eYKg1sC13ZtlwGsHUI1VnjjyefgF897Hy444SUAm3VHZoAUYcLA5c/ciI/c9QXcunoXRnMjtAsK9V7GseuH4VXbXo63nfwavHLnGdhZ74RmYKwnGDVjKBAq+5EApSrM2SMTGYyHNp7DpQ/egE/ffRVufO4OrGMVC0tDzC3OYRsv2+06DIaGOR9CzFryg+gHxykwXojZz9o1DWM8GmOuIZyybSdecdqJOOPI4zFuNR7Y/SR+70t/hfv3PIHVdhW0oDFcqLHMi2Yte8KAjQePQIU4MnJcgsh7BcFbFGawHRJx5RlrRnXaz/GeaTK1rrz14bxmXcCI5KRPwiKfoC1aqA1J3UcEZPoIkjSjrod49tnH8cmHrsT3vuitmOgGDMZphx2Pc445HdcfeBi0MISeaO8lMm5lNvOD2Qa/AWgBtbCIi++6CY++9Vkct7zLz0V3KQloftC7ylIZaG073KcIc93qHsR/oteEmEeKXsDkWZEHrByO5Hm63JeRp500GcWgfAWwSw32PCKUfksFIZ+M7fbGOjxxICugtgN6HFXB6fNEYwpECBR3NdiyOzjryO/RakqDkuWdwjO4OoRbOp8kT0eq+UR71vrWRx1Nok+i6F8Wz6SGJoWpEJbScvHpOKM9TmlbAFtDQEVkv3jT4nP3fBW/9+VP4euP3AFeHIK27jA0TlrrInN7/1xh2o9ftIPagpALEjHjb2JujcWrjNvt0CpUq3HuyefiNy54H95wwmlGHnHrZcyEW3zlqdvwF3d+CtfsvRXVAmHX8nacOTgOrzr8DJx3+Bl42fbTsFVtjdo8aTcwac0e0kE1MEesQUFB46nxHlzx6M34woPX4iuP3Yg9zW4MhzWWti1h2G4zhyc5gCPYL+aYMXAuJKtJwM8ysv1BwfptdYvRWothCxy5sIwXv+gYnHL4kdi2sIzH9+7G3994Oe5+7hmM1ASqBhYXBlhqF0w/jtzHB8xBF0xBWrieDsIwnnfR2Iv7JD44sQDTWTWjcpqsF3Ythdw1VYONq2BnZcTrsZ2oZtcXAqmitTlLL6UC32Vz/evnp+F1BmOwMMB/vekf8V0nvtl8NrLVoAHh373mO/DPPvaH0IMB1ESDW46DEa3Hh9z3lDVB1QqjjX340C1X4Jcu/H60WgvrE4AYa1tEoJYE+4VW2v4RirvN44FB5JHKl+OKzmgnQ1OW9fHabPYgjtQISvCmT37GtJbT+kN4igZK4JEoXG4G+dmhiY0BAM3myE6JcQzUpqrwb0ZRyhdcaFieiNCInH5QBNxCPWmdKWjk9q7mKOvqJpu/HAPPrlEllWfKi7V023elA0XTRmTmRZ+9oLX9rqwdf0WAUjUAxtcevQ6/c/kn8KWHbgSrGtXW7dBQ5subbk1We+3ACyKvNjuvB0kOM1Qpd34DMbiqwADag6uox4wLX/IK/Oz534k3nnIm5lQFsA3gA3BQj3DJo9fiw3ddglsO3Y2t25bxbSefg/N3no3zj3w5XjJ/LBawgJY1Gm6w3qyjgkKNCqQIw2qAQRVOUnpqtBtXPHojPn//tbjmqdvw/MZzUPMK8/ML2FZtM0FZYw2NiTniUEnxE+DNNJlgLEh73hOZ7wGRMilHEw2MWxw+XMRpRx6B0488AvODGs+s7scND9yHe3c/gwOjNVRDYG6hxhwPDE6PtRF8BLiTmYhEv4M98ACO302/ewtGjju5fyDMFJJyR3BNJL2jdP7yv4Myzkkpvm9Exj41t3feO5q9kpGWQaKARBbIG04fUqA8aZ+ckbBVa9ZQC3O4/fHbcf2eO3H+zrOhoUEgvOvU1+CYpe14ZH0VhBo0MWvoRK7/2YO20tpsBWoV9NwAf37Ll/FT578PA1Jw54X5qZWVmPA05XovXgsV71KQjbJzN/0MV+eIQ19XBmg7SbrA3RtrQnHaUH+QoNmtraW4m1KUde4SWE8U/jPl2+hjEQcDImfZOsIyBebG1Q+GoLXgbzfbG4Rm5YsWHSLK7gxvblAiWtLJGwDXkZ9VAjIAXFrz7NYRt7Wj+KfaotQmc1dHGGYAVso+P9CJIEz5OSo0nlJm8grXsWbUgxoVKdz2zD341S98GFfcdR2aIYNWdkGZg5WAyq7JgtzsNwEeDHPIuv2EHqduZGvkGYZmH3FJLUGvrmFIFd52xrn4d6/9drz+hNNRUwWGhmbzUe1nJwfw5SdvxaUPfBUHcQhnHnM8/vmx78RZKyfhxOFRmKMhKlQgMJp2gnHboIH9Ek1VAfaQcADY3ezBVY/dgs8/dC2ueuwWPDPaDVSEucEclgbbjWhrNfSk9QIShprEepAcbPpDO34nAukWTdtAN4xFVeO47dtwyq6dOGHbDjQbE9z79GO49ZmnsHu8ClaMuUGNxWrOQNJY248dsMUOe4i9YzcBEG4LUUAJF0vgtrTIeZfwGyMIVY5GrHt1wMn2gSi04/HxXCrnk8weTZZQTq7+6MQ6aRUljM/cfZbSFt3PACpketVoqLBfdjJyVc8Df/mNz+KCN56NSilorTGsh3jP2RfiT/9/rP15oG3bVRcI/8Zce59zu3fv6/LSQTpCgEgTEiIhGJoQAwrSKBRVglKAVH0KhYWKLXZYapWKIuUnSKeliNJGGqVvBEIE0kE60vfdy+vufbc75+w1x/fHnGOM35hr7XNvrG+9d+7ee63ZjDnmGOM3xuzWr/845OIdbX91t8xRm/YFdW0rkKJCDg/x3ve8HT/z1lfiiz7qudC5ttPYLD0BoE/lja3d0xxLPs7Z7gtW9tpAqjdd4yijGbyVEcxbzuOu0D4uHF2DRpN3PhPapUGDb8l58rwhN+M89ho05tyZCOWuMjY88MCD2k6yaV7WyckxLlw4j4sXLwJox0ztu9ZEetlRfbXtwsMcjxsjwvOEwN76lwTt8Vr2Z0AWVu4CMx5DB68B4Fjkvmd08fBvdkJ0mQaDI7DHMPA871p0r70vDMCgfS1SacOer3/oHfg7v/BD+C+v+XXsphnTxTsBbNpbZEqFdifK/nNjgWYsbPGHe+0dINrigXaGbHsbygSBQK7exHmcwRd8/PPxv7/gC/DJH/HRAND38s7Y4QTvvnY/XvPQW/Heaw/ijvPn8PR7n4hnnHsiLsnZdpawAjtVaAU22GA7bWLpfefHDjPedfN+/OK7X46ff9NL8XsPvgkPHj8CbBWbg0MAU3MkdkF7vB+2Oz5i7fAOse6LHukGQItiPqk4QMFd5y7hiffeg8ddugQRxQevPIx3PPBBPHj1Gnayw+Zgam+/62dcoMYQvDkzrejQJzcijJGnYMW+4CBJGlmm1UGU0bqMlmytjlvglxcUXvJq1rWRnkyEZHro6cJIrjFLI73npX62hS5+lKb/tSmRHQQH1wX/7U//AJ50+Bjs6gwUwZvvfx/+4Ld/HY4unmsnhSnV3IekBW0bUOmO1Hywwe7mVTzvYz8Nv/ylfx1TFUwiwNTe/eyIOdLpFr03aB8KrDzg0dx9I4PLPGvOjGY+2hD4KavltP/WtXR76rZKFmCbIvhTrlWcaKNDIVECXviQ/NOe/fqN67j8yGVfIGVOUZmWW4AkR7YrjVp5bypHrdkTsEbqqnLfzuKpW/mXe1fbEpOTDdgT0bKRWdLZ/x29P2ju3KGzxzmENZpXKlqmBw216ZghD8OpG15TNO0lrHimlMfOVi2loIjgHQ++F9/+Sz+Bf/17v4CbuIZy550oOgEnFSgnqKX4sXO++Ib+Ana0e/998YdR1062gJTSQoHrxziogi/4Ay/AN7/gi/GcJ300pJ9qNNc2F3kyz3jf9Qdx+egmPvlxH4cXbe/AgWzRbN4MwYxaj7GbBTstKGWDspmwKf21dTjGa668Fb/xzt/Fr73rlfjdD7wZl+dHgANgc7DBtD0AVKAnFTqfdOYIbMSjGR37LP2tRLADa6PhLTFUFbtZUXaCc5sD3HvXJTz+3rtxME24fOMqfuttb8BD16/iGO10oelQsBFA6ky8FBiY+mI5G5LO6u4AGw7qLfBuVSfpu+55sDfDbaS/1TPj4wqREbTKcF9X79+yfatpdPFhdoxH1p2YftitlyXaRoQOtrh29DD+n9f+BP76s7+mBS6z4qPufjw+4+mfip95468Dd90B2TVPRjrIsrGy4U/sZuDwLH779a/E2x/6AD72rie6qJmY+FTCKugiTSnws1tNt7W0eejWnMzENTUbr8u8zMe1unzEk/jK0f4A2KdNTa5NSaTlQUP+BWbsdVxy204duh+LFLS97cWcKfG1OBTZ1h7ZnvTI9lJTdB8KCOIz0djnWC4bOFz7wHBIFF/p3qq3xcUM6de8KS5fTMFY+ZfOj98/bTl8VHsLD2ss97Zckp5yaP/i/FAAcz+uEIC/Y5FH7d7zwPvxHb/2U/i+1/4Crhw/DLnzTrRItgtyBxPCAVjLfQ9uf7epRbVlBmSuKHNfwNPf66miwPERphPg+U9/Nv7mZ30ZPuMZz2qlad8KIa3CWit2Gi9IV7ShbkXt6XpEIAKRDUTaEPGVegOv/MAb8F/f9XK89N2vwJuuvgM39Dqm7Qbb7RlI2bSjEmuFTTUDEm8MGvyl0VNv5Im/UxYFqHOFVMVh2eLCufN4zMULuHjmLG6cHOFDjzyM+689ihv1BNgIJlsh4frSHBJ7964bYkWbC6cJ14CW3O8LnErGxpyuUXjooxudBC7W6dk+eqbTxTpbgtPAnnNwsLFUbdvmt1bMKc5sAiAwEyNBApZs6/ieR5WmE90GiAJSCnYnx7gbd+O3/vQP4hwOMB8rNmXCb779DXjRd34Ddo+7oy2GmtEXCAL+jj4jsDQ90e0G9eGH8Dde9DX4u5/9FY03/YUYRpNETw2gkefvl0yx6nRhM9a2I3440ebtbluMxWnrwpTW2JwCtmt1Dy6YlyGch+pdTb8eRi2uGzdu9K0/24hgi231aWexx/a/Yc52Ue0aeq1pLuETD68127TCzKHoXGesHkteZXbd1vMLLU5JFQ40e5l8i9IMha+tCA6nXPenQQjth3vd6pSW5AW6AGeTbBFsT+Q6+cDlh/Dtv/wj+N7f/QU8vHsY9a6L0It3QWeB6K7xsSNC2CZ1xFVuq3TIsAW4tXp0ICrtNW1Xr2OSCc/9yI/BX/qMP47Pf9YfwlS2UFXUuZ+XLO21dO1tO9LmbLWBrJ1u1t49u4FI8TOXHji5jN9632vxK297OV76vlfgXY++B7qdsT03odyxxQHOo1bBbqfAfBLtqNrBrbelsrmiV2cBsU3JeDo3J2MzFVw8fx53X7yAg6lgrhUPX30E7/jge3Dt+Ai1ADIJpq10R8G86b6AQqlMDdBfV7F1eVg9Uch0CBEBZ8GJLk3lq7XYCFs7s3xZnV08G0m1780bdQ/0pMtkbu1+FJye6/Bp6ccgYaA+PiKtr/8wuRH4YnOgAWedK7YHh3jX+96Bn377S/E/POWF7cxuVXzqk5+BZzzxo/G6K29HOXumAW5tuuqxmRms3ncyV5QL5/Gdr/oV/LXP/h9wuDnwaR907ZvMiHN7xJ4yqDIQkVyv5M2jltmQpWe3AcBp3Q4BewJ0GolMI3pcDtexeNrpTtA4ODA90EqYI0P6Ba7xrps9cHzaiGWyF606UcUmj9dzYeQNprJGhVpvxGk+zuLZ4NKasR49kCVxSGns+2L18VojbzfqxCmAKrjlHK6/nqwVBJs3tZKH1MP9scB14A6YVWj12lBEMEH65njBh25cxr/4rz+G7/7tn8YjNx+GXLoEHNwFRYsmWxmMAgzig3JSdNc89XakoU4T5qKYj46BR6/h4OAufMkzX4ivfe4L8YJnPguQLU4qMM8nKGXy0cC2oKoZkDYKrajSotn2NiABpOBGPcabH3o7fvtdv4fffOer8N/e+1o8ePwgcKA4d+dZHN69gcohdK6YT9p2IQBAle4MaAfW/lv7Yq3+KiIL2C2CrXZgvCrQ9xJvNxPOnT/A9nCD3Vzx/gcfwNHJcTvW0fYbT9IPxFKo1uhRFTQCxOtr96lujS4wwHOlZ9FQRBTjNkMXuMLdlr/EcGl21Ubj1e/0fNWH4KIcezyY6OzXdvkfDf0qUMoKPWshtqbm9EB9nyF0RPNSvTpzLAnQtCOhAkA1cFN/ObylFwXq8YzN2S2+9xU/ji99ymcDW2BXZ0wbwRc+9wV43U+/AXr2DMoOmPqJabNK6FE30u0McADbQ1x++L34L29+Ob70mS/A8W7XRne0neImpc/l5i5w26kjr/r9Ba4AWA0IGAuMX3tGFK3sFbiI4oZh632+11q+NVu9DnaDjfIvIZ8eqHn+dZsaufc8dD5I+vNIdiBnJbIdAHc/DQNBa2WHR+G/9xGtyyYxQ9Tq2DekfEq+bpGYMHApaX70Fg1ezKXKINy3MHC8MWJfDYvfQ5WrwyfkZFgkKADKNKGUgoduXsF3vewn8E9/6yX9JQF3AWfuauB8fNL3D5Y4Ok3E52WF3G4VAl17I4kAKHPz1usMvXoNevUYZ8q9+Mpnvwj/+2d+Pj7uSU+DzcPu5h3aQqkSDUuAi+4KCmwX7gMnD+GV73sDfu3dr8avv/MVeNOD78TNoys4OH+AcxfO4sLZi5jnxpvjXQWwS30m2gC8DVd3B6i/D9fqQAf7pjANlPspilCp2EwTzpw7wGYDQBTXj2/i+Mau2V1DxgJIf72e+slQNqxHfb/QMWkA5jwnkSWACx9P4swQEhAHpho6M7pv6bKsDCqrVzuMIQb1U7Wki+vlRx29nn16soIPWZcHL0JyUvMBdEyA0JtwjrNBdOA0WRxWSTs/bYW3dI512dKdYntwHq98y+/gVR96M55139NxrDugbPCln/Bp+Mc/9f+gzr3EWdw+a98S1Zy/7u5WAFNBOdzgH/3mT+HLnvkCTEVQ57G9t4asPCDYGiiZSeujehIguwbG41zoouuH4fk0ymbVJPBdA55EfE+3rF9SWvbuVmT6NBzy9OTipfSng0TyfXyIHt7XG1aCbuMQbttKgdj7KCv3IAirE/KnCAvZ4NtKv5b/dtIvFiTdroexkr6BXfvk+m2OrgFggUhxYdhbcAdnF1INnqbRsJVhH1sFd1SP8F2v+HH8Xy97CT54/9tQzt2D6czd0J1AcRwc0LafDz4vpa74DhgSJLso9kPSiwJy7RrOXj/BJ9/3NPyR5386/sfnfAaefN+TYO/Uk1pxuCnYTnl1u7ep2PEW7fV1r3/ojfj1d78Kv/WO1+H1j7wZ773yQZxMN3BwWHDunrM4V+6EomA+2mG+dgQU6bw12pvxmiAt6J4RQ7W1gW5bD6UAKmrfitTyzm3YZxJst8DmbHfL6g7Xru+wQ22nwmwK0KMN7dZausXWYbFaujqaNgNu/5JTA2d7l4XWJpvfXpUYO+DBzUUYHwnKrND+IV7HvgNN8wCcQU7cMsfAhuMWpaTyl7RLJAmZo4e2jSoMQjzP2LxmsxhJZSh6pRxhGwj48ILX351Yp7n2kaS2gh7bgjKd4N/+xr/Fs/74t6LqjKObx3j6nY/DCz/2U/Dzb/wNzBfvRt3ZaWtC51SUbigUmBSoFXL2LN70ltfjLe99E57+xGegHWTSNm3Pte3o5XUF7SzuEmsCzHFI/WFD15JPGRs6LgHtypUObKCynV/DxcPIa5K2z0miAoA9eXvlQ97bwwqvt/dxomPRDnYOQncthzt7q8PtfoLULZu6Qt0KCSPA2jMer3eLret52dvZN1w8pFull5VyAfRkeLQLlqwLlsBO6bE2xXehcmzPqlZtilBrm1ss7W/qk+cDZ/ZcZrhk0aHmfY+iZfTYUNdLf+938I0/9W/wxve+CfWuu7HRZ6A8WPx4OO0LgwVor78z+oq2k5HMqvintBfZGI71/Q8Fgu3RDp/ypOfgL3/W5+PTP+KZOH9wBwTShmChKGXy4bKyaLaiVkWdd3jLB96HH3jFr+Fn3/oKvPXKO3GMa5hKxZmLhzic7sVZnYArinq1H1JYCzZFME0TtNpUSTvVSvrws/ajHVsk2IDVzkbVzivpIewkDYy320McbAsOimCuFSdXj3FyAqAKtmWLzSQ+/9pAtYRzZQonFQWNP2oT2v2hdHZGkDWH4YW9t9fkrA2lt0VUoeIsrQ5Wwl9aJwcEt7anU4jslXMSUGwljHUkWXNLvgQwWzjEmJ4oVcqXwi5Z0OACKPluuK4MCONRff2umtMzNMQAGABQIdIODpEOQhZ0OLwq8VQlzjWuE0QVO8zQWrEpF/GLv/U7+MDnfQj3nr2zHSaEgr/04i/Ar/7Ob6KePUQpE0qd2/koc+mOUkE7PVdRpKIWQLdncDLfwHf9t1fgn/yJZ2BT4vzlubbTquY5FhIWmWArIF0m9l2UwIfHiS1r0WxaMLhnLtQWTroc9PL3HXZxK2gUxgBONzqdtE4BQn7S4AG2QEg8nX2YnC12nVBbuQxbYbzwfYesSrLUVyNrX42sfTXyhfYiAgUBRDSeJ75T+StAnAje98gIG9Kzl8BgywA+XouIegDURCTp7j5PbvROgpy+aKff41W/QNfFqnjk8qN4w9s+gNe+5b146NoNvO9Dj+Bt7/kgrt48AsqEggnTZvLhBu3zkx7/aV+pqwpFdc/Q0osIpjJ1PJyAacIHLj+E13/oPZjPbSFnz6KcALI7xqSAVEEVQW0H+oZyCQAp7X2rDrJTi/b6PkMt5gTUDswFqgeYThSPO38n7jmYsLuxg8oBimywQYHWE0AmTFqhpUIntNdRaQfH2gzGw9eu4d2XP4Ab8yOQsxPKhS3KwdS2QvR500kPUOoWYq8d02aoKiZU2Mq/9kJ0Qe19M0PV3sFbYa/0bqLQTkeO4fHG+TIJBG3v464K5i4VLfCtQKsNwARIgUUbVkK7B7iRdu/Izp1Gpy/kMWyfOQSmyX0OXm0jrva+N9PCO3AJaqWZb1sJ6aAX1goWhXsdSQNimdjSsesRYHhiMferkZbPoFBqS/IJ/LDsqCjqNyHv5fI7gEX8ufGA4AKxtSba1Y5j5OeW35rV+wpND/JQZR8Krd1x0wrR2oCynkB1BuoJSjnA5lrFxbN34nBzFucPz6IWYMKMd9z/AVzXI5Rt2xXQFgk2+dM6tamVIpAJbavdZgLmLe6SA7zoaU/EPVJx352X8NFPeiw+7ulPxFOf/FicPbPFZmpnete+KGu5uAl5LjFEIPX4bV/75lGpD1TDdi4WS43EjTQJPw6hGrcyuq8KQPfQw3WcPuweXMtD2iabI9gC16/fwCOPXMbBQbdJ0nd92P7aUvwlBHJrsO17I2/jSnJtrGAd0tyMtXMyF+xaYc4au2TP89NWz61dt0qXh3GbYLe3erS8RQS73Qle/so34qd/7dV4w9vfg99+w3vw4EPXUU8q5PCgHeiw3fZzEbcABDK1YVy1rQDJejbtbm8JaYc9wA0xpysAJpSpYHtuwnRhg1om1JM+Z2mcMqPoaI2wzh2wmnZO7a+UBuLSgKWbnQ7+/SzlCtQb16HzzTZ/q21o2sDG5VVm2NCbASi0Fb2ZCqZDAJs+OjDviA6BloKCqc+59QJl6m1gQGv8sdWjbdGYDff1/b/mYThYmONhXkaLdqXzpfWLGWL1usQjr/6WDzHFD3iy4WEJwTH08e8uVz2NGDD3djAQur/oLzuIOqLwDkOlD40bHW63slecXWYdnsX3NsoZaMprSc2EujElrMul1cyLxeVuQYCtOyRBW+uaaJsagUq8SupsIwb0qp0oKRrY+7P9LvHMjFjXxebEmSNYofMMaFvtPpUCnJzA3q+sOgGzYjqzATat/iITpGwQsjd1m9CM9Cy1renTqZ2MduVR4MZNyO4ERXbYYofH33sBf+Apj8Pnfuaz8Pxnfyw+9hlPRhtRqm1LWhdIs02Aaa9Se3NfjHOtzKW1NIrQ77ytZ8g05k3y44W1D8lZJT++9TW0Ycx32twxq0YMfefaLbJtb/25jIODeOuPSEzjlX5qnd2XBx54UCvts92dnODCHRdw6eIdyTu51bUAWx4OHog8vSBZvOB9LGe17jHdns6+rQh2yOtRrJIhckNYMKvi7W97L17yC7+JH/m538Rrf/89qDtFObNFOXcW09kz0B4lttzt0wAvL12nyq0+HweNt4eIvRPTHArV/mLq2pS82oIfjXKFjNIozgy+sDHm9ifFwLYLjs8vdRp7Uj+Yv+/nFRaDakOYnS4DkbkCdQZ2M+pcoXONdltniNDRdBJzy047wqh7XiVBoL7z4VljAbW9f5fEi/G5GRWh6kfroNR3VlGex1/YezfmIyBT1CvqdWUDFLS0D3G6Et8EsDWjo/yzyiXzpJrZxReXvWgU/5SVm2vafCsNZ+2gflop1e/a1JUzURNvF7VbxCyhlzbd0IqrSR9R2/AzlA506Qa3VaMO2s3/k+7Asn4JgObYtnYVn8bRWiGlYJLiq/eLAJhPMB8dY756HXV3hKkInv3xT8f/9hWfjy/+3E/FmYNNm9qy7WYaDkxJo5XUd3s6etG75BwmQF4BW5+i48h2wIDkADjPlmBMOLifNr5WInDTwXT3lhiXa7ZiG9he6ZGt9LMM2slRkPEEqQXYtsj2jjvuwKWLF9eJXTBLSLAHDvSGrB5Ased+ys71j+nHYWU3CoOXYowae4o6c98GaX5WqwFbV6yu6L//xnfi7/7L/4if+JXfxfH1Gyjnz+LwjrMdlBR1t0PbbWKRE9qnD1mZYjN5bEBanTGsWLNh5j9Tdh15yPwZ+Na/qRkv/+vGoBR4VEv0ks8BKT2CZJuvzH7auaq8b9Ha05yEfLjE0PdOrdE3GvbWdgXzggyqf5i5Vi87UKp9l7GtZIAZXHxbjN+mchf9QhFqIl3zd+30aSy6inQOM9zBuRhyEIRojGd7rn04x/WvVGVgbhxR/tXpH53JdaMZ0r5GLvdanhLa34wmeppq948F2GriXavFwNaSagdb+1Ogn46G7uxmwkOPpSFw6JUAKFPIl8mcTTt02s3MuYkSQR9tbsa8FGCaUE9m1CtXUW48iic++fH461/zJfif/6cXYyoFu93O8zcwIPlwWyFwtjr5Gt0+2Mggh63IWn+MeopUCZ/Ql308suYp8pQFLSMdPPW4lDNqZNKvUXYo3VBngC0PI2ewld6ndtAFAMiDDz6ktdb1YeShEc4ULBk7vt7JiaTGpyTe2brM40NRo8HFgtGDz9F/sNXff+0D/FiqPtIXZubyww/j73zHD+J7fuiXcaKK7R3nULZt32Vt+1BcmAPApp7dhh8HQ78yGhDtimP8eIbKI7UU0S1BZjQsSy4S2Hba1A1DA98AIXBHEm4ZPzXkwb3U4XJP14Z26cUFrHTJsIrhUG7LWts90RrAMekGmAIeNhTig9UvGEAfw1dX4q4jAy3hrK2p+ABKQxuFwGV8tmwXt2Gg1QBxBKs9YBtGcC8aLzs3ofF6qXsvNxK3UF5KoWs3Fg+pAtIJWU1EOpn0R7sBp9EXdsBZ5GQoT0B2IHRKF84ck031ayqt0Z5Gqio2ItgWoB6f4OTBh/AHPvHp+M5v+XN47nM+pu/RJX/CwVW42pBBMVaRnVm50sEUVpCr3EqeNZygvMtDWjTx5dRrxBTCHWDdGbCnq2mIT2no3MH2FsPIwpGtNLBVVczzvABbVe2H1I/t14Est7ap4dzgdd6seELs0ayyZcg/eC85Grj9esfnvrqY6LED+3/sJ34FX/9//Bs88IGHsX3cpXZC0NEJqlbMavs24Z1vc0Apckxzj4NDYUbKNMPb1A2FEI80IkY38glgls5CHiHI9Us/3UgdaEr+ZOUcjemgnGwzvSlKfdvps2hUopBk6GzxgwWObP9cVRaAi5x4Te8l899futH7gYeTYzGOfV9YPyqYANTaqDrwZyRKQ14gC3ITdiQAWLnYEUplZpqTYRltnP3Lde0Fz9u5TKAHvo3lJWN8m0b2tutfqc8cmQV5awwJWbXvglg06SMzC7Iz2IqN1Ig42JozF9UNOmrFkr4auW3RWFvFXNDeEiRli+Orx5Ab1/AX/ucvwt/+y38K282mbVFycgIImFb/uRIZcr1rQGgrm5eYqYMQr9hhwozkHo6gOdqBoaylawmkt2sM1XoAOaQZh7eZHpuzvXw5XkSwBragiLdFttom1FUVxyfHuHDhgg8jry6QWlU4cptu48qOn6x4IbdX7boR2uNVeXWBALbKcO1SM47a9sce3byJP/PN344ffcl/RXnMvZBzW8xHR6iY+9tvWkfEqTvktSaQ4gjJCQEgSSZGsVk0chTeBKK6mmfF1ixoMMOwGFpOxnuloM4vwQCqt+zM0/bPrR22YLDMoDoAQwLd+GpwmWqW6CvvB4RzlBZKOEiR8c6WYeUzaFm15b048y9k5IiR5bacjdnAnRUPZ2GG9skYOwN8c+06xYm2fKMur+u27AfxNRBco92BcF99e4B2jR3mZix0yfogL9Syf8U8ySFPGrFKn63d7tQi99SCVOUyM7lqW7e0bXkTAKK7vihqC/3Qh/DJf/BZ+IF/+k34yCc8ts0z9+FNWzkbLCEa0muKFmzbC7iW5r/bL1urBximBOJSYGGXZHxuyjs+5HS3slnDdeNGm7Pls5FLaX8C6dhJw/YGtmNke+nixVanjKIYw12M/K0tGpgLpCEGbwN7S3sizLGjwtEaOtaVgI3k0iNk2sc2jWP9DrBEokjB+9/xPrzgf/37eNeb3omDJzwO2J1A6w5zVdR+rKH0SNg8L3vzQwoFB2PBgjLyZc2z0kHhxP/V/AqvIcpdtVkaT7iWiCQz0Mb8CiIaIO4mT/jD0LRWjxEfBfsQDhkykz7jG/pRiOxoxHfF0pGiOUOfZM7tzf1A7UeXDetfTwdkb5zmW80407SC7dFzNkleFOj87/84xV7nMJrD8sr/igw2JoOws8D33eZS/VOiXIvQo43gLuMv7kP7Z3pKutcdmL1bM0htXGTXrOEYiTnDEYu3I2n8oP50baGhf0/GfUQd2N6ExU7DAPwEuC636G3eG5GNX1LjMfaPP9OmzaI7FOzaevnNIU4evIJLd96BH/uOv4rnP+8T2wlpNudr4IDBHroemlOgqUpj5Fqv5XLWL5aH09bNJAYkmYsODUAd7Pta+YP9X25l3YO0dFsk5mwNbEtZztka2AoAefDBB7VWxVwDbO+4cAGXLl0Mw5Cauw9sNdOzb6h2T6O5Paud5/WvlSeusEbjeuJO/x6wta08cz8neCqCzWaDV/7eW/Gir/qbuHZ03N6MM/el/32euy0+tQUT1OHWGFGijRsVW3Ka7ARfIet8iO1MwRnJCVzwltzNwztOnj8NusIyGeCysZZFGa2+cVFP1JtNSabMhp4yIZKEwaXLlW1cUhMgYHwwemTFQx+VLyLb0SiugO1wCRuBRI8SXV7xIn+MhGRjHEZZc9bkglO90YE9q1E89B87MTKAyFo7eklRBbXhlKHG7I0s04/zlKktnGbxdNmfjqga7Qrak5bBjhpduighO+1j2X/p4I1VRLTf2ZEw0XVK9jngiQQDUqO73cty2Et02TfAbXvK2wlnFZNMmK/fhBwf4ye/+x/gsz7nuV6HAcTk74EmPp96rfTDPrufuWItd9uxLOY2wHZNNnTPjpdR76ydA9iOc9aJ2KElbRi5RbY+VFxorrZvGXQQjsxWZhiXW160IpQ7yWgbS9DxT20u63QAdgqtQYkG8m7oPY/jf6l9e2owerRqW3IvBW947VvxOV/5V3D96ATTnXcCsy2cmqDS98lRnaE76oAnY1tV029f8OS8oO8WSSjxAAKb8122jDxU55ekNIJulzRWOSvRau/btON9bRuP16TwZ+hlBOD0coh+0b4ASmv/Ts9g+Tt1GrLk9S960QQi05PqNqDtaRO3NOQ8cwdgTsmi/H6fyuX+4e+JdxjbiRgWZH7wMy+/31WKPhbf+n/Unkxz9NWAJ4Nv0OmkPK29Qu3qcsE002977nym1wam9FFpyJP/GY9DopOk81wLj2h4eh36Jeq3s43pDfBE/yDXRGvItJPtvF0YNqODppCSJA/Oash+53M1GUa8wlLzp/Q/qLZzycnZl76XvVZBrb3c3TG2Z7bQw7P4I1/9V/BzP/fbrSpV32nhpz+RWLBs5D3fneMy/HnruYtW7LxSHYsyJNdp+UOTVmrZU59951EUdihYftKo6VLuonwkDoVPKXQ7cRAAUFho9gPRnkaZ4LhVEm+U7vF4g8L1jgEzZvEoL1jK5QVVy7rWb9nQVa19P5oqigg2U8F2u8Xb3vZuPP8r/wquVYFeuhPzbFt4YuYvIiJ0oA1+uEGBtugqvXUdC2CNVca88Z6ExIS79L80zNuhhod9g6iBCWqpAdAclDJ9RK/kvlSYXSBL5BS07RFRZj87uPKWieZxexuJNB5abH9C3+Ftj91TxG+3fNFL6ryk+8yWQjzj4XIRQPiQj0xDMxCsoIxe/d27aqdYhaGKBTY15RkG8pNKBT+s3kynr6QW8dO+FjRp7qv2lUY/FvwOuQpi1PtdQxLQJYG6MRwLTuPFlrEKljmiw+SB8arTEWSGQWz2WHrfcn+QLqV+NBqU8vBKYz+TkfprMORQ2MIY47/3DWgBlA0rFtr2J9LP5zajb+2nRY+AO6iZV8Z1kiWmyfJ3h6LKhF1VlDMblEt344v+7N/Fa1/1ZmymyaMyBS8KHWRj4PV/7xUAu2qW07VWF4vl/ny57GjHSP9eYOi0js5FJFqMG1rfeH6T3/i+AaxPBQECp7SEtap7G9ZRUfFym07QsLbgZYU5BNpeLX1PHDfF1BDDkWafJxsrUrRl8dUUDthsCi4/eBkv/Oq/hatXjyD33tu28xjImpdpgMQOWy/TuBlz1EuaLJEpbHhZ0hUmXljgXeQlNQUPFtNspvQTqagunn8xluVDOjodEFoY0S1Sp9WNGSJ6SUC9Ul57rCQy1YdXXGi1YKlBQkzMc4+xikzt//aojoaHslgqGj4iKxK0dKMpgA/r8zBv8F9bvsrDesELbrsTSbm9jVq7TsT39FgBWyUdo06AT0Iqor+6QAT0MXNIw12OJN2w1f1trYE6b/JWivw9RXi9BuNdiJE3pJNtgAivx6VzcLaz1gidvaz0RgChtNzvXQ66rAvJU2dcbwP3GckzQidG26huU4aV6xpbcixS87Zl5evlsPHomm8RtGh7aYZxlmhizrBtDBawMw1o378rVbE5nIB5g8/7c9+KN//8v8Klu+5o0S0A7UeRxr7fTj1H4/v6hwMhTU8iLye3vhwKG9fMrBXF9/dFp+PhSIlrhhlhZHJfIOzy/jbIeGNIJC49ULT32eYGLYpaFmKKAzKoq3WJD0+uE7vy+xS3he1t+uVCeAuHYYHooMi27fOcBEAp+Lq/8R344Fvfge2TnoS6O0LFBMVEzFLXBy/QsI7SjNVGZM58a4a2+QNNaWPfcgmAUGq3g7oBRMlp3FkxIttKxRCsACVBdwqsTDdIZjxiX7C/EsxZTYdsQONVcG7c7DxgAx/Qu0H7QR/eWPF6ghdK9lS8aX6qTwc7SBtOU1UfXmNTyQbZeSzi/FVzXoJa75sUbXu/CrWRI4nGV1F7z52/Cw8Ofp296rcEscc3jxbZDjF7+42ij2qQ6KC3v+mlRl2DUW7WLbY3RX42eQY0BkQmY72cPmRp5wxbr2ViAKDQ6VVAROTWeJNRCf6NOjWkiwWXAnutIUMig2vTodC/pG8eJXIf9byaeZZCg95XHsVyc7wWCX3l6JztkQs0zRFaSzr56spc+31bYKfedR2al3baI7jeFmNje5EzoCc4c/EcHn3gfvypb/7n+Knv+5tQ2I4UYOpvz7KI3SLvfcCzAClNljjTx86UOQXu1O4B6EgeZd3Kvg9JFpR3GecDS8ay9kbxdNudrEET3EyTadusU5LSD/WYoR9X/q0XEhudzUouucT1ODgPadcUei/zud1JV8xLy+UYedAKbLf4of/0y/iJH/sZbJ78VODkCO34QesYKzyrefsuYUWFjKwZaeWc1sd2045XrACmdjRbsePc7AxYvnpdKUJD1KEGfgLVGbV22ktpRycCbcixtr3UNkwVZtaMSYmhVgLDIKZ0muNUKIc4G46yviwT3NfzYbTuRSOG2DiC82oo6gfaTqvQW21z6RaZTe2tKkGnGcHOTylhFIXe45tkonFiHpSgbbMo0Dq3NzrZu/oswrWIzq2Uh1+hgO6EdkMIwWwvmNcCmUobdi/tEBQRYCrtOD+FYCoRLTnkcPSp+bc4EBfMaPN00b+9HEV7IXmvz52/8AgCg6v1RyWB0WSg2qsgTDLQ38AEB11fseny2o8fZRM3ypzQd5isNVnXftysy03v/zZtUDBB2vGH2sQ5tuiZXVoRgdbhqX2K0s4nN7C1URdIewet2B5LpHKdj2yYernSE9huCCj6glVz3BTutKUhnoHYMVqzERPqZ+lD8DrvcPCYx+IX/ssv4T+85DPxP37JCzD30bvcfit63b6vbZGCjLaKSCReKEIXFonYOfLb6v0RdsEKtZ+RL2kz1yHUB5rTuDs3tHd1YeQe3ExtoL7qLyKoPkl+crLDhQvnceniRewLo4m6W9S4Jw9WZJvDf07O307ZmNySCNJKHk+6vjm5kaMe3YoILj94GR/z4q/DlRNFOXcOmE+g0t4uox7hZTJ8SCmX3InvCmP734B20L7O5FApWwHUox30+BgybamS3rau2Lm6Dhz0HebVlgly7hx0s4VHXtoVGBX15g3ozaMOEH1udYw86JOBsvGvz8HOM+RgCzl3rhvRRq/xXk9m1Js3O11m9bphWJxORfOm1iYCETk4gJw9B39rXm+XokKPj1AfvdIUs0zQOreR8P6+WvtrPAyHIq8e78Z6miDnL0KnTepXVQVOjqHXrgF117s5Vn7CHDdoHOGX9M74q+1s6KlALtwB2W4gKB45aelvDbq5A27cgGymPFJUJNBsTby7cCpqqwcVuHCxyYMWsjkCqU0WcONq40+XD59/r30u3vvBjD+1CcFDOThAuXAHMG16/wKQDeyNRvXqFWB30hwgR/I6Bpa9n4o7RhBpZwvbyIUqcHAAnD2HaurvkWoFdjvo9Rutv6YJutuRxZfeP+ScuJNM8ifaHNQ6A9sDTHfcAZRNnHFcNu6A1GuPNsfVziewfu4vxTCnG1CaDRHnqeoM2UzA4RloUVpIR4sLSR/DvxCEXchg7EGC+wd9vUEp0BPFY89OeP2v/GucO38YAwMf7mV2TMJZ2iuS9txGHm6FMZwZy/IX24b2lXUqVmmzEZ701mB748aNvhp5A17gxWciA7HvluZsV2hjA0FE+NwBMXafvkOE5i3h3kximBv/nM/KXfNynDCuWJbJvCbygNqilbgpaJ7oNBX8g+/8YTz8ngcwPfVJ7c0z9uYa9GEpV5zOC6+DwYFcq7Jpgj2fYL5xE3rzRlPEc+dg5xibe6+q0BvXcO999+GTnvIUHM9zey/uJOFDlOKvcSqloEylLy1v99XeIQvFpmxwE4Lfft3v49Gj2oy3gZgq9OgIT3j8vXjmR34kSp0xa9v2ZG2qXUlVRiUO46Qq2AgwlYL3PfgQXv+2d0IODlHQIjOFoB7vcH67wdOf9jEQzCibLbZTwbSZYgM4xBdj+ivUJoGgwF6GVPoKzA9deRRveOcHgcNzYaShqLsZZw4mvPgLXoTNyU1cOzpp58KCjJ1Y9NFepTdNbV7cnM06V0wCnD1zBtPhAX7xd16Hq8cztL8rVFWhux0OMOMPPvcTceeZCSfawLnW2bG/SGuPbwPocZQtxhNVTAJspw2OdMav/M6rcXwyQzYmO/21aTev46Oe9ER85h94Ji5fvYKqwGa78fJ5ILexKSKkcAQrDjcHOLfd4Fde9ya84733o5w5Dzs0HyKoR9fwpMfejec981Mw64w6K6qor2eotZ0yNysc6CD9lWKAb4PbCHBmmnDl+AS/9rtvwHHdWoAO6fyT42t4/rP/AD7i3jtx8/gYu6rQOmOus4uXSIvwp9LeZFW6DLa3TTYQ2gCQssE7HnoYr37jO6Cbg7ZKtwNt1Rl6fA3P+vhn4GMe9zhcvn4VVdsogUgE6PZqOmjFjNjOh24nRBQH04RzB4d45PgIv/47r0I92Dap7f2rAmznG3jOp34iNpgxn2gDza5PynbHHLpu1wTad0DM2O1O8MjVa3j7e9+POm1be8TsVW3OC6QBf2VQ6M6IjcDBHOP+1NdJtJEce8PY9twhHnjPO/EPvuvH8ff/4p90E2bv5vY+JvBZjWZbB58KtPvu792u08s0x4hTaEoiq3FfvKEqFrSu1c1VZaCyr/tac9o11qjLs5F3Jzucv3Aely6tv4ggga016BQm2xDiaeSO87qn75OS9JGGgLCfMUahdsG2Je+GkVMpeNvb349P+Nyvw8mZs5CDM2irZtEjoRSauJEKkNX4bvRPBfXoCLh2GRtRPO6xj8FnP+9ZeOjyZfzMr/4W5NwdKD0yUm0vKpfdMX71B/5vfNLHPgG7fipVsWHDJNfdO5V2MLmgzeUVf9aUbdoA3/htP4Lv+q5/h3LvvT1SkeZA3HgUP/Iv/wG+4NOejt3JHCuMO7vbAm0lgYx+8W+9b8tU8Ka334/nfPH/gsNz57AtM1AE8+Ysbn7gQ/hrf+Eb8Le//gtwfHSMfCyidsc9es5eB9bY3NtpXrsqbh7t8IKv+ht40zs+gO2ZQ0CPAREcP3IFz3nec/Gr3/vXoH3+yfgHj2TFDXfwktpk9qlWoBR81d/6fvz7H/5ZyF33QHUHAKiPPoqnPPkJeMUP/184mDoPeEiz91XmmibuGTxqVeim4Gv+xnfix3/0J3D42HtQdEaVDWrZol69hv/wz/8PfNmLPx7zTtu7dol2CpQw9pKAvjQ/Ay971Tvwwq/8C9jccQlFds3BkA1OHn4YP/09/wif9Wkfjd1udorNGa42xOlFLqMJ6XSU0t7W+9lf/bfwyt99C7aX7mgHLJSpO0QFr//P34PH3nmIuXZHqL9zWBVZ3rqxh7T380JMxnuKArztgzfxrD/xDbhx4wTTpJj0BKgVJ7sTSCl4+Y99Dz7q8RdwfLzzEYxa2zr1WtV9XpNl6QGC9LrtUILtQcHJXPGJX/wNeO/7H8Hm/BkUANPmALsrV/D8T/kE/Mz3/x3cvH4T86yYAcy1RUwN0EFOUMxPq7ZXlJQCiM64djzjD33lN+KB992P7WFzkNtZCBvUK48A04Ry6Y42tTCfYJzzt7cHdeahcw5pBKk1rq0xE8HBjat4889/Dx77+HsA1XbGu9b27ulS0puCTgPb272WFuX0y2RLb7+KZf4VIjJeDBq6B2wNCa5fz5Ht8lCLbndK09kNhktpGHbNG1glTdWj3FBw8fTpPj1Pwwhr4TXf9/RDNyUgUGClGE7uw5ravHaookhBLcA//Z4fwvGVm9hcvAvV3qea6uiORQ/51QsWfwYT/PkE9eEHcOHSBXzJl34e/sjzn4NnPvWJePxj78H14xN8zrv+Kt71jvsxndmiam2DzApstlvcd++dKEWwdXAIQ8f+j4FD6ZJYhEHYKBScP2zdXIpAd4pqc4HThPNnD9tc3WaCjR7a8v+iCq3igOvzIewBitEkOLM9gJ7UNmequ8YjKUCZcOZgi2kSnDt76HnMsNowvkcSiD4HAhytbYdnNrjr7rugb3kPRA4hdYbIhCLAyclNKAqmTXEa/QQX8oNuefVhwI943D29awU6x/YLrccQ1HZetjZnqcnVOAclIR5+J75VASAFd955JzBNLdKem5FTKZDtgTtbI9Aai0wO0rV0rAEA58+cg0wH7c0xfTuWQiCbCRfuOOdON8uYxxW08n7cK5rSdgf4+GTu8gsU7a+ZnwTTNOHa9RPUS4ddnwBoafKmzEMJX5YqiEUtACqwO5nbdMm0QxHt+xnbUG6dK97/gYfw1MddwGYzwXZOFHOSYGu+NDku6NGWwJy/VvF2s8Hh+TsAeaSdwNSHjEWAw+2EaQIODjZNjwDsdm2KbjdXzLUdmlPninlu9kfURkHaRNPZwy0Ozh5g7u+BLgVAbSMN08kxXvQFL8IHP/QhvOZ3fg+7UlAunEexOX5bf6Dds+qCYU5K2iooDYRVFbLZ4OjaVXzb9/0o/tG3/K+odY5gpGh/IehScbgbAAtAY95T04PllSJvGfVmSAfr92yLLS9f+8rJF9lr+72OuysN3Q8zKRECEwU0Zzvb+2x3J7hw/jwu7jmuMUW2FP7vs2EqshwibgW5N5kz0JDC4MIvOm81Al6ng9tRtTbhn2eoAtNmgw9+8CF8wud9LW7WgnK4bcOCMiFeKE4rDLvhjzlcBcReFFxQr1zBwbTDl/2xF+PP/skvxNOf9BhsJzQj8+g1vPeBq/iz3/ov8IpXvQmbC2f7KsA2BFlvXMXHP+Np+JRnPAWb7YTdrCilbzxHWzWded7P4+wLqdyD7S99/9Dl6/iFV7waV2/MKNs2BKV95bIe3cDj77sLz3j8vTgozRBuimBjB2iXPoxbbMmFOu/bb2mvo+3ceeN73ofXvukdODh/B4o2A6ilteHeSxfx6Z/0sbh4ZsLhZsJUBGWSHlk0Q1RrbUOJ4xyMtBdiqwjKVPDojRP8zG+8HMfYukEEKqoK5OQIL3jeJ+OxF85iO6F75p1iAhAHzQH0dbZ6BLta8Isvfw3uf+QY2GzavKfuoHUHuXkNn/pJz8CdF85gkhYh+Su2JOpqNrAvmjL3TApQFVUKjncVV49mvPL3fx835orNtGkOoTTe6W6HO+84h09+6pNw6Y6z2Gw2ONxM3VaK60VrQ40hZHN2tUVwRSZUAK968zvw9nd/ENPhIVB3nQ5gvnEDj3vM3Xj64+/B2cNNj2bg0abJH4OQ8Q/ahvArgM1UsNls8O4PPYzXvvGdkAuXwtPvxwPq0U085UlPxJMecwlaZ2jdQWs/QN/K70ODlaMZi3pNl8uEG8c7vP+hy3j3+x8EtltInfuitUbPfHQTly5dwDOf+HhcuHAWRQq2fbWtOX1mPBvvujSLDcu2/iulOUIPXr2J3/zd16FOB5AyNSgrLTLfHN/AJz7z6bh09qBHOH0NhCp2cyu7zrHy2Zxal7up4NzZA1y7foKXveLVzdHCjGl7gJsfuB8v/iMvxj/71m/C+x+6gt99/Tvwoz/1i3jZr/465MIByuG51v+0N1z6qzHHfdnmwTgQTIDMx7goM978y/8G5y+cw9FxG/UopWCzmTANZ+Tn7WBmdpfOYEpr+pyV2+3qKh6kfDbv3Wu8FdiSrOzFJ/rGeiNkLHjRFV82Z7vZxJytj4SUmGIwu7x4n+3u5ATn/Wxk2/bxYV5rA+hrlystTmWyRbjZuVhnQPa4xzCgfdRa/VjGWhXTZoN/9r0/ir/2Ld+Bwyc9AWU+BgSYMfUtP8UFInuHfXi5R4oFBfXBB/GUj/5I/LO//o143id/FG5ev4HtwRbvf/AR/OdffQV+6aW/hVe95i24cbSDnjnnqyi1nsDex1qv3YDuGg2Y577g10Ij8jJ1aJgpWemre9FB98I54OBsOAsOnQLcvAnsTiA6N8Ha7fy5IVGs9qQtEl6W9gUiCtluUC5ebGtM6PV8KhNwPENvXINoG8rTuvOyUz38qj3rT18YY8ajoFy8AJm2PRqRkLmq0GtXIdh1Y1kd7NiJTaMmFJlCtYUTPdqR8+eAwzNt7q3WtiBKK3SeoVevALUNYWO2bRVD6D/W5Ujf22Mvmj57FnJw2KXWX1ja0u0UenzUnNZ+lGjeUoQU7sWWmy4zvS8UaIuwzp7tjkPnd5+X1aMj6PGNJhvD8aMJlaj4kAPph310uZsKpvPnAZmgpS2SQrH5TYHePIbUHaBz8xlmey9sdd43nQ/HxSu036XrZhHg8LDzxeSpQtEcNz0+QT3qi/NmW9hFC7w4wulbXjgyTC97L71dZerG3+yjNB25eb3JHDpf5y7ntb1oXnUO+nyLWqdHxHcKyKU7mpMyK2R7gJPLj+IPPf85+Ft//n/FmYMtTmpBLVv8+m+/Ev/f7/93eOi978V0z900ImA0d8esgy2DogA9ap2xOTzAybveju/6x38Zf/rLPx83b54Apa18n6YMtgyePOTPJn+MVBexMUGEUp61OrzMxR3LH3XvG+JeTE2aMzqkW0u/L1JeB1t668/UdMGGl+XBBx5sc7b9fYcnJydtzvbiRfdsPuxrH9juiUjT9qDTit13b4WpI9AyVLs32Rcv7CrwGV/69Xj5q9+Gg3vuRJmPmqdbNlCd4Ft6rHzyDm24cSobzB94Pz7zs5+H7/w//youbIGbN2+gHJ7Bv/rRX8L3/sefxkPv/iBw5gDT2TNA2UBhhqWvQkRtq2ep49SGhBAYz0OSwYVwArQxAED7PtcOSD2qDWwuvQkb2GZ69bL7jJ2aAWTjrN4b6ocrtM+q2gysK3pT6YaVtvUHGVTZsPtw9WgM4bxGmfq+6Ina1Q0+KqRMsVupD8eFB93bTqyzyNDkpBmKCikF88muLxYxGvvpV7pzg5UOIkDeB5kv6Z6y9HSdbil959dE/RhbrtoQeR9d0DZdQCYulZ/Nm91WFxHtDqY7OrUZ2+bMqbcpRyyaiswHHPR2uTVtw6ptDr7vyy5TOBYAbE9423LW6Avn2fgc7UjRjDvdtD+T9sl7up7P3pO85oRnACBQF0R0zR5a10Pbax5zpcRqsRzmxFh7al/dZU4r7QW35xJUad9SJr1PddqiXnkUZy+cx5d9/gvxxZ/3udhst5hR8Mij1/CPv+v78YaXvwrlvsd0OemRuUe04Tvw9qqCNgpQNgW7y5fxh571sfiFH/y2NurH4IF8sd1dG/1sj/fbc/Z7F88GoB7zrGQIukawXYlsk9/NjjBVxHq1rx3Xb9zA5Udoztbs9tQjWZq7HcC2dXp768/+YeTTrnSU4p58py73Xml4GoK2PKPXdItO5zT8vc4VpQCve8M78OzP/zPYnbmAabvBhL5ARNpBFuERInWESIFOU4vsHnwAn/WCT8H3/pNvwfH1qxBUvPPhq/hL/9f34bW/8SronRcxnb/Qld+Anow4qm8fMSUUAvlmdJ2EMIIcabCAmEFWa4e4kQvUpqHxIRpTAlvz0tEjKz/OzYFdArQ84m+OiB2/LQqA7JKZOzuEIoaoDXQBbpwP25sTYXtzk8duabkeYbZg/BlbMgZgEXTD2JPVWOXKhtOdBY8ZNPqig/3Y6kY/umMkDWRp8YoN+8UJO10v3ELE9wCOU/SUnFl3OtnBSUP3ccDE+G/eekczz5nh8JGGvi+4DWea42BbYqIM7TzzNRnc9xz5dTBWd2rYDpjtMChZgjQ7Qaum3NVNUj+A5KsZ6jjkxS8fWanNafHI1SJaAl21pWfEXTUe1OizvkfbdXSaUI9OUC9fxsUnPg5/9X/7s/i4pz8Nl69cxYU7LuKffNf34rd//WUoj7mvOYva4tZYcEhS4mKubVpEKnSu2F6/hrf82r/HfY+9G3PVFtGyzpDfNZgcNN0LKFsMHw/2mQE7rUh2uSD/Iz6W9SYR2A/wnq33ld6CJqN5eWhH+2yR7Wlv/WnyY9Nwm962LgDRiNMmrPc2ZC1CHe7d9p6qPflXMu0tcwRhY6Qpqy3G+G+vei12V29iunQ3UGcL0nqdM+yoMwDgg+UVBSjA/NAjeMYznoR//q3fjGuXr2Cz3eClr3sHvulbvwNXH3wEm494LFQn2L7FXnsYB7Fl9h0ARcxUuHFqQGb22wxL1oJw5AYj5P8uvT5ezqBd4dPvKD6A1UDEuoa9e/YI0CLhpjjSJ3fZSGqYHI0uHlTNI8BB5Kk9CotgPY1FQMYrp7+XPypQar+0YXHxouEnNDFfpR/o0YdoG0/J2GCfvNP2DF4daj6Ptc1e3djbEPJsotOHWXt7vL29COeHWHxkfWJwo8FmJd4taO7tyZjq7oWlDxBEnPAFQZ9XgMll8J8ghxwBicJcOHy6gUA4RqvIGaH2ND6b08pdl7VBSJ/MwbG2eH+ZnVFA254bOunKWQsTZHUHhuUUiVfhrCL6t0xMGOAnrLVkmzNb4MLj8ejVG/ib3/oP8bX/85/CF/zhz8L9H3oY3/R1X4u/fe063vx7b0C5+x5A7ZCKaLz3kbPRRqxmyHaDmzdv4NWvfxP+8GOfBxsB5L4WJm1xKcnAMsG4xSfKzZcMn4tnwwNlejhgo8g20XBK+Qu7YGXcCsRPgTW7Cpc/zoOuNnb05ui+2Qr+DtW06IH/xkblbSb0DMjGdk+794b+bmdoQYKGGvzGy1/TolMzYNK3ZEDhh5B71Nm/1xmQHeZrV3HmXMG3/dVvatt4RPCrr34L/txf/vu4euUapnvubfvh+wo/NdooijMANlg0Aypl6kBvBzG0Fap8GpLaPZkgZWpp7Fg+iyis5O5R81t3mmGo/QQkjYiNBFa7NNu8ldipVr3eZoX7nJYjsJVvJyOFcec+8I6AyZak9qH0fYEQ8No+aNShqT3V93wCoGE89TlPpb5sC3TmNheqCql1McLA9bS2dPAXgWLqe3CN/60P2l9fYEd8i+8TfAFLXxMgzm8aWtTqhttBqKrty2pt7acNiclp7W+E8c/+Osj+58dZOqAY2AtsRasarSip37H4M2CiSNDepoM2TKyV+ojotT8bUg3+19RetWdAHPLAlzmtfMu9Rusn0pf+17bElKDVwNRttFBfwOeRvR3WBv6e5E99S5swf1CabptsaJ9yKf0tYl2ebMRDZdNHpwoqCuqs2NxxHrj0GHzfd30//v1P/mfce/edePTyI/imr/4qXHrs3dBr1yGTzdeaI2JeVUyj2VoE2wI1n8z4zz//srb2oWZ76ZArAnF9TEynLjkdnMY0+8DZdkGYW2lOMf+5X9fbxji0uHxUzytx4lcxI6WhYvb+WM+jADZeeVpPb2kX7PSyb8nK0asw4zcMPy2GgDWkPdXT77kX4w9uw6UIGQuDiTYXcXJygpe/8nWQC2dRmOFWvyrCDewOiXU4tqiXH8T/589/A57xtCfg2vUbeOsHHsJf/Nv/GLtasblwAXU+hi1DaEptQGsGJYYgM1clvCpuhrIQ8RYNE8U2lKPebGntshIUaMNcXF94v+teX9BHbhTYwDVHjSIofkGDORNrzRwkSdx4MycibdDdO9UNmLpNWUgofRX/rUQTR0mWjvjhBHTwFeyJaqwzWv3LmS6zeeQAMYEKjNvvlWiM5/u9chmf6nraVIMi12r4y03C8JBkR4KpYYJNWBG8XIJkcEGpDO9WWyzEkYrXHvLFlsJokSXh9HwgItGjYG604obFaDJkVWIYO36mHyx/wt/JnvnNQtUzMMThGdJPDpu2BfjIJ+LH//2P4e5Ld+FFn/5puPLoo/hf/vSfxLf/i+/ErGfD6VDAjtf04x9Vu+PTTz8rAhxu8Tu/93rMqm2VtdMfIwRd1XPDbueygGnNWSImjEHfLS8lufnwKEr5bwvXEKTKIAchDstdOgLhfbYaYMRCtCcMl1RbS7sgdCW/lRGES2a+D/tRXlUS/5w/N3Yod6zX2tjzyCS4//6H8e73fgCyPRdKRZW5zXCDp21RUCnYXXkUj3nqk/Hlf+zFuHzlOk6k4C/9g/8b1y9fxfaeu6DzCWBQ11cur81NZjilRqkkCcgbuhlOB57YsKOEIZIVHvGeCqHyiKUDZeIk6jCm2A43WRHWBCDKtxGGOhwwG65bc4wTdSYfq7KgqbrMVc0vamJZTM5H96UleNceddqGhWHBmlETQf0jzvLQH2Oo/eMTCNQG8efBSU3lUyGLX2sGKDeJh0Q7nebcmhpq8FSIPnZOo64udSYX5mjvoYOXIfn9SnYGg3yTcRwzRjLrH0oiuRweUgzJ0pTdqmD8Sw2hyAj0NR6lH1nSbZy/FxxylRtnC7XabJZxpY2+lUlQH3Mfvv/f/kd89FOfhjsOt/iEpz8Vf/BTPwW/+RuvBC7d2UczrCI7crPGEZQ6Q1GBnUK2W7zz3e/FzRtHOHP2sG9pc1YG4Bq/Eg9JH1n+GUgH/lNO4ilSGprooiTLoWoHckLDfbLvb5BbGBpfkRNtzDlXSuQnJtGDjks7izC3jt22PW6C5VBSpJygNzi7cW4cQ1ywYiz35MUaY5bDzrbyLv22akgfat9C8cEHH8bxyQnK9jCo6tJFKh0N758iE3DtKr78816MOy8c4MyZQ3znv/9JvP3lr8Pmrjsxn5xgVmA2J0R5eJYAl/mZm5v5n+5lrU4cyBjobdCBL5woWK2LZ2zrE50y1L0gmiwVCb/mzieQYdpbLW1l52BYzTCNoybmRQkWp8yYrJq8LiTWSQ7F2AcPtpgn8nYGpnblgpXb3u+7YWDjk2pUUkEDYaNgrZ+U+if/MrpGOYv7Y5qlIeJ8C2gkAArZiIU9vlhPsOSTfeeIcM9wXkSrsQXPIjddc9A0WhNyK/yrt72nWehHcNPzpEoycIzDnmuX8wEMBCF3EPFV6PZnuss7IUwz5lkhhwfYVcV3/eiPY7Pd4tErV/DZn/Y8bKYSW8WsdtX0Vqz0pxXlcIsr16/jgQcuh+0c+mH/tU9rsNKvOjyO3+sQybXssVNY3F69Ti/9tKYO4D44C62bxinSkLWVfT2nczUb9gEU+f7ab/JwE1gnQV0z4PB5YB3Syoqhi9XCK7RRfSKC93/oMnZHM8q0afWW4gKetvmk9kyYT3aYLl3AH/qUT8bJ0Qne/O4P4Ide8tPY3Hc36jxDoX3vMhCHDTSBtjkdG0lIMt/8ERqiUJhHHltxwhgm4yrBHx5qNmCz6MqsikUs/p/0PzNAyis4ydiQUQlDT0ZJ2DtElG09G2PfbuDU6bMk/D1YYdbKhuCSLFEZbvRU4W+UUZpLS5yLvKHImvnj/cfYPDgUNkxmkQjU1xo0zpNVcHAKWQ49iMZmZ3KBJkMa0g125qzM1FOcjtIQXS433s9EvoF0dAkoJ5Wp2VpT+w33nAZqi29F4/aZx7US0YyaHvpFqZyvdK/rjOtOcNXLWci8UvlA6qMkd6ERQaEA2s9Wb+ooXp/NGccq6MxRyxP8bd/rbka58068/dWvwWve9GZAJtx3z1144lM/EnrtWreHsXZBXY/7CnuTVq0oZYOjqzfwpre8E1DENjFEe0dmm8xnhzL3RUrcDRyfWRDTiNQw1hG2IYJk21OPjk74kph83/FjzWm2flgDWfXykokMfzCToLC3k98K64m2Pd9PvcYGEhUr7PD74+q16JS+yGqgQMzAsaKQdvOzduqS4P0fehCy2aBstm2BQumLXWhrSUQ8IRh6MuP8pbvxEU++D3ffdQ7/4Sd/FkeXH4WcOWgn4piBoSX/PKRm/mmOouy5GfUmlNoVMHHMgVBJQYNPS/4nzvZylwbQwN2J9CKXvS1W9nixhGH5tbXtVtJDyqQY5CTzEUM7+D2mzZCQwncD39g2EOX1jbLKZK3wofNNh3bxqudW7T7eArx9aPVTqL8XRMXvwe8kZ85kaszKYUHI4KKZSZeG/KkxBpQrSS1JosOk2uSYmrwQY6X0QbPYbTeQ3Tk31V2RR7Mt9tILq69bl+wYpbYJRl6vo0/mdc7Bsmjf8zY6owP0GQjEpYm/GKJOW/zcS3+7rZ+rJ/i4j/sY4PgYvpLeymC++/3W5jIVqM546OHL/eUF3IB1GRj3MC+mBjmnjOkH7q2wfawr6diarRt/u33Yhzmn2CI59Wmmd2zI8NMj2/UMa4XHamLueh2fc1HkHa4Bb9b9FWMmw97JsR3uJa3QO9hTsz2W/m3v+WCzc6X4CUW2Cja0NYAWUqAKbA4Pce3hy/iR//SL+LVXvAX/5VdeCrl4sa3wIxW0vZm8AtiMv+Fa3+npDgayy9BH381YBkia7UkLzbqB5ygsRy/NKrHzGGpoEZZhrjjDRhk2QyKmQWzPBt0en61edD/6V5zWVuaKDDEwCNzwWLuTcyhGJxEi0RdjdG1ODuf3cmUwswv+xOISjvNdN6RRudgbrrnMGPVsvTOKufZngxLCnDSA+914ol5PvMItGpAAOYGV8SFY6P4eyYE7mkGgy5I5QEDIqDsEQnJkQ8TeTgKlRGuUCEgM5Xk7YoQC1L+cq7VjbXFgXhCYFnopy8rAH08bq3bND1BnoKQuWwzZy0CL8YrBkvtursCFO/Cm1/w+3vfgQzhz8W68+e3vBA62ULXTubqdEaW6WXmirUcnJ8buoAnLa9SP1AbN+uQFrgRQGUJDuITSj46s6zPbDudVjBg5Lf17sgkI/OA/peM8F1OV9C/7+SmVZu4C9CICm/jOEcdIWvxazp9SJcYgA5ZFTJ11uX1ZB9m1elxhRNJv1wvOsjrcEMby0WtXgakDbZld8exEnaZwXVFtKMaGCbcH+I7v/H78y3N3QEtp581qJUIw1J2Njfem84aNbzYK0rVVYfUnhoTR6+mV+CMivuAEQuaJPNClCVJi2J6+TkrDt4nnmTCnV1O6XL5SvdoNqDkVQ0EJX1z2PCfb7qzgxm8zqNpXTY0HNCzaoyaX2RDBPW7uARA9xC4JUi2dLwpjfjH4GJC5DHXaJReYOWSMI/Af5NLn3rsBF8oW98UB2nnS26ZU74JxxhcBOSg0VJ6IzXbH8GTtGiMn5exj9EIsVNobziE089B7K3WYgeeSllVDbPQlq269xvfF+b+wfhVu8F2frWEeqZoAChTtxLN65gD/8t/+ILRMuPLBDwIX7miHVvg7c2OBYGCrcA3Ov7xFMz8fbfPeka/htwFfVKTu0gT/wlLGPdpzzkT+v7waO7OuBmn77Z7RGaNNtMiQZMdFToe3/izkcCkCK4yyPJLSuEfC6RdeaXRqbsuyXi+XACl3E8JYesGLEoavRGenyL0l0stwDPqK4u4lT9stcPe9PUU/Tzd6AGpHBXZeLZwDM8zuPCABhphpVc3CTcrs87CWl+g1/rhBN4PBB0tYXSnykSF/MG0EI44Ukt/AIOKghmScXU4yO4IvboyIHxqVcaDqw+zWpJEG5e9OfuszMUVZGs4cCVn78vrIVrcOkXTw3iNYj06HYUpyTIEA8rQuQQF/rykz24CM6WVjH8LbjW0AMCMS2Yy4Xam/R3Ac+t4cAW+7gXIyjjFe0/pSIo1HbpQ8uQ0mp4g3kzHYd53kuqKcDhzGH4QDYA0zHobTYY6BtxA+X0jlR/8MOuY8QsfUaLnbHpZna5vJPqv0EKwkfSRrrrUC2w0euXwd0BOU8+dR55Nmt+zkqj5dYbLWHPeCRDRM3tiBlMRe67c0ysb9Ndh+l4IRwIZ8jd1OXaqSbYXbfgIzJ12prCEw46QA/BWxTlvyoINmoyugcZzGNHdlAB1nnWKzaGhvJhvp067TgBHUqD2ZV5/nBRFBnDhng8pcHkZt3UOAldMO2d7nLXls1AFZujVgQ9s6p50FK0lIuMfJOA80jVH68gpjsEZjarcrbfDJPVYCfZNIBhMvioTNlIlXJSbvkg2a2Xi/35Wwau5nR4UAh2XLOzh7u/g73ChbUfZQgFj5yoCiSG2IdoZ6KAA/dNjBd4XHgLsf4TNlWedfnk0RWz16fyw8dXQjwnZKRh6pi6R2/kZ3KJiZYbypv2kPNteaDE4wyTuWHVxvoxMRxo+xwWki+Q9mItEtmXng/ldEO2IYFTQ3Pyo98y7fE8CdFpOaWKBlzc6AyUFF+k6gHHfCdgXABLwlMhe3iE6TQydseOZ1mNPSa5hnlK1AdQOdT/zEOxLW1AaBBQRNm6TbQzti8LTr9MV7SIKg6Z5m/iKZktNKTEqmPCqwp5y9+NQTi2Va2LRM51hKXkw5lm10UbAlvs/21qA61ORfBzz0TxkEeLzGsf40p8QG3xFkLGCodMmNMAanSQ0prmiPWvPGym61CHCpXBUDWjOCTFgoouuLW9J4FlFm5ouSN5lXKwbwgT6hNh9IUSspmcIMiTkKzOOeXsJo7wX4qG55OAaFt9bKGLYSp5dByI2odAF1Ur7VYgABAABJREFU7vUylOgboilAImroIBkrnIMsqPoxlz6vnYxZ9LVvofX+CV60OXN4X1n0mUYkPNJttIe4WKTb0ue5dtIfGsEwfQiQkdQ3MRpihEaDAnuj76X/IkxbRCHdknkvxMEfUX/IukZ9zuqs9VZnRPDKxSMivA4aykPeNDrDhlA0RiQ0FmS5bQPdS3URyd5uMhLGc1h1wcvEH1D7WX5oRCGOrLT8xrts0NMipYUdM85nmwGQ7hnpqqHbRhc5O9HnNL1nNJru9ZeHtNdEki0cogReQe42dI9Nz+2x0UQjiOzjCq85wEoBIPMpNS7b1bXLndf03CxO0BUgPrhzGrZ4Gajn0VYzC6LawXaFJmfiGr0Uwa1dZvzWs8p4Y08p9GzsM1m5t6jwNISN/K2ddNSan7ICOlOClKAI2rGJ2o9Xa/MlOtd+bkUl0pS60NpiyqGOH6tItmiykF45erVnAzAG+Oa60jOrin2D/pnsQRCQ2Wegxfm7EMfKaXsckSIb+8jPBkt9jt+MHZcV835RMRsRMyzefOIvRwRhY10QIg3zkxTdbSnxwumxXh752X/4AiEBtL9OzR0sSPAztZ/7Kgy1Ot/ynKmDmnHdrAVHjgm8RgMZKZj2sAXGexBQOXciLUHeGj8YaK1iW1GsQ+Jwtkf9ETeKCkqiZDSDE1Rh5/kK/xl4xog4FTOCHrPCadaFDnlETU1h/bH7Ib9dbpMd6YnVHBaNP+m2C+agtfdAO6uoXyjkin7t4Ctir1oI13dhDoRkdjS1o00flCaPdjAvgxmLIrHnckQ0gF3LzaS4Z7BaA6nMLSHEaN03OpniHbE52+GoxoXlGWhK9omjlJRuEPi1aHgFaMc5HqKG8twCMIzOvdxqxtpWy41nm4bykED2D2ttnSv00YehskE5d67TXd3w8dCfKe44/LqcSxwsuRkTn/u1qEh6P4TPa6xJq5IXzEOqw70zU85k3O2eQUnQGEOdptQLTkUU1XkcQ9LUNieR5itHmpNxCkPbSNe+kC0DxsgP96QTqGdFWJMWjlxX58ydlzHiEQY82kbmt7enJJ74qAWsSMnPdejbDnZKdJrSj3OsXJ4DCbU/2kAgvewC70uvr+fLvAaNCnSQMCfBolqv3xyQoSKEjrVjR5NkBJUu+2SQrIhk/NR54D4DBv5aq6l/rWZfJ8L9aY1Q7dtjrOaBjnxUGZlA4oWC+N/bNaC3pnKojdrmYNvv2WnQkxl6dA1AAQ7PQLZbF/R2fkAxjSaEz9J/O+8x56mZ8Zv3AXKfDNrQyyD9BJJTDOXuJfmWuAfvQ6sgFjBx4JH1xX94toRRbIaH/rgtDLa8CtibkOjlpmspl7dGoF1LZiy3v0R9YoymRrRb+d6ChIW7uE7n6j2u1opStEijVojO6ZB2oQxKdNd5xtmt4H/6ii/DZ734BZCja6m9ZluMjvg9tI2BFiQELDmjklGbJcuoaThgvnAHJDMDZnS8XzQGFBdDPtQA5kNyIASo9rJvIsF4lQ0xR1ccfYZ3zJ68tQSQ3OW9IWqduPAmbSqAGDM0TSvf6P77IP9LLzUsQKZHCbA693UZ1XiZIt4PQUGUI0Sfwfg4cgEDVjM+xmwGD9YLxxBJ5TZOW3skqSPLsECA0ujItq5XTKCeIpj+r28zsrzOLo0/kkUxILaCOz/dMSK9aTogQ3/xHHPwwks3OU7Vky0jOXdHrWcQqt/xeeCz7pE78jlAFcCA140Fl49si1Q1XhbiL5boZxvXivlkB+gOz/vDL8TnfMkX4eDwAPV418+0qM7L6AOixfmT7VWyO8Ol6fYywSlm2Hk1xs06fHEWJ2OHMOQrGUNb4xIsKTR7lRSW+xRrIRszruvUSuDY7kcZsRp5jSsrBaQhpZXhglOZSxFBBhelJMsyjbwlGI00EWtWBSkXq0pfdPaDz12CGC3QgaEU1Bs38JxnfRL+4p/9k/j9t74X/+3XXobjub2A2YaRA6pCsX0MgEBChnvscZuHFqtQu8dtUUWKNDofJGY2PJpx5S0LQ8Hevyu+l7DyPAk7MVeV9gaOc5EMVBzFrbTD+Lwa9TNfB1lRa5Pm9L1NBiiCiCi8DANn1nLSYyGaAkL6M7NMC3RdU3i2znmdArcz6KMVtCs8Mb57+trbzF68MY3Isz5JPTTKAuD961X1cgRD+Uow6Wl6K+0fOud7ZJc5Tnl0h6cKiP9kOwKIJFgLK3/of4RchkzmfuhI2ztsCSEGkgHj3PbcsKCF5xm5f8X7ynlgNsH03VWVf/f09pYu1QaimAEU6NERLn3k4/E5n/uHsSnAm37/jXjn698COTeR7FkHSfR5cBp2frJj2alGnfqReTXcT+lWt9lpSsj05DKT59QfsHCT5VWCQ+G+GpwXKkaGcnQsf+U6HWj7p0je+kPJkmKni4BiPectLo5wScD2lbW2R9efdXpW5w1Wy2Or04TOX/DchVaNxnSIb3RzqYDMx7h49hAPfeBDOLp6GdNGgJMKf2OHkWsbo6266ElDOpjguFHltlKewXGHZxqKXYi5knixsDGweArqD11Ge2Ez2BAJCWZErz4D4VGCUFVhjU0R2OAl9e9tMg/R+2Joe6yhstpIRYXpQeTv9DEIAOjRYfZox6GnRlbPNNRt9zmad6Xt71f1l4QbLcp0Rxt5btVAxq9BfaQsQd9bQkY/zayKkriNs11ZdhZR2Zhah75JabOBTEOJrr+CpO4rR3ZamtxM9e3tPBNoNEVXR/s5r02XxOo6Qjr7xvJj/UXtY3BdA2yTf+9TLguUJVVoLBh45zJL4KkNJFs/TXj44YcxTX3kSSpESqpQO6guGmDB0Frg1Mkgfz3LH7d2H35gaa+TQ3LaleSJb1LtQxp+yliiEnKSADWNzNyKptOfZz9cCWwZhzL5w00ytIPUZ2cjiLccqQqKcjmNch4WuoXll6U87yV6/fIhR4sczIMcLHh4/dYIxfFJRSnbzoOuzmu8T0pitwy8oz6B6fo4D8bbQ4a5VTKUo9fv7SGmcHRm6XyxglgkwRFcRIhBjzMPyTJ2Q+fDm2BlE1/MsYjOSKmDPjbujCiRL81BahjZpDPMD3OuQH3pxrc/V+LY4AjmCAkuE+oCo94GHyHwPHlOlkGtpS+9HWT4uTHe9KAp5T+Nl2rGPeRznxHx4GJwHjwarDFH7zSopgEO6pCFSWGe8ZqC1J8utTHCIhDfNpXkxwu17zwiE0aurTrXQX7hPEf3xpTZ5N2Y+ct6znPuxj+TSYvoWxbiRFRHfU66zn2KeO78MHkKroJH9lAKZgWqCjbFXq4pvc5WUeovo9nBNs5QBvXJGpix9jAJ8SzzaS0oWh+t7GsgItFAbpbfxUDvgL/L4kMQRjqp0OgylgHPdXtAw/YinSCVBhNYoNeuUyLSBJh7E2XDocOzdXMw1D0m+jCAthWz9DCCIrMWElGQ42ozMDOAWjYopS8mKAU6t+g4trp2MAOyUiCMwWLFJSQpGKicvIgp6K+1wuZjOZpMua3XexNVua5eX4rISAbst0dYAzOdLGu1InOAwMjzDLyXbCyjBV06JVqUgYBBkYoV4eAoACRZU2YOkM7JY0+IFC7jMCkuRwdepXC3xvGWLguxGCeALIzNSEa+Fo3zxEMg7qDUpiH8ZgJV2DMzzpbNZNHAR2QhH25UrAcH4wmgz2Iw2g0yiVFH2vfYYsaGjypFTu+lm/4GspKxyUOnJuPtUW8JYU2uN/ibTIgXwkSA9JGwDdyfNLyd7K7JFf82kNCgxZwRSyOKqooKgUrp/VWCYCntt+SxPqY5pjiwlCXke1zAPru9b6h1bSosbDD/RtyV4FfUSnp7O1cKFBYeQP65zLz+ZKVuTykdbEX62x38IqOxwiQ3Cnui2jFH+q16a35QudFJZG1YWIUUdOjpxSKXFVFIkaxbmCi8AS2bvi4UKqgqmGsy9bkTuebBGUrRslXp3jsC8AS0j5Tm0zqdo7os5v/oufeb5K7l6DjNjTm/LR9v8ehUa64rRwOdRjpEICLWaHNqgdHloMFGsgMTR2wafBnnPFt3hvFzoBUDhAygSpRwZGj9F6uIw2h6XgMhNs7EL+Nj6nBI71sjVr1PuZtjBERgETODVkTDwwI2z9LbSf2cHFrjpbQRDo74efQq+yEaKunEcvsRfWWcddAA8ZF5HvSpgSyiM+3oz5AJiboVi5Ol2HawXBNj3GlwfUz9Dhdi1s88ohRdymDpOjLoh7fYm2DMyvOJPqLE+s8XG0BIyEwfZavaFupz8gayvU89ghhGWczB0RXgXAFa8t2HG8kq+u88R0p9ZPqOHPTtnQ+NBO7kRTaJvLpoRavOPikozHSSrO6hYaCE+sRJ80+RPme7JEdIEVYI3QOy+66U5lTCsdpZnaSwcBii5j1EjJPf+y8xjnSljRqi/wTo3iDQhHbW5kEaj/tglZPrILcAxF4cpXSDMLaHvXEd2RB5kyFlcXUDaQKY76evauIeXKbtrAQBmXWez20UWdyhPXlIPNIavywKieapg1dk5QLJaIG5aQZGg+FMDIFXXARgVlb/x14pJ3ZziGbTNMPK7yC3948M96h/F5onZILyA6xXo4vmcnpZ78mB0Aw4WefZeWChHNR26JOhAkoWowW5awVp3haDPKXErriZDpedbIBD6nRIl5oTlEi01fWD8rjDlXOBFdpdVO6zUwyT8BfltMRz5pnZMCmYVdu7tF0325CyuoaPl6b6llQNSIIlDgjWgUmpncHbtRpG5F6/3PFJV+Z13N4PuIlw/036TOTsg+x4FahbjFw40blJFSZtFoisVHEa0JJy8VL6MDxkpIayooihQ5OHtEbPSN5g/PZTO9bcTL0oIMVZEYvkog0CRdWKXdX+EnpLxENBJLwagGG0ddva2S59VWI3qcLdZgCuVJb4EwMaj2BE3AimIeFkmHgBnFCx6t85fGPAtY8Y3QjWxBCYzS3B+zzPH0afeHMogl2uWA4+2qk8vvimAmLD+KqQklcuj3OXeRh4GPI0IzyIjlIbRs/c+jPqM94oopN7fhBgm7xYO6l/zdvOKmllsGREt1qZib9maEFz70p1Jf6Gw7ZoryD3S+d9XhOgnfZeL/Oq5zEZdZvAIEGOjqok2Y3I3YCS519DAJPhs/oHWvIiNsqumYdpmoKinXDurG7A1jq0soK3QeOae6PRps47XlXtTjPJZqK7tzPHwwa2wAzFXFswwJYzOazeBrPJmkBxHUAs+4o9pSiRI/WoT5yHIEdxTDtOF/H0jKcjJW0nia1jlb+X3GgYaE/4zGUCSQaGgi1nxobFFboCBZ0gZTf7US7jysLbvU5LbtWswt5aRXsrJwu/yCLDbxbedZrCIzSvjwQX9jUET9HmSOfdjN1uh3YYBmDDQf2H96QC6exkAGkBhdlSM8ipmd7c6CTWl5Sul+HcMQVOiNLTEDDlwE/7GcGOglRR7ru02pSNl5HrzoPP2KboNwOJfZJRsYIMhA1wzNlQALzI0uuRBHwewVjxpgN+lCK1V83YZ3JiODQWe0XHRR9FAEQgqkSbwp2nvEAtZIuwsn+J9GYP08ISIaNLhiV556MTi/G+tV9oTjdfHK0bMKRFVRA/q3lfxO+94/xeMWb8wgUmzehSA6EMbCZvZkBdHEmvdJQryu/jB5JpWkRco56xLBPd1rehtayDA5BQf9rRrwmChHgWjIRoiTOCfX62gVrVmp1VJo/lh/jigGsyzlfv631A2wtaPuvPk6qPeb1+JB72LMnEjUkWNpNfXjLybCiPQTVdI//3XAk6O0742hkrqtO0WRCLIdUCvMhHGxi7dh5yrjSnX0s3Nl4WbB3qkOztp8JNz7vyjAIvYGMsSJbbrC0ZUDMCqsBuVuzmit1ubkeiVQV0htbZCUie68AHXgzUblqd6hLny9NpTjIrQbRpyUsz4oPh6HUL0A9PGOZZuzbwHEgyVCZIZCy5fTZQBTIkEYEjpee6eB1AcpAMTLoDw9FWi9g6H8gQeyRkhhksUzVY2MFlfOuAGW6jnWmEtZ3oX2iWAOmNNs67oIm8jv7V5rwtKh7QxntCF30q1MbUjz2LR7ZWVIoAl/2cDCLLm0UQLKcmS/ZzNIdUbRTO/I4+9X6y6HV0WAY9zyM3IyhqbnOwL+TJ2tNlQL3vbMFUtCXJr2SrZGCurp/9tsuvUt3RX6EHSO1vd21bjtLZ4MFDTi8oUFSg9IVPKKgAZmfbEm3znHanhgBXxgzUVi6PncTF4kdPJ10UGkFprcoaZgzPzTqfhivREpMvVq79oJmAVoZ2DjTuD9hGIzCU1Z9vuMPz563nddZhcH8avreI4lKC3gEOhHxZTVby8FyH73sraVexiLb/VVPetUIVbStbrZhrxW6ecTLP0LmiVkWpHWwdI+LVVVmwh1XF3DJXhn6PjqzDIMzNIIRxjcfhdechwywwsYCg85lYK2xQCMTgv0cOabrnERvT2o2796kZH6OdwIgNrRBwpQVQVqSVZa0lPqDzKEWoo7EHr4IWbx/zKx8hR3JHhjTSK9IbEdxQ2jMCWjeoUaQDizVmjMKsD/i3facyBkx3Ay9Gp8CjeKX0aVEUxmsAPAfZ8TEBJZtukiOTbLeNJF/ri1u6TAXqjQFa/53zxaL9cRDe2mpqYHK+fL7YqJ1oiq5qDGx9n7f/UK3O8CjFu42BwojvMpcdVrpEYC8QgLSVyRUNrsPhz8bfAD6Y3/6cj0VCH1NVkj6DZi5+hUeDbVgDrn1gto5Dg1xZGbDW2d0VZ6FVNla+/O2O6+1cZLi5DpKlzbIlBHBrtTARo1LKsvHth+b7pkxcLHeQG7jlfKGR5blZEZTExQzKLQA3CVVnDHecR2WAe5OqilpnzPOMebdrka1qe5+kzj1/8zZj+HkAPauA6ho98QDfoIiHhcQTx3Btu9Vhtr/BJveFUP5oD0eRRqTPgRGINN0kwTJ+Eb9bMVFOAGrM44pHoE0hHFzdYw8+WJ7FiEBnUJuXyQBsZfFoxto8onOQDLLTmDqL+sVoCYiGq7iC5jytTwONI3KJ+zrk98uMrPedukFl4+zugubMFjEbzdnQBC/8NKNOV1JFo8xXKQe6LSJSz0R2gWR9bYQlIvGW2MtitqGDl3GLPIo8IsLOmEY97kjmOeVFfQ44DSjFXrmIkF+n1eWKphW8XfD+DIAkXvOlmiTBMjS+EQ/F+tibTo4FG/UmlQ62QHf6Qw+ynPQ2c8GaUID6tX/sAVp1HqYbQxGykIWxzMyekNlxGk5Xzu7PC/4H6O36vYqzg3M5UnNKaMjELkFb23SdwE6QGrwstUr3AdVCcRf2aPE7sq4UqJrS5Rf6rrVqbNCejiIjvu8qw4Hb0Roz/lZS/yEhsLXOqNXOJe2KkiJOGuZK5dnPYPAYgTID4ytZLptbR9yy9GGcc38omoBaG/1ZMm6kdERiGrZ042RGAUkmIrqzmuy3fbTvw7IIIjy8CRthEQTQ+nwhshJk2SIHQvMzN9ASxm/ko1iTqERO4H1qfW7RmnZgWIvMmI+9/1keRhAG1kWbwdfuqBHFzgqM99Zu45dk/qR2coXUp0RTSiaAKG+1GZm2YkaG/gCzKoXm3OCYVlFqBRxM2XngosmOEM2tFJKpElXyEZxLXg/tT3S3Atw553SJG1xE1+XBEQo2qNPLySEUnVplRSBlAiCYYa+Eb7wZuy93vCIzm9ZW7MOA/iyPCkWrVud1YfbnNoCLylgEZvmfvVdGpiUORj2RftldzJfBVoxJkdnsdhFNjzdWntrnEIUuCyXhJmL2geyY33+PUca+i8ofh5+8NMeFFWNwqrRwRw55u9HMzDYDoFCtLbKts0dnZsr89xhxi83/Gk0D/f2ZzTkmKCYLanO4LLYM0OwBB8dafhOGNhdpoBURmvPWE5LyWP7kMSznUZ3zQ/TCtC/nF+k+t5eclRSUqi7a7xEFSbwm+mxlrvE7lAepvqDH2268zIx1XqX57P7bl2ZRHo7MfDRiBEgTO4lVliz/o3PKTk40gxaSOTuWc/jpN9PF8pT4R9Va6SO/42c4XkOfe3lDhKkuB8TDpIY8RxuULEy7RnvHvgzRDsnXDhzR95rf9tIBLjWW+iOBlZg8kqGnFOE8JEa63jvYeVtDP91F5ojY6tfibay1b/1xOtsfD93nbSvD99NsMtGcpgVW5v9Tv0jksfbGo7yGZT/Qjiuwx1pCcH1EY418dgb0lLaL5DacdskK2vQbAmDTvJ5BgOQ0Xq/PNw5lR/exYo8lyellOT29nLxoov0rmjtp3eVgwGSjJijFlkdRx6kVNCgRtbB2gQ6QE2e283Tst+HL6nAMGVyrb7HoJeE4CYpF1bnxTp89Y6/V+8mdAEtAYjMAdxJyN9bLBWhY6182pIFMS34AdGpQu2OREw95aeKzUnoQcDL9vakR+vnvBGiRMpEv3C7JbbRno9OR8nP5FFW7gSDEDXqGaEC60dUoRsb8CYqoSnOA/JliJJUXaQVfFTwFsdKwdaNEBsHkJOZQw8loAzVZP+lL54GzKWyB0bdWOStcTyfePntifcCGfsjrCjfYxcGupKpIHqMVNqJiyltJGbscmwzX6HsnYWGLBgDvDqiqYmf8grTdBQ64yCoc+71SuSK0jmPl0vQvuwJLfUk0yjqAjtf++dsRWJdUjbdMxvZewnw5LeEtrhFp3RtqP9PWHxnSrlbLka8uGct1+GKToX4vxzzbPTQzWEe0l4HHjcXCpciwvBgG6oJUTKi6cXErzxFOptyL281zHw0YOSArOXLVUI7k+m3qbIF0TzEWBHGkmCJDu2f1CintQE+e4wINQwmT1suNCFN6lG8kjrS0IoeFDywrXmd41+YoxVwvDRCac5XKg/dHI1mBqn1uzcqK9nLEDaaZaGn8InUfoogUhffGx7oAixyG/mUBjjDNjTA70jEHH6jkJyUxDw2QmBWyxnPrOyNxZW7UPgXRvtoBdcU7DL4SD6xZXpnS2d/BX7X7ln/BK3W0VedvtCGpbedVGilgwBs6w7RXiHfqLKL5dtedPByf+NH5hB7xhmxQeibceDaEr41nAbQxp288Y5ExGpgFIS8y1GusmGfFSZ0x+Wm82bL7tuBBppJbcEvMiT4g4hZYA8ku+FisA3SSpwzAaTRk5cqYNeBN+qkhwp22ZKMWxNG6jf/ei7p3oywknfIRNP+7rtvxEGj4aO3+osj+r7pZXhqGPT9XSzI6fdgMCOOAoXNdyBuDFMDJrvmPUia4RSmld6jsJ6KDRigUG/v+wRsY0yEVyMbAPWLAV8DG7dy36MNjZlpoiCzAWfzfRHDXGHFDu6I2pzA9hNtuxMIqpVSmmAvvl7wAdx3YTg1zQavfSev3ec6jgvEoSLtNxt0BdUXcnbXRH2Tpqb70sSr3GJ+R5RIuf0xsQIAV+rwIIfozUOXvmdCEybpi1AwQep409bAy2tEc77zIKzB1NLzWR2SsVwxAOEV0mx2w8DaCbHfARiICjF0UScfCsQjActnuaSXZ2n0yGcCSMT/1wtqX1t0KSCmYpoKpoB/4YhrDsGdfJYFkK4MIN9qZj4nvAxkJS9blia9ke0lPFo72LS/B2LxFvaNyZU/O5ZCfs+ruKTXuSuunxahAl5PNaPHWDo3K9AZRHJUl4ongheFU4uy+iIhzc8Tl8mlzO+q/vcEuWLdeP+Y619PbUng+QYcZHu2bcHOnOLzzTsjNGbMGAAOgucC1OS64cBPuOC1JyUToXo5OeGWu8djtK4b83mc8HwYy1u0Hzxk3YGaQCUO1eN4LTaf3DX0aNqZxhed4xzlg50nPKIlBZPR6mzliFSDxyphhdqV9hIFOoBLhYDrY3fnZ6Q8bpClfY/FyLo4dguQgkKPk9A1AROY3tZ8VOY9irF2U3qpnHDIDJ8jRKfFrpcTFj9WTxhBtihEYar97IC65/jRkribjHk5qN27I8hk3MPRBPNcuXIs5Y7YpYkYf0CGNWaWYV+25Fm8PYoZ2usc6yfi6XiqRTjpm9bN4xyUopWC+cROPPPAwzp47h6PjY8RozIqEEIC6A+L9Fg/clpH8jsPMKThh54DtQHKmohHjuo1FeYtr0bkkw0YgocBQ1jjS05ByqMIi6mjIUL+s3Ft+teI3a85O68w9De1GfCxTke9HJct5u7BbGXCdqtUrDfQkZeAU7M2mKaYF4K8AQW9Q8JWfGK2KcniId7773fihH/8JPPjQZczHR5CDM/AFL/s8H6+aFDYJ4p6WS4CwJ6R+Y2BK+RxQ7bl0mSKrSsZEyFoal/M8uTpfAmidQG+lCWfmshXd6vZIygyLGz8nwXmWGkb7iv15p0OINn/G9K29o9fTMOO4SppnI9222qM8yf252vi4p6n8npgNn381YiTya74VBoUyy1CGRsoEiky/kcEAwV0LBrTcwX7wwtolYai931VDWw3UjKuOLcHTbByjje602ajPGtPtxRPIDmACZW+uRJvd8LOzqymv2WiDpORkkmPhVI+2k0ZK1N9QFF05ThHkaJI6x3g4FZw8ehUv/dGfRjnYoJ7MkO0E9PcnL7kzyosu7GoiWDCkB3W7GJEDT5fAub4A6lbD16Z1rR+Ic2CHUFPEuGxH1lPF3ko5zWK9ApfbGTPqr+SiNw4AVuYYWg/dw3WuzQUtCB2ucZ4RI9OTgI49GuF58kCNfnbLk1CYUI4GoXVaW2wyKhK3JQytKiDbLa5duYpffMlPt1NbDg/jxd1CBfDwVKIrD9sEmWrU9Hvqsmt1W7miUbAa39zgmMA3IVEyGO1p9ujNoKv1i9XdgSvwyvgTQ63BqqxkTr+Vb9FzT+dGioxNNuS6iG7T/BYCsGPhmE0vaOpDP81poNGXxhGORTeNSrqChCvPebRkH+Cuj7rsK3d4lsT3NAOwXmY28MskOurfoshu2Lw/BYtxZNfHLnc9n+Ox9z38BtMV5OWe8C51A+kV0ZGFssL3DJixwlmpDptbJqll+ybZCWDn1+RyjNocCwNxFo7DcmV4fAc9d80lAXN5NX1Bn0+eJigK6kmFSvFzV4wYWXTrIA9OM6PrwM6UtTdwT7SQ+EIGLS1eHPBinKd1gHRhMMdEUp59CxMTqA5Oyq1oMLr3ln3KRSafXh4fNSK0gTyVlCZ/dQXw/MNvatwtx+Fl7LRsYEcCnMFkQLNnc1p9DPAMulw7a4uRqJCDLeTsWahKP8wiOjPpe/KcNH2kx97sbnwCp8OujHjuCcwAthsGnQFy1JqkF9wmu29gF8bMyst9p/HvAMgihXuolWEvCCBWRryhyYHC4ETwSIAO/In0kXdc0JMloBXsEZb9iUB5z7U9V4W/ds4RguhkbRq72u4PpMawHtW14gzy7SRBwily05Y/lvVLup8N7SAW+YeUTn9ph1729u2fsGnRlC6qUgLcIa/mDvNIMY2QifMxE05mx+Qcitj37LAeYOjyIEkGpTNfiA4IbUMi+fDnJqFMCzmPDuQicYiPGE2EcgP/HZQdNUc5GQRPOgPKALReDeuS2Tyjr92tCzBSuEO1NMMIuwPngc8zJwdDnA7nKZjv67K0jgiDZg9RMnl0+69s2vdeqWTJnwuGrJUnwMaUi3lrQ41rQwmr21XsPkWqPudFyjLmWSvT86cUppyS0izy9gbYPOD+RTBjBZpoR1KEsBQuoKRgHp1rAxS7z3OIFkEaj5oiMxHRSWkoL+xZIisPudMcKALwjOYOTWAFUC9D3KhwS4XaB6DPNQrxjQ20Ut9GGz3isZJp7JL7xwHX6CGHYLQhMZceK1eDywp0kJeyhUj1dovzShxNPCh02ZQGJt5PxGutYZDYOAUTVr+uPrP2pE8l8FDKRoppV1mRaTPALkYZTscRktyHSqkJScwQcHofGSkoKpjRHU1JgkuGHA7FIbIEUNS3YHuj8BJ8YJX54MARVorXEnAzAxPD2Ec9XT4kEmd6bWhdhwK1D3bVpHtAjCyF44nQf2cjrSGgtnpAgkyvyR2vdQDCAV1OjwSAOY66DGjkI1lWlm//7cWxuITsDrYgTekNtpfXNVj/WXuMF5mXlM8jhFwHk2dEMjU55lqxx3QfThfhFmW/9QogoJ+DykQlfm1IzrIy+o9T0HpRGYHhQPji2gOGmQ62tmM9bD3s9tpQzkr+QW8jorS/bnydIoOiHv0WGkYqBdDqcufw4qTzgOQwEOGMV6c/C7bNmbLhzLQ3jz8KZAe2KVluf44Mg4c8vAMReksRgx8ZAy+HhDiNT9UIUkppW0sGhVqRCqueCBbvDvNRRnPakvQN/Scz5quP9ER9rkpr+zDqFe2dE+55F0gp5Ilz7zc+iApQjFkpJoenVnsWxnnRD13gnAMRJlEe7u3+XCTRl/hH/eYl7dFXt6lifR70DPa692kYOikAZgBTAbaCcu48sDnoBrxHfZUFUFxVfUSS+54jVWQgTMatzzeO8sLhQB6SjKJ1pCXZjQwoKajW1vZkr3vepKJeEVEtjR+LET1la6ANJK20ZNyVGhKNCgezkydBtI08iZ/J3NJWbYc2KtWTwHR0YmprY61h0067Fo9vMXKZ3SEC4cT8PWVq2MLlAszTCO22yn6ZnuzBJc4VfZqTuCyB+netAaSrywVSSwxLZawteIrmUGNUV9PtuzIIkbBxCpM9UlI2Lqv17QNsMKvUo1QfgjQSFnQ1JSnd+M1VXalY8Vt5raAU9QtCwYzmhVPCq5CjzZGvA5y3OedPq6lhsw0BnOxtr0Uclle7kUvWyzxBRXjo4DkwK4LmiGs7I1orRfgBN1S/5Tb6o32SUtt3m2vryHAy4zHnD/C5f/SLcLjZoJRtK6cbnBbElsaNApTSVm+WqWAzFWymCZtpwnZTcLApONxOuOPCBdx18QLObDftABRrkySzGbzv7xANh4IWpfXEqhXVZS7yq2rkJ4M7lQlTlzfmXBOpzJMwkEriRIbGbZo4kJpTGMYraml1tuNId3VGnRVSK971wfvxT77/P+CB6zchZ8/288GzqFh7zVilOVKS51HnjAJ3Arq8OrawE2iy022OgybLjquHSyvUHGSRpKdq+tynDkz6BMxr6gWTc6dRMmgbfRTBrc7ZKpwPySRYH6jCVivT4HYGhF7WfDJDMbfjG6VApmkvyHoQ4W3rfVTXgOD0i/ernzZd6LtYBnu9WBOCJXy5PLAj6k+Yd92eDC+CSIlWgjOrlVy3FTZEXUbvnpZGxQps9uGhRzprYH0K4DIVoxezllZWfi+2FIGVZywlFt2sXqd1utG65uWBOwFhpRQAKurREXR3DJUN5PAMZNrmYSwRVzyn1JxLU+z+JClM8obZYMR9E540x2l9pVGZ3WKHxB0yu9//MWB3Q4wA+tSPmqtxz1oF4udBY4hkOnCH57DgcVQr9sE9sN69blUrZLPF/MAD+DNf9bX4O3/xT+L4ZNdO+IJi6qB6q8tBJ9XMXzTfy4SvF+o6JMNNznsb19gBq5fQv6cX0T72Kk0iWdFPS+tRqzsmh4f4C3/vO1DOXoC/og4gRO/8MlyHAV0AmFWy1G0JebXfSqaPjarfoI8EtJrk1oAV/LvTnbeN2dqDMXCI73l1M60sd9lnfhjdpsthJ9lfjjJXRua43MUl0HmHcuE8PuYPfybKZoPX/9wvol69ASkFMQVG+QdRDAd9j5ytoeCHC8q3CsLI20jkLWw5O5+MJOI0KvcFR8Ij0KcST794LtpBnUngUsM76GcjL6o1JVmuwHKjzOF/PDRqgjC+zwT3vOEcBHN9yf9I9EgmVgxGkv3TGKfgtiYDaxEoz6v2yEOkoB4f4dJj7sSL/tgX4oP3P4Df/NmfbyNd0yqJzrMk4+RdWfu0r2ge94kKp+8err0NRpJSmJDl+S5TH5jbDxuOCUExw+V7be0mR1lUErfRDVLnk0WpHHXHV5o7Th5++ybxg+Q49392SrRFmXWG1h0+6iMfA6hid3wc53uozeUG2Bt/iPIQU6pudOQSYN1KL4P5qxwbEwtoLnlPUbdT9WBX/vsuqkRVsdvN2M0zRAQ7EZw7dwYf/bSPaH1d5z6S1Ybs3RHM4u19bk6ky6gBADmIgY6Sf4NtDq3N0IHZynWT/Kr2t0TRynggykEkBbDY78qrZNlOha4D9vJ3dhZ8mNRItcTE6rDLZKTVUoQd8pEzJzS+1XmH6fw5nHncYzAVYDp3BvOVa22aRCvaSJDRLF62jX/Z5Quk+LoF0I4iZ/YgJRhtILq9H4AwrQfyLwSublAl1ZGHlqnCtSGDsC69nugw5kVOtX5Zcfv0TmRtNTIn2KPV2ktOw1r/HRq+d+XZOJxAjInMlrhTsHAAxftiT+0wiBXLwSDXrLS3FdqGWqS0qPZxj38CPv4TPxF3vvd9+K1f/q84OVKUTXjt5kU6MHinI8p34Il7o5uxn6O2CjsbGP40ZylFwKl6Fj5JlsVXaY7mxA1eyxOesDknLPuds4P3z5RkO8nD3Cn5UtRtiFvDsCkU0+EWCkXZhOczTQXTNLV3F3NZOvDDaHJ5E2cNgzS17Baot/fHqbqyarRudY2J9iF2so6n66s9rQYsfXFWKRMqBD/6c7+GerzDVmbU+QRFCqqLyQhDHaDGe667ztFVelPzDEQVLn+pLhdrBvRwKDsxqSw2F2lrD70lizt/bAc7tkyL8j/JeSe9UBvqZEDQRX/lqNfUNbdZ+kjd0fExivQFbFCzSEObFXzTIF3RbbAuQZivtSHYtcWuA0vSs1vuTskVpoW3rci8puXUa+FMSdhoL2tJz6L8U3FlmdeuzWphp5r4wVuz/APT1hrv4ffywfrQAnl+XHGTRXdB6MFKxWuMGbHPI8xct6LPPaMLMbTvZlDMO8XDDz+C69euA7WXY6sjzXuHGRgivM8V8VBRLKnvGmPn1Dr54mDEbbEFG66cgoiArZnssXPEaIrrfSgdt2hueOBvAGN7bo5Q2AlN6OkGT8OABX2jI5C7LAwPkW3efDIWFaoVWjrYFvHpJgPX5hTKCh9o9SjV70aZIxeWM07LgJuUg7+z8C4qOh2Ux0wEDin5grSQg0YCgVoiZ6B/yGf0T913qVVRiuBt7/gA/sNLfhZy8QJ0dwzRGaoFQIHSKwZjrUCrNJZiqdO12LLBz2C2RVNbQww1gV/IWuJEyCfX5BEiO9rscNtwKgshTNWgVB/slCt+XR6VZbo49i93i7fcbrodUXBEiy7P7KBG/wlUZ+g8t60/tbY1C/0vi439Cv4aidzctYsjfEuZujF1QKzVaE3jtRvLi6cRU5FrZbcMkY50ig6Sys+ojChpXNEdla8NOZvopcB9yN+o6n8KFOZ3wxwJ7Flhxhp7XEDWLjOuxMC16/SVyVlI2XbdmkBeiKLpflcXsLENHpiv2gy6v4pZ+uo+rVBIe41VDYLUGJlICeW1Oux5morvBmHpLwxaYPZwMNw8z8Lt4fLdWAz2Tfv7cfN8kZFuimXNcPQDL26RlTY6X5KxGhfSjwAApOFI45MZmQQQigJF0QrUHYqiL1CyNhvQMh+CedzfS2aNkpdp9oUxuanxnTpBBT6s7c7EkDakcfyj+6Psj3Iw0J/bnOlcpX8BtO12EcE0FWyKYCqC7/uxn8W1B64AB2dQ7TWTmqk2Z8vqiqLJxNE9Sc860FgZ3k4DnlyOAa2JEgkkRIguPvzCm60uk7Ewjb6PyG1PqD4FHGg1kjlbeRCJHT8HWqfVMhDGK9NrQNv1QUrIr/OtQucGuIIK2DkA/jcAAWNAgrlBuPYY8Ny3K+JI9Bmu+DD+nmth3oby/HNfZNyblQ+TIgwBNWfUA7P8FhwsLvZu+G89ldGT3vqzoHalgLXtNczMNa9j/K1ARCmcxzyUFNGeAtEJDAQsJ8tFU6eUkwBOsKZcDnRoG/vnecY8t0U4TLNp1WgUfViKy+xvrDalWuOradtya4MZE8kRn7NFEz8NstxbZr6BPfSg04HUVNBtXrgoy/4iGRHJQ11Of8zTWVvS0B0ZOekN1kogHmQ7PQI0o9JXzg4duLiE5kg4+oh2jPnIWFC+cWXs2E52GPiKti5XZvJsHGCyFCMkbLid3hVj52xiyz/QMLZpfOaRv3TPfDPhgYeu4l//0E9BLl2CzrsuX9JUw9/CxEPumc/RftPZYdtLJ5rP1OHh4hzhdY4pgikUGYawS5Yxi7aMFmMByW+wjayDV6FLOab2xs6G0OEkBr1POb3TR85Vaq/zIetak32zgY1htc4oqm0Yuc5AnaJEI9YRTdIzG40YAW/NqVsLklyejbYholRKqMjtSm0c2pxsSXJWRtlNlISNkiyXGPLyjogkqyaT5KLc7tXY3P7dEJtzitMwbqXzmXg783hsVAKlVcrIaJ+WNllFvrEGskEzJXKdTmlNMQKNovTBotmikXmeBxfMBDmvarUieB48ATABDLqn6CQQIFm+9kXCx9A+LGs86EWmVhigusAav8h6C6UHExs0JiDvaffKAxnSxGpzPTUAl5+uGQEzJGzZRPo+56HPUlmrV1aytWX/yQVbMzQQrAGpXeEQ2e+xrPX8i3n7UUZGlbNHqe96C1aVOxfSuj8V4PRXi4Q6z0sp+IGf/GU88Lb3Y3rSR0LnE8SqXVnp/9DJcEx45TuyQzI6DawrWOrxwo9w/bUELNsJ0r0q73/NOitG+4oA5xWpBNiDXKVbAwiEyleMspDyCly3mSk+3bNkJuY6twi31hh1YAcT+bK+YZ6fdu3bkdIbFF+tuNPsPvbYN3rWZGtJ+FJqsUh0SzqTzI5pqa8G/RIY65cLvFqxWdc2XlDvj1vwZFXomaEKLOZvMTAxbMeystOqZ5ujw++UgH579KDDXGT/5h68fR/DBmtfj9Js4ZVqxVxn1LnmSo0w88xb7Q4ozgGOMCnkjXYJUjTTG508QT/ZKQO1g6/7DpLKdqxeACTP77JC5fnXUHMCv16OL0nh6ID5gkGxjG7L72AaiqDpOS86A9rhAaWBLhr45u7T6JvhttICkXFl8h4tNpJy8fZ1zVgmAz2QsEfZ9i8aCdqWpn096f66ct+v2Z2qbctPk6WCqRTcONrhu3/wP0HuvIi2WKHLnLHZZTp+xLzwuBJdF0Cb1xg4QxrUDE6Rtcvm+GyfreEPtyt0woC10yesUySPo/Nm7WCnIOlu5jM7YgYSQmkSWBGxybESszVmf2IBYRJBy1dN2hvYFil9v6xC7WHvhzSvbcPsZAcCnFlxU1MXgLsq/0ZfsBF5bDfs0yLq7LxxS0FHe/Jipr1APcr8mmM7RN30oycgR4fzmReE3BnLNQhxbSIDCfwtPBsW3J6FyVtq7uipOMXrz9eukaQEtHsfruUcaEAfhCTQDVkwQONypOdBO5ggWVNrSwgPELqblZmI56iKyG1Rm+b7Dp5GHwDf40r1E1Ayo2xJv81ler3JkFtTVoQPS9DI7bFbbOVA8hVAnWNjibReLw1FmuMiJuTwTzPEKNIOnqAU1p6FY5H9rgU9TvuK+HBZq0N8mldxnhoFrFz7jFYgycJerSjh0I6eJrdxjHxz/2lVzP2wiqlUSJnws7/6crz9tW/HweMfA9WTONxDmtMDBW2xyuSwGrnqV803kI0z82HNithQPUvSWtsst3KkDurL9iPqSkabyg3l6AptJy3lqai0Stbq08HZYBAmUyBDX5ouClUdLGPDEHysVTHbOhMHT2cwpWeWtvuhGrcAgpVrH9CwHvNYF/Pd27qn7HTC7bBH7sPRLyfkFo91Raq8PkTfOmsX5iPblI3XSx3oGVfoT+Y7eaEs2ew90m1uZPfUACyGANeGIk1dTDA1PeOqT2PiqK7WSBLI3q7gkbQXMNc21GOoWSGYpZ1e57rY87XzYnkV86BcPa3VPw5JeYSaPDai2+6zkSeeWBQdeRvt7mFL2xIgdtCDGYpOl29d6nWks4i7cPBCEqfLaTI+UvvISKnTSL0wRLIeJevYpzTELgKgbdYvZYIvnyrjysjMu8Vlhm50nDjJinzaaMnScC9lcN8Q2Yd9nZJ94RsQyLqILwqwvnJKAwhJJ0yG/+UPvARy9hBlKtAZqP2tUmrHBFphBhwImebRDiEZynOw7b7piyDP+yvU384D+3CZ4rnPSGNAlUaFVH0Ezssf+igFsQSmDngeiZrFpZGXIM55Z7dS9Mt5nX17wMfbNwCBAKjh9LSFmxWCsrB4raq2wLM5R2bww4D4qINTcHvXOO+6ulYhpY8b40CCp0mZB3eG5Evp3xhJCEBe6IYVyRUPGMb173UA+DNEqOfNdijvsyXC9l2J4BEkKW8yLiKLfKd5MPtqzX7GntwfvowsC+jgkDxHmbonWCBlgpYClR4pcroVe+1mRc2ZCceh3V/0UhgIrZDUcoGd1sPgbOobAjcaOaumL8oquT4mw0GuFRSCrICW7vakBiAKYDay9JFmmW5T0qDDjMngIPhz47X0NvboEmXj5xtPpWAnPO9NoDE4Y4u5tj3aFfNj+flpKypvda0NOe2f+8406WKO1XqJt0GsVXqrWxERFinA1IzmtNngZa98E37j116Jcs9dzfmUqZ0Njnw6l4GTJJYu5bs3FGPmADMsnaAOoouhWFiZVtsAnF54QtDW3oU5Wc51r4mFybEA3eGg9ijzIMDLkyjzgGVBwRSz8wMuHyC70dolaivvG188sk35zRAgPo0VXK13wD6Y6tStgOTpAQ9Vw6SNjNVIN5YW1m5EBGMs3TztOo1OcoCW9Xfblv5au6XbncSD/nXj5fbP0atapzGeeGoGVZFVo2HPPP164ft/WwekwxeUXnoOEp79Y+fLS0O4BvBs3VeCGaW0PwG0FNRFUeq8JMfKF405TnH0P4CmYUqOpoJlg10IgZAAb44WopgR4cLgWSRh3uK4yjaMREQRLtdGnLeF+z6jsnpED/jZymZUPQJB8J6lXaOkGE4WoABSSjuSsbdd1qwA4Pe8jlE+7Zkgy1Vi2ZqnMJZ1OlgGOXm+ad+oTovEVtoiVtfgLKzV12lPERs/F8BeKAAAUqS9e6Hvm/0//9V/xCwF07SF1mMoptaXiuA3yXOsyjURMRlA15MuYxL5x4iN1wxE/mGOzvygFuJBtXj6NEycUcud4LTFh5iyj35mcgC8ZifUqtNuo5y/kd+iM9Yhi3RDn22uGFZY7Ds2/iH0EWi2ptpI3KgDDrhN/4y+1B6lldS3MKHWHoMlHg2xyHJtwZM5yl5G8xeCu0b6YI/D1i1xIXXveNHIQWoSO2uUNqZpYp3Kmooh8c5oMPvW9bKPHmzcCAZVILBevU7zvhNYZAoyYowNXitriIjHKGIcyhwXuWSvNzdJeuemyAnESFuc5J5jG55phnyCSoGWNpysjKrhGvp070I4oG3r7vDqrgyiPByFrhy9bRq8N2XkKQwfgrV8qRy+wfxg4xVGKg+nZKX0fk7We5QNm79kYXYLwzBMBpvaguhPa5e1F70/VABIAaT0t5wYr8SH8Rft7YmWfZNlgD3+kGnS/2B6KiDN4K0tgnD2MrgM6VxfyEwMBmn/pem7AFCfDgieLAAXivSO2VqBacIrXvN2/MzPvRS46842j+vRrMa7imFs0CQv7VaeLhhHa5QZnXgRiwsZfBOqjW0m+c36HXJnNTvod9mNt12R3Pdni4iU2ruMvp2bXtvoLIuQ/Kv6J6SAUzaVzeUvgEVbvwnQXmZhYDvyxltlTnjIV3cXuNe4IQt2sxPPKJLcgBVzP8o5+QmJ1Og6lpX8OxM0/iZGDfZsFYcYb0bjuypvawREcMOjO4DYMLJGedynKxg4rgJjQiMf7dEa7ufC9iC6GfjkdYz+xBLwTx/SG+uG8849RxLc0Xg6Xe11MahQVJFljQI/sJ2djTTQ68JEaEggNa6+Ndev63U7hk2pL8wIMGBZfrCRoOYrQrg8Eu6nLpk3b68SZJbRc4uIrZ8ZNF3QuqEIoBVvj41KCIMaQHNojGcxh4vSnBWxV945A2IBWDM+XRbVAGRdwfbKIagP7YMi49CjtTLGqZOx0BWgHbHAvzfaR4DdN/8bRtQb0L/q/jyUN+lRl+Vv++7/gLrbYZom6LyD2urvXn6sz1tYSq+Ah/8iOl0OBac5XJcxMr0uQkryGIuPWF7THKqG/EKyg7AE5y5//qzJlzuOOoAKiEbJz50vvY/NafZRBK1Ou2VmXXP9sYrFgJVq0E5fe+xg6688xAgX2Ri4D0O2aLlMLfenf1CXM+D6tcehTE7LPhW8jbxu48CLPpfpWsS6H4PGkalxQL/dtztrvJGM7/0f+72xSmyfXSQ09FmgbYAUR0MLglZIEVmkXUmUGLD2jeteu9YW1izH0G3wTbIBs8dNdjFkchpr/5uZ7rXmDFZHOWkHJEvR5DwbntQqbpOQk7CHBA5iXXmhqY3efEprq0mTs6RcfsyHevRvxpOaG20NA5c0sxvgZADIKJE1a4aVmJfzoJ+S0w+0UMXJbsZc2++pv6VmVWZOkaMFM4kkzi/WF2K6RIZQxjaOBVjxbPxGWUVS4jFf7RGZ7YkdZSylXzgc2YDNtbbtPmhtOjjY4rdf8Qa85Kd+EZs7z0PmIygUtbb5Wpcjr8o7luoEyYUY2/jpkL9TZiwcRjzC6cjGEStt9qkMv2VgmPnNWhpLuJi6te0fRv8gFWrN7VIgUZ4xLJo/gjybQHKwlNrVn9lwsqQ2t8VPs1ZUlAD5Dh9ucPZdvZ61Ba6Lxrv+M11scaiNe7Bib9nDV7N1i9FNL29Po1YCt5VmJDpXSyKD6W6Vxp9VZX+WhXV2k0sbCFq1TaN3IalBavcTuK03QNee7/E8Aiz20ZG/87YLu7+gQcy50PjTWKWYkvq/7W/WthK5Ooni+tCciuqRpXuz3CuhGxgjUtO2xB8Cq6hDh26j7T5CHrEZIrM5EorfHGKhkUV13fB6vPS8MMVJ9igl9Kqtw+BYJtqU89u8GLU/WhMORuJhH8bUuXv44qOaJ8fHkbcDkFRFLbn//9+uCnZHhmyXlLYXVfqL6dMwmunIXrmldt+GT2DzkdqBdq5zew0eG59b2NVeEtCdp6qKOte+3actijreVfylf/B/Y3d8jO2lC8B8E5Cp0WML9Af6OxZ4f3mEZgmFhzCRnWOOsvyLt8jty7gAExb9msz5HI54TqfH6TPZWxkRcgcigEQcqBG6RQY66QYayCaMTM8Fikr15Xna8E/TuFDoPAJA3Aw4UM7Y7XYoMvlCOj7b2/9l2+EYGecoN1uwf+0LOwjEkaG3LKGz0RpyCqhJuhHwHfqkNEfH6MJTj+N8/V6dl+CJiWWaBhKvKq5bmI/F60a177M1gRvbrONc0yp3iAH7Kl7NFsOPt6Da0y+UDPBIYjGPfBozTF67t5yAbaDbusv1NpEmPkfowB0olYhwHB3dNlZEa2+vzMBmdBK5/WaQGJC6z9BeHq1ZUGJbBHKhyTeiBVNE62Iu3GiTNmyVAJdYEWXHwgOPeO2j1tTXAOK4Pg22xD99k36PwrUq9GCLl736dfiSz/8sQATTZoONGC2SOtCG7MZlE2PEZSIy2pFCxsqHLnveOr5IQtrK3sIrwJnPqd5UTfrFAGv3ighkkrYVp7Ye4rOhc/pwfdxIEVhOopCNoNR2tm4pBd/yz/8f/PZLX4HNYx+PebdzwNLS+svmozucUec3eRGrl9UyITO1n41j/xKr8TX6YQBrB3KQHXPAbp8xJYPQ1VBKAjHSo8HgGgKuDTDyYsSEF06HRj3RGmbBQAdS+uTRDALptNjCjd0OG9lAZoWezIBMgC/y7MFEepGLld3+tA9rG3iP0XAELt67iZ64lkLt1bHs+8M1LAhOtbUaWYZz4TEttkrBYF+YKjZTyxknSS31gm8BXWMr4mzkSh3rN28B38h5XLb3AGheWLBArn0VePq0upAjVgNc85C5IxYuyZKW8Ai7l+t5aCiJFRcF8/EJymbrhr7tqx3huRHgusaRaTQtulLgitxgQJJ8yMgLN/bBB2+03bOylICWgMRY73xMvKFI2dvVvgYIjx5jFGr8sDLbYiZ1gDLa7S09bETcKXEwUOe/OUh+Bq+i7Su8cCf+9Y/9PH7+pS/HnefO4mC7xTS193jOGgqVl+cHCNswuNkWhc2Nh80BxF9Gvz04wF13XMKzP/7p+KiPfCye9ITH4KOe9hG4cOFcA71aMc/dCZkAUTvlypm3R1c0gTwnUVWPYKep4MbNm/iar//rePRqhZw9g5NZUbWd221Rb53n1oba4agXHlDY57q1LaxRVUwFuHG8w+vf8BbI3fdgrg30RBUo0s9ArqDVGU67L3gahCVJietYRJrhqGYZU/ceDST7PY+Yl1FLYJYu5wPZmaM6xoFjpnqQSm7AXt3jIlx+QcAv7OwR0GqUk9IzFxftbXwsItAbN3HlFa8G6gw9Pmn76Z0+SX3PdsoBV9frACLgSQBvFy+8S/2X/IcMbPb7VkFXz7xnkNfLWtJMz1a+5+lFCdlwDpktNuqDlbeNtd3ebYztqa2sP7cocRzOGT2JbLz3FnJ7BCf3Cs78haKhLbxZ0p6Vyb+RVzeGUfYy9VZZ8/pkO+H6Aw/iZT/5X3B07WbriiJDulRD8GEkS4GY84gIOkXx8G5OOhPzhCYjhr6ZF0ZX0CRtgRH1sy9WcQNpPEhLU0LJyAuQQXjceDqo50/77k4IQOU5ugK+DSUv0nKGJtQHIAUnh+fx9vuvQuojfbFX54JFe314LIbLgvdeg1sEAasce0ha51bMruKHXqLAfILpcIunP+3J+NznPwcv/ow/iE//tGfhzLkzDmK1Koo0oC7jwRt0jerC/HObLS2CPnPmHL70T3whvuKr/xLmg3ugRduW8Hrcjb4AtkFNShvt6Cu3pUxdeATQEnwRBaqiSoXceRcUBWIv3JCS6Fr3FQJd2bCmrrP8fseRyPshL8Rk2Tc3LiLaoZR03+91ZUnRo6dno0vk9BK4JBvmtbb6IFaoxOJK00TczERhBinXIY1CV5ZkQoge7X1+8oEHAAHK5BtOgkS3QeJl27QPlJx9XW9L1Bv2KZW/uOJJtrm3CbK3ebkdYTuzIGV9RPX0NUBjEbwy/lRqko3djIUNIwbrNa8kWC7nZkXZU4wxRodh3KRwnfC9hmlP+b51Z0++wBIXMu8ItxJ9GFa0vRPSFhyUgvloh3e/+nWtjlJgEWmbq7UW0qcppBnxxSiCcyVyOngbW3jFpZkbM6hw5PK5DWsbjS3bV+OrgbTT3MuP4TiLCMOJsKjUTsmK5hn9Vk7Un0YkzIh4OTbcTUBnJTkLCOwivIn+DNRGOTxEKWdIdpScDqC917M5TuFoEUdFICjDPFe0MAFDJ6PWNtf5hnd8AK9/w4/in3//D+MZz/xo/Pmv+GJ85Zf/URwebDHXitn5UIJv1r6VK0YW1kAYmOeKL/68z8JXfc3/hO/91z+Bwyc+DmU+AuoE0RlV+75w88pEOuhOsO1SbQTFjgZtPNEeyc67HS1MC1TxbtIsA8CCm84zGxnw3z1x+DnWVvXfPvyfgCrmOHn6xeZCQ+6Nvty3QSTruc31km4qghaEc5iHK0mhSLdjrhrhiJu8mA4xz5TcOmpfo5rAY0jn/Pe2tnbJdvL6Rws5xNOdFaEbMVrQaSXdypcOgW303b77qQTCjH2wtVjjICvO/Cl51qL0VCYHiJwGbAOp3mXSUy6BvdtZ0QfyhR6Gi3RKGSvPxnnfPFe0RsbtUEz0LEhYzjPfIstYgAMLbN7VaHIw6sYHtmCgAjpDdEYpwObwAGW7aR0zz0BtRjy9P3KtajcQ/g9MmQXq+38DANVJS8QnV1qhqB1AwmmyoeH2nXlEvU7OgRmwYKT6n/IIgER6hiEQQIahHdjLkbbVLbqgz424KZba6m31tkUNfYhT23zjvJsxzxW7ecbJyYzdScVuV7E7mbHbKXY7xTwD8wzsdsBupzjZaf8OnOwUc7+/2ylO5ordDMxzuz/PwLxTzHMbKq5zo2Nz4QwO7rsXm3vuxVve+SF8w7d8O579hV+HX/6l38R2M2G7aa862+1mXzE9MikiOuYZtzTkU7Wi1oq/981fi3P3XMLR5atob1UTNJFU7OaKkxnYeVuB+UQx7xS7k4r5xPhSW3tnxVzbYilFgUBCHmkMbTR69s11R0LUPC03xNsT0x0B1X3Fu8nlKZbOR596+hy5Dm6M5R3Kc+lNxjnOFqbioi0pMlH0E0AgtiUJgJ3Y5L6KaDh//G9/rr1PhfSOnQ/4r5j2ArSDZaPZHcvBJju8JxtpdAa0G4iyq4ShFKw8iee3MMBh3FZriGQy3liQvXatYo87mkO9SusgJNPepdBKTXRa0vSZiIDbZQvi6Jw1Alml78PF2zvccKrN92UvZK3RQfoyjYx/GpCq48OxwP5d6L99HaKRuH0aDaFxLrAe9aK9F1K0vx9ynlE6CKvOLU1tn7b9BL0NMD51LRVhJQhLqq70VLeDbQY9J9eAzdMEYCoCbHvnef/FUBhFeKm9QaMZvXExmnn5zLvm0Ue/8upLWy1qkbPTr9Emu7mcozLHKGyWGlAxGhkf+Q/qi4bCJEnbGoEClQlq3+nPDixRCGoVVO1nAUMaoNl7uSuAqpBZgblCdicQnTGd3WJzz9142zs+hC/86m/G1//Ff4hrV69DSulv1Km0gjh42gyui+IouPSz5Z3nGXdevIi//81fC33kQdQq/mq1VnLp7Sh9f2z/rXlOuomtoGpB1cYTVjolnfIXxfj3MPBBbP/z17yFjHBfZK+CHAnH9ZBLwVhPdvaaXIc+u/xz3Z2/WeVJ9qlsH1rtfSRUBhMQuGs6Q/SZfmpLzNNDSoxgPyDosc6pxCPTlUFvWU4U/safoCnmvJ0wDKCmAFDaFAyGdqY0ndupIykJs9Ls7IBKKyUTnXlBoNsc5ttqZVQOlcV/KdXQ1+H0RSEjtpnTIkPqW42IFxK39q+wod3HDqtRk7eQHksIlQMPl7gHhDHkCdqUOb2kRZZMWl5Bh8jKXDUX7cJu+zdjSbxoRT0+wvGVR7C7drWDrC2Vr15P0sdhGAJAerctk8icVyN40RVm7VhhuhKTQxIA3ttkWu2GjEpjvtYeYcOqEddb+x7DxExslCorypy91dHzjn52AaZVkwzymjnkpXk0Yn1Wa2/LUhlbVSY8pf8lywkTLh+S04FPdhVpKyxlQi0TqkwN0LViunAWct8T8L0/8rN47hf9Obztze/BdrPxvb+19qh7nn2BUpAr3uZEen9ee//WqvjTf+LzcM9TnozdjRv9nGgCS/reopZudMSAdLULu50MFPBT14aLgSbLP3fmkEnzfTVyOP+o78nGRrps8LJTGWzkzIuDVlMUY509BDuRVjgtgWO/10CmMcv5HJ5JuDB8XwxQqBzwVEftUTPJOf2xrm/OHGBzZhtMFe5bahRFfG6z+1y+w8lgW61LVPcwZ7ic/7dO6sK1d1SU9NhaLtSG0wkZbMBKHWnEdCjudsjPsJmNbIkU/VNxWmCbaxwAhL0HvtcKyz6SMoOGcXn3yJWEMuGX5P+SYmlm2Co3BkZ0o+teL6xfYv7KPlUr5uMjTAcTPvq5n4L7nvZk6NFNb6ML98I4WqRnqmZ1q4OjzSMnURq86PDwckTUu4PSiKcJ461xooyaY2B2KKJQpbrYuY5KWCFoiE37SlQ78o5Dh6jI22P1Kn2HavruUZ7LBXm5KUKKyKQNp3fA1epAK/RnBixHKTRMrRFFeTSFMbKq6b7zHxLypMA8z5jrDuXe+/DWt78Xz/+yr8frX/tWTNMEoL8OjaJcby9RFioiw1+7V2vF2TOH+Kov+VzUy5eBsgkdGw2lU4mgvzuRbT47T4MsNMlOKrI+oLLNhtid7OzBdQCIT+2yGuUZTdazpv/9GalPAnkC30YG19/lQ0ineC9pENiAReEOltVmfWqOn0V1PCoTMkk6R3w3tmaYJHbzc22yUbuuhi5X1wfwn7cRKNsDlO1Ba9Xg/6f+NDQtfR4fBTJt2kK67p+5foHa3fktXKI7DUjRYAKpIYpmp2O5GyJ/x577Snn5j/nLed0OGG3Md7IzQXKG2QX/luTRs5DSMiqtU8kla8qdiB4JWgwdq4bntE5jYsxeyiXIG680BMx0n3IrOiVoy8MFg6FRm6+tqCfHOHfPPfi0L/ij+KTP+ENNIKu103gcZiCBpdXvczoDT4c2+rCP5HwuUAkco20NXIz10am85caGh7VXpF4hKDomKyAIBSd+6SAfDrRWL1kRpZRLBaOFWp1bShyU7iQ4y5Jc8UIH/uh9YkbF0nYQ4hEB44F6ZeJ1h+JwJzm6Noaxl0pGE1BInVHmGzi8dB6PXr2OF37NX8W73/Mh78hSBCVpf5RjVdoKZuNbEfH9u6W0w/f/zJd/PraXLmE3A1oOUGUDlVgMJVIg6AujrI2JX9a96vxyh5Z45DIl6MdhGlD1fuuNFyp/NDXKX6xOBO9Ml4zV4biDjDwpB6IchbZhVK6SbFBMhyWl8bdhCbXdVsWHfJk71fMA8MWCXhzZEgJEYbL9L8OE1dm+t9fgKcTQt09T2RQWg7A5g2iv3NM+WmP3XE6tIYIGARPa3rSpvT1rOoSUCaW0RYKzVpzUip3OqKI0n2vtZeZQX/SOW4BQ7iz6yTJEfXOrywHylIvt7J5I2PFgFWUWlXoe8DfOyt4T9s3Z7i17ANKViDRVpJkgN+YUActKo0MBshI1WdH2R/9lF+b2r+R5meEhYyeAL7qJv/YGW63AI488jN08L8p047xgPMiGRYeHnJIBIxAwkMk8Ca4KKRt7uY1++PdMEM/XZcZxf7VIopdfeySQUIC/W1nWVnIyzBiQMtmcLuf3+54RqQwr10c9tKenKtP8Ctly54rY4qzoA3+u0Y40b2yh3GDXA6CoD2qN0ZD+W/rCOp1vYrrjPB5633vxdX/5n+DkZE66kHSFSGw6Y0Db7xdxoJ1KWyn/tKc8Fp/y7E/E/Og1YNpCy6a/pSpWHtsL32Mkh0ZJSG/Nw4mhztiaxivRbbuYMN8souMIAgZeSl1uw6LOSNhMeXQi9e1oNIlbPOIBky2LChFNEzG9CP1SVRpZIgkXeo6RR+rybxIkIigomEQwiWCDgo0U/5xKwab3l/1tpgmbaYtN2WKaNpimDTb9b5o22Gw22JQJxf8KRCYUmZrzJKW99UpKqxut7m3ZYAPBRgSTTJhkg41MmEr+25QJm80Wm2mLg2mDaRJMhxt/i1aSk6T7WR/WRzYHM74SoFnnhg5GR6WpyGTfBp1juSWxMRvuIwyS3TQPtJDxYHVF895rAFrCEL7irT8JRAkQ+NLlrf31B5PUoxwifATYtbz55nqj99F0O3TaQgpmEu+37J+uSA7sirnusNO20lNV+4ICqtqM9tgmx5aWwLdVEGBAtQ+NhIFpyQKMwyFvhjCVYxVZFItmQOz4OMZueDZb5DawMKGegBnuoNgL5G5esDqVFeXZUHZycgwhERGFKYajIXmM1j5DAvvu7JK8jcfKinsEqv6h6ese/Un5BaxH6rKkovF2KACYjzHdex9+4Rd+Cf/ye5+D//3PfWmbokCmvRlSVnxBnGEuDhDO1gpMpeBP/fEX47f/28t7fvHjR5XatWwvfTr/mR3ceb0PfFOo2ZAxu23dAVk3MrZseKOFma4krLHYLhfVh3EdPG0RX4yU5KFJqnNVLzOdrf+JJ56luHyJOZ3zMeajG5iPT2Ar44HZZdMhIL1PrrfcHc/aSVFf5ORrQchGBJka5Xa92F05BxFBvXYDMokPEQP9IylkBWqTlboR1GvvxVG9AQA4c3jQ5NJlsmtbf980L5qzKQIfCdkTbQ5szCro92T4uTxP4bT0C7zxylfKSDZuz6PxMvaP6mTymoZC2tXfZ8ueAlejC0ZENDKYKb7PjLHvZhhd8dW9ClDeRYtIibiXkoeUIhkJxb4NwM2+2qKxTkLM2wHQijqfYDfv2tm71gYzlmH+s2dmBhLhdbdnnMYb6AJjvPXzltmQaM/PLBoAJ+x/7hPL76wKfHCjx/bXi/DqNPEt1eV9kcEhsbk7O6yYsVqQjaOkdqMbPp/nc4Mcc2os80vt7m3wRjGi06rPTodYJXzerndPk540v2uyIuL7h33gUaRH9zuUu+7Gt/zzf4M/9kdfgI96ymMxd8dNOh8YaIP/5oQtnSNr0wuf/yxsz5xFPVGU7eSRnTtpHJn13pcooPeFLA0ePHlrs7K8W59j+d3lcAmu2cDZ3K04T9l3sbRK3k+OlJBkLM4nRwjDilAEUKunlQ6I/kzhgNoksEBkA4Fid/wodkdXARxDLmxw5uPuxtn7HofDOw7bmdVaAZU4yUmKr8dDP0c7gFbhKyd16K9uj0D3mE53VEQxHW4xbSbU4wqt4qbcu3kqKGXCdLDB5qDRUIq0N33dfDbe9WTgZx54DY6PTzBNE4oIzh5ucO/BHXjymftwQQ7cuWTbbw6djVhamqx8ZkT4Puk7yfU+E556cEXovM+tjDG6WNSayw5bTXlTPctbYUwXhgYq/WzkRLq9XQW5c1ap2nMFOGSAXUm4ageX3od1ThDC8zes716neaKnAC53ljudrN2DfBjoWoqqFbUPK/vh+FSyq6+uC0STNxowIxD04TZniaZPJ2ilPWFwRufJni/lYflwAMZeQ0TXpzB2aCPYaFod/TMtRhmMpzXKQC0Mp90Lp8KV17rNnisgUt18dwRrRctK3wCIFSUaTkDL0L6lFYRmEW1/oy06095F0k8zE78/CVDmHcq5Q5w88DD+0b/6UXz3P/x6N1zNNqnZ4YGvSPwKsGj8qVrx1I98LD7p45+BV732rdhsz6JiB2hFlYLZGuOREit7b1sfloTxjL2X3rdNTkkGiU7Xf+rj3K/i9EIly7TnJ3xl3RSJ8twiL7dfBLb2dIXtgXqapRKZrbH+BlBs+qTVXdCiwOMbD6EePYrtM+7GE577SXjG8z4K9z71ThzedQ66aSMKc9UWp9au09Lm5k0MWxRoQMn90EirLt8BwOZMG5BV1B4LZ76o1ra4ypxDiMuUSMHUpxVqdyImAFV3qLPiFQ9/AC97xztQ5op5lnYgS1FsygZPOLyIj7v4RLz4cZ+IZ517Ig5QFjYl6DBH2Z/4Z+J/Cj7UAXcpNcvfCygfbEhjmYw9vdLvxttTYSM7wD2CtUB2kY+6deOZiDIWfRkygUAgNXzF+KbojSNahEIuLgLg3IOmaEYDk0OUWH+5MmPJAeq1mAcEzfvpouHhb3e6VKF17u+NJKM1igM7HjIYAHs/ppDB7EW4967WGrhAEkdyxAn6kVgvxG8TT2Nvvzec8qKq/qo9rx8xv+FTA8rlaarPgsHWXRH5u41m50ltuLMiiGcHgeSIeBdsJtBIeTW6R9D9IfG2oBs7rZbDQGZOXeo2ODE/unvhIyQQIjns7+8tUiDzDtu778RP/Jefw9/9xi/HfY+9G7sdv/R7KbxC9XoVYueoKHbzjO12wos/+1Pxipe9GnLHBZR63E6E6kY9TqykVdTWwNJWSDffsZtn6+dS4vAEtURBT1//PjiWrezseKtzf2kA8wgJO52xWl4d8I0nLqEkC9EFQuhrctOdKEUHoxjyNkcpaGy8kQpMRVCPr2F342Gcfe7T8El//HPx5E9/CqZzguP5GNeuHeHhK5exm3ehqyQnvGbBllDJwEpvv9kFx16nxA/kB+BOmn+X/DsARFwFmv9RujwKivaXa6CiTIKDacLhmbPQGVBph5zsULGrFe/dXcFb738AP/OB1+DT73o6vvGjPgcfcXA3bFQmn3xqds/sf+7rZLOMLxxVRorFaU9rpn2xbsid/jwKFPwxOjKGjdOq69fKcqoxiiEi4+DMTPIywthbryxuJpD1Ik/xK2TJ8JSPnjvAsABLNry9CW7gCV/oWU+cni2ZHpW0VX1tMLCJq6K/pNkNkJr2UnWS6mZMjCYOxmGIGHRoWmgwfVcyUsMjw23/FMT2HCC0g8Aze6NRPtOZRaer82BnR2eISTenwIuyzk2dbKSJg3YWk4boPuytMWgbtAOlTBB7p22xuStaMTp1ArTtzdV+NGcc6ShkjBtt4Z8Q+JgjRjyJDiHlFAA64/DwDG4+9ABe8rO/ij/31V+KtoC0r0wGD4uTHBnI9HJrb/dcZ6f5xZ/+yfi2S2fbYfSyQRVti2i6ywOVFu0ZjZ0vrcwJKFPbq2tttXr76UazKBQVdZ57X5mTZPtXlShMwgCLzEadDFMixCNNScI21zHrQtZGfo0L76I/4bKforPOXaBAqmAqwPGNhyB3T3jmN38RPuGLn4Oj3aN4+Oo1zA8eYVPagqjz2wPo1Pa4+lvBeEWzt0sCkJ1J4YiA7JoajV3H3N5VW4jW/qk8t6vEJwHEViZ7ZCbBdLIHRawshUp/A5AAgra4a1O22B4cYFbgVx55C379t96Mv/cJX4IX3vkx6Y1TbbGYIMEc2e1TUCyNjDCo8vdU1K2uBJ4yfN1PxxqdMXIz2KK9w4Xt2ox03M4VoJALTPOxfH8lEs4FDgqVQnoN40Llt4UfSko61M1ate4iEND2Ouy3gY51hJjJ7MrQvfO2N7JG3qZdo6tjTVlEfuGTdEU0I93nEFM00I2484DKMQvui0cMYMO2OZ/9GfHezukNkGDwpja7sxP94l62RhttiCyiO1OLUThtUVXU4RGkmkEJNTNvP2TAaO0xs/dfMzKx9UIwX34EenQMqWigkoCz81oVfNxd7NdVZ2RWTvrslQcoJSa3j/4SgBMyPzdlgzJfxb/4ru/Hn/rSP4qLF88vJdZ5wfAl8aHZCVGteNqTHo/DMuPKu96GGRugHo+lRjludAVSpm4eJQ7GMJ53J6VsBNgUyLnzkM0BoPb2H5JV0xa1wVd4tOL3OTrlYUN6ltJpG21xm8B6NLQuAatxznRKkOSZgTbmF9X/pAqKKo6v3I/Ncz8Cn/F3/hjOPOE83vfge7CZFYdlg6IFx9eOcfXGDRwfH2O327UTwlynEfJjYtlB0RwMuxvBmDh9Y8+5RVWTXTi4qqq/SotH6VJ50uZn7bsK2pYiEwniQDg/0lY6TxOm7Qbb7RYXtmdxfTrBn3/Zv8O3PfvL8aL7/gDm3mfFbSmxNDyqZPezyZToP45yLXKmPCZLGeioKKXUREoa0bP+YBwiW7u2OMt5PqCa2cdFw9RfHq8LN2Hf6q+0sAm3Tg/AV0Oehur+ZGCcrbZdTsRryhwzKjyrSq0dCNbOKPXxG4VteMfQQekT6BvAY/tEgEkvh6qL4dYgwwWpu4yS5lbJSJNcOs+tjzugMPMEocDRRuKDl9uFLHMkkqSMXa37+2ajiIaIbTuQpLRjER5ljsWS4XEBlTGpNsCX4B3CfAd91nYqRlAhMmF+6H4877nPwWe/4NNwdnOAaVO6Ya0BAv4OWispG4I2r18gw15XM0Q+ONkjSz+gwvnahslb1Coo04RpKpgEmOoJpJ5gsykOOvC2jr1E8kVtLVIgk2G84N67L+Kf/Z1vwoceugI5OEQ93rX33dLq1urGNYyuSDuqT6QZ1c1mattYSgPi7WbCVgre8M5343t/+CW4stsBm8m2tEKr+Ksic2cjHINkZCUNeybDN4jowmF17lueqM75o2iWgQFHc/9G5Mv09oi213By9YM4+6KPxWd86xfhRr2Chz5wP85MW8w3j/Ghqw/hxo3rDlbCOyqJEzHya7JLDVQaWl9mSP3tNGrkNZ4ZCLDR91X33D7VPnTd0lQPiIguzyJRbj/YR2vFNBWcOTyHcxcv4OCO8/iWl/8InvJZ9+Hp5+4DVPv7m5uFTa853A8Dq6DJNp+5dloxY1ULaSFhGdVsH445Pd0YmR0IQ7YE2Tbt0zBg442pikXKtYr2RLO3dbEnu/b8lEayp7t4ZkIKW6G5ArB7ijbQNZDVkFRyxjojHWnawoK5VszVlirALF0rJ41HUUToQh11OIEGypTevCf38hKgpZlkn3sCJBw2Mf9F6Xnnlr3CroN2zF11llSYhcvsHKOSznuPUrtiRgQcqfL9PqRpRpSjVjZSlpVtlLcreNEuOjFqM2F3+WF8+qd+Mv7zD347zhxu+uERDfTWZZDgtoNwjsZjiDP8AyYsIhntvFpc7jG3vMXnkVfS7dOJIXkzbJMbRRHgK77sjzTYcCQk2SNbLQJ3AqS0PaK3o9bvvv9+/MhP/hLKnXdD6w428mAilfbPIrhDYo30o39PLwhHd4pIlmwEhLPmuWKWnxyxJnlZ4y9t2O7vQ8LJtQ/i7Kc9CZ/+t78Qjxw9iPn6EQ6q4KEHHsTNG9dRJsG0aS8kaacoWrk9QFhYcwYBu2c2DOnTpUsiDcuYWCmuYxY8uLEiu2V5w16F5Bqgjh6OMvp3Hrdgo1bFjZtHuHl8hHN3X8SD04x//Hs/he983tdg430Z9Iof1EHTgan5ZGuE+MEOFtsJa8PtCOtgj/NX0otuXHLyUUb4y+l4yBC/WS/ldnyGXPC+HELP9gFtBrVb1xflnJL+dn0AteFHA/Kx88hrcaGVDrj9uZAfz1/WFMiMkSkKHQ7QlGesmw1kLLhY9b5YggdrZKMeqXQZepw9fDdqrRy2myJeGeyMaaeXrYgiGUAX4hG8BpsXkCUpXVgXG1IOZWkLT2ZINzYVwLybsdkIvv3v/RWcPSw42Z30AwEI7NjhUSYteBYMQhKD0y7N/wztGPR1hx5J2nnGty++zGNfoyDoZ9TPPcIOE+sugXIRAsyKKgKptX2i86ZnmvsrBAXAVIDtwSHuuONcO+axoA3PuwMmyCvhEbxN8hmExGw2zb/X7vixHK7bzKQ3QnVISqhhXLluIfp6UtE2+rG7eRnlaefxvL/xRbh6/BBOrt1AOar40EMPoUrFwXbT6ROfBhKX09XuWtDDLsLIMDtow8+k7n3pn6lghFJrHt/TlCjshzvD3HgqO5uZGKlpf22fsRbg6pUrOLxwFr9y/5vwGw+9AS+85+Mx136YSO/TfnZZt4FLB2RJn81Px8W2Way9H/YVRsgkLsrbm/SUSynhfnqG99lGlxjwrGX2Tk/DQXDQyQIe3yUp2hJWIvnCsg/15x7I8WEIzO1H3QG0ULTleqZ09jX1RJM2e7MK7RL3tjkIDMLhEWBHCoWBGgJ0XF/IQFq51CerLzKwfIxgVn6v34c/UwStDl5msFn5Yn61C6dFn27IJZyAZNWpnK6oKgJ7x2XLLxQph+Wz7I1GLruriAbY2gsiCmYoKqRsMT/0ED7nRZ+Bj/+4j8Dch73SyIdT1X+niOr2orv/v1wl2G39E7ZzQJcuh+yRiw+zE+gW6ScM0WjNvovyjpdqG2Lc1fYqQahiOnOA97z/AfzMr/4myvnzfSqh0+NixwgWbfFV6oihyQSONIKVV9G353l0xtSNjKW9f9mdsmxLfK6fdMTiYNO5JluCujuGTtfxzG/8HzDfUXHjoWuQmye4/OBlTEWw2RTo3CNnqVB3rgM+ncEOkIh/HPizPVN4AziojDlVcDlWlpC+SaRJABbIYeVm9QybpFw2X67bXd8FbR5dgfl4hxPM+OHf/y189qd/PBTap461L/hTcjazQ5awhBx07t9oR8aTxQpkIpVbkXtl7CNkTGK1O1V52LYJ0WU2JR5vNHN2QeRq8fvqVl3PO1ot2afaq4WuU+T2cX9JSVEXpah7XfGQLPxYFa/Y7S/aPn/xAo4fudZvZ+YaJsRcMpxxYRLJMQB57z2R5wkPJlgC+EupLRpaiBk1uEVxRlRWQzeOFDnn8jRkSUlZqOwUBuoa7VQXyaKBtg9pkUcLsEPhBAxOmhnHGQUzBCd9ZeUE7G7iG77ySxtg1NqiWrVzBMTffhM850U6Awv/XwLvGOU5Y7gCSQmWFSc90tUkJnhC5Xe3BmuNEPpnVFMD9EkEpWyAbat2s5nwfT/8M3j/W96P8sQnoM4z1BwAjfrMaVjUrAjHSXKCPLpEckoA7QORrN/mhJh8KIhFAj9W0WTI+7pT64cLqC9ynK8/gjv+xDNx7yc9EVcefj/0+oyrD19up8W5oW8gyw5r6hPTAadncEAQQKvc3jW9GS5ejJYrzVde+MM1BTluk0yXk70J2XQsN6e1SB9Vbqv3D84c4LWX34NH6k1cksN+DkFuT8hZNrYh/sqJkh0fFzGtMIUbviw7Hi7zEl8SroxDb3uupIaSSYGkYeQkEU7rQgFHYfEhLJavnDEWM+TaGJz3bQ9h4VgCp6T+8tXJCGXPlAWt4G/c+aqweaWx5UZP2Wxw8sgVvPG//iZuXr1BjKX5EMtD+JiGbc1js4gSBLQArcYdhrVtCEapjTZk1D1ko4V5pV5n13+PHNDriJRC5QkX4MaM9w1H/Q66izYidb4rtjOnt8ft5sq+ZCDR6/m60W3f26sOS5lwcuUKnv6Mj8ZnvuCTu3ctfR6x2YeGSUJvnwLS8rpsB4Y+wId18crzZhu7Q4FhXno1c9SXIHgP8EZUGaCSSTbjPuiUjGXy1RZI2fXAw9fxPT/4n4C77rZFr91pQd+Kslw16vOt6b71c6wfCF4RMFq0ZeXawSGu3nmoHIhphqYPBmIGr3kfZ7BQ0d50LKgnN4GLE57xhc/B9etXcPzodZxcPWpvOi59UZe9fITtCNWbyiZnlOdw0xqMsZ91LCiqiXRsADm32SuaJlurU1Nqyp5SuQELaeqjURbhllZukQnvv/4I3vbo+/HsS0/p6z7gurwHC2m0UtNDP9xiALtxxGLN3eBRkP3qRXZyMV+9Quip1+lK7MvmVocV9uRrjo0k5WQvdiQwtlXsJ0sWPbFCx6LRXQWFPFNkBt7eNQwtWr8bEarg13GhTKhV8a7f+V3c/8a3QjYbPzxqzaNJXiIcXyMDJ2uwMLRhAKaewY2VFaXENM25zZDYvlG3sYlezVk1d0Fspxj4O7bZk4Qhp6T+XHzYLQy0gbs5Jkq/jTeNMD5MJE74URRomVCvXcH/+Mc/H2cOpgbA0iO3ItCpQKcSlSB4n1pGGmw0frhACwSIifR3ApjurBigW5aFU0gYu8XLlzgq0Ash/e1MZzXlVdXVtpP06wf+08/jg2/7AHD2HOpcUVX6QrIGnEjVmHxTm/tDntKIozvH9pog8MgHc4PBpdOgoHJbW1myFRX8+h1h2evF1ZvXcOZTnoRzH3kJ165cwe7mCXRXl3z02uO/Qfnit4GpZPPmlAz6ZrQH/UIUZ3A2q8HV5sGm1kL2T23FPGD9TX9jA7kcY5aEw9j0tE3THO2O8NYH33e6nK4BzZrDNzpFllQk9GgPGDJO7Vth3N2GbP8TkXtGaxPRyPlZkahNaZ+t22oyxCutHH6uJLLG+bBkN2XDsK4JkfTKPS0Pc3bNDCOt3sC1K8SEJHsAk31XGAHpndyU2Ugeo+xy7lzzbuvch55imMsY6W/dETIUKzxLQ0JC7bSSDGyMt4OQmSHiea5Y5KBebY42ba6VhDGNSqjzw6NW44+loDqZk3l0QMArrDxPjQ33/qzTEI4uRWemeGqkGOhWqLRTlEQ2wK5ie+E8vuKLX9xG2u3wCgtr7by8VHVe0MNmPIw3ORwrOr5iJ4DOu8jP6XQl/cCQVCYPc/HdMP4kMbl1w1Cc6Vr2z9QbrtoPNbB5wqqYpgk3j2d897/7MeCOO1DrDNUZNleJfpqay7rLcZcIFn8C9cQ7H1UJOnWRdm1el/XLFpnZ/GOWvQDvRoiSUPm7jvUm7nvuU3GjHuHo+hFwsmtvwek8i1EYHbbWkO74ZUxdPlLmvaflXGEHaqeZV+6OFs10Zizf2j7ysvGnpjQms7kJ3ZaVbg8MuL2QSD5XxSNH1xf6a/TYL3t5ilGysIoU1ZrNjUfDzpbBto58WRuBReQO4098iIFSXTzPJezHI2+rSAwjh/fdsV4kddSYmfPQjVCujFDx3BqzKJhAdi3vShlr1+ps8NKBin8WNMX8nd9X9wthw72A9O0O3aiRFA1w39K6lR2dCivL8utg3HOTEyi6aVWXIlNO7WOm43yNLxAayhTPOzDKtgcZ0HsDQ7tYztMhGF7OoPzSFdwUOtE+lOnf1zrRbhv/CzBN2D30ED73hZ+Opz/tCYAqNtPk5dke0qVNlAQObjc1kqUsC21mooIf4xVOxPBAFzUsyrvllSxJNivJIRI2beNwagzJ2ovLgb4PsxT8xM/+Bt786jdiesLjgd31/jYj3lcKt00eZY6N5b7FAL7cclYrdjKR7/F00bqpjcv7xG1M/0cjwq27E+D8Fnc+4/G4du1RzCczigIyiQNeagrLEHJXBmAiyZffpy5fAOXqN7an9sjAsZcqBsRNuRLg9rZmDslKOpNVyewcHXwYiLd0Kn2H8jQNwVUEVgp0IMuInto/AKvXLesxqNMzGszhWjgR2J9+TLZPHdlWnaayvs82rwbbn8HSOzEaaptAavBGnJEZORK7FwB9WhTdJdo6LidsQpVD+1EFe8TR69FIFpFfctnyEhPp6ao9Gz0tB/OglRriUc8QWvQml/DAnW9eKHn2BnBWr/vyKbId+5eB3/JZHdZ2egJXRHMGBEkxxSNe7v6uGE0bu02QRG9w1RgP8Nt1xlXa4zDuIkpUgZQNcOMqvvJPfHE7x3ZWOtM3ZMhlI/FvVDBaNEQywFfILG77WuC8fx9BtjPFlZllaPXrshQrInkvskgLcL/YcGxtc7AdaI93M/7pd/8A9HALwQzUYwg2EJnaTCfJzlhD7vPo01EeoOqiyWad1xjY8PPonHmUq5qiv3AC2y1JPNGOtV1voNDjY5SnXcR0z1lcuXo/dG6Oa/OHs8OZ7Jd9Z+dh1bibSWDbwt8lF+aky9DZUbgH7P2HtcccHi9fI82yFLvdbSs5B2m1s9Eu8CFx03EtQN3VdnIpkAHXyhaLzkP3Y759sPOgrAS04+rltsrddHuot+ddu3S4L/zF1U/ys31XNMDrY/u1Ce5lY7xvjNueWyNXHua690S63G9jubest0Fd1EG2KYQWwzwuVUbSJVaUgCbUNZWZAbMPL+xmzDf/f6T9ecBtSVUfDP9W7fM8z73dfXueuxllEBTBgRhAowE1qGgUg1MENYn51DchOMTPIa95E+OQmMRoYiQajXGKvsbZOAtERVRQUBQVEBm66bn79njvfc7Ztb4/qtZav1V7n6fbfLv73OecvWtXrVrTb62q2rXPQSEop07DN2xPnbf7HS28DPmC7lwUPvxlS+LJEP3xDooUzVEtFo65IwmeW1CR+5NpjQUCsUIYXNQDqNzFBa+8zMDHFfkOWIbkZV3ZSVOIFhedPes7Tajnz+P6D/gAfNLfel4AvhO0/jjP6DDjAndI/U/uxYpSBQOwKL2i4otshRiZFw4+qrkvy5E81mJYC9CSs+63FSgKqq/k/vnXvhFvfP2bcXD9tdDthc7S2GnJOmhTIu16zqjh+k56RGbXet/tbOhH6F4PVkWSnvHQKLOUziYfQVDV/KN2+W6PcXjTtTjezDh++AIOO8hpf9aMF7Z5M5ZJShAqqUAyDEACqIdYgyqW9DIPH0DgBMZuUt/OInrFPE3ONg9aMw2+KkPhvZS4jV1K1NTeINh4q2jz9xZAMI1i2W3715MDB7Y9gLjyPUbZ1rFobe7Xv1oSsNJS4svo5/4qB1XUuq75fbZL+HuU+jQLYwGWNmTH11aGAXoBui1KBGWaFtSY0eX2kBRiaGAJsk5Pd8TIHFhU0+c26u4Y0+nTeNJz/zoefuBB3PHHfwpMhYJRczDmeAwEzbFlh+TD1P27P6+n3bgLZfAMpMOowmhCNk+W5lz7fZYJWDs5++UnNp0w6lvGktV5s7gtvKvLRnwbs2gxaHIjYoAA4lnj7ohsztleG1YONrjw/vfhFV/4Slx68SF28wyRvhl6KUmeEYycoO+j184X+tdgxLhr2KMdq8Glg7nZFtmCmKNfIMlf+YgRJ7OrqJV9u2h7JeBcZ3zTf/xvwKkjaJmg8w62UKfpuQ7PgSq97zbAkOM8Vsk4wQXyCoyYIqGzXU/aDqTGPNJHqliSyEf5awcLBeYdyplD7OoO2LUsuRZF6dUXo2VVNQJwvW3qn4gTS4AV9VHXYYGmvQSgC8447nbMPEt0KX0Q+sYgxTYPDLeSjwAHEv7dfFXYqvm3WdV2GXffRuS7NO0Yff4apvBbf2JdClOfy62P5hlvH8VWE07lIfYRYyiRXR7muFX6+2w57KUKHoO/yG1z9jq2ThXqyjm+d3XcvQvSYcDRJzukBf7KqDRWX5ihscBAYYiR0FXI1bHutjh95Y143Id9CB64627c8edvh+4UMtluGKM3QeqPUPuL4Q7vbqtH+iMXDsb8uAFHXr7NnFUtxB/uSixACQAcFzj50irAUgrvAmnaaMQhWPrNHsSq1ywn687CrrOrtXeS2mhEg9EKKRMKCvR4h4uvuRJf8vmfDq2KedfeSDP5FoQjn9dAi2cY9xmArJYQQ459hmfl459HPTIPyEU9RtvkdhO0sKd3XWpz/aptvV9BgaKibA7w07/2e3jTb70Z5fproTqjyoSUHvS+m46E695PKLMrdHIIgBQQ0uPgB1yXfREitRy62soJ0FEyaFIb6xR70qDLUCuwae8GFq3tBQwad6l9J5sLsXMmL057+JjeLzGfohApPmLSHvPtyUQJmVdUlDQ33hx4Cr0YKTl44N+I73HLHn0GrdthX+a8z0EaYAEn58RRwX5AWi6AGrVGezmuZDE1MdS3/1Ai6wRj9WPQyUc7jBjXwbZrzWa1KteKlQbodAIKBlOOQJiGIatdAHT/bRld8/NmPOxshiGaRaXoRhqGl+eF1nrGz5BhCQi9bTPyMk145JHzOD6/7aswJ7hzUWNToGFeEdzVdIH/lLkMIBzzl5wtiFsoZ5DibcIzaCMkApYWlTpXldtR/858MNqYn4GjOcpMThFhTDYXvdae6VBenKeglL4X61tlSn/UBxXYbDDfcxde8pIX4gk3X4vj7bZxqSqKpSRJ1TK1+w438u5Nk46slXXlyo5meQjxNZOQdNXjmjyyc9KxWCeBk3pICOAZVxvBmRWQMuF8Bb7pP/934PQRZDMB8w6Vt5XU7l5Zrit0+ggIzHcEYa0e08923R0wjaqEfpgfoP6ZL2Zna+1EyOb2KFSuvdvXsLg/Ijf37QZ7/8wUGm2Df2Ago6hRVSCTcWMYOp0mzPMOx8eP4PzxMXS3hW4BSGk+5XDCweEGR6cOcVCOwNmwyyuBKBxg00JKA13iCcvfBnyZryD5OW8xHlY20EXZN7h4PcKg8iEnSXgxJlTZ4pq7I7p8uH7QtmGo3crwNT+/BrgE7MsR22XxuCTjCaN65X22j5bSPkaAJ99GJ0kRR5AdaWBa+RKfWev0HqeVBUEncrgZpTnN2tdMKc0wtMLmW63nfhdVbcbsC7CGoZy8qIm6Z5jaBefku9KFQtriCqW6UyzifF9Gmiko8aFhSSphzmbsHoO8Wz+zM/3tPdgz2sD0uLAWhtLlJkBbDVugxxfwIc94ujc2TcVvq3Vu+wXjsR1J+myxwiJdrLMFt5ASetd7Auzu+bmOUtYy8Fx15DNZR3XQp1prcnxGR9OtTsXYlCoEta2NmmccHJ3Cj/zoz+OP3vBmHF57NVBbEFMhQN81SAAKHLMjdHDsMhwtLTfPi2SCkxG75P4FQ2SMx+hg547EOWW05+Jd73TubRq4Ds0q//DbJcqL9K0Me6BUBCoVZZpwvD2Pcw+ewxm5CM86czOefNV1+OCrb8T1R5fgqBTc8dD9eOvZ2/CHd74P73nwHtyP+3HqoouwOToFzDUEOoAq1Ibz1X0EJfMWOfj9DIbaJSBcdNVND8BtJgq0R4PqGGaFrtq/zp/M/VX/nvwXkPQqLhCha/ixalP7UZNB/f/ocCaGwxjmbJH4uI5lOuoXxjrMIbOPWtyipPTEIIGBDiy0Gfi0AuO65zsXewx9TG5pJbMdG9U6R2W1DzcteiqOKxHVB0esn/b4AoNxyyJ5DpMiT6svxsmdj4solhSR5zlMaUe75TnYdt3mtXXZPiJbMcfSjCj0JCLmHoiQoYwAkbLazgM3Ou9GzIXbBQWg0wHuvPduAMDh4WGWFkf7LMP4unr4PF+iQfxvuj0hc57nsaCl8eZExUo0+/0QJBfmQgtNWhvOtznCAklA6xsCDMc09bqqQnGI2++8D1//bf8V5aLTKFMB6hYVE7XDwZ3JMGwo9LcNqSaeOGiFyw+Rhr4tV9PDY2Q306HuFDQClA2RPnUZqZjNVXNA3Y4aqDX9ZrCNRWUsE4kWHLAx9/IFaBlzwcMP3o+nHl2PL3zOZ+BjbngKHn/xFTiQiYn3Wi/UGe8/dx9ef8s78d/+/DfxR/f+JU5ddkXbMrIHU1LRMuGKeFUkZ+3jl4Ur7IBAewV4QDGWXQOgwd1orXsXIIWfD4Bf+GB1qtLBoeViv4a1rHVP4qhc0WBjawDvdv0YhpzNZ68dGzO89ZXAKzfp8udJMUOY4D7ixhtlEGpezLPaWrLS9YqzcOBDcr7IQnlYSV3/wqfl52b5PqX77QZ2wxJV9rtt+MQaMOBZ4QWDGz+LWzWiZiltKaIgvXeWMCsi/0pKwwbphK8ritqSQwZusFNbMeoF/9uzm+GcuQDfSlmyGr+pLzDA7YOOgja/duXl+IlffR2e9uQn4uorLvXX6UErdjV2zvLVkBI1M4iKCD2Pm/lBfigBrMYPDKrWzxVIae+KLVL624cKpk3BZlNw/tw53Hj9NfiQZz0j2nGnI21xlFCbEu0BsQGFBRVSBG/43T/AO999G2QzBdho7A0NaXvaGghD0d95W7Hb7qCi+JFf/i3cddtdmC6/GnPdAdjEYzUr8ovgDFknKPjg2y1456cVPDC1IIcjolTWbhmdEjWU9DOCAF6DIaqwdxt74SK0FeXST6kbVbSxUH8hu4FAdzOm4y3+6bP+Nr7omX8DF2Pq88KKnc5DbtAWGAmAm09fgc99+l/HZ33gX8MP/8nv4F/9wY/jodPA0anTqLsZZS7N7h08IihOdK84a6e8uxZe5DbasSxPkXOhW3Rc97L/GPuc684AOrp4vvaoR0o6/ORKucdC6aOfXjs2e6+Y4IbOpNVpCCed5DhkqlF6haEDzeNCHY8Xzfh6aXZuXIE/vsJkrzn3VKQraI8Ie0d7GWE8RJx1rI0vRpOTLU6iDZt41CbSR5+5f+JONs2d6pDx8sIMBWzT33h5tWFUPPvovNXhelDnTk6JZx7xA1RXXhQR2WjMw3GEx31z/gAQlKUczVXrMPIBBA9MThSk1Arg6BTuuu88XvU13wLMW8h0AKAC8zZtTWfPBXtH/WvwD2IgZ3QtHjhDBIZwB+6pFmeZArSt7Ozl8311dH9F2VQm4OG78ZVf8SX4kGc9Y8ji1Glx/WEAkmi/aoBtUcG/+Nf/Ba/7xV8GzlwFzLtgcd9Wr32mRkd/9aBlJtjtoDoDl16GcsVV/Xnykto0fQGCtBbIEl0cznX5jRl6zOWbvmqUB8ubmk/Ok2zK+EWBpIkjJK2khhr1e5Tcvte4yuSCfYVS+16n67n0oWPBfG6LK/UQ/+VFr8ILrnsy5lpxYd6iQlGkYJIWiAl1UlUx2y5rChxOG3zhB70AH33TU/D3f+k78Wf33YODiy9G3W1TRhu0Zl/G/ocFGRIaO0t+ZrjU7hYTldsOB4lrh7tGZfr2tDvIl0F33HNhrCLdB/THfUhnWDtYUYYeZsr3dOjEw3uMTVL8k7LHxdG6NywrGurJpR8Tbat3DTenqD6upeE5d3IrtambS3KMoXrd2TPCUlbnzsm2/VtkQGZ1Ld3UpK1N4OYUrDmPsrun106cMLD2go7jFkGysyLA48qbUcSQ/BBC+e8U/LlzJ0BK3AxAdZ+/+NF+2wvMHbDNYXs7WRbBk+CpAa3/OzgWqYAcHeLw+hvgS1FqhaCiolLVGqKwurgxkgsDa5MH8ceuebBlnxrfM7RApC2la6ojwHQAnU7h8MLF+PhPeCGVC5musH0xVNXw1hbKtSDmrvMXcHjzk3HqzBF03qKWDWYtgEwO/k132zke7rfseN7NmGvv08K8LPuUTlMHmJWnBMJBmj5r56d4WeuDuDjWp00GeBi4EHxK4lt6YgLt3o+qdIN5AwNmQlJ+pInwjZ9Tb+xqdny83eG66RT+2ye8Cs++9Dpsd1tABJtp4yItaXjVeDNhkgIbsj6uO6gqnnDp1fjhl/wTfPbP/hv86QMP4qKji7Cbj0NuznYJLOlgoyQXzsAj+EDwxWyodztBc+KnaUMfWu+jBGsrGsT5uS624D1hMAXtPmq3D9DXbAbkZ/KZxde1YxXITyg7njEdz++z1Vxcsbw5GQw4o10fit4/RJ0BOM1PEVNW+bDHxngl22OJF2LxiDlFMuI0r2og1yvtWYm9Maatju2AqwPAAvEMIAF5KLwa/kbkT5G6KaZ0IGrOprXjZSlY8DopKnR4GsBTuKxEQwpuC05v28C9g86qrK2+LA8loE1ZrrWpdO+ajFLwEHALGL/t59w2xZ/tnGWzFenFBQs7YwfLnOzfhf+uHE2Be/01gy0Brjkg8c36BXWjmLeCiy86wlM/4ElD8xY8sT0s6TAgExHUWjFNE971F7fgXe94N6bDI2B7DlJ3AA5QsUGVPucgJf4WeiczBT1tpKN0Jxk2EavjQyIuIUFMa7iDDJtIc7Sk6+xZeF2Djxo44BKTXJ8s0Oj25QCSgZ8BJeru51gvBDEsb7Qr32P8sX8oMFAAKqhlhtYJZVfxXZ/8xfjgS67FhXmLIgUbKdhIm1LIwjSmhixUFTtU7HRuz65ud7j69Bn850/8EnzST3wrzukFbCZFtXfrmkHxmk2XzYo/1vw18IDmwccsPsJUP68AtEoPWqyMvfZn2dxenz9krSN/dCwzHiuZMAuXRz0YStN8fuLJY4VabmdET39S2oiL7wPu7q/7sZOxEDILNoa1HgVo9xFBDl5FH51Bqcs27xpvxcmITsrjmUAHvX4uZbmpnUyLkzr4cw54vAwphdux0bYYEiJSFU3hNdxbqAAZsSsXa1aANy96SRGtGVbnc3vrUnQm5kFp1SEFaZns1kalzdDhjo2ynIQxHcAMQGuFVG0gW2donaHz3GVZobX2bvVHhbTtjdT2R5pQUaA9YKooqBBUlfYXgqql/a7DR+mv32N1TqgyQaWgWt3axFJrRa071LrDXBX6wL141lOfgiuvuATH2y3mue3a1NTJeLkUdXC8lSuloBTBNBW84Q//GMfnd8DmADvdYCeHmK2vKv1j4q6NZzr37xU2HN0SPwsectBiOmq65nQquqNXN5nQPHV6/flZB/f82JeYYYhple1UlUKk7Ff4exSAZ6KjXxiSBziVvf81+NA+/JtAF6A20MZSpOKRs/fhG57/GfiISx6PWWdMZUKR0ltaESoDrZ9qPZ9QMEHaXt+14ulnbsK3/I3Pwbn77sQFASC8+pxoJh6xTfORQZbFHP01UOBBW+0BTXC4Z9fehxSGYfQPC5/PQ8f7sleuju9ZlCHPS8HvEoWWP+1d5CfjiCxIDZJlUbQ9Z+u+bSBDV7ADlJWtV5tIGaOXtBIVWM+QvH0iQEDPGZKiCrUxEvJoaK0s2OpZogUaS9h3L0Lw1YXdUcE34kfmj2Wt/ntBCxWELIXMGa/GdV/4ZFE/kLNHrHyH2iOVHbfFDSQPbzfDTyuFrV0PEHiO1R4TIoCmYR9zI95GRe6nxLVghea3g/TrrkfVWgpn4gm8RzEnKYakYCdsRfaUJ3F50G4aaQwNx67oq1rt5eX2Mm1z5lDUC/fhFZ/xiYAqdru5rQjuwGmAOwTrya4U/QULRaC1YioF//v1bwJmtOdh5bC15SMKMdfmWaIzwPS/MTE5v2T3fYXuGl9MVtJ9i2q60zNRb6afb6+UCf6EW4ZllrxSXhcNxxfWwXhW1xSrfTTRY4/TUEg3t+FgD97NNOzebu+uw5btA8AEnDt/AR/zlGfi8570AqhWTD1Y8MV3C951Xc/Ox/k3wUbR2miDouIznvhc/NgHPAe/9t63YXP55dDtDgblHgBXwF5h2ETtBr6Gu86byGrTn04TuvzDy2k/7yaw7+jBU46LNO2z7N0nxU+jpCv8sXKeDPD9ew721OPCuygD+BvSuBMjIV56BXhUsRGR9JJdb3gPcY+GX1z5uMkzkKOQZufrjmzZbhjK4o419HrMhML7nqqh4ZI0vOSupu30Ym9FyQi9JCiJhi43A4urPtxMt6e3BFpjZvimBA4qtLhKjGIKWli91JSewDER3OsrDLhBQpKf0aiK7J+zkxa4PVAzYfQ81O2TFN3DedMURqbaCTxCToqFZxb6wrRieZ6dcrpXmYdY8VvMKAsz2j7C/XkQoBTUc+dx7eNuxqd+4se2udHeP8tsbXNAq3MMgH1uTaRntYd45NwWv/eWt6GcOQOUA8rIiDoZKsIgg/aF+hDlUjJo5ZP7aDrZfIsS4NKaAb+Ho4iQJ28D2HQ698Gwn3V9LTlIGZaDsdlNgAODvBlInWuXRbb7IBJp/3Xrl0KhBZBZ8MoP+1RM3cZKB9txLtuCEjHj6Bd4qHpM9Jr/ac9lf/VHvhS/+Zd/iuM6Y2OJDPkvGHCy4SPYkXpActTFReZrZ4OV6/wPsBQvN1af9xcf+Jp+Bwh6b6h/jCWpt8kBPfrh8tiDk41PCydMLVPrw0+upbQODI3u4zAGwceXRcfaZYUO53nowFyQDBX70EVqt7dDWUMTs7oCj/+dfMjKL+KU/7EhZnu0p9NYq28aoMr1MeDmVla5mzuZLnikx9coMLBadfEt1ZLr1/jenA2BdbeEGFHICj2y1B2momXbJDNeqOG4T9fMgToPfJN3AlzvboCQz3F7PaZrgGUWTL+36VMLkVH69+RxSZ+NTrR35vJ5gUK0DTS7jiQXogH0BrZCw9Xa5knnB+7EKz7jM3B0dNDn3IKPDJLJ0boqRF9YTr/zprfi3W9/N+T06RYQSh8+bujkaw0yMilX7LJgx5lkZnLyH8b34EV+nAbk3SPTdVlZm4Len0RK1gP+lxhji2+arYZTjtEaTYBgDWQXZX6lv1y9Pwrlj1b154FUNVYrC6D9Pcm1AHUDnNse49lX34yPvPKJvc/idiIVkEotud2EzmagZbs1M279q1rxIVc/Ac+9+Wk4f+5h1Knt/GUjQa7pRL99qvmw/ql9+iLOqwd+/ps/2vc/zubi0wqrPji5IJIHy4oVnkYDWflinn7AnRUAtvI+ZN1HIUGm2dy2NPmo9JdSiAeNjwonY4PWLp3vMytCZR8dcE1NAiiHqwQIDqR0LTlJKv+orbqirXdmQeKjHRkB6J7uNFyzKxRtPld9AUw/59zrFXbrGwEmBz3kvKxtBnlFFz6tLOao3H5L1JHdpiYFipu68dkOMwQyrnTKYKe9zwNtZPgAPINhVjo9GkGAuOmPWKjUnvaXynO5AF8QLU6nfw9mu70mQOfwLqhafpC8vKvnGBA69/OtgBl232HMHvvphl5lg3lzhONzFRdfez1e9Q8/FwJgmlp2WvrzuMzP9pf51EdWzHH6WgPgJ3/pddhtFbo5QA8L4Iug2OEM/BpHADQxMNMgpHsmNyfZdbXpD0wfydNG8JxZt7ZILgTo1GbG2HVzzGIgFk42AqfE0KFucvQdZDM4USIwmkQHXBWBloLthS0+6UkfhlOyaaAsQPMYPThzXc/ZuoMrHebsw/FLBKUADssGL3nqc1HPXUAtbeFmFeRgnezA++B96y6tn/M5eHa4fJ+DrIGlBZbqrmwhRg06XE1EIOPv6PTy91ClyXa/zuTmybU+tlInAuyeNvfcI0jP2XJUxd/WohO7ysN1Vs1ykZPSPWYQiUHEsLwmkYU2gNpaTHAyJ/ORyg0owtG2VWubQXTHX3VGNfB1bWwVW7Qe+kXDOPabu+LAYH2UPqcq5NjCcnwzh84vdiyW5fDwIgc3llVYpsDz6EtZGV3Su8fzX9GfxQIV6dLqNPh8cG84ViN7g+TYY3Vx7mGbVzMnz0K0IUYHUdOlEsA5LsLQRTWaeOn9soAlOWjTP5KkMUSM5nHEoUusP5ajmFDP3o5/+w3/GlddcQnmucZWjR4kBQzFXJWE4+svd7cXIMg04f6zD+Onf/G1wJkzfdFT9MdDL1FfxB0rjHmlOPOLgo3O5+WK+SggaQ6zl/eagpdK95o2p/Ucow2qgYsuHSyBZugCQs+SPwn9twBRBAn0PJgyYKnN5sy/tD0qGi02D9yeDGwFap2x2QEvvPGDYNM0Ff1xL/KY1qeUnRM7PSYi2+7ic1dny8Y++sYPxKl60PShkPYpun4EaCZ90vx97Vg9raCRVXW/bra8AECKSc1MYgTKaATV02uTuJkDjMwzumdo1zUzO+D0DonRn1i71KOx92Pt0Sn6aSVMU/KmFrKX3/kgBunKeaouXxsYxI49M4z/MCgval0cTNFJQ8kcXWasNYtiRbCbNO5V9aGV8YgFYBo0m5FD4S+y9hv6sFdoBhxwx7qpB2v/pjkqHRTF+RpOK9FL2YnWXFs0rqRXSyWNlDUcIATEJ14YYcOGNFAZfrrbMNXjfWSaVmQ8nlsMhROgejvMKx16lmlIf90qJX7D/tijNRUFu+5sFZgOcXzHHXjxp70EL/+sT8I8z9Tack6Ppwdq11eF9sy2DdXWCkgp+Llf/k3c8c734ODmm6DzhbaSWoQcNpGfh00QgOswkg/lVeUMiqwpFJB5MQkbYh+jcZ8yHWZ6HSSotX49A21aNGU6rMw1s+cQk/9NFmK+oP2ts/qubVU0S4eCrqztit28w5nDi/HUy6/PviNlcoIQRtCXuzb6U7NXdxEQCCYRPOWK63DDxVfg/fMxZHMQwRQrOmepA/i2v8TllAyt44IHpxLlVQHUGUTAcKizOW7I9Qv/1vHqSpl0YcCZoe0mO8kyX8WJ/RC7r9l9h7XQwNaUmiOgPTWkSHbM/sZydp4jWZjcTfnEyzBxVod2B7YkZYxmZDD6kzuff7HzhCuPuw+hy4KmSH1YqdKbOJaxQPAnZwMgNifLR4AsrwS1vtkdEQzEQijQCuOo0zJT4YwSSE6zVZGzAjcgy66pvrQAy2h1RyAu3+hVB3deRU0Zsg2NcRa0zJCjXdtA3nFTzIt2E/Hsj2XC4zDGd8ZJymxZjM6O4U6SZSQG5gXZMbZ6i7SXscvmAPN99+Hpz34G/sd//lc4PJjaqwCbBHwJDXJr4SAR9hNzu4oigu12xqt/4H8Cp44ArZC6g8iEtjFv5+8Jzis5GNW0Wp2IiE67fjLDCM866DU+BDjHvHTn+SBfV81BRpzdi9XFf8mGYoSC9Ipwx9WkWr3EG9U+jNzBthA4FSKtjQ0Dk8mkXZjnGafLaVxcDgPEaHeyWARopmoBRfKgzvNWdADefm8RgVbFxZtDXHf6DG49vhN6cBA6qtpW/atPErPCZlVgH8wL1NZQx20wZ+ZthKD2R/l4xMq7E952X3Z6Aq4EfZrLr/SBr69YlF1c/57wSE/EFm9+5XKMxMnKdo06/thTw5j2q7ohtZ9L8FxWz7nEGvW9gycCbS6fD7Vmkl4FzIzVhVEgOZjcXqyMVqjOuUIzcP656OGoEATCRklyikpKyt6dvYddUhIwK0I3jlX/uGbsAErIVLszkkE2ar3tobZnOtaegbEDHpwzCVjtrPtxydeG8zFX2mssFrS1mmy1KbM6xaoJTcUBOh9jeaKTZOC9EYEFhi14adcmKFAUMh1B77sX199wOX79B/8TLj9zEeo8A5vJHWeJ1CeDg/NbvfelO5EKQErBa1//Zrzht38fB1dfAa3H7d6+JeiKqqw6pjwI0GfZCVc9E016kCtY83eucEIhj4A2PCH5KN9gNpwoj3voNPsK6TTGfeEBloGU30F9sGBa+yNePbOt8OCwv/QXUJq26fUeTBM2wqDfeTgmHGs8TIcMMgHtP9P1BYKCgovKIWCPK3G3bYjcwJf73kF1IbPhhPUuYocYueD91msPYOrKiJ8xwX3Cmm+X9Z9ruBJ05fJeYsCF/SD7/9/hUJiICX9otG/40tLZLAnymxfOMFaHLechyEB52GDVKgeHvoha1pnOJMfQFPXJEDf1jBaoC0Z05F73f3v5UqDzjMPDA8w9sjQHrKk8VxGZY4pUyZOpl8tG2hnRKdWEt0zy6nzacI9nt5QZS6/IHTPUAyFfqWw0WB+dBg2n1x2mcDtGI+mNqA3iS4x6WD8EiPmx1jbPI/pIB/NWTB/E+2Ty8n/7NoJhEOR4W5UL+QvXT0AgFCjEWoNeicRa+NK7IKUA02nM996FJz/tifiVH/ou3HDDlQAUpRRwoCqCJEN/53Dvo7dLfmqSglkV//a7vr8v0JmA+bi1q9oXnNFOReMoi3Xc+u96BG/bGSEky6QWpsc87Nvds7VnwRLbJLJ8A1y7BBlo2H5W9C/ZjcADoTZHbRlz2KjNZZp+sl2pxmpkz2xh/dO+tIDmwBsCuTLVWjGrohDoab+78m+nkYzIbnCur4CS2Zv27BbAbJu3GN3djtHPGdgm3zwkEjGyI3SufxWkc85PAbyjFb64LPmvZORjn3Txbm8eZXL/yAmcDMJacC3uW5xPRcz3dhtcA2HSy5MOTwacOdGGANgkzJL4nLjKi7Na6vQaSD5qHSccksoZcTi5311hRGI4joc5U/3S/mm09pWjICURhFdj5T7YYHvPPXjnr/465m0rLxsZ2ulGycQ624bo372H/SSUWnZvNRgM/5IV1JtdODikfoYDi5PmaEdgGStVqnu1bNQWzq7/Q75oiEq5KfUyiSBo9JMANLVrDrh7iAhiWoteswYthKupBzlQpEsOuO0Bm6Lag5YJKIdtc4S734u/+XEvxA9/5zfiyssvwm43B+nSNrAweq07th13YvvovHtbv/xrv41f/8XfRrnuKsxVITL1YXt23mQRSYkGr5j8RQZVDhoBIfrEa4pBIc1y8fvsExIXliOZA68jsHgAzjfHj94cM4f0341GQ+Jq9klamOwhMtuS5via1lg3LKtT1JCdFjy0u4BH6g6XlHhluLdouk9Zpjed06NB80eb1u6/gPN1hwfPn4NC2ks5LJCwDJRtNenQaMMI+ROvrVCyT2abPeHQBafjvdbeEDcseA9rPyv9aNkeoAApCF3jTyJ3zT8msF4BF9fj/Ufkn5rqZkzccPupI0PB3LAMwl6WG7Mrv5fqHiPkUc0sA1S6KoJFx1ezaKo71rNyHymySA5ckiItqBI0UK7Aw++7A1ImyDSFl+Hskv2c0WkZQ8oSI8OM1XcduJXJM07E0NIaLrtLNR50Y/MMoEVTC554NruofOgI8srV4Fmfw+mZafCBnXI2ojxXgz7EZB63lfeFIql8ZF/ZAdDctEQfxL+HswX3X6L/uauSSObvmSsKaIXo3BZCaUFVYPvg/TjaKP7vr/on+P9++d+DCLDb7VrWBGAqpT+RI7kN8VnyhTo2v9bHBkRw/sIO//xbvxM4moBpgs5bqJSWtYj4lISLlfirLCfXJRnekEL2SqwI1ph8CQ2HTJFHRUwUoWa8PoH5y+HqMJs+6g7IDwicfu6ft0k2E6MgrT2zPPTHqew+u+6zw9Wy2f5bS7+/+ZMHHn4Q7z17F5551Q1wZdS2wI1XChMh/CP6BPcExIn4t/Ydw+55+EHc9uBZ4BJpz2sb51T7MHL/bgy1fnO7DrjNELPnIz4DsT7EKLE94QXt9Z+MtlRRAlpeAcqNMfit+Hb7vpiqdJsZ2vJg2G9erX+BqU5zlsl4RNCc6/X1SL3QRoQV0Jx0viFXnKM8dtB7s9hMO/kxWb0ev4Y4Q1biDgMP+h32SJmm4arG3xXcXhLTHX5a3NWdSzk6cL6xoa9FyqMDbf+bCa8RIkkR/TGFfp45YRgmBMIMrkDw2gRv58yZGGNSogibs2OA5P4ZkLEjU5KBDs5tcBY5QhiCPlmUtcUY7KSNJ9EFUnCXFtr+vuZ80J3RkDKOoGZ0hJ561BPOjAChDdsKdtsd5oceAETx/Bc8D9/5jV+NZz7jiZjnnTv/MnW3vBaoQjtQWmDUmq0KzFoxz7Pr9nQw4b/89x/FH//eH+Loxhug87m2L7Nqe6426V30NXE5gZ0rTLIXBqW9fseBFuTQFKGI4voQembtkEGy+bAdsmMeDUbXvg/9ZF0c2a5DFar+OJB2nY/dOYWeK+/2U7WvNxCgCI63F/D7d7wLz7z6xiZvQd8XJULcxC76vuwX+Qlof16X+ieCP7/rVtx3/iHgzGX9RRyKvjKqD9bRAql07IPTdi1GBYYSSuz0pMHMK0YN9h5mzyeVs+BuBYMW1TEQLy8iRXdUkv0xg8eSthUmrOiQYwv7WzR92qT7NBrdB5z7WLOvvIxl0jAZLaNfizYGAGfgTO+tZYBlq2leFqbF+3u054qAnseyTNNAogC1+srYIEUJR8J6zP9YRpXnIHtR6ldadUtg3ZSf7mHeERCoO7zIbluiI2EcxksnEJ12yiISsPX60FVFxoib21O/38DYm3THOmbIDKjLVapBNY2KdEcYWk16QvrsfCTAzbLXoC0ohYfvPSqVDr4+TaHt8a95u8V87jzq+WMcXXkZXvyJL8Qr/97n4qM/6kNRSsG827kOTDJh6u+PtYPnUFdHlIZDVVGmCe973x34+n/zXZiuuAKFIKHtnQsXrnPXzcF0qGtqmEmWP9HW7g9987NdD02fdZAjjy6EbInFbD+cPTPwapzglfFs/xyMpfops/Fb1lDNLzQdadOcltmSzaWy6Eld8ET65hY///Y/wOc88/lw43PV6zxw84oFiMqbloP/BMEW3qmqbxn7mr98K47rDqWi+6VeUqtvlzmwNHU9C3QopMvCApvTF9+0HwpoCZ4tDgumUlU0tUHt+2OlaeSLJulOyHit6vSES7IpwiAeDQkQSb91XWECK60uRJDslkQ+bANY5C6ZEX/FY1WITNN4joGW/3IZi4bXKuQGWR7gqBPIYx1MUChseCVJRiQAeBjRigXoihu4O312FtQoC5ajJun/GIayWeVM0Bwi9w2Dw07kdqMeWOdAQyT68EbQ4v9oZhw7QqN9pbtc+fK0GYSmZs0bu9Pm+sk83C+CeKhpMsj62MuX0oYFt7vWXjFZt/41+Y2L0hJ6d7KlOa+5AtstZN5BdIZMBacvuQQf+IwPwMf+9efi7376J+JpH/gkTKVAtaLOM3zxk/HYmRyLotaOWChlw86CIhNsjcHf/5p/h/MPnMfBdddg3p0H0N40RBFasB3BcOY3JPed9SdxQjHUx/wmdnUbsuAmLYqS0P0FoFCZNX+QdGClabvVink+L4D2Yc7QG2rb+O+jG2EEHRuJP464DmgpKOj/lIND/MpfvBXvefBuPO6iK/rQrgA11pKEXuXeuQ9Qsx/NPFJti6C1Afu9xw/jf/3RG6CnDqHbuY3iCNxXqNE6+stR3nY5FAD7Dp8y0GH+3+eL127iRhD38zkr6iMtSAoYKrI+kroYWj6BEB35sUKHQ0JqY2DhSsLj8iTb3izK/hUAV0CgOdLMjKAhKFm5bgSn+8n/j5FGO6VLLmAoN15bAYO8YKMXYiYMAm0LDtt7XfXCeagUlM0B4RIBpDuz6F9rycBGcxFrwzKEDqZpQwDLFqh6ZpT99gzEFGNUbBY6ZZKsf56liwE9DXmbz9EoICxny6A9KCEeSmQg5p2S8VB7Q4oSxHVZRH+GfXjdyQL17IM4ODXh0jNnsL1wAds699616Nz2fvU3P6HrENuECKQIDjaHuPGGa3HTDTfg+uuuxE3XXoMXfdSH49nPeCquu/YKHExT42PfTxfdIUZG3GrnkQLjCesEW1Ptzy4C/WUDRQAp+M5X/zBe/zM/g+nxT0Gdt4BsXDAuF1YuHumggM//EENjeJfktWYbQmsQQsKtHbBMIxNNWdaQ/QJ5TQPXmGzTwSfP40fAhvA7Xs84vGl2T7QnW9IOquogFyRp+tdwVxXQWiGl4IGH7sZ3vfGX8U0f8zmY64wiU/KV9ok+skys5toCSWq7xYgVqBXTqQP82B/+Fv7klncAN18PPd72130CKLF+Yrm4kX6y83EDDzq5pwv2Defa1o+9TZxwKJIs/IUqMG5aq6STw0jQ2iJcXejMatNRZiUrjlJW/3odBh2qg92SYJX2iNhE5Bwkir1U+mR2OUgySBDl5BzDqUdGyI4yiXOJ+DIw7iTSuhBF6KbON6H7GrP6zBu/r9PRyRoypxPnRSvm3Q5nnvgEnH/gAWzvewDTwSmYMcecjEXGmoxs8f4pccxZOPhwksGh7KaZR7LqP3LG1s9Joy8UaunYAqSNlwrfpABwuaUM3EVtxhBGwwu3RkvIziA7HO87gbP/qzTz3bXfAgVFgZ57BC960fPxrV/1xbjuhmugu13bVB7hkBvgaq+LDLcTGc++Co4OD3DmzBmcOtpEQGKsgWK327VtF4u0VawcQOw1f+tq2CKbQNWKeW6zdBsUlM0Gv/W638JXft03Y3Pzk9s+taX0ZxtLD1Y01b02ZD3yP1ml7WIWZC29VwfOti1mnrcz2Q8ii+qpjkQHBwvpvPFEswEkAkG6w31d6ng2EPUbeIi4DYdWSC0+vCtuS+p3OBCaB64K6Izp9CX4L7/9y/iiD/84PO7iqzDvZkylbzAiaO+1lTBzwAJI6T4h7A0qkLlXL42uaSO46/xD+Pe/8mPQyy4Gtn0outY2eqMSWSfHKBaES7TJPEt8D+eeBdnZanrrdVSh3eJW9Kz7gWRn5v/dZe8BzMEw1vR4AchUT1Ljlaxy39D02sGDgUZyxLfRksFgKWKZ7R7kGpy2NRK+cLmAys/3wuYQvQNqTm2F6iELcsXwa1H/2F5UF4Y1Pk4w9k3RVgcqfSJdEqSUMtJI1N0OB9dchad+/Atxx9v/Arf8+uuAzRHijUTWBDmcfi8LYxwKaUFOJ44jLuOXxP3Jbbj/IZBXpL6o1UkKqJY1+5wqgarxvvM95oYpYxn9lTvnETRo4FBXFm4pzWEn3pgYOKAj/nHNqrDXvbeLBfP587j+2ivxc9/zTTg8OvAK8kIy7oMN38Vvp9lo7Tyote2SY5vT2zxumeKFA37P2M4Q/DDQWolEk3ZaVIHNhD96yx/hJS//p5BLrwQ2glJnzCoQmTrg5nnR4FnWvxj5MIABBZRI8u1nUxDlOMZO3dWkrTnwDNNwQyuNbMQ0jC+8ZOCjAIBBW0gfeZ/g8DNw+4aac1+yl90C65TJqL2IANCiXn9zET0oc33psqn8vaJIwYXtg/jCn/ku/PLf/dr+vO6MMk3eRnrUKxNAfzrzqvRHeSp0qqjTBl/98z+A9917B+TKK4G+7ac/g6rSNg8zu/bgnWFncIz7cDIYlc453/k6yTAdgvAl1i3igYLdfJfvHnBd4MrKEQFd+EWK2lo95IzGIHffkXJKZDNhXTbVd8ClYsTHPcwCFkzPSqzJmSdrZ0r39YiZPtTZDH1kuJKR0FwIgJOyiNwNVg4CXSjpkJ1ryqpzRTm6CA+dvwAcHUGODhlOILDVrhW2arV1O9oxAB6duFNWgy5bEMHOJAuZLYSHiruD81VeTZPt8aL+B+aEpQNbVEt96pqTI7fexvBiF75orI2AI+7jczavZz4BSc7wfjPIZw3tYKsVqLtG1PYYN1x9JaZNwW63jdeJKb8esS806b9ZF5gHCu3gOrtBTWXCZrPBwcEBNgcbbDax8Mn64R+i1HTV9Ct9ukOf54rdbsY8zxAA01RwcHiIv/yL9+KFn/1lOCdHqKfOYK6CGRuov0IPEeS6qUnm34Kx+a+v4bBiNPcnY2cskEtgFcrA/40+Q6MKd7LLVaXa+yMQGpLzx5NMOqqp3lE34OhrlVuDwSdZ3BJ2x0FPCs5Np2YDZ/XXz6nOKGcuwe/86e/jq371+3Hq4KBtxzlHdjdrew8QpG/pKfFyeeO1or8xSGZU3QFSsTk8wLf/xs/gR97wC5BLr4TMQJm1d4t0V4e/5Eu0b4KRFDDxQJcfY44FUHVPuT3wwRGFrsjbf9Lo5xpppisnZqALrBl+y4gS+4j+qx+DSQEYX0Sw747xeJSIQrkxg3bKOAGkud6xLi8DjdW5zAiJ3+n5PAmQ5WHLNfqsHxFlkaP1yNvKk3LQvW3osZ/pO80koOBMDZJoTnMORgsiChrnI/IjEk0NIxu0NsV7zq+1aLw2nop1Ee6ALOLtTnKRXcJEGPPIapG8SPCa6rA2mt2Jt8fztW67QtSl7waushh5b7dZgBgOBKgB4iI4PrZVwKXTIWRkYv/vyUARjhZMsDnn2F5R7GTcmHXenIcz1AuiBZIkLwZ/UUylYLOZ8N73vR8f99mvxP33n4NcfkV7DtTj5brga4wUrK/uzvyGy20Z4UuSB/PL/Gpa5a7Bj9xfuK4u2d31l4L1mEuk+bBBDyL4It3q+u/xsdUp0bekN4vDFFepTxm4PLO1cv3ZUpvndemqYnPTdfi+1/48zmjBt3ziF0EUON7u7DVAHmRB+o5fBDG2y5WijaRsDgswTfjW1/wE/sWvfi/kyquBufvZQv4kGESCja5xPzPosT/kOtaOPnysVLEnCfuOgCH3QXTW3FFEfkQHA/O+jJf0J5Wh/gktptw7dJyc/f/BYTZEPnvjv4GI9ILy0eqcqAU7k/fM51fH1uk6A9hIcOozByUjJyQDWqtufZjbrztod8VexFHukpNDkv7QnHgUSmW64sV368oaXUNWYMC1xjNXzHA42blglc+w28jb8aMTkuikRRh+n2N7GirkQm4bZrhj+xJ9NucYPoAeZzJ5DA35lo49s1G+1v8VKWhDyKX1oxMltvLY6DRHCYG9JGDf0cgbSij9dUcu6fEAMUPqZcagBQinECtf4UBr84Y+Dy2Ct//5u/DCz/7HuOuOezFdejl0vtBWHUPgNVGQkxXWdENyGS6GoJ/7R54r/nCwKCu2aPWu2T0Hhwv/To7PekUgLZaNDkA5hO1RHtFvL5t4E7xI2/9ZJt+z1Bg2txEp+G8GmAgeaSQMArkwo9x8Lb79tT+FP7v3dnzPy16F648uw1zn9mYhVeygUMyJd2KkKHCwmSBHB7j74Qfw5T/23fh/3/xLkGuvh6AAU2+7L1FWHTtJvFGk0QkPVsbiuviy+jMBcm/XxLTvOLE5/64nlA5dsex2HGIe7xr93Cp7Fo08hjJW+UqH1YKR0nSrBCVCdz5K+2mYo7uW7hDVslj77AGAZrMR7efhLXVlM6J16LkQDTzksiT4ZI65wSiBrDvNNaDvBtSL+1CSRaAadfowd+rfALrkKpTrRERavlLYjbwG7dxPMQpNmQS2jzDz2Onqfj5ohPPdnX4neZxn5D1VbQhYxXhAgApznJRNESh11whe3BWANMR6SZ26dHzURAB/WXtf5Cdt72F7T2zK5qkzSY/ot7di5xFlmP8hZ5JfErcGmcwzhgmXe1usJ30KokwT3vjGt+B5n/L3ccdt96CcOdNeMqAzRPurzFx3Ncu284/xUlXb6trO9favMmO7EMjdSZxrq+M15OPl7Vz8XcSLBNjho2mhmjNMjapEU9RnuhnACpHQlw4oTL+bA/y2ocuDfWoDWszw4WF7ExD/hQ8ZR3/ce/R2CgSyrZDH34hfevub8CHf+iX47jf+Ah6uWxwcbHB4cNBWmEMx1xla20qozWbCqaMjHJ06wv27C/ju3/11fNi3/RP82J/8Msq1N6B0960iqMXVLzbjoJ2j8vB2/IZi0a/YzEPdXPL02qAvru9hA2kHKdYBY43pFOnBAgeAhT1yeb7Py4trJIYb6LvRrENJoc9gD/uOsYsnwOhmWfkAa66xTHeAwSKm7Bqv9v2kQ3XRJWOuN+sOzUzQDCwD0t4mrB3NXYkFtuYxwsjMOi3DsLvM0aj1fbjm5R1kKKImmlr1jCQEXNY/chqSymncT/W76+n/xMuYYzjNPLBn0GYgDIwUIC3Vdli8hnQJ0rdV8OFG83IGOBENBMul16qRQRADjQm90aCLzUQ6UxWlO1sD24LNZoMiBSq1ZQEnGU6vh7pEDpv0bsx2+YbVc1bT6DRMLxU2vy/a5pRVChQTfvInfwWf9yVfBznc4PDMxajzcbsmJQIlqW5LzhtNXfFgxuA19DIAkFmQoMeRJPoUMuBrFKQM/QTG0ZpoxMDSfPXoiF13TA3MgDv9SkDc7g8gTh3bI3rvg4CGgg1IK6SKl4rFehGcug1y/f2BDhWglq7b84zp6qvwwHyMV/70d+Cbf/tn8WlP+0h88tM+FE+96kZcf8nlODg4QJGCbd3h9ofO4i23vhu/8u4/xs/94Rtw613vAC47g83VN8IHcfhvyvCCIa4ZKy/IDnvuUyV+fgVsrJo1n2vg6jxhc2B5UNuj33E6yM8vGEtAm6ujeslfCOlBRP9xJyUpS+AFM2j1sKBknM7kaiypsOcXoqCudyAaiw4sM6u8GnVse6w33U8RiWDZRwPgEWTHoeL9jzhoeGjJNGWloLISX9n1+j2joYmBBtwQhTxXZByalIsgNtVjSsFDsDE8FcVs6DkYGIDnoK7NCRkP09xpsN+vtRXNvEoUXmeIyxydNnAbfHL8tnkScvAKeq6ThoK4DYS9UPhF37pOdOfcHPLUvpeCtsH/pn0nh27HwmmQsrZ2hyy2G844j+7ul21Hhvu6XFasAGZ0UtsCryKCC8cX8LXf8Gr8h3//apRrr8bmcALmC4BM/XUHfaBVLWgKXmeAGQ1aEl+TH3TFDcfUxMMrIQi41+ZFbYtI54m6IPMqZLrusuBVxxr0mD6yLZjeGWX+XftObDHkazAyjrjkaEoRr+PpQDtre2Vdadft1XCpf6A6rB4bTugfpZE3UbRXLd54E9537kF8xxt/Cq9+/U/i4s0Z3HT5Vbj21OU4fXiIOx48i3edvR0PnL0X82lATp9GueFxLdOGQjed+IKWYZudcqIjcS37tNDf7CFHT2fn278xHTLoGDj4VEOgsAvsOyT5nbEmWD8wlCHfr/TbrwWC5z4QCKdWVsqnAvs7sJc274tldbL2PtuuIc0vDZAnGZpWWhy2xTqB5rUODuX8hedcF2dLC0QeejIC8qOQn7E2OzF+JjUNQQyC6H4/aKWTrucdqKLKqCSyVqOlG5JWunf0n3kOzeh310j9CnJ4Mc04mkGAak5soDMqVAgKbKMP2PtJMdRLSeUiCHIf3+kdMtkM8Ar4qlRz/T127JNFIgr04eNpkhTUhitZUQS2tRP0hLMsZwP1lwMHv04VzraCFfQOWwgwNTm/+fffgi981Tfij9/8R5hufhwAxa55WShKPEJjCm3v7jUAXhJGtAz867pov+P5a2KV9YWDFeEC/DN2avJcyftPSw1dtwIMir13d0zLvW6rz9YJBIhIXxxkr75zGXed2js3SWwS+rcNEbeNIzpqLbSGrDbxMhHd6W5dsuF7QOcdsJlQLr0c86x48NwWf373rfjz4/e0tg4L9PQRcNPVKLJB2xYUDfjTVrWsZ53Hhqtr9pYCg4HFGq41ydf0U6PpJktZ8MQqWF0/Mp6SlXKkX2viWgXWNX1ZtJ1rSgHEavmTq8vNGWYuaQgXsLYaWeJLev6OrycsGBB9/J2GNvZFAOtA7EGBX5ds46ZMtPKWHdw457n/EHBLPuySfI7CnuG0uQ/pEXAofOaX9r6ELUQvfOFFAj1SIADqxtMp4peAExB63xg4NSJRy3x9foz4CRnqsABidKyqtE3wuCChtuKVpOTleQFD6IiVT5Fov48XuvGwPW91ExmS3coOKNqdSolTzGM6kiOW/eVCrur6FXNHQcbCsQ86oVX95doqwHTQnru899578a++5dX4j9/3E1DscPS4m1HnGVUFVTcBpIFPLr+RyFg8Z7RFFhE6YPY0jKjQkQCIs0fqL/byIIIADxr5MbQQQPITMSpjMlAkllq/GAtMbYv0N/L00MMdurnXWB+QBjrcjHtZA1rfDakFN/zGzVZNAG2jKfRcgD7M24IKVW5P0d6yrpC+klmODiEHhzAqqgJ6PEOlQifbaEiSj0tQx7o7yCl1lMon1+5GIjFaJFGp8duH8Uu0k6rWcZEU0ZjcQMaFmNJY6vN4fmH3UZEnfDKcX/0uQzksR03GoGSs4qSDXcDGv431JiFxJ8MRrs5fraF7MqT1CIQNaZH+0y/tNKwxYLwhC5OuE2jkIR9xvGSiFLaox7TEntfsBhO3DrREZbbYwDB57VmWyNbME0RW6Vi+GOrQ3GdIoiUN00h0X9K97JSRGBDOiklmT2uuYbUz4dhGp5AYbdVavZo6QObebyEn4jvoK91ny2sEk9Cj5KlvuSurvx/FoHjuiCkM1vZzFf66NqBls5up+OYGx9stfvRHfgpf/R++F3e98z0oV18HbCbsVKGl9OCdNzxJapxASqyPSVc6kqw+RscOOTuh/CaODogUjJnOmIS87a7DLjmnV0NcyHa8onrAwEula4SfBDCZF8GuDOS+KYXfPHxXALM2oJzhm1r0bhPQItlx9GkACx2cs9J6CW2OfRY04E38iOel7a1CXEfiV1RH/TGCk4OIQM3tqfecbWoYPQJ/VaHg16gg3tX+8UrZ6VpV7Js1XQvas+yGrnKxfFsP1B412x2653SZynNylJ1sl7/1rdu5Bh+auSmRYMPIQz37CGkVUqfGIeO1jGFUCqGhBw1yV5VnpMfP5XnaNYBdgnoGJY+ixlbNY+jKfR7BN8fpz0LSzePKOF6dyFF2ClqMHormeV7VHKfrutKcrwUBpq9kWxbFx2IlUkJN6rMaiY5v6wmaopQFXJ55mCNlQ9EVeWj0M4w1+hkaHXR63zyV6QOVHvB0IkRh+8na6KI5eyfOxDlmctnbEaJh9WjGKSAPNjiSxqN5nlHn2rZtOzpEKQUVip/82dfgX33H9+Btb/pjyKWX4ODGG/qr9BRVSvRXbNWwdLZojG6QLsQagSz7WHhC8kWWbwCqyacJNJ7E4lGGkFsuH/bJc+/cUJtxCD3ywNLsg/oQviIa0aF/Jje3Lc/q2UYG3LG2FJ7FpYsXtr7a2EBPoP7mrGy7/R7TfQ1yWVMMl8UD7wa0hkepuKlTjfvDwQ+dIazj/oJiJZOf/9GxQW/Fb2zFPXKLgDyZMjPV7A5UKPvWVZDF4B8GfYu29xgh087J2pC4MQZx8Mi+F1wmejW0Q9MjCwpklQQF1uZstVdHhpLrip8DsCXFX6kVgC9cAJfZy8T9ni6tiD4hc3YX6GH/snYRu26K42iVf5s19XPNUNKbJU8IQIifNMxhRmkCHDNBAzAgZ59JUa2FlclZd158buRn+PB8eig2Pk4RxpuN3hypJDoq7HEXqiC+OimaMug1zWDn5ijv3krd46mv0GQ+rHSs30aY305RZJuGtjnDC4IA8CI2G4oCSik4PJigB2094m2334mf+oXX4Hv/5y/gz970x9CLT2O68XqoFmz769HMF3JymezBRpQWMUyMhjj3vOujQ5PMCxMNBmXwahRI+6aTnZD3McfopRhoNWzCfR50QVrCCL9gtjH2hYOKgVNDEB82N9iP+wcFpgJ94Bxk7huFGIIaeC+00vRqoHcs05MP67OBPYAeL0oub8TO2jesIAfMNlfjLvYAbWV1L6aZuDEQyUzX1BRc+yV1lRd/QkEbEA14a+fYBMmWRjY126FzIxAOx0nXggGjrodGkNZmZ3RiveunF3dL/AmwVfqkk/sbz6sC4YQuJ72XQLPouDluIDlbd9AS9Y6ZXX48ZoVOkLKlvkWJ5D7ICCS9TYY0yx7RsE23Ff3h5SgbemxQ2vmZDJ0yub6DDDiAcEwJNHAlj1QCeei196HfLAA9nB/XWIV5mJdXfnqbgGc4Y0bqq4LJkVrW2e5jZ1upDhO9RjltfMhZERyA0hyvGgXmVUimXS4XdlvYCItaPwmzWJdcPG5+4Vzb/DDpXOfHuHoyKCgoBX3TE8Xtt9+F177hzfipX3wNXvPbb8EDt90FueQSlGuvawt4dxUzgBmTZ25A07816Ak/KDHFIS7a3C9QlkfyS9ZNmTL7cyEdE5ILhANceH1BD6njYhTGMuS4F1RWa3+rVifCR3W8m8OK8JFD5o+6RXsWHSobdSMHsVAAmwPg7oeAc3MGIQ8oOFEYzg22bdf8Du2+KKJmp63pFGVxKn20ps1Duy1T5GBv0zO5shtQawvc37hmF1LgyIdFetLoQol+ytBXr0BZHqNPtkDDAkXyOUISS8HZCnYMNef1I9Rnydbpc7lrgbes0RtFMrycDMjiJaQ/hdF+bUTGinohQUQyySojzrHvY9vky/qJDMKroCuLu07s1HIolRz9ojB9uFqhD4dsDiKmqP1m08m+P64/ND7WqVyN5t1puFCvW8LkU//Ce9K9rpSaAggd+0Z91x6xua/xYTsGLnKyDuoZWKKCsNQFx0nG9moyId6G8475DHe45oEROtKnjyJgyV6ulVU6o0RmmXDnAw8HD7vzGHfY8SHHfrothMmLJDjLNbH4HCy9CF5UMc873HvXvXjDm/4Yb/uL9+ANb3krfusNb8bD956FlgK57DKUG66HSsE8z+3xEhXSOOsND/32s0tzWzHgvLiDMCI5yRh5oPsLqVyXtYgsA4tF8Nrr0dCfgSQTNEBOcFxMFtMSvRzrQ2dAnnPulTto53nI6PygJAvaqV+bA+CBh6H3PAJcfQRst1TjcG9PBoIdLKCwE2U782DeAnIGRAIqXo/g3TcQziKQqGbwLl3OSzMP3zAeg793wmqjyZZBNGAj2zV2QNrjdhjqSYekdjiIW0xBOB2BeitUMwH53rUEL+GOnlDhGj5a5QSrpqs+QrK8aZNuTg1SNJZ7PBhwNkBFGIxRypGG3YbBmBgtksORZezqkfkAsoss5bEeCjKAPQXISBrQVn8t26Ku9FX6I0xwR2FKGh0KwFkomgU9GmVCRwlZiC/mHCODCMt0mqydoV4nifXBZCjBJg5srGbDYRvxiIyXVl6zfJk+ot/n5NWJS3QyCFgq5zZjulAr5PAQ733ne/CTP/savPRvv7AB2+hFFFlnjJc2Nxocc1mNdmJkHh8f46Wf+UX4k3fegYe3O9x/172oWqBHG5SLTmO65ur+yI+g7rZQf162uHxieLEDh+lXodXFQETnDGIst0IZkvCwdwRSXQTOey9vMjNZEe/Z9tJKYQnA8amAntVz2cHDIh2OLb0vo9NvgvVO5qDfWg7/sqbXAXr7/ayUAj1Xoe+6G3L944HjC9GCwB9JTF1wvVD+EbahVJh9zUoW16pzmIQ7XDc+anIlrgl+BE8A8zkWtAYfFiNcvc4E2p7lxmiVJWScqasCUoHTh4ce2Pm9EK/fQqhFsjKArHdXst+IQu48h35jgU3p+5jlSuZ/DjhWmEw/l0ke99HmhIFCSUqqaVTSdJUxxkHo5HF179jQaV05t1rGBOXdif8ybUb7QE0EIeR0nLB+0pfQIRgShsGy9UtuYPGx4EbQy4r9Gusm4txh9evS6DIHKwKMdCkCXEyxjWdpo4NBEa1s1Mt90qg7tTuUQ5TLjoX01D11L+lDg4mSHm1L5rODu6PBwDIygM4n3utatGLCFmWj+Pwv+3r80e+/FdIzybm2t+lo1dAhF1j+nDhFIdKHQtv1w8ND/L1/8AW4+/23YadHuPRJT8Dpm6/HwZWXQQ42mHcVc1XMc+1PltS+NV8bQIbOQK19XQPluaKx1qHzJvGdnY/7+ghGXafSPaNzyXaXHumwAACxRiE9huHBUisrQAN7Ib/WddIWo3iwDYSuskkK3Wd1ml0EVUuRpGIuxHRd/Itdk9BJ8w0Hp4B33Qk5ntvJYs65Xzd3gdC5WGVottH7mdyKOu89I0wqPjr13lAKTDTEVdmrKFfnHbb+qpi/IP/iiwqtW8qtZB+t2ramnWvf2rG97ciuCRRSKw4ODvGB1z+h90mc3kQMRwwj0KW+O2MI+7L/MDBepPtMd26V+kiy2HuM19ZsaayUvWPjceE+LUhZJSA6kIQwdGy1Dgqn+d4EuIZUmu/lOZrxvwHrMiaNHJaoT1PZkVvW11wFm23sIYrUd8++SJ84mHXH0X+Mex37ymECz6DXeNZ50Wn3LHXgr2hE1WoOnB5DMUUY1Kc9Y8j+FoAtNbZ8QoFUP3fW+iu9TIB4BELt/nbdsyWXDfEWeY7R+6NMd9DUbmn9LAcHOL5wjI//vFfi7X/2TkBKA7vhfqd9BWj540Wla59kJr30JX8T3/8D34H5gTuwe+Q8ZHeMMu+AOjfH2D/+HKdWSJ199yjxQqbvY1YU4Ob0L+w3r4p33Um8pQwn8b/rTbLBCL4TlyVnup5lmv4iaF7qsvp6hzz8q22Tj35PDGzw2ozQH+pY2JsE6byIJ5x1tsEUP5rjPzgF3PkA9B13Q46OAJ3RRiLgfPDV4GRrAUqI/ZOtr2qiDd12i9CeAY48Gj6igFTESmnV+N7PSyU6xr4DHpQqzCWTd2N5kh+x9SmqGq8VrL1D1kco6vGMa85ciWde/4TgP/OXKFlk1KRvjAdh0xLmKZFmsV/10S7Wi0HHWe/JgYMPxpWVEIYiRDqvQj81X9X+ZETOVryPKSLcdzAZe0tzPR5NnlDGM41czh01K+nIBCNkrYmR9vAFqZV0QjIPw691h9BBKTl6ZPk523sUza7FDRyUZcGUVLzX4RgktySaaVPuqETwYl3zB/7DAS6iuj6pP9ph9ET8YX+Phr0NDUXUgZGA72bnUf8AbgaurRABnFB97lT7cHiXh/A5bcOzcwXKpWdw7/0P4mM/+0vx3nffis1m8lfjVa2YtZIzjzoWR2KTuHrWqtjNc9sZSoHPeMnH4Ju+6Wtx4fa/7PsiaKenZbLaF9c1R0UIbE4bCmEZs2ytdaPRZcD8HhwHgbMFCO6sXM/QHS1iuJ7OWSP8AooEotSsDobFVPHWhW1EonrzYyZgPtEBwX1o6FLOcgaZjbpJJU8+AQAF2JyG/t5fAg8ZLyoVNsegnS9If+FBqAWU/XunO9SeAMTqHf2xgZD/JYCv8UngUXW9bfu4jnMwidAJ9tPcJwP2uQKzvcdXMUPbY8mPbPHhT34Grjg67YsyfXEhmXI6Mloi/FYG13yPYuG2rBq23zW8IX+9sIGhXCN7vC4RGPH5cW4wXRUUjgZTC5C15uMsC0RksWvHUqFzp9ecmbuXlUxCqQAPfYxg6xlHUtqVdnqFeUDOCYi/gQRQd+wFdXsM3e6ScbVPDSDx032Ic0R3pt/KgR1dqyfKDMMdOvbdemSgQcZn5dmxGYCxk0zVa/qewhty4AaMLSMynvGcGc8fRr1xnXjRwc5iE+OH2aFlASEuDb2iEQGFoOWJBfNuxnTppbj7tjvx8Z/9pbj/3vsx9Q0lPKsILoY8qL+WhWAAZauj1oo6dxAF8H/9vZfilV/xj3D+9veiagF0BuYZUuf2cvs6t0DNN0jp37v+RB6pGWgXfiOgjINP43cOpHJwmnFKQmeR+YnkiNnv54zZ9WTUm8Tf9e9x30hz0MNlm9jZTokGrl+Ztsw/r3XMbKze6TRw9znU334nytFptBfHAtCCiMC7zvXMUqu2l8PP6BtjWFbbbZle0uS+QQHYqyZ7neFSNM7XaMcyWH97jwFgrcuMVxEjUG6N5NfQ1w1IX+thJmD+CCD6tU11zP2zs4y3NS8XzuPlH/oi99VtO9LSVuUj1u8Y/0UN8AnUCFMaa2Lth0vWRjiSbmEZKPB5vznXkwKQ/p8tCBTIoqrQnf0AvQBp6RtuObjKesV8JOe2uEYGwecphc+EEWNTRStlOQva08EE4BJU+LDN6q0rQunOp9uAexnLOeTwAPPZ+3Drb70O9/zpW5tpCPXeG+p3RJXtoumCcncI/IB4/ZVFhdRP7x6a8sdUkfrfzId+2A4PBN5j8zL8XjrP3q4/kqKIbAxulPHoki+TSrQJNdKMLtq34UOve1/QRFnFot/uQysKKmR7HkdXXYFb/vIv8amf/xW4cGHrLyuQspLJSrApGecKHUUKpjKhFEGtiu12h+12h2/46i/Fp3z2y3B8160oAmywxYQZRXewbNaG4jwzCS+c9Cg6FeTZN+YoP0LBiQkLN4A8rie4UXM0vWa7IMQKC4BAwGfFJBa6ZYKDUnNEHlhRESE7YJtw2jzQCz32KQiix+hz2/DtI/f63hy4AcCpM8Cf3or6plsgF18M1R20aAQkasOSvQ0C1sgqdWAwPe5nv8lJa2+fM04+0kKq3oaaHZhZ1jifQNN4ZI/0uAF2ABMDXXNSAz96MCRzxeZ4xubCDuV41/pw/8P42A9+Ll78QR+K7W4Hmdq+35MnTmMIKeELXX+pj5wkUCAVbOw3jwmIfVgnuXxmZq6Ty8eNy2srWDTWMdY87GWXW1pzLGvn+NqJ14eoZry2FhV7+QWQLs+7+wg7oDrWHNW+g9GxgywHBkUgBaj334/5/rNAKT6sE1ltBxhe3GJGaN8DXZx+y4BVdKAoAMGGTrWDOfPNayJazOGkflPEHEDd69dwSlbIAhZ2hCGzyMZ43tWGgRZZCzmAwP0wrMh41fmzL2NCB/5Rf9g0Ref28r/dBRxccx1+97d/F5/3j/45VO052HDeld75uZyXFXpwv48hiPQXHjTgrlqxm3c43m4xzzN+6Nu/Hs//+Bdid9f7MRVBwa6Bv/KH4M7llQGXM9gcjPKQs0SfCUwtmPHvVqrrYMzTUjDWPcr4tIC3ldSTaPcgK2TrOjPoTSCLkr0Z0Ee1oTfRDgZdCN6EnhsZYY/IOpL0v3OHUU8EIhNwcCn09e+Avul2lEsuBfoT0Y2H4vSkLFOjz8031JAVCUPtg/juANR5kkY5iQesN7YrFRS+13IK2rTrrJmZaVQBtDSfpoL+hqOeaRZAiiUL1G5VlJ7VlnluAH9uxplyiG/+5C9AUfS9vwUiJTJbIR+N6KtaxOAxy9LOVxM1+2p8Ua7deBoZ8go+LqMuDnqEfFa6J/7sT07ZD7WDXh5PwKVYNpDrWJ7WFYe+8hsr9TY9Xw4dp5uVT1O2p/maDzMqoszKMQaweyk3urriQApQJqBMkKMjyNFhU1hSxnAIARqRCRIPFP6ICbvB9nB6dnI8PBg8tHuDCbFyE5HxCfFlZG+/3wDOHUA3zDSnRHoi/JdISBlON3iP43nrOf6j/Ju8tEmQlNvrliEAG50vGV9FwSyCignz7hgH19+En/mJn8ZXft2/9cxqnmdsdzN2ux3mSlvypIOHaWlxHtE0lYJpmrDZtN2iDqaC//W934qnPuuZeOSuuzCXQ6gqCmZM2KHIDF6ualDuDJEwWuVLQ5+dPvKvNj9uiMLx20LbPZ6gLMQAdihsupCuU1sioXvUPHx4lulP6D/oT6DgQK+mLSStnNp+vj4XbAER4OsBJGj35yKHzkmRPtph5QswXQx97VtRX/dOlMOLIAeb0LGEmP00v6hdGyg3uTCadn8i0l5NKGsfgUqBvyC3f1p9QvsQU/vobfH+xOZr0IeMQW0U+0yQUoBJfLSn9HdEF1VsquJgV7HZVsisqALsyoQZBXjgLL75pV+EZ153E47PbRu4DkFRBELhB3nqSsfyw7EvWdNcKEMCB3lcx5rsvXxUfAI5QYtkXffIabhWnArhinX4yxWHIab5GCKegoOVexERCEV+MpRjR+6LOkxUHcA42/PDFS4cY1S87JIDyKKncXa5IrUbABsTGb/N2y4yrgVdJpkOsuFbB6Vs/9hr2UwppTeXhl6sRvK6zegM8BjILDq2e4cozrRHuyxIceO52ZBregYTaA7PM5gO5BylUsZh7fkAkzS3wPOCfI/pYdKzpJOROVcUzNhgRkHFhFqPsbnuJnznd30PvuXffG9zvlVRbZFTHdpEgKtAqH4bPQhRinSwnQqmqUDnGRedOsCv/vj34JLrbsT2/geBadOybWkvjA/MtiHD4KcJNL4abQM4c7bmRGsqF7yKf7MDMx0NvTL75hENIzhALkZYXCfQM/ROa8zXsb6hl4854Tzk6cY86Lj0LtMFALaXt52WuODXrX/BdBoBkPwlxoQKBBNQLgVe/w7UH3sjcOc5yKlTwOGmVWV6U7U9yVUB7U9zaZU+axB/WwpZ6G8HbOSPokD7HHED2BL1eN0BunYec3znJ8tQBahRVwJxjwNaYiFoI3ZF2+ZRZVZMFZhQgM0B5oMNdvUYcuERfOvL/zE+77kfg0cePt9ed7iGUqbbXcEWZu3f17PZNIrJeusjfUB6xesQgCesons53uulU/2rmfVq38ZTLFNgk7MKHe5chyBzCh4dpkvD/Gs/5x0nQA7GJA+BpP3EhRE8GXD92ljlAvFXusPpAN0cfZPEEnO4KFOHLAqBvKtDn6xew9b+xYMO6qG/EcQ6bzsxucOT5jgQ85mux8Q7jxQHMOZIj3/HT8uuNcgdypsD9uUWLGNqy+43g3DD8ACLF7MRrd6n7thdvuKgnR7r8MBgYLd/N55VSAVEjjFddzO+/t98O264/mq84uWfirzwSbPKpmGr5aM1rp3E4tr3Oa7zjGuuvAxv/PkfxHM/6e/g4QcfwXTxRaioUEz9cc1iDSVZ8NaloCDD+unZpcsNizpMj9T4RTrBJcA8BKvlImyNw7EvGM80wUNkusXpNB1R0nk4YLsH7cEQBG33Ig295xE1sztZyCqFF7FZRrd57zu1q92vuExqX95ydAXw3oehP/JG4ANvgHzwTcCNlwKnAD3eAbsdsLNtXDXaGUbs1HRqzQV2z5Z/M8NZ31p/htszqIigCpoyaYl3S08NkLERABUolARtFCITVI9QbH3BbsZ8vIUeH6M+ch6lbPART38OvuWTXoHn3vAkXHjkPDbTFLHC4pBgNkdFCL+ANUx5DAffnzDG6mR+xE2Letb0/K9ED/U9pNjB1k6ONPjcy7Jlt8LHSoR1lOfxGjWEiOxUWCDs6NwWQyA2b8ZZL/Vv/2G2oICvIOYdvQm5eJW3aIFF49juGombKYGo27ENpVCTgZcURThPvRcU2SPaw1AcMUcm9oYYKIsoO+QB8/MRF+M5Scu0cqZnSkRLUlZkGg0ugjLPiDttAigNu5hz520lW7UU5DGf+iNCBnoOhgTG1u+cIc3YXH4F/uGr/hmuvvIMPuVTXoTax7prbcphL3bP5C+DCv7e/Ih6UAERzHPFk550I1734z+Ij/rkz8T2WIGLTkFnewm8dhsZ7MpWpDsPDchikY3PtXu/R7uyiD7sZRwCtkDI9DCui8vDdc3qUpJhP8eOjUyiUeDyzDqRwKLrevJJ1V7czvcPouUAYrjmr1wDSE/H+wEOnI2jadjXXnO4uQioW+CPboP+0fuA688Aj78K8virgStOAac2wCHarl/Ol/ZbJjEH2xcsWptwWTmBFoh2fULXb+yZk4377HbpwN57XYQ+behYZAI2lgIrpG4wnQc25x7GfO5+4LBggw1U2kr5zWaDa6++CX/t8U/Dyz70o/A3Hv8MHOmE84+ca4sEUbrN7MOH0PV01fRhH+4sjvA6wr+GxE7oe5AgXkPyTXva3YuFJ1IXdmnfN0wsnPT9SMVllQxrcX5gOGdViiwIznKY3PijmVl2XnLRNbKN9/sDAyHQzRXrWH83DNEKnWccXHE5VBXzAw9ApgNEhN5ukj3y8Qx1r5ANMLirChvOdZhzoM3OSbkf1ox7W+1BA4inNp9rC1OW/A4Hu4w8W3cIQFf6G5kuhxFC32nhmNcJP+clGTxc7hwMZMNwA+z86K8Ah7m5shGUa67B5/yjr8YvX/GdeP5HPRe73RxBQCmYCq0jJPmyf/NfGm0WAGorwEtbPPUhH/IU/NKPfh8+4aWfBz28FmVT0IbbARVFRYkgg/rLbbttEe9MZNmBDYJY2GUGv6iTMoGuRiybGGkhq+eG6fQwWLiwUeFrHdSybGH4T91oDbDXSYu7uE1TIg+EiAfdnpdmGo012yqAKFUjQDkAjg7aZiV3HAO3vAf6u+8GDifgogPgsPQXk7hCANPUN/Tv11xgQp/wk+i9DIYYuNJUQgJbAmSOKhjcDWj7XK1Kae8/6ZWIAvXus/jyr/sqvPQTXoy7HjyLU9OEWoDDU0e4/OJLcMOZK3BROUCdK86fu4Ctzpim9uy6zXXzosLEWcJCPpT6LPR7xIp0w16XvgTW8fe+gPnEuoa2T7zNi1rw2F9EkG8alHWlnaBDQvh7Mt6xUwvw5XoGp9IvLs758OEIskrXBn4HoA8HzWu5slKEDyDNxwqAutthOnMJnv7xL8IjZx/Au37t19oKRDFCxYeqAvhWsHVwnoAmJ5hjtkafuoMMfltkzHOmEUC2+RleOGVoqx3A6ewQmHSjFokAIZWL66MwxHk7RIUeHLA+dIdBsuNhaEAQxXgxF5UnJ8WRqveO9LyiQKCYbJepTYHW0/jkL/xyvP6nvhdPe8YHYJ6r0yZo/ikLL9OZ4nShfkosi5gg2M0zXvDRH4bve/W34Qv/wT/CdM3Nbcqu9ueC2XZMJ5z41mcPsJR4bulh36je2elYGHo9rp1I+igBQga8rH+yaH/4jgyGMa9qOpp1jNXcsu6BjaHXQ/sR2Fh3VkCWbH8xDdUbzxNfPHoiaGOuMyClba0ppem9LaIrmzZve3i6P/u6Ax7o23CGgYeM/LsgxrOpDPmLfAxOw0GWAJbBloXqzVi7BritzaajChSgTAK97yyeJlfjwx73ATg+nrEpgGrbdW2uM3bHM87vzrfu26NziBdytEfqVrqAjAEmc++PlZHgCQMvVyl8D2fJNKKyHnSv6Infug7SIxibmQ235z5TQGd1bJbo3Fey7YXtcOS5UuTJ6cdyDCl/on4RkfR/wnus1PdXaZvLD4p6QrAhAFAryuEpbFVwPM/JAbpDYRuiw5zLPlJ5+M6dTS7h5ZYYZ87P2uEMpGe/FJik4MDoXRRoxmqLprmPRme0P34lo/EoFXE/O9be2TY6IEGbZjfp95sS7+Gj8YGdV+NLLEJSCGa0IePp1BHOnzvG33rFl+F3f+6/4drrr0at7fWKVSt07jIh2akyv8YuSwCXxoKPqRRorfjcl70Yd9z1L/E1X/cvUG54POpuRrWh9LFXDFIkfw82TPfEtYMAOmq0V/EpV+xE85wX0miJeNBFdTN/V3Q0S0eJZwQww2EO1AMFqoKD9OxokZ028wvBGwdPBmYOqk1umvtolakqMJX+WE9tQ7CIRWEA2sKgsun1ZC/sc8De0KLnw7HiKEafvAAN82NY+U7tOPAO7QmASaAy4aH5YWzniocfOYfN1Nc7uL0Kps0mgpVeVekr8W04OMlsBC8JX2I82ncYUC4Spj1Zq+nQ4tiHaavZ6wkYEGxIRVWXVbnfhO2NnC9TeysNamvFVhB6g50KISZzPWt1mfNOK48lnotSoD8nZbqkUZ4+Cm2vREOsRH1sBwmHI8I6vpCgnR9X46oCUhH3pihNMueVFtzwvxxwIHhuc36NNyHF4KMN/FB5ujcBjTn7ThrX0WhAbP8mMXypFj0bX8QMpfOaHNIIEwNHyNwjQhDmK9DeJGKl1Up0J+B9ippbkUHW5ECV6aE+CwBRQdW+w1Qt2G5nyOmLcOed9+Ilr3gVzj1yHpvN5Pe2LRdr8JE75U3Hqvn0V2JNAQCUPrT8ZV/6ufj/fNkrsb3zdsh05K8lMx6QezLmZVsyXlhgIsZXCf0BmqPsNSrUd6yKusJu1PvbMzch24B4EGfyYQdg9/pe1yZnRf6N0O9ln+g66bPr49BvrtfaTzJJUWD4FgdQIwhI/sx4GrW1FbpWR+NFl3HpgY50f4WWLfqHgpngsfXR/vKTCzXkwef8vv6BrLe3+ExOR2q773HcdjObofMOtSrqvGuL+6BQ6Qun+rB3PBYlnsmW/j1eNZkXl8koYxcWOmaE77fMew1H9v7ytgb5M7OGOxlvPBCkj2MC6eVqHdnF06HppIhgbTIqf9f801dqQsPvUWtpYQXds7Zq2Yk5IYoAO3wsjWkfnX+1o9+cosPlpzE/tmixRR9SYvk8Q08C0dSekCzMu7SPmOMcQDJFz4Mg03BiB3lzZFxfRO0kP5ghhyswQO2o5O1FeTvF7pPnmFd46OUiwLCuQ9C3LlyK0IMRMyb6sG54xsnhZbITAwrvpfe98WYH3T6Mwysuw9ve9uf41M//MmyPdyhF+jQXOxAiYny3e3STnHjb+GIz2S5TFdvtFtvdjH//z74Un/Kyl6LecQsOpoINZky2CYeaLg2hjAU945H433hhztULKNFn/B3uj9/qAUOkimP5oCkcpp2ygDzkn8DPdYP0S4a6sJxTDu+4wgPL8Em34kfQq1YW1JY94iZcV4CM8Yt3Hlt7PlbsuVVp16WUIMZ8oQStAfLq/Q1aybElu3TCOx3weWDx+eBC88MlAVnIaN3XQaUDbgdzBREaYFhKA9qpg23p5zIY5Sw3icttGF3fTGQZnCM4E+eby8h4oyuZL9ssn6NjoUXUVgxp5zvUaRxv9oZg+m63lrESbnpxqTeQsNgjr8yYRmsG2XFF6okg+xjqf7T7Ti5Af90jaf5rn1qxVMb2XGbvGTmiDnYkCBv+yH7anH3wU4R5G0DAGUgCE+dPa9uqSgtolHJQrX7OFNOi3GgzHJMPH8IMJaLrxLv+3cHOrw2yG99uZPT1lb+2cazzy+i06JNoS9m5RkZsmJCjUnOUQa8mGde+wlMxH5/DdMXVeP1vvB4v+byvgFbtQ2McJOhoKovDM1tEFlCK7TKl2O1mbI+PoXXGj/3Hr8fHfPxHY37/e1HKBNFtewsQtO2HS1GDiEA0g1aWBzloCfkjydlojJubfgZPeLja7+qAEDGOrd5PDiF0hlic5M1tpDpId2jEx3SfZRxS5OxzEIga/cQvosVzTW/a2ksdxvj8q9hjWlJ6LQZm9txq+0iZ4rqBHmxImeZMrS0PKKk92oPZAoLwM7196fV5oN2uidMz9SBgynRKoT617kv3d6ZKJq9xyNcCsNKDCSnFd2Pz2AH8hfBg8BtJbGsgS3ji51PgG6NNmvQ56OTrPoUgMjRNyc0+3ILpB3dg0dWgwTRNtW0Pwil/RC0YIggsDhPCSUPHjwUYTzpW61+hZe04se3Vfg2Aa5EmFP7E+ADI7tQdZw3oxJ2dC9zKaQzzirdbMz0azj2JouOSz5vB9KIPAYtG/a6PfcGLYKG4QjSjA8QYUDvLzDkL84kcuq8a6P0Qok/D+bsfIc+n5mCdCdQG87iOhtdojs06jBdRX/Qx9DmZmTZO9j3WUXfncXD1DXjdr/8aXvx3v9KDlHmu/qn2CsI9xx4WtmRHeJcpwcFmwi/+4H/AB3/Yh2B3793A5hRsK45J2vaOdnOul4MIVwznv8ncdDFnmUEnWHZeH/XCEVOjzx74ZL43MdocX9dr18OQfeKJmhQDWH0qRym7pqYZmIfxJNg0im156v2hwNY7b77O+DsCLflD8awRKav1TNez3cgupQNhmlKwa3yOAjO2dwEFm3xeRlaaRpA/l06LgTGBcquTdrDy2tr1qW/akwXV+dVlPFkma9ks+2r7rgSKqZ7l93V7WccXDuRPQpgUdA/nTVdz90asWaygGCkcKo5PG4a3cFBia/oTK6GvPI+QSj8GsJXho3s+qVyKlvp/FHEZKC2YpIsvC57sdZYWSavNJ8ZfdzxVUevcnK73cU9wouEA3ClavYK0s060H7Sbs7CAzOpzZ0uZKrgdL0P0eRNZLu3v6NR8lgfmKJuRd9kaeDroAgb61rb1L1ZDm5OMLJrn63qHyD4UijbHaPNIDMD+vCHz2UE8Vm2Pc4KtvzRfDLQ5XAVUBfN8AZurrsPrfuHn8Hn/8J91kVfMc5O5DbyP4LHmMMajlIJpM2HaTJAimHczNgcHeO1Pfh9uvPkm7M4+ANkc9j2dq/fH5goTQFhwxN9d5A4/7rSBAD7WyUXAlOw8RlhChizHmANuuhFzjl0M/tu3EKVgzYEY6qDoIx6JvaZnkV2LBWrWX6WgMvGCbMp0x4JL03INjGLwan2P+VHYX/s+bGjM4BjZo2WTlGULhQlDsuOHBenjoSQFjSkZ55jTGPPMNrcLKVCU/n0C+pxu6zztjBdEJA9ifPM3+pQcTACBB/7OX5j/5i5o2rs4dc67vz+ZWz2s3aHMavKnNIrm/VrizhpYr9G6dsnaU9jbkJPBPsrB5faAVUrlH2O1q4cxOIFPGIFF7Ov3nkykrP4II4iDgLF/twULtVbUOhPGrjFRUv0uQFYg6UY9RmH0lZ2ADhOFMSQNd1Yy9EcWfAhjak6LIzw2GPrwY0ISSsn8soVjKVo1Q6fz/eahb7nfOqDZQp9EWuS4ELGE7yan4YpP9XfOeTllsNAtDq+/GT/2Iz+KL/6Kf9Xf7FP6PK5Y6bFlIn6pDyLw+wXNkVZVXDg+xqlLTuG1P/5fceb0BvWhR4DpEFULqpSEF4Pbaf8usrLRsXH/ByfUC/BbangjF+NLOJ4cJHmQN3bW9+IlImTJG15z0PRAklLEIOHy0BV6gNBnH2Hy84RrQX0HiwxWYbvi+m7dcG0U6XO0nec2X+pztRLPt1K2OWaeauwqkl56AoFn09yB/Gq4PmRc7G/3jqWvDC5TPz+1oeQyQaYp9kSe2nkpm3be+AY0YPa9k4tfaWS0/vLLPFguPl1gMl0X4AqYCV3maQe6h0uPWe9KG+zJxvsX2sW4cyLQ7q1hQVsfR4Arf6B/L3jCzeP1UdH5mmeIHC2dxCC3iNEJRv8DV2zepkfOkodkHu1YcYcI6+QG+dOy2ervJG3nfLEBOIKiOQLOrowfjkA5+1qfo85zqm1VqXpUHnOiWNRp83YMgg64Qn1FYGpeGBN38erawEybA1a/Jzl4AqaYR0P037s1yJzLQIiFHRTJFVutNg3Iw0zpu/FIGGhbfU1Hbe4YmOuMgxufhO979ffh//nGb8fmYONOkIE6hIV47IMRMvWj81Dgzy5WBbbHW9z8xOvw6//v92JTz6Fe2EHLhpyFZY4uNLgQjBrLhOSE/rPNuEMx+9QARB+hyLJxebFqWP/MKTILuuKZo2O2sL8BaPqj84jdGLOZwU/EHr0DYvU0FgDsuk+sc62kVdfOXpOxsO4NAYQDTQMeH8MRA00jdvwegG7gKqX4vW3DCYFnoOjnjB+eDfZ7ezAcmWBfGewZawNZNfC0Odwy9Wub/n0Dm++NbNXmd+ErkfmjQHznSDaYTDoCd977pxoz2MLLRb2jb0+ZKDdG5XmIexVIOepnrDLA2UPj2mF2FNN2/X01a5CDfWcVDmajM1kj/ETAW7nmkcfYwfC3ybmAvypV8ug42+/dQz+YBANY2+27G2UHOyMhvHgngSMqa6dGebNdM3gxJwfNfEAopg2jt4gxD69zn5X5Z9/p0Zq1SX8eFvbLxncl5pJztCHedokdczhMc8ypGu8Poj0H+VQw64n0+WeEGozD1NLf+uJ3JcMfAYEMzJwkitcmWiH1EZy+8Wb862/59/iu7/rvmMqE3VxRtbZHJRzwG0Apow1Cds1hW9BoQ39t7msqBZvNhN1uh2d92NPxU9//auiD9wC7GUUrNrrFBlsUnVv/mNEdH5vTpcUsDlzLufOBxFZNqk/8LTG874vLi+7POS1/t2H64K/BbviPfEtaA0E185D3cph14IU7TL854kmIL49IAVZyyiu8oUCggdow1ykBsk4TQGDXga/YYGIJUKPFS9KB0HaaiuyY6+l2b6uQoe2xuf5sSXsBwa7ZQIl2Lfv1N5dNmway0+RvMsPUwHYqEwRt16MJ2j95VG4cMk7fk3+h68N3D9vZb+7DFArdxhElImD5ewTmPecDd1ihrCz/jD5y0gGnSxdlFfveZ3vSITGkEkqdowQe+x5xkDtmdXBE0nCEOt2BJd3/WDLWFRBdxE9OdkLxxU0eUZmjdgOtbqxusAQU3hfQqAEoUuO+UlkvjyjDztrB0hxnAkcCZ+ezZUThUPyvMK+s7mA9Y7gNdXM0upZ1q9YAWeOqWh3I86xEdpYZ6RO6Y1wBMeZ9BNWaq1kLPDyoCYcuNFccM78VojO0bDFdczNe9U//BX7mp38J0zS1hVLEjzTPRbwlihPQagcOX6lcBFMR7HYzXviiv4bv/o5vQb33zvbmFcyYKs/hGuCaDZLZq/VAQn9d/hp6b+/r9N3EMv9MHUd5+5y9M6s6LZYt80I9n35xecAX2UoPEBb6RHbBMkoyNGct8H66cxv1kuUvuU8Y2ucRpvgSztkeA/LM1KjU+OvzpexbfCigP/Oq4qAbZYZX6XkbVN41IC+Ys+ktbArkmiuB00fttwUADvgTVGxlcstm1c6VNnJjj/FMRbARYNI+Go72DmiQD3HZiPmUOCfGFzNViXIJqsjPjBMSYz+t3riefYJzj3Gl9z8P0Q/tsN8QrAMyX060MD3xl33SYwNb6iUzx8/sIYodzzi31ylIwLTe5FoMo+tMGIxoDXBzeTIajlKtsrUjVZlCBLgz5Utr1ZjCgZRmQasmsBIqQ67WAu3sUDDc12W0mAJQ9exbMYIV9QnEzyEmWVslyHV4gDH0/6TFBxG05Dp5pMBuM7HF6JCG0RugSNYiu6QAbXLgrftfBVBFMEvBrgL1oECuvBaf/cVfid97w+/j4ODA22nz99UBlNuKatcdRI5o2spOVcXLP+cl+Jr/+6uwu/ceVBxglgPM2OTHHtDlLy4lMJMkt0JqqeHsmBQ1PrYfHli7JlEtUXAhSwY+PtnklXXV6moBAAt++M6njVi3A5tzNbDPHefhfnfEIv7sI69u5/t8GBURHLjChRFTHTaEywBKdduqYKDvSRz993I8p4vIoqN+RB0aoCUQYJ6BU6ewefKTcfDUpwCHB300LabW2lxr7I/cMug+b9uzXNu8wlYZ27OzhVYgL+VrfkjJitq/kfHpeEv6Tla6+pchGnSGsWS1/hFrxvI6QjzywtOhVvaMy15RHaQbf+XM1jMMi2B4SGFwAsymBVM54h+zHCpP5pEKmMFYR3geESCgHQVAQYNF3TEMOwIuHXsVi8vE356IOgmt1q6IJkAWZMpINYFHCFYJ33nV5TDvYQ7fonjvQu7D4h5rn0AuXLgi6/QIoOJ0WNaW2qC2go4xc0eAlcKzI+PfCOTrQ1bN/CJgAAFIpVYRRmrd6f3yPkAwa8EOE3a6Qa2AnDqFOp3CJ77iH+PWd9/SXinWaarUj+S8FYusXJB/s9UaXbUq/p8v+wJ8wZd+EY7vugvzdLpt/6bNcNt8Ga00NRapzYhTWwb2yRA1eKfD6c5ftTKmi67bkoIfVwzWmSF7FJoDNiC3ERuzj1bEVvhq0G1/JJ4n9za8Rs12EeGHt2fyNZr7BE7iQai3hExEfESASQLRkoIQE6fkjLSfJF8DxNhT++4AO/okifJJlp0oXxsjbYV7LRtgc+AbxkTnzN/RSmlbQNVXF/NCQFv0mOZquS+dR2mEx/XZnZ+T6mWJc9mNusfik0OyELAbPjJ77qzq5IdSUBi/dbhZUxmuiwus92FxUofMNrBycN4YezEMmVkREzY7Vm5vHy08FJFlA5tDYX9qTmAx9LPSwHKlKrWrASW5n+SouUQKKDSeN0e+XazXLFQrWUhpulPwwMGdl3Ggg+7CqWEAGBn40yk2xzgCX6+ndUNTFuJzVsa7rlDCfIlIJdpjx534OKpjDGdmlor1JG5Hlr1l8GH03eg0eB5AbdGKsbJf632K9oK/LHMRc1zGCEBQIbvzOLzkNM4/9BCe/5lfivsffATTVPouOlPfTSx47v3W4RT1NeSWs4X2MvsZ3/UvX4VP+6xPA+66BZvpEJsyY0JFEXskhzkGD3zYphJNGa1gGQ8fTW0YjPNqZIkmuQPG0exIF9nBHo/Q5SMGzJmafE84iKCFADLsBX0pgd/QAVupXrMpK29glulrZhfD1p7c8rOk9JcDXuOh241vtBI6bouPWtuWIUvUNSY0BOoLn62A7BSwzVF4nwAOD6JxxLBycdBlX8X3WDdM0ks0ICE4i5nnUefKnVQm2vJ7zP9jOWo2tLBa/6i2jFY6FNoPpeuwPgyOB32W2Y5Jm1ehmSnpXPuxaM47u5ZxIYBRh3PWTAgxd8sAaXXBlQnTnIg73yVjU1+MnkUPlseagOwRkUUppRr5uhmH0xmGzsOPsqYuYzXEQzHFNlA0XvR6IkMmMCF6ub0xI3L1U7sqtNqWwXNJn313e/PmKxXsFFg0bMBIbXN9zJMx2PJMdWyf1bgDbZ6bU896re00lK0NkIv2Z+XmYxxcdgXu+It34JM/9x+hqnbAjUibs9zBgAIUsNQrXuGpgL996Mf/yzfjY174MZB778A0HbaRxkoS5KbYxiyoyqxLf8ORZf0N3mR9dv4EigTP7e/Qhg/j0jPmgeUabRLfw5lq3I9cPt6+EvZjtHk2ZqFU/223ay/jsu51B01Rt9Xv5eHdyAEeeXsfQTF5GMgbUJAetG95dK6RYUgzCDEBrdGise/1vINqf/OQEtBqfGg9c1Rkq5A7JUUGmoQCAuO1Kmwy1v8bA2+he9kpwGxUnK4g0WhkRLB+i5fLfImvkYTlBaeaeIDER/vOPs2fr142Qe2PUzZD8IX/kwVSXKFkApbucP2eNdBM8CK2MAAJVHiYYq2RMVNo1yU7FaWbGJQMDRZEZyF7RIAucIvGRRYSE0TZcGShLnbCHQo7Nb+n35CclNGcnaDziPqXMjiunUAIiXbK8rozSGDl/W9GQK7M605DyOScnP/Ei+RsiMWGmw4kMrYV3PMYZxEwRTkHWtCXRRCSCzqfO0EVgrktVcKu7rC55gb87utfj5d/8dd51lxrbVsx7tpm7gC9zcz5l72EOzX6TP0NKocHGxQRbDYTfuF//Cc8+RlPx3z2LLA5DekAPxVFkRxAWXbL8sh9XDp3p8n5QpeMdGolsgsq0Jv2oI8lIawlg4SSx7eL4vdYvQaG3D4DdVNPyXX6TlIBiryI0zPQkV+y5B2PwnidzBcHFPQ36smgu6BnmAd/xTwXXkuQlCfkJpJeDGDbMBqwpADS+2ffK72Qou8PbllkoZGyARjHI48ycV+Gz0lHUgJrzGQB5Ep4phTeV6IofeMa9x0ulwVyUz0r0JLod5erRGOuuzCtY6SwmkUOkUN8X29/JJ8ZwFHWCt3klG0OgMpTwcgG1IFvnMOFrtFIUQ5iiGWkXQZlNwCwHQLbsFN7J2QEA+QAyDlk3ln52DNY7a+q76BjXfcybkR8DqmO6KyEI0wOBawJ3rtwYHDnZfgYw4HqGBTtIdpBrPJVcnYhDhloV8TQHvp3+DnOaDTxmFXB6oH/NR0LNabrHOVarwaehfZYC/0tQSiYscFcdzi6/mb8xI//LL72X34birTN2+e+s1h1uYRD8hoHlUrzYX1z981k2zq2eeGjUwd4zY9/L6685iroww+hTAcoEBSnlZ4F7TxdOxgQEi+dB9Rz5r02WcYpNVUIGYMXiGkCy9BFAyZ1gHHQpAAo9grP2SlgORkZ9RCEK3judggOPNOxuvkw/WKGgXQxn3Z7layTDdTtyUobUjZgl9RW63S3mP7b2gqZDPTAcNAUqC/K8qxzCRwC0H4HnXe8A57RDUl8Wz1GBJIIRNj/WpY7/udVjAEfogtt+9ksEyUaIx6IwMkDroFRIrQaOYiNYMjKDHq0xoQlZ+28Lq6HSxOUJZifBOHo+p1BI4EL1fIoNdGQwgklPTLcA8iJBqKPCixH9nM0SjdSC3CF8gVhpNgQYLPZYBKmjPqSPCsI0MjY6TYfMtGaaTfFotDRhxnNwE1pmAdGA0dS1jMDMuKFgyQHKUK81Ay47MiY3tiOz91/p59ZPYBip1N6QBBDuCFH3w5wCKQEA5YrDScS+13PdFg8ZFl953N8pzphp8U3GLBgou6OcXTT4/Bt3/5f8V3f/cM4ODjAZtrgYHOAqbQArNLz2Il+CXfjfRH4XrOl79gzzzN2uxnH2x2uv+Fy/O+f+H5cfEqAC8dA2aCi9Ec5JMDNRx8GnUbYS8wnddkTP0jb41ZXp36vmUPiFOlFevsL8RwEEoMMg09ctsOxg1nm5foxPoqTD9cxMpF2Phr30/42oAB8bjWtwQDptHVEsg6aKbOPdPNeZLvxR4dzqRbT77RRhX1oD2RvSOOjtT3OSAlHoMQ6d+F6EL/Vz7D/XLs1fBGNjdAhST/g/kNzlXugI9ytpgJx7/5AYlWnFtg7eAdZu4bwI50lntlSUtE7t85lP8/R8NhLi6pXCVd3qIqlIY4hpTNIglXGMBeWxMcNSEKUQdzYGaLXhLNQMvI01qepQC8c4/jue7C9/4HeX4oWzYFjrIMCE7GikvaPZwG5oyee+ApRDcHanBAsguxeu0XcQN5ruHPFMgpvvHPKHQbN5IqxyQyRcV0RgGwZbQ+OTBeHiI6z0FZX5SvRHgKAU9/bjwXIs1hdPylaTU6XDQHxTKr1g7Og5Dw4eNEKVWB74Tzkqhvx5V/zb/BTP/ULODjY+KIp1baquFIf3L76h5/9k8Wnvdy+DUvPON5u8dSn34T/9cPfjen4Ieh2BqRA+5xXPFNdvZPZvMhuFqgxMLMLn99GZc5x35CbK3HnkcfS3c48axpooh/g525DN0MOMSqE0FcM+pECNWs76PC7hkQhB352zqoz3xfVL0a9yJaZQ0yXJ1dDmKIsKOJn0B36028IAiHwzSr6RxPw2p7IrBC0DnrYOyBscs/hQ/OuEUxy8sPpGgXvyW9z1TC4HZWTgNP5t1DwkOkK0BreuIxWbS7LIYLTkcr8k0KDxWu2gZXnbBfOaOVwRzGyoDv5fYcAlMoP7a22Y3flWtamtdeGI1LQQJmhQx873/C0roC+pnKkd5qgxxdwz5vehLN/+ra4nrJIMvBlY+QwuA8g52H3E+B0wGOesyyikkapRYPWBbXz3qVeJ9TtNmcPrHhGf3Z8kbVaP0jB2WezEdB1M6zGi+yw7LwUyv7cSthBgqIVuuQBgDN9oSONfbF6ln1ZkCpuoC5qoL+0oAK6BeQ8piuuxOd/6dfgF//Xr0FEsNvt/A1B/lYiAgCt7ePZ/B4Qs3fhTtOEqRTMteKv/7UPwg98578DHrgHpc7YyEzvwp1zHJkY0iwoDjuHhXyaIIZAg329mr0wQ3O9/K5kxwQJByZUdfgcgZHTnJwpr0QAZq3Q2564nyFCdT/iGmouof8YV9ymLKornNmgm1vCWB4NWvGLOtBs5u318wWk+yP5iRezNyJKHhY1i7EAzl/nR7tG0QYa2W/E1IztijfbFNaeoIqDDAsKM6gSsCKuLX10vh69H9sJ/+jqgPgevyU+qf5cLnAuA+k4jLzMuscamTpyHAsoWnnOVsY61g7KoFajgaGjaRWakcPfyejG8fdlR9bgl64ZPRRqpDq9TfsC9koYmZju40jJ9w4FRdQ9o9BhOMYEaIDJTjUJdiRwpMuq7QbN0TpVlbJ5jazWg5eOvPEmI0B0OV+RdgoSwDLkFKUT4ZxZWGZqAQIrswceHdDd0TKviCNtoYmBswFzlBnnet1BezAB32UrzbuNIhBiNwad5sOdd39LEBS626GWGfX0Jfg7X/gq/PzP/RpKKT53WzUy3Fq1T5VlgF3S1b6UvpXjVCbYiMV2N+PT//bH4lu++WuBO2/BRism3aLUXd/hrJIqkx71LNXdArc1An4HGB6NYdl5vGb2a9jsH9J7P0IXBOzcOg/E+m2ASyMsY12h8E6H9yWISzyIjLX7hD1gAlhgZ/cT7YSracSk62eYlbUpzo/EAaYfPRxIQaT43zTZkHypDOf6eQ7k/I1DeevIlJWTrBv79/OF6UteWWmFsPGF9MHmtkP5MmD7YX7S9cf4Gf2NriptCRrD/WkEgJk8HuTL1qZHvdbU17EuWf0KC0C6npRVIgigQ0mykjfACKIU2OucVied/08OZjCAMZuNIW7kv0uKnK7kTEyiaw/Q8t2CrjQ0hNKHYSQ0i5SXImIDN0YpAvh0eo0FlqGrhmNyW7O+dL6oBTCZH2pO15xGUhZbnOQ/F4m7h5O9/Rxs8VwwOQvrogdD/bLW5CcseFkyPTum/CO3lQ3D/IZdb3xa2KLxZdHkypAQYZGItDfzoLSNBA42mC+6FC/9wlfiDa//A0wHG6eu1nhFnzvpwe9a9SaDcUjZs4/a3qv7Zf/gs/Cqf/pPsLvrfVCZ2qybdn3EDOgMzy4t/hx9Q2+c52tdhxNRxmmFDDyOOeDhEYgYUgE6kLO/9TICf647ALfbjdnVoBsyCtmNJ9rMScCAnd4tjUBiMD6hghZQNPslDyShC9yf9JYsb59GV8h+06FDXVbB6N9YiTX8Gerc7Gq7hdRY1Kj9Hu3DyerDzvS2IAFESl9vkJtbO9aGvpsYw954eo8DwLaJCc/rR5dsRzSbSa52nnylA7r3b5T9SNVI/HrPgr3mlFbvXt4RLpCaDUdaUmFgoYisbA4gWAFQMti9GQFHbfZ7iFYb1sU8lgqBm9MfMJtA1xQuBQbrpCwu6/gD5HiCZv+wA6nLTBZqkWW8CzSGKq0MAjiVn1+E64zCrsc1m4tVGurh7LElLwp/kk7d1JxOX2SCaN+8UawSDc+UgUgHfpGzNYeZAgiWOxlD3JzkFsN4xoQc2FmwYgGf81epPnPsLERiweqcLNGSMmcEf9X/sctNIxrgTph3Cjk8Ag4vxsd9xj/An/7JO3B4uGnvwq3x4vkYHYjqBlNIzpoPK1J7Xd/8dV+Kz3v55+L8+2+BlkPYft2l7gCdo08c0GHQt9StKG/65/qqcT9PPSTdtIzAwNt03Bw/lQ9gj/5lsGc9IuAl+bC9hr4o2WnUE34k66uXYrmQ1SwiUDc28jkpOzOCaRcurisFIaaP3ZtJ23WKZlT9O5yvw2id96sC2y3KhWPgoYeA7XGyv2aB9vID26qRPlKAaYOa7jjhGP2C/Ssal8139cCizdOOgQJ/mvwq7JPfj0y3xZfBjEc8SnmpaowKUiYR/mVYRHlS/4e++x1DYCQACkfNa5TrWIENya4MFVtH9max+0DY7osfSw80Vsnh0FjX2ok9JJnTSUjq5Io35RX1wum/tTTJjHtBmC6UwiFJLQNWb4rbNufoQ2HdkFN0DRjaeqcNoByooul0+OM6DEoJmOO/1C1yUJwdcD0uKorkc/PkfEjZBbLEHLE6C/ECntmHSkjWDxP0CL4r1bOppQDSL5p9WFATe+nU3XlsLj5C3RQ875P+Lt7+p3+BqS+WCjmp3514mI6l4toLu81md7sddvOM//Tv/jk+5kUfh92dt2OaNthgi43sMGEXdTgQ0baVqbPUHikJwbGdSvyzPoWcw4EtzJNAKjGUMgC/LJIdH+mZ6ylnunzRr2Mpb16RSG7GNZtlYXWljigrSKI7hmkpIZAY7fHpNAViHrZf82rU1ZRHehJvzVxcFxXA3KZkj48xv/dW1DvuaJtboMlcUPuoTnsuuwja23wE7bnuzQbTtIFAsN3u8H92rMh8cK7GFxWgQjFDsfNPxQ6KWVsSI1r7M+iZ/fswJgeJWNG3Xo6xDEjfm2qMWr/nWIO0FTMC0qYWAbIJ+MZbVsAIGEB2YMSY7cr4cQVcjptn+vibuayISBx4XFMHHizAZdmnTnBX5hxwhNwUOrddWjDP8dadEWgGVIvsiH67xfR7OeKnSM8dCXywBClitTlXX3ncbuYFJM2I+/3usCxD4QCH+sKd74GP36Mhdwdl0x2nmZ3CELg4PJEgFNBxk1K6nGnKGm2ZrLcvZHz8vtKUmSp9wh0wrdrnotgRp4yYX73Yd+2puy2mi07j+PgYf+MlX4Dbbr0dm1JcL2KQbH9wulxp0GzF9q5VbXPA2+0WAPA/f+Db8ZRnPB3zfXdhKoKiuzZbp3U5H+68i92n2Ib9zUxCcky2yeLJXAvJho67gzVGWlu0WtVfHdn7nuZT3T2xtiiVd2LglYkVJ+VjXe1ycPuibAhMvzhx6Xlak53IuLNUr9tfhUj80T4tYW07C6XZMLFUOyIlE6QAKfc55Cu1Qi6cg9QtRNuQMuxvnSE6o0CxEWBTCjYA5Pg89O57sb31fcD2QcgM4sXSh5MQ6KtEsOD2QaMeGOTRutey19pHfvorK9H1XKTg7PF5HNubxMCvtCQSzAeYfzAf6OSwbrA3jToYoSxA4mRj7UgcGZLClJyoYBP1yPJ2W5mSKtzb7lAu7l3MhQ3XA/TEnfVCrMNJJUZGD/YoQ6BTKhfDCzmmCVMbutsjUq0z5NQRrn/2s/Hw/ffj/j/7M0g5SG2xAji9sqixX2zXbIGR3ZuHlDVoV1IRb4P5QQ6Jrns80O81I0/KamjgNypiyziqeQzIlBpTDsSanGMIiOgfDCLzi+gfFYLLcXBil0dAMf9uQ3rpSN4CvgE+XVXkhTU5o2pDYtbDComt5+YZmzOX4L7778OLX/ZFeP0v/RhOX3Iau7nC39LW36JimSon0KZPCV40nDT6PZtpwlwrLrn4FH79x78Xf+3jX4q7770XmzOXQOf2/tuC2u63+NqyBY8Ke3DSAx5wn3u5NHrKuswBRMJHAudeTZoXZlUOeKY4IObLKVkmmYifS4cT6YQtQCH5AuOD8XuhPwEWqX/kJJLNDnxisDF9Gf2Auf+FD5NML3dSDdT80+bpWzYISJ/GanP5E4ADlDJhggC7GfXCw5Dz5zHJDjfedCM++AXPxfOe+xx8xLM+GM97/ocDaBlvA8lxbYaxmAITZ0LIyACt2msY0fa4KtJ2uiqq7ZV9U7Rzvs74i7N34i13347fvPMW/PJd78UHXXEFvvMjPxFPOH0pKiLAKkvGZPnQO7b3QVe4xKFv/d8IzmiR2gn1qMuRFE8Um0TY0Mxapa3NMCqeCA+ah4cLdL3D5I7zveTIc+QQX9QumjIqdzKUY7XhoeIYBqbggLN2K2O8mys2Z87g9HXXo24m3F/YiSvxOBqWjlkGREl43eExzUrG71VKlNF+X6OrZhCTXJfA6m/0iYN35lXISd0HB1ZnJ7GUT7S/1j9lp0Z1Gl+NHv9XqR/E1uAxPa5jPPQoHN7XvYah8UhIvMd2TVHU64s5SAoehvoU4pm5oG1IMV12Of78be/Ap33ul+B//eT3Qopgrn14TBHvRzVOpqAjy0kRvhUAihQoFJtJsNvucN0NV+JXf/z78byXfCbOnTtGOXUKorvuMvoaCLDTCMA0+WpYdb9gesXyG/SJ+CJ+jYHC5BO65d5DBvsZAiBQs/4ojhWNaIAEz/QjBQHxHC3rO/sr1u8AewN3hXej97Pzi80v2XKMsDSDygFf+ED1H9ZDvyZGoTEDRLGClhHB9h0XaBp+3c0zdufOo567AN1MOHXRaXzohz4TL3juh+OjnvsReN5HfTiuuvJSjIeU0sU+RBns41ccueuqACrqK/LbUegtggU7rXj/Qw/grWfvxW/c9l781l3vwVsfuBPHu2No2aCeFtx5+534wbddha/+sBeidoAuiOkz1hklPrJPXMObJIu1zB0ITIm7Unv5MA+mSYYAGtiSy/JvEasPDRuIcIdWCSSHTGHp3sVTTqvurbMXcKBNXXG/EEqrj6U9GT5mFMZPYVa3oa2qFZCC7W7GPFtHV+KmIeQWklGii54jDdBo52xBR6yopfkIYdAYuiUy8NGAkLtuQ3w5IIrrAh8+01RNlFX+MpQhWQDao2B4Hzg7sqE4Y33rcwb2ELJzIWRDgVWQSucMpRa0j30Tb4aIJGBedpOe4PQ6W6VtmHiejzFdfz3+9+t+A1/wxf8UP/y934YqDSgb0Fpj+7YqD7BQJUfmhDYHPm0a4D7tGU/Ez//Qf8UnvOzlqLsD4OCgBSelZ7YSrluKtKkGoVicRigcWYxEgMBjCAxSkBrgmq4jzMxcyartUHnmdOY9XQ9nQ05WQ5yDcq1OV6kBG93vdYZXBAj6SF1aUeldH40y+BIsIoZyv4X/tnZVqH2xFd3aholRmx4LoLKBqKDOM3bnzwHnLwCqOHXRxfigpz4Jz3rmM/HJH/838dyPeA5ufvwN2Gyi7d12C0XLZoXf+IO1/gT9qm0o2O3SxKExxQQfvWm8fHh3Ae968F687tb34DX33oI33nkb7js+h1m3KEeHKKc2OKoXQWvBcd2h1gkPnj/vyYUH72uH0SWZ7nUt49vCDtKxF+vWazQoGYtu4h5SrhPhLhtQoidlZSQozrjsHIeC/R6uI3eHBOjtif+NIcretjf3KP1Yu6ym5Ap7tbQarWaAqu3xC4xVWMMWvVtkrAu2mR25TZMDS04eFAlbREkRuWWN9jiGr6aLdIMyEF6EFYurzEDsO2fXEc3nuRdxGavTgSRSSU4ZQY63F+dK3KhBG9cX50b5am+r89wyXosTXOd41AOB25RdjyMA7ptNHjzaAJDmUaBEuqAQVFVImVDnY2xueiJ+4sd+Ek983OPwrd/4VfQIkKIqUFBhLyofDwWDbP9u/aV2y0aw2814/kc9Bz/46n+Pv/sPXwVMVwMbBUAbI5jW0KhIzLN2XqSRFFpJbBIe9Mn4yYClQOiyGlCRPzCl6ADCgcAIiGLyoAxWu942WzP5JanQb8qquR+QpAdkXSxsVuA4rxojVoXrIa1zV6MRS5OrTX5EKv1qfGEeNj62YeKWuW4AnaG7HebjY8wPnwO0Yjp1Gk95whPxtCc/BZ/2qR+P537Yh+ApT3k8Th0eYOojKfNc+8YrM6S/+KJIrHrm5CiNtBFzQxf7XKraWIx0F9v+q1rx3nP343/f+h784f1347fffyve9fBZnN8+gnrRKcjmAOWSi/saA0Wpc1u9PiumqTHpA6++FqVIS3BYwHRkEgloWSZspwO4Ov1DoLE+byuLX5J+uxOCCLBZRecTdrZImMFawkJpX8DF/FxKrYIBjwqMHhEuyzHgykDHo2e3A01MsHQXQ4ARfY4hmz5ARzfHYhAvzpehJHzJQOtNq/OHwcczfzP+VC3xwMGK+cIAQou6kkCtGgUKOUNukxxW5kkvZoBqnHAdMX5SldSPNBTn9bWgp50zZ+Vu1P86K4SMzPkVABOG1EYNUlms0O36owTccF2UgXeZH9KfaQSKCko9j8PHPQHf8R3fgafedD3+4Ze+Art5xtzfDiRlD9Aq/KUGPJQM1aSa6KA3lQKdK1726X8L77nr6/G1X/l12NzwBKjOHni42Edeuk6Sw6duWUPiZUNfFgN15mtyb/ya8zoqzs48BTakYGo5Pa03MPBcsYlxamrET5+TJ58X4CfZdgYgt/r4eeJsyxqJhHfWRqzEmiC9sXPae9jrFoFiA5SCogVSd8CF86gPPQKp53BwuMFN11+HJz/5uficz3opnvucZ+FxN1+PU6cOfZRL0RbT6RTvyZ2mCWWaPOM0sRfyo4YGtUZAVrS/WL53YBJgQumP6gC7WnHXhYfwu7ffgt+863b8we234K333YWHzz0MOZggR0copw6Aiy7DhAKgAnMbCWoLoFo9FnxeNB3gBTc9qQc19MSqBM9McmsIgUcp4ddOxIqV+tZhki6GTW/ipNJ/++tYBfh+IakYe80VBXUQXIsa9mTF3AWrzfkdsWMvLuNtI8H7LkRQYKAztt28H1RrG1LWphqelVQCoU7EOC+aQlwnRWAvzc6OwuZhzB5pkU7zwIlHlrGCeOGgqSzdyExspx7vq6I/P2zAY7RGBhBN5EUt0R1xUPCMKgUPkfm3P7GakacDLJvVUcepfSF+LNjaeRIpRWQjS/4YmUpOlIa9nV9xr2WFkdGIE+tQLxVF2osJDq59Iv7x1/wLXHHZFXjp53wyao0RhBwcWV8JaD2+IEDrMopFVq0fda74qi/+XLz/1tvwn//jd+Pw+psx746hEFRXb+oMq5HaPPsyGzPHbfjkXLW4arR3q54CEddRQzzWXWejpPaYvvAfwZcxAxnbN16meMjCj65Qo79IgavRwPqL+G3A6HK0YIPp7UzggNS9lwN+y9LbqvMJGymYZ8U87zA/+Ajq8SOYJuDGJ96MD3r+R+KTP+Fj8REf8Rw89SlPxEVHB85T1fZct7diL7cQQXtLEPwF8R4wpUw2Vkdb9jrTu6iLGEi3CZOzF87hj+++E2+461b8xq3vwRvvvg33PPIgtLQNM6ZTh9hcfmlbZ6AAZgC6a/QMcaavSJ5a+9cfXoKbLrq0zfsaT+NLN4LsJMYALSS+7vvHZC7WH6yV7/7sUcBZJerd+H0e/ydITI0bQWzvQiVzOck3rZC63gnsRXRd+2U2uLfPJzAjNAkGJAyu45DQomkCunh4PprkuWrAhmiJMgdNBpNMb4qkGX+ikgxMTqISeHll0XaqL69ItvvtXJJVaqe7QXdINIyWDBjJGXWySf8pJ0o0xpw1jF53SEgrITPPFmcaHfZ1uC0vksjGqGykrvi9CuqXN2MMM2K7c66YmuEpUKYCXP04fO4rvwavuelGfPTHfjh2u/Zc4zzbO3ALOT5056mh7+aUYUAL/0R3KmoV/Idv+Arccdsd+Mmf/DlsrrsZu90WVQt8blkAVRn6gTaSgKgz2Gb/kn5p6AtIruh/lHjGiix+fdhGQZvFmN0w4ke8Go43FgMSgDs5AdTUQu8jg0ushxhHyEK2I0BKqtDXUCQ+mKMJGQG2LpwWc/UdnQR9WmXeoT58DttzD0N0xtU3XI9nf/hH4ONe9Dfw3Oc8Gx/6nA/ERaeO+hagPSvUGX3hOUSAaTNF9g5bIAcmLrLX7v/MblEbBoq0saWpCA4IMs7NO7zv/rN43Z234DXvfw9+79478P6HzmKet9BpQjk8wHTFZX11vnGst1WMGcEr5yfxXNHmn59y1XW4aDrsgWmWYaDv4DtJ6ELleCSUlzF5v82eWElZf8gHxQnp9mAC7pZpXfHVyCuPO+w7NM2Z5WsZXFYKYHROUU7pd/bne6gJnV//zfQsbuXMj40pEeqCjydfuiL0T9u0m5pcRBxRzzicllZFpuLhpGWN0ebgx4DA7jUX1RUiA485J+l0B1D63CzxMK22BN9n3wlgk0aaRWuwMmXWTSF5FbABsvEmhv1yFjGWSY6bovGUgVIGlLIfDg6Yl8plSQTmjIQHpvfITgBohS2pacPnLauQCkybApy5HH/rFV+CN//Kj+LpH/hk7HY7tNGS1lTpw2WWVUDHmDwCGIueYw64rdis84xSCn7o1d+Mj37vbXjjH7wV09XXArtt1lf67nxzgHWP4aI1ULNAIIGukN4QP9KcP2fu1hiE5NsCgATvXq7L3zVEAuyTW/UbvY8BysD4NixzbTlDDt00sMKgM4bBtlZAe5DLvtKCBm9fta/IlbZIToG626Je2GK+cAzRGYeXXoIP+/APxsd+5Ifjw5/9wXj+8z4C1117ZdKAeZ6x225Ra8+E+9umHNSMPkodjSRVTYsQFcNQsbRHdFgPb33oAfzene/Ha295D9509na8/cH78IhusdsAcnQK5bLTOKingV3zj9X4XwxYIyhSIsj8jljMZb5GFLo9xgdceqXL02XvqMuwS/6AO+tnbA48Oj2OhraTEvXoUE1vcol/Q1Mgd6dpGJlKnHQkA40Or2eA4YwXVdC93jI58EelwYtwWDQ2n+drhf8qf8/0OeCYg1UWQq7fQWEEHNakRG/cC5EYciY6YuicutbraIpCi3hA/EQ+t8pFGpowx2FAZOdsDi26KkGL38/Awg4seCBiK11HYgY9GQKIdsqcmdG8Z5qiE+3D78u0NkWoo9N0Xg26uqTHlTYAAQAASURBVDoN4QaqJANqZVhEZmxjYYgqChTYXcDmaAM9p/iYT/98/M4v/g888Yk343i7bYtUVLGbd1mPlpzrfQ7HANLHXb/j/PExNpsD/OwPfQee84kvx9133ImD05dA9bgvahHfnm9hwsxD1gG2Bcmlk/qmzJDqSgC8R+4WLHb9EY0598Aw4YoRQ72jJWjYczbwXk37HgsvjWwNHQTdquG0+VlgC2KhBq/BG19IWAqkbKDzjPncBeDCOch2i0uuuxpPevwH4EUvfD4+8jnPwXOe/Uw84QnXp32K53kHoM+X9lXDBwcHbj9hQ2EztJmsf2B6aAEkGuhP9oYgBbZa8b6H78cf3nMnfveOW/CGe27D2+6/B+d2x23e9+gA5cwhSjmNTUVLPvre3xCFTkGLvxNcmOvOzPhuINUBWhUoVfGca29A6fXYCKC43IaqSOXIc+fD1Ff2zeCyr88U87EGulRDgqkNX5Q9FS4q0BVWqeYy/mMA2uHeRvDSyS3bZdDju/M9C2f7qOA9imONe4xOQY/tQetlKPI2WpaOaV8mmFfB8Rw0A1GbltBUFyqt1IQ5o+WQGHkDZw0sxlS06JNAjelXHeQUqAzPgDngErQnEsgxcXYT7E/ryXPmunJPGlZnQPRmFebmWoYRfV5dG8AZo+pQb9Yra4ZB5MRV39YzY5XW7iBaVqO7Y5TTF+G+e8/ikz/7i/GGX/lRnLn0Emy32/a2oL4iE9Kc62pAadwgtrsHUO2Pp804Pt7hzOVn8Os/+p/x/E95Bc5fOAZK21moagG0kAxq1k7qY+ivMWKQkUjrp2UfBnymhwOPWAyRLVNWDCX9Mj6CGyYZBUE8nSHKoGd8y/4kTZOQrHOmHteNL+q6RQyxFpSnUBojRArqufOoFx7B4aWX4slP/wC8+GM/Cs979rPxvL/+LFx3zZU4PDgAELsqXbhwobdX0rxr6XSWacp9Uw2+rPTffArEEs6mXzMEd5x7EG+550684bZb8cZ7bsMf3nM7HtALmEVRTp1COXUImS5x/zRrhe7mJOtayBmh+QrpYCu2Otc51e6zeNGuuh5X4FSZ8Jyrrm9gC8CWpUZglMMauzX79mw84UcGHLFgWaP+tS3K11xJatHUs/dLkHaQAu3/Of6lShf/nhA9rByLoeZFJzLoeqm10MQbJ4Yt4snWluqyCh3+Li5aBMVeNtFKRrrgPgcTdn8sSLI2AlRz8DHW5c4KSsMa3emVXJeVgQxKyF/VaGQnyUUDoExxs3MMhnp2MmbktLgmfFTPAId+8nBj1LmUP4Nh7kz2wa2dsIDIoDQcKoESwPqf6/V2qe08LI51oLamYEs51Ncjzb39uj3GdOkVePvb3o7P/Pwvw//4vn+Hi89chNJXjNbS0GVwT2Bp+8Ko5DjaP5vN1B7x2M6AAgcHR6gVfaFLaaucQaCGGtjtSkmW4jyJ/kU/pfPB+JIE7zxgXWJwY2a7I+WMkpQhyYMDXvvLNxAG+pRIAsaoy2S4GOGw0gncmeScqhjrpFYU6W8EmzaYH3wQl19zJb7hy/8ZPuHjX4AbrrsKp442ZE+KebdrdlcaCJaDAyKxL4QjjvmcK2zoOHhkgUtV7W/fEbTX67XNUM4eP4I/OXsXfvv9t+F377wVb7r7/Th7/AiqKMrpQ8jpA0zTJZj8XdMVmGdfTe1t0tuFBpcc5rp0awhHKVS4yU+KoO4qrr/sCjzpksta3YK+dlncr0AaoPMw/VpL6YysyH+8Y60qwIXLMc2+FrkK2tRibHudGL7ZlG/hiJAdV7pncEr9ZJS1KNIiSmsptL3XaV45GtDh2hjPrfF2TThsu2Pf2LnqSdxWeKboc12joxKrxxxLGE4OGsTpT/MLGq4jSpnTDF4lPKXv60Qjkl8JjvKNaS5tAB1+BCLaN6sId2v/NNAt7iACLEmjyTA4CLOzCvhbPJSvcfRqZPbzNh9r0WdgMC2KM7YLubauRrYKM7pKDQwg3CqqzSaqorIuiaDiGOWa6/Crr/lNPPMFL8Hll16Cw1NHKJsJU+nZgG+LQwOdrgNN5jJwQHsfJwHm4wopBX9x62148MGHUC66qD/nW0iWbcBxXL0e/Aya0/x2v8efczVSiZ/h+Dv1rDfm2Tx7ZH1KmkT60L67jzB1aQJLAa3rD6sUoh/BV5rD7YCf1phYsJHozk2Mh0BbBjoJ6sMP44qrL8Nrf/yH8MwPeiKAlr3anKvN305laovoutnw0LAQ783/GtBWba9xNNuPYWVBkfZIzdn5PG555AG8+c478Rt33oLXv/8WvH97HtvjC5gODzBtJkyn++M4AtQ6o+4E8W5BdV6KyYDA3Rji0w4NDMJYk1yCeY4XvV8qaMPI84zHX3Q5LimbBuh9x7S0BkZDXmsyYH6Y3riQuVyKnsjmB9k2f7NoPgHs+FEoNs1IzLET6BlNg1New5YF6UzocDh/T/D6y3nWoG8s3QyCqTCDG2j3MIhrFYxga8MrYUFA2hi/r+V2XwqHDyRX7wJicMmMCF4GyBkocQQeBs8S1rbzlJJfZwDk4hSFrh28SjC406+4BjGfSE/G8ROug/xogGj2l0EvyU9BDj8qjACE6Q0j5SOLf5gP9uyT5+MaI82BWKOxOGjZtyRmMADtMVqvizk9o1aB6g7TlVfg7nvP4u4774L2FxrY41ew1ynC5NXptjcAlQkibb5NitBfk25bLalTgZy+yJ/tjY41R+oOtP9NPhFD4EE6E3ZjYNccND+yn7K/JC8xUyH+mC6brGIo12whZScl6GbwbXbmBIAWJfi9EdwZHyJcTzrUbw/e023gNkzvBYoJKqWt7J3P4fv/3X/Cs571ZBxfuOD9LdOEaRO+yIDKtDzWsfQ1IgrYUH8RaXsdQ9pmFQZWAHaoeHB3Hu988H781m3vw2/e/j780Z23445zj+D8vAMOC8rREabDDQ5OH7bFSRWos0KlunzFEgvnj4st/NJoH84Sikjy1f6TdEiE6uyimgqeecXVbXshdzVdt7iuddeWfJ4vFvOEYAUn0r1B8Vh9Rsr+10bKxm5237UBlni3DygBpIUl+8ry6lEjbEGwOSWKZhmsU10IQPAio5J3YvKcMCnwylBVayoLTLzNlYBBTeFb2aranWBzVMnSVfpqRFppS7Q4UDCgsDvqIMAjAeMcan/q2xlsQUbMFZKbdJloAL0QzCqczvZX+jkrTHOyXC+ojNObgXL/KmHja/Xr4W957tPqJkERHZGlSgKJJDp3rMG/mE/fY6kIVYzxBhNOdsXwqrTTZCeNP0L1WBUxVwwAOu/6VnWHkP4mocAFD6WCS9LeRwopgATYusUIBanad8+tvNYgHCjz2+TuQazxlTNd05XeTSXHylml6z7phOmndPTi7JKnZWLONkQUmR2cdzH/y+VpTo9o4OuOAwqqg3wAtQ+6R0gbLMtK7oj6ryKomwPUu+/F3/q4j8UnfdILUWvFtNn4RiVTkXjetbfjc8SIkT4I+kr1GvsDT1Pyl4/MW/z5vXfhtbe+G7937234w7tvx63nHsYjF9qeyNNmg83RBqewabqiAHYzdK4eQCjxewRShiBfjwDyo4q+WUzzfSAdyf5OnPfW5gLCVCFzxcfc9HgA4tn/AmjXyAPyanB6KcWgCfQ0F5dfYtC+Y0GLBWJC6hAvIiA05s9qxUHI0qHxD8qUPGIbK9vHsMz0URABqssoYt8CqyWljrZDvSuUJmyRpqRSABSklyAHEWHsBoJcFUfa6W7mIIFL9zamgOkmzsS9Owa6S6BdlRkXoyZhdXWn2P6YUQk5q3BSqRXjWQJK60JuNC0Cgxk8SX5U+JwaL9iX9WZpODFqFeC7zLiJn1bX4ExXDzcyAplUnkcRuv70e2pvtwU7tlPO0C7rW0V3JLXzOvfX+sjzeuYoQ58I4AIhgz86nIuKqRVdDYCT03bl6v3RXDZ0OevEyOY8eiC9avJJqskOWH84GRYl4HZ7XShqAnXvq/MLpGxN+23fYruoRYD5GC/+m38DpRTUWtsiJ3vMhkC2Qh2EBdo223daBJs+imFUPLDb4l0P3offv/39eMv9d+F3br8F73zoXlzYXoAeTsBmg3L6EAenT/VN71qbCtAcLolSoh9xgkYMRl+X5Cu+eFOJ1zGtoMRWzfe636URhFpxWAQfdPnVjWbX74TXmY7R/a/ZDPtBITIscjAiT8ASS2IXiezwRej3xpsmJTzxWDO6x3iMK5F18GwecQyO1VxwvHc1z0kuVpTta3/4QQMYTsP+IyH6ADT2I/rC/RASYOgXOTPuC2mp6Z/HcTzs2RU2JKEsGsT8RZ5bS5nwcB2m0OYsYDoXK0s94/EoMCsoK3F0lR1jd/OLLJnqcEA3RxRtJ4kQiLhDIn7Fc7zU4Vx1svmcW2dnMWqclR98jfPEMiMfJfG2omB0J8C0egQ2UWTu7rHrAfNBwDtvZb1g2whdHxe3MW3NLkM3eW7WdMW4NGaD1q4o2apf1YW8OmdCi7tO+FxpB0HQeXaOYWPcf+Z7L2UbIZDO8uiLARvbhB+m641ZgQkEQLF+ROmaBtD0m2649iqutDtrSXVXrW2FrwKTtNGJ9uhP4/sj8xbvffgBvPHO9+M377gFb7jrVrxv+yDOz8fQTXukqFx6iEmPgLm2aYgZaNMSgE5w9PNhW5apB9Hsg8JnCAkvklS2G+qPRNlWhXrbID0jxw+f9FBAUXERCq7dnG6r8xWxRSTpUHLssqb7GVMSDpEtLRYherAlyeRi1IoAlc2s9yVH7vv2Rh47wH3Zf4nujYZ4In9RvSPD/jneREpoevo3aBOMQM0kcUm/wzrkEf54v5BE+31lQj13Dtuz96PsYvuyRHBypOSKDDQIoNKQRT8nsOHnTDKN1rjyh8O0YeKVG5GdEwNqKkb6zwBn+jVmaTwEPcojeOFMzqzyjJeclf1yp5mNhnnLkrJm3FlSG0jnwkAWquJ0ijv+0ZjTKnkyhgTcxjejnbzD2mwgCEQySeap4rvKwI9eLvVFhi/+LLemTivT5udWLKwDzhKISMfWgJlLx1ACcYAGZMVr6sVMTuTwYfqmznBz9h7zevvd91RGh9xTB/NOP5Nqj1wRonqffTTCHDObmpuXepO2AuP89jx8SBgxDxorjAGRCRMsc1XctzvGO+6/D2+68za88e7b8Pv33oZbzj2A47oDDgrK4SHk1BE2eqq/zrYBrFbbRlb9eVXrREpyhv7pGnBCM+v6OS636m2U7nXktXuR5dETFOnz/Nrn4J925VW4uEyYLUhXbXPU7u+YIlsoOJAJkK6tY8cCS2hExdcdrIJU2N4YA1vzxtJNnGcjor+LBga2D9nqeNsIfikS5gxmtR+0ICYN46w44NX7B7rXypkDSTS0NjniZeOSItALF3D2j98KmUoCzBgJC4cwekJd9AXhLCI0coecInygzT9zVmGgFIjo/FUEeep8XNan5KT8hiHrZvfJCf24KjV3V1L/IqMwR5jLmhNKym59pfnvDPJZoGmFKsgVEJ88ZtBm4CwLMH+U5uQk5BGSUqqHETwctdsXZ7p+dx4F2RMFQFJns6V5acpSo1R3QcRrzzJANDMyEm8g0hfIhB5Gxp+dsWdI3vX+r8uMZAnAGCukIOP8v/VDLVPSob5EeDh49HvIJOC6Yc8Be/1KYhN/jIVHpjL9Ic8oJ2G/lhFphapA5xmoM9781j/H59WKOrd9EK3JgpbFzlDcuz2HPz17F95y5+34/ftuxRvufD9u2z7cwPXwCOXgENMlp/rmEy0o0D4PrxVQ2Ds/FSNEZlvJYzUuxb5BTHRRkBeVkYqMdjN8Y7n4Wg4CPOEgiXWv61a9sMPTL7sWQDwql9YDmZ521o9rRTqR/Xv2wRH/B71pu1zuMtnL8iD+rfkjgy8oNmbweWf2Fb4t6z7x0l78W3rHFeKWoDqw6uQ64C4mt+vBVURJaShZFfzquEwT1SdAUUDnHbBVIL0WLTsuGoFKww3jwieAF+0g6jDHb5VY1e50rH9OaNA5tDk6Mb+5CNWt5DeG2WZSXns4PYsiBwBZCcL1G/pK6iOV9IyW6OY+Cnz/16iZD/WzMUCmq8YQGflaf3hOTggYsFIJOWYM8jUqnX/B6+ykNDOC+zPQtfg66hXYQSxj+hgOpCvCtEUD+aUNuT2o9lfLDaf7v6ZHY1cIE3NrOn6hegjQnF6l21cClrSgU2JhVn7MAwEs/Z5RV3wWU5mLnRarT4PTMVQ/o8wVeunF+IEf+2n8X694GZ7wtKfh+HiL2vsylQlHBwf4nt99Db7hrb+Jhy7eYKs7yOEGsjlCOX2EU3JxWwzX26z9DU4q7e04xLhOpA1lD4Lx75rAhK+xbLKOkqRk+A3zdSv6S3WxfrHOmU5KD26lAFIVH3rtjcF7smteM7KvvZUffi5WuWdksT/JLextZM/FlIlEcdsLe3m/rKC0FVL6WAY0fHxF3eA8fMjEhk2sT1beGI9BB4gYhgAWIN/EKxHTUKiGuF031hycXexACG3RY+t3fx6xSHuIEerDNjGnmYMEj56dJ9pBJpbYp+ZHB7LgZ8zjGY2qRiegdM4+kUHkurUSD8kB8gKldTmSHkAB1LjHsyVN38PBmxFr51vnr8Nj1GMA4pvVM0CoEotsxKB5SyGeMKuc/6RrANxpmvjEeNjpDJPv99L80DL6JfqDib0//RaiK7KhLlkvW4O9xkvri9Ei5qiiTrX/xoCS5ao03Oh0yUBP2BaXSQmEbeZsOo2QD8vP2zGZW59or0hrY5yuEOdX77jbl7p++qcSyHe9j99h/xa8pfLUpsuPbNFB1W2N7BlZZlZG5i3KQcHZu+/G53zRl+Ph+x+EimC33WG3m9trFlXxwqd9CHR7DjtVbC65CgebS1DKAbROqFX7vGXtC6i0TQ9UQGa1Zcq+1WoTRAu8fZDK3HMH2uSyYTpv+tz0WzpwG+8CFEOHZeBF4lliqCJfkFzCbbTxcKqKp11yBbuk8PaL4IEqSvVY9qyx1aNwQaqGeBFGOtr1/mNVhzRstIwN7g8Xch3j90XDBKgLB+8d4dAxehpsWIzAU9sxlNiYSG2kW4b7F9VlR5SsO5UxE4132Dr4SrwfcsgFc9O0d67xxUKOMejIxhv3BMssBI0QM+aCNbE2O1nqLwUh5vi4u56detGRroGTi9/k6C2oSLK3eRqJ9pJB9n47nbzgKHPXgwnn9WDIQAQHXa9YN2NBGcnNx4vVmW+A7kPVnWR78sv56bKAOyz2gyzMEaSl3yP0nS3CGnEHyfVaHUwTyTb0LLYaTcOp/lpF+6zbnwezQ9MNuHK/0kIrM1gYYUHj4PqYJSuuUYlX5m/ggAJVEIs7eES1HIDHwq3Wf+e5BQmst0THqhNWwF9XCaC/LA467zBdcRXe9OY341Ne+vk4Pn8Bh4cHONhssCkT6jzjiZddiV/6zH+CSx8+xnzuIdTNBvNubgBb5yYb/6h/F1VIVQ+0QvYkHZWYezRkYzMzVZfgq6lN8kesi+pVA5xAWZMjtg5yjdEAa7u3IgrVHS47OMQzLrvCdX1VFWX9dFwOTQ3xE9aoZt0ioteSxXysXZP0h4mjt/CuVLWqS5KJ42aGrLWf7M68dSJ1ql/PyBAOXskRjkbPmXDQtgK4e5nF9T0KQy2aRiVhmDNU0DbuSYFTrTIMtSlrOJVUWslYazceDYePVHTZI6U5LcookBRHu3GEI/co3CWM6CfVB6rPvvs1AuQMxjVlNH6fU81OV6lOu2yy7qSDvng/eg3JWIIvlvFEO8Q3UmimwQIQA2mFDZma3okPnQVr83w8ELzzgMWdTK/Td+UZRh94zFadOpZ29JlZYrcaoGRsIz2IAGNNpoke61fXBf8LCmyIV2YAQvR5q1acesG6amDHozPmD8aMN/PZLnX5eCCkuZ8gncW4cIaum1wXDrgSy/g8Qrmcx20lMaQB6sFVN+G3fu/38Ddf8vk4/9A5HB0c2n4cmOcZT7viWvzmy16Jqx85xu7++1DKBGx3gGevTiLU0SkY2UCJ+W06QF5UEMCoWT98PwLjmytN5gNLMIITOx82nW2DBE/6700IUAugk6DOimsPL8Gl0ybxPiqIr/sAcVzj4xwIcMrYM/hh/qy3sO+wqC+fLTkuBfmrPdWrJlBd6xiQbUFF2s4zYybLndpzJMNxEsLI99Fg7FnbRHoBsynkXekAAN9EHmjguttBjy9Aj4+h8+zdkSWPE32yVlByGXOCHrQYqHj7XVvF+klOCWuyi/4xYC6iun2HBz3ozlCSE+VupAUwIIeF9YZU4joPWWbnQXT0PvvQl3eAgKPTtqYfWTbEX+JEDJ+rB4M8SpOdkVUVABlcET+feYQAAu5g0ocMsElOFC1EuLnkHYOwl2ag7X/MEWPgj8JAkPIDNR1V76smwsS7vWqbIrksdVo1X/avJnMqzV2G0Snh+HnNgFJ51xlrk+sc9XB8P6oFHxLBQcqQ0Z26jXJJgcoGVQ6gsmm7fGGL09fdiD95yx/guZ/4+Xjg/kcwHWxaf0uBKPCEy6/E6//OP8bNVTDffw/KwdEq76ydJZCEcTC+QeDz76rIC4SbQrvMUxoz+Il03QIZ/9OTithqCzF3vO6XWnHpn4IqBVornnP9TThVNs5nfuxH6T/+LSEIbiLRvH+0lOzMR1qXC8lCT6KNHBcPfq8fBeOxiFxG/gzuyobU9oDmojbuAEW8NvYfk+xZOAwgq050pIucwz6ChH8HqlHZQUns+zxDNhMuferTcenTP7D1x1Z76lC3hEItANbBI/phtOcFRnnIM7JQkCFoAKgOfDMfyIbXr3nG6DQ59dnIyKiChijj5d3pxQKosV8L+pgeNIM1L5joY0Cke/k7O1if/wuJ+EUTRboX4bRTwMLAMWZ/xE8j2zO/7oF84Y2nPkLtEFCoAXh4RFNBga3l1H4pRgqMz2kHnNGOVnQDgNOQeM3BZwgXlLo5cAVLgmYLKDwzakMjHjYYaMnAexc6FGl/Y3QLGoKIxfwu0cJZceiC9msS9A/tu91qyIz1L+LB4KuBQdBrYFigKFCZoNJ2ehKZAN3h6Nrr8L4/exue/4mvwH13ncVms2n7YJfmS667+FK8/mWvxBOmS7B98Cx0016j15Jb6zcji2S5dTrYrcXbwrJ4s0aYBUb/PEIxIDHflYwNyV/uC+MzP4NWY7kWQCdAtzt8xFU3toWoNQd8YLmxX1Lrs5VNCkQtrWNGNg1J37ikDmWT2Mc+uz6uzdkulGa4PPxmA3ZHkxwVUxUKnF7TR06ds4nB2laPR13d7B5w/VLi1FgVXbchQJvXKhddgotvfjwuvuEGyMFBOCKm2/wG06lkFF1pQw/yoqE4wmlU29PW6SEyF7tzs0JmFVclPms48VReJFYHukcPMCFMjBhiyGBM/9J8cnGYS+aWslVqr9EyDOW4zjHgZAN0XoKGagHwsHBiCrp7IoCM5sxRhaO2x1Q8P2K1r7m88YbBYS3QSNllZ8Zy4MV4JU5vcp7dIVMl6ybl+tcBkOuLKhe6yHw2YOXO5yCHLpFceP2Adhqy36ERjxU+uswZQAhgk/TU5D60RX4r4ZTA9cXV1s1WE7+D6VYdBSwivk81yoRaNpjLAXblFHYKbK69Ae/6i3fiYz/j7+OR+x7AVArqPON4t8O5C8e4eDrCaz7jS3D9qctQLzwMTG2LRwdcMJ/ZyUn48S6grgUD4XyYvQ5AlVwwjS6Yb9PccggsfqT1C6Tfez23VkwCPPeaG9rL643+QX8NyPK9Y49Wql8JPFkf12/K9e6DnUUNxEaas9VE4D4Q2zcf5SA7fF8o/QjE5vT3HHkOeKksMTzQhxGG/8bmo14MJVrdDPrGkXDaAGhR1Ha7w+7CcWwWj9yAU21OFuiPFSzBDxp98agxLvTamXd+p3+3ZQ32/Fo4djPM7GRC1vD6ldpjJ+VyEgz1hdWlobvR27oy92El4ywbEBkV8ycexYhnHN041Prb+GU7Fwn1xWE70qm+O1MvEwUYYQg0dJCZ0U/OrYNlLDRTH+K2AFLpXrOTheGbzFYsmmM4X00i4Ro5uDAu+L2IgCcWbI36RDogUQvEdHPdUY0uxstKtiWel0Xnra16HSpI9uDgbDwZfIiQTI0PrO8GnB7SW39orjyajVXmwt6dRS/IXXafl0kzzseCugkzNthhgx0OsaszNldejXe+4134qL/9+Xjg7vsgUrCbZ+xUsZsrrjy8CL/zaX8PTzy8CruHHwQ2G6jObX2UKtrK51h8mHTMAN91yYKuHNCN3n+JYbGOJHdN/LoHhUvoNS4kOgDyZ0NbWisuKqfwxEsuA7TvAZ0CBusbuv8gHrPvG2hdz2ZDl4VlbUmGyXst8RvB3+5l9hhPBCihHEzIfvDTUdGp9Ni5MRTJTgH5+lroDTZua2EpyH2n07HEab9ZVoot5vfMiTrm9o31qi2SGbmgSYEHrYZ3R4j0Dla8zRlIYKIjTdSWBTdjZ6iH5rRcyVV92DIFJ6xXQjUQtrjzNhokhu7CTXdt5aW6oIyFnKrR48DmDk19OFKpf/w8coZA+PyP67RwWJUzZBmFbDIhfxVycNR34I95wvaXtzp0uYk91E98cCcRfsNpcFK5ZwobNqTwoZ0n1drjE6JqjROyKGS0wwExBhgkwN3NVBefCMBC7O5vxEOg3mdNtuOBCiubnTN+qIK5wvowDuxE8JcBM/kwMbOLc+xrYn2EBQfmRMmhkBCT3+BsiX2UAtC2Snm3u4ByxTX483e+Gx/6KS/HnbfejouPTuH0wQabqWA373BGDvDaF38WPvji6zE/cD9QjtpU1m6G1AqZ2+pkn4oDHxZimPCj30G+gSnxNjtzuNFbB1wu6rxQ4sVeBFG4Yhgbw992QN7NeNLl1+DKo6NwORI2lufJly2R6VG76r5vMeU4gjDbRDKSle5oVtG0bshl3s6VRtOKhz7pSFG+uPOx6H3EPca5dJ0AVrhcpGVr9uwOehFhp6+DYu2haSEs1jZvq1/w9hVaZ9R5B+0Plw+SDTTtziqCQIruqRl28EAsFjFnxIrJzqeRo15v20UGYRsdIMTp6gHSoIhJSOZhhfpsN1EUn3Sg09H9CMz8fONz5WdwsfrdnHUG5uQGk6jGwGKcjzRDMSfpQZtlyDbiQODumR0QICkC27TeVUEDRD2r7nzhDNyCkMR/MZmyLrhLhANb4pGJyoIVicDEWKOKeL2duT8GJ4WtNzclsT454Pi8r61CB60T4rAt83+IwUOW9NuV3QCcnMISvIE09E82b30JwYbDNh4FxTrQRhJe1JX1LbWnmuzPgoVQSQJmqO+6lXwZ+qM6/SmDtvNTwbzdQi67Gre++3Z85Etegdv+8r246OgUNn1P5N1uh0unI/zKiz8Lz7j0Zsz3nkWRgmnetpXKWqGz9rdYhDo1dkvQaKpCwVbWvywCUckBPhUJoCbfTdkjD0aHejNgIwIWv6/r4XbG0y69AhPiUT+TcWBFOCyl/3K+SP6LiE+xVkoG4794wcwJeDjwNdcpi2tlCTfDnWsHZ6FDQLCaqtsnGUFuKcqsUzJ2Ow0Vp3vCWWrSjrV+AFLYHWGFt2yE8Z+NEUa2tSS84VOUFcA3m4qMi5tUWnwgXlFkRJ1Si9i9LLKSkYHIkJ20aH+Qmyume/ReFVml94uAA1Seggg2zhYwUA89Go46LANxI+Ygih3DAKjuzKxdA9QkzxhmdhvQwcgoS/aFSpTFGucto0nOpjuLcejXANWDIHf65jgGS3VySJ9NP9imJGTtYiFnae0ILzV1gCa20KiED+t7hqKpjTbHqcR/AyADt1DJVo96Vmvlk08w5+c3dKtKxqAwK7cy7owtYKT698/DZdvwTMr7wIBJNjsco1uIOfaow326i9QQrw/11or2mGCFR8V1BnQHPT6Hw8suw9l778fz/vYr8J73vA+HBwc4mDY4dXCIAym4bHOE13/S5+ATrr4J5a47sJEJU62ouxk+nKyEuBylGa3E+hSsdZ6LDevbNEO4oSUvTsChwVkPss1ez3nu/mXGC66/GaXro5hdcsbs/nCUFfk2xqdUTP3f5XTIiExLhExNSW7Svglds6PEkBA3vB9wT1qQxJENH24IS1pXO7DsrjliSW0sI6m1GgNwOZuLNgSLFpkPOa2Iv6qh3MLXooXImNTBoOlvl4Jq/94MUqysKRJhrmU0I663HoiT6Y6EsqVYQ+KDnT7c5MDJjpei+aAlN8pzeAaOYwbn2sYOzUGZ2dyNxsdD3RU0mtyRB7C5kxQZnOMQDKi1GVmpO2erc5SxgbYFAZ4BSciR+cPByZANRZrhJdL1xibrtz02od7X8Qg8D+21LKp1zWgeHIkrv0aWaP0leRq/G8kmA+LP4lEtcf2DiZwCUw82uj6Iy5tNRTM9QwC1ZMPI30z/AmRAthfCS/2P/kn+vVaG2uNMuWWq4RvUni+vFVpnOOgmwK1tSLhW1OPzODxzBmfvfxAv+JSX4x1v/0scHWxwtNngYNMegTklE37ixZ+Nlz3hmcA9twOlQKT4UpKK0AW3Ig0e+1kdnn03X9O9QoeMCFhc0nzdL6Svy2saZcYhXCCtc0CdsakVz7vuZio0QlmW9xJZ0AGQF/DB9SJswwL9UV+4Ewj+jIdSURlOrhQsVJwYsR9Qxzlbp21k4pA5nHR9PLy8ZNI5a320IxykVYqhW8QppVOavnCF6a85vFDFcIR5eG1JL7uaGMLCUuAwOfMKZKThtdBW8hPcjYCZ7tzrUjGUKvcwzYySsyKmT+K+tSCLggwD3caf4NVidEQie3SjFt6VK1aSJlFSnQtT7vWZY83RJi3O8UAIqa4YxGGgNecUw9E2wmL3jIsuUjcpeIjrEvhqnw7mi5ETJhTWvkO5eS8vGjpOiq7hiGIEiMCLirvz7sEhJcXeHmed5BVWbS50IOgMsWQJpqDB8ZAezeq88UCVK6PmOQN2nfTgEKFDIfDU5kBQIjM96tZacXD3sV1YcD434K0zoDMMJe0dttvtMQ4uvhT33vcAXvTSf4C3/MGfQURQdcauVhxvt1AFXv2iv4MveuZHAPfeBZkK4onhvkgoJJDZv4IrbsapvKwU4ivL5MYDD9MtDRt2QNLBfrui2eZAWmdcfuoSPOnMFZhr9ff7rlDkbTJtaYRjkBFI7yxB6xfD3taO0bHonu8rBPpUEXxvZBrmOQEEvW4yymBaGGlyNAPoRvHcsbWs2JzHCLI+vLH2GdoaU/m9cUQXuvaFC7piVCMoDvH5UNdwDzngiOS7AXYLSBlRB1Gjh43cOc2OsffXs0uuC5YNUlvI1+2eLE9rPw/R5SSAXCsjlSolqrxwKwBPmH6o6ztH05HBDvy09rpz9+FFIdAzuhN9mnjE87X8thPQ1poKGe4xeoiPwr+in01XhWTQb1YDDUBpRVwDQAJ2xwZJLJABqFtZHh1Rp9F46fQbM8xPaear0rB/lnA+a8Pzpp8xvEuw6Tzgtq2GYcSE9cQyELMy6xP5VgZY7fLzq84H9jUm75iLDwdsi97I5tUvZ92XNpcJqssDrwS00a5lsW1XuArVGag7oDbw1VoxzxVaBfMMVD3Ane/5S/zeH/wxgLbyeK5tX+RZ26jLN77g0/F3nvah0AfuRZkO+oiF/P9Y++9425LjPAz9aq29T7j33Jzmzp0EDAYY5EhkgERgJkgJpGhLsij/RNl6EiVRJh8l65m0pWcFK1mmZJn2k34SFU1KtkRRImmCBBiQCIIYAoMBZoDJ+eZ44t57rXp/dFfq1eucM7QXMPfsvXaH6uqq+qo6ItxkI0SL3GZ9srONzUCOWDM9U5h3SZPSOd7nv7ZfN+u7yHQJXplffdfj9pWj6Vq9vkeXHZFQcbYR4tSEtRPlE/rY4Yz/jtT/TMWaoxI7QmN3YYT7PZtREOf7bMPNGDWCRxCfir/1+RIKNKmQF+kjyDqFcrS7xOHl7tFuxUMj9579DxVfgx1XifKeYKdc/q7Qsk0VWrWcXLaYQhEcZ8dTOqFVNpUHjx5qtKVuD4DsUIp8m6VOB8QiWCzWrCJkUrZEn2KMGCni4SIfWQIIkAx4ocBqRiu2BUJYrgelMGgxRh/5onUftxnqMQ3ykgf4IVM1EtKkIKBswMJexlnfGftdf6iOhJYMfDwqGEdeUEhzBfnw/1LWcQXysrmGKEKYE6881UEGouZ4QPMVUq95pGLVBemDspFaFLvfxFqRS8tarGVCpEc+u34igs74pPRF5eWBIMwuPzm9IivTdW66/9YtICPRicI2qVMivO4hMU9DDbDoML96Ce981zvwd//6P8Ob3nQfur5DQ4Rp24KbxrWd8Pff/1E8tzPDJy89h/bQUfBiC0DjWpeQLZgfIdE7RQMTGufZwyJaL9BeXRwiqB1xJagOenlW/GUdTn7jyTNoieRUaZViDb5o2H/ioHp8icbIK6175796++UFp5rX/eeao04lGUckp0a2PqLYDbLV0JJb1eiUTv/TV8OyRr0QV1TZjsAWLjqSEelQWiMzi753bS4LqBgCMvmSFcKeZ2EeUYsiBx6edjMoUSGtU3XulNJnv7VBFxQxQt26CtYbQ3f4fmgMJzMqRjnMwepeNVIhHvRF0X/seZaNthgjH4EKvfqXZeWms45sUW4wpHGVhWKDAYOf88yZPCCwRF6uPi1I2o4Ccz39cZGQRZ4+gvarlHVtI2QIFmyyr0fp+XfSdm2fyQ97UPSulModWz8UfeanA+SzOsQqj6T9oWUBoZ0CVOmj03+tzxwPuO9Wvxut8fzXYlxfhPqdvCl9Vgd8EmEe+/6AGU4UdWiEnsvte+NVwT8iBP4wQ2/NUocTJothsFXlvQdxB+I8lNx3IGZ0G7eA9cv483/2h/Cx//DTeMubX5lu+ul6EBLYLuWLC4ga9MxYogY//aHfj/eeuBvdlRvApM3RMqeLCqSNhUmTVcZlcOG1etT+SgRY2ICkOhJIeD11uq9/nb6ANYih+RzvO3sXABs+joY765QbCTXfg4r2DADBsKt05kAmNgylzutrnRnlw1FUM3Awwj7bCsBUSmdPUfYy7BhMcgI9pMtHu4NIVsHKD87KAqISeqWznHEpaK8tlhq+MYVRodSUFWZ4h4kaR6dbVezJVaDzBh5RwjNYhLk7R4lY1KTQNjdYbaN3crygifFVwQxWyVqtBtMrol8QhJDbVWyAqHyS4VaBjugg6AfHalXWjKCBBkeHyGpgY+F9+vlFlHxXRc0tJRo2ipJgh6FaIdbQXWlO/HN0OMVnR6x3lMMh8Fl44h5Co12dCs+vCs2W3+qrjTj5Blu3caTH7I2WKdoZ+YoMXlKeWKwsX2zzlgLKKi9i/AoHJrWPAg+CEUTohvCe3ZnAoQGS2vWFKwDqUOhvuc+pWE1NIg+AP5DDO4x+ikT5Sz0a6tBgAbucA+CO0V29gPvuOod//y9/Gv/dX/ozaFvCfLEAiNA0LZp8s1jcYkno+g4nJyv4N9/6vfjIffejv7GNBu3g0oIaqJoz64RKm0PuX6Hf5NBPY3g2R/5VnmAoPN/S+6br8MbjpxVU/DSNt78Rf0t8KhpZgCXnfwL2CZOcTPii9noUpBlBMf2akIlWnrWrWrhquQFj+EkLtmn6gSeqxVBIX6bxn1UXK0l8xTbRXSN++DCAsIfUGQLv4ccCOXQieU11xjrob88huw5LslsFBzPQia4sZDycs4N6/WL0WZlEmscNc1E29JLPHyHo20R5Ra9D1SFN7IwigjH2C160p3OdqTg3+84iJ6xsZgVFBBrESdDfHb3Gi1SfDpQxawSo/AAifSyLfCwKlXaw63/7Lddf5PH89qZBHCKzW8ZLK9P4SdRoRGeyl8tzPBbnxea0Od8FK6a36HsFLZH5os3a79Kf0i9xHpJcXut7i8ClXg/sJmIc+ksK0O1sDDsIhM0C6ZAea4XWf5Tz+7aw56c0XuyIGRHfV0pvHur2chBlzfoAzGkFsPCUC147vTAa8gIqZjTcZVlo0aMBbm6iWSH86A//afz4X/zTWD24gsViDgbQti1adQxNplV+xDlmArgPzonqc2kz/c0EFNhbeTwy+O6QeiJilPpUe4iR9dO0Ugpj7nGgWcKZ5YPB2Gv4NYLgEY+KvgstERq8XXbluqM4xU4n3dfJlErdsQhtk1ZvuDmRD5xtdxXYiifMuYqQ50YU8FRI4bCMKvWB5JAJpVTYUv5xegM9cM0X5RyloZBUsQBNA7QN0DTpNqMmb4L2IK03YqdiPBylZH3hLRtg+gjFxBxmEAo+kIJYFkyy9NF5iEVG+VCLawDleRv6S8BIwNIpov0z7Hv2wBxpSkbQDbdqflPswaO/5yEo7dOUQa7D02F3bzzEoeNe8w3o9qCWaR84M+IUKSDA/hZglX7JZTYU+UEiX8NHDKjwUJvv65I+sRxOHN1sWojqvMIbbZzTqeRl1ojtLo2LOoOIQ+COeqvHCLHGcFmPEaVzzfIhlOumbpyR9w6KgaH0peOQII30ozHGCNWGeCYYp7QPFNiMh2IyGuqQZiAZPbUAA/3WDNi6gje/6934yb/2E3jHN7wRAKNbLNA0TTgTGEA+E9mgrQEhnXnR4t+9+Bj+4q/8Ap5fbKI5dCABr+s/lUn27PP9YilFLqhsvodV9hDrnlCW8cI+OyDM6ZMjnRjFXYf7T5zBqZUDTq8sOztZj6azXJ0uLfb59wEQTsAiPg2B1uu05tH/WZUpsk2ztRORkbA+gH3ishYzkurpVQw6l3n0owNqio1QYWc/lFwWEyffgxdFCAcojD08+kVNBeoCIwKaRVgBqnGfHX8gxpicUXCKrTQkXtg8gfzJq+3g+oKgQK5G0RsERj44wwAirX404+M9OF+/GYqhAROaxKhGtjs1cIpITmPNgPu+EzHO/a1lG5r58tJ3I4bJPHl965A5jCx4Q859eKd94gFDaPbdhPh45Q+GuPTwff+y6zONoFxNDMcRWP7c/kGkmEIFy+FVUQwnqNA31kUm4ph4wHSeWyaxGLGA6C/gRwmM/ZneptHDChieLnuX8mReuwjTOzUWtbq+AvL51jlJD7Mz6mClDKZv4nwVdkOenMdGESJffJ8ORveKSFK2fBClGBZE6GmCftGDr1/B8TvvwE/8yF/GD/7R78XSdIL5fA5qCG3bJpAlQtM0IhJ5FXKvMjlpGiwY+Otf/Cz+5hd/Hd0qoVlbQ98BoD43hyyKy2LirZp2dwkmykZnz7Nyeb6LvQ7pnB3xbovIGWBEqEwQ0h22sw73rR3HhAiL3obuhzrIRkt2InRsi6w1oY+rYAZbBwFrzyCNszmBjkKE1OFXmQFYbq9issi2R/lEIxsc1OBJOHPj3aEK0YMhBm+Yfc0hqrPfa40O5e8BtCWwy6IIAwBnFYxoM6gi6U2biXEgIczNeaKB8pU6EEL8bM4fh3fe5hhCyDs3rIkMtI6vAmi6LYJKTqRKuGdQ4+6lyJlVAH2fKmgZN8szd31XCMV+0YsonRi/oO5FR9mQ3VCuRO1kWDIMv4sHLHw3JqaiueC9A1o1nA68HTabspUhHryT4e1/NEDaYgVKb8CMNr24IvCVHTGkoBArEBAWKY2fVNS1mMLoSN+z029DP8D9FoFW2jzcRmNlev45cdP8lFf3WsdJWUF8xXYHk8AIlciqYJjsDaJuuDlZ7e/c7iBuBcACsfJccIMejaEu0EzA3IBvbWDaMv7wD/4x/Pc/8cM4eeIYuq7DoptjstQ6HEpC27O13Xdv0zR4fmsD/9UnP4b/+PyXQWtreZ6W0DROEaUBajesEI17Q4cMmjkox5tgAT7TCwq8lYshQnFkxSnoKkAz7j9+CvKT9FvcbWEYE6XRiJLRvfEhbQrpB+ZQyt1XNCzlWYO8U0OuvZNMdyKSo50nT4koRm4wlQZYC4JFHFrhsDVJD3xlSh5C9xQdK0l8hOT89Wpd4RkYP0qLCeAbL6Lj6yYnKA36nR3wfJGZln53EOgMmYcDRtm7PsApPWfz7g1QU3SYeG8g64yxeIQ+ugqIY9YtRH6ZGKWuKKM+tykKFhe2mLMRowSTocxVs1hQDlLKX/KhNADaNy7qkaMpzQ+0vlEeqhF3vcRDhTZeswM/FyV6PohsON0IEVTZHy6veuTsQCHLQoxoYXwu5MMAlAPvfITrR038kCdnWlS3pRsLPqR8EdR1CB6FDqqRjPakNJYmC7aQTUCdwaDcVybfjt/w8i9t7V2Zrp0mLNm3EVOe6WhI65b8KpGe530RcZdIwmlemZCOZWwI6DFFvzkHzzbwrve9D3/jx38U73rXm9AteuzMZjmabdItfE0DuWtXLIUfWUpXUwK//PxT+DOf/AW8ML8KOnII6Ccqp6HdrukqASxTG+zod5bL94f85NvpHChyWQsfRR2uzEWw/uuLo5QwV9YsFnjbyXPwwBWdwGjbgxMqaXwn+vaT54SVNgYXZVRPLprwvniJx17+Gx+IgjHZHbzJWhIw1TWyKEAU1QNuXHiwx+M452U6fsisIqeYTtlDmkrx0v0AcOzYUYvofCO8fVevLuduWvBshsXGRjoEZjFXaUvDGqyUkBaIHP0VBgBsAh7o9JbKwC2Aof6J4Gf5fYMUD0zBFH/tIDFZWOH7TgZspGu8ASiNeIbIIPQ6Z+oAyRpqWs32EUqcq0+HOV3fD4uJUpNSu3LUUERgGiqXWFjfM4Wyq6URgMxvnUoEb98ZbgMWG/JTg+/e+74QegcjAZnPonvqU2k/FWsAvMqGURaRD8+bKFupK9naEnhlDkZwvoRzuf8V4I3BUeczaClBWjzDpSr45fuWtC5rxxBcvKMLck5PJcpP/HEGnCIbG3RoMtAmZrVYLDr061dx17334q/81z+K7/9PvhMExmxnBhBhaWmaymtsqBFg9CqxCDRtLBb4Gw98Gn//od9AtzLFZPlgsj/UOxvIQV6cwYA6G5C6gDB/aK0zGTIiLImzj0Fl3eOnypiMWdouRWfpix4Hl5bx+pNnQADaRvbZitxVbHnQUWebKIiU44mzmbviXlmP5bXvcGA9QCr3GJcmlsgEiXIDzZgUWcVAFRSZd+E8Tk/d7sg+SGNLX+x7+Qyju90APbdOjAoBt99+xnmCaj0suciiCm5uZ99h+8JFcDsBNw3SakCOAAREYXa9zLIiTY0VK00qzGxl2HpbLvjpyuyRF954wyN8lTYIWFkCHRHIaXSeVN8JbWbUY5QWajIrVkRaxpLsjBUGq1RskjQDuXG8AoF1QQir7FqaIlr0PFTAg9YnXqwPWFOTCuPP3libhIb8oPC7zZPm/nTX8Q3mPMnYH0YWyLPXRdps5VhEbbwQ+Q7zt1mWZd5Lh/NcXRBni6OciPESMPDXQvoIOK7RQGwvOXqcrASZFXfJCgz2JzopnkfDRUuZmSpF3jmMTpXLXxRh/DAaGjAa7jGhdO3mYsGYb6xjcuggfuS/+nP4if/6T+HQ2goWiw6z+SJFs9SkhVAyL8tsMpZLFnlmIjxw6Tx+9LMfw+cvfx2Tg4fRYIJ0TZ8BiMqO6KpaUI8uEYJIpzFg8ufkW/P4fbNyeIe3a04mfb8Lz6pApLLM4K7H6ckajk1XVQaoaNtgys1xSskmeyNt00J8VlPsapnepjEXP4Y0pQUr2yk9QJggdETgaZ2gQZFmkUJWDwiiSGXRIcyuP0FZR95VI+baK48xWdFPHD0CmrQ676oKrG31UueMATN4exM4ehzN4cPg+TbQyQrjIXCqxnrmeWGWl4ERKeOAP1x2sPCzUn6Q+fQiBAxkxkxkx6ujGhsnWGqTA51FHukbH2mKzXNATKW3PeCNk5XMw7TK2BlHZ7x9fgOkzEVvUYI8WX0ydSJJ2LWhaKXpr8pjkUgX2ECNlw0z5Vr8XLozXoEOOPnPPPCGUI2MdlQlOkM2317UpM8VO7jIU/RHlgE1REKLd+IcbaongTliQK1gARTN4yMyR5e2yOmVOhVynmBpCwgG6Fo2uzLJlScAKnLPxalCpH8IaY0poQMBaNsG6IH5jXU0S1N870e+Cz/+X/8wXv26V6ABYzabg5oGk+kEBAI1xQIo11QipGv4mhbzvsf/8OVP4Se/9Cls0QzTtSNoODtqBOhqG39KlHZbXgjH7HrWpMpfUOLlUvolPsaIwGEnt96h8mxL/VsqtP/IADq8+vhJTMXhld/I6bnXX2djfJnDtR8VIEjE1t9XiFSR8XmJ9i4CgjmprEksyFlhsQMF05MeUFBU+y1Yds2gnuuAkBFGVIl2AMhu3rh82P0dKz4beSLg2NEjzhA2qnCaFFn55D8Bo74HdR1oZSUZ/5vXwbN1UNtq/T7aktKi2QhWI4CGn3+0FW0uTeZJGK7JRRHbXKPQMWABWA0059WSpuzOaDqnSVWNc0u0bw3YNGIUz58ZRImvqisSfej8smeH45CKkI/YvF03GowHbqgWYjytPTrnJuXB8aeMXqW/9XcDNc9zi0zZ3jnJUQBE6ks1PNL1yt9K35IAv9GmpXonIzieAmissi3yoxCukav0qZsz1nJqQ+Jx7lkbDIDddreYxltg6wfkaM6vmlWT442p8Nv1ueijtEePnM3t8XPeQaNLusn1FNfkAZArK2M5AFGPNk/BdDduAQ3w4Q9/ED/+Y38W3/CON6JtKC+A6rVfUjTr14MweoY7LalPe2vbCb5y/QL+1Cc/ht+68gSalRVM+BCo68GNyKQtslNOF0Y5Aa2TP2eDzJfhwK8AntqDzilxrJE+FdsQ6Yj6I6TZARVkZS96vP22uwFm9D0nR8Sbrax7VuwQaAftHwPDgeh6ma8krwWbjg9jj9nT9H3i0aleFaH8IbUnvhzQ6TvPC68vA0N+hEUUo89waDK9HebzC6kSKSlNO0knstx7z504fPQIbnY9qElDM04KfUGqzCQvujnQd+ibKbB2CNi4Fdpcnc92X5zNUKEvE3qzYgt2hALPX196Fp5QrkkqQzwux28BsMJ5suE0RWarQdvqQKWIIGRRh+c9XF4/dKZRsApHmv8KbAxK7NoGM/ZykH4YRlLyYh0DiSlklH0av8hL2+odT2/gs6xUIi1ICg+S+Z3SCccfmGOpYOkcE5R8gzc6nO5szp1ebuU1Y5u/OXkwqBL+cvhb8s34RJFxInBF+vHy2Iy5lun/Sr78Qq1aUQacg2itdWWK8+J0wSfL8t8QA+gdZKV99kQEvrWJKW/hbe98O37iL/wIvukD7wYR0Pcdui7JY9OmGLhpSBfN9Lndzv1JOtm0mHOPn/rq5/FXH/gN3GwXWDp0DNyl+3DRNnBSkGl3zBY7leUjjlTmkaSgw8JSk0Ptdw+uJQxY5ShfV5QKNRxBbkXT95igwTeduxsNNWDZuhQEGqbzMNtUK3FAY25e4JMmMSkvF/CN4WhFlOvtlqAi24E8Z+sMhKtiSFrpOXhRkf5yxnZgRJ0xRlQy6+roEVPgHbm8GDw6p1QpP5Ti2nDbmdO44/Zz+Mqjz6JZW0YvJ/KQi0kVaI1PDRg8nwHzBYAGdOAgeDIFz+egpoWhqWNJ/keocjpti6eywZNIk8CQ22i0P8o5QQVQmysXYykgYHNkUiowtGjGSccuF81AjXEASTGORVpb0CS964y2i0rhaC/n2ZIBlLSSrtckafEEw8+Bw6U3O8s6J6lRFfk51fRbjFQdR0pR6nvrLxj4BsOloOPnwM3SpdW8xvHBHDVZFwkwqwwNLKaVNJhm0eLI9qZq2WYQQmNFrop+DeUWbVK+Wous/5wJCDoeos+y/d5a5hr974gRotl0scoRtJk40MvMqnfce972wQGV1cWgBkwtgAb9xgb6+SZe9/rX4S/92A/jI9/9IbTtBD2ns4zZ0Sv7ZrVPwfmQitT+hqAnRX3lygX8yG99HJ+8/BiatYOY0irQJRuAJk4usAMwG2ot+tOMgO/gnEzsjcmfyYHoCiAni7GP8CvgEG0vBo+aOPdGRl8O0gR3LB/K5TRw7HJ5Y6Em8pG3+rvzNNSsDDhB+q/XIQ9lic9sPFbnyPCphpUAnP7oAqkiQe2lyxyh0VfFZUID3V2i3FBzKMYNOSEycsxLGvdHzPgTpeX2YMZ0OsVb3/YmfOUrX0PTHI5CGlokL+RACQa6BWh7C5i04K4DHT4MvnwJQFu2KpBMRWdquyseIDuAFGiLmeW3AtAUVM2IaP6Ca9FYu7qz4noDqBEQuezyhwtnx9wVK0+rNcUmIA8pB6ak1og3qgDRWx7X/qQSFA8YL71Ujb44spksTWBDABKrlUNCVz8hdKHCsHYVB6pLDR04h8JmMtrLkRoB8VE+w5KXCx6D46zNYRsxIIQ+CZ6/Vugcg2Hh5nApwBUNdw6b8tYaUogrRxOhDpQyKTitIg+SNuV1FqJwWNjR3IBBecFTsmHTROXGFrCzjrd8w9vwo3/qT+C7P/IBLC9NATAW+fQnksM8IAY5ldsD6Xq8LAdy4l7TtFjv5vj7v/vb+LuPfA7r0zkmR46nW/moA7VQQDFZclzxDoYHWpeUAuMKeSlNspiE0qa7PvDpTc3MBhmE1WRaaLElsLetHcbJ5QP54A7K8+EOLLUdBa3SNik7Rmeheu+axSTR9qkN9ZWNoekej1cXBVt2/3lCqo96oxRtjiWw3GL0SpClilSA4hm9SB1YWwg1OtRcwdpweAFZ3q7v0bYtXv3KVwDdDoh7NLD7W7U8FSJR1HybBjP6m9dAqyvg7W3QygqwtATMF6B2kqMty2dc8VJQvPUd7CIwib4GCz08H0IoRyiX9WvUmdOOzflp7xaRsv0GF/2RtiesMs0AbRFZosdHjuknMg4wh/J9xGnixC4/OVYREJvibYu2VzpC59PdHKp48bpKXLvfRcPww6xClzE5UexlPfMs3yyjyu35L+31dWkvSl2uAgEGx0vDGDdH5/tD6FWd5aIPvbFMacPK5fyDzoln257a0bi2WV8OH3NUiGVkYJimlDvfN8b/KAdhrp5t/plcu4y/0Hb5URbx64gA6tPBFA0RuCfM19fB8y3c//rX4r/9kR/G9/6Bb0NDhEXXYTabo20bNHm9RuJVis68eUwRbT7NDT0mTYsehH/79NfwV774aXxt43m0hw6h5QN2ZR+JXbApgEJlXWdo7cY4N3KQRqBIZT9wnVVSIbYj7IDwHqQ6M2IGnf6otXPpHZnqY4njSS140eMVaycxpQaLzuSrpQIeqZAJKTc4+EV9msbZWTe9FLlQjJS491Vg2ePx6ydAkNXIpNWIcu9a9hjQCaHqvVQAthLlqvGvuA82hu7eedAZpWHohZNruI9OvvkD78N/s7wK7haJRO7A3Kf9br0WCI1MxOg2DXhrE7S5DlpaSnUeOQq+fBmOzc7YZQcFI92nVix/rUVkgBoLH3VI7/nhtMgz44vywHt4JCaWFbSsXvIjNQowZhRJ8wueGbh5xTMroaYhWGj7zEWbo9H1gAYtW+oNMqTgb7Qo2OQWR7uUDFcp4mL8THhyU5yC+n7yfpAUq+KYZc8Ph0YnCmr0FaA8fRWw8UpLjlEW+Fl7rRukfv/O8d47nCU/XIfICEgc2raUg0/MbrFLgRwa6UYeqcRI/4fI2dkJjMhNQUvprFOekyVOAEttA/SM2a1N0HwL73rXu/CnfvA/x+/76LdiOp2A+x7zntE0hOl0ohGsLGhDBrSeczSb624YeV/tBF9av4S//Nu/iY9f+Dq6pRaTQ0eALjewsb5Radd/SgX3bRnaRbU9ilTOkcr5g/rl/nTMstLJkMJ+cnbeyVv1URuakzYAdx3efvbODO4yckhFe2PTPA3B1xjDBa87Y9jJxRx3qGuXYssvqq8c+JOOaxwprQycpOYwCFF6LpDfGaUCjUW5sYpgvoKSVftPQGMX7FUPN9POSKv/uE/njb7q/lfhjnvuwbNPPYv20EGgnydjxg3QUyxHjbpAZo/++nXQqVPAogMmU9CRI+Cb63lhhJ8Jz+auBBf/UTusXEUIFRRbWOKNUsictSabGBd1pORmIJMjwKEMm68i16c2L2z7cKW8TK8CqZUX5vlKo1qAh5Qp5Ru98oOTjEp0G7baSH9pW6R8U9wyApT2pT4qBS4CbeQ5xZ8g/ePnhL2Bc2jKbNbQ0QrpeRUWGd6FDj+W856+P2xOneFiPNfXFYXRU7Jg9CBGgmEPLaSPbQ2Bp0db4SJsky8DoLxQwh0uk9pczud7R0QeMyXRlgTeKBvjgGESK866zmgJaJpkFxa3NtF3Hd789rfjv/vRH8Z3fPv70bSEbtFhNpuBiNBOWjRti7Y4FMcvtOq4R8dphe0knxZ1fbGD//HBz+IfPfo7uElbaNaOoOkI3AFwR1qoM+L0hKU/fCvy78Iagu9bW6URWOLsT+hfx18LABnmHTmmw/2upLBmLudYNS8boDMz2q7Hm4/f5k1fFfQG5XgS/LcqTkTZLBoAaEDheZ8+CXbs9RSiqdVJ1dU5W6mtVv6gsECwvItDYZaZKo0dlj9gXv7DZUL9GEGovgKUVHiZOV3K3PfgvsdkuoTv+vYP4x/83Z/E9NAqwAtwz+i5ATjOv0r5rGU24K4D1jdAa2spOj5wAFh04O1tyFLQYBzJaBmEP4h/KbRTCQhe6UC4iGI/FRhnZbkv+ei9eDB37t3Qbc5Z4KKf2dKT0k7GM9T7RvrcyXoE6dxGcnnshRfxrOChClNqGe5k95sf/RjYBvZlOF4FJyTzRA4OKvvLjQ74iD6ufJTuj/1tTHc8381mkLCKAzNt1TYcACMcGq+pHcim5E5SFCCtb0KfKa+8rEPr89+17MKjl5+ll8i/h/Ep+CaV35VvgUmpk9PZxbJyHeCmVT2eXb+ByfISPvzBb8QP/fE/hg9++L1YWU6R7GLeAQ1hMk1ms20aXV2sPOQUm/V9l+rue7QETNsGczB+9umH8De++Fk8vv4CpsfWsNwdwoLhtoMNT6kX+yX+jI1wGO/l89Dgm/0M6iLfC/0NU4MlCb7Mqhn3BLn5dwfUnB0bHf7vOqwtreAVh487h02cLWt70FVkjFHN8sPiVlfYX+zkLLgiZNIZbKL7yFxlbK7DlzhMQO4/OxsZ7P4bzateUiHe+dMIkI54IeHAg0EPC4x7QLDctW0+g6EhD2SqtUlauWf0XY+eGdT1+IH/9Pfjf/n7P4V+NkdDHcSjTBGOU2eyv5zpIAZ4YwM0aUHLK+DFAnTwYGrB9rYaFdsPmIkKLiqrEbE2ZiOeV/uzo194oFtDPCDodWTssDjObYX5Or/qQqyYsi69kxOG5Gxh6lnPlFVpYjPAAqxlBOXnO72tT+TmdjWiaJlytt/LeU6L7j1PfcTr6udhO5V/lPgQeKJta1Sp2Nfviwz9YX3KigoSYRofdF+qUwNJb55/LjnYRN//GUzdKmPdZw3TEwVGJ8vk6PP8N56yI8pYZ46Wx/DUntDnJgixPk+XT8huwVNwRpzsSh422vzJXE5YnGpRNjGMdNJbhwY9qGnQYYJuaw7evIbp4WP43j/wUfzYn/2TeMMb7sckX9G4yDfyoEly0jT5IvfQRge0zFj06XL4adNg0jT4/JUX8P/90mfxGy98Df2hFUyOngR3aQ5XeAPPGyeHfr7dusLNw3uvw7DVwEOdolyK7MsVPhGcXZFRnSAliE8GP+0LhBEPE6Lcx8l4FIiRS+0Yp1YO4/hkyfShCvY1OoycsNPBFRHqrAV6xWiZke9xzWxk6bAEe+2RVWnK/zH82ciRvDjpXTwKzv5d9A+MAFOYWkOtwLKiSmnqmQxBd+DDVkPCWDxR3vfGPd7w2lfjPe99Nz71m5/C5PBB9Nwl31eFHsZNkvIlWsuXSd/aAHV9Aty+B60eSFHhzk5uIhekcOWzaC7MyxRwgjOa8m+lg/xxg6FID0I9G6gFwIDDLIcCqlx+VXQ0wswCwPLK589vnB0O6QIm+v7V6rWYMF8L1u5hIF0q4UHYp0+FwzsTJV2uMQYSFcAuldk3qDQq0bkSQPNMH25h8QP/oS9UHKX/A2P0r24P4chbiJNU0g9YpOktdsXQWpXOyZOoXEAYBd/LSwyil2XpCpmLTlGixxZRVuhUHpiDkkZZ7HeiCZh79Osb4NkWXn7fq/D9f+BP4D/7vt+HV9x7Vy6uR9dnG9G2kEgqTnEJidK2/DeDLIjwws5N/NUHfwv/5xMPYaOdY3LsEBpu0XeMXgx4yWJFQlc+CpmRtuiBFracSTsgsIRNLtj0JTiXomzOZHv5Nl0UeozvXs5Mx6MR0qkrzZf69ZXHjuNAM0Hf9zoaJjBl5rCw774fKnLq8HDXh52e+yDGg7sfofPlD9e8DB9tPemhFtXeDgZnQGQuKBxEUJz1WHaIN9X+rROTXQn3Hr031MnLLAyOo7H22GKGFOU2kwZ/4c/9Sfzmx38Vi+5IsI8pis11EBnoa5SWy+t78MZmAtyl5cSOlVWgnQDb20DfpS1CDuRsjlDa4drpvHnbAxcNjciBRRgASqVUZniQcgpSSKUZTTfH6MC6VBoZriFqwL2PKITA3O+hXJ/AiBeadK4VNkecohcZr0WRDhBjF8EOwdBL21i+cFCZzCLHW9c3xv5iFTH78kUmvA4Zv3V+2EduTlJzEKC6R7kMD8bEjcq9RMHGHw4yoTN22mak606Ff9pGD8CF8yHyJQDG1jZbWGd9YFtQ4vwsFf07mJMV/oKMfgLS6n/rr7iKmgMY24Ip+TmBf9O0Kd9ijv7mTQA93vjWN+OP/aE/jD/yh38fDq4uo+t6zBcLMBhtTk+i+8VQqH/kGkRpb9M0uD7fxE8/8iD+wdd/G+cXG6DVJbTNGrhjAJ0gXehfFRWVUdK+K9mrfFLdkfUKZgwYBuReokufCoj9G8yMkwFrb6xDwds7ySJsYiCRpcSbDgJ4vsCrj55OcsppqgcoplMQGpHJ8TjipM8HNHE4yBpSYIRyx11J6THFp9Hf3bcxvDLaUknjc7Yjj7fLgzlI5waVBAKRQdHLd4U7IB1tADvjPZoo/mxLRIyWpiEwU97Hxvjwh96PN7z9HXjwgS+DDh8B9QukzewpN1Ojx6ShFEQ1jpzmaudz0PJyuqSgaYDVVaBbAPMZeNFBOmk4zGmLeoKvw14ArRWiUIEfBQLHFd1Ri8zMO2ESxfP9kN/5LRaqTwB0H6D/UenJiqQ0lgUDouXe2IhTofOEYpRUga1HA3a7MpWELFYGwFaHGDwvv8oHYWVfpFVemfXwhk4fH4FJeseaIR9Q9HVMIjzUyNZhjo/+YkOLx2/BkjKcfoQWZPop8NUl4vKdN7CG6BaJK2LlX13HEKye0tgbA+yvAHCuigA0JHfJMoAG3E7QgMA72+DNWzh45BC++aMfwR//gT+MD37gXWiI0HV9OruYCJNJq4VlilNVQrYHXAFFlRPCZt/hZ7/2JfxPX/0tPLl9Cc3BA2gPHEpp3FWeNjrjAEpB0PVj+QhdRXZWB8UcIAqlOJ0fHAdlc++Omli/OjcwZ8w5SFH1yo7jWIZrQAPGe26/Ay0IvfalBDaRC36eNrKEbPverqAgpVkacv96hrGzB2UwKG8F5MdiUqOXASZMxOZUn73oHhht7zIEN8TSkG+oaySzSXJoWp25A7ALdFSycVFqSMRp2Ldp8Lf+0o/jW7/z90O2fzRZcHsipLOTC+By9ErdhB5Y9OC+S0A7nSQBIgKmU6Dv0/FrWTATELiozRv5ApdSWmuMRlwEF2GSGmz1YLMmqG12jhKzCJQzckX0J0CjxtiXLx6xi1q90VTAyT9YYMTaBnMEXDk5orHoyOSHff2+U73ka30WYVmbzalJ/hMNeBJMzwhPvOMn97uGiE07TRSzMLSuPVZXtKShTEh/Ga+cL+Ii8BgBKi1FnX64zOykrHolLUf6T0x44L8blvbztRSirQIkJJGLuJW2zHu1TYUshajWAy447ZWnPu2P5R7z9XV08x2cu+tO/OHv+6P4z/7g9+HVr75P6Z3PF6nfGgI1Ddo8H8sZRMOCOqeaAMB9D85zv/Oe8R+efBR/84ufxldvPIv2yEEsHTmCruOk687wknBAaBfT59oVcMl6PoKhA3nV6dBnBVxL/2XWaX94MyZlaEicP+e/XBZadfBcIobmD/BNALjH6nSC1xw5lUYESC5mqANSDUiT7DjHQkY2hB9FE5UkKdNjWOk4Ojsc6Rg+KudFLR6PJhkdgtUaw970m4d/qzkMDY4QGRoEY543otEzKiiptdInLXBwLDoohYI5H53W9fjGD7wb3/Kd34mP/dIvoz1+HE0/TxEtGoAa12Bn4TId0sHCXOI+RbHdIhmkJh9Sq3MT0oasIE0z4J1TP8cRGe4k854cEPiOD0ZZhcgtlsl65HCm4FehTKargyQCuImnpCCmZ2sEQxkfmVPTRTAh4jeeBIdgYGyHJaeItFQkN2Sfy7BhTsefweMAL9cfRh4Ac5ik7MDD0rFQbyU4EbXH8Jet5KITdBhZRTOWpX0OCnKhi31c+eJcDGnyPJcFNwECwvo8xzZbHKiRu+sT1w59xVnCB+0E0ulO0nfpJlnRn26+wGLjFtqlJXzDW9+KP/Gf/xF817d/AEePHQaQTnoiSttw2kkD7pNRlGMVZQiRs7PQMaejbjzTiYGmwYIJHz//JP7HBz6Nz5x/HO3qMlaOHgW4Ac97A61cnuqOiwrDX5WxDPbOwPnqAyB5ngFqA3zd8t6zfCBpBfDa0D7bH2+npV6RN5jkaxkeD/z+dSJw1+P2g4dw+/JBgDmNQAgwi6NBCG1WzHBtC26I0IooVuqElg+PQLuwrGYJ1LYSCuEtvttbMMdhZC46tJ6XrZKynpryDHqQ4k+AY5V4UT5rxWCEujN6KgaOIawjA5lR2dj0zNmDZbTU4n/5O38Vb/rcb2E+n6NZmqQbOaiBXKplfLCOinObcPNoKS336b9kLPycnftc6A+RzSGWna6K7yKyEL0x8tm/XhDVRoY+UrPpoyL4OWLJI/S6rnFl2mri/Fm8YdUD1mIE/HUVpo8sFVDTfFn02IUO95c5VZXv8xVAH6xMrPEYRstASIQGH6kyw2/P8H2oKuC6QfvOxCb0H8FGBaRJcXqGqwBsztMgNjVekhgEdj8ZPzWPqmXq0Dgn6ukBNGrKZXj6SCyk9rOs25B+IGW6RMbl6EQZbRN5++B42vfpTP4mtW/R9eg2ttDNtnH0tpP4ru/6VvwXf+yP4h3veBOm0xZd12F7ZweEtD920rb5eGvK++ELGgRw3bs+63xDhAUzfv3CY/ifvvh5/PrFx9C3jJWjR9AsCDzvwU0PbtRaJaDg9C20xa0iVzNWmLCSP5LYuYtSWCF7zumT8rM94EIuQhZRbFe5PzTCLHohlx7QKsGb6m7+yx3j9PIalqjJI4uEgahHZjmkKJyQSr3eCfdpqEJbmb4a8ZZJK/1k2VxZOcOkBCByCar+fUDj+txsSZR34mpQaIkqYF0aKQDlodCh4HoFMNDwRghoGpnh6UHUggDc+4q78FN/86/jj//JP41++Qz6pgO4TQtte7aFUXIIwEj7vJdn3p8YqfSbdAT63i2MacxgMgcAEWVMJJSgY3ULaGo0UfAx9CP7XBRBm5R7qQh31JnSbl9i2argrjhyvzlGlZGsXzxk7TeBlkVyjNhGS2fGWioJ3r6sWvZkDyKEqMoxGGGlwetDKr/UHDFqoqEOkYstE8FWsJnFUrDDO8fgEDFWHj/XaF3GrglZpl3TQlRdDJVVa6LiY+4XP9+PUP5wgZPIOlGfjnYE5xEmSnpKaV9sv7WNfnsLkwMH8A1veyO+9yPfiY/+vu/AHXfehrZJC/a6+QIMwnQ6BQDdG6vRk2sNZ1bYDVJJB1sAE2rQocenrzyFn3zgs/iN809ge9phcngN1DVAB/TUpbUggee5LGoC1PoFQ0EVI3pU2BuUODgFHrhTnT6jDGsaj7XbU6MHVXIvvVzYfD3b0oxLwJnCJqU1L8i2j0AtgTrgNafPQnZ2JBK9I2FVsBaZnQUNVsYfkdcyVQkXXJSz1yhT+pG078Rp3I0cgi6QikZAItd65prlrhReyTxKy26NqmVmmCce5a7I4pDCCNOimnzIAQCNAgV8/7Mf+D785md/G//kX/xLNEduB2GmQJ1INsHUuTBI1CeAHn0IrQuOPwHUXDQsEQASwEtlpQGElBX2VrrUAbi8Flr5UoY1yQw3c3Yu8mdR7Lj9wpQtRXgZsHUI1+rlDDpatus8Lc15yMEQgzW/KryAufLemwWK4pr5Uc7leOfCR78KJUpDVl6VmdTvfmiYJJ+ijKQLr1Ja72Sqo0BqcLyHMhj9EOHyIwJSBpn5tZ/KqKAwrGLN+jxKoO2k1P+97aFlsQ3ZQPs+suF4hpdHD7qml9Ju6dGgAUh7TPsEuPnGnZ4J/fYM3eYNtCvLuO/lL8d3fNuH8H3f851485tfh6VJm3WmR991yr+G8t5YAdrMHDlzWKiVe2VltIsoHV7BzPjc5efwPz74W/j4849ittxieuwolmc9ujmD0eniSXOPmgS0bmTGy7Tpl/VDdWrNGTA3Cwi/MEgfAaYgI8XvCmhSBoBO5CXRabaL1UFr2im468DcQe6otmg240aj3BWC9Q8rKqW2TTrGu2672xLmkbABPBIZPTAbVF9sWDbWrVORsgrvX7nsP/vo1xldgZ0wAlt9guEBAEzYSjNaPfYOnpGxb59iBOJFn+ObXWgcwXQz6vHdsKhdGOIyNI2dLNR1aTN60zT4yb/zV/DlRx/BFz77O5icOIO+m+WzTmW4FUD2um1owoyYURgN4oAmlh9ksZQkdWJHw84LN+LAFqyEqM4bF/go0BRO02RJiuIgToHYVgOHogGufaz2Rcp1o18gBz6BFcHoSNFuQQkyCOih/qTNN2Puy3OclDnhnoMRI5dJ5Eqrk6Y7fnKfrlobDv+xZSOjWGXQleWHW6VineuvPdrNLhplyye0KZecgSX1RqJ8KKALAZKfsgEWGZFQLzhskb/mXBg/yX4ZZDO9ZBATCD1IFrlkMGdq0kESNEXbd+CdGbBzC0st4d5XvRLf8R0/iO/61g/hja+9HwcPrkCmg+bzdCmAbtsR3XK6YPRQuuou91RapJMkfpL3i2/zHP/+/JP4R1/5Aj57/inMJz2mxw5h0rfoFgswgKYhZJSJpp59xzs+OSENugHrz/KzdS65r9I3vh8LOaKYR9HC6Q0J4CPLC/fJ6WKJaXsQWnS3bqGZLAGry+DFLF8l2oOphWxDGw4XZH2FrTNpwCBeYBUN3nbiNACgJ651T3iGI2SkfLKvpodwrGHL5AuI9qfAFPeD0aRvKvoQqdV/cyyfI9tRYK0ZeBoKgfst0+za5QRrQIz7bWB1YUNeAgwD7GTdkjEYLiiGvAYOQBZ+25dH6Psenbv0eXllCf/hX/5jfOi7/lN8/eGH0R49Bu4XyUDI8Ip49AUomH2ydoaIJaOq2jTIBxcZZPbnkUmVQFKFjcOrbgWKdTVHQLXy7V3pCPhSzADmvodfJRo7ZLD1ZbBSRrtSIzChNQG5pfc2UocfqVF6jMmINGRwEf7ZnCoUnDVCzowX8C+lmmH9YTTnivUELdfnmtbaJnyRSC9GszG/Q0MzWkKURIEuEvN8V1nR5Nbvdmxd5rfoMDkyKlG0kemmMdxCtoHARMR3dFs7vTyZcUxzsA0hR0xtOolptkC/uQFabnHvPXfjQx98L77r274F73vvO7GysgQg6ex8vshOEGWglftQo/MahhXZItku25G2IUzaZBJvzDbxi089hn/49QfwwM3z2JkyJkcPYMotuGMwd0ndGhFHF/Wo/IhMetlAXigl+m+y4mM6i6YAivMkzoGxOr2DZwddWBSocqK/yG+5jAZyo73Kuv6vm+PUosV//+6P4O9+/mP42voG2oOr4H6BtJ8lg2zTmAA6WUgRo+k2MYBFj6NYwsl2GV2fTvJrSIBJmJDjeDL5HRvitdEB0xtyHRLsv/tcjWChRShYDkYQUAHm0jnIuYUPbhjZozdrYQPc5pje6LfFNe7PMK92RhQea38EyABo+R8mwvZsG9S2WG4nSTDCyThCuyxAGXofNR9GhpG1bmacPHMSv/of/3d850d/AA/8zufRHj+FludoOZ192jGhR2PGWgweJ/CQ6NP6XYZhERwEUUh5EYXD88VFnkUTzM7H9vp+CR8ZgLvqbHhuuDeKQwMunoDa00w/gUJb2IrTbyIvwoFy2FPo0WiOHT2euh7RyOfEKqHB6XJy5Bhv/VYsxVGQl6SuXeTMgjuxS/Oza52xwhqoNoGNQcHpifooXAo6JOV650Pzi6mFnuPtI96SX1A2ck4qIwe55sLJHuirO87O6vPpOOtjPpeYGT1LBNuAqAWY0W3vgLeuAcS44+Uvw4fe/xH8Jx/9CN759jdh7dBavqKOMZvN87GJDSaTSXRmvJPtmgpCXuRk+iZHTDY5Gn52cx3/8pEH8U8ffxDP7lxBvzLF9PAalrjJflCvx6dSH5gdGOP7Vepm98KmKJzBD04IaZ95SVDagWKhj9em2PqoC0KPWsckiz1bvdSAmy79tpjjQNfiH3/TR/DBl70Sr1tbw4d+/h9jfmgVDbXpuNuWdBrOyig6QEQkV9N3Pe48ehSHJ1PIEH4RHwnVIZodBnqZO35y2iep2P5QoAsQfLRsozN1rNCKnNEM3Gckp8rZl4l2tsiM+69avHhoYh4dX2NU44mo06lzQzBhCYYlp5M/vv825gv81iNfxR1nTuANZ+7K9052Kki+5jCZ7jxDGpQMNG2bAZdytMs4deYUfvkXfhbf/4d+CB//lf+I5SOH0VKHvu8BbtGjhQwjpSq8ihcCqNU5GrNxjSDp5sUKIRMPTA3bAGCL0Qct38tZsVq3iGx8ZCZKr8O2LvoGLArSwAzWFs97G/LM9582rlpHs587EU9MnC7v1NlnAwpfjpdL6/80DMwuY8ANtXs+TwE2rk8G82qZET5SNN6boxEMbs6nGuD701ugCtAmTC9+kOZIf/uOL3DBpmPKRUq+rbENNu/J7t88j+b1mEybxag0+c5oIqBhxmLRo9vaRrezDpou4/S5c/jOb/n9+O5v+zZ84IPvweFDB3O39ZjNF/lIvwyOehGAyb53dtSHyf0pc5UJVxJfG2ox4w5funQB//TRB/Fvn3kYNxbraA6uYnL0EJoe6POpTzaPzQhdJ8yE19PScXMdqMc0FgEKeafc+pQdveHxQYhaUdJBEZMxCvmJBBwBsB/lSos0mTqAWvQ7G7hn5Tj+9Xd+P15z4jT6vsdb7n4F/tq7vx0/9ju/Aj5xEtTNE18bAjfmOvsRBeUXc14TwOhnc7z88EkQ0r3iacRmiBT+/I1gA10feNtnixYDC0NfBLzyzpnw2WXPFZRU+VLsrbcHFfWly1eucLr9Jo3Rz+dzHDh4AEePHBk0JFBAHsk5/LQr0NY8jcJr3u1R4STCixs38FO/+Qlc2LqKP/meb8abz9yVEuUhJVCek8mGoqHhLR2h7CzkRgrn4lJ9i/kcP/4Tfws/+fd+EgygPbwKdB2AHswNerTo4U6ZAoC8MAMuSvCfzWzt0n5vLBGNdpizYw++vgVaqxpyM4mymjq8KXKi6G9n5BUYnGEIK2xLdICCdqzVf0ME05BfDIa9toLHFcAPnZo9JEe/N1mRlIDCrj3qZOTXg0VzQq9zmkqd0T/eQBb9HRyCsn0IyexlyFCps3A+h3pq9MA5OGK6kwiTjXb4PEgRrA1mNuiRhr+JO2C2A97aQD+fgaYrePvb34xvevd78OEPvR9veesbcCgDbKqS0+KmRqYGbEqjaRqQOKWaPvGeM6hqxOvFI8vr9W4Hv/jsY/gnX/9dfO7C01g0HaYrq5hMltMJkU2aS2xy1K0dqQKSeSJ2I7BYANV/w8A2Bi0rQCOYobFLIcIHGuipYo8IKZFuSQreepccmj4v6OL1a3jv7W/AP/um78CJpVUwM1oitNSAGuAHP/Z/4GefewQ4ehToGNymsgPWKLsY1AHU9XnXRY9ufR0/9Y3fix+497VY5CsWW2rQEqEpnKfhyGQ9jo88yTwcDteFXGNWt2IBXaYkTBsbG7h16xam06naGJVLifQB+3758hXmvk/eBacN3wcOHMDRo3Ww1X6vEa4ryQqPy2uzjzrIM7XOAZuLyGUWkekCjJ/+4mfw137+X+Nb7n81fuRbfj/uP35W61p0HbpsiKUzY9RgrHWjOarY6X26j1Ly/eYnfht/4s//N3jiKw9gemAZS8sNuGMsMMECE/R5T66CmhyGkT3K5PkZ8IYW+iElB8gedGQRit4fK4beGelyRa95wTaSYMbSzWkC2m51T8mIKAHeArjGolu5n9Rpno+w/MrnMAzjy87/sqQRsNJypF3p9wCgri+DnBHlFdJuzlbTIJQZFc0MvKsinFEb+c9xhan2he8faH97qA99PaLxaogVx815CRd/SyWeGdqHvmVQXRB++XKGfrCBbfEWQJp7S6c4pfr6jjHfnqGfzYDFDMfOnsHb3/g6vPed78AH3/d+vPUbXou2bVWOF4tF0reG0Ob7Ym0edkCJtlMcHNHfDowuy2JDhJYIPRgP37yCf/P4w/jZZx7G01efB68uoZ0so22noC63u5GOBtKSHjff7mTZO1mJ1ezymSANFztFfU1mklQd/BSFnuIkchb0VNJHPRIh1iH9JncuiR0SOrKj3+eh/W4O2tjAD7/2g/iJt70XE6TjLCnzryXCpG2x1c3wzp/9KTzKC2B1BT06B7ZOmhlg7kEdo1l04K5HRx2wNcMnP/on8cYjJ9D1adSgIUKLGBBJeQKucfRl+HjxVwHx+BM/xn4J9bpUIluhEsL6+jrW19erYIvcHiAdC6xgq3e7MmO+WGDt4EEcPXI4GJh6ywY0lj8VmhqtRzDGIZO8LoE+CrXN0zR49PJ5/OC/+l/xyLOP4KPv+hD+9Dd+B9506k6loe/7dAqMmHGiPMUbhyx1YRKsfMC/T3m2t7fxt//OT+Enf+p/w+aVF0AHDoJWD6KTNWd9l/mStiwwGrDsnxXADY1jR0TRuQUXyJJZHhhYWX+o9YQOqxWCB/nqIhxvMHy9ZtEjMPsFOgk84gYFM0jJaOhQD0F7RJTJrBMM1QqCzXkYjgg4DI08EHTKBjlkM7tZPJbQVlP6ctnK9ZFPnexAowdd/Uo0IM2MMiy9VlvQNKjT0S/tE3YI/9llZvu9WhwSx5PNln6jdP43NcmDZ4DQgWc7wOYGsJhjuraG28+cxVu/4S344Hveg2/+8Ptx9txp27fODO57tK2c0sYqLzFSqPOSs3PFSAdONKB8lGLiHQNYX8zw6xeewT979Mv4tRcew8Z8He3aMppmCYwJ8hU/Jp+ub3SlsXMGa5SYeXDgL8wfy6b6bj3m+7vkfkVAht9VDLOOEJLDT9DtNwLCSY56NNyg397AYZ7i773zI/iee+5LtPSsFwLZVXzAtG3x9csv4j0//4+xdegY+ski85qTDVBzloCcegYtejD3WPRzHKNlPPD9fxonpkvpQAsFWyrANjWmZHscOjYtNTuSwdnZ772xzDlKFJQjsFhs7Pr6BtbXNzCdTkAyakqEtsn2PQ+rU5NidQNb7tH3FtkeP3qkDrbiZA2ahmDlakvYB4rr01MEnzgMMwRdBqPr032QBMKkTcO3f/NTv4i/9nM/DVpZxgfe/G786bd+Iz58z2tBAPq+x6xbgDmF9m1jAxYKMkl7DWgzIHi9Qfa6AcIzzzyPv/G//EP8zM/8H1i/+DzQLKE5fBiTSYtWTmdkQo827RMEQY99VKvG2rHGKw6dbZGpwyBJ78HP8BDxE/tiDIPBkFOIpLwwzKzevDP6MjeT33lD7sHXvHMT0LjC1yJGzsbBovX4u8qLcwR4RBlEQf0qWt82ScNAGtZSTnnHQNJwHpkwgPLG2K/KZZFVQtyH7BTXR8AWmWfaxDiILkgfZ3Q0nhjwKH/Ytdf9qCQFZ8CMueqwd/bye/K/Q4CW0VBeOdokme6YwPMFeDYD5ptopxOcPHkSb33bW/CN73oXPvzB9+Dee+7GoUMHtI/6vkfXycr/tNXO1kqgeOSdGFGjnJGPU8wjCg0IS22rPH761lX8u2e+jp9+9GF87eZ5LNoe7coKWkwSt/t8labTG5tWiG6jTxScS6eQ4gSJwKjtCGDhnSAzLH56xeutHn2ayw4azZZGKyEDO71FKgOBAC6L/IOApgFt3MCbT96Jf/K+78YrVo+i6zswI0WzWb8XSCOJDGAKYDqZ4p888gX8mV/7j+jOnADzXPU7tbnPK5y7tACrS9HzfL6D+w+cwCe/77/EStMqDxukyHkItlAbYyqmAhz8jxJH5ImL+4bWsfZozzPycHS0O7du3cLm5pZGtnLcZ3IOcz0S8ULAll1kO19gdWUFx48fGxBWPuQV2ymDEFoZf4r5R77VorpalMsse+SgW4CahvDolRfwR//1T+PhJ7+CydoRnL3tHH7gDe/A97/2Lbhj7Vg0ZL5OhnplXNQ2eHIayl73pUtX8PO/9Mv46Z/513joC1/CfP0mmnYCTFeAA6vgdgncTPI8Eun5yMTJA+dequdg8D0Q12hQ/QwKX3Ar4q1xuCg2OjsGgsP25/JJlNwBD5GNfElOR6e3+Wq7vE+hVRjRozOWXst8/qBw3liW391ws3kLoe4EbBSzB/qGj1PL4W+G7OqwyDBw4o8D2+wIJcAvGy70yRvPDD8nP1BNo19kWMxu8iTzQRKs/ElGI23JYU6LnHi+A2xtgRczTJaXceLUSbzq1a/Be9/1TnzwG9+NV73i5Th9+kTgijizTdvq2945chHoXHPU6aB8cA+j4UwvM7oMIGLYNvoZPv7C0/hXjz2EX3/2SWx0m+iXWtDKCggTUN9DEZCHfeWdROOm77QKduoH+0Xhl31S7yrAgGnPxzsa9qRWeHCXfpQ+JVCT12ATpYVMlOYyuSHQvMeR6zfxR9/yjfjLb/kApkjbqYTShoAmf+7AcvZFAuG8c+NPfuoX8NOPPoD+6BHwfJZclK63U6k4zdXKrUez7S187z2vwz/98PdlJw4ZbFNd6VyMIeDGhg9tUpVBmjymHzjw5ePfSxcpm5PQ3Lp5E1ub25hMJ2EERg9QyXPjEvGGyFYWSC0tLeHUyRPwS/+VaADh4HHxPJwgBhB2jHEi6/xlX2YhiAXzok9nP3TcY9F36HpGA2B5MkWHDj/+az+Pf/jrH8MtmgM8wdryCr7jFa/Bf/H29+Odd92LaTNBx4yu73QRVIOyv7zRj50hxpFAeRVziiwef/QJ/O6XHsLvfPnL+NjHP40nnngS2zdupLigXQYdPACaTtG2APp0t2Xf9eg5n1wDW+kLrziOiWZEje8hgsJQWNWYC5fdiIPscY3eowxL21/AhE3AyUeQlBGVK/mlTClDIkdkgy7AbAGfAI2kIxdNRoUZRJgELTdXaLKjbCKjKYT8EbStub695pBop7jIO47mSHRiw/zixAjIh/Q+Qi0jYWultasS0Rp/XL/AaHbqBnHoiHPUmlcLJ1oY6HosthfoZjPwfBvt0hJOnj6Nt7zlDXj9q+7HN3/4/Xjd61+D0ydPpFPZwPlu2Dn6rlcj1MoKYhlWczZC5z294WOL0JgZPQGd9Gvfo+U0bNxTg210eOjKRfy7J76Of//s1/DEzSvopwCtLqOdTPO55I45VklakOPrDYaeQ/dqLu+QWdiZxUtGZJyusOO7B3YWlw5wE6lxZEjrSWk0lchOdkCSucjwmzu44VxJlnVO6JlkZnsDt00P4x++6zvx4XOvwIIZHSd+NGILfTDFyMGNs5NEmKPH+//N/4ovbF4DVlZA80VuokQQedFVfjdfX8ffePdH8Gfe9E5wnw4FIRio1yJbR0Jq+0ikCsdeGZn072plFtnUrdHvXJSVCMD1Gzews7ODyWSi4NrIdAq5BVIS3V6+fIWZ8wKpvsei6zCdTHHq1Mldo1qp0I1vqBEoQckL8pgTF2OR3V09NTk5S1pxnJwFBkB9GpZC0+ATj38Ff+4XfhZPnH8ezeET6DbX0S4Ybzh7N/7gW96Ob3nla3D38ZNQFen67G2RuFypNrYtSTYZ7pwNZt1Yn96l/PP5HE898zw+9anfwSOPfx2/88CD+Pqjj+H6hUvokYdZVqbgyTLQTnQFZd93KcLgLu1L7Dh5pfmGEwblTeQEEwwHNqN8K3phkJaiUEmyEmzNgkAWWMWITIrzAC2g4USC9J+6k1M5OSuVJ0ULwLumFA4HFUMV5cxOzYsx8sMX5bS0d/DUtHfwozkEoTwU6uIMuhp8V8wAMLUAzxsx5L2Crw3HN3rggA5N9x2wmIFnc/BsG5jPsHxwFadPncLrXvcavPENb8Q3vv/dePWr7sNtZ09r3Wl0JjmelA/7KKc0/CKSOGQqxaQ26KlO2b5R/k0ANznFhK7v8fSNa/gPzzyGn3vy63jg+nnMeAY6sIy2XUrD3HnxTVK0wrZw1ByR6cJnMf6T57/TJv1YhAMqOk7YVXVyvV5Gcoey68+6BY51s9BgCpD0LCeg3PYEtk1ypjbX8ZF73oa//Y4P4tzyGjrWc7QUZH2/aStc4NSD9WrSp29ew1v/9/8J62sH0HIDzDugccPo2vA5eHMLH//on8I7Tt+hdoVA4VCLYBHIOLvvOdjyKQNALd4pXC2Nw7WiQFy7fgPz2SwFWhLRNhbhChZou67krT9yTOFi0WEyaXH69KlqY8YXCZghiiSVDoF1VvAwXIfW0tfoKCthpFXDXXYe0lxui/X5Dv7SL/4c/tFnP47FyiraA4ex2LiFbmsTBw+u4T0vuw8ffd1b8W2vfDVOrh6ws2+RhE+PAc2tDEZDDR/nE6iS0yLD2pNJqwegy3P58hV89jOfxyOPPYrf/PQX8LUnH8XTjz2DxWyWTqdpG6AhtKsTtAD0UpKmSYsG0aQtRk0LzgcDBF4AkM36XjniiEOcGxOPmxNzg/HRYgtECHOERWTmIzKQ+vr6XQwoKjLgKrT6LFXsdGmLN42S10XU7gdE107KN0DTs4xdBOiHaT0AC79khMMKJs8WZElyxsK1T3+vgLgvxLXLWW1HmWQhzZqMbt76loHWIgdGN+/QLxbotnYgoyjLR9dw+vhJvP4N9+P1r3wdvuvbP4BXvuJlOH7sSPbtUn45vUloadvs1fu1EEX/1oCE3W/MrNv1GHlxTmPg3PU9Xtxcx688+yR+7tnH8Bvnn8LmYhPUEtrlFRA1eb8mQfb7pL6Tqw8LXqqkmyxSdr7Yp8vOA2UPwEZMEM4almjT5t+heYP8S4exC05YV6oEHoWg23MuH4OY9sZ6PiewNRTucmsa0GIHh3rg777je/CH7nu92kwBBgM6J+de3HIfdcxYcK9z5W3T4ucffxh/8D/8I7QnbgMWWS5Itt8w0BD6bobDM+B3/8iP4ezKgezzSb0umg56J10wYITxyMuS0q9dV9F3a0vtc8S+QsNyP129dg3dfIFm0oLQoG39nK05lRKU0ZU8Z9tlgEjLvIEzZ07raUqRThoQJgQVuyKHT9VzQDQoRV1+eKkGziUnS2VVownGbz35FH7o538GDz//BKZHjmGysoLFzhyL7S3wYo4zR07go/e9Fr//dW/A68/diUOrq5AjAnUVZm6lDJs3zngxm5CrWSdrR1y4k37rGdiZzfHwVx/HQ488jN/9wlfw+OOP4asPfRWXrl7A+rWrqd52CWhbYJLmnjCZgiZTMKfoJF1W0KdV0Jz2OGY9yI6ItAKuNcN+MHWPvw97u/iR3AffJwHsfG4BccrGK74P6QN4OIOteaC2VTI6W6bvhi2m8EeMex3Qy0ZXlFHpdMociRg+bLSW9EUAzbKcwdPa4+dzxfim+VXIPlTu0xwaFuDtGbCYA/MZ0DaYLK/gzjtvx32veBVe89pX4eV3vRwf+KZ34OzZ0zh4YFW3cQGs0aV48ETp0BfvFHkDo20S562IkNLpgLYK3pzDpEeU6WcAF2ab+MTzT+HnnngEHz//FG5srwNLDdqlJVAzBRZChwBHrt05Sp6/POjaso948FXuo/UOFcqPY/atfIIDlZMVYEtF0lBkzpwWOpEugvKykA6syHrSd+D1G3j7qZfjf3v/d+M1R0+rrRT/TtySAHIVuhmyKE3A1mj685/6GP7BA59Ac/IMaL6dDhtCum6Q2wbdbAdvOnQGn/re/xeWKNohkQEDfG2l8aogq8SjchHkgHnq9LgmgUMZZdlVNvQ9rly9Cu4ZTdtmkM2LpBpbmUxOBm2BVJfAVhZLnTlzBpNJW4++LZyLprkAvdrnKmBWGrrXU4tsS++Ls/fV5RWn1DTYmO/gb/3ax/E/f+KXsJg2mK4dRdsSup4x295Bt72FSTvBq0+exkde83p8yytfjTeeuxMHptN0Shsn77rLNLSZyWOCqluURLD7tOq77zt1Zlo9tQppKwSA7e0dXLp4BQ99+VE89ewzeOrpp/DAA1/CY48/hWvr17B16xaomaR7EFZWACJMVqYgMCYNIJeYJ/zPR+PB/ycdVgeTilx75qu1ykuI1JHyEZ6Bl/yW+ZPHvLjsxwD2pidDLxMQYJHPIYk7S9bPUVMhIyI07OgP+1R9kWKR2La8KDU1kPUKUQFUAYOwEM6KivqQmaG956JVAueD8LNN7dPc/2Leo5/NgfkctDwBzTscOnEEt508jXe++204e+I2vPKVL8eb3vB63PuKu3Ho4OpAH+fzBRaLBYA0r9Zmo1LrD9tyVjhMni9ErsfyucQugm1yVJAuA2Bcn2/hc+efx//xzKP4xWcfxeWdG+jBaJZW0DSTNJfGPfqebMiazBikoTyTNyh026pviPzKsaO+v9SBs96T28a03zVtrsuFU2H4VaPZOCDJDlTJ3dwFdnaEZeV1LtcSACD0uW5v3PVgyp7Asw0c6gk/9qYP44de9w1Ya+R4S+/yWnQZ7bg0M9pzlr/5s4Buxz2+7d//U3zm4jOYHl5DM5+BGkbXEPq2wWJrE99/x5vxr771+9IK5YZ0ygCU5233gQu1oe2xNMpDJ3yiMaFd/mjdUHccBQSAvutw+UoKhGS9DpFt+2ncFJ86MmnONu9Dzf91XYczZ86k4c8R45NICC0LvwVPo/J7mbcawTq9VaOuWQpkKB5drcxpWFlGVdLmPsbvPvUU/j+//O/wqScexfTIUWBlGUAPXvSgBaNfzNFNCJOlZbz15O343vtfjW959Wtw/7HTmDR23J8esoAkNJ0b/tF5D2dQRUiFbmmXrMrsmXWhlamVGfPtnRkuX76C3/rs5/HgQ1/BpUtX8fRzz+Hxx57E1etXsXH9OsBdqnM6BYjQLE9B02UgR8JoGtih/33yqJkNaAbjVuSiZIsBzAuPaWO3FB68d7Y03bgH6RPWvG0epCl/GHnBwyRUJpBPKock/3eRkXc0o+MwfGy+VHitJoMZ/sYWzvUlmU17tImQgJZ79PMFiDvwfJ6G7GYzUJP2qE4OHMDa2iG88lWvwF2334l3vfNNuOPsnXjjm16DE8ePYe3gKtTZyfX1XYemaXWRhxh9H7kOgTa32QOS6wBm453v/uScyRwhQ+6RBoArsw18+vwz+MWnH8enLj2N525cwXwVwGQVbbuEvKghT9NwWFDoh/qFXgWtPUQs/s7Fx1If4PrenD7xQc18FfVSBRdKtslrsZvimAodkt6N7PQqexQOr+C+B21v44NnX46/+tYP4g3HbI4dbuopkBhGZQolka8O/DmPUKT5WwY1hAvbm3jrv/r7WJ8Spm0DcIeuJfQTwuLmTfzNd/8+/Ojr3qmXeciuEgX8ERoGUWvBr/BkOfPOTMHywm6NPObxh9fdYoHLV66maLZp3ErkPLqj87aAnIlFV65cZQPaLu+17XD69CksLy8rRdoY9faEhrqBGfVIXDs9+Rw+7aUZ3rPhcKamn6PzUSUjCYQOezQN5v0c/+Izv4m//Gu/isubNzE5dgRtD0wWHUBAt7KEeTsFujloe4bV1YN4zZnb8b333Y9vfcV9eO2pc4HSrsv7eJGi3YlEvFQRIjEY8llaI1FwNnIy90wAJtOpRhdwbel6xubmNi5dvIxHn3gSjz/1FL7wwJdx9fJFPP7ok7h4/SouX74EzHYAaoHJSjL4kxbNdII2b8qmtoVAX1gdyjav4wMxdt8HQFN4x6HvcppgGj24FI6V2HNvvMLtgiNPiKOc02b1AZGILMLMMa0k2mVYKeWNy21AQnjKr0CLHJ2KXUxHLhnwAmnen4F+3qNfLNLpS+Aki9NlEBhLB1dx4tARvPwVL8M9d96FO+48i9PHTuBNr381Xvaye3D77afM4cut0ZGVrkuGSIxE25ihEGBX8DA++tGGJKvyk4G3STNM77KsN+A0t5v1ggFc2LyB33z+Wfzic0/hEy88hauzW+gmDZqDK+mYRpqA+y7t0wxAaPqi0UoGX0eyRZsCjT4iDR0vH2Md7gvU4RqKlvKllIkkp04GJcpVsZJRn1gviZMreSVi0HdOhygNKfdNA25bYGcLR5dW8N+95UP4wZe9Bstyty5kmgFVcHOtrIxOUvYLc/9SGpXoGboFs+cek3aCX3rhCfyhn/snaI4dQ9vN0bXAomV0167jY9/3Q/jAqXu0IvZyVdCzn8g2XMigOgftO5ELa59T+pGR1iAf3oPKz2w2w9UrV9FOWlttn0cndc42R7fSprxAykW23GMx73Dq1AmsrKyoN1F6ORQ+DGMO00EfqcZIr8rGgLWOKe69X2jiH/FkPNgmstkJSfbEGODs3F2+eQP/w69+DP/8dz+NnckC0wNHE83TBl3TYtEA1E5SK3fmoMUCy9MJXnP6LN571734wD334g2nb8OZlQNoHfATEOal5CXl9ugcb8EL57Tq8BwhdZ7KfD5ebcA+101pTq3HrfV1PPX0c3jmxRfx/IsX8MILL+DBLz6EF88/jyuXr+DWzVvY3tjUhV1ESSFpupSqmBC4adPqTjRpxRaLYPcq4JwJSD52tgplwxJhZe9aHxegxmzph2A3Bn4e7FQSy4rCR43XNYQfyp1R7JwJle/0vgcBTZsih3x4iSodNbl5DOS5de4WoMUCmM3B3RxY7EBWztJkiqWVA7jj7rtw9vZzuP32Mzh2+Cje8Lr7cf8r78O5s2dw5PChdJaw9oHN5QLQ1aISdfitR34tgY9ay++1R/pa5bsEL6GDkSMv49+cOzx+7RI+cf4Z/NITj+JL1y7i+vY2sERoVpbRLE3BaME5+k1NS9tIwuEbGezJg36EPtWj8hf3Wr84/As8HDxkf4J4DNL50MLnpUBbMZsckiZbUIItK3BSR2iJ0VOPrm3QcYdmcxPf8/I34a+941txz+pazidy6kBKHTHPJ98ijibG6bj1gotytaS0G+QvfeET+Puf+zXwyaPAYo6eO7SLHTz4B/887l4+nM6sr7Jtb7Dd7xOAliq96oA0yoPZjmjCEh93dnZw9epVTKZTdVJbvzBK1jWoc0a2GrnXucQei8UCx44dxdraQaeU5qg7yA/Rgyc5rhyrew9xT51xx5dZxDjOBrKXifh4sBV+Musma0Y6CaXL8zTCpC8+8xT+3//Xz+HzT30NOHoEk7W0QGRBeRhP5lYprQLuFgvQbIa2bXFieRXvOHU7vv2el+OD99yLu4+fRJOHanruMe962yyuq+88GNnwrOw7K0cNPDgJ2JaRsPyVVXEAbB+YgEQut+97rG9s4vq167h08QpeuPAinnnqWVy7chXPvXgezzz/PJ5//gKuXL+B69duYmdrA123gFziSXI4AaXtSDRJK1HbaZsiJZm3UMFx/aNeLcyQ+G4WhRZQLzo4FKeRAWAn+pfCwYXDZnUGFWSb0VZc1chUht4kJJE/rAuJup7T/n3Z1ymeXbdA2m+4gKxib5eXsbS6gpPHj+Lk0eM4d+dZnDl1ErefvQ33vuwenLvjdtx2+gxe/rI70pFwrt2cnbW03qLLh9IYP5JnLfv+rNHDYbXi25inn9OaDbC5ul7BlrUf5NhEAjAH4+L6Tfz2+efxK888gd+++Dy+dvUyZrQALbWYrK7oNXvJWWZ36hFCu23sQ5ng/R594pCj6FnqsGBT5K5USevti9RcjEyEFC5K1p8HXqQUT06estT5EboBOJNzzvL7PIyehuEpbXMEoW+Abucm7jp4En/l7d+G77nrVemMLJY5abHOWeY5gq7RaYQH6z6IcnNpPrixVgFE6AB823/8x/jc+ScwPX4K3dYGTjLhoT/8F7AM0iuhG1mESp5xuSTn246uAwIGF7AoGfLRt9F3kAPUco7dVRbqJRA2tzZx8+ZNtO1ET4zS9QZqe1M/yzpjunLlCnOfhivl9p9Ft8Da2hqOHDmcO6Duu4kxDMZqF2+49BxqXkv0MQrGF0awTlD5yvKQS9eTeeWyIq9tGjB6/PyXfgc/8fFfxjObl8CH1sDLB5JSNy04z5+lLmsyoFI69m82Ay3mWG2X8MpDx/GuO+/C++6+G284fRtOHzqMJTHWnJwa5KE1GU7TMzT90AO87ooAZqMmQ2jaSrfYoohUOAO98iMrP+W+ELpK3s3nHbZ3dnD1ynVcvHwFFy5ewubGBq5cvobnXnwOjz36FK7duI7N9S1szbZx68Yt3Fq/ic31jTRUKWfUqrETApu0upopjTBQY/cRizGa5CHzpoVqnPdCqSxTfnPl+DaVR4NlwErjtZxfZCcmr+5Oxi3vcwaD5eaSfpGNXuea1IImU6wcOIC1gwdx+NBaOmf86CEcPnIYZ87chrvuugNHjh7B6RMnceedZ3HyxHGcOHEES0vLWMpz7LETcs/2vVoV2ceqckOo6lLVY68mERBKvAtOnThmDmQaSSH8a6QM275zfXsTj1y5jM+++Bw+dfFZfPr8C7gx3wCI0Swvo2mnaCatTaWAk6EXgdfRjJJiDn+iZjjnrZanhoKhDtEXbR4UZNXocHA4RquBQDVHWaUon6oWA1m2MkBpP74FDEDfd7lvGvBsG8uLDj/42vfgx974LpyYHoDYgsZvCyybK2S74yBNEqop878iKcNfbfFUj6ZpcWG+ie/6hX+Cr116Dm0zxX95/zvxN9/z7ejyQlAB291uY4u0cvhbe4LzMPw1tGWXQpwsDdPevHkTW1tbeVovT8U0FMCW0KhzRUA5Z2uXEawsL+PkyRMIAggVt0HjfZqywbVw3Bv5YVOss4Ojsp8hBYclbhGii8zjitOek6PR5Yhm0rSYtC1u7azjb3/6E/ifP/1JbDQd6OBhNNPkeXPToKc0VKh312YlIkZa1T2boZ/vgPoFlpeW8MpDx/CNd70cH7r7Xrzp7O04cXANrdJrCz00KoGcpGILB9TcyR2UKva5frLRhaC/LrL0kTA7sJbvBtJsQtT6e0O9p8N6I4i4lbPZAteuXsfly1ewsbmFjc1N3Fxfx8b6Bra2trG9tYXtzW2sb6zj2eeex/mLV7E938H6+ga2dnawszPDYtFhPp9hY3sL29s76XSttME4j1LIdpTMAx+hijEL9oIgURIUtJDaN51iMp2gadp0ED5kjQlheWmKlaVlHD60htWVVaysLmF5aQlHjhzG8WPHcfLUSRw9ehRHDq/h8NohHD16BIcOreH48aM4tHYQBw6uYGk6wZIc5ya8dY6Q9EVaL2H73SX6TZ6xHcQf51TNmQo64srOH4xHogvZ8Pu1GKI/3hzJLGkvC5p6xqTJe2rzAf0dM67vbOPZWzfwuRefxydfeAafOv8cLsxuYdHPgKUJaGkpHdPYI61CFb1sSrlyEamji52jJGdFy2iPl0nVE2171hLveGl+kyIfbQ6Qm2SOtQba7PhsfLUyiznkor9A2aFx/SkOlBXEkK2z6hQSoVvMwVtbeMvRO/C33/Pt+IYTt6f0ecqgkdGsWr0hWvOscLIE/4zZecsjC516Gd5HCmBu9HP804cfwImDh/EH7n4VlqnRVehyWpXxjSG3HBn7C3kuPhMo7I33xFFIXwHaIGTWtr2w5urVq5jPZmgnE7OTWUd1sVTTOh0VsGVbhQwG5vMFJpMWt912xg3RZaOfUSygfuE+eFEMjzMEiYD9eTPmzDovOMCK98Zy2RyjuAHQOzplT67qIkMB5okrF/E3Pvnr+NdfegCzSQ9eWwNPW/TUpCg305fOO0Y+rzWvBmaAOqQ9btub4Pk20DMOHjiAN528De+752V417l7cP+Z23D8wEGsLC2ljhNeJRfRscwPn0YBkS0PEnOb7Yg8VpCW6HjQU/Xe8/lSpCwVi+3abaUgNJ38bovX0rsuR8CLLIOL+QI3bqzjxo2b2J7NsJgv0HWMTqLlvJ0rLTTrs3IXXq8AWx7eadycZdM0mE6mOHR4DQcOrGLStlhaXkpD+NlQLS1P0bYTTGUY3imORT4wPQgfObQZwrds/G2hmxkAAQkBzGAApSw36lHjdSTJga1/7/+K7GdKCHLHjekGMiBKnp4Z13a28PVrV/DbLz6Hz158Dl+4fB6XtzYw7+eg6QTN0jJomqSRZb8n0lxjafLKGGnQpEoT2fOX62mkkgCR6nSInHNRIRUfy4ksc+wGi+0KQpyPqwUKOJmDinyRO1kHwH12R0NpP3GHfnMDJ6ZH8Odf/z784CvfhCVqwMy68IxgQBiBtGKZK5e2+4aVoOsBtrYquPe5mGErn9n1Vw3eX8qzW6dDaSvXGkUnfJADVf4USbhnXL58GX3f5xX8TbrnNztMsg2oadrgeNGVq1dZgNaGkRNYnLv9dt1OEENz88Ai3XXPIwDdPsDWA+dgpXGt/WPlBBq8Z1anQaJcmbif5GO4AODBZ5/DX//kx/ELDz+I+cFl8Nph8ESmUnLpPYM7BnX5EIEuXS3V9gs0nFYLdm2b6lhsA12PSdPi+ME13H/0KN5+x514+7m78bqzd+C2g4dxYLqEhgxA0tnJ0OhIZwWkQyERrVNeGLhVeQfXj5V0g+/2gwNMA27xIPt80cKYg8iAXUWlBggW2Ttwi/Tk3KJDDkik7aXRCpGSb3vFGZE2xxGAvmhjRbYYeW5UO0NHA3y74Lx4D5q+7lI+y6g0tAEIl81r+gzYof9c5GTTJ5xH0RMINg1hkj11IMn3TtfhxY1b+NrN6/jM88/gCxeex1euXMTV+S3MFjvAyjKayRTtRIbBKfcPo8+XVchtLGKKwbZVZ7d9sArMWQ9sqx3bNa9q2ClXXeTNdanhzfmpZKiF/QXLSJ1e+Vnr8PWT9V+qywGl0kNGm4iLA1qREaOBAMpTGwR0sy2sLHr853e/HX/xLe/HqaVVvYtcrnlzUmj6MNBDczLC+IAfGfH23IFWlE/jT+ncy3y+HKdLsKFWXY3OhYPsuwLR/kdjVaSt2BmfPOqB/ygVIfTX4JhY91PXdbh0+XLWl3zeN8Uzv9P7OE2nYBv32aZFF2fPnsV0Oqk0QsU4EGSeXukt1p/9gKSvM3R+1IlsvArD5SWM7Z3WW+ThDBZ5GikNJzKgd0GC8bnHHsXf+syv41eefByzg8voVg8CSJEWuh6kkVeOAhlo+i7dlAKgp3SSSlKsFsT5aur5DNxto+l7HDqwilcePoU33X4Obzx7B95421ncdeQ4jh44mPJk+pts0EjppeFiIlUoMWYRfKiSVhhs3TAYN1CG+kVou3qFFSVRGc9fBJQMgCtgH8DW/c2FD/DTGV0xguXQmuVxy28Yo4ZA6ypp5JJPVodSR25IkUqJ9aVjdx3Kdakx8Q4IbKGSqqLwV0G4dzxpNGrqmbHZzfD41ct46MpFPHD+RXz5xkV89dJl3NzZRMdzNCtLaKZLaVoFlLeAZUAjqQgK9r32soBr0c6wukUVtRBOz1lJX7wOhdZ4Jr4ARRPlh160Xg5FeYvnCSRJy+63YeKBsVITRHL6E7JsGNgKQFODdJvO1g7ee9sr8N++/v1466mz6ZIBFjqyU1daQfUDIoB6O0gjjNxFm0O7Ah647pO/ZXRJrv3Vx9lqIOpPTcNK0B7gih/p2qsx+2i1bPvRo0mbJjsReaGUu/UndWe+D7kcRhZvfj6b4fTp0zhwYDUK/kAJynFxR7djRjWrj0ocI5RxZfqQ1bxJ7/3IopGChF1p88bepxevDJRONpF9VADj0489jL/wGx/Hbz/9LPq1FWB5BdTNQbO06rRnBjeiC6yLoUB5Ww0nsGzAsDWuDfomHXDRzxdpKwj3WG4nOL12CK89cwavPnkKbzt3B15/+izuOXoSS+0EbdOqmDCngzXKwwjkr3iXHmjNxpG+lFWr7Dphr2H/GIVJhBX5n5TcOsFHAbXiI4Z7Z6sG8mNKvJtyk2/2rm2zCiOf5H2Idl0YRMUwnRY1XlnhL7gMFGVZF6TIZzbQlEwy0tHKcHrubwaw4AWe27iJz51/AZ+/dB4PXjyPJ29ewwvXr2PO8wTKy8toJhOdg0q2I9dLKE4w8n+NLgQ3J7q4lL2CNLfpZEY+F222sAdBQEyuONirtK81gxK4OEfYIl4BAf1OzngXcqZHN/oOVSeHgu8QLwnQEpRPnHlK2VnWldhNmxbjbW7gVUeO4y+95YP49rP3YgkTzPsFegZaatA2FPYt24rqghV+gaCL3IKdFCfCtSs4GFKe/Ob4E4HQlS/ODQrZJScRyuNxWz32+Mi2nMstbaBmUCI4nPZWxTJ516dGbG5u4ubNWzoV1LRp10VLbn1FtrNie4iavPWHZYFG3m/LCWyPHT2KI0eORP45ikohZN/JFQNWGzIbMm44tFDzVKqXBHt0JgoeNLt/ta7Bm9xBuQzZ0iDem67qzVq0YMb/9fBD+O8/8+t48Kkn0a9MgeUDoL4HLebakR0RejnZBZSVzAEeI91vmwVWFkyIFBEzsLMA5h2YF2hawvK0xZkjR3HnkRN49dkzeOPJU3jr7XfizqMncGT5AFoyH9cEKP3jI/uk86JUeYjU8cf3C5WfiQbpBl2ShzQ9Xoo9ikIvZY+V4xIV72rO0uCpyAvVhDT8vgtBQ0IQKfQjA/YDFS9SZDhIFosvaZLPBF1g7bdgWJ70okc6tnRjMcOj167g4euX8dCli3hm4zqeuXYVz6zfws2tHXQNwC2hmbagpaXkGDKl+1/lpDEpvzEizFY5fga2caBnyFHnLHkOqrc39kQNlmsdYy9InRGQkww6Ky3tCKAhVKcyJbk3M2W7g18opJAfKncJsiOWB84AEPqW0jnC1IE3NnB6+Rj+wuvfhz9y3xtwqJnq7WZZgey+2YGN9B9HlLryROCNOjJmr0OVzgkWXlPR9Oh4D8FWad7l2efgqdEZPsS6fILdFkbJbzdu3MDW1hYmkwngAFaGkcO9tkC+15aKfbacFqAAwHw2x+rqKk6fPjWsUIU6OJBOMWK4PzZHup/VxS91njakidQF1amW7wxF8L1dpC3zD13H+aiuFIn+8lcewl/7zK/jgaceBS8voZ2sokWHnjssmhZd2+rFzUpFRlsBQQVWhl6M3fQ9Gs6nDjVpuww3LfqG0qXZXQegQ9N3mLYtDtES7lk7hnvWjuENt5/FfcdO4PVnzuDk2mEcOXgwXJwAsq0ashJdI9mMiCIs4vWL0xGx0guvM3Rc/2zemjOXXMhJAMKynNKgYg+jLM2ty2FttePu5cTq9lotyU4vZI5Ph3MJ+TD5EqhZ+4aBfNhIdnTyfy1JRGPpFn2HmztbeObaVTx98wa+fv0qHl2/gcevXcGT6zdwaWcLC6R7YNASqG3RLuUDW4jCcYhpXtJ5Cc5ma4vI/818cJ/1CEq2QpKjbIuyvN2g2lwZ0rxvrDh/CQ4GKbilnwRUoy1i99lGH3Ijcn7hp1Yj25uy/MlCu9RexwSNHmUxkxbuHAnpbQJxA6IucaZp0BOh39nAGlr8kfveiR95/Ttw1+oRdNxhlhcFttRg0jRoA9C5kaisO8LbPaU6mEDPe+uL3aLWUIxvYnHW8MAB9VXt4mVrkSFqhZt9qOu1b5zfQUNO3mLKQmdHcODylStYzOd2fgE1YREmIIArFxLk2mzrT45sWa7aW2DSTnD77bcNiBpjSmxefHYDx+o4eyXNcHgNEMHXNHvUNQDbEVEci8J1QYlEgXqHbTqE+5e/+iD+zid/DZ9/8gn0qxPQyiq4mWi65LU2Gr36q7fID/1mACY3TEPJbUrGuW3AkwTg1DR6Zi51HWjRAbMulbGYo5kQVmkJLz9yHHccPIL7Th7DvUdO4DW3n8Wpg4dx8vBhLE+nmIjABEfKFkAFjpD3ps25itzkYKAzI6Hebtmf/l/y70KJhYG29wPAjb5WpN1XsstTkw7zK4YmSD+V7Zaq2fgqLgOTnEGcvWBldgZAASkk6e24x+ZshvX5Dp66cgUPX72Ip2/cwMXZNp65fhWP37qOC5sbmHOX5Ktt0p7lpXRzlJxoJQTI2dgGArYYTIDIQc+ebCsXt3oXigUgC+eMhokV+wzklLVDGsiBrbAuUlW8jCBQaYXHFEtN5U82DGlAzqEYBX8P+pzoJQBoKdnd2SaWugbfc9fr8WNvejdef/Q2yDoS74w12dEacxL3M4JY+KuOrnrnhSHoPR8KvHsJGVPuMdvLtaH7/ZWj2B8Khslj8d4KKX5ixsWLF9H3jMlELubIxzW2doKU3mkrQQpR3GfLObr1FxLcfvvt1UVSJSPEgEWfwQ0fBbdnd8bsJ/q1NNFbGl91WyufTUlRygarM655i7GLnnss+j5t0GbWObGee/zKww/hr37mE/jCE4+CV5bQTg4AbZP2oVEG3MZ5ZwDSWafezXQeMwj5ssdEb5MNcV5gRXk1qey1tavi0lFufV70xosFCD1o0YFAmFBaDX1yuoZ7TpzAfbedwR0H13D3oSO4//QZnFhdw7HVVbQjG88586GTE8jY7g2VKYGw6ElsHtlQuucxxX+qbl4NbNOrHI0V3i58eucghCRiuCrt82VEcDVQVWejdDpLQ5iNsuzJK+uR+a1532GzW+Dixjpe3NrAY9eu4bn1dVzaWscT16/iiauXca3bxvrODjr06NGnK/WoQTO1+dUElrltRHr5OowNkDiTAOjWHAU3Aym1nzo6Y05B0EHfz+G99EEq10oxqxHOJR6zA1xPYw0qTskq+GzzhFCDm0lyMgvVSx2N8lGx0sFutCq3xy6rTVsQ3dyztTetHmYm8GwLbdfjm257Bf7im9+H95y5E8SEru/y7WJ2IpesNpa2eJaYuaDwPrCAgtsEsZ9m41y5QT/s69gIDg10yC3L8nQ42asC/j76PQxvu7we46lQMFvA6ygrEdgUMZbMDDSExXyBixcv5VHNNlwYn67Xi/fZAvlgEYIDW85X7GXA5b7HYjHHiRMnsbZ2cMiR38OzlwdWe1dfmVyUO1pXZV53pJBBveGTVyZWa5JO4nM3CuV6xZj26PGxh7+Cv/5bv4kvPP4oummLfvVAOjmp7zUaBdKcLuu+LIu8OP9VGtXTFLBN6qsCJguxJFJhVgUzQ2SgniLoHrzIxwkuuhTpND3a6RQHlg7grrXDOHfwMM4cPoTTBw7i3MHDeNmxEzh36AiOrx7E2vIKliYTTJpWAVSVigvDJ+zMws+Z/qIzCj2PfVOba+XMe+/8Wfrxh2qJXH9aO+Qnr/DuU7AiEt+Y8ZHVvpzbvdN1WJ/v4NLmBl7YuIUnr1/D8zdv4OrWBi5s3sIL6zfxwvYGrm5tY953iU9NA24ING3TJRJNo3Igw4ckx/khW19ZhEK2+Ibh5F1QZtB4kQ8PtjTENtjvkKIUbDk4kP7fwEMqnXREEJXfB7ZAQCw6ZuYkDx+NJj14jDho3twaMPvMlbZoicK/CAo9IY1GEaPb2cKka/D+M6/AD7/u7fjm21+GlhrdQ+55IJeqU1FT3frt/Qy2PblWlCv2a/y0hYGoMnrk9aBsX9Z+pgat8GEN6bV5HWHRlQNawLLahIY9pcT6Z2NjA9ev3whDyBLR+vtsCRSm30AEunrVX0SQV+B2HQDGbDbH2toaTp48MTrUS1kKBdrMrNe9k5on5D+X9Yx7NoGIQf3aH5W69lo1HdJQkSgImXV42uKQtg1R1sq2SR7NjBm//tij+Hu//Rl84tGHMCNGs3QAbcOgbgEw0v7b6QTcyImyJt1U0iBCREA67jB60CT0s3yPn2W4mnKbZYl6Kjtdwde3hL6ZJCPfLzIYL5KTAKChFMkvty0ON0s4Ol3G0ZVVHFk5iDOHDuH2Q0dx+uBBrE2nOLW6glMHD+P0gUNYaSdYmrSYNi1WJlPjeRghGZqU0N2FcVcwEwD35WmZ7glzhMbSgVPgf/evVdrs3bzvsd3NsT7fwcZsGxvzOW7N57i4tYln1m/i+Vs3cX1nC7dmO7ixs43zm+t4YWcd61tbCUx71uFXalqgaROoUo5W+3RpO/t2Z5kTw+zFhMk7Z43SbItS2NqXnRTVHzHEOZmzWWrA/PAbQaI5L5fs+G4OYDSRAtTyO+nR1t4hkLq0NO/AsesRr79uURI7wLMkOYoOeyvNSHubXI7eCQ1JgdwCPQHtQkosoifdKzvpe7z/tlfiz73xPfjQmbsxzeeN9+yGpVG739V45+0CFbbI0o/YW9gT+oTMSSTlLeX6/GFG0k6TpTDnWQHVkh5T4xHbXNAcyjHPZzS9L3tfNt/TLDLu6CICrly5iu3tHUzydEzjItk2T880IL1Ni3QEi0DXrl3lvk/H7vmbf5gZ3aLDdDrF2bNnIoWVZwAInjH76Px9PZXhowHohvF9qncoLM2edHhLk3OPPf1AUNJcXJ+LWHCPLz7zNP7B5z+N//DwQ9judtKWoXaqBpNlEVRrhjUKd3zH3ljpe+cQsKRi++zS2Mpi59E1EgWl84rzLrFsg/PiHgVwBuUpiGS08zCkLNoGo2kJTTPF0qTFhAiTKXBosoR7j5zE2ZVDODyZYqlpsbo0xdrSCg4tr2ClmWB5OsHKZIIDkylW839LbYOV6RRLkykmbZuG7rNHOSFCC8pboSj3SZ+doF4BigFwPqKz6zt0fY9F12PWL3B9exM35jPM+yQni0WPBXfYni+w2c1xa7aDazvbuLGzhY3FPIFqN8fF7S1cWWxhY76NBffoFgkIu26BriFwjzR3igSmTAC1dlg592JebUERg/WkrjR332Tjbh6AHlzpLabIvIx+VPXSgWn5k9lPdX5VwqgQSn3HMXOwbVzmiHQMyq7Q41oRARvF26Iudrwo6/CRtyrBPgCpoNuvmiZwPpIyX95OALeJrsVsG8t9gw/deT/+zP1vxTvP3oVlatEg0dFkMDbsH7qdOpcuNFZY5nujnPqqPaFHQ+aRMvWdc4bCEzYQqe+WyNkdTF9ylJsyGf0ub1zhvI+FYpEylC3mvseFixfBPetFK0QGuE3Wt0YiW7L/QABdu3qV0yrkeD6y7L3tux63334W0+nUFG+v6BTe66mD7ejk/qCJI6yo1FsrzyWKXuke6WNnl2ondPr2WlJfplxen05UIh2/f+TiC/ipBz6Hf/6lL2Nr8yba6RTN6jJAaUi5byfgNg8Qc++AE06x80dZ9ee9MVFK9g5HFLlkZOxuS81G+msSFlF+jZYNcCl78po/L9hC/o8bAijNVdseQk5XzM078HyRr5rrIOihvoMOw6QbYZLjyKCW9PByysM2CWyb9F9eqSkOzoJ7dHKecv6b9iPn1eVAmkIBY97N8t2cjTlamdF2Ew2lYDG3DZMJqG0TeArNwmM2Y6z8k67JEWWv/Wp6E6MEc2ZVr5zQeQn2Pq8NFWedzVaPnIM22Ecq9ZBbC0E+hrFo30ecrvhIkY9CnRrVtE6G29RG5OhRQMvLux7Hqg32867SnPw+AKxnECsfKUtxwltnW7T/oHX4VkiPpEXHafqNOH9u0lnqi9k2lhvGt73s1fizr34b3nHqLrRodCRR9meWCxPN2/beRt12jUWtXlDG7Op+RhKt5AK8ncEu90LTMMmuNL8UMKRd6h2Wn0Y3qvZfPRuMLg6TZzab4dLFS6mvFGzl7HgbSibk06Mc6BMR6Pq1a9xxj76ToeROF0kx95gvOpw+eRIHDx7cMyqlQijKvhobig7DQv79oHz/pVb/PjrMuVljQxFa16CO4ANGQr0Sux8YYlSRI5W8ejkDxIX1G/g3X/4S/n+/81t46vIL6Fem4LXD6Js2aXrXZXwot4e4OlwIbGszvNLEvZxlk2yxwLAN4Zu5pzrEFNYX+Oihcf9lzy4tChMBFICm3IbcF8wD02DFemNIVZ77hWHWyyniNgckvy9pl2HXMLQEHaLjsl4FJiqUHPHRegVspYVe/qz9RfOH4FmWPRBTmSeK/HExcUlcUY/84jVK1g+4EosPAz32Q7yRlDoFNJYkDj97lkU63KMA6pMQbOonA7UbYrbRMlLwlDzmQJlnlNI0qZbsxPVEWc/n4M11HJwcwn/yyjfjj7/qDXjDsbMmmWLjKZWsC+Yq9qic0RKHpjqaKPrsnbox3dc8xaKrMDpYoQdDWfT5Ah0Ygm0YXqZKvxZlDAKi8v1o9D5kaOJNtA76XrKEvFbGrVu3cOP6TbR5FXKbQbZp3RytniRF2rc6d3v9+vXBcY193+t5m4v5AgcOHMSpUyfhJMSURxdARAO1Hw8sPCPeScXm1PNUyt+PpxT2QFLtfZ1mL1wiUlymF93Oj0S5XTa6kzZFYQBh1i3wSw9/FX/v85/Bbz//JGYTgNYOgLgBOgYv+hTxNq4eibb8pQvi7PuhlXDHq4FNCRqS3vYGZr4U/BBA9EZS+GdHz8FAKH9mQwBAIw7WvZ0WOQ9lSrsgl2llk9YHNIUBEp70Duign3W7C1u50q9BdgR8MhCHCNf9J5FZIjOaZjNgkTRAWC3zpqUT4IyWL3M3b97bMjeClPxMdsltCFUXFHpR97oUcdd9SIYu6IvIlxg2FTHbQsbO2fLbgaKqWaVhXytz+H2gd5l2ze1HKPIHErq1PQ4CFPUoH9fKUVVymziDWkNWVtclkD21cgw/cP/b8Ede8Vrcf/gkAOjtYsjg2pLb8y4UDNpon0tQGhvd87K111xl6auNj/oZbeQz+v5luC1Ccb1DzRZrOY426a8gBhWnanxE0hJGm1VWPCzfrz8q6WQAFy5cxHw+t5OjZPi4acIKZB1GdodcgJHAlrnXYWSWIWW2SwmapsHtZ29DK5eF156y14wrnguDBnimRGEfL37XvDn/bh1c7aYR+k3JafB+WLJUL8bRlY3UjT1745AMkzjQjLR/98HnnsI//sJv499+7cu4sb2B/sABYLIMblu7viobZoDRo1HQTRLPsZFsPJF66pzxn/2GKKeALmUJtqGDMgZF8IkRtrNp6W+I6pzx9lqevUXIiVyVaNRbBXVNPNAKwLrPZpSdsjklj22Fq1vqEv5SpKUQOHXC2fHSt5frvI6FuUKVHuktKjMV1tTqUlwmqbcYmq3ps9ajpbj80gRpiyBoRYrIMdKdLzjuixcCrSjJAx4YqTIVUjIBmo/hmRA+OieHRaShkRH3aX0FNWDu0M820c4XeM3RO/BfvuZt+O6X3YeTS2spv5MpEynbxuO1bUCjtt3Rpw10f6gSAfoKg7xEJUwyyJUs/p3r8bFOKuslo7q24jclc3LvZVgT1g0zO/p8YOvzlguc9Pcq+XkabrAZNz1d1+HFF8+nLVhu9THJBQRNgzYsisrTX0A9smV2q5J9dLtY4MzpUzhw4EARsXsvPAKcsBKwztnVi/LN3k9njpQTTG4RXST6SioMOqwFNNJR+TuZCFmaIdiKsRf7ZitvTRDkcAx/29A0L/x55tpF/MwXv4R/8ciD+PqF81gsNcDKajqYoGNQvsqvp9Z52nbvq5lDMyjexrFru0cUW60KjURKABwAivLG1eP5MADD3BOkJkzfyT/BxHi8bcIXjxhafjjbXrOzleqH2VD7POJ9wVgV2giEfjdyKmWQ1a+DaoMIxPqEwTo8bquJLa2PVAHBOL+wya+1iMOhKsPeA2hkjrdol+Smkj0RcHWYExR0R2/uAWC3AMECT1k9rGJpjm4ZcalZ9sPCvmXOufQOgu966PRAZpq219oq7SWfJR8u3S3m6GbbWOUJvunsffihN3wD3n/mDiw3Ez2fXFajhrUPLnKzoW6xpQ6egrF0/Je8Xu8q9koarXk8DwMNvp6YplbmviPqagVja2dccm+3He+9yO2VN6Wv82Qgz66gcshdpj431tdx5co1TOVuarnVhyyqtS1AjdYT/rt+/TrLYRYebLuus+h2scDaoTWcPHEC9Ycjo4UpAy84tEJaPmjcYBhhl2e39LuVYYbeyPe2ozYEMTB0gQ5XpzNS5bxwOczBuVwWQy9pGXov4ozn+K3Hn8K/eOhB/PuvfxU35xvopxPQ8lKie5FuHBLTKRd+63BnYTAKBMqGbhdmjTbQffYf5b1UUfIs4KLP743mkCBy5cbvIxpZjDDU5ugjuPqP0W2UcqKH7oddCQOBK/kTfzCCeeQnT8bg5zoY6tAou2F6AXdBNQXaLNOhDw2ACgwffKHQX8ZfKzPqkDoooRgKIAw2UNYmRrILSlyHk28ZDGhq/eKysX+f/6T/nJ4QpUNDmLGYb6NZLHDXgdP4vntfhz9476tw/6Hj2aHpoY61jMIUqhOAwTl4XBLijYGAcFA3326To7EVv2Wp1WdkemLP9ToCkH50ap9GvGp/nHxE1Wb9rG+Dk2J5axdA7EbbaHJO99dub21jMk1Hm8bVyD7S9adHFYB74/o1ZmZ0vdzdmfbZyjnJvXpowB3nblfUrvElGKlRUNq908o0Pu1+Vg6XK+tKARsYf+8WeS0svTSfZA+a9xOZCxDrYoacR89ezktUGwCTNnUqADx/4zr+z4e+jJ958AE8eOUF7PQ9mulydrbzXl9CutyeKC1IclbOR7kaoZdzYJklcltKHRfNarJYyQA+MMPv682aZb6WM5mVfhTSNVqqRdTkld2BgAMjdWb0u/0eoq9yngrizDlQybwOc2zCIJG50onwYEexeKVByXZgIXe0armShrOYFjyX/uDIK5ujZH98b+5n40t6zYO+YCej/r20Po7yOpQcWDaWhjl+cgGsbPTrCIDjqXP8kuhJOVafzgmLY5nd2ppT5my14io4rXgmENA2YO7R72xjignefupO/OB9b8Z33nMfjkyWQEhnUi9yJKt3AsMV7NpRirCyjuvcSr08riOpeK5+fqnpa3Zb3yiO7t+Ge/BL74eQNpCOkcgzjjCy9pvJACPe6ORKd0Mx+7Hnko6IsFgs8MKLL+qdtfG/CLAytCwAC8Ai3RvXr2ewlYPoE9h2vWz/SY1aLOY4feoUDh44UCWsBDVrcLFqzLgQ0gyYUGm4T1ulYZdyIp46Qy7iTGXHutY4IfMgo6rg0g4MrSuvDlZRvbQPXC1ElPdb2nrSnX6BB556Ej/z5S/i33/tEVxcvwpemoCXVtKZyT2nc5IBAGkVMDfuTGY1ROYRx6jHWZ/gerr3WdJH21xqWijBy4IvE/AjFcHIVsHSDRf6Gshl02aaQ2C6Z7I5Ln1evmuSTsNm6ivXt+V7FSFxcEqex79UsMmZy92NpMh2MHpOJ6XcsoLKY2BRJqoQHKFEv+tQtMur3UFC2y69MaCPtLpYmyyk8zS6T9oO0zZ2vCIGeN4BizlOLx/GR17+Gvyn99yPt5w6g5UmRTh6oYQrPdzEw4NaI+VjQQTXv3gwiuN5fq1BXR72eljyevrG0rkEfgHfoC3Mgeb4U1HXYAQsTrGIzu5OU+muDJ/kOvN4cpGlDLa3bt3C1atXMZ1OAZBbIOXusVXQpRwYWaSr/XXjxo3BnG0C3HQ2TQJhoFt0WFlZxpkzp5WI2AAEo+h9EDuJpJ5eOnk/HaL5X0JU7NMnz95HXOY7xoB3b08x1OtbV0pjJW+oS/7JCq5Dea5eWcm86NKhEW2e1yUA5zdv4P/62lfwzx/+Mj7z+FOYLWZopuk2lxYN0Cfw7tpJOqiCKHiAYuxFqCn+Y2BVcxZoOJSammCeZ94jAbIf6/wkx5iaLGgVDmydAmqfFqChPoW/wzO/jEPG0XsOZ/yaJwAZsgsrWnOZtm9PDAUcryuRuTSK7aVFrQjGzw9NlXNW4YYVPfi+JnvisO0Btma5o96G9o74zxLBhwgXiHfVktbvT0zyS4m8g+3xQ0/acv5fnPUxsDSeWbmm9fL0WfbyYTJ9D57toO17vPbkOfzx+9+C77nj5bh95QiY03WFYgPTfu8M7N6GcNxoRb6LjUrljeWRj/X9ycGesG+HK93dE+vrfKmjirvaOh6mGYucx569InDFBa03/w6EOefRVcf+CWpXGl/5WLp/6Tl/4QJmOzNMphM01IIIFtmGqDatH/HDyHLtHjWUwNZA1hZHyeeO+7xzIl1McMe5c5hMWqV+6ESZwNW8nL08rrKDx4aUtTyM89dliPJay0BRiEL9VHSQZBgprByKNKUZUb6aN1kILsPdr4uof0ykC60eu3IBv/T1r+Jff/l38eiF57HT7aA7sAIsHQRPpumqtq7PRzYSuJE53mAtiwoi0BnuOO/dsEj/jOlb4GS+6zGjl6ubBv2mbpFznKTipIAZcEpaRFykIcFpcO2r9X9BedXujYp06TiMyT/FT+JZg3W01YbHi0ct0C564klw7uUwfa14YZgz4E4E3CSDRrwBq327FBTH7YCfQ1c6A2BHvSHYnK+ryb4x8hq6aJAZAvINWmL03IEX28B8gaOrx/DhO16JP/qqN+Jdp85hrZmq/vlq0kInndktaqeSlLKh7k8Jw2zN1uKG9ifAaSHXPk85sjhwSkPlw74pLV057DystqzXCvFRZS1o2+3xdtQDcXA4GENeeZSGOG+78M09s9kML774Itp2Erb4+JXICrqUbZYcaJHto646v3HjBgNpu0+MbPN8bX4nFZ84dhxHjh7ZHQSLpzYnQMX7MQ9p9NnHnEMoZ2SY0A+JvZR5D/NbreOreVHLG+WBnRIEyDOUgL/iyqf3fURNOp+zpQYdejz4wtP4+Ye+ip978hF8/eIFzNGBlpbQTiZo8u3fHffoqUGfwS0yR1YHk3mSYlDzXxsq5rioJudzRGvrvMH0w3xc8pko1+WMBDOi5+sMuebVX2NEJ+T4vwXP4wp5Wysq3618R6f+bv9a+TRMQzEZCHZgPUPN0dCpjGlCaCktGWm7lyW4CFz7QsHcDGGmPqX1RlWqJRRz+k0kA7bQKgzbZ7CrRdKB/3Z0mWQepLftGn6ExTGXASKZpza+MOVLRPoF2p0dHJgu40233YXve9nr8d0veyXOLR1CA8o3e1n07YeIaUhOeIay4bvHvCgFMW1ULHA/0WMJzOaD1e0SO9mp2pxcTjVvsI1wGDdit2vMGRKNUvZKekbX44ykDyMLTuF3nzBy5RPh6tWruHnjJibTabwkntzq47BIyvb6y66JRi6Pv3nzJgeQ7ePtP/5GoEW3QNM0uPOOc1n59u+V7Kdhyph9gO1gHtg/pbdFcdhNX5dl+rJrHts+O6sGtpTpsPx+XrLWhgjUNWeBc16JFhT0GXZyE4BZ3+Grzz2DX33s6/i3X/sqvnb5AmaLGXipBS8vo58uAR1cxJt50SAfsUjgvJc3zoGZ8S+ZFexFOZyov7GCKjv+eA/UWW7r6yAfZliVFG8FgxEuDFrxWH/Ii+IND5uqw6oVZ2hAf1mvFutA3Fnl3fXLeQ1GcAaxol2+v8o/6qSU0p3fCiYEORZjV3or0g4nFGFKpESRSqvcsLalKyR/0GwHGpJd9CCDra5VYEY/3wYWcxyYHsTbTt6J33fPq/Dec3fgtcfO6pGJYLZ5VyKNainz86XaPu/UA3B972XrpUV6sbBoPwfzoUAB7HU7O+Y4jFddcYQGSYanRpW1pnqLmnks/VCN6lyLb8vyx/Olp+8ZL7zwAvq+R9u27njGJBdyBnsJwiBZFJVsjzhmCrYsK5HDflsD3C4PLe/MZjh75jasrR3ck1ht8n4i3pH0o15LGKcf9/A0SazYpfemv563tiIupTcFDJsdnOENToRbmBUMBA3lKhpAX+9QsTxt6dCMtIK8R+rXJm+4bogw7xf4+vPP4Vcf/xp+8elH8bnnnsdGNwPRBO3SUhoKyfKgJ1ZRo5cSgBzRJTVsUWgwhhkA5NA7i9KzUyNOiANyi14doAMgjWJk7pTNuFptxkwRdMrGzJcpfSiYANLyvTFiV77+GjqsNBVFb5aypFjkeVX2qQdsZZUyfDhnCzsvWHnuywQEjMs6MnooWNlqa/fdtchxEZpRnNPg7Qh/KVx+IQxXf1nrM3AW1PS23C9mVJ2NY9r5ykgOV62Be/TdHDzfwVJzAG85eQ4fveeV+I6X3YeXHT6OpaYFc15RnB3/Np+vrYusgHg4xT7mNv3z/5QNDHO5KPqwXsEYQfuqq5Ym1OTNcPAlggEoqlXJKUoTHRuZjw2OmksTbKzT35DTE+okMXi4VqcsjLp8+Qqm02k+htHd7NM0FtHmQyv8nC1g87Vqg27euMGcK/CAKxFtr6uS0+fFYo6VlRWcPXs269j4lpzyGYzlFyzct09XDK/p6yLZnlTtRndNeEN/jeete3EjvvCA6GHJnsd++LosguW/Ym4G7p0OGwLowHj6yiX8+pOP4+e/8jA+9/RTuLWzniLelVVgeZIEOV3cq/mTsUwRby8HTAzcBFe/i2x9Kh0KBRVRs/tbFubAWECQRuRJ+pBqkRHV+sgoQ/ZKA4BWivEu0JjLZIbB1ymHPvjXheHxoyvezkDkj1yw70AKvr9l+L/WXtum5MnwC5B8k0f1U+vwvR/bMczPQ96ZBXSuHOAvYw+0sGVjrUecmR48nwGLDivtMt547E585GX34oPn7sbrT57BhNrs79i5x0zOGYG/qH24DoVjx9nQYeEISVmlgySN0MV+Y0+mwddLjp8e/AfrXdIP1fRWfJGnBPZdHAmqfNvPEG2oW/1NLqWm+DD4MpQryhKtXtyAyPCI/5f6PrYCAF54/kXMFwu0kzYDa4xiw2fKw8dkK5BlTl/90Vs5su3yvGyIbDnN3TIQjnOcz+e48447sLKyXBcUcg3epcWj3mGIUlBNUxOCUjj+76yIKw8vqJkRuDdh/XXtNClndGxhT9yr+XuhOVCyi7fau/9ke1E6Yixf7QXgxRs38KsPP4JfePwRfPqZp3FlvoGOAVpaQjNpQS3p+cUMoG8b9E0bVtsaD2BzpD7KQBSPMNTqwLZc9Qp2w7UonDxGjGRki5RiPJsxFhkhGnamWnBFdCWUhVZG8Jv9sLR2C7liOFZj7WJr99ACAmCUjmxcemQ8N2oc2Lr4gJTP6Zvua01W3C1uKwFZotW4rUSNt4yCuPTZTzEjSlqK/hz4Jp9Y9KLiexCHqAkAqOd841SqI8l0j36+ALoey0sreP2Jc/iWu16B77n7Prz+yHEsNRMAOYLterCLYOMZxUJPaWc8EDlaStmGxf7a3pcYwYY0ruYxa/pSbYLP91JtJiptF92kQRpvGwjllIDmcBH76Bqc4PyN2W2nA7tE5l6eB2pLhK2tLbz44ouYTKZ6q08E2grwunp0GFnvCifQ+q1bLBEskME2DxunQy7y1p++00Mv5vM5Dh86lC8nGD7JSESGDFu591Odd6h4yXsVWXqDe+UZm7MdOAFqPCi832VxZPXxxqjKt0DDrgWlPwMPN0mpnMs8GIJ3IJdhCdc21/Hgs0/jE088gY8/9zQevnIRs8VOujpveQqeLNmdu3mut8kOm9yFm9Zg6XIfM8gFzeR/U7D1363damxMR+FU1t4nQqIBKEFlWHwFcAbk7q+fXLleHjQ/fLtrtYRB7/BbaTPdwIGCRDD1ZTXk+FjSk/NG+mxrWNBBqc8VJGukzIhao9OfCsiKFR3wNC9QS2PDbpoh/aW+B88W6OczUMdYWz2Mbzh1F77znnvx3tvuwCuOncRK06a5V7lnGbIGwThNmad1VR0HW6JhmmHfvASDt9fDxcK5WhITgEzPONjuRdtYZFufrx9/dp2vVb12Cg4eMhIj8GFe+zDVwIk1mR5ru7y/cOEitre3MZlM3IIou4BAIlcBWgC6OCrVIWkAWThIt27dYgDDfba93wbEGuX2zOA8zHznHXdgMpmgNrGfPDw/HOQNSE7D3it3Da40vkzjlT6kr7IQYahxPyvuBnUVadK+3EpvOp89vREaZW1rbs8e0e+AnhEF4liZ/dH7SjMVFYCQLUUMO7mq7znNTbTponciwlY/x2NXL+KTzz2FX33iCXzp4iU8d/UaFv0MPGnQTCdoqUGTCgIj3xHrD9LIAlgDW1UCiOGOK5/9o7qV/1GjGYDG88oYaFFlsWgq55VhIE+bwo5f6ONBmqXcuAikHGZU66zyTK78ikyy5PGv64bT+tUzRHHSfcj1BS+f3BCak182MtLrxFzfJSLPYYGX52Ecmyu0o9w/mcq3wQqd4U8Gq0mnofVg9PM5eD7DtCHcdeg43nHubnzg7MvwnjN34a7VQ1imdGFKxz0WfQdwMpCtnOzjeCgsHqywHeWzURzTR0uHosyxZ3zlrVUT14nUadtfmXvburFyano7cEOcctbtGyqZKnVV+F/ixLitLnTOCrLX3m4XNBARtre38eKL5xVoyyFjAdHBTT/ihBZRrg4pr6+vc4p63D5bZrA7qlGGmQV4welEqaNHjuDY8WMDD4jcv6PPiHcxNq8bnjC0Voj+Ll5fpG+Ydj8rluHrq6Qf8zwHUXpIM/TZ4jwtdN1InM2q05kMJDuBr8wDuzIYHnjl8Ak3ICMglevf7js8cv55fPLZp/CJpx7HFy8+i8vXr6Hv5+C2BS0vA9NlYDJJ0735QvgGlOZ+KR8jSWTzZDK061rj1UzdtVInCzYGMA6J6t6yj3LlQ0FG+Cwg6kEcu3+MjwNb6ScjhfS3UTpL0gQQfWfC0egcEJKtXN5QloaQnQMAn7doGJVLC+NoRNRJ/8d1kAA4s0ZkSX/SqAgTgL5HO9sG+jlaAg6tHMJrTt6B95+9B9987mW478hxHJ2uuHvg3d5k2KiKGD8CMMJJ1xrvOBXyUXRsajLXTEH1Gdi3YoqlmmdY7f7T7KP8sef3EpX/3lZTm+O2V3l70RTBFohf99ee8xcuYGd7B5NJC8pztXL/uJyHXIItUdoCBEJ459tAG+vr3Pe9Glzd+pMXRXFv+zh1tWuet+v7HnfccTvadlIdclBPuTh4wEd7VYZ5L0TLKhhdAK6mHTNKsQJN7/OGckbKH0vj6fRD3b6FL3UFo8uJ2JKae1hEa+xoHSCQ0cAZyUksJDng5XzWcp+cLaJ0B+c0D6dI2Ze3N/HQC8/jk88/jU8+/QQeuXIeV25ex5x6cNOiX5mioaW0MTxbewbQN43eVqR9J7iobQuz4WrkI0sMPdgZ2wEXB++cMmjxHnyi3CpJoV5BM5snHhLoEK/qbcdFb2MjLz4yHn00VPPlFOvmBQy9tyKfWX6X9sYRnDBHJ94NeXcIri9cnSWZMrzPaZG7TF8wevBiBl4sQD1jdWkFrzp6Gm85fhu+8a6X4+23ncM9K0fRUpNSc7oGtMug0lA5B2ujOqUNGVPBOHpiiTRgL/prXyt4S+Ws1VsnZ9Qe1uyPUTWkJ6TZR8QbhqQLk1O1QPuItP0zSoPKXqpY5XW0HEfgSDQe9grUhsez/Ozs7OCFF15Mt/s0BII//9idHkVyCQHZftoMwjpsLPtrRS021tdZQFYI6dzeWj+kLFtK5GaLxWKOtbVDOHnyeKa1ZuFKzlT5tecz4lgaoyBGsUaDeXejQO7KGasbLtoce2qwqDkqhrZcaZyMW0k+R4Gq0F/SG7YiVbk29CXDcJiLdFMAwjkqyB6bGy72NTAYW90Mjzz/LD717JP4jaeexldvXsELt26h6xZpiGXSgpemwNI0bysicJejnL5PC1/U1nOeA84ElswJfIkmYCgzBFE78nk90JLGnNCIPsB9BljNZPOZvixPRzEaPHyKeaewvsCH2WRpg+wGB6UmF36NbfpBeRKEtTJu4ptaMYgReoVG3ziCOHAEytvHkmSh78FdD17sgPsODRhrS2t41ZGTeOvJc3jPHXfj1cdP4t5Dx7GUh4DFsUkgnWun+j5Y4Z+xjZ3fM1ycqG0rmFMOfjAKfeS4gCw8uzjV4Zf9jOjt8ngb5ekonf2X4uTvJ/3uI3YG2PtZnFV9yGLVfS0yC44thv3LTnZFnlyaixcvYntrB+0kbunxQ8UW0RoQA/GYRo104bBHwTYDqF4gX65OFkDWzwwwYz5f4Ny5s1haWho03DMVcD6uCm8dLgIAjHiKgZ/78BT3WpXn6RwAZsXzq/WjSzTIW4J5rS2+fPWIuExFZiz9UC/qbTTDIsXU6fGNsbmsWKfPx0BY3dz1veJQ27a6R5HB2FzM8MyVK/j8C8/gM888i69fv4qvXLuEW4ut5NhNJkDTgpYmaEBoe07bjSgv6iLb74tcriqgO13Kg9TQvzXgHO1f8jxkdwCWzdlael+aUqBlRok0A6AAyjGVzf0O+9H3r0VdLm8O3XQkKZcf96V6ByYOVIepVbNsof6hT2MjVgGzgkjleppcXL9Av+jA/Rzc91huJjizehQvP3oC966dwAfveRneduY23Ll6CFNqVMa6vlN7JDeqSPQaHRIbzg2r031bCx2UOfhCIuzTWCQ8oteikwCC47+viHeEzt/rSuPd8u7rGXO09kMb6napRps6gDxMH/SxesFvIcuhL+oE+dP4RBeJgJ2dHbz44oU8fJzsryyKKudm5TNEDimCrqc9DCMzALvTNoKuH0LWYeQ8zMwMLOYLHDiwitOnT9UZO4ZKQSmjyfJP0G+iwe8Dw1kpg53hKB/vEb4kwSyi5cH+tLL8QcXDtmi52FtQQyKItx0QU38ZzGO4ugZbKkY8bCstFuUjYHlJRIN2eLDuAVzfWsfDly7gk089g69cuYSHz1/A0+vXsLWzle4VbFpguQFPl4DJBJwFG3nLB/rh0KS3hna70fAJMqMdFRUDGio6xS/qCC5fWaDzoMuqIjEFhSORO7nPL/2JTm1qP4dffbPV6fDK1GQqhF4fzclpZQ5xmRm8WKCfL0DMaBg4sryKO1eP49UnT+F1x07jfefuwCuOHcex6UrYeqNzuUKlgLu6Tfm/wtDWHvGLtKcK53UYiaHanekjhXdVHeGy13cjbH/PXtHjvsvBUHpK21jaslBnYW/GS/2/RZBUGOiS/qdB2mKPeCTSnAWU43hDWs5fuICdnRkmbQuQDBfn+dpyfrZYkQzIymPSBVLiCChvNzc2WPbUJvpttbEHWBlm7jqLeCWqmc/mOHv2NqyurkKF2BupEGV5nbQoI4ype8+mMvQqdJbll59H51Icj2sAJd6qduC+hi/cU6mrlKvy1p1qQSMeXvq/DI8Fr6VKmxTK+k/FSAVbN8K36Nrnd8njlJ/8kHjPUKdMTrYCA22bzm9us7D2YMy6Di9ev44vPPccvn79Er7y4nl8/eYlPHL9Orb6Hj0ItDRJnuSEQNTmM0f7vPc38YTzHtt0l28ju38cJ5w37ZrCmd/le2un+6z/eJkNrHYdXhvOdg8XDmINa4ORjwY/nQ3sEhfiwC5t6WhpgE7iO0bARL6T1e7H9fSk730PMHr0i0Vy1DtG0zCWaIKXHTqJuw+fwH1HjuOdZ+/Em06fxdnlFRxsJiovfhW8gL4MwTW+qSxAYM6c2gxnULXtjld+ZfjoqmPPnjGZH7EtTrEw6EB9a85bnAutp99XNDuWfhDwZJ0sHZq9ygz0x7w1ed3Lzpd0+mH8Wr0CWCUtADudpsD/kI6M7rDmovJsbm7iwoVLmE7TXmy7q7YGtJUFUmjShRdFdOv5QpsbG5xANdHBfbpaT/bbDiJbN3crQ8/dYoHJdIJzt98+8P4pinHkhGv9GFjVnoFDVItYRyK0WFD0onZNU9RbtrNuSIsN45UyA80Qw0nF+zFzLYJYetjj7dnvirz9PEMgyHVItMtWo69XVzsTgfs+7d119En6Rd/j0vVbeOzGZTx67TIev34dD77wAp7euIUXNjYw42zgW0plTFugTf/JdIU4ThnxU71pLKdQZoKiif6V38UolHzl4u9evKo8o1mHxlOHlAuQ0E+7iLE4acnms34t9Y+IIChHcqg6UeJz34MXPfpFByx6NMRoQTh9cA13rx3HvceO486Dh/Hak6fx6qMnce7wEay0E0yK9suULSl/pd9NosgZSo//3m6UliM4REROzYo2FpwZ2AqXL+nkroyNjwJbqomK967W6sdBOYnAinMsCwUr9nOUtMJO7LNdoic1/ggtMX3ZR5Y++gRjjkn8EvZsB2fZv68XsB97x8x4/vnnweyPWnQXDDS28MlHtekgC1sgRbpAikLbmqZJ8r65sZGakFcdAxKN2LGNuoAqDCsjzOPO5jOcOnkSR44cKVpdAoFrJDmWOaEJN1WMdNyomIxFuT7JSOQ2UKqx4ZRaOSPeYShupGyfkwtJSxxkhAiIyhSWxui0Or1g+uHesf1m+xkpqKanCLASjXh6fDkMuzbQ/5X0k7ZNeyMlLRgdM+Z9hws3b+DR6xfw5Ysv4sVbG3jk0iU8trGO5zc3MevmYCbwJC3FRz44HE2TDjhQzziDcNFjTLADFPw+YWP6kKM1B8pnKcHaG6y97EEGnrLvw9fgFMCEJTsWGliFfNkhIQMHZoD7Dtx1IO6BBYMawrQBji8v4/blNdxz7DjuOHQUrzt1G1537DTuPnwERyZLmOb9rYR8bSP3ec41TcBrZCDDa8i47s431si1cKkDe4PcerAdtjAl8WmcRtBI+Vy3On6FxJ5zpNoEK8nIr+tX7TKLnKievggEamn2N0pVoX+faVJCmK5zfAfA5kiD8S+KGBnF89Bq7aXiIKo6r/ZcgZyJunHjBq5euYql5bTuSADXXxJPWb+aPGUiV+pRuLs2KZKBr/0lItDW5mZSx7zy2IaO47GNPDj0wqXrGX3fgZlx1113oW1bVB/mwIzA7IIBFTZWUwRRLsrfpW93f8boHAhZ8K/Cu1raUaO8xxPKZ1ZvL7gy+yp26PzUK5FXEWAUJBUQaZhupIYB1uRhwDSiwgPMUQFVB5BDIZLWxzfzvsfVrXVc2riFhy6fx9evXcHFzU1c2rqFZ2/ewPntddza3sRi0YE7Sgt3wOjbBmgaUDvJfxtwHkJKDlCJYFCwkDa4huXfZaGSoVx1xKEqD76fPLJnUCplXN45wFWu5Eie+xyZ9j3AHSTKBfdosjRNJi0OtMs4feAgTi6t4a5jx3DXoeN41fETuO/wUZxdPYTD02WsTqaBB9ITalNpd3nwC9liyvFxsPjsR9idtxmMMWs9IVoraHAc3P9T1jUgqdZa/yIqgel23R7tJzL9vdqcQvqK3wazp6MFhJW/gzQvwZ6G9MHNjUUMbFG97TK1sFjM8fwLL6SLWtwq40EE6/5KNKv31xLpymVpq/znQZ62traYe5tPs7nZLjvGbig5b/uRrUBgRueOdJzPZzh8+BBOnz5db6BnWBga4eis7ieyCgyu1FO834+n6Bc2jT17lTMKNLuVU/t9JB+5vKVhCl5geOONs0UNwS8u9b5S+5jg1uaHAa9LYz00BO702UUR2f70BThzllUGp/1tACZt3ngOGvBl1ne4MdvCxVs3cWH9Ji5t3cILm7fw6KUreHbzFi5tbuPGfIabO5vY7LYx7+bpjl8m9LKaloxAIqSha73KkPL3tP/OobHJiUTLgQ3sPgMSxdo8lzMsedomh58QMNV+7gE/SU0AGgYmTYOVyQQnlg/i1PIajqys4vDSMk4eXMPZtcO47eABHFtewR1rR3Bq5QCOLq1iiRpMMl8FmKS/Os7HuTLbUBpB+0GGgCWfyizFPh2TjtozHKkx9un3IJ5e5odg61k+rMvbBNcD0jfSHp/I01l0aWiAlL+XoRiJSEejXJ/VFecBez+2NJQT6rXC4hyvyfRLjaLro3uwwCTntfa4vhvFgjGe1Gk7f/4CdnbyARYNgdgviJK9sxlcPejCAFUj2QJwffsZGWwBA1lbaZyj3F4ONvD33fYW2RYR73w+x7nbz+LgwYOQ5U8ytFjCw6iSUUGwG3YUZpE3YMK8lxrZjkWhPknxPXibvoyX8NgCD1fWbuXk9GZUrP0v1fMeDq0zvAUTQxAXcezWGAGH4XuLhCVdaM5LITsOT8NXlwon2O0tQN6aFobo0j+WP8t7ztFnAN9cbOPq5joub9zCzdk2bm5v48rOFq5sbuHGzg42ZjNsLhbYnM2wsVhgfT7Ddr/AVtfjVr+D9cUsOaBdjw5sq/yV+niASGyLZx4B1GuL22aCpXaCZWpxsJ3i4GSa5kMnDabTFkeWlnHq4GEcXVrB2vISjq2s4NzBwzh9cA3HlldxdHkVx1cOYEp1g2COZl636UYxCLa9QWjtAZVbMqpzuVJO/C6NDY5Q7tdS/Dk7KVbGLvDshGJ4cMkQWl+SzlBhvsuhW5aFXcK98WdQb+FR11YCB8di3ySPKFjx/iXxwT17matU9t7Rby240fZWKyjDC7MIXqbD3HKtmPz+1q1buHTpct62yi6i9YujUgF22QCF4xh1NTLl70BwysIojoCtAivbauP012/56dH1HRiMvhteNi/Dyg0R7rrrTjRNu6sHpasLi5jp97TibqR8l7ma9yWvWB6hR4WjlMQRD0/EhnIa/RwAYlgOl3k96Bp6uwZEIIwOyD7ULbDN8S0ORVTKLjK7Zy9+DnXEvFly7SIyx0MMn+T3W5KYfdk5Ks5ymujJS/w1Qtt9MEpPuXbOCAPY7hbYnM/saNM+nW603S2wMZthq1sUUzV5UZBDK2KghR39hibNXR+cLuHI0jJWJlMsT6aYNi3aHFVLdpnf9lzzc/pdjkplQWRoGec5p8wD9dwB+54BMHZQdnaoKHMsCgp9bbQpwSPyVoKtF/X4WFmxF8Xx3w/EGG2jc6R7RZuFEL/kqM89L3UO9qW6/4EjI2VGB2kkzT7atecq62jICjtvArLfusZ+WywWeP755w0sYcApw8dtm96Xv4dhZNhws5AogN80jdJAAGh7e5s5WSN3FKMYK1t1HCPZvoh0/YplYNEtcGjtIM6cOTPqXPw/9uzixQ2M/z7DKUlrdn3Ygv14nH64N9BbKSdnSOXtUp+vs4z8x+oYIzSu59zdE6XSMNae3To7/0a+pkE0Y4BYRuFCxSCbN2iSW4w+uzbqSMSwYir+amaYLHBITOVH9+MYf3bRghHve9cYJGKPfXcjLgK2NgoSV4bvFXkMIlRfr/bNbvLgOr1G+9j7SED5MaTdj8Po9Tj0pzPG1Z7zQ+Ch7mHPDGS1APvasPNoXtSBolw1vefq4t1G3yrhaWn3CKhHmAX9Y49fILTntFklylUqRIRcOTLiooS+xOfCxQvY2tzCpJ3osYo2TFw5vEJB1V1EIFdckXNQG5MnHZGk5BRPhM4+B0OsBh/OQJJ6lhpNIOqdMJTBaJoWN27ewurqARw+fGi0wSY8gNfJvfeYMZitE/a1NL8i7LHMaAPYml/1ojh/rtpJAdmaI1AoQMAnST82BOQ+67da2qBInrmMMM5WBBS1xQyj8zz78FsG7k6p+yPgnONG56xYhrhoy9rDEs07VCSCrQUgEzAVbWdMJWBTUksiWWvRpjAcTxTYh4x5KUPmez3l3DYAXd2a9LDRBnr5FODNCmO6w3VjyK4pEYhEtrIOFrQUxGKEJfBzp+rIEfQmMKnL1eCIQ/WzjbaQWwPidKE2clU4J2VjxiLJ8hmsPShku9AEfacyVLElZZm7Ahb5yzrq9i2UnQrUvKN0elvC+k+gv05O3VHw5Q1krkLD6ODkwFP3mSKB5lill7du3cL6rQ0sLU3V7fSnQMnCSC2I04p8kXtd/KT0JQefGotoNZ9rwIRzi+wYx/SjDCOrQmfFUWKIQejRUAMGg6hPY9l9WrgxmbS4dPkSVldXMJ1Oq4a1tjhm7IlpkjnezeDvJgjSKCrfVZRR+TNShjyjirCb5+zLKUFYPL2yHqJImxFQL8+ndA5NSUzdVo4oeU0rBpnLtE5hufL7SN2xyOG7ENk45zDWWzaWvCqpbJeGpEKVx6pAP2uB8sFA2FcWqCmt7m6fHd1DqiLBFDq60gKf1us3vE6WuTj/To7PNjYioO2fct6OQAEQC7JV3muk1/VLjF7plPmC97YtWv7YSJGUtIedkumBaqQ6LCxQp0GOT2IFV72Z0Wky7LfVlbwF8LJPQ0mQSxF9Sc9+olx4vvhKVNpy3ZmHTHFaKyYPdnS2s4PLly9jMmlhIJt56f6mLJTXP0o9siAwFa7O7Ehwog5QBueJT9Qzg5ombQ9wBJMyWBahJIIaNOip14YT0l2oPdJk82LR4cKFSzh37mxq8siwR1zwI4x0/NoLjCvCwiPvBwzx9PgiK+92yzv2+EUlYWgahQIWij4cliqUE1EZdJtJMeoQyiq9vzGgc/RGQK+UCaDcryse5IBgX2+FwcRu9j7IbJ3nLqgM+kgB74Zehc39UijHMhlzaqaFXNmU52XsB4S0eqNSKF9I5SJ5/j0UU8qtyYfNe9aRerCaFKZrtUBgdyMo8seOrfF0LLEPfh64LMLBdtV5Sq98/hHZ1ZfeOvk0Tj693rmpHa+N8dhd53Ttw268lKChpM2XPbZmJNC0WxRaeT9qb/b5aP+OjKztJ8jwT22kQFKa9nkdkZdO1nnoWNnoCI82tO97XLx0SWsT12EAtAw3HJx/g/QRdMQssqSQt8IWMLMNI7MWxhnR7VgxzrwTZQ8r74jSmfENgbgB+h5EDbhnTNoJtra3cO3qNRw/cTywvgoGrkz/fVevz6VnBzaDZ5fhC09DAOmxoRBH/wCzKhGqTz9oR6VtZfk1mgdOQKXOKh+G2DEgalQpXXpPdZibgsyZ7lO1K8nK+eG9POHSuMTkhbkROz5KowCq5yU5UTAQLdOOUafakgF1d+O817sMLDyUKG/eRGf1CzsSJNWYR4nSYBTGTz45h6WUUx8hWA7vwJTHFg4q0BdiEDW9866CHPoIpzJEGXTEpRnxyawcAZeaHZIhxYqM7im3g9GECgh70iqRc1mDsnPEWR9zJISOsZ0e/mIHT4+nsygs+NS7PdoLRIU0FZ8UiEYKUmeuXuuVq1exM5thOplovylQE6mc+YWS6SebvwVEtv1Qsr0XJz7IRKZ3osSJ4ElkRJT3WIvPasjeNHImaq6ALaRmSvsc+7xtYTqZ4PKVK1hZWcHBtYNVICgjjeDf7OE5waWxeePQxsFTnYMdiYJ9mvAOGAiTKLOAPlB4hLV6d6MNdeUp7VIJ+OVc8YD6SgEhuttrzmc3bHHP/uaOajwpDWXdWx2NOlxaZtdcp6ejKzkDmbb62ZKPA3QsMxDq6BkzP4VTUKFtfOW88S04wpK2zpoAvrXHDynXqa7oxW6Oh+DgWP9qRRF8yhE1WcQZSGBfzoiO18nZtVUCsoP0xahc1Y6MyX/Fvgyi2prdyLY22JYKbaN1VWRGK+RK343ZxEobPegoPSNBS+0ZXyeipUXvsVQX1dOhjhARbt68iZs3bmA6nQZAFT40RQSrziIZADPsBKkSaF1LCv4bH2i2s8MajbB5zLq6GEA62CL9Hs9JLm4GcqdQpWP32L3rceedd2IymeD38niPa2wusQRnb3jk7X5WCO/3qZvHSEOt/NF5nV0jUvM2NRp23uYYT3ZrZxXEZGjyJbCkCgiRIfGTE/KSln2vMBzxqIwPRfKstHsEoRXaRX68IRlbuT003+JElmDNWqL8O3ILVCiHB+2qpNz32yFe7Vl4xbvchRIHIuUK81oEYjIQCollZhqGTkN01ErnmfTjS7vdq6rju4x8eRvkh68J2HUh5+j6CMk7QtuuLZEAqLSTRSS9H56M8YH9bxn8SzUKoOQdhIodtCmvUoEzFZ6h4ee6Qw4Am5tbePHFFy2izYdPUONPirItP36/LREG99p6OhWYRbZH7BEANHIAu3hTPqMV6I6pGosmyFdGdmUWmRC++OJ5nQ8WUJb/xhilv+/yzsqoF1J6pAORr9RRq29XgZT6S7CjuBhH3tUeKmjz+eRzGHaugJzvN0BklKoOhQyfhN9IPL7dbanUM1AWyenaHRfJDIEW7h2DB0bY16X/U6VE6OCwwIdcAhLFzhS4pvtyQ9U5q3ap1kW1roYMI0VdoZBO88mBxI5+4zkP/hu2KzBPWF48vozhW/k25LgjhspX8i+NFT8qF9Fe8CCdzKO5gjDGB5+mBNpaU2r0jclwWb78pyzxgFBGUiMjSuFuW+xiw8qynAMudcswZq1toY1STqWOGsjtPh3iG1O0G04EKN+4VZQd8lbeh/oLhVF4GCFvDD+ICPPZHBcvXEh70h3B3ukLelsB05Te0UWFo8DOYeGsUczer0jZdnZ2bEWNRLL5+EY5hhGQwy3i1XtldMvMmreMgAmE+XyOtbz/1ijIxDoPP+nx/r3PwMWaIaf6kLQ0G/JbIcC1PN6iBWXy5eR0Q8Mx9DJ382hrwziBZtRbXH7fi5Oj3qTLO/CGpRbpq5JNhX9b9cwLjzpFAlaullNldKZpVzspvK1kHtApKWppJKeAsdQbwWOkCtQaUAZHsd0SwXpjhKItVrT6FAP6xWBAdVtJKOst3g8EbeSpzrvu6xlWIPo2Jr+1kao6TUU5e4BINSIt85Qd4OzFIF1tdMnxf9CFtXIq9mjMhtQCiJcSvdeel7zoC6K/laewmZ4Pu5ZeqNlLbREz47nnnsN8NkM7meSDYsii2abJN/vIOzuwQiNc+Y0cRpFFxyxg7RuIOt8mqfHpXxXqhsB9WlGcLpM3lKbsbcpnVQAZfmwA9BFEiFJ5k8kEt26tYzqZ4sTJE6Ec4aafnxEzrWa7Aj6ufRh0dZmmYEAAU6cksr1GDsEXoRjYFO/B8fA6Lkbdg9xt+CSAj/+9fOfoLunaTYjH5qu9tzwIxbQ8GjJhRANs/jBzzl34OhrZe3CpImydZ1LfgAaW6GnYLA9OoV4yufNKrrcEZTISj73BHR+KGzr2VIqigSygvIp4Hve1ugb4RNHJoUFqV9fwYbfoC769GBoTqyKhfXUeFYX8a5mFk1UD3eIZjNbI50I+S5tRPnuu1yjLHfNyiqgs0BZs4pDmWIwrZ8S++c+jTvleaUo6yyi6ksb/NjaiWZ3KK+stf1c5icsszaX1dqZmB3Z3JiQaPX/+PLa3t/NxjEmtiKB7ZskVT/k+MHFeNdoFbJQ2tJ/cNkxb0wQMeZjJwSRriiYy5qaNt2krjxiujKRIngFz2nfU970eTdUzgIbR9GkLUNMQuCdwk6LkyWSKq9euYTJtceTIUYRj2MQuj3i8/rs/lNpnD/kcWNbSmGEt7ARzvmKtiM98eRUlHFA0ElF72mLyukGpPuIcjHmTY9leQtpB+OVKGXLWebYlbwTwMjAwD/OWxNVXO5dxm2pKaYGrNBSN0wo5uNAck2gqV5dvvRr7oQGqORVJx+p0aCnkf/PiU5FkgpNLcoukK47RXo95FZkW40+VBE+1dDAPHZjaOoKke0PejdJV8SCl38ppCpTfRZ8x0idF06rOoHfGc5m14VFy6f0CJi1j2Izwe1Xv9+EM7GvOlevjhb6McsHXXk85OjUAa6Hfj0qI6BaOoulfdB7sVyczQjN4KJPMuHjxEm7duoWlpeWUkyr/Nf5zql4i2lSHRbbSBtPUor1V9pPqE4EwCWPLhTOV3rkoTzglJ2AA2jlSY9p2m5jSUJPOWiYASPt3idI9gRcuXkJDDQ4dPhz5VDBPALG0p7GF0mCXiorffZRaAUrXzb7EgndD5apRNDZHsZfHObYSefQhCt7wSwLS/Twj0Tcw5hmPAFwpXMEAvSSCAGLQrp1U1OFo8MmDs+DkN5ZhfwYB2iBN4RyM0lZzF9yokgdL7DNadp+4BrJ7ClKRvig/+B+1yBCxP3cDWqWSBMwFoL0hLvqMECLnwMFdIi5t/kiUSAVt5g+W4B3rpSJN1RbISFel3rEn+ouRz+bsFKBeAVAao38scq7kK79zqU8jdA7KrORxaDFI7wGq9qjG5P20hHwHuDofwJXLV3Dt2jUsLy8npjaJNj1vHKRnoQN2f613MvTOZRFMB7SQQCw7zn6brJwiJSPAJFsgmDEhkeZBA207DmeC0p2iqXbKXnAEFlIctkOY02lT3DGoleFpwiQDLlGDtUNrqLquvnN8Y0d7YiB2iaxCQLkYdjEeDt+VClBNs08vs/x9L+9xTHg5JtL3o+XsWgsCTSJIA6VOifZJZ8of+SyWkjTJrrR4ox0bHPOX+Mh1BR9kKPsi/+P0NmSpzQ9XI7NKu8blwVeU5F+OLBwWYkmDH1nUXz1JR3hZLbZwEkJluz9BH5xgVvWEDWQlDZBlx7eZY/3abAc4QY8rNA3yagNj3SWAhehrZFSsxpmxcrwe7esp0ldBc5fIvFoexuVP87ro1PfdYNFlHkkbtdRlBDta62hTPFXJjPjga6Rir+/Xr13HpctXsJyHjnXlsQdR95/M00LBV+ZgK4v3aCiZ4jDqSA0XToqjb+IzmsHVV6BMYF9GBgQw+/kwdsc1SlmZQD14Gc7rb0DU44Xz53EWZ3BobQ31QQ7P1MH9QBoZ7JqP4v7bTKD+5tPZz1z9XM6PeA92oHRFmWPvajI3aJHnf+Gpk0tTVDTwfMei7vBOALdMM+IZj3nAfnWmN+Rjc60xst+DKxYyhO8DoB1ErbFdgzlFijItWSSyImCwhaMc2hpQPSoP9c9h80Rp7ZWg8j0XacpXzlmoqgu5/bj7cGxR4Z2vuuRvHpGoOaajDt2InI85q6Ogsg+9Hp2HLOipsXCsHC+L+5ojHSunSFNrZeDEWFtG0g/mXffoo11lw+l/lVe+jKr8FA7L2ChYpVnXr13HxYuXEtA6GyYfJXiUOVd/7zSF9KSV2QiMmAezNzoq7ABzuC3QWkzz2SzbEYELskLEy+R8ebesUu77lJp58J+uWs7pe+7DXwE9drcGzbsFbr/tNhw+fHg0ehxT/+B/Bs/Kn9w67KthBbmG0jMei4Lz+xoo+vx+0tx7yx44fb1VRSp/28W73VURaWQOWYfrinIdzTXvv0bLnnNHvvFj9AQSIpjWI7H43iUYl5tgUOEbhCoXx0gcEapqKYUgjs7RO8NDXPB3pJ36sSyzgsE+AQPwl81r6mDfI1Dsdz5v0Lcjo1Plu0ELK/l+T6ttawZ8v88eIFKtbo80pV0q5z+xy/v9zNWWdAbQ9HpcKV/6brc57sFIQQnKlQg/+ojD0YqagIy1MaMVAODa1eu4dPkylqZTrZPI7qEF7Mq8dD1eXIUMonxRvN3mY/txk3NLbvsQOTmgpkE5cuNZJORPEsJzXvfkxpsd0PoRNPnd/kqB5g31IMvEueH53FsZjtAFC02Dlls8/8KLYABHijlc6w2xiLF7CF53zOP3Z2SSJVcagSGOhiHFEGVFcgiwFcvunXC3HLb2ZZfv9xNJlqIWBbb+vhohVEC2+r3qVQ6BuPp4cIwMyP3gftit7aNV0PAjD77kj+QXQcdACYUkebmp1roHsBcUeGm1hVzREdt7X+g40I45HT51YAUXK4o1QiLoWgcq8lfgYjTi8pQVAF9zdqt5C73xl26Uz34XBpXl+whmt0jY2zt5F4ZRiSrcQVyB7C3tbqAVqh6+LYfGqUJ7fS59+JR9IeUNho7zb9VRhJHIeax/WfNwWBSlwVwgiAaMKWkr+XH1ylVcvnIFS0tLqT1N6hs7hKK4kzaDqi9bho0lqI1yUtgOx1+C7a/1uBgbn54JgDwX65hOriAk74FZiGjMcMLmdXXVMhgNCFyuUgahgR3a3mS+dh2jbRpgMsELL7wA7nscOXrE+iAIjlhEwK/yUt+gfCrGwwPpfob9PL9K41EzIrngarmuAk0zltKv7PVKPVbnYAGDB7BadL6LEdBnDKR3yRPmG5VYUgDS8qT9no5CQVObxo191SEaRNpQBaob1wpvyjYlQsuaaiUNUtDIL15dYxnFnNiogOwNsuReSdlltZampKME50pNbO2ikcQ+27C1Lk2tb8aGTB2IaW2FjI9FiSFC3U+EXgNMtvUIo+2p0KT1wvHOpRmLan1b9kHxIMKstcX3xV5DzaKLfmHpS3BxnDM7sFrOvjsL9xIKv3z5Mq5eu4alpRTRihNk87L+ZCgD1BTRkuX5/9d2tW1u27j20PZk0qbbJO1227v//7f1vc1LkyZjj8X7gQRwAIKSnHT5tBlbAkEQBHEAkpbIHgyAu/wFyX156QYoYpF+8gQznZ9Q+p7s4gddURrQE4KllPYEqN6h/lENr1e2uv0hyjpQB7QDUuJqlqr7wYdScDye8ONPP+O6XPHy5TdqlMOkoOzITjZimADDUiEsKpUJmk64MFEjyBpPMtxJxD/b/9maNLMlxmm90A8HPgK4oX56SjMD4Xiv63kbfqSh2IM6tjMuM2xxnTTlbWDqT13WTh+5XzNwju1RXaGYhHFBoAhwfK2O9E7kkn7GYPPyMe+vXdOwWoncATAdpplO8h4z9E7thDOVMEcsXsv7uLqMmgSLbmyTDLAwvdhRBMMky438QfUy+Z1PET/CQUTwxVkmHwGY9ZXqjWWP7XL/WQfxGs2P2Oc81xdehYh9HwfyDriywpo9Ua7Wil9/+w2vX79uv6Ot0Iw2AqNkqQy0RmOfa62aHLalZZgc1LYzaPU3rJfgi0WW8+VSfaQltLIcVFVfsi8LyN5sv9c/t6dItf3cRfZ1aW/W7e8ui/KoteK6tIdnLHXB9fGKl9+8wHf//m6INtZK3N/bCpGqi8jziVsxc7pD406Grb2U7O4nLY31Et1dCfc649jg0HZKF0twYim1C2TCwTZ2EsnknTab8WJ5FWS7HkvQQwJExcjbh9Qe5nCxuYepS0Iy7oUC2DGKT/AhYwqXKegfaSQZF53eYzAymIUJG2+oI5wGq7MOJJlnBoJR9r37w0OwlnVsZTVnFoTGuZ/OW870JvK6q/9Q3+cH7xzR2M5aHV51yup0mjgzlF+qY+IUA0Yxl8mr8dr06XOo29v1uuDnn3/G+/fvcXd36kDa+MkerAAof9YlZMp02/2DgbDM1WL7tQ5sOciVebfiw1gLJwZajZSqOZHqdFDUTkrPKJdlUSU3etrP1XsmfDvVXHEFUA7t0JQJ3paay6ng1Z+vcX284ofvv6d3hnpwHAeGsmYaWO9Q4YzJxWVJRhqby0CMgW5XpN0Ic/knUazPxCaR9ISGr033jmeFJys50jKhmTDxYsSqyaMO9+wR+b5IFEzkFXF1dCIZ20NWVu7MovOo5yDb7LWbIz6YhE3/TCD3xJK7/acZXT7u2dBV2MEsF2Y4R9m+Dnt6AsBZNuh4edumITOavUCb0a5ly9ncnmZZYxAbQ689jnYq76TvrFsOjhy4TdrOfNTYfBgPoZ/Mu0zO2OLct0yk4KYmqyeCCxIEXM4X/PjTj3h4OOPu7q5fryjglwfQwafeV/2flo5tGTkAbfclQstxnPpoxKV9XhL3PdfA9nI+K9pJljkOViXbbVktKmW2HZwlg13AGSyfVvbZrNLXRSNm473gel3w9OlT/Pe/P+B0OvVOr5lw3EOZR3WqpeQGn2TOqkSe6SGCWC/cuyV7nQF/GnXG9ootmUcnMZPP7SdF/kkfY2Se8fQV1jOBNSc4yDY42YyJRN0EOtFrpWUW26+P3XBy1EXDHCjZ/Gn3jD61v0/y6qNscVlsXNXybTpH6FYo/LW415WDfiqU1bthpUNAKD2py9nX1uoD5jY3szevN/GSJtMnlaCnQeaVLHs+pj5YXvee8ULJxy6uIujl2fy3OcNj4aQp2z7xw4cP+PHHn3C9XnE6nQwkC2DvnD24t/gAZdizFUA+aEZ7GE8aU9IjAMzhSXcnjW6IyExvvMXawFbTVf/j5pkiBSTV0HuU3paODURrbdeACLBM046ELPL7XP55kbRzOOC/P/yAL589c3LEJebBf06i22nEHCJ3uagnp0PdaZYVDH+rzPhkZQ1wU7ANNJjQzORhHa6C4Ix+a1ImulrFQXZsdN9Fk5OxyGSwvZYxYCqaSc4DpeyQULsUZKj0WWUegWuUmaRz9hn4MBgmbc2K4+PGhT66FwGzZDGGT9rdtSrB5J9mtzHgnR76mcgzBAgJzazsaStUYKJcnlnmOQlcdq2w7JBnl0/Y1RawFQXOxiIrb1+/wS+//tpA8njU+j5DPdAycf8Zz4FA+OhPKRfYsjIAl/UOfzlIKOFdtt1F+BUm0ov09/F8brmsH9G+vEefg1LaG4Hshr71p06AtS7tsBTgstulNpAd9nQlc+48rtcrvv/+P3j+/Hk6WPx9GLiq2thVZKNfHZzzHcEZrBjJ3v2mYRn/xnqDHoDcUZEeYo3tB4oEVrfQTHTEBpuBZuTrn6m6niVNAyrk47bXlmRrhSP1GY9G1cBvzCli/hoNTWgiqI28pg8GcbpdH2N2FByI6N9pfDryTElphUXknI7QjhWiWRaVJQlDADXYY3jkH9dfk2+SmIx2UNSXBuFyvpMS50iasSerCe67ZLchsZoFG6vyBJ3n8nihXWZbzOYGRffkb1kW/PprOwh1d9feRwvJPEFgq5mqLRfL06EOCr6U5UrdUgACa8mWYx8BeyFBTe7pnNT+jkFRuVwuiqbN4OLSTHMCLdtET4LtoFQNyzWSoS799Xx6TcGXM14DafTsVjPcKhluG4haKy6XC148f47v/vMdjscD2c9W9gKfQZFj4bIn0opZhyqSnstcfYV2pe6MGqdt7aDPaDj6ChGXi6pTjp8n856MPY4NVXByGuDSmUcXBeo/0+xInMrgaieTax5t01gnme3YFc6guK2cxkVD4fKWnPO2WCfb2VqWaVeSoegF+r2uiL0SXJGgJOeE5uZxQUozzRK5qYlscQ/TfOl6gDPIzMHUZOXI8ceNheaFs/EYCCT8Y4afgQnLxsWPhfVxry/NE6PG5uPHj/jpp5/x8PCA0+lke7CHgoLD8FJ3AVkFWxR9QTzTSSbsHl4hAYAsPZPftL7IYxlH/RQ/mZ1GlKaBrV3WbKMGgyImAo4NICtAweJadqtg20FUouj2f3/CFKBLyErXs+tagcfHC+7v7/H9f77D0y++yDuLSZQloyifatUMQrzHOPb8/Nd8j8hxj3KADDipt7XstZc+RuwabYZ6Tpbe9xZjZRH/jUUmZGgbdE3oxmLRLcFXQj6CRszwM0Ddzj7WsqPW2vqKg0m9u0y9/XhflorzDJkAlP4MLOOFnSJPwVDur64oYT1bChkXg4T6os8oa12cca5hbhhxSW0713VyfmR1elVxvtqgjWl11zNG2dDusdbseqqr6F9WeDd5Yu9v8C214tWrV/3Z+QWn07FxLLI/W4DSwFOzWcpYD0d/ArktLxe/hwsPsHwKWcZOggH2QzJEtv203Rfl5zJb1XQx2+pLv1a3KuCI064g566ZKnymmwFubXuz7f7i6nAWLKAufK/XVv+7f3+DFy9e6m+jYvETVaJz/wg8F5BQT2/Z94s0W/TRoHdlKSv81aHMMskdDmsuQ5S4DvSzqG4a4a1knkqTZmXedc72GLnsycDX9U9RLSgY3WhrP/+RZlV+iftYP5jwt5wTKPS72dkRbZfITCL1HXYVM6WM5x5HNeinjrb3SXySz9NA80Y9eFvd+s12FJTbpUt+8uQVeBWPS8hO0+CjTqAwZPL8OePPefnwxDK5UzDXNYDr9RE///QL3rx9004bh8y1NUnLxMWeDnU4+KVkO43Mj2a0ZXQFUclsO4i6vdku6yGMcQ33RxtrwZOG/wUoj5cz0dFbYovPxszx1P5fpc8j2PKeawWBLfzhKAVrAdh+bal2SEqu19roCgqWuuDxesXT+3v88H/f4+n9U5KLOw1V4jDGFche5yR9zYwlKz6LLl1N0UlSZHhLxC9ixgmdGGyoMfIsOqjTZmdL7KlsUX4n10okTwEdUdutjBwN7vS+sA/jF2F5q2QrIlp/Av4KeCXuQ2YqSQKDUNb6vlohlAK4nzr5vbixBTfWQQiJ3EuwZQ/m86XzTyq6dOc76LaDRO7i1ZDtzdY430I7URujYmPnkuBxJQNPYVHm35bipnFkiUipc8EnDhjm6RCkZD6k5is4qSYEpIcsHgBtq20advcbb968xS+//ILlesVJ9mclo0XRA0yHQ9Gl5PbZThfLHqyCLqAvi5fDUIc+URRgGcT7/5keStRhZjIT31gAlMfzxdyL+MrAxFJpOThlBEvtb/PALKOljJXv16UZyeIBeFkaiNtfOjilmS40s75er6gV+Pabl/j3t992BxgAt8To3/et0Xl42RP9zwlyb+gmHw3KENBmjtlFkI6RXuSgaZ6lZDL469keHYCbM2fez3Rd4UvTKDkVGXFaR/c31NvMXkogyft46/7nP7bHWLzdloQ+DB5chYxP8UFLRj/LoIatpYnMWbi3Z5VhSj+RjUHD782aUaerXoHPiFTxcw3tTuyEfOPU52QJQSwObJOxCHHJ59jknj3b3asz7FIcs1QkoBScz2f88vMvePvXW9wdTzgdj81+dHlXwLCBKy8Ho2e+/PMeefqTgnERkD5QPQNXcUgHZw+md01uev80JiSauW1Dk4RyOV8EvoZ9O9aVTHSbRH75GJq1ApphSgbb6WqlA1FCH04myz3LcOWtQZwt9+c5y2RagPPlgi+e3uM/332HZ8+eAaWmhui02fvBf6Rntv/Hvd0uXmf+bTop2NJ9x6eGFrM+TAaYI21Xq4Qqsy4V90fbH51fRkisJ1Fy3n7N9RBmK/s+zjA1EBTZYv91hgwNuAWOfJyrjzw2Ay7H3tlDBHfQvSx7tq8xyMgAxJ85cIAX9DHUDk7Rn66sSKbJTWXWbnGR11hGJ7YuS5qVhSUHBmi9PlktcnZGOnE8lLTJpk4aVvc2vclxKu+D1mSrWSsR6MpI8r8p/hxBRZ30oeLVq9f47Y8/sFwfcTrdNVCiLNYvHyegivg7Wk8DwD01inlKcJBluGwy8SyI2nIJY5OtFFBgWy4P5+p+R0oqgryvNjjauDzDzkRBWYARdEAKcHu4ELBFlgkv+oALXVIGFJBFBKEH2l7udbni5fOv8e233+LJk7sQEA8eDKgEpzXcS+rNom0GVbvso1APttxWBjIxaqS6xG0cX76byD+SJiWPvGd1b4+qST62q8nD/m8JUiLPbN9+IM+5oMWkY7t8prswGE2BwwBikDmLHiKbIWis+rxyANMVh4k5e+DZk1HDj1c2Si6GoxWNFgfVkaf6HOGe8c3lnK2Y8KVCOv+f7PFO6KfzogSasj52mLU76YCbdzvmZgzEFIeDQ0m3QWY+NTzdgVc6Gfxqrfjr7Vv8+tvveHj4iLu7OwJPD3riV+V+CZ/tzT4NjAFopis80lfmgYIZzW4j4Hq5tZsoaMmcBc5xq0PVRIBczuezwGNn4wHUg0gDyLb/KYpsg+gGqlqU10CM9lwjAFe777PdxbJbOhyly8/K035iJCs41+sVFW1p+eXLF+1H0MnEM+XZv9UhwUqZAC3rbkY/CpA3OHF3FtwMdHS9VjeZPNdKhPOGo4N2B7wq01kFt/+3UQSnnNwwp5BqZQpoUlkH2vMoYQic/EMDJtyGqnzbEzZyiwbMoCY4txDy5ogZsmNeBQlZ3CcVcRAkgqh9CDbJIdaaKWsEkIE+Nr6lk41iW0PBBgbvtl5fKvvlxERcrpPNizV6bdR/qaHdbF45ExjVNsgw6/vq6hO3seLDnJ1Ti2aOjeL9+/f47bff8O79e5xORxwPR5dpukyWTg3b8nBb7o3g2+yQDkFxVqs0HkzlrwNWr5hV3awmYbRiInFWuVzOFf1ds36SVTtsQXDslg97I7xfGxuuBLjiFBzIyu9uBURhmSzQM1cF10Xfi7u4w1NWV5bjaq24PD7ieDzi22+/wYsXz3E8HKdRK1DcK3N1Yhf6DLjzOHFgss/TfScqzp9yRJtSf2Z0PskWuPhoNec5pZ/IwHvU7v0YtDceD/fc0tY0m92zKpHQZ1E+0+jU2BPxJzAxC9CGAKTmBrdnT7js6csg1ARoVc5JW95Qcvpbg4CJPjlL3GXPDnByIF3dh0z5ZEFuHiTEGrMsNFQOX2RActnc74EHPQiw9Narb4BXH3aNkQvu9B+4S6F8+Ptv/P7HH3j79i8cDgXH00nBrRwO/Texfn9VQNq9i/bQD0EV+r0sZbcRkAEDXFGFB1xbvUWVba8W2MhvbnXPFt02KMA0lUzAlqwgB9uoW0B/kyovDoiGIxnrELDJwEzA1u3HIoBn5T1aeTAGAfwSfkbUrwldKe0NEY/LI07HUwPd589xOBzVfDXo8t1yna9l3HNIyD671FqdUYwZQokVLFuIyz0cFEUn7RKQ27MIJ2cq6yzSFbkiYQnE1V9P27UWOJOZthtl3GirxGtB7sg/7tetJDXrtlJ8QFeTYd9TVE+53/WFdJHJNgUr4ulerDDYbbfesDSaZ4MTPhwIlBFYnd3O5nLoyzi8bmIMNG7uJCtgkbeTJZu+YjOaga8/5StbqlwFx8Gf19z4AlCv2We0YV1RtOqufPz4Eb/9/jvevnmLUoDj8YTDoYXbblm4lHaqGLCDT/2aAF7+v+cjWa6BrT/4FPeC2acY0Da+bUVBxr3qENpQbsyLoLMBbGV4GsPONgyAW6ahewKOvBjN6/b2V04bWx05SOWfINVGL/4GF4Dt9V7tVX7y6EcGZfS+XK9XXK9X3J1O+OablumeTicnmync9/W2fRsfcKR1w1Lf2vLMQBOccSbPEGw6GexGpaULNh4feU9kuyHDjL7PZRHKprj9q8294gieOwBplgW5lYvZWKdZevunooZfIBXHdU/mf+uKxq59xQG1+ngUG2kZAA2IpUYxOfw4MpjlGf6eVYkx65N/J6sGO5TiA8m87riHmQR6g12NKcitKw7x/IXMvXJjXS7Tg1MbPIdau9qNWxfMKMhXgfd/f8Aff/6BN2/eAGggewxv4QE6UOpvYOUnPK09e4YxUIrfmy2HHHCFZ7PNDpri3Q7NPuJLB6iHQGm/qWW/H89H1E7bAmH2Bawb8/U6j+R9to3GGxqLEZFbI7saolQIgNogaIbq7jMQL1gqwjXLamX/tob/QZmxHZyyOg2EKRhYKpblimVZcDqd8OLlCzz/+uv28mEqg4GWqVkrfbpXyZlnI7Rbcn9CD3UclSpkjU+uqw0UR8PvjRwcyIQHs9gOCxLROMhgHpFZcX9c3eke1w6QNfbbYDs4laQZk78OGRvzG6wm6GEupy+36DwtE11p9p4BFAmzvVTrI5/Vvb2oXOe0Ay+Wi+bgPAOMEN59Acbn8XZBc9XEqTyiEwl/Wxky8j3LtjtKjD03pGgrEbHtruMoo/gqiotDQtH+LsuCN2/e4s9Xr/D+3TscDoeWyR4PqEvVzFX2VTUDVZAlMKVM1WWph2KPVNQlZTh6/Z+EKx18mwBQ3BKS6r5noSD0np8vY9A0qrv7g/PlTOdx4bS4x+nZcoqNQMxiq+zed8MXIG7guACw1/vxb3FboiqZb+Mlr/ADAa7bv5VTzugP0pB2+yGrtlJQca0LrsuCQyn417++wtf/+hpfffVM1/crTcQtsG0kfhJDNerCTL3u1KhfoqPnJ9AYR06jzLHTfSA8JStG80Ij8lW3X4pJ3fU3ACSlxA9J/SSLqK5uYFVr1OqqSH4vkT5S0DG63K7TSca4ZyXCyZDoP3mWClfYbGtXBuXCZa48ays2MpLP9qg9RnqbnEVENdGzuz/rC8sczVPjGZ4jPvBjW8LwuSTm+Wn2sDVGlDBpYyrFygrLaP/0ABKiie26qQzusjOIEBMGuXvjvEr3cD7jzz9f4fWb13j4+BHH0wl3xzt9sl8t8gQmzkKhp4/HE8VEh76XS3T89Kh2X+RuPHi/VpaVpZ+yGltin2FBWSE6yHXBSAo++RyK6JRdSQy6y/l89n7WiZAExYWempOFU2GgM3CW+pqdEgjz3q3Q6HXKYO0eH6jqJ5epba4PVNpzNnmuy4LlesX9/T2+/tdXeP7iOe6f3K94KOE3ZkFOJZzZst4mZTVerkbDUB4SV5KNHBSBngQbrp3gmKxfE4nc8mEiQ+Uak7oOd9nLYCjj0ujI0wK8dj868MFUrfMhch2FCLEksfDPTeX2uTPbjtnb0SaYy4QP4DbrO+APpaXcS3DA/hZcUDbM+X53KyLdKMNizhD4J+jvCbYDwULaYNCjkrFwW2dOZnO8wx5sXPEYfGFrbT27LT3zWumY9CmjySJTaZyC21uGTrbz3r1/h1d/vMbfH97jer3ieDzicDi2PVl1fbyXCpepxodT2PKyZbSI9KXA/ZYWBf7VeLbfKtfasjDC8nFXHPnoWmsHeFabnf8BoEvKAs7sl1nlWRnANsz6gUHpNGKsuoTMn4tlqnFvScC20t4rANvDdRmvGZk+HKO/GUjYVtrrtUza7wkvoKdVheyby7IseLw+4nA44Iv7e3z9/Gt8+eUz3N/frzrM2d5e1Gfmp2L9tX2eSeXkYqybR8nzttLZCTYpdjLtQv8jEUDM3onlrTLIwYVBte3mJ/Rl7ryyPZyb+YfA4XOyoIxGAImdgRHZODmH0i/EbGXmadUX93rqXIyxt3XHZy/yJX2b6FmaHafXNkyUTN7tSqvyxO0ZplFHr3zEYY9iOPpwX8bvVtvWCDjScKDNAiW8ua78vV6vePfuHd6+fYu/3v6Fx+u1LxXLz3cAMQRrl34/qwAZs1oAsN/G8jONFZzdwSb/MIuDjEUHZ2n5QL+nVXmK4ZAYlCRCBzEwuS694XnH34dgEI5OaFQT7Xe2VsMvu9WhcubzaQydc+LokXkqIMtLDii7RbWnQzFYG5iG1/PxQzH0vq+HItlv700lEFfUtsi11vb+3KUvcT99eo9nXz7DV199hadP7/VxYINy4JU+A0Ikhn67g6rk4G6JSz+lrZyF2sIaGxlXjECW77vlbQmvTy7OcEV3QW8ReErx9E4GDjI29E9+uUY+twzdDXqIWeKn8PisItHhp7Yz008acG7JslJ3q1L5jD5M2Dp/mbeK6XLj3jIJdO0+AXiUgcDkfD7j/fv3ePv2L/z94QMeHy8NYMvBvcQdYY7rHml4f+yY3fLPemyf1fZr+xJzqCt1irRZBJzR71l/DuVgq1AlBvLijov6/qh6iV97D23Ks2/jDDmLCgGU8/lSNUx2b2oQEIIyGCPpCj22WA2oGKJnexUR7GLGuWjG6zNWWb7l9+Yy0MqBqIWAfKEsWQ9QwZaUa2iflbnUiutyxfW64FAOOJ2O+OLLL/DF/VM8e/Yl7u/vLRIzdYXRGvTe6HdE5avFh8A76KXhz2t2yn6y1Da7/jnyTHnuq9zb/QR5avLlc/jMwOQfHKNdurqx3Zv1fwt4cvknwHajDNsuN/DctG3kwebI6LZ2t+UKQtANf4bAl8vlgr///hvv3r3Dhw8f8PDwoD7XMtiwJwpJKuM1pvP7s6Xws4r5N7V8GOowgC+A/jIByVot+4xPoEKnKJJEFn9Nv1EWrtl5BRR2KcsFtWsjC7rWaAwim+4K0E4js9rt4IYiKGLZszeQ7dWGCwpyWRbs91zD/ivQlpkr9ClSckOy4viWIV1f12tQfqD2GXRjL+vS9ndr3zc+HA84HU54cv8ET57c4dmXDXzv7u7sIdrIE6TPKWpgxja9m/upQK1R7Hjvf16Cg+Eg51ZpckdZc51PwHZPAuRo5J/IR35Os3oKygm6QWW7w3z4qLoPn1loLD4lEbSlWvkT5zvgh4jf17rGeEXWNRonW6/mhp2XZ/sy706wlcMzMp8kMxorVrWRSu3eUgRsvL1hc3CknivVxmXpj7b9+PEj/v7wAR8+fMDlcsH54UETnePx0PZgO1BaTwxIJastERgBBU0BV67De7J2+tjqNNA99GvMO4BpB1J/yEoAkR0L3D3pTcu4D6rQUa10fDgJiByoltHnOjnP50sH8D4baFKUzqQA7pi4nIfjDNVHeGS8AqpNV0Oma1krHJ8GmL21sJzssuFKwNnl9W8aWhytXe/8agXcvnG1iVQsw5Z6ut4vfK6LZtcy4Hd3J9zd3eHJkyc4ne7w9Ok9ntzd4XTqvzVzkV9ryAcjYcLiUyeq5zObn+OqR/CMQwlO0kV70WxXAo5aCWGDb5gKS7cr0boJ5flU/pJIau2b7TbxxlfUjUA0jlukWd3j/8fKuKfNbU11wpV4HNUmsnEsw/VBmmG9fJu2rJOFSkhsZ3yNZrsc7VXanTFfR7Nsz44aoybiKiAmppeHxWpvnCkpSQxmKo2ZlWVZcL1e8fDwgIfzBZfzGY+Pjzifz7g8PuJ6fdQDpodycE9o4o6NmaBlyC6j7L9l1T3Zwr9/NXoDT95/hatT9FV5cD5T//Zh4vaVLzy9YlYx3XG23FQ4zgX9aJO581PVtD8CGGpbVe+rLJeLPBtZm0Q6mfKZbBljLLVF4zIobvJVDI7IddRlu01R0yyXwNplpfw/aMlYMt8OvgrcC+0bw/hz++VQ7GAXaVwGQ/aO256vgbzsT7TTegccjs2YTscjTqc7+346qcGr6qu3+y0YtAlq362mU7G7Xv1FswLu40a7Y5lHe9GwU/aJnx4uhQujKZK9bQB4+7juaFmfM57qbsOD2cswJmtCRdKVASBBViUPUzULv8RZZczSy5MvmRyzHsxoayQo7s8q90qV5E6cR6netmMDX4YJGW059i6bjwY0cV4K/wqglENbVUPFcm33JbForxptwLostYGo/l3UvwGwLJMejyi66MdUJFGz+/K5+gBO+EAzWNujRWnAKYAjq33xFXeN1jJgd3gKfq9X6qnmGDAleakwvqJy0SP5U/dKvWSkshHLvWkwgbAqqnJfzmd7gv+0GY4+q/7LjARsqD2XyRbmw9khxKkHp98HP55SBsI7cvXzCNxyX3hqJgx6/KPSUd0A8NJBn5W3/i2S+YvM3na173G5fImnrTWdogZoGDLHPgLg+jKGK5VuFLo9s6bIi8WtFqA7OYun1+eKycSeyJwuL07kH/aHXUWaZWmf8mx/K5jxrZVRd0ON0o421ChCdf+SCxkcuP8ojLzC/YziZvLBzKDWfOs6NIYwwu5FVVcyl+rHfxeYMbOpDa9XA8T5JiyzwePO8X3Wta567JkwnS6VPz6ClH2YIke/2zcUdD4V+ymKAF9cxs1A8mCoU4Pfiaedq8pXSFa/nMv7pZzJ8lt2RPt8MpkPOrV7/Png6RtyW7/oL9st3H3ATpr1Cejqid9qfVOVCyrLV0ji6OtWMhR++p0HW5pTFz6NPCmZz3O+OsUJetxVBFwWl5kzYPc/8XCTA06ExzsKSOqpY/8e3EqGrBmuRHwEvHIPlQ5wwUAYTq+136VN9Gr+jYMMMV4bVKFho58PR7wzz3iLd+zRyGZNbDmz1Dk2w4zhmrNzx6/6rwXuARzqrKd68HHmFKhjWUPV/uNR94jCgBop31L8ScVkWXEPaGUiCf/VEh1kCtB1HJihxZFgCwfroP95f8KwT+RdbSyKl99bqVr0nzAmesPP3wGECWvFB2Tiq/YKLLjQm7nweS48arJEZ0tAO0ijIrDiDYCzoExkr31JWudC4eRK2qQlW/pfX2cnGScHAVKvCEDV24aKAAAM+klEQVSXNvekrmS89KQpB+y9bX5ohfhV1REFFxarcNAwKdnqGgUi7BtEWXUAZavnX1vbq1zOl+qWeJNGB1uXjoIQnYBSnKg80Nn428Rmg+XbvC+qABeWh8UgbAmZwdeDMDof/rmQ8ALQl5dDZittgQ9MYbhvul2GTF4H2dGZy2YjaVGyRFcr3mOHc1rJbdlvTJjVcaxTHhlo70Hwmnyal+le5wyhpjib3/BQUaf3Zpwymr18dpWdYBtbjuPLh1o2C/GMPrwmNLEvM/1Y3TEgQXJvzifR3Zo6ky7r0uQmozEIjEuEke8n8dxZ+MRADdd4b5L9jnhc6bMCabEHT8j1Dof+rUoCWB19a616ilj9SfEHlCLgCkD739EWfTLULJsF9a1QW7xsLJ1gPg1siwUcbP+D/RX6SHbm4kE5gwQLukJxmS0HJ6qnSj/9mRSDR2MUUVw/Zgx4kZy+RhASwTiz5WxSM8p+O/4Wl0HRX+PMFrZMzNluAHStQ/LpHm6QGSQjXxfjjfxFTw1sWU/8gd+7OYzAatnjUKeAPKu6icBCk5rhpE4d7H7a7poP2+mwZkFM0enEjFeglgB/rgpzdDTjHQUJgN2d2Ftq+tGGYqdJ5WFScqE7E1Nx8becy0u5jWUTU/fNCc76Kkye3RoPhHFlax8vMlYKeCvInJIYZC1s8/7B95MTu5RD0QsG1tSqy2SlJscIDHbwb+kBgaFlsjH7LQr4DJ5aX3kbWEtywvvBmTz6e1dVbvX05KdqrO+UVXSOC7VjMejWipsaDOZn2bMdnFGBvCGm3bKmJNrxUN8nkyhawapCMlxQxCVgsywhEhNRBHN7SCF7JAKmcs/vrRYFxTYpKvhJVPFNQ/zZZdqwg1M5vfiXRucycZLL0Jpk5uHocvoMmCMt0X2la8X0EkeMB9bVMjmEbojPaeKllbcsrAmV0Mxd0ei4hI0FX2k7LM9ngq2VqPdcvxrxEo0uWxEr29PLxdZ6gwze7nK67ZLbk+c/w9y4IpM3gFT3qQkMVXeMhWPkw5dRkAkXWl5ck2cmwtBSXGkJRHFtge94ecagh2sOK2LSEtFLID9ksoV/azrapwEpP+lKAsIOBSgkR38LjlAW4yM+o+Oi/USIQRHZK/BavXhQymTp7dN9XQmsFfoGIFVngeyb8f606ORwODQs0MBmEnhTwKKgX2GvWBVMUygMFiB4yfeKjaw7jRyDb57jQyDbpHZEFfFVY2Ndq2phgzcui5AFXIW3MFMgRQ0/zfFADL3PmanPUuXdudKu7tf2f1smHIAXCKebuZ9+z1eBn/s9fI5ujxVf4UeUqQg0i3wnvdkcGlmU+LVM77myBXIryzQZr8zxDmAb24tVNrznNtD21nQyIgSae4RYHUXYHMvRKHPcbP/iCCT2UrVOQE/5UHMqX0mqbPAZaJmpKyNQs0+0aVzjpZw/WGc5iMktcddNR8nD5ml8U9FTofOgsESidGQZHf0IZ/XJi7urXXpj1w2jwuzG70kKYNCzu1HA4y8yif/lS9oigw/dsyc12Q057NS+EnjSz3dsD9aCh7jULD1yJ6URAxVvwLoni4S+2uftII94Qqu7sRtcT+JbnLWyPi/yUAvNvFhgBgYewM6lIrx1Q2ZStSdOhWy2XZIowYxRs8NkoioMM1AtltUy6NjeLR2ckhPJfJ/AFwNIC6gy0FbI24ssG+79oNlrPKtOemnPdGnD4QCXTzWtpAgehJIJWrmCObXIJ/KK4P1ZJQRiOQ1/3D8RhD0wNjHLBrcAdyt7TKuX2Q25Pee51d+5/DxeQZa1Ut2fcWi2gqgJv8HpcbdmqKaX4woLfZuoxx/Fy8c6KzN9DnUHTxl8F4FXkJhC9Hm7ev3WCebkMWAepxlpVTNB2Y3tPkaklOsKunOZ3d5jKbSvaiAqAG17sJ2/e1GA8WI6oANyl4f3WQWIo1wu43Wy0Gdd8dTYwgJp+UdWAYK5qpYJuCs/e5yNvXq9Kp9imFou8aEW1JArxLhk911t4qFLGCE61B5xdJovXw3Xql/mFRoHmAR2S/UgXuleJZ4MvrYnrD3xmbGQKl1wG3JAq5dFUk1U7zjr6HY7lVOTSQG6LiNRTM0J3znQjpwAOF4eymcjn8jvgojkfuyU2KAYf7CLqKcZ2M5Avib8RJIYKcdukgnA5glNug66fSQ6lY+0A7dVLdKounnirmVGs1b4dT3DePg3ee0b5bn0mRfRh+JIcMz+pA/HMBMSIdg8RNNxvAf52fkpo0oX6E6NhELOsys6ffMN0rjHbJ8ZZVC2WlbkGTJehLksAgo1kxv6uOyW29TF4E4aX18XwW04QQxs0ssytTwpyvsyDPxEviJC8eU9gZf7EugVQ6SNRlPD/YEPcnjTuhX9rT9xfaW3wgPGy7zZdBq6KNGCEgnQ2Gchq8FzupN03Xk6ZykgV7xcVa4z8MpdyUa953QArfsgBKq8TN0mkbx/dxnqA+OLDWIW6/ZYKtRYPBi0f3SIVV0xGJFDVoUrujLf9+PrW+51DhpBwLRMgVGrB3Cd8au0gpEEI5Gf41DhIma+Hrw3sUmCvxFrXQRtNp5VSIUN90d3HDOXyH10TfNvuRxzmiShzh1a9XK7/eGgRw+2ftyz6zplva91baUrF4OcElxFsjL4i6FkKwvFj6uTQ+xPQGG18Pwlu87ULHdDfyOIDcGl0PTYRG22jBmj+G7bI41gOQdTL8tIp8FB4ecbG083p/pcGjLa/pQqzcoBzXDlEGMRH05yIPGFlRQ91AF9HzAygna3rM7DyDVqac9GztadwQ2ERirflihu6tTJHN2Esc4wDQNtxsOM2b7HJWRORfh3su05Fh6sqhMugGdNfioENBDskykCuO7p1gU2vjyZGbz9/rQ6JTVCVlj8bPJLXZ6qOjbCr/rlFr/HI02uHYyhCLfSSeo6woPgF0f4HpwC6xT/MuBin54YfY2sfMCnuEp1YiCQYMsggMk3L21c2GaocQDyA90E40fxS1K/3+ezDzmLAm824zwmSsjmjvnzwDxkiXqwsAC6p8TOGn7OeXuP85Gbin5hHDu22Wgv6fiE6cM9c/t6PEWFrlKQLPMrsJVvuv1URgoaUtMxZ77ViEocOiAMvw9ODMwMSF2wraBn/BVoKBBtS790DwbQAn5Zlip//d5xTWnHQ1GeT+SbXTNdFp0j5Bk7ILuKWk9K/oaeEmjM6tawMvMd7F/aiwgmaG0GqFU7A1IOR4Q6sMSpBoDZcPB+eamk1+V7thdsB5da4wzEmvkiTh44o3X7tg5khX5sm0Fb6vlIt+lsWRaXzbc5WUYd1XBIvJg7jHqgiqtApu2Qt4rkzmBDADXuscW2xudoayelX64x6mB3TuIsxnGJ0mXf+7jqPbqOeOo757IGNHvqz0p2AIq+KP+MZtC/swnf9rDcOdjDDGx7jZUYYqv/vJ9pDsrGl3XMibBQxdUr+5i0ORF0NhZxBWdYhjVxPLCt2F+cFbQWlcvsBdqUWpd5SZ4kwdK61kfjWbit4nuo4+WC/GoZpzzDmGQuYN0zwNr9ZkcG7A4POmhz266/2u8K9FPEg05cD+FkinOhJPViEhkDukgvo2uuM9qEhYZWTc4vmF8rlws/1IINosA9Hofl46Ymk9ehO5IiNl49jTkUmpxkDAV9abdregS19k+2pyvAnmW3OjAEhPL8ZPG+3FN5lZ/Wh+1FVXnAKPVMWJUSl7KNzl0GYZFzBjbbakI3uKBuQPqcapbKgW10NTOMHOlcYypvsAD3CJbgXGp0Tub0JYueJtzOgQJ6AtP5+nH/emaTww0BtDohnHh3PixUmEZ1QDEuDaTXWtwmiPThcgaEWfRVJ/23SqMd2c3eZeu/nOuzPcCkWg3ww8jhbL/aPVUg5wPFmdcIPrwC0/hlOpzFf0FoTVB5rllhwyxGSLYb7Uc1GwKNWRmDNC/HqO4yyqu67l+cqP68B4PTmHkWByYKIjoW8dCUgK0HVGORZ8f6WX2aD/KdTVdeoZsnAxkeab+z+cv0DuC9prQqAbu7zvPjHE4jKwFIEnHWVXUOcxb5cvAoMF01CRVw6bW4rgx7PepYq9dWNVoDQT9ACrgdzMXJc8bbaKGAXsNbf+JfFYPAvpYKD/7hvlNkVV25DJ0ncVbECNlrhCAiTuyRB48FA8gM3by8rZV1On8tKxF0rX03sbuRrGXWDgTcjdCf5KNPNAI9dWcWgNjYcYUUdTy/cNmJEL5QWEGCRXtZ00/QXwa6Bab/4YaJ0xyvB0EvvAjsbVqDwlr6ma1xfo0Z9NjfrJ/tahJcRPkG+6zp1YH/LLMfrs84leQTSzA+UtDszes/nnPxjAQASZ/9q/HJT/Hakrxc9wAqGSz3cpapyu9oFU+oA2Zmtq8rvlT0aXvMgjDePuyshNh20AevrrjpbHOzaiCB6RKxf/Qi1aUpXriNSnjXwRYA/h+zeWpG+oOanAAAAABJRU5ErkJggg==";
  function photoSrc(p){return validPhoto(p&&p.profilePhoto)?p.profilePhoto:DEFAULT_PROFILE_IMAGE;}
  function render(){
    const b=document.getElementById("profilePhotoBtn"),p=active(); if(!b)return;
    b.innerHTML='<img alt="Money Flow profile" src="'+photoSrc(p)+'">';
  }
  window.pfOpenProfilePhotoMenu=function(){
    const m=document.getElementById("profilePhotoModal");
    const pv=document.getElementById("profilePhotoPreview");
    const p=active(),src=photoSrc(p);
    if(pv)pv.innerHTML='<img alt="Money Flow profile preview" src="'+src+'">';
    if(m){m.classList.add("open");m.setAttribute("aria-hidden","false");}
  };
  window.pfCloseProfilePhotoMenu=function(){
    const m=document.getElementById("profilePhotoModal");
    if(m){m.classList.remove("open");m.setAttribute("aria-hidden","true");}
  };
  window.pfEditProfilePhoto=function(){
    const i=document.getElementById("profilePhotoInput");
    if(i){i.value="";i.click();}
  };
  function storeImage(file){
    if(!file||!/^image\//i.test(file.type)){alert("Please select an image from the gallery.");return;}
    const reader=new FileReader();
    reader.onload=function(){
      const img=new Image();
      img.onload=function(){
        const max=320,scale=Math.min(1,max/Math.max(img.width,img.height));
        const c=document.createElement("canvas");c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));
        const ctx=c.getContext("2d");ctx.drawImage(img,0,0,c.width,c.height);
        const data=c.toDataURL("image/jpeg",0.82);
        const a=profiles(),p=active();if(!p)return;
        const q=a.find(x=>x.id===p.id);if(!q)return;q.profilePhoto=data;save(a);render();
      };
      img.src=String(reader.result||"");
    };
    reader.readAsDataURL(file);
  }
  const input=document.getElementById("profilePhotoInput");
  if(input)input.addEventListener("change",function(){if(this.files&&this.files[0]){storeImage(this.files[0]);pfCloseProfilePhotoMenu();}});
  const originalSwitch=window.v10SwitchProfile;
  if(typeof originalSwitch==="function")window.v10SwitchProfile=function(id){originalSwitch(id);setTimeout(render,0)};
  render();
})();



(function(){
  const pfFeatureState={analyticsType:'EXPENSE',catType:'EXPENSE',catPeriod:'all'};
  function pfOpenFeature(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  window.pfCloseFeature=function(id){const m=document.getElementById(id);if(m)m.classList.remove('open');if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow='';};
  window.pfOpenAnalytics=function(){pfOpenFeature('pfAnalyticsModal');pfRenderAnalytics();};
  function pfAnalyticsData(){const q=pfTxFiltered();return q?q.data:[];}
  window.pfAnalyticsSetType=function(type){pfFeatureState.analyticsType=type;document.getElementById('pfAnalyticsExpense').classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome').classList.toggle('active',type==='CREDIT');pfRenderAnalytics();};
  function pfRenderAnalytics(){const data=pfAnalyticsData().filter(t=>t.type===pfFeatureState.analyticsType),by={};data.forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]);const total=entries.reduce((a,[,v])=>a+v,0);const donut=document.getElementById('pfDonut');const legend=document.getElementById('pfAnalyticsLegend');document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=pfFeatureState.analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;const stops=[];entries.forEach(([,v],i)=>{const end=start+(v/total)*100;stops.push(`${palette[i%palette.length]} ${start}% ${end}%`);start=end});donut.style.background=`conic-gradient(${stops.join(',')})`;legend.innerHTML=entries.map(([c,v],i)=>`<div class="pf-legend-row"><i class="pf-legend-dot" style="background:${palette[i%palette.length]}"></i><b>${escapeHtml(c)}</b><span>${money(v)} · ${((v/total)*100).toFixed(1)}%</span></div>`).join('');}
  window.pfOpenSearch=function(){pfOpenFeature('pfSearchModal');const input=document.getElementById('pfSearchInput');if(input){input.value='';setTimeout(()=>input.focus(),80);}pfRenderSearch('');};
  function pfRenderSearch(q){const list=document.getElementById('pfSearchResults');if(!list)return;const query=String(q||'').trim().toLowerCase();let data=txs.slice().sort(compareTransactionsLatestFirst);if(query)data=data.filter(t=>[t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other].some(v=>String(v??'').toLowerCase().includes(query)));if(!data.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}list.innerHTML=data.slice(0,100).map(t=>`<div class="pf-search-result"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(t.date)} • ${escapeHtml(t.mode||'')}${t.description?' • '+escapeHtml(t.description):''}</small></div><strong style="color:${t.type==='CREDIT'?'#2fa65b':'#e3483d'}">${t.type==='CREDIT'?'+':'-'}${money(t.amount)}</strong></div>`).join('');}
  window.pfOpenCategory=function(){pfOpenFeature('pfCategoryModal');const b=pfTxMonthBounds(pfTxState.month);document.getElementById('pfCatFrom').value=b.from;document.getElementById('pfCatTo').value=b.to;pfRenderCategory();};
  window.pfCategorySetType=function(type){pfFeatureState.catType=type;document.getElementById('pfCatIncome').classList.toggle('active',type==='CREDIT');document.getElementById('pfCatExpense').classList.toggle('active',type==='EXPENSE');pfRenderCategory();};
  window.pfCategorySetPeriod=function(period,btn){pfFeatureState.catPeriod=period;document.querySelectorAll('[data-cat-period]').forEach(b=>b.classList.toggle('active',b===btn));document.getElementById('pfCatCustom').style.display=period==='custom'?'grid':'none';pfRenderCategory();};
  function pfCategoryRange(){const now=new Date(),b=pfTxMonthBounds(pfTxState.month);if(pfFeatureState.catPeriod==='month')return b;if(pfFeatureState.catPeriod==='year'){const y=now.getFullYear();return {from:`${y}-01-01`,to:`${y}-12-31`};}if(pfFeatureState.catPeriod==='custom'){return {from:document.getElementById('pfCatFrom').value||b.from,to:document.getElementById('pfCatTo').value||b.to};}return {from:'0000-01-01',to:'9999-12-31'};}
  function pfRenderCategory(){const r=pfCategoryRange(),by={};txs.filter(t=>t.type===pfFeatureState.catType&&t.date>=r.from&&t.date<=r.to).forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,[,v])=>a+v,0),list=document.getElementById('pfCategoryList');document.getElementById('pfCategoryTotal').textContent=money(total);if(!entries.length){list.innerHTML='<div class="pf-empty">No transactions in this category view.</div>';return;}list.innerHTML=entries.map(([c,v])=>`<div class="pf-category-row"><div class="pf-category-avatar">${escapeHtml((c||'?').charAt(0).toUpperCase())}</div><div class="pf-category-name">${escapeHtml(c)}</div><div class="pf-category-amount">${money(v)}</div></div>`).join('');}
  document.addEventListener('input',e=>{if(e.target&&e.target.id==='pfSearchInput')pfRenderSearch(e.target.value);if(e.target&&(e.target.id==='pfCatFrom'||e.target.id==='pfCatTo'))pfRenderCategory();});
  document.addEventListener('click',e=>{document.querySelectorAll('.pf-feature-modal.open').forEach(m=>{if(e.target===m)pfCloseFeature(m.id);});});

  window.pfOpenExport=function(){
    closeMenu();
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.add('open'); m.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden';
  };
  window.pfCloseExport=function(){
    const m=document.getElementById('pfExportModal');
    if(!m)return;
    m.classList.remove('open'); m.setAttribute('aria-hidden','true'); document.body.style.overflow='';
  };
  document.addEventListener('click',function(e){const m=document.getElementById('pfExportModal');if(m&&e.target===m)pfCloseExport();});
})();



/* Money Flow — first-launch onboarding */
(function(){
  const KEY="money_flow_onboarding_complete_v1";
  const ob=document.getElementById("mfOnboarding"), body=document.getElementById("mfObBody"), actions=document.getElementById("mfObActions"), step=document.getElementById("mfObStep"), progress=document.getElementById("mfObProgress");
  if(!ob||!body||!actions)return;
  if(localStorage.getItem(KEY)==="1"){ob.classList.add("mf-hidden");return;}
  const logoSrc="./data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdsAAAHbCAYAAACDejA0AAEAAElEQVR4nMz9d8Atx1EnDP+qZ8558o3SVQ6WZCs7ybZkSc44gzHGZLPsLuy7vMuy8BGWDAYWWGCBXb4N7MIuYMDggLMk2wqWLVvRilbOOV7d/IRzzkzX90en6p7uOeeRzft+Y+s+c2Y6VHdX16+qurqHJpMxAwBAAAD2d/HF4p6YMykAFs+JyJfKFEpk9y8D5GviqFJZPFFCjXvpy+eINndPLO4T+t0zk97SYstjZlF2WgZ3CmLRbiJK6mLkuoqIojzMHNc/4yV6r/MsU2lCOGef5+onZMbv/+Erbde3ngLyXRH3AXW6ztPgxlBS1yFUcFBpcFhyTP/74jjm3s14fav6Np2rm+Hl//++qDx0L7y3ouHKz7u0LuSFWfKYCOCEZmY2vzs8YmQUWXqE+AuFpeVI+VgADIobF7chQ3uSOZOqfEW4kyuH43FK8Yt9exI5R+aOOGCjrIQidIhSIEdRLarsDNCmryCtpiW0aChGijFjJ4c6DLUkHnfB0BUdVQ2yDxkEBRBDawd+pmx2JNmHTqw6xYC1qFown0/FnHR4HlAd874QwZRTJnK8b5pamMxs25PrN2Y7cV2ZoaaYzdyExaYmSlkAxJPaqVTfDG92hEjnpewDjtKzUMYkff4i8ZuFAuVLs/8mfRwJwyJpqXYX/86NdfTMDYxUPnvG6JuBx1hpfMGFRKDRaWFBSQTKhsI3R4NXs1P46q+NGUwZeWrLdsAmJ2/M8wVjIau8x/3NVrbJPiL5MlLwCcryr+Rzf5+kd/3h+MmVwQh85sWrfdMhMO0SfJPj5oSU7BwBtFMvQXOXjrgPo2p6iM4aQuPJJMGifElRokLH9VpVnNhEHQ09X5DUQvxjgQC+8RZs/VwUxZIHS07Gg8AWZCOLNhKeYXLnlMrYuilrcCmgRiBLZNqZWLxR+URZyzrqnCmMlZY97XJ9loqMabwwa/lB8OSBbOZyclfC7SUZ3afkzF7/DJ3/Aq6SkvStuHoB91vR/y/gylp3KW8knqg07zdL8yw0bKacXN4UVHPpO4q5lRF+vmxy7qTC3wOpt2jzApiIvDIZW7QxsJFE2k55oUySMpLFb6lkpEpC3j3YfU4IKnnqnYp+e8vA/QrpPA1SE6Ls9E5pT72scdkdsJXWw7cIbAVjdFJHiqLQKwpgG4pMOykBr4ieUE/EADlmyDGJA2Fn5XGhTPGny7yCbjGG3pdAkv5y/pKG2O++6wGCnOYty4kL7Um5yStTbz+wzAZm0wFkdlAsleWVo1I9rpakuj55vVlQfSFLDiZjECcz1TmFP9yVKytSjDvphdI4ZUi6YJsWFo/H5hWUF6oodZcX8nWXlyFMnq4B0EcaR/Io8YhlLWlEcs3JHPIA2aUndgHD800QP44GkUDSLJ6UILdjFUkaZgBbdn3QeZ6pFLCuYPeCC3wZlAkQd56LBzadYGISL7pJTarxeMIS9/rEnUkQCE2ZqzjBcp3l0gsNw71gMWBFf7xL7gfdZhYaoMkTg2hange5tFxpUTLHbcjMssDM3SRSW3WAqhQh1WJf6PVC18ooJTS5poFtdjxeYL3fivW9Way1qWWYgqaWU0xnlaikxH6BOyttpUKyvMnu/2V6O7SKYnLpS1dGmY5yfov5M0z3MEe7JH0LlcPCNUu95THL931fv/e1KY37kPIu/R3XR7Hyn6nbg3KWLBLjEMGDa2Yo078j8V7yrqgv9YR2a81eXZklATRXkKQlFBBZ4K4ER583rKaDraySxuMxzzKpioJ1FrDNuD8TfSjkScG2VIekwfakB88kjc6BvZioqVY86zSVyplnMiIoZUpUSol1jlB2ynBxY/KvNpXmm726WNGTNkPQN0nbP4Ubs1hmyb+8ictbi8J6yNY1y/VPML6dQK4+LemflK86sz5cnYmdCrLSe0xJly9/JndxKa+VZ/0g1HNlBczm+LBDf2rVOgD1nrcYPLTWUTkmZoUFaAtjADEoBlDN05pbUguGhrGs+6A0uLg3CbbOaOq0mXI2XdJnTjmN0CD+5fqjCLZdiiWdNTmkSJL2Bu34SmM1JnQPSyvca2uyIyLElyQKeljkBZAdAMcOjBhoi7QLMAcla6ROC0wI67qnTecqZVwxEahKzMm4ebzA6ZE7/29eHcH8T0jn/1trg9/qq3ctPUr4zQP7t6SczYzpt4hmzsz72TMXf8TPgyb7rblizCiTsIn+zEawv4CrI1tyJqVIK36AYAwBSRMzg7VGK2JYTPnx2rAMpArryaG+3O4KUt1YFEKyU0P0YW90cQ6EBT5kDbie9GlFAVxlo2JKvDHos8vg4nhcmcOTusxR8ZXlp5wFW8jrQSZZd4zAFAWQlBOeOabYupFLIBsxitXcHIAKArz169I7DUwzg1mDKICqssBKymqABbdIFBAFE0JutLq8u6Z45YaoMMHDmtz0MZX90u8HLF1d1V9MpehNOq+yLkCh3MhnxHliyi5QsvpMGQTJaf7fCuEsZV4fGPiKp5dTTtNNVAoA7KSf0tQ8H3sTqUN7ie+zZUfrcCKUxGXr8LNj+n8abS8FhXLC3KPMwxnIjGSDEM9xom4/F0lL5GaOhCDnEiBOjAIiApRCZctxYKu1Nr+12H7RNfUjOghBfrqdH6n3xxfDCT+UGxv+JgYMpeXOUk6a3ilq7H8goL94VSq297mVdZPJJFIxulYjOu+KwSN2ssfiPpmgGbCNLElYCzNHA8XvZJms3cS0tPRp5JkyZICV1NqUUgFkhTY4i8bfXR+R8JSdxbHmS918adnSlZUFWhYj0bMek2X2pOK0Thfu321LFIaTx4AMTbLNPk1B+512TQsiSgVV8coyonhdsM5nqbdTTyrDBI9R/CLDdxmdPMejifbjhKJ/l1G65Dj00u9vxfxOAbrkMZtSbwrE1DcuqRyl6ZsaJV29IOxshpkUDVeeoFvQnJO1vs3pmE+5chaz37CUFESOplkrYIZmsz3SgC97L2JuHnkbT85tCVaCz+SaMTw0pP3fZUz5tohZBdkf/eymgCTJ8FoeH2X5xbMnfBKS+2ynX3KeUnQD0XmpVpwQ19dYDk+yfFBYT2Vrq3uTnWyQFKVDYsE6sZQhBLPT8qqq8uAq11xzV14z60qP7vEb3QlLEVcKxgWQCrG0zs7vGdy0HboFWQQyIfASsAXNjgZntXtCwzRHSR8sihI3TDmEFpNy2uV4Ii/cKSoml8aPqR/6zHYNZIR4n/qbtMVZAFOSFR6mHZEIBCuw43wlK8B3eufqeor625zjwZkUm7Q/XPNKUrXnkltjfOHi3SxWUJHNMspl2TKTSkzi4vSyKs1BVkwFueTmURnSu3PT00XdPcK++T1zKXLlEqBIwYjDKoAua7/2a9LFPMQs509J8YLtGzfYOpRDfX075fJeu9DWbhhs4UqUHYlmZYlWJCTcma0/otdz/vKs1u4YKUzUbgSXKYUE1V3hzl0tTmSIWFRqGCV3Govm5Pz7jgHcnLZtIUWoVGX+VpV/5zWtpC5GHsQ6IOFnFMfu0BJglEYyp6T1FPOCroKO1CGFy0Av3fPh8JCkmsxaj8xbUKmSfu0Ba1c2hOacLa48bdJJVbRUZeEU5/Lcl0zenhLQR1WEOyzTJtaL6yrR9Jkt+b7LLwVNS4Pi+JSs9Y6bMVW4Cv3X7T37b2cOZmgpvIqBJgZqzzc9k2+q1RvRFgrKutcTGqREy3nB0nI6sSaiTG/JFyz/vshqZ6dobQC3bdtAYARUscfQ0eHtF1GWLDdYvGFOJWiQpUu6iVk+830Fjzmm7aJyqeBkLXZE4x5tUSp5h0WaevMSuzxRy5qXrTj3smh1BabzSeygRWuhYhCjaFCHqcmk44RQVVWoqiqsWyCALJEN1C5t3sqSnaRNK5x2ueypWpWvDLJXX7AW6Cr1E8AqIL054rqKdfd0XcdKYtjN5AUae32HuXrkjE6T9ffTC+1FiH6YbVrJXugH/9xTyr2cgoezWnfpFY616y28t4xorkYgMgWUcmWVtahMQZsZjbQeSQ7HDwtlOPr65qSRU6mbN54wXmGlkCtOTdn7UppOmYzNa+0Cn5wHsKoqD7qsOSh7ArxilaEzIc0tO94AFJQ3VsIs4eDB7MzvALTRxZuZj+nFfgxTBTZONf0y+2xjNSrcRqVJ5PZmA8gyjPltWu3bziFHp8SE4ojYnEblNBU7SYOw4Oz8SjW64GpmEClUlfIWbBAAjv+S0qisQXddarEQ6TTQd50Tr5JO0XQSE7+r7EZl+N+UUN8DdIY3u9pbek8JP0Qbv52WL+spaNjR1YOnnXKIsushfczthIl0A8seT/P3utstM6eBHTlXar9lnrkiV2FCT3Z9HXleoOR+xupnDdLrteo9EsXhPzEjWKLiThdDnfBY1AYHbiJN7CqLk8ZCy1WV0J1UlnaDKLBrVTryOeKDaF0bOVoDX6R5XeFpLERUIWXmU/I+e0Vs28+fJXd0b/mZS2uNtmnhA1IRWMDcB/xw3SYVQOdByPWdKyxmeZFOHIqf7pYJZU1vVlAsDb5JHqPowItAU+7yaMjY3JptUkpKXveV62D/dxYVKiNYbURcqTkxSiXCgeHXLRQR6ro2AU9ygNh0SlgfjQd5Vo3RkVO8BNDmGD6azOBOPwZ+7XHBRVK7hxbLADma++et+DeSeZYyK7x612QzpJTeka9ICM5iH4vVLVlm35gUgmF8jdkhTh+S9VRxb11RM0uW5TSLk+w/kfIreFSyfqFts76XVabY1+lf4Y5z80m69OKK43LjOWbH0AtNJ5E5FrLpElG227qM1Wltb/OlAIsBIeVxudYa+yoy8iMzPyIXdaE9riwP2um4F5WGDNBm0s7iGSPk9siGGFsiQqUUqmEFzcbSbdtWnD0f+tTBQS6gKm23jKdJKYpuS9PK8meUOxND1K3b/CvbLV3evbotuzoMbSYaOcF67tzFJUbuJLmOUwx+kBpcSatyJcbv5absYDlk3nfujQbCDO/mcJZspxCgqwhk1J9p7rfZxJYrXrCsXHsRVUf9T/6fDo05i2pqBGkfCHF3NJz2mU8uJ1JMm/9JOTUhpO0IJer2B0SbzFqQoxLRfez1kAIx5I2u1JtDaTlANMMkjSz6XtDW1b5dMQljUfxeTmYA0WH2MgBlFuu5My4Z5YrKvdK5KCkjPQCgh5BOQRRzty8mV2JKfrbs3PzwSQTYZjx3MRRztp9mvnJ5O7JG3KbrwFG26cqSLwOyjOCa7oCsnD+S+Xp4IxusKGiM2lKgs2kav77rQLOzliut20TBkTEhRAqAWAv2dCdKaGENNiEuvvcdl1izSXs7ukpBxkoJlrVs+3iss740oysqZIkBNbb0e5jLqLtFkVCKsBzUFao608zNqbjFOiMh/wJKEWpL9Iw75WVK9rIhMGjkCnKaNoczmOMGdIv1zDuV6qAs5KyquJqerRccp+uK/64iF9xxQbu0WosBOT/nHJ2EmOtIlIKuu8kXLCZvwpfSFZZXwOJWZ7sm2yVdSvNXVzHtKIMEpApMzFgzgqVLleWjGfImbuSSg6vjbe5nq1R4vKCL018zTOLiskMpbzpUnq17TlJKxy6l2c9TCuU5d2eHrAC02foiBS6utU8F6wRFCrpTZX8wGICZvaVbMpJk2X7HhS0zmo6u3XGnxHN2xmu6bhVSdGddklMWlkwvmoizkTtwJbVGj9KRdINb83AMIKv29RIh1axEJfCaWCTbul/JCe0JAxlZMQiaUlVVqHMgO8OVanJTLbq+2UniLws3p+iOKEmUd1qoksgtJmefJhrRnlaYWGOegTuNSa5Iiw7TM2dRlNxQMcf3S7tIphXA0JciBLKv11WXtndKzdOmcBS1uBkQSKeUozsphwQabU6cILKKRSXhNrkD3NTuKoKZlLabU1pFO1zKpF2xYA/pS+OTlpPWWYw9CIkKJZZANC9eHcVh5YA6ABl5moSiUvIm5NMgUuh6gV6SXGpfSmMis1PPTUcZFvO0P4SyfElLNw5wDdXneKnDw5Zcr5QnV8RbJV6KYgfiglmkiVNwJ32p++Xz2oNUjhCRI98UNv/lggxsmtAZyPIs2b2sfsuOvbTWncH0lHJXG3I/HciSd6j30Jcfo5muXmvNFw5RgQCiqDssEVbRoOR5L3kR1ibngk65UsGUVSgcMXkJi8iK9q/7hJMsTnopKDoPW1Yv8+WeR+uCSRvya5LlaOFvCmgx3SNQ6Mb8GyrQOSvKRrwtOtd3uRPe5YJzQJurnjMnfMXBLjGASvo4zhRTIt2ACZXevZiMcSfQRtAy7SIrYGXXefmeLSLM6XgFheP7RBGJW+J+dvm3qNv2KnJWjhIlfcZ55ZJiKzSu2s5LaVSQUApmvFJjM1i6GpNJE39L3NGczl0pTkVf6VniDqwm6457CZ6VUr5U8uTTbRY+/AlSeV4STCzX8ZK1Ux8tKtI7Bu2uO4p3ZDc1dzRAOeEE8xIAzdHeKDeRlFIh+KlHwzVkkqUtDjYwVWSk/hSQiQuPAXXqxEgqy+ssYk8cEEXnZqMlMxM3t948i3WQzJKetnSv0h6/TXFoKnAFuHKUTNZl/xU6Vp+4deV2+ETW0WcRifQhc38jqSfNLHEBqbLthbrg3+nrsU4wy5KTetzvHHBxWrJV+XIWrqc5zNtIDZ2lv9A/jlOvF8DLabu766N99QlZEfUJfNeXaCq2dwYJH3gkRdBCxlhgibql63Z6z5fXxpPlP9t+97xtNSaTSaDdAbp1d5LjZa/8uwJiFPeKnbSELen5tWUnU4V8iTyojlZhTqQiO6NIUkKXu7yftaS1Zi/r+vXCzPer4AQJDkl203Ec8nD8VpAv9BH4jnblOa3GBT8ppaI1yuKEiLSkzPseoHX0M+Kow5C83JPdNzNM+B6h0O3XMuDmgDZVBIKrd/NCrSMckrXDUHGhgB53cCdr2pYOMemY5K+I5gzQznrJcnpHNHFpl/VnMQJJwqCoxu2KeJI6o1Ggx5XdD7SG9KBgRoILqQUuy/LSsdOsbIWF64XwY74g6syL6ApCxsu2lDck6MptJsUqM40riaQ0ZZquqLxG9Ym8qdDvXePOKO1IgvVcGUBHdpTc2+kOD+NkNBzj+KaqFJQaomlatE0Dsz4rFEXXOdxteRpUJZc+Ar2U9szsF3duEhaP8S56nsqU9GzkqOhIO0l7Pa0MUXviCZm5pBsIsetH7s/yVQofq5vgLso4OrPYvU01EAgtM3V75Qjk7vtZQuM71pGkS3RVqXpOB88qF0VrMy0r8Tr00TjTPss+ayCnweXcufZ59DQR8inwxSyWpzMXzMU96dPrBU4/T1PJU9CXp48OmygiKIqbAPy7eJwLyl2C2R03reBJ+wvwQxqrvKnQdKV2avbD74SrJKCb1tPZfYxQShf4c4ph//7w7lXaXTCLbhjP5wC60sUayYuonxOanVwrEOpk8VSuzsxHGcQZGS2WEEdpGnTYJYA7c3bqMpTMP9uUhG61X8/1S4GAN2y8V1Ip3xC5lut5OFEIYxUiXHIepQo2h0SR/PLYL/s70Sl9PnEpzHyRJzsmqMtMhY+0xPnkviuneLhOimaW/0f8YVRVhcFgkACtTcQutDymmOz/Oi6NEo3gKO30ddrcFbQqRtw0Qyv7514gJsDaEerFquS2rR6KqMuQM105YE1/zwJ0JDXN5JV9X05hq+p7lwO9tF9FGZsd0Vwd01y/vVs4+ipKO8IUhrAdopA7Vx2RHx9ynMzhF8O1I+a/0hIAZ0YpNFPM2VIDXfaCHp/NXpoLlvfSvZjFXp9F8Zl2ZdpVXi7JqBAcv8qyLQzvzERXkSd7pUHPmw56xO9Td20vbdOTACbmZjgcoKqqyOjqBoxpOwcg5gKEARepBVPrnYVPot7MZegwb/yAxuMx9+1B8hVk0yTimuW4CM3brcNK926BxnSvLEQnAkajGdi12TzNsnWlZgmgL105PpXgnfr2O9ltHT7yJ6N10iYnt8tXEOxxCH5+gqZrbhH1U1zWUrCl2vbMfUrx3BWHsKWMMJWmLG2iKvcuLbNjKWTa0XfN0tacMi8145SmbjtNq7JbdwQNcmtEl6ZARWfcvRwN/ByrlaLaZP1NoHSHhdyPOGgu0JyNLBXWuy+VHZk9k6RnTdKtm3kF1o1xYR1PNDCeEslAFk4RjpqSxaa0qr5pwrZizxpdkPPtijJh6nzpMZcCnUmSTok9HoHQDyyT+/HsFpWULhI1bYOmaUIZBbCP7oW+X/LylYYlt9YaA2xcf4f9svwU8ky1bMsWhtRcKQbaNL+cYBF4xRpoGtQUPKrmeVVVHmidBhPXRYHgnASGYa1U+802LW04WVtAWEj9Sjt1GLu0jcL/EJZH9KpEKyX/RW1g20ddurqFYCZQ80XHOQONhUkoq8r1QBSJ7qR3pi/6KMy1qrdFBe9BHNDTbYsDjGnafAlouwmF8hbVl5FOM1oH0xJ3QaYweXuLJnHvngeaw9wQKkapjs5Yu9+BYbKyZYp1ysmDoCwW6JjyzoiF7qyPy+Vu/25q3AI4+ew5izW3FjvDHJbUpZRyYYzySkl3bkpl3D2TikcXtDNdI+RZXdfee9krVojCewHKueXI3qtnSSFVblIEmGX60GQyiarI6wLySU4TiSs0CgI5BBXapU2aCGUCwsfbBZBJAK7r2u+bzUYXZygu9XO851MyrUyUzxvSxh0/a5ndgKpNzkSI9hP88Yippj7LmlVfe/uU8jRdrBnnvSFeG48KjPupRL99EOiaZQI5rVZas9LCEe9614Qz4NtxU05TMkIBnrbcmERGhU9aUnXz9UWBJV6a9dPWAaeUphnnBWdf57kvv45W5FTzVoxpH819dHX2wdqXsTBNvR6Ch0oVOPIhxoZFSaJp8is7jn9sw2LASi2pjAIm6YxfCCXOF1neJlPyOk4rP5qPwuOVFJ7UJsfA/NvrJeJ4X66pgvzflGuIusuFfd5b/y61bJ3sEG3tfrbVyfz8ZdaBTZ5NrNnGBLjKo2Z67co0Pyw4C26074PbyzFn+M9pbu5bicPh0OydjSsOJPUpB73CIeOmC+TPdOUEZh9tZWfdJuvzikspYSrISgX11JPxHuSuABCxRhtpzZE2zkgJSL/206mWu8FQvVfiViOEienpthZqnwWLJL2ckClo+7yYzj65oaPiD/HMy+4MrKXWIc9CSaA3skRElZxLXCCv+6CreOb2z6d3ud/pvtpZ+rgTRFfodMcfKc3U+TdTSdJx0qslgdf/zvB2n0tcljvzlSuz5+p4HV0xpfKYkwTIA+20el3dglc7Q0RmX648pIinyDe5PbM0x7P9kyzFdddsJVbNOiKWlslkLJdG+y/y/4RHUwY07RTXcL9VwbqLWbO3bsGAZg2lFAbDgfnOrOgwR3C66bkDXgX1N7cXMev6kcWLTursbeXCcYhJ+3PaFaPch0V9UCyCcDLJi4XIbQq5tQchdDpIUFgP8ngv3ncA1ldZ1qhlmrDWjSy/pXX3TZhZdabSIQj9Sw3TheO0q8OeThkIEg59W8ki/k38U4REsStZNclY59bXMkZWtx0F3vZzQ5Q1XUV1pQbxJj0SzkvSqVFYhix4siu8Xa0Uj0EEJmnaLsn5PbRlL0dJwcryca8FmkkjPTily4Jadg048Sxm68gVKWmD5GnBt5xP7z1ChJnb37YtJpMGqfz3uGKst0iRlnujw9quBUuxKB9EjlDmevpDklw2nEOiGS1bq7qlYcapVicYU0urKONyYNbw1grHqweaNaqqwtzcHBRlSKSMIMw9C8pStjkmSWGNJS3egVFpHXGarKUuP+UmGSX31HluC/JSBeV2WrpNH1N4UEhTbEvGJRXRP+N6Uan+UB4LpTGiKF+UJz4d94zgmaIUphO3T2hC1ruZtsvsyAybd8OhV9EI6csvcksZs6wlStZyv3MA4aw36mu/H0eZuVBgeiXtTxXSXBZO/paieJ2Rls61TgXU7Q9ZQYjong0oikCby5PztuTonFJH533OWzND3067QjtgFJxMIX5I3Y1oUI8ICwooh2hlQG4XTZRNEnKdBD9EeShSLCPeEW7xnpYKqnNMkmnHeDzx3y0RTettdRfRY2GsRYNK+0Nzi/4Mc0xjPagxqAcdzWSWK5eegeg0oOCjR7fvRMPcJ4vjoaBs1j56XPpZhHKkKZaEfWEtpxM1Kt51Cu+jIaMxm7L6aU7fb2Y/b6p4FNdRSvmF+UXhYULo5sTIzPsIXRqXL32WtSjLiwheFnU61GrnoPJY5sba5gvZUpjpKlHTWjuNF/x94i2Iy7D8kXyZyc82MU1LdYSHZeUoKlPIh27LBUgIL1sIHErn1xRlLLk6PJ6W0ONC8MOaAUYu1OfLLNCUenKi9KmiklEGUj7J9UZ2jTxtgKPBW6UJ3RCMYCtlZozHY0s7RcPTiVIOTYqr9vji6BOzQ/BT3A/2H4bYQ15etZVrvOKk/pKuaFtY9KeI5wIcY8aPOzmnxTBMBw4GAwwGg1B6h4kyg+DeFIC5b1qUD6rwO7dE+YA7jk70TFJayNlDaoGW8tWHlwRxmo0fjkybCpO5syUjJYo7t7nXUXnZsnqu4hh511BplODblRP0fdukNhOpmOUtWW8PqGQK8zQW+zM3QSCEVw4RBZPkg11mgi3/NBWk5j/jsdJW6XYil8AgUlC2PxRIyIwSCBYAaQqFcu5JxSq3JSbq45xnJnkiRLcgYnNKmq9rirUayZApvnpK8sgyXuiVV4BmnLeJEpyXh0E57ItPiZaOXGEeOVOF2fxRpDAcDjEeT0xsDxX4SeARkYrAmgpt7T06NNqvuTm+sJZtV3PrIoWjsivIpYaU7pM1r9gfYuEEYPDVh3JkxHGnjWLtJ9JURQHTIto66Sho1VLr6px649JlcCi9kxGOUd0JMziNy9OfR618Y0qaeSF5qjTki8xovYzoIHJXd8QlmwCsPrUpLSu/hy7ZqlDwGkjBVNLsS2VG5WY8JH7pI1NmlA7d9iaVFPMHmin5k/BqJquMRyhHr+b1cBIdF20DEdOBmdGyhmbdKUOBoEhBqdzGNyQ0C+7NPU/aJy1JPw5ybU00QgKwTB83ctpF4t9uM2RRnm+dlpQorp05krMeBdj61AWvToevge58cXw9A6CWFN1O/2bK6iBGjyVtXrs525WnrhAJzqnYdflcOVozJpMJtG798o+kP6xykXgm5zA5gzrfD5T4MErzrmAMSHpqkpNKMLlnqMxaX0cIyYocccxQ5AA40JkdfGvR1nUdGFMwYrcDkoeFtRlZfu4ybct0UkdAFRgjypITHI48uw+Mwu8oT6ZOW3GXrgzgT4O7IGD7tcs4kMXuJ01zSaGwCaAFYvK7GnCHYHNbqKsTZRpny5bfFf4BrGN26n79xZffmazf4qsHaKdFr+f2dWeDBovFxODMzPA6sv1PEYFIQcP1EXvjQ0FB2SYwjPXr6JACz9eFiJ1i8qj7zvFwqlzFTQjbTxzoENCxVoqyJaEvN/E9jakuQ930WaBNlzssvZw2uMct3ue1kdT3vfd9kAH1mbYOZokLSmynTgm0xezJnlkpN9EtWynCcDjEZDJG27ZJOe4kKdXxuHqFQwpmxHxBrq6UQUOLLInu60jFZpmsbp+txNv4kkDqmpzuYWVLU/IVH6FdBZeTyGULMUBbAejuv/VaOHHvIGWp5q5iUFJNUm3ZPYwi2CD6naM/4nfskp0GSCUFBBDMRUBsbHMnVaqtyhrypTOiRTE5bi/EbeaoEXlnBuOMVliKnC16MpxQ7WbJpg9N5n7FLktuAGlb8Ay5XtjVWfPqSTPtvVeiI/q75TPCfHX3CgRSBGaN2/c8hs88ehseGe3BwckGtAIW1QDn7DwO333Cy3HM3OHQCLEbylKQddl1ADVN4BsRWuJkbgftZJvj7KUrp8zJdXGynZbWFfG5iPTPS5dEOSwtdSVu2VxdqUyZZa947sp6jgp50nkl2xLllaAtlB7Xnq6ym9Bk/2GZIenzPoVzMpmgaRpBk1XyIu0931cyUCyVpzkg7ZQg+SFKZ+UsATSeTDg9kiy9vMs3V5pP4/q6ywgAQ2v2Y8EAyGrNZo22e1iFtybFZIvImCLfOntoJfGmJ+PmpEArk1O3uqj/BdACYZByE2MaY8d1xOKwMBXDXcZyyP/qewh0zqib8Uo1dWB2wE2Vjrxglu+TGgv1dHoqdcEn0j7q6wwSON5NCPknu6QakFMnZrF4ZTlSWeuCrdkJYNZjbRpmQBmF97bdj+FP7rgMn3vuDqzxIVBlbFmqlZ9S26pl/PiJF+KnTn8btlZzfrpF+x4T2kKQyix9SR05000R2jPLlQKun6dWUOfqihSYVOYVllqmKmcFsJU09rqmM7zd1welOI3eOWvLlEFmtpDOHJza/yVFyRdl5ZDv6jKvuzaPx8bCDfTFwju3JUi+c210hBDgLf+cMp8b0wzpJkmIRnaZ5XQUzXA9kPRpcU+Z5ogRu+u53WAo97xz0ISlPuBuYQAYKFk+XeYnoUVNB8lcORHd5CkrXrNombYZADj+OhF134NTZurur5Q6ZSfQKNXWkv6Qk6p4EXnwyYJXKsiQMGBKhk3Q0a6ngG9JG8wrUGWw7ICtSMNJmnKt3avYj2kbomQM5hhuY1opPOdumk6MgKMxqcYtAzEDFmrNPLQCaVWP8Ue3fhF/9MAXMaYRhnNLUKigiKCIAOWAqQJrxnh0CKfvPBlfuPD/xmH1ErTWaC1dishaugmnijkZaA7dU1Kei7sVkrGTz6Nx3JSyFHPv1DXZTPkdpbJAw6aDDFMavgVKoLdgEw8SJ8qEVy4K4B6VIdLklgwBiCMBUkV4NsUyBVx3KUWOGuFm7oKxpS7MLweBSJTt1Kr3l1/sMHhq29MB26zISNcR7CzQ6QDLUoQ7AYj33ZaA1tfuJpAE9XSy+T4qgW2818vfWvpTyqNplGhpZbANAmOm7S0zgq1MLzXo7HvpMgHQAVpDnK8ncodx1GrRJDtOUxSIbJBRhhE77vREC7eUdtrWqacnjWcIr1b25+1cTost0FnMhjLt3cjupC9z/JB6J8TsnEXQFIPMBDCndJmAJ/b8ZocdAHDDvgfxk9d8GLfsuReDlW1QbeUdH0QMUsp87owChNJggPX1A/iO41+FD7/yR8Ca0cKcBqdIobZRyym9chKmgrXXYswA6masx9l4JJ5L8iouFxXoiNKKNkleKioRRfLKAP9CrizQinfmVQw20fzJtD1VZItyU7KEwMKchEsvJ7od4Eo65d/Ic+rqsOPoP3Jj5aNcJij2rLRsI/kWllxpMh4z/EREGLRE+/U+bZLRxN2TR2J1NACt61y3j3ZuOFfsMJZWHTnKEsGRALFLG2n2kv8gshDFA993cW54uyJWui06QiKXjfpgzGf29Eb1THEPyXqn7smk+GfJHZudeDnX0SwaeVajjZl6FrBN68zSnRMWyPB2TzmzrL3L/Gl5HQ9LFmhygjlWGIs0CL6aGtHtyhIat3MdO+29UhUOtev4T3degv9888XYWACqegGqVSDWgNtBoeDdcvYHCApgAtcKk/0H8dG3/Ru8c8cZGLctSBEqIgO2UGVNS9IYP4jbHL3jKEnHRYiEv4Wl3+n1RK7luE9ad2nsQLcduQK6c7t09XnaChmmK8iinA6fZoAwqzCL+tIra7X2eZSEcRW3L5H9Lh+JuKHOIJrRHo1G9ru48Akk4Cpy0cpWZicy2ctaCqhMaS0J36Vtc5YtAHNco/ctIQGrqFSnCYgB6oBtWE9xTBpcVOy1hrm5uYIQtINecJ+GR3mwjbYrAJ0tWnGZ5G/9JJwJMKVkk48zebNAHacvXgWteBow+MAw9PdhVspkyu0k6aE7Z32kVSLxUETgIxhzM2Cbo7sv72ashpwbHCK/5J+Oe03kc+0Mc6ogvHJCKFOefD9Lv6Xr+a31TLn1UvIaPeHy57+Bf3/Nx3DPgftRbd0K1vPgCVstXYfpQ2aumqJVaBcUmICRHuOIucNx1zt/GQswZZPvg6BIUGS9x3KnLwiqc0lAyvHhLJ6KDLB1xlSklX9TOrgwplmaC2n65ntHLmWV2OllzjIfZlkrBmKFpujeL/GlpyeUJkwGm2EKPb5csy1oNBpFykTWyqXuGi6z9dpYhvRjLusQ8r0MtqFBNBlPgkrrMwUNx0kTr4QmAyyDoIJBGwbR9a3RMAjz8/Mdhg7rSbOBbad1iYbshXqJgWQTkpvSvGan2WTqjSzxNB8V3gmmKWmMRpD6HzG9Ni3HP30LpKYY8XNIEk3K6dtK4r6RkypqkmBijipjIUnj8RU6XHz58RR8mEyWPi0/Z1lOs7zTSTfTulxIHOXLuUhjyMvVDchUOas6157NXIzgOgYzKmWszT3tKj5402fxV/dchnbLEMO5FeiNxqziagZYe6o7iqzYIsgEaDCaSoEPreLHX/pO/OnZ74NmDavru6Ri/Va0J5JoQbmOeTQO+TJ5w29O50vJS5R5l7Mi+8DIz1M5d5NyOkqUuM+NYF99HYs0LT9nbeXSFeotgnDaX+l9mm6GS9YXi3EBvDnZB1jDBlGu9GrbFuPx2NeV+5u7TwE6pRFevvZR4Ci09Xk3MoVFXZfVCcGoE1JNJgLWRKOzAOwGbW5urvzRd3nl1Ijc+9CmzrvOlh2ZrTAHpomtDqhG/N0N4ChHRCMI3mnCPOtuCezo29Uh3ioHKZ3dJD5dH+Am+owgM8OECMybA+Wi1Z5rBuK+kRZlse9S2vomv7QICnlIpOt2sxiLPrCVZbmsZap6y/AFzYCzctxaF2kMo9AqmKCRMVp88omb8Gs3fgaPrz6O4fYdAA/AbQMwQzHArGE23Vqlmm3bLfMFOWH335IBvKpSaPat44r3/Txes/VktFqbd8yoSKFy67du3nq+T9sqGhzkV6J8ii6ZIaKekrH3xRSeF8tAhgdZnGjVlx+ZYZximWZd3BmwBaKu6qZLCEkjrze1JNRXdpp2E2A8mxeqbzIQmqbBeDy2wGmr56AkZUHYdlxH+c7ROIUa78sZj8fsBb9fjTY1SVdwqWDzkDvfo3WWrAPhubk5DAaDrpbu9dPuIKdpuq11ky8I4ChnJhtDTiSxJkZ5oZ21UDIXJ/uA032+kW7mBlIUlpu0Eqhya1BRwrhZUydBqjh4iypCg66GXALdWd77d4my4AiQ95ue9Mj3oXw3kxXI5cCN7Bj1jU+u3xPrRxSeoUXwCHd5TKbJuzTDflnN4T/AAp2q8PjBZ/Art34an37062gWKtRziwAUNGsQNKANbpEDVnZgy/aexTNRMxleUqQwRoOzV07Al9/+s6g46FpZsJWI2Ys4LklXfqR5+xScWYSnT5to5p3T1fy7ACqe56WSXPCeyLyzQX1cZyT/cvwrlMWccuhoi4udTkluDstcXimgcCZAqrh2LOiZ5mqgQLasO3cJ48kYzaSxYCvdxmI5g1S4t7Kw6D1I2msbGsjiOA2DzUKLjSEULQgTVw5OKgRdriiNryMArfsebbSmRwmIIlMIkjSd5CkF+cnjUnTZOK0sP7unBTLlLNhunrgdJaaO1hXcb/s+pVzwWkIQx++KfJu+kNIyP+ldvaV+zuUp1QY4oTwFREGZCZQpqwR8WSDrUsNs110LdUnvDRDmRHm5IkEgQ003XZo/zeZANyfXi4EJpvqWGROt0dgPb1cE1KrCBo/x/739Urzm83+Ajz15PXjLMgaDFUArwJ8PZUiL7LMcpjFZQIYHYdj6TEDkPG575m7857suRqUUKrggKQGUJEpMGMmPPyUVW4VVBkjmiGR0uzQk7xk7FmV3E5QBwdEq5mF3isYK2wtZDshQVLxyYiAFRAdAKQjPGt/g2lsC2piggDEp0M5YmxOQAKad6MYY1AMoZU6S8kcH23fRfSICHe9J5cTV1Vunh9TAAcaN7BqbESRsP+BuXstDnU2nmEOgyX/oXbqQtTZBFwsLC71dkXKBEyC+24WWkJc44lnWL8ye25gQRTp39m4JJSAr4CK5I0B+E64RWY4RNEmUW8YKYwTNNNSVrFpEpq0E47ygnmpZmUIzGbv77OL6A83eMs+XHtU7y1pkpNxl3MszX9NcWptwJUraQvEcly0nqh97mTfQk/WkzNA8J9S8dwkcbesxViRw5TN34xdu+CS+se8e1CsrqNQ8vFeLACIDMu5reKzNfbBoLWHuXnMEGJGiRxV0RcAQqPZu4Lr3/RpOXz7WWreEsPgrt8AIPkgYN7dU4+9j106hj/L8JtP3ghZZ0c75lDPtBZUgXHBRpsFVWUUysZbds5KaL8VhJxB2yjxM3ftx7EoyJqlnsk+2lCz8XHkifbIJbFqPAzBYtbGxAWY23pQM4BtcC/epfPaymYDs134cfwjaHE/QZDJJJGSXcDaSPgiJSBjEg6G1jrSbxfl5E9WFeGtHXIG83eT+MkEDgF6wDfwYBiw3TL3BN36WcFxtWvdUmt2f8iTJ52M47Z+kUPHj5rRqWU2ZFYNBMYP1lwoG10+5tFExAnBTOShBqAS20SSTpMWt24wGnrYlpb7IAxKEJV2JwhoCfaRwtGMWjb1rV7jnePBmA1pBb8sGZB1gug8DPD0+gN+75XP4q/u+jLYGhvOLgCYwmaAmktq4YzM3mZ3Fal87K9Y8du7kQDQ7ukkBiqAqhfF4Ha897CX44lt+BspojXC2EIHsF4PCOOfP7CmD8Wwuz5SHfZMSEdlXhqC9K2t78xpRmp9XKdima74pO8y8NJKhLVrvFTSEnzH/d5f2ynmz6Tvem4LMTtNKPBKyr18lK19N02A0HnmLVdYXedAInfcxjwQOTa/8V4PYBUiho0H5tqH7yTzpcmAxCR3QghmtZiwszmNQd9dpTakJo/o2FrSbQFD3IhIMTKFHMuW/kKtoZRU0uqkamqUnt/5m/sTlUGYKc7bvOkUlvwun8HQKRBf8OdbwOAGX9MoNQdBTpMKQpzcmkOMJxkAuwHsa6JcExDel3KFAe44fI1oKUh4F0VGQ4qngd9Zsq03kcEUVNGl85IHr8Ru3fg5PrT+JenErlFYgMDSxze/6gQU/GcWCIHjbjZ0HYCcP4p5wYEtQZgsuAD2o0Ty/B//tzf8SP/Ki16Nt7YIwTFRyRSpy1XXOpPV6aaKUJO9Lcz1d7nHtg61LKp6xgHe3aXRuQl9qb5HMH5TzojWboTnXBd+EKMtevo6O52y2vO6aHfaTenNlOp7MeXnse/8o/Uqbf59Thgij8QiTySQK1qXA9LGVm1niITW9f9K2ESDA1jcwIdBrNghaYDK50ohkZkZVVZifn+8QIfTeqJ5pA9wXlUkJw/s/3wKw7dMc+0C1BMS9eSO+io8SS0MPfPcnc79QXO+VgtSmwSdzlUB0M8LC0bVZenrHzN98E2Br6QJKfZzRBvoAFzEQlLwtHfcyheeRNYvwdZ67157Az1/3UXzpkZtBi0uo1NBEFxMAciueBjylVi9JlrJMbtJ3TCjwJFi09q/yE5TAijBRDZbbOdz23t/GDjXvy6oggqVccTlPWAlQpwCtpdQmSZTYKC9lA5+k4dF3UdJ50yzPCOAL3hz5LLt/eNq7KfXH4r7fYEjzAqU58MLzSppihV8+CP1c3ItN1nfJSR4A6xvrYO32jAv+p+SvmBeOLreEWlo+yykgBIDGoxFHgkcI+OAe8ipZB1jdla7ZLi4uZgesZH3kXLvFdQhOfkirJ6on3friRFEov7yeICbnCxT2s+abxSHSJ4gzFIQcs7qaMu2Vrv+ZQFJ4GNLJUmpV71QV47+Zq39cu9q7d9dtwiUHZKh3Zbs5lBbX0ww5vnIOxsV36WObp9UaLZs5WCmFCY/xx3ddij+96YvYp9ZRzy2i0hWgNaA4uI0t3ZLAmbtbuCIdjEWUEcJ3oImgGeCaMFrbj/ef+nr89St/xAg8Mt/BrWCiQaVQixrqb2ebI73LQe69fxXS5MDHlc9JSzu8ZApGOmNiGsK7otD2Frfz5tiaC4DaiXJPACK9AsgkvSnnekdfzMnz2Y2R2LOXj+RFQi/JZRuZnCw9PIUGyKXCUGPbttgYbQDMUKRCXbbcNCDP0+HqTazeyC3v5QCi/d40GY+5JJxYZMxOdAG42kYfModtPn1Xqo04AZOC7TQL0KoeUzSlPFAVZfkmhGSHtE1aYrMw8ExBFyK3lQAmb2YJIOcaEZWFW6lcSQDPlOueddZYKHaCx/WHsPhv1TVT/wurwU+ITQKtu3zbuDuho0RTy+lItvxlhQvDHrPI5ruxBLPNpuEGn3/iZvzmDRfhjn0PoVrZghpDE+jI1m2bWE0USVYhtPsmhs+TbnkL70nQC5DnIF0RJvv34dPv+UW8ZftLQBogu67shV1a/xSw7Zsj0TuBgQGMkwpcPVM9JJQ+iMcxIj/Iu3QrjCVmap0+7ybWSEtyMVGLNnEFaTpTXifTSwZWQYG0CeyDJI1vVH8rfGBSwhuOBcbjMSaTiXcXR/znwNTOFWem+THz702JjoVkoGNKFY1HY3aklKJggXC+cdjSY8qTFq3WGkpVWFzMRx+XXGHZK8aMoCV3KMs/yW3HkQVLodARdX2cWWCAYmRswu3ZdVpKtuok6TqMmuFwyfqzuuRzCk7vmCRXn45impWbJBQljgR9NLxpYEScxGn5Ud0Zj0IabJG7Irp9GSlBoQ4pIPNWhvgxrS99P5R5xneZ8Bowm8P9datNABIRHjrwFH7ruk/jU4/cgGZYoV5cAloHriYnu/IEP7qmhmpLWqitXbibo74Q80pazRz1iRFSbbuO4xePwDXv/mVswZz5TIFQECtnXST9FH5251tJqex1riZ9G+6paOHbKSuKCP2xOUVALh38E1w9nqG4VsoMHCJ3ulEQKMmPDn9Pa0c8LoWrBLI+U1DqnUIXyZZcvV5CsmVhk3ZjYwNt2/r121zglJ8vQknLKjOibYGkQJMyL8igt5ssZBM5S4XZFSesWRHq78dUYX5hLvi00z5CWfPrPPS9KFpDmXT2VQq04IKW6IWM+69/nYNFO80D7gXaLAJN0co7HqaoulmA1mTKLuhnLskQuUJnjXBMyU4KiZ+R63H3Oy0pr+Tl6sy9MyxLXcHixmtamzxfuz4sCCiyQqjgCeJOBvkzw21ittpZlTTKvGTbny1rNLpFwxpgYFBVGKPBn33jMlzw2T/AR5+4Drx1BdVwGdzCBEApDuVmhKOZLyHewjdEc6b/hGCWj5PxZtkZbNsABhODoVHNzeOhvQ/h12/9NIgUtNZo2PynWW8KfEzfcNSXs2fuppfDm5MTcTXixKxiFfmo1X9SoAUKylJMQSRvpynpgoeY+tscasgpTD25EqBlJEPkNLfs0mLIE70SbYsijmG+pw4yXiLD+uF/viSLPQF80zkcwLnD9jLZeDzhoPkGzcNNboI50FmCbeiLAESt1pgbDjE3Nxd3VgckXZM7j0Ln9KyxhD1OmQSurmydtowsCEy/nOZiSKVO+ZFlWLiKsD6FZkb5mMipV+Iy7K0/ymbbWgCVjtUq32Uszth1XOikZA0kqisHooL5O+Mqi0V5WMw7doQn5HTpydFMfWnIjvtmJGrO2oKZphrazEcybuNrnrsXv3DDR3Hj03eCVraCMGdPewpzNqfomn4FYsIyqCPbIGlLnrt/4zVN1/MGbjxvkKmclUK1Zx1Xfvcv4ewtJ6Dx67eEmqooWCoAdkLmDHMh5kfONjNWFPqXIoLgJ3RFQTqRujREfdhRpjkYOZk2FLfFFImNvWbpOJaGPH1V8txFxaTLE16ZyLTR5XWKf8GapaTcXHspedGNTXQSJ99bo/EYk/E4jk52rmX7nxPPXb4ga5eaOV44It+kDN+zZUFQ8jUfFm/d4In3xn2ssLi42O2EXBO9gtQFLS+XEl+c4b9vXgdMjywD8oCSu7wrJZN8U3v80tk9pfrI7TtD+jSvZOosXXk+zwCle254Ii0xBdrouajMT6ASIcj3Zwk0S4EwnfQFxSNbLqHzAYmpoi23BrUZsE0UTgdTcs4RDMjunhzA7976WfzFPZejmQPUYBlolZ2v2s9bShQ1LwDtu+7lJ6doVpfvsmMKMac6JVpgIoL9Cp/JNxnhjJVjcNXbf9kESEHSGm6idb/S3CkwyFSlSRDvvWIIaoJsLznhKtSMuO2Z8jmWdcXzBqI8cWk5sJ0qc1IPnCmgLD7cnJbKgL1jFi1N9AZPqWeKRGktgJ1UoktxEzkZ05dGOmC6NGSAnAhaM9bW1rySFRxkFmyV6shBf8/obgXK9DED4as/8ZqFocS5lYgIrIMrSgZGObCdn5/PB0UVOtF1gNe8NgkgnXIQOki8SCzS0PC4vC6PbIqpMV0b9uVkVEc5kfrWjtL1Bpk3toJQ7vPSemZUZ/TAJY4lbCIM+sr8f+rK1czpfUb5KNHciS/wtbi295xxK/IUQTpCrKhoUQPEp/AIDI1PPXoDfuOmT+GR9ceApS0gnoNuLW855dhat2TVbe+JSOMepP7h6+cQ7WkaZl/lhZW/93Q78UqhOivBiAisjHBlAANVg/ftwQfP/y78zCnv8TJbQ/s2KwtzSed0+7yPAbxCmcyvrOJslRwAbF3aTtFWSvnDN0iQlFERiuA/TWlzyqgDx+hdQS7NFI08g5fLv43kckJDNC3iDraj7ojt0l30iJVUaVFONB9DW2SgVawa+cKT8oJcZdvIyWSCjY0Ne7KUSebXcZPluchLV8CMbDOyYIsweHL9k8Rzd4CF1hp1XReOZMwgS/QumTwzyWlOjV6vuUd8QfntHCXA9Q87SopjorI2OmsEctjKFBORA9sMKZ6OjhBMxi52qcZMLK2U3iCsXioQ9Ws0HD0A/q0G4hJ1fVxnCbIJu9ZCnCwHtu5nt02bAtsMz3OS0gldR+ct+x/FB7/+CVz+5I3Awjyq4Rx0Q9CKzNfv3FgzPOhGZxb7toePjERXkLTxZCIIkA69HuKLkRmIILS8FUsEKAO6WpncFQClgJWNBle991fxosGRaHWL1sokRfawC1DCyTH/pn0ZmspxWqdMiLHRrr2ujdYFbyyWGEadPmMeSIpsBHUBbH2vuWDIPrwVCmGfMtsJCAuJfPVRVZsBW5s+expSKNA2saDl5IBalg0hX6eAcVx03A4J5MXcPaLMvV9bX4fWrS9Pgq2Tl9JDkQZQubOXSwYmjUdji0niiGQIsGXHmOwH1B/JyOb846WlRVRVNUu/RNZnCugSAIrRvXH/AODOOZ0pk3XA0E0Sny/+nVosJbpyICK1ylJ6WWVf+17I5Qa7u6ZK0R9zKxQJlx+I8kZBAVJ7FIpDNNlS5aZv7Aog/EKWC6ZZ7L2TeIb6nRXUH04niiwoMoa3TAr5zGOkA3GG2Q5DhH3jg/idmz+H/33fVVijddSLW4CGQcQ+UCUGCjvv2IwlMYHtt2Sh7V9vuUieFDMnEiTBEWiSp7An2pOCtLMUCBHYsgI0wX/qjzYO4YLDT8VFb/pZu2fY9Lc5WYqgoLp1dc1K/1uef56OQ5BnVsGheC47WD/YruLOPY/i0dW92NdsYMfcMi488sU4ZrgzyMiAcN69LCqMTqZiaRTYGzkPcluCgohK8iLhU47HcSqXFsAtN0vS0ZbA3gm29LpHTpssy3SJhWldKS1pfsOS3f4pg2+uJnOU4/r6emTJKiVONev8NWMaRCR1vJMSAGuQAFoByIF0jp5rDpoZM2M4HBigzcw/qUzHY9vVsFIBFAVDFS5XpdS1Edt+ghYBoB1hyhnaxfosZwAYXYahkFk2Kn9xcm8nagx8pe1L5UtGxCUqQESp66kuXZxl/L4AJJfQeZolLUU60enyKN+mAbfLZEWBElGRkJjWK70Rmx0LWY2jw/G5G2sG+zlFIikpwgQtPnz/VfjdWy/Co/ufAC2toFIrwMQgqVuXVWJ+xtPL8A+R/ZCA1nbCtN4mcTXH67Keioj8wFhSmHRuuo33oEtBMeOg6jVao1pYwpcfuAV/dfyl+GcnfZsBYNtTYIivGxES9U4wqfidGVenzGjf5/ZjC951SBjxBPceeAL/8MANuPyJO/DAgd1oAGhFQAUcNr+EH3rROfjJ09+GI4fb7ccaCE6OyvXYKPacGWK3ZvlKQUTkT98Xu0BYpNnUs1iRor5YVGUU0WwBuZodnlBuiDrlFNS5Dn2d3yxzlErpUl3XNaq6Rtu21tMc5FAK7q53yfK2pM25tcPUMG2m0Wjk16a9kGMpdOy6kT1rVet4vXZpaanzQfgQ0BM641vlSswKYpbM5rqiy5xSi0zBPU5jyymk6b2E0O8DlHxecU+ZfuwU1lVaYjpM7oi9nHBIpo3bOhG729DbfO+mS9LmQGnaGnhuvbrkkqaQKSGmW1eUN/u0/8rRUWwLZ9KQ7ducXmPzazPhQGCQUmAwbnjyXnzwxk/hy0/fClpcBqoaoNpYqpYVnILs4CeSMfZGWV4mrc2ZFq1xk2mrlbdgAMpsArSAGOsgDHKfJGNko9ANX4lMbt44QaTIW7QeeGGh3saCkAa41Vhca/D17/0tHLdweL7vUwXAV5soToXJ54C21eaADweUz48O4EuP3YWPP3QDvvLcfTjYbGAwN4e6qqHq2uwDVmaLSDsZ4bjFnfiHN/woXrFyktkiRQRtlRcPshSDbQ5eelSUXmXUFBnPF2TrRDxPckArZHMO8ChXTpQ3VRA4oqO3LVG+zCW8aUXjRuSPpZ2bKPHSo587mattW6ytpdat5TDn9XBTW6Rxv5ltemFpetrG9gSpbhtj97Fcq3V/S2u1JYtMTh4fKu1IyfHiLFcHdwvCWNDg6y8V2YNh0+mJM2/KSksZol+3QxFsOWb2qOis0C/0STomhVkzi8s/fd9xD83QT05Zmgq29l1K/gsB2/SaKagMYtKLue/Ehjv1CWKeuEn80MFn8Ac3fA4ffuBqjAcNBvPLgK7B7huzhOgLPQRYq89ajSQbTVDWBUyswaxBVEGvjsEbG8DcAtrFOVDbwnydhwEl1mAZAGuQDg3wBiYb+juWmgNT/5c6v32XMIfP87VGNkzW9+Ftx74cH3vzT5nYZKEAilnlmykFoFdKbdktMzTsEZb27GVROSbc4t69T+IfHrkRH33kZjy89hRYAYN6HkpXdguVBqqgLJACaFBjxCNsUyu49q0/hxMGOwwIW7BV1u2dbl2KDQL/OMM76H3v04k5U4wbmcXLFtlquTq5jFAZJcJ4yzkat2lzr5gmcY/L9PlSkuwSXyDHIE0eKFhbW0fbNsaIJITjHBF7gCSWySW5CICl8TUajYIc5nC0lRxEh85OC2VmtK3G8vISKlV12jhrwFDUSN8Z5by5LTAd1ysnFtq02nNWSg/wTwOEnBXkQCL3Pl1XkFaQFCKdWvvQU9QTly21VPlQar7w612pG78YLJbpr2ng+U2v03Iq5jMiys6ofq057qe4KxIaZ4XrSNERwTi22zTMMYsAQ4GhVI2xnuB/3fkl/M4tn8He0R7zZR6u4ddaLaz5YCMLvIa/2H8mTwoBkLJj2VpwYvCe/XjHrpfh3736nfjpK/4ad472Q60sgbkBlDkL2wkiYgpgyyw+Du/aFawOz6iOPoJxZUbWrIvgJVuOBloGswa3ZCzEGhg/vxv//Z3/Gj988hsA+01s15++Cvc/qbwnY9WyUWwIwEApkBWaB9oNXPHk3fjYozfi0qdvx4HJIaCuUKsh0AIkvHeeJ5xlrqwXoFaYjFfxtmNfjc+8+kfRtA1aOxaKFOr0owoQikrXQkjFIEqK9CyyNburgcoSsaNTF5RYkaDo0QnCqqCAFxQEpyhJWdmpPwVb6lRlHG25hrLDFp87lOT42VbRNA3W1tb8eq3/zykPKnBjpAyS2GdOLng1kE2j0dieyuUmjmA0y6yuMZrD+cdKKSwuLdrJnISJbwpsZWeEnuvNL7gjBdsXfBHF65IZ85bTgZ9i0ZUAJ7d2nKYy60kBbHNp0jJ8+UAnitD1bRwPkwCRm5AsAHWTwyjLNuT1jE2uHzJKSaqwwJFVKjsRcr1XKjNEf3/TYCsmsf+IOwJgKAuQX9t9N379uk/g6qe/gWphGZWaM9FDCGuAfiikckR2OxBZKJZg6/5jMiDTjDG3OsZPnvZ2/Pp534lKDXHvnifwlk/+DvYtDtDUDFYsFDJnPRo3MjEDGoB2Y+SUcNFHSgKr+etP77FC2PetO52qZTC3QGuFHmlMqMVQDXDD+38bJwy3gTRQkaAHQviRi1Fwa7K+a6AIqKjyHXfH/qfw8UduwqeevAkPrD6NttZQ1RyIa7SNtjS1nhnCkoUDWvEfmSGqD7X4wrt/Gucun4Cx1jCWUPdQjkRvRY4zAzs7ZTGTYwpwzjLvOmAMtnwiE1kO6JRDFp+424QC/b7YhLYUbPvkG4u2FdOzeDnD81yAqLtW19ag2xaK4gApM61UmGeckf32p0qe03g0EtgaKtUsvuLDMdBqrbG4uIjBYOCZKCV4pu0UssmUTxd3cAysfZ2VlpV3scT1RqCWuF/CJM5rWvLKW8t5TTWaPL3WYJgM3SjEGJQl+dF8oS79pYkAWMDPTetCv8nXL+gSYBRpsTmNN8kXXTMoerHtWUrjhEJSXTaHiEoUZZrAHOfSNABTKePSfGz0HP7D9Z/BPzz4VWxgjHpxGzBx9RLcJ/DInV7OcdnBBBXKFcGukZo2Kq6B9XWctnQU/uiC78cbjjzdEqYBUrjuqbvx7Z/6Q2zsWEY7MF8OMvWJZVwHjBr2CEcJuM6SEEAb0eUJ9cqCiZBmU5a1bEnDeM4I4LrCaOMA3n3aefjwBf8aNZu9tspa9KapZjuQD8IW/Q0Y11+tFA40a/jiU3fhow9ej6t234PVdhWYmwMNhsYb0Gho7cCQAdZGIdWI+ty7wJXbJ2z6nA6O8N6TXo0PnfsjmLQNyFq0VWINeQXWEev7hQPPZGROh5NLlt4Unk/XdLtgK4t145WXr+n8jGVWUNQkndn5O4s3S+TNgq2TGRQoLszOuC1FdDdlTSbWuhVgq5STswSyVq/DPxcUZV03pp/tf96rOdoYsRHIQtuwdKRrtcwmoIEUYXl5Oem3zYNtNCRZmc55zUHWIwDYm/CpDll04cq6Re+XgNG985V30/S6R3PlJs+8K6LIh3lbvjsp4S0199tppCGwM2hsKa2dvk8s+XzwyuaANlJuetLM9FWeGZSguN5+sI0USDmEaWqK+U22qeXw2TuwM4oUJmjx53dejD+69Yt4ev0p0Lad4EltQI50ACVfv4JTfYz71SGAQbogri3QVQBIQbUa8xPGD518Pn7zte/D1noJ42YEZkJd1aiVgoLCxQ9fjx/8xz8BH3sYGtJmHZUMYEMB/lCM1oJkBLb+MyZg5QSaEzhu7Cx1FmQNmFkGdV8jcoHSpjq0NUEfPIS/eNe/xg8ef4FpPalkbpieN/1K3optmXHb/ofwuUdvxccfvhkPjp+EVoRquAR3RIZxvbsDQ8yhPaZLbeS28Og5l7VTZDTBBpgxVANsmwxw4/t/A4erRbitIN69KEGABT91NFS3TDBdUUyvmYG29B5xW3u1Z/nati0F0hRoszTMArQpGcI4kLJmmoU8q1EmMgAMHDq0aj4BqYQr2QEo4D1IniYrp/x7pax4t7J0NBqx074JiXtBrNG6/5qmxcLCPObn57vrArLSUodZQREJKBHJmHZIb/DJjJeLtM3lTVbXZiis0E7hEo0+4izcINJalr9Tl6mnxmN/V6vzZYpnEfVCI5fbV2YZp82k6QvKiOjrser9+8IEnGWK+BqFIE7lRs6a7eOkmY7Vi8pmP64abs3QBuhYi+drz9yJX7j247j56TuBnduhuAK3CkBr6bKWm3Pleh4I/AU7X42VaMGN4F22rCpgfRVHzO/EH1z4A/iBE18FgDGajDFmDVCFWikMVIXarmP+7W1X4Ccu/q/QRx8Bmq+h2wm4UtCVBRpmkLZj5M5KT+UnYA+IcEKIwLoFMUFzC2JlwNYDrStHw5mobs8rK6BBi3nM4+4f+F0cOb/VrnM7ZdRUrohQqQqKgGcnB/H5x27HRx+6Cdc/cw/WaR28MATqBcB9KByAP0HI9qfDVX9WtEN9P7Z2hF3/gtGSDRKlAbD3EH7/9T+I//ukN0C3RjhLedOnCMf8KX+IXyVgKliMZU9QDuURyQcpi7uXU8BN4s3DZXzJamLZVW5vuC17AXPr9x1eLXk7xTUajbCxsYGqqoR12z1VijoyLPCKHAva2NjgNKrN/ZX38nu1KysrWQtuFg0rG8rPbq51O69oCW/iKgVdZSOmp7FQwWVZmiizRNgGIRAEgHsX3CTxgPpSLWDFYOs7tGMHR274TJ90PBRJe3wamjIakZVcqE9a9UnbU4t/1onNktnF1VVVcpnFa49t/TXL/jERsMaadcan2zbw6Mbz+M1r/xEfv/sqNAsV6qWt0C0ArVGROXQiVVHC5GVzQpQHA6eIMUgbq1cra422DHXgAN71kvPwn97wwzhx8TC03EA3GlTX0NB4dPwcjps7HAs0FPURLrr/6/i/Lvsf2Ic10LZtwEBBKwE+rAJQwgVMQSiRdmtNM4EeTzBcbbG0sIQNNJjMD8CN2d9rANf1t/GWiUaHwahq6LUDeNfpr8XH3/xvPR0hYAXY0Bv44u778Q8P3IArH7sbe9aeA80r1POLYFWDW0CxBpMLNJMDF0CXHfp5O70wxjatCdBmKACTtsFpS8fi2nf8HAZQACnfr2lEdZ+W5+ZwUfFM50QpXap5J14fSvKWvJLkAVXKYFPeC7HAUxLltRmwTedcsY4eQJ7lYtY4dGjVl+UsWZWzcCMSw/Mg22HANhSeB1qjTGu0bYvBYND54IBLN5PwjkAD8OLfydgesToL2EYug57kOUYqXZ3AKHSLjrQ0YeW+kMuLmymuUSOrehizZ2IbZS8/Npu+Mpa8oy+pMquF+3uZJ9fnm7V+naYu0ri50BtNmRaTKk9CeLrfZo4wGtZotbFS66qC1hP8r7uuxB98/SI8vfEs6i3boNTArk8aaysY0BzGxFqGZOceOynPMOubng6DQJoIeuMQdmIRv/f6H8YHTrsAiipMJhMwKVRVBU0af//wV/CRR6/CW48/G//2Rd+JOdQW7Mx65NPru/Hr134CH7vrKqwvtsDcItSwBqEG2ehmaQEal7CG1g0m4w20o1UMxsBZS0fjVy74Hrzy2NPwzz/xJ7h676OgpQW0ujFtFmNMOkRSW2QC2fOTVaXQ7tmLv37XT+D7XvJGACaa+/49T+CSR+7AJx+5ATcdfAIjjKEW5lBVA4AJ3NqtTtGQkv/jsNUJ7hSfohzSknO6h5WLpI3LWx0Y4bPv+km8YdfpaO3Xi8DW8gYlfC5B3ws+88fxOgfQj+ZNj7s0ezmiE+WYO2mAlPcjRTuS1TMo0uJ9r1SRfZ8r1z+IFQ2X17/LpSvIC+cqn7qrgoD1tTVMJmMoVdmcZNduY8A11WXA1/5mCLBNXcJhrdaBrgHbpaUl1HXdaUDp6gNbp527hvaBXx7iplxTk09n2VnXooMGszltqtcdK9Oh2xzHoFMoKvbDrK7/Wa9Zoqw79ZqM/j4HyGXr1xcg6uIkG3WJ6APbUFzyKB/1zjDBg9rPGfaupq89eTd+6dp/xI3P3QFeXEQ1WLFyT8PFzrozlTii3gpyT7tb0GRAw2/BMXqEAnMLHDyAN53yGvzXN/4Qjl84Aq0eo2k0BvUAlapxx4GH8df3XIr7m8extGMF+/btx3m7zsBPv+i7zcfb7aE1StUgBdy99xH83b1X4+KHbsWT67ux3o7RqtA5RMquuxIUGHM0xIlbduCcI07Ce055DV53xEswoCGICfc8/zje+qFfx/6VGloZq9aDiW0DCH4/K9sgJChjRWgCdk5WcNl3/xye3rsH//WOK3HV/gdwsFkFDRSqwbxZRNUMNu4C05PW5e6Gk2yPeyNTgK3ko+xlwdPxp3Zls3G1txur+MAJ5+F/Xvgv7YEZJltFZLYBJbAf+CwW+Oy4jeD5vKOAlmRoaGRcYNAxknrETZbnRXoJXJKuaR6uGa+pQZDuXZ+csl6tMOC2M5LuQWEud4kCmskEa2trwZtCFPbdui1p9h9nyXa8tw5s19fXPdgSwbiriAXIwruRiYCVlWWUmLLXh94zqKFDMlwRpfKsKPoj4yb1PCmZsiBcCdm8Hfq7D7PWnCyegZmil00RCegmWlnWvdtXppgQveuulGjaPZcERk4mXkpHr/KRmzRJOSV2iQRAYRxjwyH8KE0wuWYlKw/8kyrPHPVDC+3X6hQR7jvwFD54zSfxmYevQTMHVPPbwEzGKvS+11hFkKpC5Op3AUjuYAkNeDAhgt5Yw1a9iN+98PvxI2e+3gRgNRNoALUaQkPjIw9eiU8/ehWqFaCq5zBuNaq6xurGGo4eHIafOO09eOn88bY9xiqrqxpEwIZexyMHn8XD+57F0+sH8PzGKjb0BC0Dg6rGlmoRx61sw4lbjsDJW3dhSAMwgEY3MJhjhNNf3vwl/PQX/wf4iO1QbRuaXRkQIkVApQzQVsqDLdl3qmlxxMJhWB0fxMHhCHW9CEAZOdUyYLcnMXOInob4a4VwiGB22xUF0BanQSQk4OJYjLKhwMTgGlherXDz9/w6ds1vhbaBpAZsk21Afmzlr4zoKVh9Bcos0Np2ZNJH0yUCpoKyWshryEnklSe524kR/RzPQhnYVJJlqSHYK61SeRZZ5t3y4qQ5Q4lx8NAhcKuhqsqDaRokBcC7l129buw8UG9sbPgAKXAgREYhA+YYq7m5OczPz0/tkGzjhYbl2ugHVwJtctt39QU3RdtWSAitmDRHQZIXEbN291GVgTYqT7iCXL6+K3LFJ8R1rMFpZUqmzgDqLGvs6ZUF0IIykSrY30y9XRpYKKz9Ctq0ALgO3yZ9lbqQdVR3ACcA2D05iD++6RL89298ARu8inplmxHGbKJoY8GSCtvgQo6FovmWJrTlX9Km/9sxcGgdb3vJufiT878XJy4eaQHOWrNU457Vx/E/b/ksHmgfwZatK+AJodUttAIabkFVhY1mgtGowfeceAF+8Ji3YJEGIBB022LSNkBlwNJsgVCZbnb9YT5qT2Qirplh3KlWoDdo8f6P/SEuf+YO1EuL5pxmIrBiEFV2U6wy/wnLFiBAAZU913m4vAAmBW7t+cZam8Atra0OYgDWRROHWGnHnmFfrrSApD0QMUPaVAvezq1PdmwxV2Gy9wD+8LXfj39zxtugtUal3Jal7mlS4ZbTqd6lYgarj6IbCqAkBJCUSzG45S29CGwLLtnSfM7FZ6Rt8KSl1nGSN9v2vuUzT39GKHAy9knaXD+MRhvY2BiZQCkA7nAUckse3uo15Zv98+SVdG/xSss2uCTMvbbRgqwZrW6xZcuWzjnI2cvJYduoOPI4SSQ0K/Gg2PDSNQvDhoKlWCM/4N39qz5zdG8URzFJpLblJkZUT5eG4HKdrZ0+8Cd+6svplMCelUXqHgWiU5dNFzIUdaAs9QUlpKTBptT6dBlNM9bEZXWpEEnANproec3c56NuPgeHztvjeHvCE/zNXVfht276DJ459BhoeTuIBlaEMUAqmnSxXmnnHemuAgELtt5CM6/atYM4YrgNf/jGf4b3nvBK1FBo2jE0FOpqiDEafPTeL+Gix65CtVJhMJhDM9ZQitCaECY0WqMxkgFaKew/cBCnrByB7z3pjXj99rMxTwO0WqNhDc0tmNkDhmmH61kXAGQAZYQG968+gy3VAo4dbgdrNl/3UYSHDzyH1/75z2G0bS70Sw2YoyLJbJVQ1solC7hstBJlR6Cqa9RzAzRtWMemFtayhVl/FqBIEIDm5ooViizORg4WUIA/928k7K1F60Slj96tCON2hFPnj8Y13/UrmIOxZlXUV/CKv+dCcZhEb7xKjh+li7wgB4JnLWK6Yk0d8MzM+xeyC0Vk8OVGdLrXhWzTSvbynNPUciwzBTlecHkzFbVti0OHDoUTpZAESEVnJ9tiBU46EI7A1hPO2n9wwPCWhiJlXcgzXInmZtpEkbljjpvLdWFhbazgtohzxtpbJHQzzBqlIeqeIBUyF+vLMU8JbHP0lzSqzhphUpBnTspxiH2WKoNTAMaQnNCRWKvFfPnC8okLmqsUiDNM27jOSKuRt3nQTJXAmLzwXDP7oxWdY8grZwC+9uzt+PfXfBw3PvYN0JYVc/oTTHQxlKsz+oaNoC9YH5w2gAGDNoD5lB5BTzZQrY/xA2e9CR8877twRL0NLU+gmxaDwRAV1bhp3/34s1s/jaf109i2fSv0OCgIIG3PpTDn+GowGtsnqlIYtxOsrW/g1JWjce7Os3HOkafhmOEO7KxXxLpj3N0T1ljTIzy6uhvf2PcQrn72Ntw7fgrDEeM3z/kXOGPheDu2Bnj+6PrP4Tev+GvQsbsA3YAHJvAEZAWUAz6yR0d6UPQaPOYWF4xsch9XcFuSbEPZNzhQGx28gcxc8GAV5k6080uUH+pwcs0k1sMK2LeGT3z7v8M7jno5tHbR6AHwKALb6NVUpdsDqgTbXoBze+pjoJXVRql7ZGzOxbppL1VGVsrc00yOmeRPxsgweSl+LIeAA2/lKmFmrK6uom1bKKU6239SI6r725RNa2trLAt1f71Vy9aFPD+Hhbl5OHdYbmBKLjsW/+a+PcuIt2pEQpFRtoYcDel79pmiRqf50qs0mCUAzkHc9CujfVFat5j4mULd4Ml+TXVDFzzhjUNKy3iBYfHCAkhaEVHj02TAM1rzTKiH/J2hW245iHipVJAopG+tJqJN5HRLLM6KMOf0Eh5ffQq/cP2n8Znbr8LGcg01mIPiCkb6szPIEEZJJRNe9B/LX5Ze7WhTYGjoQ/vx4u3H4vdf/31429EvBwFo2gkYFZRSaNDgw/ddiU89/CXMbakxrOb8yYPuJCrAHLTBcF+/adH6NgJUEVRVYzwZYzKeYK4a4AjaiuO2HInDBtuxY2krRs0E680YB0ZrqIYKe9f2Y+9kH55b34PRoEE9N0Q1N4f10Sq2rA/x3877WWyheaA17rUJN3jtX/4i7h09j2r7Elq0gFIm8lhYA84mJauIkO0Q1oxK1RguDNE29ugnpkhgOiWYgWhLYWfapdZgpK1bsGX3TIC4AHNzEAkMPw8U2rVVfMexr8LH3voT/gAgr6wRWS6I5WTu27vuHWxbpi1BdbxAUgZmZW7U8qwsmEUpT4ElXYa0FAQaM3U4ZTtbfoGezicEM/VKwdoxaqzSw0kfpG12z0ajDaytraN2e26JfIBUCrDKHWZhnVKRGznd8sOCuYyVq7G8vJx8IN7l6Q5KyVqLwNP0XicPKAbbacE7soOiuSIEda4Dc9dMYPsCtbJuoQmSZAA3TLZSXxRUMdfJhUkMdLXkzV7/1H2VLV+66IG8iywpgDn0Ww5sIwC0Atp9lYfhjiwMAmrP5AD+yy1fwP+45XIcaPej2rIdpG1EsBNwzEETYBt4yNa6jcA2nH8dOsZGmCoCM4E3VjHfAj/28rfgV1/9nVipVtDqMbQGqmoABcJtq4/g/9z9edy7+iC2rCxBtZUJErJAoznmI0b48pD9cKYLLAYAq70TlK4AZmi7FgzrSh5UA3NsoWazLllX1h1doWknxlVdA2sbG3j74a/Cvz3hvaigwMwYqArXPf0A3v13v4zxrq3QFQBVm972YGs35jllxVqT7pu8BMJwfggw+bPbuTAXpMs4YpUIdGQGeR/6LeBeoMtZjQwGK2X4nTTm1xg3/OB/wMkLh9l+NksExq1sPQRCYY5YQtoMsg8KMiwKAs0p51LOROJm9q2PfVckfxOwjSjejAUcV9BV2BMvIkHM7YxcDTc9bXUytkBn27Y4ePCgB1alCG7t1ingoBh4XX84+VFHTATBXxzAl0hl1mrDYHmB5gQcXAUkJkIYYP87JysjeRhrTSFNgHFKOl5kFslzjCkai8xQZCw4TsGjoJXFxcR0x3RyVA/LeuOOgHMrSzoj8I14zNLljglL+5ETzTMsGoWx2QQYz5RG3GcnYa4MStonJzBRVBIn/RVug+LXG5Vt0zDbrTyiPFI1RnqMj9x5DX7z+k/j8QOPgZZXUM/vAE80gMYzs1vLDUNLQveR0tWhGwWlwVmYpMBNCxw8hAuPOwO/9brvwbk7TwYBGLcjAAqqGmCVx/jIfV/GpU9fi3Y4xrblZfCEXEsCTzkrjzm8sy121pui0H60LVibvqqIMKiH9gQsaZcxUJEH6rbVaHVjDsEgw631sMLH7rkMp+qdeMfJbwCYMGomeO0xL8bPvO4H8B+v/jvQUbvArMXcolQImdOfONCv2xbNOlAPBoAOedl1OgXeSUGYIVjOW4Nm7dSjn0wtgFZMPDPciowHQihrqhpgbbIHH7vvWvziS7/dnCmfUiGaKmWZJNBtCTPsE2jLyb1QrJDBwmUbW/0hjYOwkvu6A54Fy9STnrNmU1oL1q9MVwTpjKzI9YL7Q8m453+EbDnDzsnLqjIepLZtzZ51zVDKnrpoFVtFKgLt1Dqn9bU1TickwwRFMZuPLM8Nh/nv1nLG2pIWQ5zaK2nuV+hc6qZMNQ3ntk3cfHICxGVkH2/afRqB8CzunFI5dmJ7cHYzKb2m1pFoblMfT/cOFIHVaf+F513lofssF5WYrpP1KSshTfo8fuZBrpNMgG22H8yYmJOf2AO6idFR0AR85em78cGvfQbXPX4zaH4OarAIhgJXDCgdKwFCdJETypQ0UehTxAK8CGAotGsHcfhgC37l/PfhX5z6egxpgEabM41VVQNQuOb5u/A3d16KJ5qnsLK8BLaHTRjA1J4SHwoYKRSmLi3Gyu9IcJo7jOZe2cAnZR2g5nkAdA1tDtRQjLYCJtxifbyGSgPH1Dtw3vYz8YZdL8VJK8dCUeX5RlcKr/vwL+G29aeBlWW0rd2bavcREzsXMdvzk00+/wEDBgZzQ5PEKl7+YAzx9SF2QpQkX4agyOB+tLDjFCNp1ULehwH0w2gBkYiM0tJMcPzc4bjx/b+JIRQae8hJZT+O4PZpynHx5XfkZzLHCvJhVu9daEEXZLNGSQKMRddyOpcLQFoCWz8eQHaW5mSFlPFBrsoy8rjSLTvbovgVEdbW1rC+voG6Nh5eZ9HKs5NdW6N7W1DNyYQDYE+UsS5lzcF9nLoGc27gQsM6oJcRT/4Zd9PEQpwBDhMmdbd26itoX0jTiDooqi+QlRXXfa6UHJAlFnJah3OFeP6M0kQ6o3/jIyuTtpSAtkRbpMEWLP/wTdwCWFJSa6HtXa0+k66DUqngk/lFMsT3Hf4UQsGsXxqQYjAqZdZl7jnwNH792s/i0/deiZbGqLfsADUAdAsobawhC5hs1xSdvA/GiAUmcgRaPuGQyJ9p3IxQrY3x3adcgA++7jvxooWjwTzGpNmAqipUaoAnJ3vwt3dfgauevgn1EmFpsADdBDAJM4SD4iz4UYIvi9TheE+hiXtA9QT7YwqNIgxzTKTSmOgGB1dH2KLn8ZbtZ+GcXafi7B0vwY5qBZX5mgHuX30ccxhi13ArFqtF/MHbfgzf+aFfxWRpyXgS/NYdOz4OaLX20cbmY/MAWKMdNyClfLQziKCtJWKUBrbbhwIzOA4K88y03w2PB1wLsoH9ktlPPhfcpw5dKjU3j0f3PIavPH0X3nrUWaZcFfNf9uoKSVNHx6Mj03RlpHncL/PStUpXliw9my+xcHOyIkpPidqQodE/lzI3tWhT8E7qkecZRHwtHyLul6JAR+ifIFLYeFLW18GaoSpCTobK3x4LvBvZUc5AqnE4y9KD7SasOoKfvygpFKUGglIIimDFd1Knr6TM2Qy9ROjWOC1LPkgsdc/2ReylT+XAZNNYAeC1NwqPIq1YgFif+yd9F+RKqIPTd7KqWS39WdKkkzVr/RdGKAey6NHC7eW/ymM7sSICqQpPj/bhP9/yBfzZrZdiY+15VEvbUdEyuAF0ZejyH2r3MsKH9IRx8c+CACELzubrORru9CR98ACOWTkSf/Se78d3HHuOOXO3WQWRQl0P0YDxmSevxT/cexn2YT+WtyyZgCzNgGLYTwAIIcHhG+3+uXMvO3riielPxmGILSumsdrzHvsvAjXtBKsbG9CtxnH1Drxj13l447Evw0kLu4xXABoPrz+Na568G3ceeAz3PH03vuvk1+GHT30X9qwewBsOewl+6JXvxl/fejHqndvAbQOG4Uvn4iUN840GAcSuz/W4haqBaqhAZA4XAQ3M+LiPvVseIi+QhLIWDY59yHGf+BzSze3+OiWJbF3KzikF6PkK/+eur+CtR52FgTLnJZOlRRoXOQszGB0zSKRU8ZXPc9ZuAVA7cTepBzBVoGWe3NwVNE1rhevj4mwt9EMs+wXodfoiZIg8XNQjHxO6mc3xq0opq8C6eW6UxFSZSnre5HdzKARHBcBlzVDKVtADGhL4Uu0la2n6dKIIYca5L5lIt07I1WlGgabUEQPfrqxmFjfHl1GqeTOu6A5DE8WWc4nhJf2ZSZVdd0Xc3mmAkwaYeS1ySvvk+c8p0/fllEKv1K6INk9YnnZHuJxA2YAomc++C9t6gFoprOsx/vftV+IPbrwIz+57DLRlC6qVHVBNZazeysTEupgmcsxpmdk8dyvr8JPZvKZQufWVEgiYbGBurPFjL3snfu4134HDB9vAegON1qjrIYhq3L/xNP78ts/jhj13YGnLPJawDN0ApLSx6qDh1jN9FbaHtbduNUSv+z4wulugjVz/CZD22/SUWc9eHW1gfWOCI6oteOvOM3HOkWfgrB0nYcdgC8CMCU9w654H8fknbsY1z38DB6tVDDHEwkqF29cfxgYmGA4qrE7W8duv+x5cce+NePzAHvDiPNq2sTxE/txlarXf22qcPmwPw2Bj+a+NsKVdxsqWHdgzOYDR8gBMGkyVPwlSzBTPc8zsLVhXOGv2U8Cndx0m55hTtgjiw7/mr9YaNL+ISx+8HY+c/zxOnj8MWrBKYJvAvxD1dd2dRSkXaJK87gAnZw1KRTojd7wMSKvJ1NtZc7Xly0hhM92TPhfvI9ksCysBrATwnAxKPJTuWSS7I25wvB4UoCB0kvaRiZhvmgYuIhk24txFnkuDUQZwMgBaW11lBot9taFTmrbF/Nxc/OGBkgrSpS1o99xNk3alBNvyCCT1RckSwZG5SuD0zVx96xylOjvrt+ZhSOfyhkJ6J0CpL3MBCDMpCbMqEhKkC7T48mTbM7SVaXF1IbICshr5FKBluM/eOWWCraaq8YXHbsGvXPcZ3PnULaClFSg1DwKgW21OLNLwJxu5oAmyiiH8RBV0WknjPo1nt2KabiA2QUirG3jliafhT87/XrzmsNMA1pg0ayBVQ6kB1niMj93/VfzjA1dgPNzAwuISuLH1kwEbU41VhhEUHecwDkFREOPKgu1cjwXLywkgEJnzJhRhbTzC6voGtuhFnL3teJx/1Jl41VGnYke9BYoqaGZs6BG+uvtufOaBr+LWPXdjNNdgZX4ZQzVnDr5SBL3R4kdOfRvef9ybMJ6MsXW4hMuevgvf/Re/jsnR29DaAzQYAGlG1bJ13WtjqSuAlQnGIs04evlofOCU8/CBM16HE7bvwvd85k9wxb77gC32E6AVvPwh6/Y3ZrEdN7ZKk3cB5ICNoj9wgtaCKyuZhkDaAEqzZy9++fz34zfOfq897lZ1BH1RCnHnxiFX8iwVhGXltXjJ+ZmUG0X5Tikz+zYjD3Oyd1Z5ME1uy97pNRBd+uQ41wjMO2ALrK6adVsTMGVnX8/3bqMo5dVDh9gokNoT6BreNA2WlpYwNzeHTN2hdWkjTUGCSCoywdSFdwHu0r3Cou7Omu8s1yaYUrpLIj1gBvCe2r5cfUj6sNg33UnSAV6ZfLP1ps8LEzsX/GBeSxDKTLCEPifsjRDsaFP2j7AGIhrjSROldXYEW9exPee7UgpPru3GL1z7UXzyzq+ima9A9ZJZY2xba8mZr8zE/Rxr7lZKR9a1FL5O8/bRimsHsH1uBb984Xfih099M7aqRehmAoY5QlGD8OXnvoG/ufMKPDR6Alu3zAON2RLEBBAxnAJOkhr2Z1aJHpCgG/elIU8EPdlJpZQyrlBorG5sYGNjjFPnj8Jbjj8H5x55Bo5d2AmFyiovLQ41a7jy6TvxmQevxi377sVgWWGxXsIAQ6DRUAqgClCDGgqEreN5/My5H8CZ88djtL6GLUtb8JvXfAJ/cOlfg044Gryxaj8pyFBMUPZIRNYN2tEaKgZOP+Ik/Pgr3453vfg1OGK41RyLqAjXPnEf3vr3vwo65VjodgO6orBnmZX/iAPc+cnut7By466iwGsSbEHhrBIYpcTbV7a8ZjTCrvow3P/9v4OhGx/BIiHYLDM0HFfrZWuC+9krkVOBbKmYFo5c9e3r1iPje+LkYlZQd3kt5r1+HOi+i/k2bTcDM8lW6rSXIuU8d+XUrvF4ggMHDvhv3PpTpUgETFFctg+gOnToEEO40xzouu/XbtmyBXVVh6oz0tyhdzQYEojiVk/tGNFaqWpBOihnAY6p6SxYpUwi381SZglQZ9GsptE2a5ppYDub3ijKBTxQhMK69FBCZ1RPlFdSE/NIp48cT3U62nJhEWjFWrUVmuzIdvOMjDK5e7IP//nWS/E/b7kcq/ogML8ERm2/SKMDP1ufH3vtLiZKMQByYtZaZC4tGYB0GjCPVjHXML7r9HPxK+e9Fy9ZOQHgFi1rKKrARHhs9Cz+4vYv4Kpnb8HCVoVhtQA9sbSQVF5cP5n2u3VM125HC4u/rsvJdgoBIA5gqyoTyDSajLC2vo4VLOJVh5+KbzvxXJyz88WYxxDaAmyDBg+sP4NLHrkOX378Fjxy8BkMFhXmF+ahuAI1drsEmUAlVZkoXFVVQKtx8vwR+ImX/SB2qRXQeAI1HODbP/Yfcf3j30C9shW8MQIrBU2MtlkFjxrsWtmJ1x99Bn74zDfiwuPPxFANLQib7YmVUhhUNb7vk7+PS5+7E+rInRhPNsDKnQ9glB1oBsmzlN33dJkzI2xOsnL95d9JwPWD4piP7TGVBLX7EP7uu34K7zvmHHPEpB1DRcrECKAbL+LkbG72937bXdTvyxGk9W3B6ZPRqQzp27IzTc5IkR4pETk5Izsi1bETedKpp8/jGMnNzYGt1hp79+4z+9At0AbApQC2sm5l59rBgwfZESf/0/abjFu3brWZwhpqdJVoTRL6gS+4W+MiM4UKMKfY3PVPYpU0ASLJQFlXUUp+RlmQvv8M/SUmdPe5KOXORMtYg/nJaAVAj1YKly7Nm6HPvZta3pSrk9pqkamhmiVKygJhUcRjkS9IBvW5IiOXnW3HarOKv73jq/iDmy/B4wefBK0sg9Sc+WoPuKsg+DET7fED4hS1dO3PJCAiEw07maBaX8frTzobv3L+d+KCXWeCQNBtAyIFUjU29AY+9eDX8I8PXIUD9QEsLC6ANZlToIj9vl/hRPD1OzJZzE+23gETTSx6wikClgdrIlT2lKq10TqajRanLx+Pd5xwHi489izsHOzw3aG5xRpv4Ko9d+NT93wVNz9/Dw6OD2Lr0gJqGgJkDpkgAqo6aP5VpawL3fCBUgQaa7z6sNPwL0//btBkgq2DeTwy2Y+3/fnPYd94DYQK7fo6BtUA573kbHzHSa/Bu1/8Khy3cBgICq1u0bbGEwCYoyArUhiqGnvW9uO8v/op7NmxhGZIaMDQbruNB1sLstqNWRIfYBUSls8oehnxtDxOEmyX5QDQ2gZevetUXPGdv+C/pEYwYJtuA3LsE8bJ1R3KjnYdIJnDAkw4ohe9ynvWWOjxqvV66wTQvzBDQ3ZCqN9LfKfNRmdKZ2gT8sP/LhlriTbh13GjaNtw7d27F1pr1HUNAkFVdlOccCN7l7Q1HLxlGwDWiigG2rbBcDjE8vKM5yGnV8Y6kgPQC7bepZV2hpd44SFlgDatXxQxiwXbC5qinFzanDWbulNC4E8+iCulv5TGtTulqXNNcf9k60UA/LJiwl4oRSQUMkxTcNywUjxLIANGIletkEzM9ghCC5hhLZIBUphwi8/c93X8zo0X4c7n7wPm50GDBQMObCDJAEIs2Jx2HYGt7xyYSW9PCAqBfe49gzdWcdSWXfiN89+HHzrlQtQYApgAbL4dywC+tvdOfOjWy/DA6BEsbVmA4grcsnVNWgXYTV5wrPSJNTxnxYKdokE2QMomtd+RJRsZSwoYN2NsjEbYxiu48Igz8e6TzseZW18EBRWN6+5mPz756DW45N7rcO+Bx8B1g8WlISoMQC3ZQBGAalN2VVXW1WYjmxlmzdtaiaoiVE2NC446HR84/h1o2zF21tvw4ce+gp/+89/GMUcdjze++FV470suwBuOOQtDNQSgofXEgngNoMLzo/1YHCxiS71g9gJbkq999C6863O/ivGRu9AQoK0AhYZZU23Zu5KLCiYJXhNC33e9VLBgAZcBarU5p8Ba3Nizii/8yK/i3J0vgW7ZWEUg1Cr+9F6KM54cCCXSKnvxHLG/RDuycy2VdRzKLcqCjELuaOrSKLPG2yG9AjCrx84X3CPTCnK76ylL+odDEFe+bNO/JbA9eOAgxuMx6rqyyjIFC9dUGICWnFJgwda4jA2xzp3cNBMsLi5icWGh6A5No+ZI/pUdvFnriApHj4nOKFnUkWUYCswCVg6kc9t4pkUv9y3ul9Z73bOUvkzhRYaX5fo+R1eRSfvETxghVFKBw4K2PFk9GiTFaTpXBBZxw3JrstPWw11AjYu+BQAFF/wEfOWpO/Db11+Eqx6/CTw/BA0WzcfGme1h90EhJFE/W+CWfBJH15Mph6zg9ihLQHMIw3aAH37lW/CL57wLxw53gd3Xc5RCRRV2twfw59+4GJc//XUMlwjD4RzaMdsujycWg/0BGVKBdYNvHAjBdQ4Eo80uWZpjAllDo8XaZB0YE85eOgnvOuE1eNOxL8OWeqvNZ3IoIty9+gQ+8sCXceUjN+OZ0fOYnx9gfm6ItoX9wk4b3GdKmc/h1cZdW1UV6soEb1WkvCWonYVbVZhvhjhryzE4Z+sZeOWuU7BUzeHyB76Os456EV68dCwUCG3bgrVGVRsrGQQ8O96LLz/7Dfyv2z6BxXoeH3/bH2KZhhF//MVdX8RPX/nf0R59jDk0w3VGGyxbHxwFxCBLsNs55DqrCECzHc0symAzRtRqoLUKWl2jWTuEHzj9dfjzN/0r6EYbRYTInsgllfGuWEulRikOoig/Eo8aXH0FGSrjayIZkqaR9UpFpOitjOl36aP1XnF5moWsiAMkU6p6aJMyUub1dDMi9YVdm/JtWV1dw/ramrFsicz3lpU4ulEqGQJ469B4Fv8ZUuXXDWRjQp54HVVevdFlVjPLpZktYpZFh3TzZ6rLW4VT8uY0pKiMDJ19wQEdOiQQlwB3BkWlk6IwSYq9KgE9VZAKmqjcLtJRdz0oiHdekkjmz2vZURmS8ExXtKz99hbz7VD7PVUC7l99Gr917SfxifuuQtNMUC1uBWsF3bK1sCS4xuBlJamo3050J6isYPXJyOy3pEkDWl/HuSe/DP/x9d+Dc7aeDAJj0m5Y1+EADTQuefxqfOjuL+J57MXy9hXoRqNtzJpeYG32dSMak0QpRCALAKABc4qU1c4VoYHGwdEqeMw4vN6Gdx3xcrz7xHPx8q2ngCDPPDcg+5Xdd+DD91yBrz5zByb1BCsrc9i6sgV6wmhabSqxn8Dz1pa1WjWbNVpWQAsG1cp8zo/cQfyG6NX1Q1gfK7Q4BqcccySOqLYC0Hj/yW8AgzGZTMDKnJpFdYWDeh3XPnMrLn3selyz++t4lp/BYNsWHDy0Dz96/a/gI+f+ITQzRs0Ymhg/ctqbsdFq/NJX/jdoxw7oQWWjmGE8B9oqMa7hVpEhv0fX/cd+KALImsd+6cEeKQnN5mtETkS1LWhxARffezOePO95HL9wGLwAtsyWtVaZk6WXONzPpeko6r2WY3C9FoG2A+/l6ZfSEZNR2MMvfpeojOVPnNABroTo4IHKiI3U+MoYER3JO0Xk1nUdlHFHU49HE7CetgMHDjDA0Sf13Cf2tm5zwVH5i4HIIqKYV0IaMcJxmmmg2k0z1fJEooUJWmW+MMGmg1lUv83Tob3PEkwBuPC+k1+2S6aZwc3Sae+UdkrwlNNNWriyhI4+mpk93XLyCkXolww/pMAiJpaGOU7UbeWpKoWaFPY3q/jTmy7Cf7n1Yuxfew7V0uFQbQVmgq4AXQW+NLI0eFLMntJATYS3km844LPJ0EIf2oedC0fgt9/4A/jAi89DTUO07QY0E+q6QqUq3H7wIXzozstw4567sLjFuD6ZCeYj9K7gULGR/ypUw64XhfJik0vLHlYBGbUT7Ftfwzbegrcf/wqcd+RpOGPb8dhZ70AFZdtrwmoP8QYuevQGfO7Ba/D13feiXlJm2x8ptM0E0nqDOwyEg+BTikAVAcq41lRlLbfafthAEdrJBKPRGCuTIc7ZcSbe++LX4RXLJwMgaN2i1S0AhqIKFdVo0OK21ftx0f1X4WtP3YAH1h8GzQPD4RCD4RDcEFQ9xOpz+/B9p78Vv332z2DUTMBaY1jVmK8GuOjRm/AjX/gzHBxugBeXgFYDjfaBUZ4rlQJV1n1utDZnR4VBt4CqNdtgOhNsxXYdmK1rmtkdm6xAAwU6cBC/eeF349+/8v1GGbFeF6e/+cAaz2+Bzw3fp9Mrfh9ds8g0soUiBvrOspjjsFQOZ+pKZc40AlJDzcuByLoObJ5KjyCbYqUY1BVHiWoqK4V8FQUS5rqRgVa32Ltvn1HuKxskRYZ3CE6uJFuAHNi6iD5nXrdtCyKFbdu3FsQjAhOy7PjwJwe2nbW4xNXZBwjT9mf15c1pOuFlP2PK9dWeRFPLIUdrDxgXaXJAN4Ny4l0jOddRT570uDNP19R2pSKA4/7uFNopIConBdx4O41pT3ryk4l4VRjxBH939xX4/es+g8d3Pwi1Yzug56C5MoqkUsZypNAsghGIiajwmmvYzkFWsJrXrIxQICbw6CAW9AD/4hVvw8+++t04vN4K5jFggygUDfD45Dl89P6rcNnj1wHzLebqBWitTWBWrezYuhpjrVu65o2xRZYV7F/nRieGVoxxO8GhtREGbY2TFg7Htx37CrzluFdg13AH3N5c0+oBGIQ715/Epx+4Bpc+egOeHD+H5aUh5geL1mDTYMVGGWCIjwKEL9mQBWtSZA6RUGT251YKlf0Y/Gg0Rt0ovGT+OLz5iFfgDce8HEfObUfDLVrdGDdxVXvF4unJ87j4oa/hkvu/gjv23471ahXLK8sY1nPe/QoyY8CqQlVXePbpZ/Hjr/g+/PpLfhLMjKaZ+G1bD609g1+89h/xxQeuRzskoB4GC9Z0nlE6FMxH7CtlvkJECoAGtQ24baHX1qGqeXA9ALVmWYDa1h8piWg8ACKzbs00wouqnbjph/8Qc9XQjJ1JBWXPn+6ArZw3WcFfmFSbNCCirM4bkhZdkFFpTV4tmUVWRfmFNpGCbSIj3Iug6wp6C23PPpXWs//DXo8pdiMDe/eZIKlKVeZTe8oCLglwtXUosiG9+/fvZwdCLlqubRqoSmHbtm39QjohMgXTkCB9TkhHs7Q+OuugpWSla5AdwHSuTD+ShXXOnLnu6pDlZyzSTVm/olxPb0K/1Pg672S5PX1WHM9M22NaxZiV1EaObsWGcRaadAKoqV4BRPMmAL+TYxZsdQuAUCsDlBc9ciM+eN2ncftjtwIrW1DTApQFC10RtEqjR+G1ZRIcHDXC86ohhJyrkAhaKfB4HfWkwXtffD5+7bz34NRtx6PRGpPJBkhVqKsBxrSOTzx0NT7z4FexrzqIhYV5kFZoJ9ruGwJAHJZ8O2ALwK/tWWtIOY3fHhWIFswao2aM0foExw534g1HvBSvPfYsHL9wBJbUAqwfwAQxUYU97Sq+8uxduOT+G3Hb7nswojGWVhbBqrIg23pL2yt6GgDLL/AYQWK/2mCAUgGqJqgK5tN8kwaHVdtx4baX4t0nXoAztx1vz0oGJu0EYz3x5RCA2w7eh0/cdSkueujLeJKew8LcACtzJmiMwIAygViorXBWBA0yxzNWCvse34sfOes78Htn/zwYjPXJhtlapSqAgK88fiv+222X46qHbsc6jdASgwZDQFVQgwpU10YWgMHcgscM0hPUTNhRr+Cso07Go/uex0P7ngMGCrptQdDgVvsPQbj5YaxRo4ioAQHPHsDfvu+n8L5TX49J09ptQ2y3Aak4WMpNovQiEXFulc2Ou7ZkhUpAE1ZcJBsFiMr14VIMRyf4KUN6GUNE4GHqDhflBAwWykjURidfCvRFBUaUZV5x+jh77du3D82kQVXV3ro1QVIms1eeHA3OsjWHsLP/ZmXTthgOBti6ZUsMSLme8Lc5sPXGR8f6TRuZqyK37jnzNUUT88whOqTPGvT5XBpZtCy/D2hfoMbZVU36n89WaGatx9wI7RSxVYUwnmFQE+aOBj5/yR6cZZN++FAAew+HsgLx6mfvwgev/RSufvBW6BpQc8sAKnDrY5PhtuCkI+dcyMZcteNm13IdQUqrcNiBIjAr8GQEdWgN5xx/Fn73wu/Ga48+HZqBphlBwZxlzMT48u5b8OG7LsXj7TMYzNdQVJsToOCUdxZ84iS0WM92Xc8qBOvAbJ0xf4G1yQjjZozlZgFnbT0RFx75Mpx/5BlYqZZN+Wjt2b3ACA1uOvggLn7wOlz3xJ14duN5DOcqzM/Pg2hgt6vYqGIjYY1rFPbIRmvVuy4kq7ErspGYlQKTxkazjqEe4mXbXoy3H/tqXHDkWdihlkEgVEQGbG08yFhP8PDG0/j8I1fj4ge+hDufvwvNcISFlUWoagAaGZ1EkXFRUwVjfVYWYC2oaXtkV11V2PfU8zj3+HPwH8/79zhR7QJrYDwZQRODqALAeHD/k7j5+Ydw9ZP34JGDz+OZg/uwQSMcHI+wMBhiy3AJR207HEcuHY4zdh6D07YfgdO2HIkT53fhyufuw/s+9BsYryyBJxOrBIovLXn+IQ+gqqqgN9bxxiNOx0Xf+2vQmu3n9/JfA0pY1U+SF7T0Jhk+FUsOcCXYzuhBS2UiMrIxKrtLaLgV5RW3SfaBraArT26pXbG8KkUgp9fBgwcxGo0M2NpvGSv7n7sPdopwI2u7RusAt20azM8vYGVlORDqSUu0gZxU7TwSg+BltwSlQFjfmmxuAHLvI0D9FlyyxanVlxp56RUFSOXc4En+aF1XrBFKkC/riYGuWWA9Uj8Ek3kNrwOksi7PnVGCGGxFGSTzhooiKzbqW/ePsfq0bqERgPbe3Y/j9677DD5531cxrgEM5qBoCGoZTOZ7tDrDU5J2ggNbpzi45+TbQszWyWzWFHltFadsOx4ffO178f7TzwehxkYzwqRtQVWNgVK4d+0x/M0dX8TNB27H3PIQhAqN/eStATFpYQRntesyFvULE9xaZ4xGN9gYjTBoK7x82yl443GvxBlbj8ex84dBsTk6sdUtQAotNB6Z7MGVj92Cyx+9Cd/Y+yCaaoLFQY1hNQRr66ZWLjDI0WiJsYfc2EVhAOT5g5SCqk3iSTvBpGmwvVrBm456Od7zotfh1dtfAth+W29HYDDmqiEGaoC97X5c+eRN+OwDX8bXn7sNe8d7MLdEGKoaxJUJFmM2H+0R7mkHtCGIyZDn9iEzM1StcGjPGrZU2/ETr/wh/Mhx346KK4zaCSbNBFVVYaBq64423KDRYKwbrDUjLNZDLNYLGNJcxDdat5joBlAK7/j7X8PVTz8INTcEtwFk/TGdZPhOMQUrp1IY7F/Dl//5f8BZh52E8aQBKeqCretqxPOhFFSaXjljIQ1JlJG908pJy/LGBcclZOvNLP91QNqVN+WSUi3yQvrvdtvSsx9KjwiFACI4JbeT3LbRTwdxra6tYn113e8nJwpLAQZ8XT8IbDtwYD8bLUuCbYuVlWUszM93OmLzYMvRXX7dFQJsTS25wKgS2OaubzXgekJjojaRtcuI7jnFje/VLLNbm+Dk4Gwg6y4q/AjWazk9pzceU0XPd/y25nnfmLjI4riskO/J1b34z9dchL+4/XKs6QNQy1sBGsCvrdu1RCP0bFmpNi+FCNt/3Mk+bAQk2XFhMmtYen0Vh6/swi+95jvwo2e9EUOah+bWLLkMagCEZ5u9+Ovbv4Arn74RtNRgbm4OHOKKOm3xbRR9E8AMFkzM+qfWjPVmA9RWOGlhF87Z/mK87thX4LTl40E20MkJBWZgb7uKLz9zJ77wwHW4+Zl78Ox4P+YXK8zVcyZ9a7YYmUAm6wK2wObVPVsYM0yErSOzMgJtrEdYnYyxTPM4c+VEvOPE8/DWY1+BYwe7unODgXXewE377sZFD3wZX3rsajw+fhI0T1io51FxbRSlNliIvl+Maev7AsoKMHF6k/bVmD5URNBjwuredZy241T8y7Pei7cddQHmaeDbx6zBLdtv9apwxi2sImZ71IAxQKTQMqNSCh+791r86Md+H7x9C7gNa+YGaIMiUJE5+tIFSvH+/fiJV74bf/CGf4GJPdDeWETKKBZ+qSX8W7pcDEhuXmblg7QSRdvclW657APblLI+eCvKa2kJT5NdhOgcY0Omze8PlcF0mZwDWt/gQgMy12g0xsGDB6GU4Rv4MXSuZPL7bw1ZBNq3bx8DiC3btsHWrVuNsJAdxXF7/IeZo4Z4keEpZ/+OZm6MyfJNHHdoCc1qUVGSHPiXmdwI9LgjNgPofdHVabpZXTs567jjnnTvSvk7SoB7I8p14zdzgzmZhSZ/aUK7GmVwiNlOorDabODPbrwc/+nrn8Geg0+Ctm4DVXMZd31cEsS/LN+5IbST1nc1GxmubDo9XsM8zeNHX/ZW/OJ578Fh8zvAYLTNBGyDI9Z4hI/cfzkufvxrOEj7sbC4CD0JCgPB6QCcWANWrKuw/QMMuwYEMLfYaMdoJy12YBvefNQr8YajX4azt58AhTlo1mjaBhrmG7wNGtyy/yFc9sjNuPKRm/HA2pOA0lgezoO48uDpvvPqMcEJBS8cLF9ru7TkrDVmtJjg0HgVumGcseU4fNvR5+DNJ7wKZ6ycgAHmAlDZIxJbtLj54D24/KFr8dUnvo479t+HZjjC4sIQigZoxwy0Zqz8oSJOOfFg61iHYtB14Iag15kxNl/eUZqgdI2NZoz1g6s4eeuJePuL3oDXH/tqvHjpWGyrV1ChsodhUCSiFCm//qYZaLkFmP0e5JEe4w1/8bO4c2MPaDBn+8mAH7u+VDa8zSozpAhoxjhML+HmH/1j7KgXoLXzqKfLOuK+TwQm66Rmmk2XmV1voFdBRNFuknSNLFl3wLmyLPN1RJpBKL8rKgJIdeiRlSYPercbFQweSc+0tjgKJ5MJ9u3b5w9ucRatiypXyi39WKB1YMuwwVFsNrQ3TYPt27Z5sJXUO5kJOAYXw1AABPl0VgA1BkeC7p0mh3f9+3qtwJsCdLO4aGRbnUa22SunkXqlQJQflb2JtRQA0TdtS+vFFOURylEGaE36zba1QK9wQTHb4wTFRFB2UhIIY27wsfu+ht/56qdw37P3mi/yzC0AbCOL7QYLJ2Tjqcbd9iQgTzooUJ6fFKCbVdRa4R0veTV+7TXfhZcfdhIIBN00ZnsIFA7pDXzsoavwqcevwl7ajeWleVBTAY1rC8L3boXuwxT6mdnssVbWRapbA7CsCUcNt+OMlePx6sNPx2t2nY7DBjvtGqAr0ERK7dVr+PQjV+NzD1yDb+x9ECOaYH5ugKGqgQbG8uJAk//YuRMCKt6Mb1Zo2VsPmjX2jw9hPJlg12Ab3nTsWXjXiefh/J1nYkBzXkybqNoBWrS47dD9uPyx63HFI1fj7kP3YaI2sLQ4j9q6iXliQKvV7vStgiCl8Jec21j8xz5N+AhDsMYZ1MJucVIYTUY4tHEIlaqxq96Jk7adgONWjsUph78IR8/vwrb5JUzaMdaadRxqRlhtN7DabuCxA0/hiOFW/MxZ/xzEhFZr1KTwxzd8Fr9x+V8C27ZD68awtVVeoBRgA2dQW7AFzKlgzzyP//Xen8U/e/HrPW862g0vZmYaJX+jqcVJn/XP09SCLV4F8IlISMF+M/IwI8/S+mYCWzslvLowi3WbTRMbJlHhydU0Dfbs2YuqUtEZyUCYS25rof9O9L69+9gt1LuPEDRNg507dmAwGCQNDGgbdT3105/TlnqjjjmsMER2QE+eacFUHY0vw0jT1oRdPtG0QKt3z+R5uPTc04aYeVPGncrEM7iebUGiXglNOcZ37hny6X06OfmzVacvQgCdxx3bd5rNGquxKAiVqqBZ49JHb8Jvf/mTuOGJb0DP11CLW82HxJ2wBcCkDfB2Jgoj3n/HAaMkWdpAi8UgcDMCRiOce9JL8RsXvh+vO/oM1KjAurUCv8aEG3zq4a/io/dfhqdoNxZWFswH4VszEZSc/Gz7mU0PuLrd+jMUwFpjo93AZDLBTlrBqw47HW846mV4xa6XYHu1DWBlz8zXdnsBgaFx64GHcNED1+NLT9yEhw49geHSELUagLiCdttRoMH24AkPpQQDtHa7AioyRpkNvDKyQaOZTHBofRXzPMRrd52Gt7/4PJy363QcUe20vGCsPaUGAAiPTXbjC49ci0sf/ipu2XMnRvUa5uZqo7S3tg4Hrpa/tDzmymjECRuFzowsIwJir6LRbDx4aTu21uBkv6e2MmdO6wajdowNHpm1/QYYVEM0GEOTiWGhqoLiGuPBGMNDQ1z1A3+Lk+aPQ9ua7WbPrh/Aef/tJ/DsnAFU5YRgRUBVmX5VCqhhzVdz6Io+cAivOfIMfOV9vwHFQuG0zGHtI9/WDvQGjT/iZTfGUQ9GCju8K7Yz37NzuAC2QvFPo5RTAO7Lm9YrRE02f1G2R3p0jn+SelMjruSpLBhpANC2LZ7fsycEB1ovRlUZj45SIbrcAW9t2kd2M7x1v5BCVVXdShzjM2IXMmf6KNMvAZBjBnA0hMG1v7JanCuLO79do4rReJaAXN5c+Q6gO6CegpdblKPgPN8M4PpnnGWX/msGb8ILuYLm2w/IxUplVJ/EQdtfcq8swbpuLaNeu/tu/M6VH8GV912PZqChduwEtbVxxaoAGr4qaTYCPv6I3T8U9ssq5vCFHIPuAMw2HmyMcNrhJ+GXz38vvv3UczGgAdA2aNFCqQpjNLj06Rvw9/d9AQ9uPIKl5XkstgvQY8CcqEQAabuNx/GC8pR5V7ECGBqjSYON9QlW6kW8ZssZeMPRZ+Ocw0/FUcMjYE51YrDWIGJ7VnGFfe1BXPLoDfj0fV/FjfvuxUbdYGlhiOVtS9ANTBQ2t2asbEPdljEXtGOUBtN+7b6JqwhcaWitcWhjA3qkcfLi0fjnZ7wD7zzh1Thl6RizDooGJvK2ArjG881eXPX0zbj0getwzbM34/n2GSwuL2B+ywLmsQVoNXjEgDy0w/JSsOocy2QkLQeeiR5bnmI3zl6Z8tqMOc2JAVjXrz9ZiwiqYizUAyyqIfy5VsRgNQ/Y7xczCLoFJgPC/vU9+PiDn8fPn/FjABn+3bWwBW8447X4yO1XQG1bhprYc7aJoCsrD1xkN4W1Xywv4OYn7sGt+x7FK7YdbyKTYRROBSqfJuc6pBTCT+Kc+JxyzrGETbfgpQFYfbO9BOg5mdm55HgmUJCVj4mBllt6KtaDbjelNEvQ5czvnFOxqsxXphxdzn0MwG9jc5jm+LT2MjXVVJAfM2/c2oGT4CnX2vzTTk+IDvCNcvI47u40/7R1VweQkebl8jkGnsVVnJSXSZC1qmWH+fY5d2lP3W6Ac66absJod1xMVsEtQ6Jby5M4qQbUna9+eMU2rwhgCwUSPNjBavFyK0+tKlRK4cFDz+K3rvo4PnbbZWjqFtXOXaAJgycIwTAQ3UhO2lrJ6xmGol5iKNs3YsyUtTqaCWjtEM7Ydjx+6s3vxntOPw9L9TLAGqxb+7EAjS89eys+dM/ncfvaA1jaMo/FxWXwxFpmCiY4Rsf9b+aKNoBrrdhJO8FofQN1q3DS4jF40ymvxgVHvxTHzx+OmmqrSWswa5AagKjGOm/gxufvweWP3IIvPnw9npjsxnBhDnPbFlGx2Z4zadroQ/bsFEC7gTeE/Th+NNHErABGi43JGONDG9iiF/Duo16Bb3/R+Tj36LOwqBZNb/LEK9h79D58+ZlbcMUjN+HqR27FM+vPop4nLC3OY6s6DMQMPWaAGj9E3rUr2STSkSg/PaIDC2J+YwEe6ZZud8AEO63KCS5ytFjXOhtuodA9/jnYbCnSrcb88hz+/uaL8aMv/l5sr1fMIUAK+NfnvB0fvelSUw5RdH61OzyFfeFGbqiqxoQP4m9u/zJeccEPm73gNpjPu0DlXIraHVRNaf1GbuGCF8zIM5s/2eKSg/dcEJUrJyQSMmsayJrMJo9YSollfqwESC9jyaBKoyDiNnRpjryEEisSwykuJW1XDPwmcp58XuO1Y7N2b3nCzW5Hta9f/k0vKWxZ/JvSk9c/qJDArbeIts0AjHkCI6q6FOSYInUpIBmUUr6kDBL3ORo6pObq6RbbmWzdggo1CTnTd8kqugwbK1PpxOy49JNSnHhv2AaY2KSVDRp5YrIPf/L1i/GXN3wBa2u7UW3diYrmwOMWLdzRdiyEoNNArZWqEoEMht/Ow+ajBH6XbUVAZT4OTwf34vjFXfilt/4g3nfWhRiqBTC3aJsx6moAKOD6vXfhw/dejq/vvR31coWtW1YM+LO2ez6NA1w5xnWgQrBuJEKjx9gYTwANHDfchdccfT4uPOqlOHPbizBHc2arTttA0xg1VVBUoaEWtx+8F5+9/2pc9fQ3cP/Bp9DWDRaWFrBQLYMnQDNp4b9x631pfhOM7w8V9ZntFiKMJhtYHa1jWc3hlVtPwbtPPx+vP+ZlOHbxcC/0tFWO1jDBtXtvx6fvvQJfefRmPH3wGVTzjKXFBSwvzoNY2SMMDcDCBjezV0A4FTPJjwL/snwTQXUAWiDi/1ivcmdaq+BscZ4OCvm9asayDMNzqgXmqjk8ve8JXPzApfjAS97nXe2vPvJFeOlxp+Ab+x4Dzc8behUZV7JS5p7JLDMwQzFAEwbml/CRu6/DL5/3PmxXc2g5KEFwrexZOsrN0ezJT75PMsI5EsVhbicxyhYiOJZvvpPQfd6pPCHYCyQhddwfikd7ajs8ldnEXnmZxcgwCbuyrVC0AVXrPXFKpeuraF3c9k8deI6DJdcjnCMrTqSK8ECiZkCfTn9DMpbPyn4cnCvOZ8gNalYT6VSUa0gMrBmA3sxiv7OmI3pTUmy9OW2rU6fnQY76ytBKmQHK0xopsHHRsdWQK07QMO1K17XTw8E1G5eo1sbdWpHCgWYNH7r5CvyXWy7B43ueAC0vo9p6pDkgnhuwDQuOv8cagmDCZ2T8S9lMOKtFOfqYzBaW1QPYNdyGf3f+D+Bfv/qdWJnbgknbYNxM7NFrCjfsvQt/f99l+PruuzDcWmNx6xLQABgZ8PYfCrLjrltzq+yXbzRrrLcjTCYTbFcrePXWM/Dm48/Dqw47GdvUCggmzWQyhlYERcaF/vRkLy55+AZcfN91+Mb++9BWDeaX57CwZQCoebAG9MR9ace1Ed5SM/ck9sIEDdt8F7fF+toauCGctf1EvOuU1+KtJ56Hk5ePQAVjxbv/NvQEdxx6CJc8dg2ueOB63L3vATTVGCuLc9ixfQWkFfTEfpSALE2u83Uishmx9RVd3edSnnD2aTp/JI8U6hAC0ckYCdQdPDKMa2gfaQznF/G3t1yE73/xe1Aps8w2UDV+7NXvxE9/8r+Al5fMOnll5md6RoVZswao1SBVY+/+Z/CJB67Bj73kzeBJG6KXCUKecV6EFdYTQ674bxE0kBxGBHQtZku7i7HwOIkw3qnCQ+TVW3iXhqPQi15BO3WpCTZXv/yRiknHBs1Z4aIv2IMdZfPklxhdvRTmnTM4KHyUwPWJj+fZu3cvuy0/WpsgKVUpHLZzR6eSbq2BRrLQHtBcdETaAdkH9rH4OHI04frAtuB+zfModRgjrSuXJypzE3llntI2IxlcldPcO/RE6WLNEMj8FGMxHTYLF8vbngAyuEnp3IZ2yrnzCImw3o7w97d8Bf/ppovw0O4HQUvLoHoB/oxiClZY9Nk4q1jJeUqeOPauZgIZC8KxhqrMJFg/gMMXduLHX/4W/KuXfxt2LRxmLDdtPuLOAO5efQz/5/aL8JVnbsTcNsLi3BJ0Q37ZL7ictLdEHMhoaIyaEdYnIyzxIl6+/cV441GvxKt2nYYj6x0wgVwa0Nocz2c/8jHiBrfueQD/8I3LcNmjN2F3sxcLK0MsLsyZU6esXuEih73i6mUYx9/T0wTN2na3CcoZjcfYmGxga72Ctx/zSnz3aW/Bqw87FUP7WTq25uCYx7h/9TFc8sjX8PmHrsGtz92DCW1guDiHxeE8qFXm83SsA+BTGAzPCpI9M0pdrJxzeNrh4zRjUPa74J1yeA+3U/d9WOqAGW/3V9uDVRRh7fmD+Nj3/iku2HUOtGYMqhr7Jxs467/+G+xZbIC6Mlu5vHVLMFojoGzAlgvKazfW8KLtJ+GOH/gduzYfto7MouaXPG1FmTtLmcne+LA0mAIjzVyP9KwRgo48yzXLDhEAkQztYk1yvn0krwJY5WR7niZTxL59+/13bUEw5ySTO8TErueKvdu1X7uw1XnhL/i/07AESb2LD908Tmh6V2RQC5DV2gRQy7OAixFtqaB3nc6cZ9is+poZoAyAyHeU5hX0iCZ4WkpXCuRRrTJbVKDIUwiWyLadELV/6r6zTIFlTToIPgm0ISiI0HCDz951PX776n/EXc/cCywvAlu3A7o2lhAZ89A3yWucgmZ5x+6BfaoduhpJSdqAN4/XsFQt4Mdf9d346XPfgcPndxp8ahsTjKIqPLbxLP7qjktw2RPXQi832HrkErgF2kmIEnV6PRHsRw0A5gbjdoz1yTrm2yHOXDoRrzv25XjFEafhtOXjUaGG5hbjdoxGmzN6azUEEeGZ0X586r6v4VMPfAW3Pn8fMNRYXp7HtnoFaAltw9DKbDVygU3eZSVkoOkC49IyFi2DKnPi0dpkA+16i5cvvQjvOev1ePsp5+L4xV0mCtm6ulpucc+hh/GPD16Byx+4Bg8cfBSr+hAWVhawtG0A4gVzlvOIATJf5YkEseMFiX3+o/YxgHYsL5YP8vNEhFBFGYJ1lBP7suDM5GB5E02uSEmUeK4AqAHj43dcgguPeJWPOt8xXMJ3nf16/PltnwMdvsVHzKfhku6gFZA510AP5/HQY/fjumfvwfm7TjNueFsoC3rMtBVPxBpm3FFBHjkB3wm24mTcouklv8PDUdfEPSjkT+IhlDSG/bVR9ZGcmLrFR5QXXSV8yrm6kyW9UlvSdnToz7mYI/61txbblPQtE1DHA2fuOwdiJ1fk38/wcqdVboA7i9tWcHU01KhFeW0j85xRALYCMHeeFbTELFMTxSQXrOvwjqOBn+nKyZB05sgB3+T1Qg4MIdFuqS36gCe4Mwgs01cKDbe46tFb8Vtf+xSufvhm8NwQtG0nwArM9qsyjh4KbcxZ9rIrwRZcmO0HvAHAWFxcA5PJQQy4xrtPew1++4Lvxxk7TzCF26MMVVXjydEe/PXdX8RFj16FZmEVS7uWzZeCJi3ItsspAMpavxqMcTvG2ngDC3qAkxePxoXHvxyvO+blOGnhaBDMB9Nb3ULrEUgpDKohqoqw1m7ga0/djM/edzUue+R6PNPuxvzKPJZ2zKNCBT0xH1lQlThfld3GKNOrzvfDMHNJM/wHEqAYo8kGDqyPsNjO4U27Xo7vPfdNeNtx52Cg5ny/HtKruOvQo7jyyZtx2SPX4ranbsekOoSF+UUMV4bYju3gVkNPGBoTOK9EAn32y0cImOqnWkYKITPX/UHCFiiyAiXKnXKEfZV5R+K9fOz6ykrCKF9KtlBQNQOD5UV8/qFr8OzoeRw5f5g58YoUfvJVb8eHbr4Ik8oxqM2XKPNGDrL/+lRbM/7bbZfhvLecaqKROSh3Zs85/L3rn+JZBUIm5oAl6ynrNF6gL6WJKE5WGqcObd0xTb1jQFfOeplQujYpvqYmj/X6rFLjpwGcLOROWoVk/QCm3Nol8Foi81SwdZn9YrbN65TFOJqXBGgEwJWTw3xP1Bck6uh+3i6yxIUV6zoiG/iUWKJh837UnEiDyfVAGhmXzRuVbyadpdJ2k00tNcZ0DcEW6vLFM8ZMRvdO5uykTctMckRXSemhkCfV9Fx7nAWrrSuSYQ9pIIU7dj+AX/vK3+Oiu69HOyDQ8hYQKnDLAIUvn8ABreszr0OwcDvZfb/MdlsHW/euBlj774tyswHVTvDG016L33z9+3HuEaehApkvtNg12WdGe/Hx+76MTz9yJfbWB7B0+BIG2GqCjriF1q0/XB9k1pvXJiM0kwbLmMOZS8fgvGNehlfuOg2nrRyHeRvoNNZjjJoxiIBhNYe6Vphwi5v33ocvPvB1XP7w9bjnwKNo6xaLy0vYRjuMJTTR0Nz605KM4kJgjt11RKaNmsOeSgKj5TH2ra+CV4GT547BPzvxFfjOs1+Pl215MRQqaDR4buMZfH3PfbjiqRvxtSduwUMHnsDG6BAWl+ewuDKEUrvQThpgzGaLDwEmCM19BScwZth/Hbv1Z7kCHwmFWYBMJofgN8eXCYxkvUeJ9PSPRb2U0OPb2Z3XzIxqMMDz+57HJ+/9Iv7NS3/IHOUJxmk7jsV5x5+Fr+2/B7S44L+gVtpWyMzmqMj5BVxy29fx6IW7cezcTjRa+6YpS6uUl85Y6ZwFABcI1iO7O+JVzmcnkDh63zEhLMgG2Y08uHLSd3kJ36HF/gjpOh7NmJwOzwgmSVSHqPzu5c0Dob8FvCjZe7J0NyZaayhl9sYrcs8VaO+ePWzWrTSYgaZpsbg4jy0rK53Gdq6IKQsDLTHAmyVJER0BH9hcAmB/QFEymIkVSeI5Z9rVXTsNaWR4t69PapHsNHkxWCmpEYBk6Bd0uELyPd/VErOXSOJduUDnfNE+KzKmE/G4MaNl910d9uuj7gsYj60+hf9y9Sfwl9dehkODNdBwO1CZIwb92io5ALEI487lJcBZSq5atoqgCTBhUKPFAfBsLOTJOmi9wRnHnY7/8Pr34y2nvMIcOM/2+D1S2Nus4qMPXImP3/9F7Kn2YmXrFlRVbdykzNDKrHW2ukXDLTY2JoDW2KW24PTtJ+GcHafinMNPxQlLR6PGAACgoMFta08OquAO2Xhk/Rl84cEbcMmD1+CW3fdgo1rDcGERC4N5kCYwm4AxqgLfUXq6E5TdCywGwa0DtYSN0QSrGxvY3izidUedhved+Xp82zGvwgDz0NzgybVHcfXjt+NLT38DX3vuNjxx8AmoirE0t4DhwHwkgdmsIzNzUKCFIi3nqOMeQXH0ImLnWCuLX6SarhtlFmnCy34Y5uhXAE1ZjC82kQlxNfZeyBoGoLVbmABXhI3JCKcMT8QV3/d/MDS7JzFQFa546Ba85+9+DXTc4dCTFqzMOi8D0JbZ3TeBWTMwbqFQQ+3Zj1//9g/g51/2PjS69TO/UoSKKm/8lNcvuzHEobmJfMkp1MKbECm5HKSQ6yuGUL5lP7qbgmfRPY3e5oyaHus2FzyaXun20U3ogLHELRkf4lpdXcWhQ6uoBzXIGhjh5CgKp7KRWLONLw+d092MTiu0uBPPMzsgJL9oEqOsn6qUsIqbQVP8+NHz1K0saY802QI4yzIz6TplRmsoQNR6KQHiBciIMaO1bi+zcnXEPdsNGik0wlct+lHmpbS+OE28jiLLDntltY0kqZRCpSrsGe/DH1/7afzZ9V/AgfW9UCtbUWEr0LYBaLXrFucmNcwQ9BUSgpJgtk64r8+4j3TbfaKaoccj0OoaTjzyBPz8O78LH3jp6zCkOQPAbD6rtr9dw8WPXIePP3ApHm2fxOL2JSyprWZdVDdwhxqM2wlWR+vAqMWu+a149bbT8JYTzsNLt52EYwY7MaQazIyJnmDcjsAAhlWNuhqCyHwA4Nqn7sBn7/kqvvTkzdjd7Mf84gBzW+Ywp5bAbQtu2Jx8RQxUgFvsNP1Nvs0mjEaDtJmw5jGD2wYbGyMMVxXOWDoObznzVfjB096MIxeOhOYGj64+iCsfvQVfeOIm3PD8Pdg72g0FwuL8ArYtb4GCMpHhEw2Q9gArhkJoOpKPUz5K5nOqTAoJK53PlOTzJUb8LgVmae6nTxzocJLGNsY3MICxjNb3y2IS9D0jOjnHGC4u4s6n78alj12P7zj+QnMsJAhvedHLcNjcDjy/3kANCK0EJefls8sdyga0UduCl+fxF1//Gv7N2d+OOSgfesAcTYruPE4UBP9aygNO+09EEMeTWvQXIZIMqXwjhj9SUsiZyCItyM2++BWXVo5+1BTHnIniH7NT5sWUpcJUYXQappmOZUXHxw7ZPuh6cl1Cw091AKLQAjfpA4BmiJYV2kZG/T6LdpEBiRTkZ9ZM0s4Qlq0D9Chd4oKeWl6e3O7lu1ECPBCjX2bwOOnegDbT6ytdHPdl+g5AvLldKE9RRLhtk4aNWrfuYoL5eDsTYXezH//j2ovw3792MfYfehZqeQeqLbvALQw4u72N/mB7AhQbN2llanJNJrdHVsF8Ao60CXhrDWOzMkCk1w4A6w1OOeoE/OTbvx0fOPsNWK4XDbHMUFTjQLuGzz1yLT75wGV4uH0Sw+1zWBpuASYtgBZMGqNmgvWNDaiGcPz8kXjXUa/FKw57Cc7eeTIOV9tQi9OcNtp1Q35VYVDPAWDsaQ7iqqe+gUvuvw7XPXEbnhs9D8wRFpcWsUVtMWclM4C2AYkPxjOsR8AKSqe0ie/32Chk48odNxOM1ibY2S7gzce+Et/3hrfjDYe/FBqMh9cewz/e/g/44kNmy9D+yT5U88B8NYeVhXkwK6A1B+pras1H2B0f+GAmWJD3I5+IaS+SxUP2gp4d/qZ87JkIae7kR8Zdl1Fk4yRxhfJIzM6n1li4P6P2uSAkQRKL9gBg8qHuqECot9T4q/s+je884fWwn8gFSOH/Ovcd+N1rPwIcucN4C23bXV+T3TNGLUDaKJHtsMajux/C5x69Bt9z4uug7XGQQfkSrS1YjkUPZApMnQHKA1uUP/ktlzbid0Lm/VNdafHF6gqYlaMxSpIqguW+9TEmsgc91gZcVGw/ubdnzx5mK0CZgcmkwfLyEpaXl6MsEWUzoU5G+4LQlyjWnLJMJDsmAc9If5FWZpo/+Z2Ca7r2Ksvvgj5H8zfaEUaCjXPrNGl5kQs6IVMMVCTX5FpwenUmVfK6zxWVamKZd8xmX2irTQAPKUKtKqyN1/C/b7kMf3r1xXhszyNQW1ZQ14vAmMHcgisDju7bsgynnZLlAbLWnf2t3D1M8A0ZhUi1GtQA0Iz2wAGoCXDuiWfj3577DrzjJa/EnHKWLFBVNZ7Z2IPPP3Y9LnnwKjysn8Bg6xDVknFjk9YYjTewvr6BekPh6OEOnLPtNLztRRfgrK0nYWtlPnSuoTFuJhi3LQBgUCvzvVUijLnFbfsfxj/edSW++NB1eOTAU1DzhIX5oTkQA+YrO145Dsjm7x3G2U8vhP4mc0ABEaC5xeqBVSyOhzhl+1F47UmvwA+e9iacPH8Unhs9i4sfuh4XPXwtbnnuARzgvaABsFDPodLKeAC0VWMcEYJlLTR1BltAPZxlZDT2HIomucV6Q1GIp/Is+pEKjBRs0jR+toZCWLzz2QOwhn+7Cq+8d8BNYPvZPIDtx+uVIrQHga9+4MM4ae5In23fxgGc8sc/gtVjtqIF2+Bwt10K9rxmswxCjYkzaGtATzZwzq5TceUPfNAqXwoVkf3mrlDEMkp6aJAQAlJLlp1XAA6PK1HXJeNdoiFbYLzuSuI5iedRE6i7k8Nk4ehvSpt0ohdPipLl9nhAo+WDKTi3vr6O/fv3ox7U9itRZuuW/BABAO9erh0ThvrZd0hYcPeSskxI5ll2JWFGoO5cDngzgJseqBDdJ+9KbCKP8E6BMSI7x6yUpCmQX6rZkCmBXTKDJysPsjNevRPE1U8hLbs8zuthZ2OlFOpKYa0Z4cM3X4n/eM2n8fBzDwLz86i3HwG0gHZuUnuMYX4dWtCjTTq403ZkwzWDocAtQR/aj3pU451nno//z2u+Axcce6rJ7k59qucwphZ/8+Al+Pu7LsbTajeWty9gfmEOPGqxvrYHaxsb2KqXcMb8CbjgmLPxysPOwKnbTsCCWkTLAHOLyWRkBCIRKqWwOJwHA2jQ4q7Vx3Dp/dfj8/dei9v23ouRGmF+cQHL2xZBrMzn4hgAaXvQP8FGdZkW225ma+GYD47bFUGnfICxvjFBszbGjnoR7z71jfieU1+HM7ccj+fH+3Dt4zfi9x/4Oq577l483TwPNUeYm5/DEhaAFuaEIg6fxpNARGGQHfTHjJA8iwJbosRdhmZbLpBMu07K8DCInfLMjNNlkkTeOSGr/NyRbWDLzhIAwl9Zjw/bpJDPP60UNnAQH7rrs/jgy/+VJ2Xb/Ba866zz8dGHrgFtXwEa9nNA+fOazXiz+ySfZtDcPG687zZ8/am78dqjz/Lrpd516jUzivtKKsrpeeSis4oGiXyW6i3pVTy7On0m1RqnuHV1eneOdIfGnuXLrlwup02DyPLK3wyomiVElGk9JmzHQPpLyPEkA7R7924GwqeuJpMJlpeWsGVLPkDKA6gfTKFh9FleOXqFIJjpGK6ctpQwHwuAlRO5zD8klAtJG/m/RdpI9kWGcurh28iiDmXMsh2nZKVO26s2rXyvQcIBLiMIT6Ntr+sRPnbbVfiDqz+Fe5+5D7y0ABougybauHnhAMSjiuAHCrqb/Y+g7HIgWQtXiQ/Kmo+c86FDqDeAt556Ln7twvfhnKNPNkaCNraDUhUatPjys7fj7+68BN8Y3Q29g0ALhPHqCGrc4HC9grOXTsB5O1+KC495DY5bOAYKlW23xqgdY9w2Zk1OVRiS+TBbQ4y7Vp/ExfdfiysfuQG37L4Hq7yG+bka8/UcWJtjCt2hE+5D7ESuzwIfsFjUNAfiG/e6Y5LRaIJmvcGyrnHK4UfjgtPPxAVHvwxbaYAbHrsDlz/0ddz03EM4oA9ADxiLQ/PRdbQAazZHRjpsd+vAQiqEsfeqNBKuB5Jnsdic/UrZbAqW2ttZlcmUnkgjLSaN1m87NMh5HItwuSWNK/MfVQq6abFDH4FbfuhvMbDBcgBwx+6Hcd7/+LeYHLMDbWs+L+BOonLxBqy12w4OwFg/zYH9eN/pF+Ij3/XvzZeFKuUTKKuIdU5qS9sAYR1mhy2sR4eAUIree/7wsjGFpwyIU9JnEN2ZGDndPbMh0lqm6TMQ5Nood+R/PwiT7CtKaA0kJU8JlKyfr62tYd++fRgMhn6uKyW+a2stWmXva0A0SqB1XgsQNocbTQ4EbMbyIt8W7jJFwd3R6RBBnwThmNoAqF0iwvPZKU+qKWbsMmmxLMs4LBbbqdSnhDwTvgDlLKKWZcCT08psO5XCWE/wyTuvxe9+7ZO4+7G7gIV5qO2Hma+jNCYfOXBlgjhySdYS4mxchC2z/eYKg1sC13ZtlwGsHUI1VnjjyefgF897Hy444SUAm3VHZoAUYcLA5c/ciI/c9QXcunoXRnMjtAsK9V7GseuH4VXbXo63nfwavHLnGdhZ74RmYKwnGDVjKBAq+5EApSrM2SMTGYyHNp7DpQ/egE/ffRVufO4OrGMVC0tDzC3OYRsv2+06DIaGOR9CzFryg+gHxykwXojZz9o1DWM8GmOuIZyybSdecdqJOOPI4zFuNR7Y/SR+70t/hfv3PIHVdhW0oDFcqLHMi2Yte8KAjQePQIU4MnJcgsh7BcFbFGawHRJx5RlrRnXaz/GeaTK1rrz14bxmXcCI5KRPwiKfoC1aqA1J3UcEZPoIkjSjrod49tnH8cmHrsT3vuitmOgGDMZphx2Pc445HdcfeBi0MISeaO8lMm5lNvOD2Qa/AWgBtbCIi++6CY++9Vkct7zLz0V3KQloftC7ylIZaG073KcIc93qHsR/oteEmEeKXsDkWZEHrByO5Hm63JeRp500GcWgfAWwSw32PCKUfksFIZ+M7fbGOjxxICugtgN6HFXB6fNEYwpECBR3NdiyOzjryO/RakqDkuWdwjO4OoRbOp8kT0eq+UR71vrWRx1Nok+i6F8Wz6SGJoWpEJbScvHpOKM9TmlbAFtDQEVkv3jT4nP3fBW/9+VP4euP3AFeHIK27jA0TlrrInN7/1xh2o9ftIPagpALEjHjb2JujcWrjNvt0CpUq3HuyefiNy54H95wwmlGHnHrZcyEW3zlqdvwF3d+CtfsvRXVAmHX8nacOTgOrzr8DJx3+Bl42fbTsFVtjdo8aTcwac0e0kE1MEesQUFB46nxHlzx6M34woPX4iuP3Yg9zW4MhzWWti1h2G4zhyc5gCPYL+aYMXAuJKtJwM8ysv1BwfptdYvRWothCxy5sIwXv+gYnHL4kdi2sIzH9+7G3994Oe5+7hmM1ASqBhYXBlhqF0w/jtzHB8xBF0xBWrieDsIwnnfR2Iv7JD44sQDTWTWjcpqsF3Ythdw1VYONq2BnZcTrsZ2oZtcXAqmitTlLL6UC32Vz/evnp+F1BmOwMMB/vekf8V0nvtl8NrLVoAHh373mO/DPPvaH0IMB1ESDW46DEa3Hh9z3lDVB1QqjjX340C1X4Jcu/H60WgvrE4AYa1tEoJYE+4VW2v4RirvN44FB5JHKl+OKzmgnQ1OW9fHabPYgjtQISvCmT37GtJbT+kN4igZK4JEoXG4G+dmhiY0BAM3myE6JcQzUpqrwb0ZRyhdcaFieiNCInH5QBNxCPWmdKWjk9q7mKOvqJpu/HAPPrlEllWfKi7V023elA0XTRmTmRZ+9oLX9rqwdf0WAUjUAxtcevQ6/c/kn8KWHbgSrGtXW7dBQ5subbk1We+3ACyKvNjuvB0kOM1Qpd34DMbiqwADag6uox4wLX/IK/Oz534k3nnIm5lQFsA3gA3BQj3DJo9fiw3ddglsO3Y2t25bxbSefg/N3no3zj3w5XjJ/LBawgJY1Gm6w3qyjgkKNCqQIw2qAQRVOUnpqtBtXPHojPn//tbjmqdvw/MZzUPMK8/ML2FZtM0FZYw2NiTniUEnxE+DNNJlgLEh73hOZ7wGRMilHEw2MWxw+XMRpRx6B0488AvODGs+s7scND9yHe3c/gwOjNVRDYG6hxhwPDE6PtRF8BLiTmYhEv4M98ACO302/ewtGjju5fyDMFJJyR3BNJL2jdP7yv4Myzkkpvm9Exj41t3feO5q9kpGWQaKARBbIG04fUqA8aZ+ckbBVa9ZQC3O4/fHbcf2eO3H+zrOhoUEgvOvU1+CYpe14ZH0VhBo0MWvoRK7/2YO20tpsBWoV9NwAf37Ll/FT578PA1Jw54X5qZWVmPA05XovXgsV71KQjbJzN/0MV+eIQ19XBmg7SbrA3RtrQnHaUH+QoNmtraW4m1KUde4SWE8U/jPl2+hjEQcDImfZOsIyBebG1Q+GoLXgbzfbG4Rm5YsWHSLK7gxvblAiWtLJGwDXkZ9VAjIAXFrz7NYRt7Wj+KfaotQmc1dHGGYAVso+P9CJIEz5OSo0nlJm8grXsWbUgxoVKdz2zD341S98GFfcdR2aIYNWdkGZg5WAyq7JgtzsNwEeDHPIuv2EHqduZGvkGYZmH3FJLUGvrmFIFd52xrn4d6/9drz+hNNRUwWGhmbzUe1nJwfw5SdvxaUPfBUHcQhnHnM8/vmx78RZKyfhxOFRmKMhKlQgMJp2gnHboIH9Ek1VAfaQcADY3ezBVY/dgs8/dC2ueuwWPDPaDVSEucEclgbbjWhrNfSk9QIShprEepAcbPpDO34nAukWTdtAN4xFVeO47dtwyq6dOGHbDjQbE9z79GO49ZmnsHu8ClaMuUGNxWrOQNJY248dsMUOe4i9YzcBEG4LUUAJF0vgtrTIeZfwGyMIVY5GrHt1wMn2gSi04/HxXCrnk8weTZZQTq7+6MQ6aRUljM/cfZbSFt3PACpketVoqLBfdjJyVc8Df/mNz+KCN56NSilorTGsh3jP2RfiT/9/rP15oG3bVRcI/8Zce59zu3fv6/LSQTpCgEgTEiIhGJoQAwrSKBRVglKAVH0KhYWKLXZYapWKIuUnSKeliNJGGqVvBEIE0kE60vfdy+vufbc75+w1x/fHnGOM35hr7XNvrG+9d+7ee63ZjDnmGOM3xuzWr/845OIdbX91t8xRm/YFdW0rkKJCDg/x3ve8HT/z1lfiiz7qudC5ttPYLD0BoE/lja3d0xxLPs7Z7gtW9tpAqjdd4yijGbyVEcxbzuOu0D4uHF2DRpN3PhPapUGDb8l58rwhN+M89ho05tyZCOWuMjY88MCD2k6yaV7WyckxLlw4j4sXLwJox0ztu9ZEetlRfbXtwsMcjxsjwvOEwN76lwTt8Vr2Z0AWVu4CMx5DB68B4Fjkvmd08fBvdkJ0mQaDI7DHMPA871p0r70vDMCgfS1SacOer3/oHfg7v/BD+C+v+XXsphnTxTsBbNpbZEqFdifK/nNjgWYsbPGHe+0dINrigXaGbHsbygSBQK7exHmcwRd8/PPxv7/gC/DJH/HRAND38s7Y4QTvvnY/XvPQW/Heaw/ijvPn8PR7n4hnnHsiLsnZdpawAjtVaAU22GA7bWLpfefHDjPedfN+/OK7X46ff9NL8XsPvgkPHj8CbBWbg0MAU3MkdkF7vB+2Oz5i7fAOse6LHukGQItiPqk4QMFd5y7hiffeg8ddugQRxQevPIx3PPBBPHj1Gnayw+Zgam+/62dcoMYQvDkzrejQJzcijJGnYMW+4CBJGlmm1UGU0bqMlmytjlvglxcUXvJq1rWRnkyEZHro6cJIrjFLI73npX62hS5+lKb/tSmRHQQH1wX/7U//AJ50+Bjs6gwUwZvvfx/+4Ld/HY4unmsnhSnV3IekBW0bUOmO1Hywwe7mVTzvYz8Nv/ylfx1TFUwiwNTe/eyIOdLpFr03aB8KrDzg0dx9I4PLPGvOjGY+2hD4KavltP/WtXR76rZKFmCbIvhTrlWcaKNDIVECXviQ/NOe/fqN67j8yGVfIGVOUZmWW4AkR7YrjVp5bypHrdkTsEbqqnLfzuKpW/mXe1fbEpOTDdgT0bKRWdLZ/x29P2ju3KGzxzmENZpXKlqmBw216ZghD8OpG15TNO0lrHimlMfOVi2loIjgHQ++F9/+Sz+Bf/17v4CbuIZy550oOgEnFSgnqKX4sXO++Ib+Ana0e/998YdR1062gJTSQoHrxziogi/4Ay/AN7/gi/GcJ300pJ9qNNc2F3kyz3jf9Qdx+egmPvlxH4cXbe/AgWzRbN4MwYxaj7GbBTstKGWDspmwKf21dTjGa668Fb/xzt/Fr73rlfjdD7wZl+dHgANgc7DBtD0AVKAnFTqfdOYIbMSjGR37LP2tRLADa6PhLTFUFbtZUXaCc5sD3HvXJTz+3rtxME24fOMqfuttb8BD16/iGO10oelQsBFA6ky8FBiY+mI5G5LO6u4AGw7qLfBuVSfpu+55sDfDbaS/1TPj4wqREbTKcF9X79+yfatpdPFhdoxH1p2YftitlyXaRoQOtrh29DD+n9f+BP76s7+mBS6z4qPufjw+4+mfip95468Dd90B2TVPRjrIsrGy4U/sZuDwLH779a/E2x/6AD72rie6qJmY+FTCKugiTSnws1tNt7W0eejWnMzENTUbr8u8zMe1unzEk/jK0f4A2KdNTa5NSaTlQUP+BWbsdVxy204duh+LFLS97cWcKfG1OBTZ1h7ZnvTI9lJTdB8KCOIz0djnWC4bOFz7wHBIFF/p3qq3xcUM6de8KS5fTMFY+ZfOj98/bTl8VHsLD2ss97Zckp5yaP/i/FAAcz+uEIC/Y5FH7d7zwPvxHb/2U/i+1/4Crhw/DLnzTrRItgtyBxPCAVjLfQ9uf7epRbVlBmSuKHNfwNPf66miwPERphPg+U9/Nv7mZ30ZPuMZz2qlad8KIa3CWit2Gi9IV7ShbkXt6XpEIAKRDUTaEPGVegOv/MAb8F/f9XK89N2vwJuuvgM39Dqm7Qbb7RlI2bSjEmuFTTUDEm8MGvyl0VNv5Im/UxYFqHOFVMVh2eLCufN4zMULuHjmLG6cHOFDjzyM+689ihv1BNgIJlsh4frSHBJ7964bYkWbC6cJ14CW3O8LnErGxpyuUXjooxudBC7W6dk+eqbTxTpbgtPAnnNwsLFUbdvmt1bMKc5sAiAwEyNBApZs6/ieR5WmE90GiAJSCnYnx7gbd+O3/vQP4hwOMB8rNmXCb779DXjRd34Ddo+7oy2GmtEXCAL+jj4jsDQ90e0G9eGH8Dde9DX4u5/9FY03/YUYRpNETw2gkefvl0yx6nRhM9a2I3440ebtbluMxWnrwpTW2JwCtmt1Dy6YlyGch+pdTb8eRi2uGzdu9K0/24hgi231aWexx/a/Yc52Ue0aeq1pLuETD68127TCzKHoXGesHkteZXbd1vMLLU5JFQ40e5l8i9IMha+tCA6nXPenQQjth3vd6pSW5AW6AGeTbBFsT+Q6+cDlh/Dtv/wj+N7f/QU8vHsY9a6L0It3QWeB6K7xsSNC2CZ1xFVuq3TIsAW4tXp0ICrtNW1Xr2OSCc/9yI/BX/qMP47Pf9YfwlS2UFXUuZ+XLO21dO1tO9LmbLWBrJ1u1t49u4FI8TOXHji5jN9632vxK297OV76vlfgXY++B7qdsT03odyxxQHOo1bBbqfAfBLtqNrBrbelsrmiV2cBsU3JeDo3J2MzFVw8fx53X7yAg6lgrhUPX30E7/jge3Dt+Ai1ADIJpq10R8G86b6AQqlMDdBfV7F1eVg9Uch0CBEBZ8GJLk3lq7XYCFs7s3xZnV08G0m1780bdQ/0pMtkbu1+FJye6/Bp6ccgYaA+PiKtr/8wuRH4YnOgAWedK7YHh3jX+96Bn377S/E/POWF7cxuVXzqk5+BZzzxo/G6K29HOXumAW5tuuqxmRms3ncyV5QL5/Gdr/oV/LXP/h9wuDnwaR907ZvMiHN7xJ4yqDIQkVyv5M2jltmQpWe3AcBp3Q4BewJ0GolMI3pcDtexeNrpTtA4ODA90EqYI0P6Ba7xrps9cHzaiGWyF606UcUmj9dzYeQNprJGhVpvxGk+zuLZ4NKasR49kCVxSGns+2L18VojbzfqxCmAKrjlHK6/nqwVBJs3tZKH1MP9scB14A6YVWj12lBEMEH65njBh25cxr/4rz+G7/7tn8YjNx+GXLoEHNwFRYsmWxmMAgzig3JSdNc89XakoU4T5qKYj46BR6/h4OAufMkzX4ivfe4L8YJnPguQLU4qMM8nKGXy0cC2oKoZkDYKrajSotn2NiABpOBGPcabH3o7fvtdv4fffOer8N/e+1o8ePwgcKA4d+dZHN69gcohdK6YT9p2IQBAle4MaAfW/lv7Yq3+KiIL2C2CrXZgvCrQ9xJvNxPOnT/A9nCD3Vzx/gcfwNHJcTvW0fYbT9IPxFKo1uhRFTQCxOtr96lujS4wwHOlZ9FQRBTjNkMXuMLdlr/EcGl21Ubj1e/0fNWH4KIcezyY6OzXdvkfDf0qUMoKPWshtqbm9EB9nyF0RPNSvTpzLAnQtCOhAkA1cFN/ObylFwXq8YzN2S2+9xU/ji99ymcDW2BXZ0wbwRc+9wV43U+/AXr2DMoOmPqJabNK6FE30u0McADbQ1x++L34L29+Ob70mS/A8W7XRne0neImpc/l5i5w26kjr/r9Ba4AWA0IGAuMX3tGFK3sFbiI4oZh632+11q+NVu9DnaDjfIvIZ8eqHn+dZsaufc8dD5I+vNIdiBnJbIdAHc/DQNBa2WHR+G/9xGtyyYxQ9Tq2DekfEq+bpGYMHApaX70Fg1ezKXKINy3MHC8MWJfDYvfQ5WrwyfkZFgkKADKNKGUgoduXsF3vewn8E9/6yX9JQF3AWfuauB8fNL3D5Y4Ok3E52WF3G4VAl17I4kAKHPz1usMvXoNevUYZ8q9+Mpnvwj/+2d+Pj7uSU+DzcPu5h3aQqkSDUuAi+4KCmwX7gMnD+GV73sDfu3dr8avv/MVeNOD78TNoys4OH+AcxfO4sLZi5jnxpvjXQWwS30m2gC8DVd3B6i/D9fqQAf7pjANlPspilCp2EwTzpw7wGYDQBTXj2/i+Mau2V1DxgJIf72e+slQNqxHfb/QMWkA5jwnkSWACx9P4swQEhAHpho6M7pv6bKsDCqrVzuMIQb1U7Wki+vlRx29nn16soIPWZcHL0JyUvMBdEyA0JtwjrNBdOA0WRxWSTs/bYW3dI512dKdYntwHq98y+/gVR96M55139NxrDugbPCln/Bp+Mc/9f+gzr3EWdw+a98S1Zy/7u5WAFNBOdzgH/3mT+HLnvkCTEVQ57G9t4asPCDYGiiZSeujehIguwbG41zoouuH4fk0ymbVJPBdA55EfE+3rF9SWvbuVmT6NBzy9OTipfSng0TyfXyIHt7XG1aCbuMQbttKgdj7KCv3IAirE/KnCAvZ4NtKv5b/dtIvFiTdroexkr6BXfvk+m2OrgFggUhxYdhbcAdnF1INnqbRsJVhH1sFd1SP8F2v+HH8Xy97CT54/9tQzt2D6czd0J1AcRwc0LafDz4vpa74DhgSJLso9kPSiwJy7RrOXj/BJ9/3NPyR5386/sfnfAaefN+TYO/Uk1pxuCnYTnl1u7ep2PEW7fV1r3/ojfj1d78Kv/WO1+H1j7wZ773yQZxMN3BwWHDunrM4V+6EomA+2mG+dgQU6bw12pvxmiAt6J4RQ7W1gW5bD6UAKmrfitTyzm3YZxJst8DmbHfL6g7Xru+wQ22nwmwK0KMN7dZausXWYbFaujqaNgNu/5JTA2d7l4XWJpvfXpUYO+DBzUUYHwnKrND+IV7HvgNN8wCcQU7cMsfAhuMWpaTyl7RLJAmZo4e2jSoMQjzP2LxmsxhJZSh6pRxhGwj48ILX351Yp7n2kaS2gh7bgjKd4N/+xr/Fs/74t6LqjKObx3j6nY/DCz/2U/Dzb/wNzBfvRt3ZaWtC51SUbigUmBSoFXL2LN70ltfjLe99E57+xGegHWTSNm3Pte3o5XUF7SzuEmsCzHFI/WFD15JPGRs6LgHtypUObKCynV/DxcPIa5K2z0miAoA9eXvlQ97bwwqvt/dxomPRDnYOQncthzt7q8PtfoLULZu6Qt0KCSPA2jMer3eLret52dvZN1w8pFull5VyAfRkeLQLlqwLlsBO6bE2xXehcmzPqlZtilBrm1ss7W/qk+cDZ/ZcZrhk0aHmfY+iZfTYUNdLf+938I0/9W/wxve+CfWuu7HRZ6A8WPx4OO0LgwVor78z+oq2k5HMqvintBfZGI71/Q8Fgu3RDp/ypOfgL3/W5+PTP+KZOH9wBwTShmChKGXy4bKyaLaiVkWdd3jLB96HH3jFr+Fn3/oKvPXKO3GMa5hKxZmLhzic7sVZnYArinq1H1JYCzZFME0TtNpUSTvVSvrws/ajHVsk2IDVzkbVzivpIewkDYy320McbAsOimCuFSdXj3FyAqAKtmWLzSQ+/9pAtYRzZQonFQWNP2oT2v2hdHZGkDWH4YW9t9fkrA2lt0VUoeIsrQ5Wwl9aJwcEt7anU4jslXMSUGwljHUkWXNLvgQwWzjEmJ4oVcqXwi5Z0OACKPluuK4MCONRff2umtMzNMQAGABQIdIODpEOQhZ0OLwq8VQlzjWuE0QVO8zQWrEpF/GLv/U7+MDnfQj3nr2zHSaEgr/04i/Ar/7Ob6KePUQpE0qd2/koc+mOUkE7PVdRpKIWQLdncDLfwHf9t1fgn/yJZ2BT4vzlubbTquY5FhIWmWArIF0m9l2UwIfHiS1r0WxaMLhnLtQWTroc9PL3HXZxK2gUxgBONzqdtE4BQn7S4AG2QEg8nX2YnC12nVBbuQxbYbzwfYesSrLUVyNrX42sfTXyhfYiAgUBRDSeJ75T+StAnAje98gIG9Kzl8BgywA+XouIegDURCTp7j5PbvROgpy+aKff41W/QNfFqnjk8qN4w9s+gNe+5b146NoNvO9Dj+Bt7/kgrt48AsqEggnTZvLhBu3zkx7/aV+pqwpFdc/Q0osIpjJ1PJyAacIHLj+E13/oPZjPbSFnz6KcALI7xqSAVEEVQW0H+oZyCQAp7X2rDrJTi/b6PkMt5gTUDswFqgeYThSPO38n7jmYsLuxg8oBimywQYHWE0AmTFqhpUIntNdRaQfH2gzGw9eu4d2XP4Ab8yOQsxPKhS3KwdS2QvR500kPUOoWYq8d02aoKiZU2Mq/9kJ0Qe19M0PV3sFbYa/0bqLQTkeO4fHG+TIJBG3v464K5i4VLfCtQKsNwARIgUUbVkK7B7iRdu/Izp1Gpy/kMWyfOQSmyX0OXm0jrva+N9PCO3AJaqWZb1sJ6aAX1goWhXsdSQNimdjSsesRYHhiMferkZbPoFBqS/IJ/LDsqCjqNyHv5fI7gEX8ufGA4AKxtSba1Y5j5OeW35rV+wpND/JQZR8Krd1x0wrR2oCynkB1BuoJSjnA5lrFxbN34nBzFucPz6IWYMKMd9z/AVzXI5Rt2xXQFgk2+dM6tamVIpAJbavdZgLmLe6SA7zoaU/EPVJx352X8NFPeiw+7ulPxFOf/FicPbPFZmpnete+KGu5uAl5LjFEIPX4bV/75lGpD1TDdi4WS43EjTQJPw6hGrcyuq8KQPfQw3WcPuweXMtD2iabI9gC16/fwCOPXMbBQbdJ0nd92P7aUvwlBHJrsO17I2/jSnJtrGAd0tyMtXMyF+xaYc4au2TP89NWz61dt0qXh3GbYLe3erS8RQS73Qle/so34qd/7dV4w9vfg99+w3vw4EPXUU8q5PCgHeiw3fZzEbcABDK1YVy1rQDJejbtbm8JaYc9wA0xpysAJpSpYHtuwnRhg1om1JM+Z2mcMqPoaI2wzh2wmnZO7a+UBuLSgKWbnQ7+/SzlCtQb16HzzTZ/q21o2sDG5VVm2NCbASi0Fb2ZCqZDAJs+OjDviA6BloKCqc+59QJl6m1gQGv8sdWjbdGYDff1/b/mYThYmONhXkaLdqXzpfWLGWL1usQjr/6WDzHFD3iy4WEJwTH08e8uVz2NGDD3djAQur/oLzuIOqLwDkOlD40bHW63slecXWYdnsX3NsoZaMprSc2EujElrMul1cyLxeVuQYCtOyRBW+uaaJsagUq8SupsIwb0qp0oKRrY+7P9LvHMjFjXxebEmSNYofMMaFvtPpUCnJzA3q+sOgGzYjqzATat/iITpGwQsjd1m9CM9Cy1renTqZ2MduVR4MZNyO4ERXbYYofH33sBf+Apj8Pnfuaz8Pxnfyw+9hlPRhtRqm1LWhdIs02Aaa9Se3NfjHOtzKW1NIrQ77ytZ8g05k3y44W1D8lZJT++9TW0Ycx32twxq0YMfefaLbJtb/25jIODeOuPSEzjlX5qnd2XBx54UCvts92dnODCHRdw6eIdyTu51bUAWx4OHog8vSBZvOB9LGe17jHdns6+rQh2yOtRrJIhckNYMKvi7W97L17yC7+JH/m538Rrf/89qDtFObNFOXcW09kz0B4lttzt0wAvL12nyq0+HweNt4eIvRPTHArV/mLq2pS82oIfjXKFjNIozgy+sDHm9ifFwLYLjs8vdRp7Uj+Yv+/nFRaDakOYnS4DkbkCdQZ2M+pcoXONdltniNDRdBJzy047wqh7XiVBoL7z4VljAbW9f5fEi/G5GRWh6kfroNR3VlGex1/YezfmIyBT1CvqdWUDFLS0D3G6Et8EsDWjo/yzyiXzpJrZxReXvWgU/5SVm2vafCsNZ+2gflop1e/a1JUzURNvF7VbxCyhlzbd0IqrSR9R2/AzlA506Qa3VaMO2s3/k+7Asn4JgObYtnYVn8bRWiGlYJLiq/eLAJhPMB8dY756HXV3hKkInv3xT8f/9hWfjy/+3E/FmYNNm9qy7WYaDkxJo5XUd3s6etG75BwmQF4BW5+i48h2wIDkADjPlmBMOLifNr5WInDTwXT3lhiXa7ZiG9he6ZGt9LMM2slRkPEEqQXYtsj2jjvuwKWLF9eJXTBLSLAHDvSGrB5Ased+ys71j+nHYWU3CoOXYowae4o6c98GaX5WqwFbV6yu6L//xnfi7/7L/4if+JXfxfH1Gyjnz+LwjrMdlBR1t0PbbWKRE9qnD1mZYjN5bEBanTGsWLNh5j9Tdh15yPwZ+Na/qRkv/+vGoBR4VEv0ks8BKT2CZJuvzH7auaq8b9Ha05yEfLjE0PdOrdE3GvbWdgXzggyqf5i5Vi87UKp9l7GtZIAZXHxbjN+mchf9QhFqIl3zd+30aSy6inQOM9zBuRhyEIRojGd7rn04x/WvVGVgbhxR/tXpH53JdaMZ0r5GLvdanhLa34wmeppq948F2GriXavFwNaSagdb+1Ogn46G7uxmwkOPpSFw6JUAKFPIl8mcTTt02s3MuYkSQR9tbsa8FGCaUE9m1CtXUW48iic++fH461/zJfif/6cXYyoFu93O8zcwIPlwWyFwtjr5Gt0+2Mggh63IWn+MeopUCZ/Ql308suYp8pQFLSMdPPW4lDNqZNKvUXYo3VBngC0PI2ewld6ndtAFAMiDDz6ktdb1YeShEc4ULBk7vt7JiaTGpyTe2brM40NRo8HFgtGDz9F/sNXff+0D/FiqPtIXZubyww/j73zHD+J7fuiXcaKK7R3nULZt32Vt+1BcmAPApp7dhh8HQ78yGhDtimP8eIbKI7UU0S1BZjQsSy4S2Hba1A1DA98AIXBHEm4ZPzXkwb3U4XJP14Z26cUFrHTJsIrhUG7LWts90RrAMekGmAIeNhTig9UvGEAfw1dX4q4jAy3hrK2p+ABKQxuFwGV8tmwXt2Gg1QBxBKs9YBtGcC8aLzs3ofF6qXsvNxK3UF5KoWs3Fg+pAtIJWU1EOpn0R7sBp9EXdsBZ5GQoT0B2IHRKF84ck031ayqt0Z5Gqio2ItgWoB6f4OTBh/AHPvHp+M5v+XN47nM+pu/RJX/CwVW42pBBMVaRnVm50sEUVpCr3EqeNZygvMtDWjTx5dRrxBTCHWDdGbCnq2mIT2no3MH2FsPIwpGtNLBVVczzvABbVe2H1I/t14Est7ap4dzgdd6seELs0ayyZcg/eC85Grj9esfnvrqY6LED+3/sJ34FX/9//Bs88IGHsX3cpXZC0NEJqlbMavs24Z1vc0Apckxzj4NDYUbKNMPb1A2FEI80IkY38glgls5CHiHI9Us/3UgdaEr+ZOUcjemgnGwzvSlKfdvps2hUopBk6GzxgwWObP9cVRaAi5x4Te8l899futH7gYeTYzGOfV9YPyqYANTaqDrwZyRKQ14gC3ITdiQAWLnYEUplZpqTYRltnP3Lde0Fz9u5TKAHvo3lJWN8m0b2tutfqc8cmQV5awwJWbXvglg06SMzC7Iz2IqN1Ig42JozF9UNOmrFkr4auW3RWFvFXNDeEiRli+Orx5Ab1/AX/ucvwt/+y38K282mbVFycgIImFb/uRIZcr1rQGgrm5eYqYMQr9hhwozkHo6gOdqBoaylawmkt2sM1XoAOaQZh7eZHpuzvXw5XkSwBragiLdFttom1FUVxyfHuHDhgg8jry6QWlU4cptu48qOn6x4IbdX7boR2uNVeXWBALbKcO1SM47a9sce3byJP/PN344ffcl/RXnMvZBzW8xHR6iY+9tvWkfEqTvktSaQ4gjJCQEgSSZGsVk0chTeBKK6mmfF1ixoMMOwGFpOxnuloM4vwQCqt+zM0/bPrR22YLDMoDoAQwLd+GpwmWqW6CvvB4RzlBZKOEiR8c6WYeUzaFm15b048y9k5IiR5bacjdnAnRUPZ2GG9skYOwN8c+06xYm2fKMur+u27AfxNRBco92BcF99e4B2jR3mZix0yfogL9Syf8U8ySFPGrFKn63d7tQi99SCVOUyM7lqW7e0bXkTAKK7vihqC/3Qh/DJf/BZ+IF/+k34yCc8ts0z9+FNWzkbLCEa0muKFmzbC7iW5r/bL1urBximBOJSYGGXZHxuyjs+5HS3slnDdeNGm7Pls5FLaX8C6dhJw/YGtmNke+nixVanjKIYw12M/K0tGpgLpCEGbwN7S3sizLGjwtEaOtaVgI3k0iNk2sc2jWP9DrBEokjB+9/xPrzgf/37eNeb3omDJzwO2J1A6w5zVdR+rKH0SNg8L3vzQwoFB2PBgjLyZc2z0kHhxP/V/AqvIcpdtVkaT7iWiCQz0Mb8CiIaIO4mT/jD0LRWjxEfBfsQDhkykz7jG/pRiOxoxHfF0pGiOUOfZM7tzf1A7UeXDetfTwdkb5zmW80407SC7dFzNkleFOj87/84xV7nMJrD8sr/igw2JoOws8D33eZS/VOiXIvQo43gLuMv7kP7Z3pKutcdmL1bM0htXGTXrOEYiTnDEYu3I2n8oP50baGhf0/GfUQd2N6ExU7DAPwEuC636G3eG5GNX1LjMfaPP9OmzaI7FOzaevnNIU4evIJLd96BH/uOv4rnP+8T2wlpNudr4IDBHroemlOgqUpj5Fqv5XLWL5aH09bNJAYkmYsODUAd7Pta+YP9X25l3YO0dFsk5mwNbEtZztka2AoAefDBB7VWxVwDbO+4cAGXLl0Mw5Cauw9sNdOzb6h2T6O5Paud5/WvlSeusEbjeuJO/x6wta08cz8neCqCzWaDV/7eW/Gir/qbuHZ03N6MM/el/32euy0+tQUT1OHWGFGijRsVW3Ka7ARfIet8iO1MwRnJCVzwltzNwztOnj8NusIyGeCysZZFGa2+cVFP1JtNSabMhp4yIZKEwaXLlW1cUhMgYHwwemTFQx+VLyLb0SiugO1wCRuBRI8SXV7xIn+MhGRjHEZZc9bkglO90YE9q1E89B87MTKAyFo7eklRBbXhlKHG7I0s04/zlKktnGbxdNmfjqga7Qrak5bBjhpduighO+1j2X/p4I1VRLTf2ZEw0XVK9jngiQQDUqO73cty2Et02TfAbXvK2wlnFZNMmK/fhBwf4ye/+x/gsz7nuV6HAcTk74EmPp96rfTDPrufuWItd9uxLOY2wHZNNnTPjpdR76ydA9iOc9aJ2KElbRi5RbY+VFxorrZvGXQQjsxWZhiXW160IpQ7yWgbS9DxT20u63QAdgqtQYkG8m7oPY/jf6l9e2owerRqW3IvBW947VvxOV/5V3D96ATTnXcCsy2cmqDS98lRnaE76oAnY1tV029f8OS8oO8WSSjxAAKb8122jDxU55ekNIJulzRWOSvRau/btON9bRuP16TwZ+hlBOD0coh+0b4ASmv/Ts9g+Tt1GrLk9S960QQi05PqNqDtaRO3NOQ8cwdgTsmi/H6fyuX+4e+JdxjbiRgWZH7wMy+/31WKPhbf+n/Unkxz9NWAJ4Nv0OmkPK29Qu3qcsE002977nym1wam9FFpyJP/GY9DopOk81wLj2h4eh36Jeq3s43pDfBE/yDXRGvItJPtvF0YNqODppCSJA/Oash+53M1GUa8wlLzp/Q/qLZzycnZl76XvVZBrb3c3TG2Z7bQw7P4I1/9V/BzP/fbrSpV32nhpz+RWLBs5D3fneMy/HnruYtW7LxSHYsyJNdp+UOTVmrZU59951EUdihYftKo6VLuonwkDoVPKXQ7cRAAUFho9gPRnkaZ4LhVEm+U7vF4g8L1jgEzZvEoL1jK5QVVy7rWb9nQVa19P5oqigg2U8F2u8Xb3vZuPP8r/wquVYFeuhPzbFt4YuYvIiJ0oA1+uEGBtugqvXUdC2CNVca88Z6ExIS79L80zNuhhod9g6iBCWqpAdAclDJ9RK/kvlSYXSBL5BS07RFRZj87uPKWieZxexuJNB5abH9C3+Ftj91TxG+3fNFL6ryk+8yWQjzj4XIRQPiQj0xDMxCsoIxe/d27aqdYhaGKBTY15RkG8pNKBT+s3kynr6QW8dO+FjRp7qv2lUY/FvwOuQpi1PtdQxLQJYG6MRwLTuPFlrEKljmiw+SB8arTEWSGQWz2WHrfcn+QLqV+NBqU8vBKYz+TkfprMORQ2MIY47/3DWgBlA0rFtr2J9LP5zajb+2nRY+AO6iZV8Z1kiWmyfJ3h6LKhF1VlDMblEt344v+7N/Fa1/1ZmymyaMyBS8KHWRj4PV/7xUAu2qW07VWF4vl/ny57GjHSP9eYOi0js5FJFqMG1rfeH6T3/i+AaxPBQECp7SEtap7G9ZRUfFym07QsLbgZYU5BNpeLX1PHDfF1BDDkWafJxsrUrRl8dUUDthsCi4/eBkv/Oq/hatXjyD33tu28xjImpdpgMQOWy/TuBlz1EuaLJEpbHhZ0hUmXljgXeQlNQUPFtNspvQTqagunn8xluVDOjodEFoY0S1Sp9WNGSJ6SUC9Ul57rCQy1YdXXGi1YKlBQkzMc4+xikzt//aojoaHslgqGj4iKxK0dKMpgA/r8zBv8F9bvsrDesELbrsTSbm9jVq7TsT39FgBWyUdo06AT0Iqor+6QAT0MXNIw12OJN2w1f1trYE6b/JWivw9RXi9BuNdiJE3pJNtgAivx6VzcLaz1gidvaz0RgChtNzvXQ66rAvJU2dcbwP3GckzQidG26huU4aV6xpbcixS87Zl5evlsPHomm8RtGh7aYZxlmhizrBtDBawMw1o378rVbE5nIB5g8/7c9+KN//8v8Klu+5o0S0A7UeRxr7fTj1H4/v6hwMhTU8iLye3vhwKG9fMrBXF9/dFp+PhSIlrhhlhZHJfIOzy/jbIeGNIJC49ULT32eYGLYpaFmKKAzKoq3WJD0+uE7vy+xS3he1t+uVCeAuHYYHooMi27fOcBEAp+Lq/8R344Fvfge2TnoS6O0LFBMVEzFLXBy/QsI7SjNVGZM58a4a2+QNNaWPfcgmAUGq3g7oBRMlp3FkxIttKxRCsACVBdwqsTDdIZjxiX7C/EsxZTYdsQONVcG7c7DxgAx/Qu0H7QR/eWPF6ghdK9lS8aX6qTwc7SBtOU1UfXmNTyQbZeSzi/FVzXoJa75sUbXu/CrWRI4nGV1F7z52/Cw8Ofp296rcEscc3jxbZDjF7+42ij2qQ6KC3v+mlRl2DUW7WLbY3RX42eQY0BkQmY72cPmRp5wxbr2ViAKDQ6VVAROTWeJNRCf6NOjWkiwWXAnutIUMig2vTodC/pG8eJXIf9byaeZZCg95XHsVyc7wWCX3l6JztkQs0zRFaSzr56spc+31bYKfedR2al3baI7jeFmNje5EzoCc4c/EcHn3gfvypb/7n+Knv+5tQ2I4UYOpvz7KI3SLvfcCzAClNljjTx86UOQXu1O4B6EgeZd3Kvg9JFpR3GecDS8ay9kbxdNudrEET3EyTadusU5LSD/WYoR9X/q0XEhudzUouucT1ODgPadcUei/zud1JV8xLy+UYedAKbLf4of/0y/iJH/sZbJ78VODkCO34QesYKzyrefsuYUWFjKwZaeWc1sd2045XrACmdjRbsePc7AxYvnpdKUJD1KEGfgLVGbV22ktpRycCbcixtr3UNkwVZtaMSYmhVgLDIKZ0muNUKIc4G46yviwT3NfzYbTuRSOG2DiC82oo6gfaTqvQW21z6RaZTe2tKkGnGcHOTylhFIXe45tkonFiHpSgbbMo0Dq3NzrZu/oswrWIzq2Uh1+hgO6EdkMIwWwvmNcCmUobdi/tEBQRYCrtOD+FYCoRLTnkcPSp+bc4EBfMaPN00b+9HEV7IXmvz52/8AgCg6v1RyWB0WSg2qsgTDLQ38AEB11fseny2o8fZRM3ypzQd5isNVnXftysy03v/zZtUDBB2vGH2sQ5tuiZXVoRgdbhqX2K0s4nN7C1URdIewet2B5LpHKdj2yYernSE9huCCj6glVz3BTutKUhnoHYMVqzERPqZ+lD8DrvcPCYx+IX/ssv4T+85DPxP37JCzD30bvcfit63b6vbZGCjLaKSCReKEIXFonYOfLb6v0RdsEKtZ+RL2kz1yHUB5rTuDs3tHd1YeQe3ExtoL7qLyKoPkl+crLDhQvnceniRewLo4m6W9S4Jw9WZJvDf07O307ZmNySCNJKHk+6vjm5kaMe3YoILj94GR/z4q/DlRNFOXcOmE+g0t4uox7hZTJ8SCmX3InvCmP734B20L7O5FApWwHUox30+BgybamS3rau2Lm6Dhz0HebVlgly7hx0s4VHXtoVGBX15g3ozaMOEH1udYw86JOBsvGvz8HOM+RgCzl3rhvRRq/xXk9m1Js3O11m9bphWJxORfOm1iYCETk4gJw9B39rXm+XokKPj1AfvdIUs0zQOreR8P6+WvtrPAyHIq8e78Z6miDnL0KnTepXVQVOjqHXrgF117s5Vn7CHDdoHOGX9M74q+1s6KlALtwB2W4gKB45aelvDbq5A27cgGymPFJUJNBsTby7cCpqqwcVuHCxyYMWsjkCqU0WcONq40+XD59/r30u3vvBjD+1CcFDOThAuXAHMG16/wKQDeyNRvXqFWB30hwgR/I6Bpa9n4o7RhBpZwvbyIUqcHAAnD2HaurvkWoFdjvo9Rutv6YJutuRxZfeP+ScuJNM8ifaHNQ6A9sDTHfcAZRNnHFcNu6A1GuPNsfVziewfu4vxTCnG1CaDRHnqeoM2UzA4RloUVpIR4sLSR/DvxCEXchg7EGC+wd9vUEp0BPFY89OeP2v/GucO38YAwMf7mV2TMJZ2iuS9txGHm6FMZwZy/IX24b2lXUqVmmzEZ701mB748aNvhp5A17gxWciA7HvluZsV2hjA0FE+NwBMXafvkOE5i3h3kximBv/nM/KXfNynDCuWJbJvCbygNqilbgpaJ7oNBX8g+/8YTz8ngcwPfVJ7c0z9uYa9GEpV5zOC6+DwYFcq7Jpgj2fYL5xE3rzRlPEc+dg5xibe6+q0BvXcO999+GTnvIUHM9zey/uJOFDlOKvcSqloEylLy1v99XeIQvFpmxwE4Lfft3v49Gj2oy3gZgq9OgIT3j8vXjmR34kSp0xa9v2ZG2qXUlVRiUO46Qq2AgwlYL3PfgQXv+2d0IODlHQIjOFoB7vcH67wdOf9jEQzCibLbZTwbSZYgM4xBdj+ivUJoGgwF6GVPoKzA9deRRveOcHgcNzYaShqLsZZw4mvPgLXoTNyU1cOzpp58KCjJ1Y9NFepTdNbV7cnM06V0wCnD1zBtPhAX7xd16Hq8cztL8rVFWhux0OMOMPPvcTceeZCSfawLnW2bG/SGuPbwPocZQtxhNVTAJspw2OdMav/M6rcXwyQzYmO/21aTev46Oe9ER85h94Ji5fvYKqwGa78fJ5ILexKSKkcAQrDjcHOLfd4Fde9ya84733o5w5Dzs0HyKoR9fwpMfejec981Mw64w6K6qor2eotZ0yNysc6CD9lWKAb4PbCHBmmnDl+AS/9rtvwHHdWoAO6fyT42t4/rP/AD7i3jtx8/gYu6rQOmOus4uXSIvwp9LeZFW6DLa3TTYQ2gCQssE7HnoYr37jO6Cbg7ZKtwNt1Rl6fA3P+vhn4GMe9zhcvn4VVdsogUgE6PZqOmjFjNjOh24nRBQH04RzB4d45PgIv/47r0I92Dap7f2rAmznG3jOp34iNpgxn2gDza5PynbHHLpu1wTad0DM2O1O8MjVa3j7e9+POm1be8TsVW3OC6QBf2VQ6M6IjcDBHOP+1NdJtJEce8PY9twhHnjPO/EPvuvH8ff/4p90E2bv5vY+JvBZjWZbB58KtPvu792u08s0x4hTaEoiq3FfvKEqFrSu1c1VZaCyr/tac9o11qjLs5F3Jzucv3Aely6tv4ggga016BQm2xDiaeSO87qn75OS9JGGgLCfMUahdsG2Je+GkVMpeNvb349P+Nyvw8mZs5CDM2irZtEjoRSauJEKkNX4bvRPBfXoCLh2GRtRPO6xj8FnP+9ZeOjyZfzMr/4W5NwdKD0yUm0vKpfdMX71B/5vfNLHPgG7fipVsWHDJNfdO5V2MLmgzeUVf9aUbdoA3/htP4Lv+q5/h3LvvT1SkeZA3HgUP/Iv/wG+4NOejt3JHCuMO7vbAm0lgYx+8W+9b8tU8Ka334/nfPH/gsNz57AtM1AE8+Ysbn7gQ/hrf+Eb8Le//gtwfHSMfCyidsc9es5eB9bY3NtpXrsqbh7t8IKv+ht40zs+gO2ZQ0CPAREcP3IFz3nec/Gr3/vXoH3+yfgHj2TFDXfwktpk9qlWoBR81d/6fvz7H/5ZyF33QHUHAKiPPoqnPPkJeMUP/184mDoPeEiz91XmmibuGTxqVeim4Gv+xnfix3/0J3D42HtQdEaVDWrZol69hv/wz/8PfNmLPx7zTtu7dol2CpQw9pKAvjQ/Ay971Tvwwq/8C9jccQlFds3BkA1OHn4YP/09/wif9Wkfjd1udorNGa42xOlFLqMJ6XSU0t7W+9lf/bfwyt99C7aX7mgHLJSpO0QFr//P34PH3nmIuXZHqL9zWBVZ3rqxh7T380JMxnuKArztgzfxrD/xDbhx4wTTpJj0BKgVJ7sTSCl4+Y99Dz7q8RdwfLzzEYxa2zr1WtV9XpNl6QGC9LrtUILtQcHJXPGJX/wNeO/7H8Hm/BkUANPmALsrV/D8T/kE/Mz3/x3cvH4T86yYAcy1RUwN0EFOUMxPq7ZXlJQCiM64djzjD33lN+KB992P7WFzkNtZCBvUK48A04Ry6Y42tTCfYJzzt7cHdeahcw5pBKk1rq0xE8HBjat4889/Dx77+HsA1XbGu9b27ulS0puCTgPb272WFuX0y2RLb7+KZf4VIjJeDBq6B2wNCa5fz5Ht8lCLbndK09kNhktpGHbNG1glTdWj3FBw8fTpPj1Pwwhr4TXf9/RDNyUgUGClGE7uw5ravHaookhBLcA//Z4fwvGVm9hcvAvV3qea6uiORQ/51QsWfwYT/PkE9eEHcOHSBXzJl34e/sjzn4NnPvWJePxj78H14xN8zrv+Kt71jvsxndmiam2DzApstlvcd++dKEWwdXAIQ8f+j4FD6ZJYhEHYKBScP2zdXIpAd4pqc4HThPNnD9tc3WaCjR7a8v+iCq3igOvzIewBitEkOLM9gJ7UNmequ8YjKUCZcOZgi2kSnDt76HnMsNowvkcSiD4HAhytbYdnNrjr7rugb3kPRA4hdYbIhCLAyclNKAqmTXEa/QQX8oNuefVhwI943D29awU6x/YLrccQ1HZetjZnqcnVOAclIR5+J75VASAFd955JzBNLdKem5FTKZDtgTtbI9Aai0wO0rV0rAEA58+cg0wH7c0xfTuWQiCbCRfuOOdON8uYxxW08n7cK5rSdgf4+GTu8gsU7a+ZnwTTNOHa9RPUS4ddnwBoafKmzEMJX5YqiEUtACqwO5nbdMm0QxHt+xnbUG6dK97/gYfw1MddwGYzwXZOFHOSYGu+NDku6NGWwJy/VvF2s8Hh+TsAeaSdwNSHjEWAw+2EaQIODjZNjwDsdm2KbjdXzLUdmlPninlu9kfURkHaRNPZwy0Ozh5g7u+BLgVAbSMN08kxXvQFL8IHP/QhvOZ3fg+7UlAunEexOX5bf6Dds+qCYU5K2iooDYRVFbLZ4OjaVXzb9/0o/tG3/K+odY5gpGh/IehScbgbAAtAY95T04PllSJvGfVmSAfr92yLLS9f+8rJF9lr+72OuysN3Q8zKRECEwU0Zzvb+2x3J7hw/jwu7jmuMUW2FP7vs2EqshwibgW5N5kz0JDC4MIvOm81Al6ng9tRtTbhn2eoAtNmgw9+8CF8wud9LW7WgnK4bcOCMiFeKE4rDLvhjzlcBcReFFxQr1zBwbTDl/2xF+PP/skvxNOf9BhsJzQj8+g1vPeBq/iz3/ov8IpXvQmbC2f7KsA2BFlvXMXHP+Np+JRnPAWb7YTdrCilbzxHWzWded7P4+wLqdyD7S99/9Dl6/iFV7waV2/MKNs2BKV95bIe3cDj77sLz3j8vTgozRBuimBjB2iXPoxbbMmFOu/bb2mvo+3ceeN73ofXvukdODh/B4o2A6ilteHeSxfx6Z/0sbh4ZsLhZsJUBGWSHlk0Q1RrbUOJ4xyMtBdiqwjKVPDojRP8zG+8HMfYukEEKqoK5OQIL3jeJ+OxF85iO6F75p1iAhAHzQH0dbZ6BLta8Isvfw3uf+QY2GzavKfuoHUHuXkNn/pJz8CdF85gkhYh+Su2JOpqNrAvmjL3TApQFVUKjncVV49mvPL3fx835orNtGkOoTTe6W6HO+84h09+6pNw6Y6z2Gw2ONxM3VaK60VrQ40hZHN2tUVwRSZUAK968zvw9nd/ENPhIVB3nQ5gvnEDj3vM3Xj64+/B2cNNj2bg0abJH4OQ8Q/ahvArgM1UsNls8O4PPYzXvvGdkAuXwtPvxwPq0U085UlPxJMecwlaZ2jdQWs/QN/K70ODlaMZi3pNl8uEG8c7vP+hy3j3+x8EtltInfuitUbPfHQTly5dwDOf+HhcuHAWRQq2fbWtOX1mPBvvujSLDcu2/iulOUIPXr2J3/zd16FOB5AyNSgrLTLfHN/AJz7z6bh09qBHOH0NhCp2cyu7zrHy2Zxal7up4NzZA1y7foKXveLVzdHCjGl7gJsfuB8v/iMvxj/71m/C+x+6gt99/Tvwoz/1i3jZr/465MIByuG51v+0N1z6qzHHfdnmwTgQTIDMx7goM978y/8G5y+cw9FxG/UopWCzmTANZ+Tn7WBmdpfOYEpr+pyV2+3qKh6kfDbv3Wu8FdiSrOzFJ/rGeiNkLHjRFV82Z7vZxJytj4SUmGIwu7x4n+3u5ATn/Wxk2/bxYV5rA+hrlystTmWyRbjZuVhnQPa4xzCgfdRa/VjGWhXTZoN/9r0/ir/2Ld+Bwyc9AWU+BgSYMfUtP8UFInuHfXi5R4oFBfXBB/GUj/5I/LO//o143id/FG5ev4HtwRbvf/AR/OdffQV+6aW/hVe95i24cbSDnjnnqyi1nsDex1qv3YDuGg2Y577g10Ij8jJ1aJgpWemre9FB98I54OBsOAsOnQLcvAnsTiA6N8Ha7fy5IVGs9qQtEl6W9gUiCtluUC5ebGtM6PV8KhNwPENvXINoG8rTuvOyUz38qj3rT18YY8ajoFy8AJm2PRqRkLmq0GtXIdh1Y1kd7NiJTaMmFJlCtYUTPdqR8+eAwzNt7q3WtiBKK3SeoVevALUNYWO2bRVD6D/W5Ujf22Mvmj57FnJw2KXWX1ja0u0UenzUnNZ+lGjeUoQU7sWWmy4zvS8UaIuwzp7tjkPnd5+X1aMj6PGNJhvD8aMJlaj4kAPph310uZsKpvPnAZmgpS2SQrH5TYHePIbUHaBz8xlmey9sdd43nQ/HxSu036XrZhHg8LDzxeSpQtEcNz0+QT3qi/NmW9hFC7w4wulbXjgyTC97L71dZerG3+yjNB25eb3JHDpf5y7ntb1oXnUO+nyLWqdHxHcKyKU7mpMyK2R7gJPLj+IPPf85+Ft//n/FmYMtTmpBLVv8+m+/Ev/f7/93eOi978V0z900ImA0d8esgy2DogA9ap2xOTzAybveju/6x38Zf/rLPx83b54Apa18n6YMtgyePOTPJn+MVBexMUGEUp61OrzMxR3LH3XvG+JeTE2aMzqkW0u/L1JeB1t668/UdMGGl+XBBx5sc7b9fYcnJydtzvbiRfdsPuxrH9juiUjT9qDTit13b4WpI9AyVLs32Rcv7CrwGV/69Xj5q9+Gg3vuRJmPmqdbNlCd4Ft6rHzyDm24cSobzB94Pz7zs5+H7/w//youbIGbN2+gHJ7Bv/rRX8L3/sefxkPv/iBw5gDT2TNA2UBhhqWvQkRtq2ep49SGhBAYz0OSwYVwArQxAED7PtcOSD2qDWwuvQkb2GZ69bL7jJ2aAWTjrN4b6ocrtM+q2gysK3pT6YaVtvUHGVTZsPtw9WgM4bxGmfq+6Ina1Q0+KqRMsVupD8eFB93bTqyzyNDkpBmKCikF88muLxYxGvvpV7pzg5UOIkDeB5kv6Z6y9HSdbil959dE/RhbrtoQeR9d0DZdQCYulZ/Nm91WFxHtDqY7OrUZ2+bMqbcpRyyaiswHHPR2uTVtw6ptDr7vyy5TOBYAbE9423LW6Avn2fgc7UjRjDvdtD+T9sl7up7P3pO85oRnACBQF0R0zR5a10Pbax5zpcRqsRzmxFh7al/dZU4r7QW35xJUad9SJr1PddqiXnkUZy+cx5d9/gvxxZ/3udhst5hR8Mij1/CPv+v78YaXvwrlvsd0OemRuUe04Tvw9qqCNgpQNgW7y5fxh571sfiFH/y2NurH4IF8sd1dG/1sj/fbc/Z7F88GoB7zrGQIukawXYlsk9/NjjBVxHq1rx3Xb9zA5Udoztbs9tQjWZq7HcC2dXp768/+YeTTrnSU4p58py73Xml4GoK2PKPXdItO5zT8vc4VpQCve8M78OzP/zPYnbmAabvBhL5ARNpBFuERInWESIFOU4vsHnwAn/WCT8H3/pNvwfH1qxBUvPPhq/hL/9f34bW/8SronRcxnb/Qld+Anow4qm8fMSUUAvlmdJ2EMIIcabCAmEFWa4e4kQvUpqHxIRpTAlvz0tEjKz/OzYFdArQ84m+OiB2/LQqA7JKZOzuEIoaoDXQBbpwP25sTYXtzk8duabkeYbZg/BlbMgZgEXTD2JPVWOXKhtOdBY8ZNPqig/3Y6kY/umMkDWRp8YoN+8UJO10v3ELE9wCOU/SUnFl3OtnBSUP3ccDE+G/eekczz5nh8JGGvi+4DWea42BbYqIM7TzzNRnc9xz5dTBWd2rYDpjtMChZgjQ7Qaum3NVNUj+A5KsZ6jjkxS8fWanNafHI1SJaAl21pWfEXTUe1OizvkfbdXSaUI9OUC9fxsUnPg5/9X/7s/i4pz8Nl69cxYU7LuKffNf34rd//WUoj7mvOYva4tZYcEhS4mKubVpEKnSu2F6/hrf82r/HfY+9G3PVFtGyzpDfNZgcNN0LKFsMHw/2mQE7rUh2uSD/Iz6W9SYR2A/wnq33ld6CJqN5eWhH+2yR7Wlv/WnyY9Nwm962LgDRiNMmrPc2ZC1CHe7d9p6qPflXMu0tcwRhY6Qpqy3G+G+vei12V29iunQ3UGcL0nqdM+yoMwDgg+UVBSjA/NAjeMYznoR//q3fjGuXr2Cz3eClr3sHvulbvwNXH3wEm494LFQn2L7FXnsYB7Fl9h0ARcxUuHFqQGb22wxL1oJw5AYj5P8uvT5ezqBd4dPvKD6A1UDEuoa9e/YI0CLhpjjSJ3fZSGqYHI0uHlTNI8BB5Kk9CotgPY1FQMYrp7+XPypQar+0YXHxouEnNDFfpR/o0YdoG0/J2GCfvNP2DF4daj6Ptc1e3djbEPJsotOHWXt7vL29COeHWHxkfWJwo8FmJd4taO7tyZjq7oWlDxBEnPAFQZ9XgMll8J8ghxwBicJcOHy6gUA4RqvIGaH2ND6b08pdl7VBSJ/MwbG2eH+ZnVFA254bOunKWQsTZHUHhuUUiVfhrCL6t0xMGOAnrLVkmzNb4MLj8ejVG/ib3/oP8bX/85/CF/zhz8L9H3oY3/R1X4u/fe063vx7b0C5+x5A7ZCKaLz3kbPRRqxmyHaDmzdv4NWvfxP+8GOfBxsB5L4WJm1xKcnAMsG4xSfKzZcMn4tnwwNlejhgo8g20XBK+Qu7YGXcCsRPgTW7Cpc/zoOuNnb05ui+2Qr+DtW06IH/xkblbSb0DMjGdk+794b+bmdoQYKGGvzGy1/TolMzYNK3ZEDhh5B71Nm/1xmQHeZrV3HmXMG3/dVvatt4RPCrr34L/txf/vu4euUapnvubfvh+wo/NdooijMANlg0Aypl6kBvBzG0Fap8GpLaPZkgZWpp7Fg+iyis5O5R81t3mmGo/QQkjYiNBFa7NNu8ldipVr3eZoX7nJYjsJVvJyOFcec+8I6AyZak9qH0fYEQ8No+aNShqT3V93wCoGE89TlPpb5sC3TmNheqCql1McLA9bS2dPAXgWLqe3CN/60P2l9fYEd8i+8TfAFLXxMgzm8aWtTqhttBqKrty2pt7acNiclp7W+E8c/+Osj+58dZOqAY2AtsRasarSip37H4M2CiSNDepoM2TKyV+ojotT8bUg3+19RetWdAHPLAlzmtfMu9Rusn0pf+17bElKDVwNRttFBfwOeRvR3WBv6e5E99S5swf1CabptsaJ9yKf0tYl2ebMRDZdNHpwoqCuqs2NxxHrj0GHzfd30//v1P/mfce/edePTyI/imr/4qXHrs3dBr1yGTzdeaI2JeVUyj2VoE2wI1n8z4zz//srb2oWZ76ZArAnF9TEynLjkdnMY0+8DZdkGYW2lOMf+5X9fbxji0uHxUzytx4lcxI6WhYvb+WM+jADZeeVpPb2kX7PSyb8nK0asw4zcMPy2GgDWkPdXT77kX4w9uw6UIGQuDiTYXcXJygpe/8nWQC2dRmOFWvyrCDewOiXU4tqiXH8T/589/A57xtCfg2vUbeOsHHsJf/Nv/GLtasblwAXU+hi1DaEptQGsGJYYgM1clvCpuhrIQ8RYNE8U2lKPebGntshIUaMNcXF94v+teX9BHbhTYwDVHjSIofkGDORNrzRwkSdx4MycibdDdO9UNmLpNWUgofRX/rUQTR0mWjvjhBHTwFeyJaqwzWv3LmS6zeeQAMYEKjNvvlWiM5/u9chmf6nraVIMi12r4y03C8JBkR4KpYYJNWBG8XIJkcEGpDO9WWyzEkYrXHvLFlsJokSXh9HwgItGjYG604obFaDJkVWIYO36mHyx/wt/JnvnNQtUzMMThGdJPDpu2BfjIJ+LH//2P4e5Ld+FFn/5puPLoo/hf/vSfxLf/i+/ErGfD6VDAjtf04x9Vu+PTTz8rAhxu8Tu/93rMqm2VtdMfIwRd1XPDbueygGnNWSImjEHfLS8lufnwKEr5bwvXEKTKIAchDstdOgLhfbYaYMRCtCcMl1RbS7sgdCW/lRGES2a+D/tRXlUS/5w/N3Yod6zX2tjzyCS4//6H8e73fgCyPRdKRZW5zXCDp21RUCnYXXkUj3nqk/Hlf+zFuHzlOk6k4C/9g/8b1y9fxfaeu6DzCWBQ11cur81NZjilRqkkCcgbuhlOB57YsKOEIZIVHvGeCqHyiKUDZeIk6jCm2A43WRHWBCDKtxGGOhwwG65bc4wTdSYfq7KgqbrMVc0vamJZTM5H96UleNceddqGhWHBmlETQf0jzvLQH2Oo/eMTCNQG8efBSU3lUyGLX2sGKDeJh0Q7nebcmhpq8FSIPnZOo64udSYX5mjvoYOXIfn9SnYGg3yTcRwzRjLrH0oiuRweUgzJ0pTdqmD8Sw2hyAj0NR6lH1nSbZy/FxxylRtnC7XabJZxpY2+lUlQH3Mfvv/f/kd89FOfhjsOt/iEpz8Vf/BTPwW/+RuvBC7d2UczrCI7crPGEZQ6Q1GBnUK2W7zz3e/FzRtHOHP2sG9pc1YG4Bq/Eg9JH1n+GUgH/lNO4ilSGprooiTLoWoHckLDfbLvb5BbGBpfkRNtzDlXSuQnJtGDjks7izC3jt22PW6C5VBSpJygNzi7cW4cQ1ywYiz35MUaY5bDzrbyLv22akgfat9C8cEHH8bxyQnK9jCo6tJFKh0N758iE3DtKr78816MOy8c4MyZQ3znv/9JvP3lr8Pmrjsxn5xgVmA2J0R5eJYAl/mZm5v5n+5lrU4cyBjobdCBL5woWK2LZ2zrE50y1L0gmiwVCb/mzieQYdpbLW1l52BYzTCNoybmRQkWp8yYrJq8LiTWSQ7F2AcPtpgn8nYGpnblgpXb3u+7YWDjk2pUUkEDYaNgrZ+U+if/MrpGOYv7Y5qlIeJ8C2gkAArZiIU9vlhPsOSTfeeIcM9wXkSrsQXPIjddc9A0WhNyK/yrt72nWehHcNPzpEoycIzDnmuX8wEMBCF3EPFV6PZnuss7IUwz5lkhhwfYVcV3/eiPY7Pd4tErV/DZn/Y8bKYSW8WsdtX0Vqz0pxXlcIsr16/jgQcuh+0c+mH/tU9rsNKvOjyO3+sQybXssVNY3F69Ti/9tKYO4D44C62bxinSkLWVfT2nczUb9gEU+f7ab/JwE1gnQV0z4PB5YB3Syoqhi9XCK7RRfSKC93/oMnZHM8q0afWW4gKetvmk9kyYT3aYLl3AH/qUT8bJ0Qne/O4P4Ide8tPY3Hc36jxDoX3vMhCHDTSBtjkdG0lIMt/8ERqiUJhHHltxwhgm4yrBHx5qNmCz6MqsikUs/p/0PzNAyis4ydiQUQlDT0ZJ2DtElG09G2PfbuDU6bMk/D1YYdbKhuCSLFEZbvRU4W+UUZpLS5yLvKHImvnj/cfYPDgUNkxmkQjU1xo0zpNVcHAKWQ49iMZmZ3KBJkMa0g125qzM1FOcjtIQXS433s9EvoF0dAkoJ5Wp2VpT+w33nAZqi29F4/aZx7US0YyaHvpFqZyvdK/rjOtOcNXLWci8UvlA6qMkd6ERQaEA2s9Wb+ooXp/NGccq6MxRyxP8bd/rbka58068/dWvwWve9GZAJtx3z1144lM/EnrtWreHsXZBXY/7CnuTVq0oZYOjqzfwpre8E1DENjFEe0dmm8xnhzL3RUrcDRyfWRDTiNQw1hG2IYJk21OPjk74kph83/FjzWm2flgDWfXykokMfzCToLC3k98K64m2Pd9PvcYGEhUr7PD74+q16JS+yGqgQMzAsaKQdvOzduqS4P0fehCy2aBstm2BQumLXWhrSUQ8IRh6MuP8pbvxEU++D3ffdQ7/4Sd/FkeXH4WcOWgn4piBoSX/PKRm/mmOouy5GfUmlNoVMHHMgVBJQYNPS/4nzvZylwbQwN2J9CKXvS1W9nixhGH5tbXtVtJDyqQY5CTzEUM7+D2mzZCQwncD39g2EOX1jbLKZK3wofNNh3bxqudW7T7eArx9aPVTqL8XRMXvwe8kZ85kaszKYUHI4KKZSZeG/KkxBpQrSS1JosOk2uSYmrwQY6X0QbPYbTeQ3Tk31V2RR7Mt9tILq69bl+wYpbYJRl6vo0/mdc7Bsmjf8zY6owP0GQjEpYm/GKJOW/zcS3+7rZ+rJ/i4j/sY4PgYvpLeymC++/3W5jIVqM546OHL/eUF3IB1GRj3MC+mBjmnjOkH7q2wfawr6diarRt/u33Yhzmn2CI59Wmmd2zI8NMj2/UMa4XHamLueh2fc1HkHa4Bb9b9FWMmw97JsR3uJa3QO9hTsz2W/m3v+WCzc6X4CUW2Cja0NYAWUqAKbA4Pce3hy/iR//SL+LVXvAX/5VdeCrl4sa3wIxW0vZm8AtiMv+Fa3+npDgayy9BH381YBkia7UkLzbqB5ygsRy/NKrHzGGpoEZZhrjjDRhk2QyKmQWzPBt0en61edD/6V5zWVuaKDDEwCNzwWLuTcyhGJxEi0RdjdG1ODuf3cmUwswv+xOISjvNdN6RRudgbrrnMGPVsvTOKufZngxLCnDSA+914ol5PvMItGpAAOYGV8SFY6P4eyYE7mkGgy5I5QEDIqDsEQnJkQ8TeTgKlRGuUCEgM5Xk7YoQC1L+cq7VjbXFgXhCYFnopy8rAH08bq3bND1BnoKQuWwzZy0CL8YrBkvtursCFO/Cm1/w+3vfgQzhz8W68+e3vBA62ULXTubqdEaW6WXmirUcnJ8buoAnLa9SP1AbN+uQFrgRQGUJDuITSj46s6zPbDudVjBg5Lf17sgkI/OA/peM8F1OV9C/7+SmVZu4C9CICm/jOEcdIWvxazp9SJcYgA5ZFTJ11uX1ZB9m1elxhRNJv1wvOsjrcEMby0WtXgakDbZld8exEnaZwXVFtKMaGCbcH+I7v/H78y3N3QEtp581qJUIw1J2Njfem84aNbzYK0rVVYfUnhoTR6+mV+CMivuAEQuaJPNClCVJi2J6+TkrDt4nnmTCnV1O6XL5SvdoNqDkVQ0EJX1z2PCfb7qzgxm8zqNpXTY0HNCzaoyaX2RDBPW7uARA9xC4JUi2dLwpjfjH4GJC5DHXaJReYOWSMI/Af5NLn3rsBF8oW98UB2nnS26ZU74JxxhcBOSg0VJ6IzXbH8GTtGiMn5exj9EIsVNobziE089B7K3WYgeeSllVDbPQlq269xvfF+b+wfhVu8F2frWEeqZoAChTtxLN65gD/8t/+ILRMuPLBDwIX7miHVvg7c2OBYGCrcA3Ov7xFMz8fbfPeka/htwFfVKTu0gT/wlLGPdpzzkT+v7waO7OuBmn77Z7RGaNNtMiQZMdFToe3/izkcCkCK4yyPJLSuEfC6RdeaXRqbsuyXi+XACl3E8JYesGLEoavRGenyL0l0stwDPqK4u4lT9stcPe9PUU/Tzd6AGpHBXZeLZwDM8zuPCABhphpVc3CTcrs87CWl+g1/rhBN4PBB0tYXSnykSF/MG0EI44Ukt/AIOKghmScXU4yO4IvboyIHxqVcaDqw+zWpJEG5e9OfuszMUVZGs4cCVn78vrIVrcOkXTw3iNYj06HYUpyTIEA8rQuQQF/rykz24CM6WVjH8LbjW0AMCMS2Yy4Xam/R3Ac+t4cAW+7gXIyjjFe0/pSIo1HbpQ8uQ0mp4g3kzHYd53kuqKcDhzGH4QDYA0zHobTYY6BtxA+X0jlR/8MOuY8QsfUaLnbHpZna5vJPqv0EKwkfSRrrrUC2w0euXwd0BOU8+dR55Nmt+zkqj5dYbLWHPeCRDRM3tiBlMRe67c0ysb9Ndh+l4IRwIZ8jd1OXaqSbYXbfgIzJ12prCEw46QA/BWxTlvyoINmoyugcZzGNHdlAB1nnWKzaGhvJhvp067TgBHUqD2ZV5/nBRFBnDhng8pcHkZt3UOAldMO2d7nLXls1AFZujVgQ9s6p50FK0lIuMfJOA80jVH68gpjsEZjarcrbfDJPVYCfZNIBhMvioTNlIlXJSbvkg2a2Xi/35Wwau5nR4UAh2XLOzh7u/g73ChbUfZQgFj5yoCiSG2IdoZ6KAA/dNjBd4XHgLsf4TNlWedfnk0RWz16fyw8dXQjwnZKRh6pi6R2/kZ3KJiZYbypv2kPNteaDE4wyTuWHVxvoxMRxo+xwWki+Q9mItEtmXng/ldEO2IYFTQ3Pyo98y7fE8CdFpOaWKBlzc6AyUFF+k6gHHfCdgXABLwlMhe3iE6TQydseOZ1mNPSa5hnlK1AdQOdT/zEOxLW1AaBBQRNm6TbQzti8LTr9MV7SIKg6Z5m/iKZktNKTEqmPCqwp5y9+NQTi2Va2LRM51hKXkw5lm10UbAlvs/21qA61ORfBzz0TxkEeLzGsf40p8QG3xFkLGCodMmNMAanSQ0prmiPWvPGym61CHCpXBUDWjOCTFgoouuLW9J4FlFm5ouSN5lXKwbwgT6hNh9IUSspmcIMiTkKzOOeXsJo7wX4qG55OAaFt9bKGLYSp5dByI2odAF1Ur7VYgABAABJREFU7vUylOgboilAImroIBkrnIMsqPoxlz6vnYxZ9LVvofX+CV60OXN4X1n0mUYkPNJttIe4WKTb0ue5dtIfGsEwfQiQkdQ3MRpihEaDAnuj76X/IkxbRCHdknkvxMEfUX/IukZ9zuqs9VZnRPDKxSMivA4aykPeNDrDhlA0RiQ0FmS5bQPdS3URyd5uMhLGc1h1wcvEH1D7WX5oRCGOrLT8xrts0NMipYUdM85nmwGQ7hnpqqHbRhc5O9HnNL1nNJru9ZeHtNdEki0cogReQe42dI9Nz+2x0UQjiOzjCq85wEoBIPMpNS7b1bXLndf03CxO0BUgPrhzGrZ4Gajn0VYzC6LawXaFJmfiGr0Uwa1dZvzWs8p4Y08p9GzsM1m5t6jwNISN/K2ddNSan7ICOlOClKAI2rGJ2o9Xa/MlOtd+bkUl0pS60NpiyqGOH6tItmiykF45erVnAzAG+Oa60jOrin2D/pnsQRCQ2Wegxfm7EMfKaXsckSIb+8jPBkt9jt+MHZcV835RMRsRMyzefOIvRwRhY10QIg3zkxTdbSnxwumxXh752X/4AiEBtL9OzR0sSPAztZ/7Kgy1Ot/ynKmDmnHdrAVHjgm8RgMZKZj2sAXGexBQOXciLUHeGj8YaK1iW1GsQ+Jwtkf9ETeKCkqiZDSDE1Rh5/kK/xl4xog4FTOCHrPCadaFDnlETU1h/bH7Ib9dbpMd6YnVHBaNP+m2C+agtfdAO6uoXyjkin7t4Ctir1oI13dhDoRkdjS1o00flCaPdjAvgxmLIrHnckQ0gF3LzaS4Z7BaA6nMLSHEaN03OpniHbE52+GoxoXlGWhK9omjlJRuEPi1aHgFaMc5HqKG8twCMIzOvdxqxtpWy41nm4bykED2D2ttnSv00YehskE5d67TXd3w8dCfKe44/LqcSxwsuRkTn/u1qEh6P4TPa6xJq5IXzEOqw70zU85k3O2eQUnQGEOdptQLTkUU1XkcQ9LUNieR5itHmpNxCkPbSNe+kC0DxsgP96QTqGdFWJMWjlxX58ydlzHiEQY82kbmt7enJJ74qAWsSMnPdejbDnZKdJrSj3OsXJ4DCbU/2kAgvewC70uvr+fLvAaNCnSQMCfBolqv3xyQoSKEjrVjR5NkBJUu+2SQrIhk/NR54D4DBv5aq6l/rWZfJ8L9aY1Q7dtjrOaBjnxUGZlA4oWC+N/bNaC3pnKojdrmYNvv2WnQkxl6dA1AAQ7PQLZbF/R2fkAxjSaEz9J/O+8x56mZ8Zv3AXKfDNrQyyD9BJJTDOXuJfmWuAfvQ6sgFjBx4JH1xX94toRRbIaH/rgtDLa8CtibkOjlpmspl7dGoF1LZiy3v0R9YoymRrRb+d6ChIW7uE7n6j2u1opStEijVojO6ZB2oQxKdNd5xtmt4H/6ii/DZ734BZCja6m9ZluMjvg9tI2BFiQELDmjklGbJcuoaThgvnAHJDMDZnS8XzQGFBdDPtQA5kNyIASo9rJvIsF4lQ0xR1ccfYZ3zJ68tQSQ3OW9IWqduPAmbSqAGDM0TSvf6P77IP9LLzUsQKZHCbA693UZ1XiZIt4PQUGUI0Sfwfg4cgEDVjM+xmwGD9YLxxBJ5TZOW3skqSPLsECA0ujItq5XTKCeIpj+r28zsrzOLo0/kkUxILaCOz/dMSK9aTogQ3/xHHPwwks3OU7Vky0jOXdHrWcQqt/xeeCz7pE78jlAFcCA140Fl49si1Q1XhbiL5boZxvXivlkB+gOz/vDL8TnfMkX4eDwAPV418+0qM7L6AOixfmT7VWyO8Ol6fYywSlm2Hk1xs06fHEWJ2OHMOQrGUNb4xIsKTR7lRSW+xRrIRszruvUSuDY7kcZsRp5jSsrBaQhpZXhglOZSxFBBhelJMsyjbwlGI00EWtWBSkXq0pfdPaDz12CGC3QgaEU1Bs38JxnfRL+4p/9k/j9t74X/+3XXobjub2A2YaRA6pCsX0MgEBChnvscZuHFqtQu8dtUUWKNDofJGY2PJpx5S0LQ8Hevyu+l7DyPAk7MVeV9gaOc5EMVBzFrbTD+Lwa9TNfB1lRa5Pm9L1NBiiCiCi8DANn1nLSYyGaAkL6M7NMC3RdU3i2znmdArcz6KMVtCs8Mb57+trbzF68MY3Isz5JPTTKAuD961X1cgRD+Uow6Wl6K+0fOud7ZJc5Tnl0h6cKiP9kOwKIJFgLK3/of4RchkzmfuhI2ztsCSEGkgHj3PbcsKCF5xm5f8X7ynlgNsH03VWVf/f09pYu1QaimAEU6NERLn3k4/E5n/uHsSnAm37/jXjn698COTeR7FkHSfR5cBp2frJj2alGnfqReTXcT+lWt9lpSsj05DKT59QfsHCT5VWCQ+G+GpwXKkaGcnQsf+U6HWj7p0je+kPJkmKni4BiPectLo5wScD2lbW2R9efdXpW5w1Wy2Or04TOX/DchVaNxnSIb3RzqYDMx7h49hAPfeBDOLp6GdNGgJMKf2OHkWsbo6266ElDOpjguFHltlKewXGHZxqKXYi5knixsDGweArqD11Ge2Ez2BAJCWZErz4D4VGCUFVhjU0R2OAl9e9tMg/R+2Joe6yhstpIRYXpQeTv9DEIAOjRYfZox6GnRlbPNNRt9zmad6Xt71f1l4QbLcp0Rxt5btVAxq9BfaQsQd9bQkY/zayKkriNs11ZdhZR2Zhah75JabOBTEOJrr+CpO4rR3ZamtxM9e3tPBNoNEVXR/s5r02XxOo6Qjr7xvJj/UXtY3BdA2yTf+9TLguUJVVoLBh45zJL4KkNJFs/TXj44YcxTX3kSSpESqpQO6guGmDB0Frg1Mkgfz3LH7d2H35gaa+TQ3LaleSJb1LtQxp+yliiEnKSADWNzNyKptOfZz9cCWwZhzL5w00ytIPUZ2cjiLccqQqKcjmNch4WuoXll6U87yV6/fIhR4sczIMcLHh4/dYIxfFJRSnbzoOuzmu8T0pitwy8oz6B6fo4D8bbQ4a5VTKUo9fv7SGmcHRm6XyxglgkwRFcRIhBjzMPyTJ2Q+fDm2BlE1/MsYjOSKmDPjbujCiRL81BahjZpDPMD3OuQH3pxrc/V+LY4AjmCAkuE+oCo94GHyHwPHlOlkGtpS+9HWT4uTHe9KAp5T+Nl2rGPeRznxHx4GJwHjwarDFH7zSopgEO6pCFSWGe8ZqC1J8utTHCIhDfNpXkxwu17zwiE0aurTrXQX7hPEf3xpTZ5N2Y+ct6znPuxj+TSYvoWxbiRFRHfU66zn2KeO78MHkKroJH9lAKZgWqCjbFXq4pvc5WUeovo9nBNs5QBvXJGpix9jAJ8SzzaS0oWh+t7GsgItFAbpbfxUDvgL/L4kMQRjqp0OgylgHPdXtAw/YinSCVBhNYoNeuUyLSBJh7E2XDocOzdXMw1D0m+jCAthWz9DCCIrMWElGQ42ozMDOAWjYopS8mKAU6t+g4trp2MAOyUiCMwWLFJSQpGKicvIgp6K+1wuZjOZpMua3XexNVua5eX4rISAbst0dYAzOdLGu1InOAwMjzDLyXbCyjBV06JVqUgYBBkYoV4eAoACRZU2YOkM7JY0+IFC7jMCkuRwdepXC3xvGWLguxGCeALIzNSEa+Fo3zxEMg7qDUpiH8ZgJV2DMzzpbNZNHAR2QhH25UrAcH4wmgz2Iw2g0yiVFH2vfYYsaGjypFTu+lm/4GspKxyUOnJuPtUW8JYU2uN/ibTIgXwkSA9JGwDdyfNLyd7K7JFf82kNCgxZwRSyOKqooKgUrp/VWCYCntt+SxPqY5pjiwlCXke1zAPru9b6h1bSosbDD/RtyV4FfUSnp7O1cKFBYeQP65zLz+ZKVuTykdbEX62x38IqOxwiQ3Cnui2jFH+q16a35QudFJZG1YWIUUdOjpxSKXFVFIkaxbmCi8AS2bvi4UKqgqmGsy9bkTuebBGUrRslXp3jsC8AS0j5Tm0zqdo7os5v/oufeb5K7l6DjNjTm/LR9v8ehUa64rRwOdRjpEICLWaHNqgdHloMFGsgMTR2wafBnnPFt3hvFzoBUDhAygSpRwZGj9F6uIw2h6XgMhNs7EL+Nj6nBI71sjVr1PuZtjBERgETODVkTDwwI2z9LbSf2cHFrjpbQRDo74efQq+yEaKunEcvsRfWWcddAA8ZF5HvSpgSyiM+3oz5AJiboVi5Ol2HawXBNj3GlwfUz9Dhdi1s88ohRdymDpOjLoh7fYm2DMyvOJPqLE+s8XG0BIyEwfZavaFupz8gayvU89ghhGWczB0RXgXAFa8t2HG8kq+u88R0p9ZPqOHPTtnQ+NBO7kRTaJvLpoRavOPikozHSSrO6hYaCE+sRJ80+RPme7JEdIEVYI3QOy+66U5lTCsdpZnaSwcBii5j1EjJPf+y8xjnSljRqi/wTo3iDQhHbW5kEaj/tglZPrILcAxF4cpXSDMLaHvXEd2RB5kyFlcXUDaQKY76evauIeXKbtrAQBmXWez20UWdyhPXlIPNIavywKieapg1dk5QLJaIG5aQZGg+FMDIFXXARgVlb/x14pJ3ZziGbTNMPK7yC3948M96h/F5onZILyA6xXo4vmcnpZ78mB0Aw4WefZeWChHNR26JOhAkoWowW5awVp3haDPKXErriZDpedbIBD6nRIl5oTlEi01fWD8rjDlXOBFdpdVO6zUwyT8BfltMRz5pnZMCmYVdu7tF0325CyuoaPl6b6llQNSIIlDgjWgUmpncHbtRpG5F6/3PFJV+Z13N4PuIlw/036TOTsg+x4FahbjFw40blJFSZtFoisVHEa0JJy8VL6MDxkpIayooihQ5OHtEbPSN5g/PZTO9bcTL0oIMVZEYvkog0CRdWKXdX+EnpLxENBJLwagGG0ddva2S59VWI3qcLdZgCuVJb4EwMaj2BE3AimIeFkmHgBnFCx6t85fGPAtY8Y3QjWxBCYzS3B+zzPH0afeHMogl2uWA4+2qk8vvimAmLD+KqQklcuj3OXeRh4GPI0IzyIjlIbRs/c+jPqM94oopN7fhBgm7xYO6l/zdvOKmllsGREt1qZib9maEFz70p1Jf6Gw7ZoryD3S+d9XhOgnfZeL/Oq5zEZdZvAIEGOjqok2Y3I3YCS519DAJPhs/oHWvIiNsqumYdpmoKinXDurG7A1jq0soK3QeOae6PRps47XlXtTjPJZqK7tzPHwwa2wAzFXFswwJYzOazeBrPJmkBxHUAs+4o9pSiRI/WoT5yHIEdxTDtOF/H0jKcjJW0nia1jlb+X3GgYaE/4zGUCSQaGgi1nxobFFboCBZ0gZTf7US7jysLbvU5LbtWswt5aRXsrJwu/yCLDbxbedZrCIzSvjwQX9jUET9HmSOfdjN1uh3YYBmDDQf2H96QC6exkAGkBhdlSM8ipmd7c6CTWl5Sul+HcMQVOiNLTEDDlwE/7GcGOglRR7ru02pSNl5HrzoPP2KboNwOJfZJRsYIMhA1wzNlQALzI0uuRBHwewVjxpgN+lCK1V83YZ3JiODQWe0XHRR9FAEQgqkSbwp2nvEAtZIuwsn+J9GYP08ISIaNLhiV556MTi/G+tV9oTjdfHK0bMKRFVRA/q3lfxO+94/xeMWb8wgUmzehSA6EMbCZvZkBdHEmvdJQryu/jB5JpWkRco56xLBPd1rehtayDA5BQf9rRrwmChHgWjIRoiTOCfX62gVrVmp1VJo/lh/jigGsyzlfv631A2wtaPuvPk6qPeb1+JB72LMnEjUkWNpNfXjLybCiPQTVdI//3XAk6O0742hkrqtO0WRCLIdUCvMhHGxi7dh5yrjSnX0s3Nl4WbB3qkOztp8JNz7vyjAIvYGMsSJbbrC0ZUDMCqsBuVuzmit1ubkeiVQV0htbZCUie68AHXgzUblqd6hLny9NpTjIrQbRpyUsz4oPh6HUL0A9PGOZZuzbwHEgyVCZIZCy5fTZQBTIkEYEjpee6eB1AcpAMTLoDw9FWi9g6H8gQeyRkhhksUzVY2MFlfOuAGW6jnWmEtZ3oX2iWAOmNNs67oIm8jv7V5rwtKh7QxntCF30q1MbUjz2LR7ZWVIoAl/2cDCLLm0UQLKcmS/ZzNIdUbRTO/I4+9X6y6HV0WAY9zyM3IyhqbnOwL+TJ2tNlQL3vbMFUtCXJr2SrZGCurp/9tsuvUt3RX6EHSO1vd21bjtLZ4MFDTi8oUFSg9IVPKKgAZmfbEm3znHanhgBXxgzUVi6PncTF4kdPJ10UGkFprcoaZgzPzTqfhivREpMvVq79oJmAVoZ2DjTuD9hGIzCU1Z9vuMPz563nddZhcH8avreI4lKC3gEOhHxZTVby8FyH73sraVexiLb/VVPetUIVbStbrZhrxW6ecTLP0LmiVkWpHWwdI+LVVVmwh1XF3DJXhn6PjqzDIMzNIIRxjcfhdechwywwsYCg85lYK2xQCMTgv0cOabrnERvT2o2796kZH6OdwIgNrRBwpQVQVqSVZa0lPqDzKEWoo7EHr4IWbx/zKx8hR3JHhjTSK9IbEdxQ2jMCWjeoUaQDizVmjMKsD/i3facyBkx3Ay9Gp8CjeKX0aVEUxmsAPAfZ8TEBJZtukiOTbLeNJF/ri1u6TAXqjQFa/53zxaL9cRDe2mpqYHK+fL7YqJ1oiq5qDGx9n7f/UK3O8CjFu42BwojvMpcdVrpEYC8QgLSVyRUNrsPhz8bfAD6Y3/6cj0VCH1NVkj6DZi5+hUeDbVgDrn1gto5Dg1xZGbDW2d0VZ6FVNla+/O2O6+1cZLi5DpKlzbIlBHBrtTARo1LKsvHth+b7pkxcLHeQG7jlfKGR5blZEZTExQzKLQA3CVVnDHecR2WAe5OqilpnzPOMebdrka1qe5+kzj1/8zZj+HkAPauA6ho98QDfoIiHhcQTx3Btu9Vhtr/BJveFUP5oD0eRRqTPgRGINN0kwTJ+Eb9bMVFOAGrM44pHoE0hHFzdYw8+WJ7FiEBnUJuXyQBsZfFoxto8onOQDLLTmDqL+sVoCYiGq7iC5jytTwONI3KJ+zrk98uMrPedukFl4+zugubMFjEbzdnQBC/8NKNOV1JFo8xXKQe6LSJSz0R2gWR9bYQlIvGW2MtitqGDl3GLPIo8IsLOmEY97kjmOeVFfQ44DSjFXrmIkF+n1eWKphW8XfD+DIAkXvOlmiTBMjS+EQ/F+tibTo4FG/UmlQ62QHf6Qw+ynPQ2c8GaUID6tX/sAVp1HqYbQxGykIWxzMyekNlxGk5Xzu7PC/4H6O36vYqzg3M5UnNKaMjELkFb23SdwE6QGrwstUr3AdVCcRf2aPE7sq4UqJrS5Rf6rrVqbNCejiIjvu8qw4Hb0Roz/lZS/yEhsLXOqNXOJe2KkiJOGuZK5dnPYPAYgTID4ytZLptbR9yy9GGcc38omoBaG/1ZMm6kdERiGrZ042RGAUkmIrqzmuy3fbTvw7IIIjy8CRthEQTQ+nwhshJk2SIHQvMzN9ASxm/ko1iTqERO4H1qfW7RmnZgWIvMmI+9/1keRhAG1kWbwdfuqBHFzgqM99Zu45dk/qR2coXUp0RTSiaAKG+1GZm2YkaG/gCzKoXm3OCYVlFqBRxM2XngosmOEM2tFJKpElXyEZxLXg/tT3S3Atw553SJG1xE1+XBEQo2qNPLySEUnVplRSBlAiCYYa+Eb7wZuy93vCIzm9ZW7MOA/iyPCkWrVud1YfbnNoCLylgEZvmfvVdGpiUORj2RftldzJfBVoxJkdnsdhFNjzdWntrnEIUuCyXhJmL2geyY33+PUca+i8ofh5+8NMeFFWNwqrRwRw55u9HMzDYDoFCtLbKts0dnZsr89xhxi83/Gk0D/f2ZzTkmKCYLanO4LLYM0OwBB8dafhOGNhdpoBURmvPWE5LyWP7kMSznUZ3zQ/TCtC/nF+k+t5eclRSUqi7a7xEFSbwm+mxlrvE7lAepvqDH2268zIx1XqX57P7bl2ZRHo7MfDRiBEgTO4lVliz/o3PKTk40gxaSOTuWc/jpN9PF8pT4R9Va6SO/42c4XkOfe3lDhKkuB8TDpIY8RxuULEy7RnvHvgzRDsnXDhzR95rf9tIBLjWW+iOBlZg8kqGnFOE8JEa63jvYeVtDP91F5ojY6tfibay1b/1xOtsfD93nbSvD99NsMtGcpgVW5v9Tv0jksfbGo7yGZT/Qjiuwx1pCcH1EY418dgb0lLaL5DacdskK2vQbAmDTvJ5BgOQ0Xq/PNw5lR/exYo8lyellOT29nLxoov0rmjtp3eVgwGSjJijFlkdRx6kVNCgRtbB2gQ6QE2e283Tst+HL6nAMGVyrb7HoJeE4CYpF1bnxTp89Y6/V+8mdAEtAYjMAdxJyN9bLBWhY6182pIFMS34AdGpQu2OREw95aeKzUnoQcDL9vakR+vnvBGiRMpEv3C7JbbRno9OR8nP5FFW7gSDEDXqGaEC60dUoRsb8CYqoSnOA/JliJJUXaQVfFTwFsdKwdaNEBsHkJOZQw8loAzVZP+lL54GzKWyB0bdWOStcTyfePntifcCGfsjrCjfYxcGupKpIHqMVNqJiyltJGbscmwzX6HsnYWGLBgDvDqiqYmf8grTdBQ64yCoc+71SuSK0jmPl0vQvuwJLfUk0yjqAjtf++dsRWJdUjbdMxvZewnw5LeEtrhFp3RtqP9PWHxnSrlbLka8uGct1+GKToX4vxzzbPTQzWEe0l4HHjcXCpciwvBgG6oJUTKi6cXErzxFOptyL281zHw0YOSArOXLVUI7k+m3qbIF0TzEWBHGkmCJDu2f1CintQE+e4wINQwmT1suNCFN6lG8kjrS0IoeFDywrXmd41+YoxVwvDRCac5XKg/dHI1mBqn1uzcqK9nLEDaaZaGn8InUfoogUhffGx7oAixyG/mUBjjDNjTA70jEHH6jkJyUxDw2QmBWyxnPrOyNxZW7UPgXRvtoBdcU7DL4SD6xZXpnS2d/BX7X7ln/BK3W0VedvtCGpbedVGilgwBs6w7RXiHfqLKL5dtedPByf+NH5hB7xhmxQeibceDaEr41nAbQxp288Y5ExGpgFIS8y1GusmGfFSZ0x+Wm82bL7tuBBppJbcEvMiT4g4hZYA8ku+FisA3SSpwzAaTRk5cqYNeBN+qkhwp22ZKMWxNG6jf/ei7p3oywknfIRNP+7rtvxEGj4aO3+osj+r7pZXhqGPT9XSzI6fdgMCOOAoXNdyBuDFMDJrvmPUia4RSmld6jsJ6KDRigUG/v+wRsY0yEVyMbAPWLAV8DG7dy36MNjZlpoiCzAWfzfRHDXGHFDu6I2pzA9hNtuxMIqpVSmmAvvl7wAdx3YTg1zQavfSev3ec6jgvEoSLtNxt0BdUXcnbXRH2Tpqb70sSr3GJ+R5RIuf0xsQIAV+rwIIfozUOXvmdCEybpi1AwQep409bAy2tEc77zIKzB1NLzWR2SsVwxAOEV0mx2w8DaCbHfARiICjF0UScfCsQjActnuaSXZ2n0yGcCSMT/1wtqX1t0KSCmYpoKpoB/4YhrDsGdfJYFkK4MIN9qZj4nvAxkJS9blia9ke0lPFo72LS/B2LxFvaNyZU/O5ZCfs+ruKTXuSuunxahAl5PNaPHWDo3K9AZRHJUl4ongheFU4uy+iIhzc8Tl8mlzO+q/vcEuWLdeP+Y619PbUng+QYcZHu2bcHOnOLzzTsjNGbMGAAOgucC1OS64cBPuOC1JyUToXo5OeGWu8djtK4b83mc8HwYy1u0Hzxk3YGaQCUO1eN4LTaf3DX0aNqZxhed4xzlg50nPKIlBZPR6mzliFSDxyphhdqV9hIFOoBLhYDrY3fnZ6Q8bpClfY/FyLo4dguQgkKPk9A1AROY3tZ8VOY9irF2U3qpnHDIDJ8jRKfFrpcTFj9WTxhBtihEYar97IC65/jRkribjHk5qN27I8hk3MPRBPNcuXIs5Y7YpYkYf0CGNWaWYV+25Fm8PYoZ2usc6yfi6XiqRTjpm9bN4xyUopWC+cROPPPAwzp47h6PjY8RozIqEEIC6A+L9Fg/clpH8jsPMKThh54DtQHKmohHjuo1FeYtr0bkkw0YgocBQ1jjS05ByqMIi6mjIUL+s3Ft+teI3a85O68w9De1GfCxTke9HJct5u7BbGXCdqtUrDfQkZeAU7M2mKaYF4K8AQW9Q8JWfGK2KcniId7773fihH/8JPPjQZczHR5CDM/AFL/s8H6+aFDYJ4p6WS4CwJ6R+Y2BK+RxQ7bl0mSKrSsZEyFoal/M8uTpfAmidQG+lCWfmshXd6vZIygyLGz8nwXmWGkb7iv15p0OINn/G9K29o9fTMOO4SppnI9222qM8yf252vi4p6n8npgNn381YiTya74VBoUyy1CGRsoEiky/kcEAwV0LBrTcwX7wwtolYai931VDWw3UjKuOLcHTbByjje602ajPGtPtxRPIDmACZW+uRJvd8LOzqymv2WiDpORkkmPhVI+2k0ZK1N9QFF05ThHkaJI6x3g4FZw8ehUv/dGfRjnYoJ7MkO0E9PcnL7kzyosu7GoiWDCkB3W7GJEDT5fAub4A6lbD16Z1rR+Ic2CHUFPEuGxH1lPF3ko5zWK9ApfbGTPqr+SiNw4AVuYYWg/dw3WuzQUtCB2ucZ4RI9OTgI49GuF58kCNfnbLk1CYUI4GoXVaW2wyKhK3JQytKiDbLa5duYpffMlPt1NbDg/jxd1CBfDwVKIrD9sEmWrU9Hvqsmt1W7miUbAa39zgmMA3IVEyGO1p9ujNoKv1i9XdgSvwyvgTQ63BqqxkTr+Vb9FzT+dGioxNNuS6iG7T/BYCsGPhmE0vaOpDP81poNGXxhGORTeNSrqChCvPebRkH+Cuj7rsK3d4lsT3NAOwXmY28MskOurfoshu2Lw/BYtxZNfHLnc9n+Ox9z38BtMV5OWe8C51A+kV0ZGFssL3DJixwlmpDptbJqll+ybZCWDn1+RyjNocCwNxFo7DcmV4fAc9d80lAXN5NX1Bn0+eJigK6kmFSvFzV4wYWXTrIA9OM6PrwM6UtTdwT7SQ+EIGLS1eHPBinKd1gHRhMMdEUp59CxMTqA5Oyq1oMLr3ln3KRSafXh4fNSK0gTyVlCZ/dQXw/MNvatwtx+Fl7LRsYEcCnMFkQLNnc1p9DPAMulw7a4uRqJCDLeTsWahKP8wiOjPpe/KcNH2kx97sbnwCp8OujHjuCcwAthsGnQFy1JqkF9wmu29gF8bMyst9p/HvAMgihXuolWEvCCBWRryhyYHC4ETwSIAO/In0kXdc0JMloBXsEZb9iUB5z7U9V4W/ds4RguhkbRq72u4PpMawHtW14gzy7SRBwily05Y/lvVLup8N7SAW+YeUTn9ph1729u2fsGnRlC6qUgLcIa/mDvNIMY2QifMxE05mx+Qcitj37LAeYOjyIEkGpTNfiA4IbUMi+fDnJqFMCzmPDuQicYiPGE2EcgP/HZQdNUc5GQRPOgPKALReDeuS2Tyjr92tCzBSuEO1NMMIuwPngc8zJwdDnA7nKZjv67K0jgiDZg9RMnl0+69s2vdeqWTJnwuGrJUnwMaUi3lrQ41rQwmr21XsPkWqPudFyjLmWSvT86cUppyS0izy9gbYPOD+RTBjBZpoR1KEsBQuoKRgHp1rAxS7z3OIFkEaj5oiMxHRSWkoL+xZIisPudMcKALwjOYOTWAFUC9D3KhwS4XaB6DPNQrxjQ20Ut9GGz3isZJp7JL7xwHX6CGHYLQhMZceK1eDywp0kJeyhUj1dovzShxNPCh02ZQGJt5PxGutYZDYOAUTVr+uPrP2pE8l8FDKRoppV1mRaTPALkYZTscRktyHSqkJScwQcHofGSkoKpjRHU1JgkuGHA7FIbIEUNS3YHuj8BJ8YJX54MARVorXEnAzAxPD2Ec9XT4kEmd6bWhdhwK1D3bVpHtAjCyF44nQf2cjrSGgtnpAgkyvyR2vdQDCAV1OjwSAOY66DGjkI1lWlm//7cWxuITsDrYgTekNtpfXNVj/WXuMF5mXlM8jhFwHk2dEMjU55lqxx3QfThfhFmW/9QogoJ+DykQlfm1IzrIy+o9T0HpRGYHhQPji2gOGmQ62tmM9bD3s9tpQzkr+QW8jorS/bnydIoOiHv0WGkYqBdDqcufw4qTzgOQwEOGMV6c/C7bNmbLhzLQ3jz8KZAe2KVluf44Mg4c8vAMReksRgx8ZAy+HhDiNT9UIUkppW0sGhVqRCqueCBbvDvNRRnPakvQN/Scz5quP9ER9rkpr+zDqFe2dE+55F0gp5Ilz7zc+iApQjFkpJoenVnsWxnnRD13gnAMRJlEe7u3+XCTRl/hH/eYl7dFXt6lifR70DPa692kYOikAZgBTAbaCcu48sDnoBrxHfZUFUFxVfUSS+54jVWQgTMatzzeO8sLhQB6SjKJ1pCXZjQwoKajW1vZkr3vepKJeEVEtjR+LET1la6ANJK20ZNyVGhKNCgezkydBtI08iZ/J3NJWbYc2KtWTwHR0YmprY61h0067Fo9vMXKZ3SEC4cT8PWVq2MLlAszTCO22yn6ZnuzBJc4VfZqTuCyB+netAaSrywVSSwxLZawteIrmUGNUV9PtuzIIkbBxCpM9UlI2Lqv17QNsMKvUo1QfgjQSFnQ1JSnd+M1VXalY8Vt5raAU9QtCwYzmhVPCq5CjzZGvA5y3OedPq6lhsw0BnOxtr0Uclle7kUvWyzxBRXjo4DkwK4LmiGs7I1orRfgBN1S/5Tb6o32SUtt3m2vryHAy4zHnD/C5f/SLcLjZoJRtK6cbnBbElsaNApTSVm+WqWAzFWymCZtpwnZTcLApONxOuOPCBdx18QLObDftABRrkySzGbzv7xANh4IWpfXEqhXVZS7yq2rkJ4M7lQlTlzfmXBOpzJMwkEriRIbGbZo4kJpTGMYraml1tuNId3VGnRVSK971wfvxT77/P+CB6zchZ8/288GzqFh7zVilOVKS51HnjAJ3Arq8OrawE2iy022OgybLjquHSyvUHGSRpKdq+tynDkz6BMxr6gWTc6dRMmgbfRTBrc7ZKpwPySRYH6jCVivT4HYGhF7WfDJDMbfjG6VApmkvyHoQ4W3rfVTXgOD0i/ernzZd6LtYBnu9WBOCJXy5PLAj6k+Yd92eDC+CSIlWgjOrlVy3FTZEXUbvnpZGxQps9uGhRzprYH0K4DIVoxezllZWfi+2FIGVZywlFt2sXqd1utG65uWBOwFhpRQAKurREXR3DJUN5PAMZNrmYSwRVzyn1JxLU+z+JClM8obZYMR9E540x2l9pVGZ3WKHxB0yu9//MWB3Q4wA+tSPmqtxz1oF4udBY4hkOnCH57DgcVQr9sE9sN69blUrZLPF/MAD+DNf9bX4O3/xT+L4ZNdO+IJi6qB6q8tBJ9XMXzTfy4SvF+o6JMNNznsb19gBq5fQv6cX0T72Kk0iWdFPS+tRqzsmh4f4C3/vO1DOXoC/og4gRO/8MlyHAV0AmFWy1G0JebXfSqaPjarfoI8EtJrk1oAV/LvTnbeN2dqDMXCI73l1M60sd9lnfhjdpsthJ9lfjjJXRua43MUl0HmHcuE8PuYPfybKZoPX/9wvol69ASkFMQVG+QdRDAd9j5ytoeCHC8q3CsLI20jkLWw5O5+MJOI0KvcFR8Ij0KcST794LtpBnUngUsM76GcjL6o1JVmuwHKjzOF/PDRqgjC+zwT3vOEcBHN9yf9I9EgmVgxGkv3TGKfgtiYDaxEoz6v2yEOkoB4f4dJj7sSL/tgX4oP3P4Df/NmfbyNd0yqJzrMk4+RdWfu0r2ge94kKp+8err0NRpJSmJDl+S5TH5jbDxuOCUExw+V7be0mR1lUErfRDVLnk0WpHHXHV5o7Th5++ybxg+Q49392SrRFmXWG1h0+6iMfA6hid3wc53uozeUG2Bt/iPIQU6pudOQSYN1KL4P5qxwbEwtoLnlPUbdT9WBX/vsuqkRVsdvN2M0zRAQ7EZw7dwYf/bSPaH1d5z6S1Ybs3RHM4u19bk6ky6gBADmIgY6Sf4NtDq3N0IHZynWT/Kr2t0TRynggykEkBbDY78qrZNlOha4D9vJ3dhZ8mNRItcTE6rDLZKTVUoQd8pEzJzS+1XmH6fw5nHncYzAVYDp3BvOVa22aRCvaSJDRLF62jX/Z5Quk+LoF0I4iZ/YgJRhtILq9H4AwrQfyLwSublAl1ZGHlqnCtSGDsC69nugw5kVOtX5Zcfv0TmRtNTIn2KPV2ktOw1r/HRq+d+XZOJxAjInMlrhTsHAAxftiT+0wiBXLwSDXrLS3FdqGWqS0qPZxj38CPv4TPxF3vvd9+K1f/q84OVKUTXjt5kU6MHinI8p34Il7o5uxn6O2CjsbGP40ZylFwKl6Fj5JlsVXaY7mxA1eyxOesDknLPuds4P3z5RkO8nD3Cn5UtRtiFvDsCkU0+EWCkXZhOczTQXTNLV3F3NZOvDDaHJ5E2cNgzS17Baot/fHqbqyarRudY2J9iF2so6n66s9rQYsfXFWKRMqBD/6c7+GerzDVmbU+QRFCqqLyQhDHaDGe667ztFVelPzDEQVLn+pLhdrBvRwKDsxqSw2F2lrD70lizt/bAc7tkyL8j/JeSe9UBvqZEDQRX/lqNfUNbdZ+kjd0fExivQFbFCzSEObFXzTIF3RbbAuQZivtSHYtcWuA0vSs1vuTskVpoW3rci8puXUa+FMSdhoL2tJz6L8U3FlmdeuzWphp5r4wVuz/APT1hrv4ffywfrQAnl+XHGTRXdB6MFKxWuMGbHPI8xct6LPPaMLMbTvZlDMO8XDDz+C69euA7WXY6sjzXuHGRgivM8V8VBRLKnvGmPn1Dr54mDEbbEFG66cgoiArZnssXPEaIrrfSgdt2hueOBvAGN7bo5Q2AlN6OkGT8OABX2jI5C7LAwPkW3efDIWFaoVWjrYFvHpJgPX5hTKCh9o9SjV70aZIxeWM07LgJuUg7+z8C4qOh2Ux0wEDin5grSQg0YCgVoiZ6B/yGf0T913qVVRiuBt7/gA/sNLfhZy8QJ0dwzRGaoFQIHSKwZjrUCrNJZiqdO12LLBz2C2RVNbQww1gV/IWuJEyCfX5BEiO9rscNtwKgshTNWgVB/slCt+XR6VZbo49i93i7fcbrodUXBEiy7P7KBG/wlUZ+g8t60/tbY1C/0vi439Cv4aidzctYsjfEuZujF1QKzVaE3jtRvLi6cRU5FrZbcMkY50ig6Sys+ojChpXNEdla8NOZvopcB9yN+o6n8KFOZ3wxwJ7Flhxhp7XEDWLjOuxMC16/SVyVlI2XbdmkBeiKLpflcXsLENHpiv2gy6v4pZ+uo+rVBIe41VDYLUGJlICeW1Oux5morvBmHpLwxaYPZwMNw8z8Lt4fLdWAz2Tfv7cfN8kZFuimXNcPQDL26RlTY6X5KxGhfSjwAApOFI45MZmQQQigJF0QrUHYqiL1CyNhvQMh+CedzfS2aNkpdp9oUxuanxnTpBBT6s7c7EkDakcfyj+6Psj3Iw0J/bnOlcpX8BtO12EcE0FWyKYCqC7/uxn8W1B64AB2dQ7TWTmqk2Z8vqiqLJxNE9Sc860FgZ3k4DnlyOAa2JEgkkRIguPvzCm60uk7Ewjb6PyG1PqD4FHGg1kjlbeRCJHT8HWqfVMhDGK9NrQNv1QUrIr/OtQucGuIIK2DkA/jcAAWNAgrlBuPYY8Ny3K+JI9Bmu+DD+nmth3oby/HNfZNyblQ+TIgwBNWfUA7P8FhwsLvZu+G89ldGT3vqzoHalgLXtNczMNa9j/K1ARCmcxzyUFNGeAtEJDAQsJ8tFU6eUkwBOsKZcDnRoG/vnecY8t0U4TLNp1WgUfViKy+xvrDalWuOradtya4MZE8kRn7NFEz8NstxbZr6BPfSg04HUVNBtXrgoy/4iGRHJQ11Of8zTWVvS0B0ZOekN1kogHmQ7PQI0o9JXzg4duLiE5kg4+oh2jPnIWFC+cWXs2E52GPiKti5XZvJsHGCyFCMkbLid3hVj52xiyz/QMLZpfOaRv3TPfDPhgYeu4l//0E9BLl2CzrsuX9JUw9/CxEPumc/RftPZYdtLJ5rP1OHh4hzhdY4pgikUGYawS5Yxi7aMFmMByW+wjayDV6FLOab2xs6G0OEkBr1POb3TR85Vaq/zIetak32zgY1htc4oqm0Yuc5AnaJEI9YRTdIzG40YAW/NqVsLklyejbYholRKqMjtSm0c2pxsSXJWRtlNlISNkiyXGPLyjogkqyaT5KLc7tXY3P7dEJtzitMwbqXzmXg783hsVAKlVcrIaJ+WNllFvrEGskEzJXKdTmlNMQKNovTBotmikXmeBxfMBDmvarUieB48ATABDLqn6CQQIFm+9kXCx9A+LGs86EWmVhigusAav8h6C6UHExs0JiDvaffKAxnSxGpzPTUAl5+uGQEzJGzZRPo+56HPUlmrV1aytWX/yQVbMzQQrAGpXeEQ2e+xrPX8i3n7UUZGlbNHqe96C1aVOxfSuj8V4PRXi4Q6z0sp+IGf/GU88Lb3Y3rSR0LnE8SqXVnp/9DJcEx45TuyQzI6DawrWOrxwo9w/bUELNsJ0r0q73/NOitG+4oA5xWpBNiDXKVbAwiEyleMspDyCly3mSk+3bNkJuY6twi31hh1YAcT+bK+YZ6fdu3bkdIbFF+tuNPsPvbYN3rWZGtJ+FJqsUh0SzqTzI5pqa8G/RIY65cLvFqxWdc2XlDvj1vwZFXomaEKLOZvMTAxbMeystOqZ5ujw++UgH579KDDXGT/5h68fR/DBmtfj9Js4ZVqxVxn1LnmSo0w88xb7Q4ozgGOMCnkjXYJUjTTG508QT/ZKQO1g6/7DpLKdqxeACTP77JC5fnXUHMCv16OL0nh6ID5gkGxjG7L72AaiqDpOS86A9rhAaWBLhr45u7T6JvhttICkXFl8h4tNpJy8fZ1zVgmAz2QsEfZ9i8aCdqWpn096f66ct+v2Z2qbctPk6WCqRTcONrhu3/wP0HuvIi2WKHLnLHZZTp+xLzwuBJdF0Cb1xg4QxrUDE6Rtcvm+GyfreEPtyt0woC10yesUySPo/Nm7WCnIOlu5jM7YgYSQmkSWBGxybESszVmf2IBYRJBy1dN2hvYFil9v6xC7WHvhzSvbcPsZAcCnFlxU1MXgLsq/0ZfsBF5bDfs0yLq7LxxS0FHe/Jipr1APcr8mmM7RN30oycgR4fzmReE3BnLNQhxbSIDCfwtPBsW3J6FyVtq7uipOMXrz9eukaQEtHsfruUcaEAfhCTQDVkwQONypOdBO5ggWVNrSwgPELqblZmI56iKyG1Rm+b7Dp5GHwDf40r1E1Ayo2xJv81ler3JkFtTVoQPS9DI7bFbbOVA8hVAnWNjibReLw1FmuMiJuTwTzPEKNIOnqAU1p6FY5H9rgU9TvuK+HBZq0N8mldxnhoFrFz7jFYgycJerSjh0I6eJrdxjHxz/2lVzP2wiqlUSJnws7/6crz9tW/HweMfA9WTONxDmtMDBW2xyuSwGrnqV803kI0z82HNithQPUvSWtsst3KkDurL9iPqSkabyg3l6AptJy3lqai0Stbq08HZYBAmUyBDX5ouClUdLGPDEHysVTHbOhMHT2cwpWeWtvuhGrcAgpVrH9CwHvNYF/Pd27qn7HTC7bBH7sPRLyfkFo91Raq8PkTfOmsX5iPblI3XSx3oGVfoT+Y7eaEs2ew90m1uZPfUACyGANeGIk1dTDA1PeOqT2PiqK7WSBLI3q7gkbQXMNc21GOoWSGYpZ1e57rY87XzYnkV86BcPa3VPw5JeYSaPDai2+6zkSeeWBQdeRvt7mFL2xIgdtCDGYpOl29d6nWks4i7cPBCEqfLaTI+UvvISKnTSL0wRLIeJevYpzTELgKgbdYvZYIvnyrjysjMu8Vlhm50nDjJinzaaMnScC9lcN8Q2Yd9nZJ94RsQyLqILwqwvnJKAwhJJ0yG/+UPvARy9hBlKtAZqP2tUmrHBFphBhwImebRDiEZynOw7b7piyDP+yvU384D+3CZ4rnPSGNAlUaFVH0Ezssf+igFsQSmDngeiZrFpZGXIM55Z7dS9Mt5nX17wMfbNwCBAKjh9LSFmxWCsrB4raq2wLM5R2bww4D4qINTcHvXOO+6ulYhpY8b40CCp0mZB3eG5Evp3xhJCEBe6IYVyRUPGMb173UA+DNEqOfNdijvsyXC9l2J4BEkKW8yLiKLfKd5MPtqzX7GntwfvowsC+jgkDxHmbonWCBlgpYClR4pcroVe+1mRc2ZCceh3V/0UhgIrZDUcoGd1sPgbOobAjcaOaumL8oquT4mw0GuFRSCrICW7vakBiAKYDay9JFmmW5T0qDDjMngIPhz47X0NvboEmXj5xtPpWAnPO9NoDE4Y4u5tj3aFfNj+flpKypvda0NOe2f+8406WKO1XqJt0GsVXqrWxERFinA1IzmtNngZa98E37j116Jcs9dzfmUqZ0Njnw6l4GTJJYu5bs3FGPmADMsnaAOoouhWFiZVtsAnF54QtDW3oU5Wc51r4mFybEA3eGg9ijzIMDLkyjzgGVBwRSz8wMuHyC70dolaivvG188sk35zRAgPo0VXK13wD6Y6tStgOTpAQ9Vw6SNjNVIN5YW1m5EBGMs3TztOo1OcoCW9Xfblv5au6XbncSD/nXj5fbP0atapzGeeGoGVZFVo2HPPP164ft/WwekwxeUXnoOEp79Y+fLS0O4BvBs3VeCGaW0PwG0FNRFUeq8JMfKF405TnH0P4CmYUqOpoJlg10IgZAAb44WopgR4cLgWSRh3uK4yjaMREQRLtdGnLeF+z6jsnpED/jZymZUPQJB8J6lXaOkGE4WoABSSjuSsbdd1qwA4Pe8jlE+7Zkgy1Vi2ZqnMJZ1OlgGOXm+ad+oTovEVtoiVtfgLKzV12lPERs/F8BeKAAAUqS9e6Hvm/0//9V/xCwF07SF1mMoptaXiuA3yXOsyjURMRlA15MuYxL5x4iN1wxE/mGOzvygFuJBtXj6NEycUcud4LTFh5iyj35mcgC8ZifUqtNuo5y/kd+iM9Yhi3RDn22uGFZY7Ds2/iH0EWi2ptpI3KgDDrhN/4y+1B6lldS3MKHWHoMlHg2xyHJtwZM5yl5G8xeCu0b6YI/D1i1xIXXveNHIQWoSO2uUNqZpYp3Kmooh8c5oMPvW9bKPHmzcCAZVILBevU7zvhNYZAoyYowNXitriIjHKGIcyhwXuWSvNzdJeuemyAnESFuc5J5jG55phnyCSoGWNpysjKrhGvp070I4oG3r7vDqrgyiPByFrhy9bRq8N2XkKQwfgrV8qRy+wfxg4xVGKg+nZKX0fk7We5QNm79kYXYLwzBMBpvaguhPa5e1F70/VABIAaT0t5wYr8SH8Rft7YmWfZNlgD3+kGnS/2B6KiDN4K0tgnD2MrgM6VxfyEwMBmn/pem7AFCfDgieLAAXivSO2VqBacIrXvN2/MzPvRS46842j+vRrMa7imFs0CQv7VaeLhhHa5QZnXgRiwsZfBOqjW0m+c36HXJnNTvod9mNt12R3Pdni4iU2ruMvp2bXtvoLIuQ/Kv6J6SAUzaVzeUvgEVbvwnQXmZhYDvyxltlTnjIV3cXuNe4IQt2sxPPKJLcgBVzP8o5+QmJ1Og6lpX8OxM0/iZGDfZsFYcYb0bjuypvawREcMOjO4DYMLJGedynKxg4rgJjQiMf7dEa7ufC9iC6GfjkdYz+xBLwTx/SG+uG8849RxLc0Xg6Xe11MahQVJFljQI/sJ2djTTQ68JEaEggNa6+Ndev63U7hk2pL8wIMGBZfrCRoOYrQrg8Eu6nLpk3b68SZJbRc4uIrZ8ZNF3QuqEIoBVvj41KCIMaQHNojGcxh4vSnBWxV945A2IBWDM+XRbVAGRdwfbKIagP7YMi49CjtTLGqZOx0BWgHbHAvzfaR4DdN/8bRtQb0L/q/jyUN+lRl+Vv++7/gLrbYZom6LyD2urvXn6sz1tYSq+Ah/8iOl0OBac5XJcxMr0uQkryGIuPWF7THKqG/EKyg7AE5y5//qzJlzuOOoAKiEbJz50vvY/NafZRBK1Ou2VmXXP9sYrFgJVq0E5fe+xg6688xAgX2Ri4D0O2aLlMLfenf1CXM+D6tcehTE7LPhW8jbxu48CLPpfpWsS6H4PGkalxQL/dtztrvJGM7/0f+72xSmyfXSQ09FmgbYAUR0MLglZIEVmkXUmUGLD2jeteu9YW1izH0G3wTbIBs8dNdjFkchpr/5uZ7rXmDFZHOWkHJEvR5DwbntQqbpOQk7CHBA5iXXmhqY3efEprq0mTs6RcfsyHevRvxpOaG20NA5c0sxvgZADIKJE1a4aVmJfzoJ+S0w+0UMXJbsZc2++pv6VmVWZOkaMFM4kkzi/WF2K6RIZQxjaOBVjxbPxGWUVS4jFf7RGZ7YkdZSylXzgc2YDNtbbtPmhtOjjY4rdf8Qa85Kd+EZs7z0PmIygUtbb5Wpcjr8o7luoEyYUY2/jpkL9TZiwcRjzC6cjGEStt9qkMv2VgmPnNWhpLuJi6te0fRv8gFWrN7VIgUZ4xLJo/gjybQHKwlNrVn9lwsqQ2t8VPs1ZUlAD5Dh9ucPZdvZ61Ba6Lxrv+M11scaiNe7Bib9nDV7N1i9FNL29Po1YCt5VmJDpXSyKD6W6Vxp9VZX+WhXV2k0sbCFq1TaN3IalBavcTuK03QNee7/E8Aiz20ZG/87YLu7+gQcy50PjTWKWYkvq/7W/WthK5Ooni+tCciuqRpXuz3CuhGxgjUtO2xB8Cq6hDh26j7T5CHrEZIrM5EorfHGKhkUV13fB6vPS8MMVJ9igl9Kqtw+BYJtqU89u8GLU/WhMORuJhH8bUuXv44qOaJ8fHkbcDkFRFLbn//9+uCnZHhmyXlLYXVfqL6dMwmunIXrmldt+GT2DzkdqBdq5zew0eG59b2NVeEtCdp6qKOte+3actijreVfylf/B/Y3d8jO2lC8B8E5Cp0WML9Af6OxZ4f3mEZgmFhzCRnWOOsvyLt8jty7gAExb9msz5HI54TqfH6TPZWxkRcgcigEQcqBG6RQY66QYayCaMTM8Fikr15Xna8E/TuFDoPAJA3Aw4UM7Y7XYoMvlCOj7b2/9l2+EYGecoN1uwf+0LOwjEkaG3LKGz0RpyCqhJuhHwHfqkNEfH6MJTj+N8/V6dl+CJiWWaBhKvKq5bmI/F60a177M1gRvbrONc0yp3iAH7Kl7NFsOPt6Da0y+UDPBIYjGPfBozTF67t5yAbaDbusv1NpEmPkfowB0olYhwHB3dNlZEa2+vzMBmdBK5/WaQGJC6z9BeHq1ZUGJbBHKhyTeiBVNE62Iu3GiTNmyVAJdYEWXHwgOPeO2j1tTXAOK4Pg22xD99k36PwrUq9GCLl736dfiSz/8sQATTZoONGC2SOtCG7MZlE2PEZSIy2pFCxsqHLnveOr5IQtrK3sIrwJnPqd5UTfrFAGv3ighkkrYVp7Ye4rOhc/pwfdxIEVhOopCNoNR2tm4pBd/yz/8f/PZLX4HNYx+PebdzwNLS+svmozucUec3eRGrl9UyITO1n41j/xKr8TX6YQBrB3KQHXPAbp8xJYPQ1VBKAjHSo8HgGgKuDTDyYsSEF06HRj3RGmbBQAdS+uTRDALptNjCjd0OG9lAZoWezIBMgC/y7MFEepGLld3+tA9rG3iP0XAELt67iZ64lkLt1bHs+8M1LAhOtbUaWYZz4TEttkrBYF+YKjZTyxknSS31gm8BXWMr4mzkSh3rN28B38h5XLb3AGheWLBArn0VePq0upAjVgNc85C5IxYuyZKW8Ai7l+t5aCiJFRcF8/EJymbrhr7tqx3huRHgusaRaTQtulLgitxgQJJ8yMgLN/bBB2+03bOylICWgMRY73xMvKFI2dvVvgYIjx5jFGr8sDLbYiZ1gDLa7S09bETcKXEwUOe/OUh+Bq+i7Su8cCf+9Y/9PH7+pS/HnefO4mC7xTS193jOGgqVl+cHCNswuNkWhc2Nh80BxF9Gvz04wF13XMKzP/7p+KiPfCye9ITH4KOe9hG4cOFcA71aMc/dCZkAUTvlypm3R1c0gTwnUVWPYKep4MbNm/iar//rePRqhZw9g5NZUbWd221Rb53n1oba4agXHlDY57q1LaxRVUwFuHG8w+vf8BbI3fdgrg30RBUo0s9ArqDVGU67L3gahCVJietYRJrhqGYZU/ceDST7PY+Yl1FLYJYu5wPZmaM6xoFjpnqQSm7AXt3jIlx+QcAv7OwR0GqUk9IzFxftbXwsItAbN3HlFa8G6gw9Pmn76Z0+SX3PdsoBV9frACLgSQBvFy+8S/2X/IcMbPb7VkFXz7xnkNfLWtJMz1a+5+lFCdlwDpktNuqDlbeNtd3ebYztqa2sP7cocRzOGT2JbLz3FnJ7BCf3Cs78haKhLbxZ0p6Vyb+RVzeGUfYy9VZZ8/pkO+H6Aw/iZT/5X3B07WbriiJDulRD8GEkS4GY84gIOkXx8G5OOhPzhCYjhr6ZF0ZX0CRtgRH1sy9WcQNpPEhLU0LJyAuQQXjceDqo50/77k4IQOU5ugK+DSUv0nKGJtQHIAUnh+fx9vuvQuojfbFX54JFe314LIbLgvdeg1sEAasce0ha51bMruKHXqLAfILpcIunP+3J+NznPwcv/ow/iE//tGfhzLkzDmK1Koo0oC7jwRt0jerC/HObLS2CPnPmHL70T3whvuKr/xLmg3ugRduW8Hrcjb4AtkFNShvt6Cu3pUxdeATQEnwRBaqiSoXceRcUBWIv3JCS6Fr3FQJd2bCmrrP8fseRyPshL8Rk2Tc3LiLaoZR03+91ZUnRo6dno0vk9BK4JBvmtbb6IFaoxOJK00TczERhBinXIY1CV5ZkQoge7X1+8oEHAAHK5BtOgkS3QeJl27QPlJx9XW9L1Bv2KZW/uOJJtrm3CbK3ebkdYTuzIGV9RPX0NUBjEbwy/lRqko3djIUNIwbrNa8kWC7nZkXZU4wxRodh3KRwnfC9hmlP+b51Z0++wBIXMu8ItxJ9GFa0vRPSFhyUgvloh3e/+nWtjlJgEWmbq7UW0qcppBnxxSiCcyVyOngbW3jFpZkbM6hw5PK5DWsbjS3bV+OrgbTT3MuP4TiLCMOJsKjUTsmK5hn9Vk7Un0YkzIh4OTbcTUBnJTkLCOwivIn+DNRGOTxEKWdIdpScDqC917M5TuFoEUdFICjDPFe0MAFDJ6PWNtf5hnd8AK9/w4/in3//D+MZz/xo/Pmv+GJ85Zf/URwebDHXitn5UIJv1r6VK0YW1kAYmOeKL/68z8JXfc3/hO/91z+Bwyc+DmU+AuoE0RlV+75w88pEOuhOsO1SbQTFjgZtPNEeyc67HS1MC1TxbtIsA8CCm84zGxnw3z1x+DnWVvXfPvyfgCrmOHn6xeZCQ+6Nvty3QSTruc31km4qghaEc5iHK0mhSLdjrhrhiJu8mA4xz5TcOmpfo5rAY0jn/Pe2tnbJdvL6Rws5xNOdFaEbMVrQaSXdypcOgW303b77qQTCjH2wtVjjICvO/Cl51qL0VCYHiJwGbAOp3mXSUy6BvdtZ0QfyhR6Gi3RKGSvPxnnfPFe0RsbtUEz0LEhYzjPfIstYgAMLbN7VaHIw6sYHtmCgAjpDdEYpwObwAGW7aR0zz0BtRjy9P3KtajcQ/g9MmQXq+38DANVJS8QnV1qhqB1AwmmyoeH2nXlEvU7OgRmwYKT6n/IIgER6hiEQQIahHdjLkbbVLbqgz424KZba6m31tkUNfYhT23zjvJsxzxW7ecbJyYzdScVuV7E7mbHbKXY7xTwD8wzsdsBupzjZaf8OnOwUc7+/2ylO5ordDMxzuz/PwLxTzHMbKq5zo2Nz4QwO7rsXm3vuxVve+SF8w7d8O579hV+HX/6l38R2M2G7aa862+1mXzE9MikiOuYZtzTkU7Wi1oq/981fi3P3XMLR5atob1UTNJFU7OaKkxnYeVuB+UQx7xS7k4r5xPhSW3tnxVzbYilFgUBCHmkMbTR69s11R0LUPC03xNsT0x0B1X3Fu8nlKZbOR596+hy5Dm6M5R3Kc+lNxjnOFqbioi0pMlH0E0AgtiUJgJ3Y5L6KaDh//G9/rr1PhfSOnQ/4r5j2ArSDZaPZHcvBJju8JxtpdAa0G4iyq4ShFKw8iee3MMBh3FZriGQy3liQvXatYo87mkO9SusgJNPepdBKTXRa0vSZiIDbZQvi6Jw1Alml78PF2zvccKrN92UvZK3RQfoyjYx/GpCq48OxwP5d6L99HaKRuH0aDaFxLrAe9aK9F1K0vx9ynlE6CKvOLU1tn7b9BL0NMD51LRVhJQhLqq70VLeDbQY9J9eAzdMEYCoCbHvnef/FUBhFeKm9QaMZvXExmnn5zLvm0Ue/8upLWy1qkbPTr9Emu7mcozLHKGyWGlAxGhkf+Q/qi4bCJEnbGoEClQlq3+nPDixRCGoVVO1nAUMaoNl7uSuAqpBZgblCdicQnTGd3WJzz9142zs+hC/86m/G1//Ff4hrV69DSulv1Km0gjh42gyui+IouPSz5Z3nGXdevIi//81fC33kQdQq/mq1VnLp7Sh9f2z/rXlOuomtoGpB1cYTVjolnfIXxfj3MPBBbP/z17yFjHBfZK+CHAnH9ZBLwVhPdvaaXIc+u/xz3Z2/WeVJ9qlsH1rtfSRUBhMQuGs6Q/SZfmpLzNNDSoxgPyDosc6pxCPTlUFvWU4U/safoCnmvJ0wDKCmAFDaFAyGdqY0ndupIykJs9Ls7IBKKyUTnXlBoNsc5ttqZVQOlcV/KdXQ1+H0RSEjtpnTIkPqW42IFxK39q+wod3HDqtRk7eQHksIlQMPl7gHhDHkCdqUOb2kRZZMWl5Bh8jKXDUX7cJu+zdjSbxoRT0+wvGVR7C7drWDrC2Vr15P0sdhGAJAerctk8icVyN40RVm7VhhuhKTQxIA3ttkWu2GjEpjvtYeYcOqEddb+x7DxExslCorypy91dHzjn52AaZVkwzymjnkpXk0Yn1Wa2/LUhlbVSY8pf8lywkTLh+S04FPdhVpKyxlQi0TqkwN0LViunAWct8T8L0/8rN47hf9Obztze/BdrPxvb+19qh7nn2BUpAr3uZEen9ee//WqvjTf+LzcM9TnozdjRv9nGgCS/reopZudMSAdLULu50MFPBT14aLgSbLP3fmkEnzfTVyOP+o78nGRrps8LJTGWzkzIuDVlMUY509BDuRVjgtgWO/10CmMcv5HJ5JuDB8XwxQqBzwVEftUTPJOf2xrm/OHGBzZhtMFe5bahRFfG6z+1y+w8lgW61LVPcwZ7ic/7dO6sK1d1SU9NhaLtSG0wkZbMBKHWnEdCjudsjPsJmNbIkU/VNxWmCbaxwAhL0HvtcKyz6SMoOGcXn3yJWEMuGX5P+SYmlm2Co3BkZ0o+teL6xfYv7KPlUr5uMjTAcTPvq5n4L7nvZk6NFNb6ML98I4WqRnqmZ1q4OjzSMnURq86PDwckTUu4PSiKcJ461xooyaY2B2KKJQpbrYuY5KWCFoiE37SlQ78o5Dh6jI22P1Kn2HavruUZ7LBXm5KUKKyKQNp3fA1epAK/RnBixHKTRMrRFFeTSFMbKq6b7zHxLypMA8z5jrDuXe+/DWt78Xz/+yr8frX/tWTNMEoL8OjaJcby9RFioiw1+7V2vF2TOH+Kov+VzUy5eBsgkdGw2lU4mgvzuRbT47T4MsNMlOKrI+oLLNhtid7OzBdQCIT+2yGuUZTdazpv/9GalPAnkC30YG19/lQ0ineC9pENiAReEOltVmfWqOn0V1PCoTMkk6R3w3tmaYJHbzc22yUbuuhi5X1wfwn7cRKNsDlO1Ba9Xg/6f+NDQtfR4fBTJt2kK67p+5foHa3fktXKI7DUjRYAKpIYpmp2O5GyJ/x577Snn5j/nLed0OGG3Md7IzQXKG2QX/luTRs5DSMiqtU8kla8qdiB4JWgwdq4bntE5jYsxeyiXIG680BMx0n3IrOiVoy8MFg6FRm6+tqCfHOHfPPfi0L/ij+KTP+ENNIKu103gcZiCBpdXvczoDT4c2+rCP5HwuUAkco20NXIz10am85caGh7VXpF4hKDomKyAIBSd+6SAfDrRWL1kRpZRLBaOFWp1bShyU7iQ4y5Jc8UIH/uh9YkbF0nYQ4hEB44F6ZeJ1h+JwJzm6Noaxl0pGE1BInVHmGzi8dB6PXr2OF37NX8W73/Mh78hSBCVpf5RjVdoKZuNbEfH9u6W0w/f/zJd/PraXLmE3A1oOUGUDlVgMJVIg6AujrI2JX9a96vxyh5Z45DIl6MdhGlD1fuuNFyp/NDXKX6xOBO9Ml4zV4biDjDwpB6IchbZhVK6SbFBMhyWl8bdhCbXdVsWHfJk71fMA8MWCXhzZEgJEYbL9L8OE1dm+t9fgKcTQt09T2RQWg7A5g2iv3NM+WmP3XE6tIYIGARPa3rSpvT1rOoSUCaW0RYKzVpzUip3OqKI0n2vtZeZQX/SOW4BQ7iz6yTJEfXOrywHylIvt7J5I2PFgFWUWlXoe8DfOyt4T9s3Z7i17ANKViDRVpJkgN+YUActKo0MBshI1WdH2R/9lF+b2r+R5meEhYyeAL7qJv/YGW63AI488jN08L8p047xgPMiGRYeHnJIBIxAwkMk8Ca4KKRt7uY1++PdMEM/XZcZxf7VIopdfeySQUIC/W1nWVnIyzBiQMtmcLuf3+54RqQwr10c9tKenKtP8Ctly54rY4qzoA3+u0Y40b2yh3GDXA6CoD2qN0ZD+W/rCOp1vYrrjPB5633vxdX/5n+DkZE66kHSFSGw6Y0Db7xdxoJ1KWyn/tKc8Fp/y7E/E/Og1YNpCy6a/pSpWHtsL32Mkh0ZJSG/Nw4mhztiaxivRbbuYMN8souMIAgZeSl1uw6LOSNhMeXQi9e1oNIlbPOIBky2LChFNEzG9CP1SVRpZIgkXeo6RR+rybxIkIigomEQwiWCDgo0U/5xKwab3l/1tpgmbaYtN2WKaNpimDTb9b5o22Gw22JQJxf8KRCYUmZrzJKW99UpKqxut7m3ZYAPBRgSTTJhkg41MmEr+25QJm80Wm2mLg2mDaRJMhxt/i1aSk6T7WR/WRzYHM74SoFnnhg5GR6WpyGTfBp1juSWxMRvuIwyS3TQPtJDxYHVF895rAFrCEL7irT8JRAkQ+NLlrf31B5PUoxwifATYtbz55nqj99F0O3TaQgpmEu+37J+uSA7sirnusNO20lNV+4ICqtqM9tgmx5aWwLdVEGBAtQ+NhIFpyQKMwyFvhjCVYxVZFItmQOz4OMZueDZb5DawMKGegBnuoNgL5G5esDqVFeXZUHZycgwhERGFKYajIXmM1j5DAvvu7JK8jcfKinsEqv6h6ese/Un5BaxH6rKkovF2KACYjzHdex9+4Rd+Cf/ye5+D//3PfWmbokCmvRlSVnxBnGEuDhDO1gpMpeBP/fEX47f/28t7fvHjR5XatWwvfTr/mR3ceb0PfFOo2ZAxu23dAVk3MrZseKOFma4krLHYLhfVh3EdPG0RX4yU5KFJqnNVLzOdrf+JJ56luHyJOZ3zMeajG5iPT2Ar44HZZdMhIL1PrrfcHc/aSVFf5ORrQchGBJka5Xa92F05BxFBvXYDMokPEQP9IylkBWqTlboR1GvvxVG9AQA4c3jQ5NJlsmtbf980L5qzKQIfCdkTbQ5szCro92T4uTxP4bT0C7zxylfKSDZuz6PxMvaP6mTymoZC2tXfZ8ueAlejC0ZENDKYKb7PjLHvZhhd8dW9ClDeRYtIibiXkoeUIhkJxb4NwM2+2qKxTkLM2wHQijqfYDfv2tm71gYzlmH+s2dmBhLhdbdnnMYb6AJjvPXzltmQaM/PLBoAJ+x/7hPL76wKfHCjx/bXi/DqNPEt1eV9kcEhsbk7O6yYsVqQjaOkdqMbPp/nc4Mcc2os80vt7m3wRjGi06rPTodYJXzerndPk540v2uyIuL7h33gUaRH9zuUu+7Gt/zzf4M/9kdfgI96ymMxd8dNOh8YaIP/5oQtnSNr0wuf/yxsz5xFPVGU7eSRnTtpHJn13pcooPeFLA0ePHlrs7K8W59j+d3lcAmu2cDZ3K04T9l3sbRK3k+OlJBkLM4nRwjDilAEUKunlQ6I/kzhgNoksEBkA4Fid/wodkdXARxDLmxw5uPuxtn7HofDOw7bmdVaAZU4yUmKr8dDP0c7gFbhKyd16K9uj0D3mE53VEQxHW4xbSbU4wqt4qbcu3kqKGXCdLDB5qDRUIq0N33dfDbe9WTgZx54DY6PTzBNE4oIzh5ucO/BHXjymftwQQ7cuWTbbw6djVhamqx8ZkT4Puk7yfU+E556cEXovM+tjDG6WNSayw5bTXlTPctbYUwXhgYq/WzkRLq9XQW5c1ap2nMFOGSAXUm4ageX3od1ThDC8zes716neaKnAC53ljudrN2DfBjoWoqqFbUPK/vh+FSyq6+uC0STNxowIxD04TZniaZPJ2ilPWFwRufJni/lYflwAMZeQ0TXpzB2aCPYaFod/TMtRhmMpzXKQC0Mp90Lp8KV17rNnisgUt18dwRrRctK3wCIFSUaTkDL0L6lFYRmEW1/oy06095F0k8zE78/CVDmHcq5Q5w88DD+0b/6UXz3P/x6N1zNNqnZ4YGvSPwKsGj8qVrx1I98LD7p45+BV732rdhsz6JiB2hFlYLZGuOREit7b1sfloTxjL2X3rdNTkkGiU7Xf+rj3K/i9EIly7TnJ3xl3RSJ8twiL7dfBLb2dIXtgXqapRKZrbH+BlBs+qTVXdCiwOMbD6EePYrtM+7GE577SXjG8z4K9z71ThzedQ66aSMKc9UWp9au09Lm5k0MWxRoQMn90EirLt8BwOZMG5BV1B4LZ76o1ra4ypxDiMuUSMHUpxVqdyImAFV3qLPiFQ9/AC97xztQ5op5lnYgS1FsygZPOLyIj7v4RLz4cZ+IZ517Ig5QFjYl6DBH2Z/4Z+J/Cj7UAXcpNcvfCygfbEhjmYw9vdLvxttTYSM7wD2CtUB2kY+6deOZiDIWfRkygUAgNXzF+KbojSNahEIuLgLg3IOmaEYDk0OUWH+5MmPJAeq1mAcEzfvpouHhb3e6VKF17u+NJKM1igM7HjIYAHs/ppDB7EW4967WGrhAEkdyxAn6kVgvxG8TT2Nvvzec8qKq/qo9rx8xv+FTA8rlaarPgsHWXRH5u41m50ltuLMiiGcHgeSIeBdsJtBIeTW6R9D9IfG2oBs7rZbDQGZOXeo2ODE/unvhIyQQIjns7+8tUiDzDtu778RP/Jefw9/9xi/HfY+9G7sdv/R7KbxC9XoVYueoKHbzjO12wos/+1Pxipe9GnLHBZR63E6E6kY9TqykVdTWwNJWSDffsZtn6+dS4vAEtURBT1//PjiWrezseKtzf2kA8wgJO52xWl4d8I0nLqEkC9EFQuhrctOdKEUHoxjyNkcpaGy8kQpMRVCPr2F342Gcfe7T8El//HPx5E9/CqZzguP5GNeuHeHhK5exm3ehqyQnvGbBllDJwEpvv9kFx16nxA/kB+BOmn+X/DsARFwFmv9RujwKivaXa6CiTIKDacLhmbPQGVBph5zsULGrFe/dXcFb738AP/OB1+DT73o6vvGjPgcfcXA3bFQmn3xqds/sf+7rZLOMLxxVRorFaU9rpn2xbsid/jwKFPwxOjKGjdOq69fKcqoxiiEi4+DMTPIywthbryxuJpD1Ik/xK2TJ8JSPnjvAsABLNry9CW7gCV/oWU+cni2ZHpW0VX1tMLCJq6K/pNkNkJr2UnWS6mZMjCYOxmGIGHRoWmgwfVcyUsMjw23/FMT2HCC0g8Aze6NRPtOZRaer82BnR2eISTenwIuyzk2dbKSJg3YWk4boPuytMWgbtAOlTBB7p22xuStaMTp1ArTtzdV+NGcc6ShkjBtt4Z8Q+JgjRjyJDiHlFAA64/DwDG4+9ABe8rO/ij/31V+KtoC0r0wGD4uTHBnI9HJrb/dcZ6f5xZ/+yfi2S2fbYfSyQRVti2i6ywOVFu0ZjZ0vrcwJKFPbq2tttXr76UazKBQVdZ57X5mTZPtXlShMwgCLzEadDFMixCNNScI21zHrQtZGfo0L76I/4bKforPOXaBAqmAqwPGNhyB3T3jmN38RPuGLn4Oj3aN4+Oo1zA8eYVPagqjz2wPo1Pa4+lvBeEWzt0sCkJ1J4YiA7JoajV3H3N5VW4jW/qk8t6vEJwHEViZ7ZCbBdLIHRawshUp/A5AAgra4a1O22B4cYFbgVx55C379t96Mv/cJX4IX3vkx6Y1TbbGYIMEc2e1TUCyNjDCo8vdU1K2uBJ4yfN1PxxqdMXIz2KK9w4Xt2ox03M4VoJALTPOxfH8lEs4FDgqVQnoN40Llt4UfSko61M1ate4iEND2Ouy3gY51hJjJ7MrQvfO2N7JG3qZdo6tjTVlEfuGTdEU0I93nEFM00I2484DKMQvui0cMYMO2OZ/9GfHezukNkGDwpja7sxP94l62RhttiCyiO1OLUThtUVXU4RGkmkEJNTNvP2TAaO0xs/dfMzKx9UIwX34EenQMqWigkoCz81oVfNxd7NdVZ2RWTvrslQcoJSa3j/4SgBMyPzdlgzJfxb/4ru/Hn/rSP4qLF88vJdZ5wfAl8aHZCVGteNqTHo/DMuPKu96GGRugHo+lRjludAVSpm4eJQ7GMJ53J6VsBNgUyLnzkM0BoPb2H5JV0xa1wVd4tOL3OTrlYUN6ltJpG21xm8B6NLQuAatxznRKkOSZgTbmF9X/pAqKKo6v3I/Ncz8Cn/F3/hjOPOE83vfge7CZFYdlg6IFx9eOcfXGDRwfH2O327UTwlynEfJjYtlB0RwMuxvBmDh9Y8+5RVWTXTi4qqq/SotH6VJ50uZn7bsK2pYiEwniQDg/0lY6TxOm7Qbb7RYXtmdxfTrBn3/Zv8O3PfvL8aL7/gDm3mfFbSmxNDyqZPezyZToP45yLXKmPCZLGeioKKXUREoa0bP+YBwiW7u2OMt5PqCa2cdFw9RfHq8LN2Hf6q+0sAm3Tg/AV0Oehur+ZGCcrbZdTsRryhwzKjyrSq0dCNbOKPXxG4VteMfQQekT6BvAY/tEgEkvh6qL4dYgwwWpu4yS5lbJSJNcOs+tjzugMPMEocDRRuKDl9uFLHMkkqSMXa37+2ajiIaIbTuQpLRjER5ljsWS4XEBlTGpNsCX4B3CfAd91nYqRlAhMmF+6H4877nPwWe/4NNwdnOAaVO6Ya0BAv4OWispG4I2r18gw15XM0Q+ONkjSz+gwvnahslb1Coo04RpKpgEmOoJpJ5gsykOOvC2jr1E8kVtLVIgk2G84N67L+Kf/Z1vwoceugI5OEQ93rX33dLq1urGNYyuSDuqT6QZ1c1mattYSgPi7WbCVgre8M5343t/+CW4stsBm8m2tEKr+Ksic2cjHINkZCUNeybDN4jowmF17lueqM75o2iWgQFHc/9G5Mv09oi213By9YM4+6KPxWd86xfhRr2Chz5wP85MW8w3j/Ghqw/hxo3rDlbCOyqJEzHya7JLDVQaWl9mSP3tNGrkNZ4ZCLDR91X33D7VPnTd0lQPiIguzyJRbj/YR2vFNBWcOTyHcxcv4OCO8/iWl/8InvJZ9+Hp5+4DVPv7m5uFTa853A8Dq6DJNp+5dloxY1ULaSFhGdVsH445Pd0YmR0IQ7YE2Tbt0zBg442pikXKtYr2RLO3dbEnu/b8lEayp7t4ZkIKW6G5ArB7ijbQNZDVkFRyxjojHWnawoK5VszVlirALF0rJ41HUUToQh11OIEGypTevCf38hKgpZlkn3sCJBw2Mf9F6Xnnlr3CroN2zF11llSYhcvsHKOSznuPUrtiRgQcqfL9PqRpRpSjVjZSlpVtlLcreNEuOjFqM2F3+WF8+qd+Mv7zD347zhxu+uERDfTWZZDgtoNwjsZjiDP8AyYsIhntvFpc7jG3vMXnkVfS7dOJIXkzbJMbRRHgK77sjzTYcCQk2SNbLQJ3AqS0PaK3o9bvvv9+/MhP/hLKnXdD6w428mAilfbPIrhDYo30o39PLwhHd4pIlmwEhLPmuWKWnxyxJnlZ4y9t2O7vQ8LJtQ/i7Kc9CZ/+t78Qjxw9iPn6EQ6q4KEHHsTNG9dRJsG0aS8kaacoWrk9QFhYcwYBu2c2DOnTpUsiDcuYWCmuYxY8uLEiu2V5w16F5Bqgjh6OMvp3Hrdgo1bFjZtHuHl8hHN3X8SD04x//Hs/he983tdg430Z9Iof1EHTgan5ZGuE+MEOFtsJa8PtCOtgj/NX0otuXHLyUUb4y+l4yBC/WS/ldnyGXPC+HELP9gFtBrVb1xflnJL+dn0AteFHA/Kx88hrcaGVDrj9uZAfz1/WFMiMkSkKHQ7QlGesmw1kLLhY9b5YggdrZKMeqXQZepw9fDdqrRy2myJeGeyMaaeXrYgiGUAX4hG8BpsXkCUpXVgXG1IOZWkLT2ZINzYVwLybsdkIvv3v/RWcPSw42Z30AwEI7NjhUSYteBYMQhKD0y7N/wztGPR1hx5J2nnGty++zGNfoyDoZ9TPPcIOE+sugXIRAsyKKgKptX2i86ZnmvsrBAXAVIDtwSHuuONcO+axoA3PuwMmyCvhEbxN8hmExGw2zb/X7vixHK7bzKQ3QnVISqhhXLluIfp6UtE2+rG7eRnlaefxvL/xRbh6/BBOrt1AOar40EMPoUrFwXbT6ROfBhKX09XuWtDDLsLIMDtow8+k7n3pn6lghFJrHt/TlCjshzvD3HgqO5uZGKlpf22fsRbg6pUrOLxwFr9y/5vwGw+9AS+85+Mx136YSO/TfnZZt4FLB2RJn81Px8W2Way9H/YVRsgkLsrbm/SUSynhfnqG99lGlxjwrGX2Tk/DQXDQyQIe3yUp2hJWIvnCsg/15x7I8WEIzO1H3QG0ULTleqZ09jX1RJM2e7MK7RL3tjkIDMLhEWBHCoWBGgJ0XF/IQFq51CerLzKwfIxgVn6v34c/UwStDl5msFn5Yn61C6dFn27IJZyAZNWpnK6oKgJ7x2XLLxQph+Wz7I1GLruriAbY2gsiCmYoKqRsMT/0ED7nRZ+Bj/+4j8Dch73SyIdT1X+niOr2orv/v1wl2G39E7ZzQJcuh+yRiw+zE+gW6ScM0WjNvovyjpdqG2Lc1fYqQahiOnOA97z/AfzMr/4myvnzfSqh0+NixwgWbfFV6oihyQSONIKVV9G353l0xtSNjKW9f9mdsmxLfK6fdMTiYNO5JluCujuGTtfxzG/8HzDfUXHjoWuQmye4/OBlTEWw2RTo3CNnqVB3rgM+ncEOkIh/HPizPVN4AziojDlVcDlWlpC+SaRJABbIYeVm9QybpFw2X67bXd8FbR5dgfl4hxPM+OHf/y189qd/PBTap461L/hTcjazQ5awhBx07t9oR8aTxQpkIpVbkXtl7CNkTGK1O1V52LYJ0WU2JR5vNHN2QeRq8fvqVl3PO1ot2afaq4WuU+T2cX9JSVEXpah7XfGQLPxYFa/Y7S/aPn/xAo4fudZvZ+YaJsRcMpxxYRLJMQB57z2R5wkPJlgC+EupLRpaiBk1uEVxRlRWQzeOFDnn8jRkSUlZqOwUBuoa7VQXyaKBtg9pkUcLsEPhBAxOmhnHGQUzBCd9ZeUE7G7iG77ySxtg1NqiWrVzBMTffhM850U6Awv/XwLvGOU5Y7gCSQmWFSc90tUkJnhC5Xe3BmuNEPpnVFMD9EkEpWyAbat2s5nwfT/8M3j/W96P8sQnoM4z1BwAjfrMaVjUrAjHSXKCPLpEckoA7QORrN/mhJh8KIhFAj9W0WTI+7pT64cLqC9ynK8/gjv+xDNx7yc9EVcefj/0+oyrD19up8W5oW8gyw5r6hPTAadncEAQQKvc3jW9GS5ejJYrzVde+MM1BTluk0yXk70J2XQsN6e1SB9Vbqv3D84c4LWX34NH6k1cksN+DkFuT8hZNrYh/sqJkh0fFzGtMIUbviw7Hi7zEl8SroxDb3uupIaSSYGkYeQkEU7rQgFHYfEhLJavnDEWM+TaGJz3bQ9h4VgCp6T+8tXJCGXPlAWt4G/c+aqweaWx5UZP2Wxw8sgVvPG//iZuXr1BjKX5EMtD+JiGbc1js4gSBLQArcYdhrVtCEapjTZk1D1ko4V5pV5n13+PHNDriJRC5QkX4MaM9w1H/Q66izYidb4rtjOnt8ft5sq+ZCDR6/m60W3f26sOS5lwcuUKnv6Mj8ZnvuCTu3ctfR6x2YeGSUJvnwLS8rpsB4Y+wId18crzZhu7Q4FhXno1c9SXIHgP8EZUGaCSSTbjPuiUjGXy1RZI2fXAw9fxPT/4n4C77rZFr91pQd+Kslw16vOt6b71c6wfCF4RMFq0ZeXawSGu3nmoHIhphqYPBmIGr3kfZ7BQ0d50LKgnN4GLE57xhc/B9etXcPzodZxcPWpvOi59UZe9fITtCNWbyiZnlOdw0xqMsZ91LCiqiXRsADm32SuaJlurU1Nqyp5SuQELaeqjURbhllZukQnvv/4I3vbo+/HsS0/p6z7gurwHC2m0UtNDP9xiALtxxGLN3eBRkP3qRXZyMV+9Quip1+lK7MvmVocV9uRrjo0k5WQvdiQwtlXsJ0sWPbFCx6LRXQWFPFNkBt7eNQwtWr8bEarg13GhTKhV8a7f+V3c/8a3QjYbPzxqzaNJXiIcXyMDJ2uwMLRhAKaewY2VFaXENM25zZDYvlG3sYlezVk1d0Fspxj4O7bZk4Qhp6T+XHzYLQy0gbs5Jkq/jTeNMD5MJE74URRomVCvXcH/+Mc/H2cOpgbA0iO3ItCpQKcSlSB4n1pGGmw0frhACwSIifR3ApjurBigW5aFU0gYu8XLlzgq0Ash/e1MZzXlVdXVtpP06wf+08/jg2/7AHD2HOpcUVX6QrIGnEjVmHxTm/tDntKIozvH9pog8MgHc4PBpdOgoHJbW1myFRX8+h1h2evF1ZvXcOZTnoRzH3kJ165cwe7mCXRXl3z02uO/Qfnit4GpZPPmlAz6ZrQH/UIUZ3A2q8HV5sGm1kL2T23FPGD9TX9jA7kcY5aEw9j0tE3THO2O8NYH33e6nK4BzZrDNzpFllQk9GgPGDJO7Vth3N2GbP8TkXtGaxPRyPlZkahNaZ+t22oyxCutHH6uJLLG+bBkN2XDsK4JkfTKPS0Pc3bNDCOt3sC1K8SEJHsAk31XGAHpndyU2Ugeo+xy7lzzbuvch55imMsY6W/dETIUKzxLQ0JC7bSSDGyMt4OQmSHiea5Y5KBebY42ba6VhDGNSqjzw6NW44+loDqZk3l0QMArrDxPjQ33/qzTEI4uRWemeGqkGOhWqLRTlEQ2wK5ie+E8vuKLX9xG2u3wCgtr7by8VHVe0MNmPIw3ORwrOr5iJ4DOu8jP6XQl/cCQVCYPc/HdMP4kMbl1w1Cc6Vr2z9QbrtoPNbB5wqqYpgk3j2d897/7MeCOO1DrDNUZNleJfpqay7rLcZcIFn8C9cQ7H1UJOnWRdm1el/XLFpnZ/GOWvQDvRoiSUPm7jvUm7nvuU3GjHuHo+hFwsmtvwek8i1EYHbbWkO74ZUxdPlLmvaflXGEHaqeZV+6OFs10Zizf2j7ysvGnpjQms7kJ3ZaVbg8MuL2QSD5XxSNH1xf6a/TYL3t5ilGysIoU1ZrNjUfDzpbBto58WRuBReQO4098iIFSXTzPJezHI2+rSAwjh/fdsV4kddSYmfPQjVCujFDx3BqzKJhAdi3vShlr1+ps8NKBin8WNMX8nd9X9wthw72A9O0O3aiRFA1w39K6lR2dCivL8utg3HOTEyi6aVWXIlNO7WOm43yNLxAayhTPOzDKtgcZ0HsDQ7tYztMhGF7OoPzSFdwUOtE+lOnf1zrRbhv/CzBN2D30ED73hZ+Opz/tCYAqNtPk5dke0qVNlAQObjc1kqUsC21mooIf4xVOxPBAFzUsyrvllSxJNivJIRI2beNwagzJ2ovLgb4PsxT8xM/+Bt786jdiesLjgd31/jYj3lcKt00eZY6N5b7FAL7cclYrdjKR7/F00bqpjcv7xG1M/0cjwq27E+D8Fnc+4/G4du1RzCczigIyiQNeagrLEHJXBmAiyZffpy5fAOXqN7an9sjAsZcqBsRNuRLg9rZmDslKOpNVyewcHXwYiLd0Kn2H8jQNwVUEVgp0IMuInto/AKvXLesxqNMzGszhWjgR2J9+TLZPHdlWnaayvs82rwbbn8HSOzEaaptAavBGnJEZORK7FwB9WhTdJdo6LidsQpVD+1EFe8TR69FIFpFfctnyEhPp6ao9Gz0tB/OglRriUc8QWvQml/DAnW9eKHn2BnBWr/vyKbId+5eB3/JZHdZ2egJXRHMGBEkxxSNe7v6uGE0bu02QRG9w1RgP8Nt1xlXa4zDuIkpUgZQNcOMqvvJPfHE7x3ZWOtM3ZMhlI/FvVDBaNEQywFfILG77WuC8fx9BtjPFlZllaPXrshQrInkvskgLcL/YcGxtc7AdaI93M/7pd/8A9HALwQzUYwg2EJnaTCfJzlhD7vPo01EeoOqiyWad1xjY8PPonHmUq5qiv3AC2y1JPNGOtV1voNDjY5SnXcR0z1lcuXo/dG6Oa/OHs8OZ7Jd9Z+dh1bibSWDbwt8lF+aky9DZUbgH7P2HtcccHi9fI82yFLvdbSs5B2m1s9Eu8CFx03EtQN3VdnIpkAHXyhaLzkP3Y759sPOgrAS04+rltsrddHuot+ddu3S4L/zF1U/ys31XNMDrY/u1Ce5lY7xvjNueWyNXHua690S63G9jubest0Fd1EG2KYQWwzwuVUbSJVaUgCbUNZWZAbMPL+xmzDf/f6T9ecBtSVUfDP9W7fM8z73dfXueuxllEBTBgRhAowE1qGgUg1MENYn51DchOMTPIa95E+OQmMRoYiQajXGKvsbZOAtERVRQUBQVEBm66bn79njvfc7Ztb4/qtZav1V7n6fbfLv73OecvWtXrVrTb62q2rXPQSEop07DN2xPnbf7HS28DPmC7lwUPvxlS+LJEP3xDooUzVEtFo65IwmeW1CR+5NpjQUCsUIYXNQDqNzFBa+8zMDHFfkOWIbkZV3ZSVOIFhedPes7Tajnz+P6D/gAfNLfel4AvhO0/jjP6DDjAndI/U/uxYpSBQOwKL2i4otshRiZFw4+qrkvy5E81mJYC9CSs+63FSgKqq/k/vnXvhFvfP2bcXD9tdDthc7S2GnJOmhTIu16zqjh+k56RGbXet/tbOhH6F4PVkWSnvHQKLOUziYfQVDV/KN2+W6PcXjTtTjezDh++AIOO8hpf9aMF7Z5M5ZJShAqqUAyDEACqIdYgyqW9DIPH0DgBMZuUt/OInrFPE3ONg9aMw2+KkPhvZS4jV1K1NTeINh4q2jz9xZAMI1i2W3715MDB7Y9gLjyPUbZ1rFobe7Xv1oSsNJS4svo5/4qB1XUuq75fbZL+HuU+jQLYwGWNmTH11aGAXoBui1KBGWaFtSY0eX2kBRiaGAJsk5Pd8TIHFhU0+c26u4Y0+nTeNJz/zoefuBB3PHHfwpMhYJRczDmeAwEzbFlh+TD1P27P6+n3bgLZfAMpMOowmhCNk+W5lz7fZYJWDs5++UnNp0w6lvGktV5s7gtvKvLRnwbs2gxaHIjYoAA4lnj7ohsztleG1YONrjw/vfhFV/4Slx68SF28wyRvhl6KUmeEYycoO+j184X+tdgxLhr2KMdq8Glg7nZFtmCmKNfIMlf+YgRJ7OrqJV9u2h7JeBcZ3zTf/xvwKkjaJmg8w62UKfpuQ7PgSq97zbAkOM8Vsk4wQXyCoyYIqGzXU/aDqTGPNJHqliSyEf5awcLBeYdyplD7OoO2LUsuRZF6dUXo2VVNQJwvW3qn4gTS4AV9VHXYYGmvQSgC8447nbMPEt0KX0Q+sYgxTYPDLeSjwAHEv7dfFXYqvm3WdV2GXffRuS7NO0Yff4apvBbf2JdClOfy62P5hlvH8VWE07lIfYRYyiRXR7muFX6+2w57KUKHoO/yG1z9jq2ThXqyjm+d3XcvQvSYcDRJzukBf7KqDRWX5ihscBAYYiR0FXI1bHutjh95Y143Id9CB64627c8edvh+4UMtluGKM3QeqPUPuL4Q7vbqtH+iMXDsb8uAFHXr7NnFUtxB/uSixACQAcFzj50irAUgrvAmnaaMQhWPrNHsSq1ywn687CrrOrtXeS2mhEg9EKKRMKCvR4h4uvuRJf8vmfDq2KedfeSDP5FoQjn9dAi2cY9xmArJYQQ459hmfl459HPTIPyEU9RtvkdhO0sKd3XWpz/aptvV9BgaKibA7w07/2e3jTb70Z5fproTqjyoSUHvS+m46E695PKLMrdHIIgBQQ0uPgB1yXfREitRy62soJ0FEyaFIb6xR70qDLUCuwae8GFq3tBQwad6l9J5sLsXMmL057+JjeLzGfohApPmLSHvPtyUQJmVdUlDQ33hx4Cr0YKTl44N+I73HLHn0GrdthX+a8z0EaYAEn58RRwX5AWi6AGrVGezmuZDE1MdS3/1Ai6wRj9WPQyUc7jBjXwbZrzWa1KteKlQbodAIKBlOOQJiGIatdAHT/bRld8/NmPOxshiGaRaXoRhqGl+eF1nrGz5BhCQi9bTPyMk145JHzOD6/7aswJ7hzUWNToGFeEdzVdIH/lLkMIBzzl5wtiFsoZ5DibcIzaCMkApYWlTpXldtR/858MNqYn4GjOcpMThFhTDYXvdae6VBenKeglL4X61tlSn/UBxXYbDDfcxde8pIX4gk3X4vj7bZxqSqKpSRJ1TK1+w438u5Nk46slXXlyo5meQjxNZOQdNXjmjyyc9KxWCeBk3pICOAZVxvBmRWQMuF8Bb7pP/934PQRZDMB8w6Vt5XU7l5Zrit0+ggIzHcEYa0e08923R0wjaqEfpgfoP6ZL2Zna+1EyOb2KFSuvdvXsLg/Ijf37QZ7/8wUGm2Df2Ago6hRVSCTcWMYOp0mzPMOx8eP4PzxMXS3hW4BSGk+5XDCweEGR6cOcVCOwNmwyyuBKBxg00JKA13iCcvfBnyZryD5OW8xHlY20EXZN7h4PcKg8iEnSXgxJlTZ4pq7I7p8uH7QtmGo3crwNT+/BrgE7MsR22XxuCTjCaN65X22j5bSPkaAJ99GJ0kRR5AdaWBa+RKfWev0HqeVBUEncrgZpTnN2tdMKc0wtMLmW63nfhdVbcbsC7CGoZy8qIm6Z5jaBefku9KFQtriCqW6UyzifF9Gmiko8aFhSSphzmbsHoO8Wz+zM/3tPdgz2sD0uLAWhtLlJkBbDVugxxfwIc94ujc2TcVvq3Vu+wXjsR1J+myxwiJdrLMFt5ASetd7Auzu+bmOUtYy8Fx15DNZR3XQp1prcnxGR9OtTsXYlCoEta2NmmccHJ3Cj/zoz+OP3vBmHF57NVBbEFMhQN81SAAKHLMjdHDsMhwtLTfPi2SCkxG75P4FQ2SMx+hg547EOWW05+Jd73TubRq4Ds0q//DbJcqL9K0Me6BUBCoVZZpwvD2Pcw+ewxm5CM86czOefNV1+OCrb8T1R5fgqBTc8dD9eOvZ2/CHd74P73nwHtyP+3HqoouwOToFzDUEOoAq1Ibz1X0EJfMWOfj9DIbaJSBcdNVND8BtJgq0R4PqGGaFrtq/zp/M/VX/nvwXkPQqLhCha/ixalP7UZNB/f/ocCaGwxjmbJH4uI5lOuoXxjrMIbOPWtyipPTEIIGBDiy0Gfi0AuO65zsXewx9TG5pJbMdG9U6R2W1DzcteiqOKxHVB0esn/b4AoNxyyJ5DpMiT6svxsmdj4solhSR5zlMaUe75TnYdt3mtXXZPiJbMcfSjCj0JCLmHoiQoYwAkbLazgM3Ou9GzIXbBQWg0wHuvPduAMDh4WGWFkf7LMP4unr4PF+iQfxvuj0hc57nsaCl8eZExUo0+/0QJBfmQgtNWhvOtznCAklA6xsCDMc09bqqQnGI2++8D1//bf8V5aLTKFMB6hYVE7XDwZ3JMGwo9LcNqSaeOGiFyw+Rhr4tV9PDY2Q306HuFDQClA2RPnUZqZjNVXNA3Y4aqDX9ZrCNRWUsE4kWHLAx9/IFaBlzwcMP3o+nHl2PL3zOZ+BjbngKHn/xFTiQiYn3Wi/UGe8/dx9ef8s78d/+/DfxR/f+JU5ddkXbMrIHU1LRMuGKeFUkZ+3jl4Ur7IBAewV4QDGWXQOgwd1orXsXIIWfD4Bf+GB1qtLBoeViv4a1rHVP4qhc0WBjawDvdv0YhpzNZ68dGzO89ZXAKzfp8udJMUOY4D7ixhtlEGpezLPaWrLS9YqzcOBDcr7IQnlYSV3/wqfl52b5PqX77QZ2wxJV9rtt+MQaMOBZ4QWDGz+LWzWiZiltKaIgvXeWMCsi/0pKwwbphK8ritqSQwZusFNbMeoF/9uzm+GcuQDfSlmyGr+pLzDA7YOOgja/duXl+IlffR2e9uQn4uorLvXX6UErdjV2zvLVkBI1M4iKCD2Pm/lBfigBrMYPDKrWzxVIae+KLVL624cKpk3BZlNw/tw53Hj9NfiQZz0j2nGnI21xlFCbEu0BsQGFBRVSBG/43T/AO999G2QzBdho7A0NaXvaGghD0d95W7Hb7qCi+JFf/i3cddtdmC6/GnPdAdjEYzUr8ovgDFknKPjg2y1456cVPDC1IIcjolTWbhmdEjWU9DOCAF6DIaqwdxt74SK0FeXST6kbVbSxUH8hu4FAdzOm4y3+6bP+Nr7omX8DF2Pq88KKnc5DbtAWGAmAm09fgc99+l/HZ33gX8MP/8nv4F/9wY/jodPA0anTqLsZZS7N7h08IihOdK84a6e8uxZe5DbasSxPkXOhW3Rc97L/GPuc684AOrp4vvaoR0o6/ORKucdC6aOfXjs2e6+Y4IbOpNVpCCed5DhkqlF6haEDzeNCHY8Xzfh6aXZuXIE/vsJkrzn3VKQraI8Ie0d7GWE8RJx1rI0vRpOTLU6iDZt41CbSR5+5f+JONs2d6pDx8sIMBWzT33h5tWFUPPvovNXhelDnTk6JZx7xA1RXXhQR2WjMw3GEx31z/gAQlKUczVXrMPIBBA9MThSk1Arg6BTuuu88XvU13wLMW8h0AKAC8zZtTWfPBXtH/WvwD2IgZ3QtHjhDBIZwB+6pFmeZArSt7Ozl8311dH9F2VQm4OG78ZVf8SX4kGc9Y8ji1Glx/WEAkmi/aoBtUcG/+Nf/Ba/7xV8GzlwFzLtgcd9Wr32mRkd/9aBlJtjtoDoDl16GcsVV/Xnykto0fQGCtBbIEl0cznX5jRl6zOWbvmqUB8ubmk/Ok2zK+EWBpIkjJK2khhr1e5Tcvte4yuSCfYVS+16n67n0oWPBfG6LK/UQ/+VFr8ILrnsy5lpxYd6iQlGkYJIWiAl1UlUx2y5rChxOG3zhB70AH33TU/D3f+k78Wf33YODiy9G3W1TRhu0Zl/G/ocFGRIaO0t+ZrjU7hYTldsOB4lrh7tGZfr2tDvIl0F33HNhrCLdB/THfUhnWDtYUYYeZsr3dOjEw3uMTVL8k7LHxdG6NywrGurJpR8Tbat3DTenqD6upeE5d3IrtambS3KMoXrd2TPCUlbnzsm2/VtkQGZ1Ld3UpK1N4OYUrDmPsrun106cMLD2go7jFkGysyLA48qbUcSQ/BBC+e8U/LlzJ0BK3AxAdZ+/+NF+2wvMHbDNYXs7WRbBk+CpAa3/OzgWqYAcHeLw+hvgS1FqhaCiolLVGqKwurgxkgsDa5MH8ceuebBlnxrfM7RApC2la6ojwHQAnU7h8MLF+PhPeCGVC5musH0xVNXw1hbKtSDmrvMXcHjzk3HqzBF03qKWDWYtgEwO/k132zke7rfseN7NmGvv08K8LPuUTlMHmJWnBMJBmj5r56d4WeuDuDjWp00GeBi4EHxK4lt6YgLt3o+qdIN5AwNmQlJ+pInwjZ9Tb+xqdny83eG66RT+2ye8Cs++9Dpsd1tABJtp4yItaXjVeDNhkgIbsj6uO6gqnnDp1fjhl/wTfPbP/hv86QMP4qKji7Cbj0NuznYJLOlgoyQXzsAj+EDwxWyodztBc+KnaUMfWu+jBGsrGsT5uS624D1hMAXtPmq3D9DXbAbkZ/KZxde1YxXITyg7njEdz++z1Vxcsbw5GQw4o10fit4/RJ0BOM1PEVNW+bDHxngl22OJF2LxiDlFMuI0r2og1yvtWYm9Maatju2AqwPAAvEMIAF5KLwa/kbkT5G6KaZ0IGrOprXjZSlY8DopKnR4GsBTuKxEQwpuC05v28C9g86qrK2+LA8loE1ZrrWpdO+ajFLwEHALGL/t59w2xZ/tnGWzFenFBQs7YwfLnOzfhf+uHE2Be/01gy0Brjkg8c36BXWjmLeCiy86wlM/4ElD8xY8sT0s6TAgExHUWjFNE971F7fgXe94N6bDI2B7DlJ3AA5QsUGVPucgJf4WeiczBT1tpKN0Jxk2EavjQyIuIUFMa7iDDJtIc7Sk6+xZeF2Djxo44BKTXJ8s0Oj25QCSgZ8BJeru51gvBDEsb7Qr32P8sX8oMFAAKqhlhtYJZVfxXZ/8xfjgS67FhXmLIgUbKdhIm1LIwjSmhixUFTtU7HRuz65ud7j69Bn850/8EnzST3wrzukFbCZFtXfrmkHxmk2XzYo/1vw18IDmwccsPsJUP68AtEoPWqyMvfZn2dxenz9krSN/dCwzHiuZMAuXRz0YStN8fuLJY4VabmdET39S2oiL7wPu7q/7sZOxEDILNoa1HgVo9xFBDl5FH51Bqcs27xpvxcmITsrjmUAHvX4uZbmpnUyLkzr4cw54vAwphdux0bYYEiJSFU3hNdxbqAAZsSsXa1aANy96SRGtGVbnc3vrUnQm5kFp1SEFaZns1kalzdDhjo2ynIQxHcAMQGuFVG0gW2donaHz3GVZobX2bvVHhbTtjdT2R5pQUaA9YKooqBBUlfYXgqql/a7DR+mv32N1TqgyQaWgWt3axFJrRa071LrDXBX6wL141lOfgiuvuATH2y3mue3a1NTJeLkUdXC8lSuloBTBNBW84Q//GMfnd8DmADvdYCeHmK2vKv1j4q6NZzr37xU2HN0SPwsectBiOmq65nQquqNXN5nQPHV6/flZB/f82JeYYYhple1UlUKk7Ff4exSAZ6KjXxiSBziVvf81+NA+/JtAF6A20MZSpOKRs/fhG57/GfiISx6PWWdMZUKR0ltaESoDrZ9qPZ9QMEHaXt+14ulnbsK3/I3Pwbn77sQFASC8+pxoJh6xTfORQZbFHP01UOBBW+0BTXC4Z9fehxSGYfQPC5/PQ8f7sleuju9ZlCHPS8HvEoWWP+1d5CfjiCxIDZJlUbQ9Z+u+bSBDV7ADlJWtV5tIGaOXtBIVWM+QvH0iQEDPGZKiCrUxEvJoaK0s2OpZogUaS9h3L0Lw1YXdUcE34kfmj2Wt/ntBCxWELIXMGa/GdV/4ZFE/kLNHrHyH2iOVHbfFDSQPbzfDTyuFrV0PEHiO1R4TIoCmYR9zI95GRe6nxLVghea3g/TrrkfVWgpn4gm8RzEnKYakYCdsRfaUJ3F50G4aaQwNx67oq1rt5eX2Mm1z5lDUC/fhFZ/xiYAqdru5rQjuwGmAOwTrya4U/QULRaC1YioF//v1bwJmtOdh5bC15SMKMdfmWaIzwPS/MTE5v2T3fYXuGl9MVtJ9i2q60zNRb6afb6+UCf6EW4ZllrxSXhcNxxfWwXhW1xSrfTTRY4/TUEg3t+FgD97NNOzebu+uw5btA8AEnDt/AR/zlGfi8570AqhWTD1Y8MV3C951Xc/Ox/k3wUbR2miDouIznvhc/NgHPAe/9t63YXP55dDtDgblHgBXwF5h2ETtBr6Gu86byGrTn04TuvzDy2k/7yaw7+jBU46LNO2z7N0nxU+jpCv8sXKeDPD9ew721OPCuygD+BvSuBMjIV56BXhUsRGR9JJdb3gPcY+GX1z5uMkzkKOQZufrjmzZbhjK4o419HrMhML7nqqh4ZI0vOSupu30Ym9FyQi9JCiJhi43A4urPtxMt6e3BFpjZvimBA4qtLhKjGIKWli91JSewDER3OsrDLhBQpKf0aiK7J+zkxa4PVAzYfQ81O2TFN3DedMURqbaCTxCToqFZxb6wrRieZ6dcrpXmYdY8VvMKAsz2j7C/XkQoBTUc+dx7eNuxqd+4se2udHeP8tsbXNAq3MMgH1uTaRntYd45NwWv/eWt6GcOQOUA8rIiDoZKsIgg/aF+hDlUjJo5ZP7aDrZfIsS4NKaAb+Ho4iQJ28D2HQ698Gwn3V9LTlIGZaDsdlNgAODvBlInWuXRbb7IBJp/3Xrl0KhBZBZ8MoP+1RM3cZKB9txLtuCEjHj6Bd4qHpM9Jr/ac9lf/VHvhS/+Zd/iuM6Y2OJDPkvGHCy4SPYkXpActTFReZrZ4OV6/wPsBQvN1af9xcf+Jp+Bwh6b6h/jCWpt8kBPfrh8tiDk41PCydMLVPrw0+upbQODI3u4zAGwceXRcfaZYUO53nowFyQDBX70EVqt7dDWUMTs7oCj/+dfMjKL+KU/7EhZnu0p9NYq28aoMr1MeDmVla5mzuZLnikx9coMLBadfEt1ZLr1/jenA2BdbeEGFHICj2y1B2momXbJDNeqOG4T9fMgToPfJN3AlzvboCQz3F7PaZrgGUWTL+36VMLkVH69+RxSZ+NTrR35vJ5gUK0DTS7jiQXogH0BrZCw9Xa5knnB+7EKz7jM3B0dNDn3IKPDJLJ0boqRF9YTr/zprfi3W9/N+T06RYQSh8+bujkaw0yMilX7LJgx5lkZnLyH8b34EV+nAbk3SPTdVlZm4Len0RK1gP+lxhji2+arYZTjtEaTYBgDWQXZX6lv1y9Pwrlj1b154FUNVYrC6D9Pcm1AHUDnNse49lX34yPvPKJvc/idiIVkEotud2EzmagZbs1M279q1rxIVc/Ac+9+Wk4f+5h1Knt/GUjQa7pRL99qvmw/ql9+iLOqwd+/ps/2vc/zubi0wqrPji5IJIHy4oVnkYDWflinn7AnRUAtvI+ZN1HIUGm2dy2NPmo9JdSiAeNjwonY4PWLp3vMytCZR8dcE1NAiiHqwQIDqR0LTlJKv+orbqirXdmQeKjHRkB6J7uNFyzKxRtPld9AUw/59zrFXbrGwEmBz3kvKxtBnlFFz6tLOao3H5L1JHdpiYFipu68dkOMwQyrnTKYKe9zwNtZPgAPINhVjo9GkGAuOmPWKjUnvaXynO5AF8QLU6nfw9mu70mQOfwLqhafpC8vKvnGBA69/OtgBl232HMHvvphl5lg3lzhONzFRdfez1e9Q8/FwJgmlp2WvrzuMzP9pf51EdWzHH6WgPgJ3/pddhtFbo5QA8L4Iug2OEM/BpHADQxMNMgpHsmNyfZdbXpD0wfydNG8JxZt7ZILgTo1GbG2HVzzGIgFk42AqfE0KFucvQdZDM4USIwmkQHXBWBloLthS0+6UkfhlOyaaAsQPMYPThzXc/ZuoMrHebsw/FLBKUADssGL3nqc1HPXUAtbeFmFeRgnezA++B96y6tn/M5eHa4fJ+DrIGlBZbqrmwhRg06XE1EIOPv6PTy91ClyXa/zuTmybU+tlInAuyeNvfcI0jP2XJUxd/WohO7ysN1Vs1ykZPSPWYQiUHEsLwmkYU2gNpaTHAyJ/ORyg0owtG2VWubQXTHX3VGNfB1bWwVW7Qe+kXDOPabu+LAYH2UPqcq5NjCcnwzh84vdiyW5fDwIgc3llVYpsDz6EtZGV3Su8fzX9GfxQIV6dLqNPh8cG84ViN7g+TYY3Vx7mGbVzMnz0K0IUYHUdOlEsA5LsLQRTWaeOn9soAlOWjTP5KkMUSM5nHEoUusP5ajmFDP3o5/+w3/GlddcQnmucZWjR4kBQzFXJWE4+svd7cXIMg04f6zD+Onf/G1wJkzfdFT9MdDL1FfxB0rjHmlOPOLgo3O5+WK+SggaQ6zl/eagpdK95o2p/Ucow2qgYsuHSyBZugCQs+SPwn9twBRBAn0PJgyYKnN5sy/tD0qGi02D9yeDGwFap2x2QEvvPGDYNM0Ff1xL/KY1qeUnRM7PSYi2+7ic1dny8Y++sYPxKl60PShkPYpun4EaCZ90vx97Vg9raCRVXW/bra8AECKSc1MYgTKaATV02uTuJkDjMwzumdo1zUzO+D0DonRn1i71KOx92Pt0Sn6aSVMU/KmFrKX3/kgBunKeaouXxsYxI49M4z/MCgval0cTNFJQ8kcXWasNYtiRbCbNO5V9aGV8YgFYBo0m5FD4S+y9hv6sFdoBhxwx7qpB2v/pjkqHRTF+RpOK9FL2YnWXFs0rqRXSyWNlDUcIATEJ14YYcOGNFAZfrrbMNXjfWSaVmQ8nlsMhROgejvMKx16lmlIf90qJX7D/tijNRUFu+5sFZgOcXzHHXjxp70EL/+sT8I8z9Tack6Ppwdq11eF9sy2DdXWCkgp+Llf/k3c8c734ODmm6DzhbaSWoQcNpGfh00QgOswkg/lVeUMiqwpFJB5MQkbYh+jcZ8yHWZ6HSSotX49A21aNGU6rMw1s+cQk/9NFmK+oP2ts/qubVU0S4eCrqztit28w5nDi/HUy6/PviNlcoIQRtCXuzb6U7NXdxEQCCYRPOWK63DDxVfg/fMxZHMQwRQrOmepA/i2v8TllAyt44IHpxLlVQHUGUTAcKizOW7I9Qv/1vHqSpl0YcCZoe0mO8kyX8WJ/RC7r9l9h7XQwNaUmiOgPTWkSHbM/sZydp4jWZjcTfnEyzBxVod2B7YkZYxmZDD6kzuff7HzhCuPuw+hy4KmSH1YqdKbOJaxQPAnZwMgNifLR4AsrwS1vtkdEQzEQijQCuOo0zJT4YwSSE6zVZGzAjcgy66pvrQAy2h1RyAu3+hVB3deRU0Zsg2NcRa0zJCjXdtA3nFTzIt2E/Hsj2XC4zDGd8ZJymxZjM6O4U6SZSQG5gXZMbZ6i7SXscvmAPN99+Hpz34G/sd//lc4PJjaqwCbBHwJDXJr4SAR9hNzu4oigu12xqt/4H8Cp44ArZC6g8iEtjFv5+8Jzis5GNW0Wp2IiE67fjLDCM866DU+BDjHvHTn+SBfV81BRpzdi9XFf8mGYoSC9Ipwx9WkWr3EG9U+jNzBthA4FSKtjQ0Dk8mkXZjnGafLaVxcDgPEaHeyWARopmoBRfKgzvNWdADefm8RgVbFxZtDXHf6DG49vhN6cBA6qtpW/atPErPCZlVgH8wL1NZQx20wZ+ZthKD2R/l4xMq7E952X3Z6Aq4EfZrLr/SBr69YlF1c/57wSE/EFm9+5XKMxMnKdo06/thTw5j2q7ohtZ9L8FxWz7nEGvW9gycCbS6fD7Vmkl4FzIzVhVEgOZjcXqyMVqjOuUIzcP656OGoEATCRklyikpKyt6dvYddUhIwK0I3jlX/uGbsAErIVLszkkE2ar3tobZnOtaegbEDHpwzCVjtrPtxydeG8zFX2mssFrS1mmy1KbM6xaoJTcUBOh9jeaKTZOC9EYEFhi14adcmKFAUMh1B77sX199wOX79B/8TLj9zEeo8A5vJHWeJ1CeDg/NbvfelO5EKQErBa1//Zrzht38fB1dfAa3H7d6+JeiKqqw6pjwI0GfZCVc9E016kCtY83eucEIhj4A2PCH5KN9gNpwoj3voNPsK6TTGfeEBloGU30F9sGBa+yNePbOt8OCwv/QXUJq26fUeTBM2wqDfeTgmHGs8TIcMMgHtP9P1BYKCgovKIWCPK3G3bYjcwJf73kF1IbPhhPUuYocYueD91msPYOrKiJ8xwX3Cmm+X9Z9ruBJ05fJeYsCF/SD7/9/hUJiICX9otG/40tLZLAnymxfOMFaHLechyEB52GDVKgeHvoha1pnOJMfQFPXJEDf1jBaoC0Z05F73f3v5UqDzjMPDA8w9sjQHrKk8VxGZY4pUyZOpl8tG2hnRKdWEt0zy6nzacI9nt5QZS6/IHTPUAyFfqWw0WB+dBg2n1x2mcDtGI+mNqA3iS4x6WD8EiPmx1jbPI/pIB/NWTB/E+2Ty8n/7NoJhEOR4W5UL+QvXT0AgFCjEWoNeicRa+NK7IKUA02nM996FJz/tifiVH/ou3HDDlQAUpRRwoCqCJEN/53Dvo7dLfmqSglkV//a7vr8v0JmA+bi1q9oXnNFOReMoi3Xc+u96BG/bGSEky6QWpsc87Nvds7VnwRLbJLJ8A1y7BBlo2H5W9C/ZjcADoTZHbRlz2KjNZZp+sl2pxmpkz2xh/dO+tIDmwBsCuTLVWjGrohDoab+78m+nkYzIbnCur4CS2Zv27BbAbJu3GN3djtHPGdgm3zwkEjGyI3SufxWkc85PAbyjFb64LPmvZORjn3Txbm8eZXL/yAmcDMJacC3uW5xPRcz3dhtcA2HSy5MOTwacOdGGANgkzJL4nLjKi7Na6vQaSD5qHSccksoZcTi5311hRGI4joc5U/3S/mm09pWjICURhFdj5T7YYHvPPXjnr/465m0rLxsZ2ulGycQ624bo372H/SSUWnZvNRgM/5IV1JtdODikfoYDi5PmaEdgGStVqnu1bNQWzq7/Q75oiEq5KfUyiSBo9JMANLVrDrh7iAhiWoteswYthKupBzlQpEsOuO0Bm6Lag5YJKIdtc4S734u/+XEvxA9/5zfiyssvwm43B+nSNrAweq07th13YvvovHtbv/xrv41f/8XfRrnuKsxVITL1YXt23mQRSYkGr5j8RQZVDhoBIfrEa4pBIc1y8fvsExIXliOZA68jsHgAzjfHj94cM4f0341GQ+Jq9klamOwhMtuS5via1lg3LKtT1JCdFjy0u4BH6g6XlHhluLdouk9Zpjed06NB80eb1u6/gPN1hwfPn4NC2ks5LJCwDJRtNenQaMMI+ROvrVCyT2abPeHQBafjvdbeEDcseA9rPyv9aNkeoAApCF3jTyJ3zT8msF4BF9fj/Ufkn5rqZkzccPupI0PB3LAMwl6WG7Mrv5fqHiPkUc0sA1S6KoJFx1ezaKo71rNyHymySA5ckiItqBI0UK7Aw++7A1ImyDSFl+Hskv2c0WkZQ8oSI8OM1XcduJXJM07E0NIaLrtLNR50Y/MMoEVTC554NruofOgI8srV4Fmfw+mZafCBnXI2ojxXgz7EZB63lfeFIql8ZF/ZAdDctEQfxL+HswX3X6L/uauSSObvmSsKaIXo3BZCaUFVYPvg/TjaKP7vr/on+P9++d+DCLDb7VrWBGAqpT+RI7kN8VnyhTo2v9bHBkRw/sIO//xbvxM4moBpgs5bqJSWtYj4lISLlfirLCfXJRnekEL2SqwI1ph8CQ2HTJFHRUwUoWa8PoH5y+HqMJs+6g7IDwicfu6ft0k2E6MgrT2zPPTHqew+u+6zw9Wy2f5bS7+/+ZMHHn4Q7z17F5551Q1wZdS2wI1XChMh/CP6BPcExIn4t/Ydw+55+EHc9uBZ4BJpz2sb51T7MHL/bgy1fnO7DrjNELPnIz4DsT7EKLE94QXt9Z+MtlRRAlpeAcqNMfit+Hb7vpiqdJsZ2vJg2G9erX+BqU5zlsl4RNCc6/X1SL3QRoQV0Jx0viFXnKM8dtB7s9hMO/kxWb0ev4Y4Q1biDgMP+h32SJmm4arG3xXcXhLTHX5a3NWdSzk6cL6xoa9FyqMDbf+bCa8RIkkR/TGFfp45YRgmBMIMrkDw2gRv58yZGGNSogibs2OA5P4ZkLEjU5KBDs5tcBY5QhiCPlmUtcUY7KSNJ9EFUnCXFtr+vuZ80J3RkDKOoGZ0hJ561BPOjAChDdsKdtsd5oceAETx/Bc8D9/5jV+NZz7jiZjnnTv/MnW3vBaoQjtQWmDUmq0KzFoxz7Pr9nQw4b/89x/FH//eH+Loxhug87m2L7Nqe6426V30NXE5gZ0rTLIXBqW9fseBFuTQFKGI4voQembtkEGy+bAdsmMeDUbXvg/9ZF0c2a5DFar+OJB2nY/dOYWeK+/2U7WvNxCgCI63F/D7d7wLz7z6xiZvQd8XJULcxC76vuwX+Qlof16X+ieCP7/rVtx3/iHgzGX9RRyKvjKqD9bRAql07IPTdi1GBYYSSuz0pMHMK0YN9h5mzyeVs+BuBYMW1TEQLy8iRXdUkv0xg8eSthUmrOiQYwv7WzR92qT7NBrdB5z7WLOvvIxl0jAZLaNfizYGAGfgTO+tZYBlq2leFqbF+3u054qAnseyTNNAogC1+srYIEUJR8J6zP9YRpXnIHtR6ldadUtg3ZSf7mHeERCoO7zIbluiI2EcxksnEJ12yiISsPX60FVFxoib21O/38DYm3THOmbIDKjLVapBNY2KdEcYWk16QvrsfCTAzbLXoC0ohYfvPSqVDr4+TaHt8a95u8V87jzq+WMcXXkZXvyJL8Qr/97n4qM/6kNRSsG827kOTDJh6u+PtYPnUFdHlIZDVVGmCe973x34+n/zXZiuuAKFIKHtnQsXrnPXzcF0qGtqmEmWP9HW7g9987NdD02fdZAjjy6EbInFbD+cPTPwapzglfFs/xyMpfops/Fb1lDNLzQdadOcltmSzaWy6Eld8ET65hY///Y/wOc88/lw43PV6zxw84oFiMqbloP/BMEW3qmqbxn7mr98K47rDqWi+6VeUqtvlzmwNHU9C3QopMvCApvTF9+0HwpoCZ4tDgumUlU0tUHt+2OlaeSLJulOyHit6vSES7IpwiAeDQkQSb91XWECK60uRJDslkQ+bANY5C6ZEX/FY1WITNN4joGW/3IZi4bXKuQGWR7gqBPIYx1MUChseCVJRiQAeBjRigXoihu4O312FtQoC5ajJun/GIayWeVM0Bwi9w2Dw07kdqMeWOdAQyT68EbQ4v9oZhw7QqN9pbtc+fK0GYSmZs0bu9Pm+sk83C+CeKhpMsj62MuX0oYFt7vWXjFZt/41+Y2L0hJ6d7KlOa+5AtstZN5BdIZMBacvuQQf+IwPwMf+9efi7376J+JpH/gkTKVAtaLOM3zxk/HYmRyLotaOWChlw86CIhNsjcHf/5p/h/MPnMfBdddg3p0H0N40RBFasB3BcOY3JPed9SdxQjHUx/wmdnUbsuAmLYqS0P0FoFCZNX+QdGClabvVink+L4D2Yc7QG2rb+O+jG2EEHRuJP464DmgpKOj/lIND/MpfvBXvefBuPO6iK/rQrgA11pKEXuXeuQ9Qsx/NPFJti6C1Afu9xw/jf/3RG6CnDqHbuY3iCNxXqNE6+stR3nY5FAD7Dp8y0GH+3+eL127iRhD38zkr6iMtSAoYKrI+kroYWj6BEB35sUKHQ0JqY2DhSsLj8iTb3izK/hUAV0CgOdLMjKAhKFm5bgSn+8n/j5FGO6VLLmAoN15bAYO8YKMXYiYMAm0LDtt7XfXCeagUlM0B4RIBpDuz6F9rycBGcxFrwzKEDqZpQwDLFqh6ZpT99gzEFGNUbBY6ZZKsf56liwE9DXmbz9EoICxny6A9KCEeSmQg5p2S8VB7Q4oSxHVZRH+GfXjdyQL17IM4ODXh0jNnsL1wAds699616Nz2fvU3P6HrENuECKQIDjaHuPGGa3HTDTfg+uuuxE3XXoMXfdSH49nPeCquu/YKHExT42PfTxfdIUZG3GrnkQLjCesEW1Ptzy4C/WUDRQAp+M5X/zBe/zM/g+nxT0Gdt4BsXDAuF1YuHumggM//EENjeJfktWYbQmsQQsKtHbBMIxNNWdaQ/QJ5TQPXmGzTwSfP40fAhvA7Xs84vGl2T7QnW9IOquogFyRp+tdwVxXQWiGl4IGH7sZ3vfGX8U0f8zmY64wiU/KV9ok+skys5toCSWq7xYgVqBXTqQP82B/+Fv7klncAN18PPd72130CKLF+Yrm4kX6y83EDDzq5pwv2Defa1o+9TZxwKJIs/IUqMG5aq6STw0jQ2iJcXejMatNRZiUrjlJW/3odBh2qg92SYJX2iNhE5Bwkir1U+mR2OUgySBDl5BzDqUdGyI4yiXOJ+DIw7iTSuhBF6KbON6H7GrP6zBu/r9PRyRoypxPnRSvm3Q5nnvgEnH/gAWzvewDTwSmYMcecjEXGmoxs8f4pccxZOPhwksGh7KaZR7LqP3LG1s9Joy8UaunYAqSNlwrfpABwuaUM3EVtxhBGwwu3RkvIziA7HO87gbP/qzTz3bXfAgVFgZ57BC960fPxrV/1xbjuhmugu13bVB7hkBvgaq+LDLcTGc++Co4OD3DmzBmcOtpEQGKsgWK327VtF4u0VawcQOw1f+tq2CKbQNWKeW6zdBsUlM0Gv/W638JXft03Y3Pzk9s+taX0ZxtLD1Y01b02ZD3yP1ml7WIWZC29VwfOti1mnrcz2Q8ii+qpjkQHBwvpvPFEswEkAkG6w31d6ng2EPUbeIi4DYdWSC0+vCtuS+p3OBCaB64K6Izp9CX4L7/9y/iiD/84PO7iqzDvZkylbzAiaO+1lTBzwAJI6T4h7A0qkLlXL42uaSO46/xD+Pe/8mPQyy4Gtn0outY2eqMSWSfHKBaES7TJPEt8D+eeBdnZanrrdVSh3eJW9Kz7gWRn5v/dZe8BzMEw1vR4AchUT1Ljlaxy39D02sGDgUZyxLfRksFgKWKZ7R7kGpy2NRK+cLmAys/3wuYQvQNqTm2F6iELcsXwa1H/2F5UF4Y1Pk4w9k3RVgcqfSJdEqSUMtJI1N0OB9dchad+/Atxx9v/Arf8+uuAzRHijUTWBDmcfi8LYxwKaUFOJ44jLuOXxP3Jbbj/IZBXpL6o1UkKqJY1+5wqgarxvvM95oYpYxn9lTvnETRo4FBXFm4pzWEn3pgYOKAj/nHNqrDXvbeLBfP587j+2ivxc9/zTTg8OvAK8kIy7oMN38Vvp9lo7Tyote2SY5vT2zxumeKFA37P2M4Q/DDQWolEk3ZaVIHNhD96yx/hJS//p5BLrwQ2glJnzCoQmTrg5nnR4FnWvxj5MIABBZRI8u1nUxDlOMZO3dWkrTnwDNNwQyuNbMQ0jC+8ZOCjAIBBW0gfeZ/g8DNw+4aac1+yl90C65TJqL2IANCiXn9zET0oc33psqn8vaJIwYXtg/jCn/ku/PLf/dr+vO6MMk3eRnrUKxNAfzrzqvRHeSp0qqjTBl/98z+A9917B+TKK4G+7ac/g6rSNg8zu/bgnWFncIz7cDIYlc453/k6yTAdgvAl1i3igYLdfJfvHnBd4MrKEQFd+EWK2lo95IzGIHffkXJKZDNhXTbVd8ClYsTHPcwCFkzPSqzJmSdrZ0r39YiZPtTZDH1kuJKR0FwIgJOyiNwNVg4CXSjpkJ1ryqpzRTm6CA+dvwAcHUGODhlOILDVrhW2arV1O9oxAB6duFNWgy5bEMHOJAuZLYSHiruD81VeTZPt8aL+B+aEpQNbVEt96pqTI7fexvBiF75orI2AI+7jczavZz4BSc7wfjPIZw3tYKsVqLtG1PYYN1x9JaZNwW63jdeJKb8esS806b9ZF5gHCu3gOrtBTWXCZrPBwcEBNgcbbDax8Mn64R+i1HTV9Ct9ukOf54rdbsY8zxAA01RwcHiIv/yL9+KFn/1lOCdHqKfOYK6CGRuov0IPEeS6qUnm34Kx+a+v4bBiNPcnY2cskEtgFcrA/40+Q6MKd7LLVaXa+yMQGpLzx5NMOqqp3lE34OhrlVuDwSdZ3BJ2x0FPCs5Np2YDZ/XXz6nOKGcuwe/86e/jq371+3Hq4KBtxzlHdjdrew8QpG/pKfFyeeO1or8xSGZU3QFSsTk8wLf/xs/gR97wC5BLr4TMQJm1d4t0V4e/5Eu0b4KRFDDxQJcfY44FUHVPuT3wwRGFrsjbf9Lo5xpppisnZqALrBl+y4gS+4j+qx+DSQEYX0Sw747xeJSIQrkxg3bKOAGkud6xLi8DjdW5zAiJ3+n5PAmQ5WHLNfqsHxFlkaP1yNvKk3LQvW3osZ/pO80koOBMDZJoTnMORgsiChrnI/IjEk0NIxu0NsV7zq+1aLw2nop1Ee6ALOLtTnKRXcJEGPPIapG8SPCa6rA2mt2Jt8fztW67QtSl7waushh5b7dZgBgOBKgB4iI4PrZVwKXTIWRkYv/vyUARjhZMsDnn2F5R7GTcmHXenIcz1AuiBZIkLwZ/UUylYLOZ8N73vR8f99mvxP33n4NcfkV7DtTj5brga4wUrK/uzvyGy20Z4UuSB/PL/Gpa5a7Bj9xfuK4u2d31l4L1mEuk+bBBDyL4It3q+u/xsdUp0bekN4vDFFepTxm4PLO1cv3ZUpvndemqYnPTdfi+1/48zmjBt3ziF0EUON7u7DVAHmRB+o5fBDG2y5WijaRsDgswTfjW1/wE/sWvfi/kyquBufvZQv4kGESCja5xPzPosT/kOtaOPnysVLEnCfuOgCH3QXTW3FFEfkQHA/O+jJf0J5Wh/gktptw7dJyc/f/BYTZEPnvjv4GI9ILy0eqcqAU7k/fM51fH1uk6A9hIcOozByUjJyQDWqtufZjbrztod8VexFHukpNDkv7QnHgUSmW64sV368oaXUNWYMC1xjNXzHA42blglc+w28jb8aMTkuikRRh+n2N7GirkQm4bZrhj+xJ9NucYPoAeZzJ5DA35lo49s1G+1v8VKWhDyKX1oxMltvLY6DRHCYG9JGDf0cgbSij9dUcu6fEAMUPqZcagBQinECtf4UBr84Y+Dy2Ct//5u/DCz/7HuOuOezFdejl0vtBWHUPgNVGQkxXWdENyGS6GoJ/7R54r/nCwKCu2aPWu2T0Hhwv/To7PekUgLZaNDkA5hO1RHtFvL5t4E7xI2/9ZJt+z1Bg2txEp+G8GmAgeaSQMArkwo9x8Lb79tT+FP7v3dnzPy16F648uw1zn9mYhVeygUMyJd2KkKHCwmSBHB7j74Qfw5T/23fh/3/xLkGuvh6AAU2+7L1FWHTtJvFGk0QkPVsbiuviy+jMBcm/XxLTvOLE5/64nlA5dsex2HGIe7xr93Cp7Fo08hjJW+UqH1YKR0nSrBCVCdz5K+2mYo7uW7hDVslj77AGAZrMR7efhLXVlM6J16LkQDTzksiT4ZI65wSiBrDvNNaDvBtSL+1CSRaAadfowd+rfALrkKpTrRERavlLYjbwG7dxPMQpNmQS2jzDz2Onqfj5ohPPdnX4neZxn5D1VbQhYxXhAgApznJRNESh11whe3BWANMR6SZ26dHzURAB/WXtf5Cdt72F7T2zK5qkzSY/ot7di5xFlmP8hZ5JfErcGmcwzhgmXe1usJ30KokwT3vjGt+B5n/L3ccdt96CcOdNeMqAzRPurzFx3Ncu284/xUlXb6trO9favMmO7EMjdSZxrq+M15OPl7Vz8XcSLBNjho2mhmjNMjapEU9RnuhnACpHQlw4oTL+bA/y2ocuDfWoDWszw4WF7ExD/hQ8ZR3/ce/R2CgSyrZDH34hfevub8CHf+iX47jf+Ah6uWxwcbHB4cNBWmEMx1xla20qozWbCqaMjHJ06wv27C/ju3/11fNi3/RP82J/8Msq1N6B0960iqMXVLzbjoJ2j8vB2/IZi0a/YzEPdXPL02qAvru9hA2kHKdYBY43pFOnBAgeAhT1yeb7Py4trJIYb6LvRrENJoc9gD/uOsYsnwOhmWfkAa66xTHeAwSKm7Bqv9v2kQ3XRJWOuN+sOzUzQDCwD0t4mrB3NXYkFtuYxwsjMOi3DsLvM0aj1fbjm5R1kKKImmlr1jCQEXNY/chqSymncT/W76+n/xMuYYzjNPLBn0GYgDIwUIC3Vdli8hnQJ0rdV8OFG83IGOBENBMul16qRQRADjQm90aCLzUQ6UxWlO1sD24LNZoMiBSq1ZQEnGU6vh7pEDpv0bsx2+YbVc1bT6DRMLxU2vy/a5pRVChQTfvInfwWf9yVfBznc4PDMxajzcbsmJQIlqW5LzhtNXfFgxuA19DIAkFmQoMeRJPoUMuBrFKQM/QTG0ZpoxMDSfPXoiF13TA3MgDv9SkDc7g8gTh3bI3rvg4CGgg1IK6SKl4rFehGcug1y/f2BDhWglq7b84zp6qvwwHyMV/70d+Cbf/tn8WlP+0h88tM+FE+96kZcf8nlODg4QJGCbd3h9ofO4i23vhu/8u4/xs/94Rtw613vAC47g83VN8IHcfhvyvCCIa4ZKy/IDnvuUyV+fgVsrJo1n2vg6jxhc2B5UNuj33E6yM8vGEtAm6ujeslfCOlBRP9xJyUpS+AFM2j1sKBknM7kaiypsOcXoqCudyAaiw4sM6u8GnVse6w33U8RiWDZRwPgEWTHoeL9jzhoeGjJNGWloLISX9n1+j2joYmBBtwQhTxXZByalIsgNtVjSsFDsDE8FcVs6DkYGIDnoK7NCRkP09xpsN+vtRXNvEoUXmeIyxydNnAbfHL8tnkScvAKeq6ThoK4DYS9UPhF37pOdOfcHPLUvpeCtsH/pn0nh27HwmmQsrZ2hyy2G844j+7ul21Hhvu6XFasAGZ0UtsCryKCC8cX8LXf8Gr8h3//apRrr8bmcALmC4BM/XUHfaBVLWgKXmeAGQ1aEl+TH3TFDcfUxMMrIQi41+ZFbYtI54m6IPMqZLrusuBVxxr0mD6yLZjeGWX+XftObDHkazAyjrjkaEoRr+PpQDtre2Vdadft1XCpf6A6rB4bTugfpZE3UbRXLd54E9537kF8xxt/Cq9+/U/i4s0Z3HT5Vbj21OU4fXiIOx48i3edvR0PnL0X82lATp9GueFxLdOGQjed+IKWYZudcqIjcS37tNDf7CFHT2fn278xHTLoGDj4VEOgsAvsOyT5nbEmWD8wlCHfr/TbrwWC5z4QCKdWVsqnAvs7sJc274tldbL2PtuuIc0vDZAnGZpWWhy2xTqB5rUODuX8hedcF2dLC0QeejIC8qOQn7E2OzF+JjUNQQyC6H4/aKWTrucdqKLKqCSyVqOlG5JWunf0n3kOzeh310j9CnJ4Mc04mkGAak5soDMqVAgKbKMP2PtJMdRLSeUiCHIf3+kdMtkM8Ar4qlRz/T127JNFIgr04eNpkhTUhitZUQS2tRP0hLMsZwP1lwMHv04VzraCFfQOWwgwNTm/+fffgi981Tfij9/8R5hufhwAxa55WShKPEJjCm3v7jUAXhJGtAz867pov+P5a2KV9YWDFeEC/DN2avJcyftPSw1dtwIMir13d0zLvW6rz9YJBIhIXxxkr75zGXed2js3SWwS+rcNEbeNIzpqLbSGrDbxMhHd6W5dsuF7QOcdsJlQLr0c86x48NwWf373rfjz4/e0tg4L9PQRcNPVKLJB2xYUDfjTVrWsZ53Hhqtr9pYCg4HFGq41ydf0U6PpJktZ8MQqWF0/Mp6SlXKkX2viWgXWNX1ZtJ1rSgHEavmTq8vNGWYuaQgXsLYaWeJLev6OrycsGBB9/J2GNvZFAOtA7EGBX5ds46ZMtPKWHdw457n/EHBLPuySfI7CnuG0uQ/pEXAofOaX9r6ELUQvfOFFAj1SIADqxtMp4peAExB63xg4NSJRy3x9foz4CRnqsABidKyqtE3wuCChtuKVpOTleQFD6IiVT5Fov48XuvGwPW91ExmS3coOKNqdSolTzGM6kiOW/eVCrur6FXNHQcbCsQ86oVX95doqwHTQnru899578a++5dX4j9/3E1DscPS4m1HnGVUFVTcBpIFPLr+RyFg8Z7RFFhE6YPY0jKjQkQCIs0fqL/byIIIADxr5MbQQQPITMSpjMlAkllq/GAtMbYv0N/L00MMdurnXWB+QBjrcjHtZA1rfDakFN/zGzVZNAG2jKfRcgD7M24IKVW5P0d6yrpC+klmODiEHhzAqqgJ6PEOlQifbaEiSj0tQx7o7yCl1lMon1+5GIjFaJFGp8duH8Uu0k6rWcZEU0ZjcQMaFmNJY6vN4fmH3UZEnfDKcX/0uQzksR03GoGSs4qSDXcDGv431JiFxJ8MRrs5fraF7MqT1CIQNaZH+0y/tNKwxYLwhC5OuE2jkIR9xvGSiFLaox7TEntfsBhO3DrREZbbYwDB57VmWyNbME0RW6Vi+GOrQ3GdIoiUN00h0X9K97JSRGBDOiklmT2uuYbUz4dhGp5AYbdVavZo6QObebyEn4jvoK91ny2sEk9Cj5KlvuSurvx/FoHjuiCkM1vZzFf66NqBls5up+OYGx9stfvRHfgpf/R++F3e98z0oV18HbCbsVKGl9OCdNzxJapxASqyPSVc6kqw+RscOOTuh/CaODogUjJnOmIS87a7DLjmnV0NcyHa8onrAwEula4SfBDCZF8GuDOS+KYXfPHxXALM2oJzhm1r0bhPQItlx9GkACx2cs9J6CW2OfRY04E38iOel7a1CXEfiV1RH/TGCk4OIQM3tqfecbWoYPQJ/VaHg16gg3tX+8UrZ6VpV7Js1XQvas+yGrnKxfFsP1B412x2653SZynNylJ1sl7/1rdu5Bh+auSmRYMPIQz37CGkVUqfGIeO1jGFUCqGhBw1yV5VnpMfP5XnaNYBdgnoGJY+ixlbNY+jKfR7BN8fpz0LSzePKOF6dyFF2ClqMHormeV7VHKfrutKcrwUBpq9kWxbFx2IlUkJN6rMaiY5v6wmaopQFXJ55mCNlQ9EVeWj0M4w1+hkaHXR63zyV6QOVHvB0IkRh+8na6KI5eyfOxDlmctnbEaJh9WjGKSAPNjiSxqN5nlHn2rZtOzpEKQUVip/82dfgX33H9+Btb/pjyKWX4ODGG/qr9BRVSvRXbNWwdLZojG6QLsQagSz7WHhC8kWWbwCqyacJNJ7E4lGGkFsuH/bJc+/cUJtxCD3ywNLsg/oQviIa0aF/Jje3Lc/q2UYG3LG2FJ7FpYsXtr7a2EBPoP7mrGy7/R7TfQ1yWVMMl8UD7wa0hkepuKlTjfvDwQ+dIazj/oJiJZOf/9GxQW/Fb2zFPXKLgDyZMjPV7A5UKPvWVZDF4B8GfYu29xgh087J2pC4MQZx8Mi+F1wmejW0Q9MjCwpklQQF1uZstVdHhpLrip8DsCXFX6kVgC9cAJfZy8T9ni6tiD4hc3YX6GH/snYRu26K42iVf5s19XPNUNKbJU8IQIifNMxhRmkCHDNBAzAgZ59JUa2FlclZd158buRn+PB8eig2Pk4RxpuN3hypJDoq7HEXqiC+OimaMug1zWDn5ijv3krd46mv0GQ+rHSs30aY305RZJuGtjnDC4IA8CI2G4oCSik4PJigB2094m2334mf+oXX4Hv/5y/gz970x9CLT2O68XqoFmz769HMF3JymezBRpQWMUyMhjj3vOujQ5PMCxMNBmXwahRI+6aTnZD3McfopRhoNWzCfR50QVrCCL9gtjH2hYOKgVNDEB82N9iP+wcFpgJ94Bxk7huFGIIaeC+00vRqoHcs05MP67OBPYAeL0oub8TO2jesIAfMNlfjLvYAbWV1L6aZuDEQyUzX1BRc+yV1lRd/QkEbEA14a+fYBMmWRjY126FzIxAOx0nXggGjrodGkNZmZ3RiveunF3dL/AmwVfqkk/sbz6sC4YQuJ72XQLPouDluIDlbd9AS9Y6ZXX48ZoVOkLKlvkWJ5D7ICCS9TYY0yx7RsE23Ff3h5SgbemxQ2vmZDJ0yub6DDDiAcEwJNHAlj1QCeei196HfLAA9nB/XWIV5mJdXfnqbgGc4Y0bqq4LJkVrW2e5jZ1upDhO9RjltfMhZERyA0hyvGgXmVUimXS4XdlvYCItaPwmzWJdcPG5+4Vzb/DDpXOfHuHoyKCgoBX3TE8Xtt9+F177hzfipX3wNXvPbb8EDt90FueQSlGuvawt4dxUzgBmTZ25A07816Ak/KDHFIS7a3C9QlkfyS9ZNmTL7cyEdE5ILhANceH1BD6njYhTGMuS4F1RWa3+rVifCR3W8m8OK8JFD5o+6RXsWHSobdSMHsVAAmwPg7oeAc3MGIQ8oOFEYzg22bdf8Du2+KKJmp63pFGVxKn20ps1Duy1T5GBv0zO5shtQawvc37hmF1LgyIdFetLoQol+ytBXr0BZHqNPtkDDAkXyOUISS8HZCnYMNef1I9Rnydbpc7lrgbes0RtFMrycDMjiJaQ/hdF+bUTGinohQUQyySojzrHvY9vky/qJDMKroCuLu07s1HIolRz9ojB9uFqhD4dsDiKmqP1m08m+P64/ND7WqVyN5t1puFCvW8LkU//Ce9K9rpSaAggd+0Z91x6xua/xYTsGLnKyDuoZWKKCsNQFx0nG9moyId6G8475DHe45oEROtKnjyJgyV6ulVU6o0RmmXDnAw8HD7vzGHfY8SHHfrothMmLJDjLNbH4HCy9CF5UMc873HvXvXjDm/4Yb/uL9+ANb3krfusNb8bD956FlgK57DKUG66HSsE8z+3xEhXSOOsND/32s0tzWzHgvLiDMCI5yRh5oPsLqVyXtYgsA4tF8Nrr0dCfgSQTNEBOcFxMFtMSvRzrQ2dAnnPulTto53nI6PygJAvaqV+bA+CBh6H3PAJcfQRst1TjcG9PBoIdLKCwE2U782DeAnIGRAIqXo/g3TcQziKQqGbwLl3OSzMP3zAeg793wmqjyZZBNGAj2zV2QNrjdhjqSYekdjiIW0xBOB2BeitUMwH53rUEL+GOnlDhGj5a5QSrpqs+QrK8aZNuTg1SNJZ7PBhwNkBFGIxRypGG3YbBmBgtksORZezqkfkAsoss5bEeCjKAPQXISBrQVn8t26Ku9FX6I0xwR2FKGh0KwFkomgU9GmVCRwlZiC/mHCODCMt0mqydoV4nifXBZCjBJg5srGbDYRvxiIyXVl6zfJk+ot/n5NWJS3QyCFgq5zZjulAr5PAQ733ne/CTP/savPRvv7AB2+hFFFlnjJc2Nxocc1mNdmJkHh8f46Wf+UX4k3fegYe3O9x/172oWqBHG5SLTmO65ur+yI+g7rZQf162uHxieLEDh+lXodXFQETnDGIst0IZkvCwdwRSXQTOey9vMjNZEe/Z9tJKYQnA8amAntVz2cHDIh2OLb0vo9NvgvVO5qDfWg7/sqbXAXr7/ayUAj1Xoe+6G3L944HjC9GCwB9JTF1wvVD+EbahVJh9zUoW16pzmIQ7XDc+anIlrgl+BE8A8zkWtAYfFiNcvc4E2p7lxmiVJWScqasCUoHTh4ce2Pm9EK/fQqhFsjKArHdXst+IQu48h35jgU3p+5jlSuZ/DjhWmEw/l0ke99HmhIFCSUqqaVTSdJUxxkHo5HF179jQaV05t1rGBOXdif8ybUb7QE0EIeR0nLB+0pfQIRgShsGy9UtuYPGx4EbQy4r9Gusm4txh9evS6DIHKwKMdCkCXEyxjWdpo4NBEa1s1Mt90qg7tTuUQ5TLjoX01D11L+lDg4mSHm1L5rODu6PBwDIygM4n3utatGLCFmWj+Pwv+3r80e+/FdIzybm2t+lo1dAhF1j+nDhFIdKHQtv1w8ND/L1/8AW4+/23YadHuPRJT8Dpm6/HwZWXQQ42mHcVc1XMc+1PltS+NV8bQIbOQK19XQPluaKx1qHzJvGdnY/7+ghGXafSPaNzyXaXHumwAACxRiE9huHBUisrQAN7Ib/WddIWo3iwDYSuskkK3Wd1ml0EVUuRpGIuxHRd/Itdk9BJ8w0Hp4B33Qk5ntvJYs65Xzd3gdC5WGVottH7mdyKOu89I0wqPjr13lAKTDTEVdmrKFfnHbb+qpi/IP/iiwqtW8qtZB+t2ramnWvf2rG97ciuCRRSKw4ODvGB1z+h90mc3kQMRwwj0KW+O2MI+7L/MDBepPtMd26V+kiy2HuM19ZsaayUvWPjceE+LUhZJSA6kIQwdGy1Dgqn+d4EuIZUmu/lOZrxvwHrMiaNHJaoT1PZkVvW11wFm23sIYrUd8++SJ84mHXH0X+Mex37ymECz6DXeNZ50Wn3LHXgr2hE1WoOnB5DMUUY1Kc9Y8j+FoAtNbZ8QoFUP3fW+iu9TIB4BELt/nbdsyWXDfEWeY7R+6NMd9DUbmn9LAcHOL5wjI//vFfi7X/2TkBKA7vhfqd9BWj540Wla59kJr30JX8T3/8D34H5gTuwe+Q8ZHeMMu+AOjfH2D/+HKdWSJ199yjxQqbvY1YU4Ob0L+w3r4p33Um8pQwn8b/rTbLBCL4TlyVnup5lmv4iaF7qsvp6hzz8q22Tj35PDGzw2ozQH+pY2JsE6byIJ5x1tsEUP5rjPzgF3PkA9B13Q46OAJ3RRiLgfPDV4GRrAUqI/ZOtr2qiDd12i9CeAY48Gj6igFTESmnV+N7PSyU6xr4DHpQqzCWTd2N5kh+x9SmqGq8VrL1D1kco6vGMa85ciWde/4TgP/OXKFlk1KRvjAdh0xLmKZFmsV/10S7Wi0HHWe/JgYMPxpWVEIYiRDqvQj81X9X+ZETOVryPKSLcdzAZe0tzPR5NnlDGM41czh01K+nIBCNkrYmR9vAFqZV0QjIPw691h9BBKTl6ZPk523sUza7FDRyUZcGUVLzX4RgktySaaVPuqETwYl3zB/7DAS6iuj6pP9ph9ET8YX+Phr0NDUXUgZGA72bnUf8AbgaurRABnFB97lT7cHiXh/A5bcOzcwXKpWdw7/0P4mM/+0vx3nffis1m8lfjVa2YtZIzjzoWR2KTuHrWqtjNc9sZSoHPeMnH4Ju+6Wtx4fa/7PsiaKenZbLaF9c1R0UIbE4bCmEZs2ytdaPRZcD8HhwHgbMFCO6sXM/QHS1iuJ7OWSP8AooEotSsDobFVPHWhW1EonrzYyZgPtEBwX1o6FLOcgaZjbpJJU8+AQAF2JyG/t5fAg8ZLyoVNsegnS9If+FBqAWU/XunO9SeAMTqHf2xgZD/JYCv8UngUXW9bfu4jnMwidAJ9tPcJwP2uQKzvcdXMUPbY8mPbPHhT34Grjg67YsyfXEhmXI6Mloi/FYG13yPYuG2rBq23zW8IX+9sIGhXCN7vC4RGPH5cW4wXRUUjgZTC5C15uMsC0RksWvHUqFzp9ecmbuXlUxCqQAPfYxg6xlHUtqVdnqFeUDOCYi/gQRQd+wFdXsM3e6ScbVPDSDx032Ic0R3pt/KgR1dqyfKDMMdOvbdemSgQcZn5dmxGYCxk0zVa/qewhty4AaMLSMynvGcGc8fRr1xnXjRwc5iE+OH2aFlASEuDb2iEQGFoOWJBfNuxnTppbj7tjvx8Z/9pbj/3vsx9Q0lPKsILoY8qL+WhWAAZauj1oo6dxAF8H/9vZfilV/xj3D+9veiagF0BuYZUuf2cvs6t0DNN0jp37v+RB6pGWgXfiOgjINP43cOpHJwmnFKQmeR+YnkiNnv54zZ9WTUm8Tf9e9x30hz0MNlm9jZTokGrl+Ztsw/r3XMbKze6TRw9znU334nytFptBfHAtCCiMC7zvXMUqu2l8PP6BtjWFbbbZle0uS+QQHYqyZ7neFSNM7XaMcyWH97jwFgrcuMVxEjUG6N5NfQ1w1IX+thJmD+CCD6tU11zP2zs4y3NS8XzuPlH/oi99VtO9LSVuUj1u8Y/0UN8AnUCFMaa2Lth0vWRjiSbmEZKPB5vznXkwKQ/p8tCBTIoqrQnf0AvQBp6RtuObjKesV8JOe2uEYGwecphc+EEWNTRStlOQva08EE4BJU+LDN6q0rQunOp9uAexnLOeTwAPPZ+3Drb70O9/zpW5tpCPXeG+p3RJXtoumCcncI/IB4/ZVFhdRP7x6a8sdUkfrfzId+2A4PBN5j8zL8XjrP3q4/kqKIbAxulPHoki+TSrQJNdKMLtq34UOve1/QRFnFot/uQysKKmR7HkdXXYFb/vIv8amf/xW4cGHrLyuQspLJSrApGecKHUUKpjKhFEGtiu12h+12h2/46i/Fp3z2y3B8160oAmywxYQZRXewbNaG4jwzCS+c9Cg6FeTZN+YoP0LBiQkLN4A8rie4UXM0vWa7IMQKC4BAwGfFJBa6ZYKDUnNEHlhRESE7YJtw2jzQCz32KQiix+hz2/DtI/f63hy4AcCpM8Cf3or6plsgF18M1R20aAQkasOSvQ0C1sgqdWAwPe5nv8lJa2+fM04+0kKq3oaaHZhZ1jifQNN4ZI/0uAF2ABMDXXNSAz96MCRzxeZ4xubCDuV41/pw/8P42A9+Ll78QR+K7W4Hmdq+35MnTmMIKeELXX+pj5wkUCAVbOw3jwmIfVgnuXxmZq6Ty8eNy2srWDTWMdY87GWXW1pzLGvn+NqJ14eoZry2FhV7+QWQLs+7+wg7oDrWHNW+g9GxgywHBkUgBaj334/5/rNAKT6sE1ltBxhe3GJGaN8DXZx+y4BVdKAoAMGGTrWDOfPNayJazOGkflPEHEDd69dwSlbIAhZ2hCGzyMZ43tWGgRZZCzmAwP0wrMh41fmzL2NCB/5Rf9g0Ref28r/dBRxccx1+97d/F5/3j/45VO052HDeld75uZyXFXpwv48hiPQXHjTgrlqxm3c43m4xzzN+6Nu/Hs//+Bdid9f7MRVBwa6Bv/KH4M7llQGXM9gcjPKQs0SfCUwtmPHvVqrrYMzTUjDWPcr4tIC3ldSTaPcgK2TrOjPoTSCLkr0Z0Ee1oTfRDgZdCN6EnhsZYY/IOpL0v3OHUU8EIhNwcCn09e+Avul2lEsuBfoT0Y2H4vSkLFOjz8031JAVCUPtg/juANR5kkY5iQesN7YrFRS+13IK2rTrrJmZaVQBtDSfpoL+hqOeaRZAiiUL1G5VlJ7VlnluAH9uxplyiG/+5C9AUfS9vwUiJTJbIR+N6KtaxOAxy9LOVxM1+2p8Ua7deBoZ8go+LqMuDnqEfFa6J/7sT07ZD7WDXh5PwKVYNpDrWJ7WFYe+8hsr9TY9Xw4dp5uVT1O2p/maDzMqoszKMQaweyk3urriQApQJqBMkKMjyNFhU1hSxnAIARqRCRIPFP6ICbvB9nB6dnI8PBg8tHuDCbFyE5HxCfFlZG+/3wDOHUA3zDSnRHoi/JdISBlON3iP43nrOf6j/Ju8tEmQlNvrliEAG50vGV9FwSyCignz7hgH19+En/mJn8ZXft2/9cxqnmdsdzN2ux3mSlvypIOHaWlxHtE0lYJpmrDZtN2iDqaC//W934qnPuuZeOSuuzCXQ6gqCmZM2KHIDF6ualDuDJEwWuVLQ5+dPvKvNj9uiMLx20LbPZ6gLMQAdihsupCuU1sioXvUPHx4lulP6D/oT6DgQK+mLSStnNp+vj4XbAER4OsBJGj35yKHzkmRPtph5QswXQx97VtRX/dOlMOLIAeb0LGEmP00v6hdGyg3uTCadn8i0l5NKGsfgUqBvyC3f1p9QvsQU/vobfH+xOZr0IeMQW0U+0yQUoBJfLSn9HdEF1VsquJgV7HZVsisqALsyoQZBXjgLL75pV+EZ153E47PbRu4DkFRBELhB3nqSsfyw7EvWdNcKEMCB3lcx5rsvXxUfAI5QYtkXffIabhWnArhinX4yxWHIab5GCKegoOVexERCEV+MpRjR+6LOkxUHcA42/PDFS4cY1S87JIDyKKncXa5IrUbABsTGb/N2y4yrgVdJpkOsuFbB6Vs/9hr2UwppTeXhl6sRvK6zegM8BjILDq2e4cozrRHuyxIceO52ZBregYTaA7PM5gO5BylUsZh7fkAkzS3wPOCfI/pYdKzpJOROVcUzNhgRkHFhFqPsbnuJnznd30PvuXffG9zvlVRbZFTHdpEgKtAqH4bPQhRinSwnQqmqUDnGRedOsCv/vj34JLrbsT2/geBadOybWkvjA/MtiHD4KcJNL4abQM4c7bmRGsqF7yKf7MDMx0NvTL75hENIzhALkZYXCfQM/ROa8zXsb6hl4854Tzk6cY86Lj0LtMFALaXt52WuODXrX/BdBoBkPwlxoQKBBNQLgVe/w7UH3sjcOc5yKlTwOGmVWV6U7U9yVUB7U9zaZU+axB/WwpZ6G8HbOSPokD7HHED2BL1eN0BunYec3znJ8tQBahRVwJxjwNaYiFoI3ZF2+ZRZVZMFZhQgM0B5oMNdvUYcuERfOvL/zE+77kfg0cePt9ed7iGUqbbXcEWZu3f17PZNIrJeusjfUB6xesQgCesons53uulU/2rmfVq38ZTLFNgk7MKHe5chyBzCh4dpkvD/Gs/5x0nQA7GJA+BpP3EhRE8GXD92ljlAvFXusPpAN0cfZPEEnO4KFOHLAqBvKtDn6xew9b+xYMO6qG/EcQ6bzsxucOT5jgQ85mux8Q7jxQHMOZIj3/HT8uuNcgdypsD9uUWLGNqy+43g3DD8ACLF7MRrd6n7thdvuKgnR7r8MBgYLd/N55VSAVEjjFddzO+/t98O264/mq84uWfirzwSbPKpmGr5aM1rp3E4tr3Oa7zjGuuvAxv/PkfxHM/6e/g4QcfwXTxRaioUEz9cc1iDSVZ8NaloCDD+unZpcsNizpMj9T4RTrBJcA8BKvlImyNw7EvGM80wUNkusXpNB1R0nk4YLsH7cEQBG33Ig295xE1sztZyCqFF7FZRrd57zu1q92vuExqX95ydAXw3oehP/JG4ANvgHzwTcCNlwKnAD3eAbsdsLNtXDXaGUbs1HRqzQV2z5Z/M8NZ31p/htszqIigCpoyaYl3S08NkLERABUolARtFCITVI9QbH3BbsZ8vIUeH6M+ch6lbPART38OvuWTXoHn3vAkXHjkPDbTFLHC4pBgNkdFCL+ANUx5DAffnzDG6mR+xE2Letb0/K9ED/U9pNjB1k6ONPjcy7Jlt8LHSoR1lOfxGjWEiOxUWCDs6NwWQyA2b8ZZL/Vv/2G2oICvIOYdvQm5eJW3aIFF49juGombKYGo27ENpVCTgZcURThPvRcU2SPaw1AcMUcm9oYYKIsoO+QB8/MRF+M5Scu0cqZnSkRLUlZkGg0ugjLPiDttAigNu5hz520lW7UU5DGf+iNCBnoOhgTG1u+cIc3YXH4F/uGr/hmuvvIMPuVTXoTax7prbcphL3bP5C+DCv7e/Ih6UAERzHPFk550I1734z+Ij/rkz8T2WIGLTkFnewm8dhsZ7MpWpDsPDchikY3PtXu/R7uyiD7sZRwCtkDI9DCui8vDdc3qUpJhP8eOjUyiUeDyzDqRwKLrevJJ1V7czvcPouUAYrjmr1wDSE/H+wEOnI2jadjXXnO4uQioW+CPboP+0fuA688Aj78K8virgStOAac2wCHarl/Ol/ZbJjEH2xcsWptwWTmBFoh2fULXb+yZk4377HbpwN57XYQ+behYZAI2lgIrpG4wnQc25x7GfO5+4LBggw1U2kr5zWaDa6++CX/t8U/Dyz70o/A3Hv8MHOmE84+ca4sEUbrN7MOH0PV01fRhH+4sjvA6wr+GxE7oe5AgXkPyTXva3YuFJ1IXdmnfN0wsnPT9SMVllQxrcX5gOGdViiwIznKY3PijmVl2XnLRNbKN9/sDAyHQzRXrWH83DNEKnWccXHE5VBXzAw9ApgNEhN5ukj3y8Qx1r5ANMLirChvOdZhzoM3OSbkf1ox7W+1BA4inNp9rC1OW/A4Hu4w8W3cIQFf6G5kuhxFC32nhmNcJP+clGTxc7hwMZMNwA+z86K8Ah7m5shGUa67B5/yjr8YvX/GdeP5HPRe73RxBQCmYCq0jJPmyf/NfGm0WAGorwEtbPPUhH/IU/NKPfh8+4aWfBz28FmVT0IbbARVFRYkgg/rLbbttEe9MZNmBDYJY2GUGv6iTMoGuRiybGGkhq+eG6fQwWLiwUeFrHdSybGH4T91oDbDXSYu7uE1TIg+EiAfdnpdmGo012yqAKFUjQDkAjg7aZiV3HAO3vAf6u+8GDifgogPgsPQXk7hCANPUN/Tv11xgQp/wk+i9DIYYuNJUQgJbAmSOKhjcDWj7XK1Kae8/6ZWIAvXus/jyr/sqvPQTXoy7HjyLU9OEWoDDU0e4/OJLcMOZK3BROUCdK86fu4Ctzpim9uy6zXXzosLEWcJCPpT6LPR7xIp0w16XvgTW8fe+gPnEuoa2T7zNi1rw2F9EkG8alHWlnaBDQvh7Mt6xUwvw5XoGp9IvLs758OEIskrXBn4HoA8HzWu5slKEDyDNxwqAutthOnMJnv7xL8IjZx/Au37t19oKRDFCxYeqAvhWsHVwnoAmJ5hjtkafuoMMfltkzHOmEUC2+RleOGVoqx3A6ewQmHSjFokAIZWL66MwxHk7RIUeHLA+dIdBsuNhaEAQxXgxF5UnJ8WRqveO9LyiQKCYbJepTYHW0/jkL/xyvP6nvhdPe8YHYJ6r0yZo/ikLL9OZ4nShfkosi5gg2M0zXvDRH4bve/W34Qv/wT/CdM3Nbcqu9ueC2XZMJ5z41mcPsJR4bulh36je2elYGHo9rp1I+igBQga8rH+yaH/4jgyGMa9qOpp1jNXcsu6BjaHXQ/sR2Fh3VkCWbH8xDdUbzxNfPHoiaGOuMyClba0ppem9LaIrmzZve3i6P/u6Ax7o23CGgYeM/LsgxrOpDPmLfAxOw0GWAJbBloXqzVi7BritzaajChSgTAK97yyeJlfjwx73ATg+nrEpgGrbdW2uM3bHM87vzrfu26NziBdytEfqVrqAjAEmc++PlZHgCQMvVyl8D2fJNKKyHnSv6Infug7SIxibmQ235z5TQGd1bJbo3Fey7YXtcOS5UuTJ6cdyDCl/on4RkfR/wnus1PdXaZvLD4p6QrAhAFAryuEpbFVwPM/JAbpDYRuiw5zLPlJ5+M6dTS7h5ZYYZ87P2uEMpGe/FJik4MDoXRRoxmqLprmPRme0P34lo/EoFXE/O9be2TY6IEGbZjfp95sS7+Gj8YGdV+NLLEJSCGa0IePp1BHOnzvG33rFl+F3f+6/4drrr0at7fWKVSt07jIh2akyv8YuSwCXxoKPqRRorfjcl70Yd9z1L/E1X/cvUG54POpuRrWh9LFXDFIkfw82TPfEtYMAOmq0V/EpV+xE85wX0miJeNBFdTN/V3Q0S0eJZwQww2EO1AMFqoKD9OxokZ028wvBGwdPBmYOqk1umvtolakqMJX+WE9tQ7CIRWEA2sKgsun1ZC/sc8De0KLnw7HiKEafvAAN82NY+U7tOPAO7QmASaAy4aH5YWzniocfOYfN1Nc7uL0Kps0mgpVeVekr8W04OMlsBC8JX2I82ncYUC4Spj1Zq+nQ4tiHaavZ6wkYEGxIRVWXVbnfhO2NnC9TeysNamvFVhB6g50KISZzPWt1mfNOK48lnotSoD8nZbqkUZ4+Cm2vREOsRH1sBwmHI8I6vpCgnR9X46oCUhH3pihNMueVFtzwvxxwIHhuc36NNyHF4KMN/FB5ujcBjTn7ThrX0WhAbP8mMXypFj0bX8QMpfOaHNIIEwNHyNwjQhDmK9DeJGKl1Up0J+B9ippbkUHW5ECV6aE+CwBRQdW+w1Qt2G5nyOmLcOed9+Ilr3gVzj1yHpvN5Pe2LRdr8JE75U3Hqvn0V2JNAQCUPrT8ZV/6ufj/fNkrsb3zdsh05K8lMx6QezLmZVsyXlhgIsZXCf0BmqPsNSrUd6yKusJu1PvbMzch24B4EGfyYQdg9/pe1yZnRf6N0O9ln+g66bPr49BvrtfaTzJJUWD4FgdQIwhI/sx4GrW1FbpWR+NFl3HpgY50f4WWLfqHgpngsfXR/vKTCzXkwef8vv6BrLe3+ExOR2q773HcdjObofMOtSrqvGuL+6BQ6Qun+rB3PBYlnsmW/j1eNZkXl8koYxcWOmaE77fMew1H9v7ytgb5M7OGOxlvPBCkj2MC6eVqHdnF06HppIhgbTIqf9f801dqQsPvUWtpYQXds7Zq2Yk5IYoAO3wsjWkfnX+1o9+cosPlpzE/tmixRR9SYvk8Q08C0dSekCzMu7SPmOMcQDJFz4Mg03BiB3lzZFxfRO0kP5ghhyswQO2o5O1FeTvF7pPnmFd46OUiwLCuQ9C3LlyK0IMRMyb6sG54xsnhZbITAwrvpfe98WYH3T6Mwysuw9ve9uf41M//MmyPdyhF+jQXOxAiYny3e3STnHjb+GIz2S5TFdvtFtvdjH//z74Un/Kyl6LecQsOpoINZky2CYeaLg2hjAU945H433hhztULKNFn/B3uj9/qAUOkimP5oCkcpp2ygDzkn8DPdYP0S4a6sJxTDu+4wgPL8Em34kfQq1YW1JY94iZcV4CM8Yt3Hlt7PlbsuVVp16WUIMZ8oQStAfLq/Q1aybElu3TCOx3weWDx+eBC88MlAVnIaN3XQaUDbgdzBREaYFhKA9qpg23p5zIY5Sw3icttGF3fTGQZnCM4E+eby8h4oyuZL9ssn6NjoUXUVgxp5zvUaRxv9oZg+m63lrESbnpxqTeQsNgjr8yYRmsG2XFF6okg+xjqf7T7Ti5Af90jaf5rn1qxVMb2XGbvGTmiDnYkCBv+yH7anH3wU4R5G0DAGUgCE+dPa9uqSgtolHJQrX7OFNOi3GgzHJMPH8IMJaLrxLv+3cHOrw2yG99uZPT1lb+2cazzy+i06JNoS9m5RkZsmJCjUnOUQa8mGde+wlMxH5/DdMXVeP1vvB4v+byvgFbtQ2McJOhoKovDM1tEFlCK7TKl2O1mbI+PoXXGj/3Hr8fHfPxHY37/e1HKBNFtewsQtO2HS1GDiEA0g1aWBzloCfkjydlojJubfgZPeLja7+qAEDGOrd5PDiF0hlic5M1tpDpId2jEx3SfZRxS5OxzEIga/cQvosVzTW/a2ksdxvj8q9hjWlJ6LQZm9txq+0iZ4rqBHmxImeZMrS0PKKk92oPZAoLwM7196fV5oN2uidMz9SBgynRKoT617kv3d6ZKJq9xyNcCsNKDCSnFd2Pz2AH8hfBg8BtJbGsgS3ji51PgG6NNmvQ56OTrPoUgMjRNyc0+3ILpB3dg0dWgwTRNtW0Pwil/RC0YIggsDhPCSUPHjwUYTzpW61+hZe04se3Vfg2Aa5EmFP7E+ADI7tQdZw3oxJ2dC9zKaQzzirdbMz0azj2JouOSz5vB9KIPAYtG/a6PfcGLYKG4QjSjA8QYUDvLzDkL84kcuq8a6P0Qok/D+bsfIc+n5mCdCdQG87iOhtdojs06jBdRX/Qx9DmZmTZO9j3WUXfncXD1DXjdr/8aXvx3v9KDlHmu/qn2CsI9xx4WtmRHeJcpwcFmwi/+4H/AB3/Yh2B3793A5hRsK45J2vaOdnOul4MIVwznv8ncdDFnmUEnWHZeH/XCEVOjzx74ZL43MdocX9dr18OQfeKJmhQDWH0qRym7pqYZmIfxJNg0im156v2hwNY7b77O+DsCLflD8awRKav1TNez3cgupQNhmlKwa3yOAjO2dwEFm3xeRlaaRpA/l06LgTGBcquTdrDy2tr1qW/akwXV+dVlPFkma9ks+2r7rgSKqZ7l93V7WccXDuRPQpgUdA/nTVdz90asWaygGCkcKo5PG4a3cFBia/oTK6GvPI+QSj8GsJXho3s+qVyKlvp/FHEZKC2YpIsvC57sdZYWSavNJ8ZfdzxVUevcnK73cU9wouEA3ClavYK0s060H7Sbs7CAzOpzZ0uZKrgdL0P0eRNZLu3v6NR8lgfmKJuRd9kaeDroAgb61rb1L1ZDm5OMLJrn63qHyD4UijbHaPNIDMD+vCHz2UE8Vm2Pc4KtvzRfDLQ5XAVUBfN8AZurrsPrfuHn8Hn/8J91kVfMc5O5DbyP4LHmMMajlIJpM2HaTJAimHczNgcHeO1Pfh9uvPkm7M4+ANkc9j2dq/fH5goTQFhwxN9d5A4/7rSBAD7WyUXAlOw8RlhChizHmANuuhFzjl0M/tu3EKVgzYEY6qDoIx6JvaZnkV2LBWrWX6WgMvGCbMp0x4JL03INjGLwan2P+VHYX/s+bGjM4BjZo2WTlGULhQlDsuOHBenjoSQFjSkZ55jTGPPMNrcLKVCU/n0C+pxu6zztjBdEJA9ifPM3+pQcTACBB/7OX5j/5i5o2rs4dc67vz+ZWz2s3aHMavKnNIrm/VrizhpYr9G6dsnaU9jbkJPBPsrB5faAVUrlH2O1q4cxOIFPGIFF7Ov3nkykrP4II4iDgLF/twULtVbUOhPGrjFRUv0uQFYg6UY9RmH0lZ2ADhOFMSQNd1Yy9EcWfAhjak6LIzw2GPrwY0ISSsn8soVjKVo1Q6fz/eahb7nfOqDZQp9EWuS4ELGE7yan4YpP9XfOeTllsNAtDq+/GT/2Iz+KL/6Kf9Xf7FP6PK5Y6bFlIn6pDyLw+wXNkVZVXDg+xqlLTuG1P/5fceb0BvWhR4DpEFULqpSEF4Pbaf8usrLRsXH/ByfUC/BbangjF+NLOJ4cJHmQN3bW9+IlImTJG15z0PRAklLEIOHy0BV6gNBnH2Hy84RrQX0HiwxWYbvi+m7dcG0U6XO0nec2X+pztRLPt1K2OWaeauwqkl56AoFn09yB/Gq4PmRc7G/3jqWvDC5TPz+1oeQyQaYp9kSe2nkpm3be+AY0YPa9k4tfaWS0/vLLPFguPl1gMl0X4AqYCV3maQe6h0uPWe9KG+zJxvsX2sW4cyLQ7q1hQVsfR4Arf6B/L3jCzeP1UdH5mmeIHC2dxCC3iNEJRv8DV2zepkfOkodkHu1YcYcI6+QG+dOy2ervJG3nfLEBOIKiOQLOrowfjkA5+1qfo85zqm1VqXpUHnOiWNRp83YMgg64Qn1FYGpeGBN38erawEybA1a/Jzl4AqaYR0P037s1yJzLQIiFHRTJFVutNg3Iw0zpu/FIGGhbfU1Hbe4YmOuMgxufhO979ffh//nGb8fmYONOkIE6hIV47IMRMvWj81Dgzy5WBbbHW9z8xOvw6//v92JTz6Fe2EHLhpyFZY4uNLgQjBrLhOSE/rPNuEMx+9QARB+hyLJxebFqWP/MKTILuuKZo2O2sL8BaPqj84jdGLOZwU/EHr0DYvU0FgDsuk+sc62kVdfOXpOxsO4NAYQDTQMeH8MRA00jdvwegG7gKqX4vW3DCYFnoOjnjB+eDfZ7ezAcmWBfGewZawNZNfC0Odwy9Wub/n0Dm++NbNXmd+ErkfmjQHznSDaYTDoCd977pxoz2MLLRb2jb0+ZKDdG5XmIexVIOepnrDLA2UPj2mF2FNN2/X01a5CDfWcVDmajM1kj/ETAW7nmkcfYwfC3ybmAvypV8ug42+/dQz+YBANY2+27G2UHOyMhvHgngSMqa6dGebNdM3gxJwfNfEAopg2jt4gxD69zn5X5Z9/p0Zq1SX8eFvbLxncl5pJztCHedokdczhMc8ypGu8Poj0H+VQw64n0+WeEGozD1NLf+uJ3JcMfAYEMzJwkitcmWiH1EZy+8Wb862/59/iu7/rvmMqE3VxRtbZHJRzwG0Apow1Cds1hW9BoQ39t7msqBZvNhN1uh2d92NPxU9//auiD9wC7GUUrNrrFBlsUnVv/mNEdH5vTpcUsDlzLufOBxFZNqk/8LTG874vLi+7POS1/t2H64K/BbviPfEtaA0E185D3cph14IU7TL854kmIL49IAVZyyiu8oUCggdow1ykBsk4TQGDXga/YYGIJUKPFS9KB0HaaiuyY6+l2b6uQoe2xuf5sSXsBwa7ZQIl2Lfv1N5dNmway0+RvMsPUwHYqEwRt16MJ2j95VG4cMk7fk3+h68N3D9vZb+7DFArdxhElImD5ewTmPecDd1ihrCz/jD5y0gGnSxdlFfveZ3vSITGkEkqdowQe+x5xkDtmdXBE0nCEOt2BJd3/WDLWFRBdxE9OdkLxxU0eUZmjdgOtbqxusAQU3hfQqAEoUuO+UlkvjyjDztrB0hxnAkcCZ+ezZUThUPyvMK+s7mA9Y7gNdXM0upZ1q9YAWeOqWh3I86xEdpYZ6RO6Y1wBMeZ9BNWaq1kLPDyoCYcuNFccM78VojO0bDFdczNe9U//BX7mp38J0zS1hVLEjzTPRbwlihPQagcOX6lcBFMR7HYzXviiv4bv/o5vQb33zvbmFcyYKs/hGuCaDZLZq/VAQn9d/hp6b+/r9N3EMv9MHUd5+5y9M6s6LZYt80I9n35xecAX2UoPEBb6RHbBMkoyNGct8H66cxv1kuUvuU8Y2ucRpvgSztkeA/LM1KjU+OvzpexbfCigP/Oq4qAbZYZX6XkbVN41IC+Ys+ktbArkmiuB00fttwUADvgTVGxlcstm1c6VNnJjj/FMRbARYNI+Go72DmiQD3HZiPmUOCfGFzNViXIJqsjPjBMSYz+t3riefYJzj3Gl9z8P0Q/tsN8QrAMyX060MD3xl33SYwNb6iUzx8/sIYodzzi31ylIwLTe5FoMo+tMGIxoDXBzeTIajlKtsrUjVZlCBLgz5Utr1ZjCgZRmQasmsBIqQ67WAu3sUDDc12W0mAJQ9exbMYIV9QnEzyEmWVslyHV4gDH0/6TFBxG05Dp5pMBuM7HF6JCG0RugSNYiu6QAbXLgrftfBVBFMEvBrgL1oECuvBaf/cVfid97w+/j4ODA22nz99UBlNuKatcdRI5o2spOVcXLP+cl+Jr/+6uwu/ceVBxglgPM2OTHHtDlLy4lMJMkt0JqqeHsmBQ1PrYfHli7JlEtUXAhSwY+PtnklXXV6moBAAt++M6njVi3A5tzNbDPHefhfnfEIv7sI69u5/t8GBURHLjChRFTHTaEywBKdduqYKDvSRz993I8p4vIoqN+RB0aoCUQYJ6BU6ewefKTcfDUpwCHB300LabW2lxr7I/cMug+b9uzXNu8wlYZ27OzhVYgL+VrfkjJitq/kfHpeEv6Tla6+pchGnSGsWS1/hFrxvI6QjzywtOhVvaMy15RHaQbf+XM1jMMi2B4SGFwAsymBVM54h+zHCpP5pEKmMFYR3geESCgHQVAQYNF3TEMOwIuHXsVi8vE356IOgmt1q6IJkAWZMpINYFHCFYJ33nV5TDvYQ7fonjvQu7D4h5rn0AuXLgi6/QIoOJ0WNaW2qC2go4xc0eAlcKzI+PfCOTrQ1bN/CJgAAFIpVYRRmrd6f3yPkAwa8EOE3a6Qa2AnDqFOp3CJ77iH+PWd9/SXinWaarUj+S8FYusXJB/s9UaXbUq/p8v+wJ8wZd+EY7vugvzdLpt/6bNcNt8Ga00NRapzYhTWwb2yRA1eKfD6c5ftTKmi67bkoIfVwzWmSF7FJoDNiC3ERuzj1bEVvhq0G1/JJ4n9za8Rs12EeGHt2fyNZr7BE7iQai3hExEfESASQLRkoIQE6fkjLSfJF8DxNhT++4AO/okifJJlp0oXxsjbYV7LRtgc+AbxkTnzN/RSmlbQNVXF/NCQFv0mOZquS+dR2mEx/XZnZ+T6mWJc9mNusfik0OyELAbPjJ77qzq5IdSUBi/dbhZUxmuiwus92FxUofMNrBycN4YezEMmVkREzY7Vm5vHy08FJFlA5tDYX9qTmAx9LPSwHKlKrWrASW5n+SouUQKKDSeN0e+XazXLFQrWUhpulPwwMGdl3Ggg+7CqWEAGBn40yk2xzgCX6+ndUNTFuJzVsa7rlDCfIlIJdpjx534OKpjDGdmlor1JG5Hlr1l8GH03eg0eB5AbdGKsbJf632K9oK/LHMRc1zGCEBQIbvzOLzkNM4/9BCe/5lfivsffATTVPouOlPfTSx47v3W4RT1NeSWs4X2MvsZ3/UvX4VP+6xPA+66BZvpEJsyY0JFEXskhzkGD3zYphJNGa1gGQ8fTW0YjPNqZIkmuQPG0exIF9nBHo/Q5SMGzJmafE84iKCFADLsBX0pgd/QAVupXrMpK29glulrZhfD1p7c8rOk9JcDXuOh241vtBI6bouPWtuWIUvUNSY0BOoLn62A7BSwzVF4nwAOD6JxxLBycdBlX8X3WDdM0ks0ICE4i5nnUefKnVQm2vJ7zP9jOWo2tLBa/6i2jFY6FNoPpeuwPgyOB32W2Y5Jm1ehmSnpXPuxaM47u5ZxIYBRh3PWTAgxd8sAaXXBlQnTnIg73yVjU1+MnkUPlseagOwRkUUppRr5uhmH0xmGzsOPsqYuYzXEQzHFNlA0XvR6IkMmMCF6ub0xI3L1U7sqtNqWwXNJn313e/PmKxXsFFg0bMBIbXN9zJMx2PJMdWyf1bgDbZ6bU896re00lK0NkIv2Z+XmYxxcdgXu+It34JM/9x+hqnbAjUibs9zBgAIUsNQrXuGpgL996Mf/yzfjY174MZB778A0HbaRxkoS5KbYxiyoyqxLf8ORZf0N3mR9dv4EigTP7e/Qhg/j0jPmgeUabRLfw5lq3I9cPt6+EvZjtHk2ZqFU/223ay/jsu51B01Rt9Xv5eHdyAEeeXsfQTF5GMgbUJAetG95dK6RYUgzCDEBrdGise/1vINqf/OQEtBqfGg9c1Rkq5A7JUUGmoQCAuO1Kmwy1v8bA2+he9kpwGxUnK4g0WhkRLB+i5fLfImvkYTlBaeaeIDER/vOPs2fr142Qe2PUzZD8IX/kwVSXKFkApbucP2eNdBM8CK2MAAJVHiYYq2RMVNo1yU7FaWbGJQMDRZEZyF7RIAucIvGRRYSE0TZcGShLnbCHQo7Nb+n35CclNGcnaDziPqXMjiunUAIiXbK8rozSGDl/W9GQK7M605DyOScnP/Ei+RsiMWGmw4kMrYV3PMYZxEwRTkHWtCXRRCSCzqfO0EVgrktVcKu7rC55gb87utfj5d/8dd51lxrbVsx7tpm7gC9zcz5l72EOzX6TP0NKocHGxQRbDYTfuF//Cc8+RlPx3z2LLA5DekAPxVFkRxAWXbL8sh9XDp3p8n5QpeMdGolsgsq0Jv2oI8lIawlg4SSx7eL4vdYvQaG3D4DdVNPyXX6TlIBiryI0zPQkV+y5B2PwnidzBcHFPQ36smgu6BnmAd/xTwXXkuQlCfkJpJeDGDbMBqwpADS+2ffK72Qou8PbllkoZGyARjHI48ycV+Gz0lHUgJrzGQB5Ep4phTeV6IofeMa9x0ulwVyUz0r0JLod5erRGOuuzCtY6SwmkUOkUN8X29/JJ8ZwFHWCt3klG0OgMpTwcgG1IFvnMOFrtFIUQ5iiGWkXQZlNwCwHQLbsFN7J2QEA+QAyDlk3ln52DNY7a+q76BjXfcybkR8DqmO6KyEI0wOBawJ3rtwYHDnZfgYw4HqGBTtIdpBrPJVcnYhDhloV8TQHvp3+DnOaDTxmFXB6oH/NR0LNabrHOVarwaehfZYC/0tQSiYscFcdzi6/mb8xI//LL72X34birTN2+e+s1h1uYRD8hoHlUrzYX1z981k2zq2eeGjUwd4zY9/L6685iroww+hTAcoEBSnlZ4F7TxdOxgQEi+dB9Rz5r02WcYpNVUIGYMXiGkCy9BFAyZ1gHHQpAAo9grP2SlgORkZ9RCEK3judggOPNOxuvkw/WKGgXQxn3Z7layTDdTtyUobUjZgl9RW63S3mP7b2gqZDPTAcNAUqC/K8qxzCRwC0H4HnXe8A57RDUl8Wz1GBJIIRNj/WpY7/udVjAEfogtt+9ksEyUaIx6IwMkDroFRIrQaOYiNYMjKDHq0xoQlZ+28Lq6HSxOUJZifBOHo+p1BI4EL1fIoNdGQwgklPTLcA8iJBqKPCixH9nM0SjdSC3CF8gVhpNgQYLPZYBKmjPqSPCsI0MjY6TYfMtGaaTfFotDRhxnNwE1pmAdGA0dS1jMDMuKFgyQHKUK81Ay47MiY3tiOz91/p59ZPYBip1N6QBBDuCFH3w5wCKQEA5YrDScS+13PdFg8ZFl953N8pzphp8U3GLBgou6OcXTT4/Bt3/5f8V3f/cM4ODjAZtrgYHOAqbQArNLz2Il+CXfjfRH4XrOl79gzzzN2uxnH2x2uv+Fy/O+f+H5cfEqAC8dA2aCi9Ec5JMDNRx8GnUbYS8wnddkTP0jb41ZXp36vmUPiFOlFevsL8RwEEoMMg09ctsOxg1nm5foxPoqTD9cxMpF2Phr30/42oAB8bjWtwQDptHVEsg6aKbOPdPNeZLvxR4dzqRbT77RRhX1oD2RvSOOjtT3OSAlHoMQ6d+F6EL/Vz7D/XLs1fBGNjdAhST/g/kNzlXugI9ytpgJx7/5AYlWnFtg7eAdZu4bwI50lntlSUtE7t85lP8/R8NhLi6pXCVd3qIqlIY4hpTNIglXGMBeWxMcNSEKUQdzYGaLXhLNQMvI01qepQC8c4/jue7C9/4HeX4oWzYFjrIMCE7GikvaPZwG5oyee+ApRDcHanBAsguxeu0XcQN5ruHPFMgpvvHPKHQbN5IqxyQyRcV0RgGwZbQ+OTBeHiI6z0FZX5SvRHgKAU9/bjwXIs1hdPylaTU6XDQHxTKr1g7Og5Dw4eNEKVWB74Tzkqhvx5V/zb/BTP/ULODjY+KIp1baquFIf3L76h5/9k8Wnvdy+DUvPON5u8dSn34T/9cPfjen4Ieh2BqRA+5xXPFNdvZPZvMhuFqgxMLMLn99GZc5x35CbK3HnkcfS3c48axpooh/g525DN0MOMSqE0FcM+pECNWs76PC7hkQhB352zqoz3xfVL0a9yJaZQ0yXJ1dDmKIsKOJn0B36028IAiHwzSr6RxPw2p7IrBC0DnrYOyBscs/hQ/OuEUxy8sPpGgXvyW9z1TC4HZWTgNP5t1DwkOkK0BreuIxWbS7LIYLTkcr8k0KDxWu2gZXnbBfOaOVwRzGyoDv5fYcAlMoP7a22Y3flWtamtdeGI1LQQJmhQx873/C0roC+pnKkd5qgxxdwz5vehLN/+ra4nrJIMvBlY+QwuA8g52H3E+B0wGOesyyikkapRYPWBbXz3qVeJ9TtNmcPrHhGf3Z8kbVaP0jB2WezEdB1M6zGi+yw7LwUyv7cSthBgqIVuuQBgDN9oSONfbF6ln1ZkCpuoC5qoL+0oAK6BeQ8piuuxOd/6dfgF//Xr0FEsNvt/A1B/lYiAgCt7ePZ/B4Qs3fhTtOEqRTMteKv/7UPwg98578DHrgHpc7YyEzvwp1zHJkY0iwoDjuHhXyaIIZAg329mr0wQ3O9/K5kxwQJByZUdfgcgZHTnJwpr0QAZq3Q2564nyFCdT/iGmouof8YV9ymLKornNmgm1vCWB4NWvGLOtBs5u318wWk+yP5iRezNyJKHhY1i7EAzl/nR7tG0QYa2W/E1IztijfbFNaeoIqDDAsKM6gSsCKuLX10vh69H9sJ/+jqgPgevyU+qf5cLnAuA+k4jLzMuscamTpyHAsoWnnOVsY61g7KoFajgaGjaRWakcPfyejG8fdlR9bgl64ZPRRqpDq9TfsC9koYmZju40jJ9w4FRdQ9o9BhOMYEaIDJTjUJdiRwpMuq7QbN0TpVlbJ5jazWg5eOvPEmI0B0OV+RdgoSwDLkFKUT4ZxZWGZqAQIrswceHdDd0TKviCNtoYmBswFzlBnnet1BezAB32UrzbuNIhBiNwad5sOdd39LEBS626GWGfX0Jfg7X/gq/PzP/RpKKT53WzUy3Fq1T5VlgF3S1b6UvpXjVCbYiMV2N+PT//bH4lu++WuBO2/BRism3aLUXd/hrJIqkx71LNXdArc1An4HGB6NYdl5vGb2a9jsH9J7P0IXBOzcOg/E+m2ASyMsY12h8E6H9yWISzyIjLX7hD1gAlhgZ/cT7YSracSk62eYlbUpzo/EAaYfPRxIQaT43zTZkHypDOf6eQ7k/I1DeevIlJWTrBv79/OF6UteWWmFsPGF9MHmtkP5MmD7YX7S9cf4Gf2NriptCRrD/WkEgJk8HuTL1qZHvdbU17EuWf0KC0C6npRVIgigQ0mykjfACKIU2OucVied/08OZjCAMZuNIW7kv0uKnK7kTEyiaw/Q8t2CrjQ0hNKHYSQ0i5SXImIDN0YpAvh0eo0FlqGrhmNyW7O+dL6oBTCZH2pO15xGUhZbnOQ/F4m7h5O9/Rxs8VwwOQvrogdD/bLW5CcseFkyPTum/CO3lQ3D/IZdb3xa2KLxZdHkypAQYZGItDfzoLSNBA42mC+6FC/9wlfiDa//A0wHG6eu1nhFnzvpwe9a9SaDcUjZs4/a3qv7Zf/gs/Cqf/pPsLvrfVCZ2qybdn3EDOgMzy4t/hx9Q2+c52tdhxNRxmmFDDyOOeDhEYgYUgE6kLO/9TICf647ALfbjdnVoBsyCtmNJ9rMScCAnd4tjUBiMD6hghZQNPslDyShC9yf9JYsb59GV8h+06FDXVbB6N9YiTX8Gerc7Gq7hdRY1Kj9Hu3DyerDzvS2IAFESl9vkJtbO9aGvpsYw954eo8DwLaJCc/rR5dsRzSbSa52nnylA7r3b5T9SNVI/HrPgr3mlFbvXt4RLpCaDUdaUmFgoYisbA4gWAFQMti9GQFHbfZ7iFYb1sU8lgqBm9MfMJtA1xQuBQbrpCwu6/gD5HiCZv+wA6nLTBZqkWW8CzSGKq0MAjiVn1+E64zCrsc1m4tVGurh7LElLwp/kk7d1JxOX2SCaN+8UawSDc+UgUgHfpGzNYeZAgiWOxlD3JzkFsN4xoQc2FmwYgGf81epPnPsLERiweqcLNGSMmcEf9X/sctNIxrgTph3Cjk8Ag4vxsd9xj/An/7JO3B4uGnvwq3x4vkYHYjqBlNIzpoPK1J7Xd/8dV+Kz3v55+L8+2+BlkPYft2l7gCdo08c0GHQt9StKG/65/qqcT9PPSTdtIzAwNt03Bw/lQ9gj/5lsGc9IuAl+bC9hr4o2WnUE34k66uXYrmQ1SwiUDc28jkpOzOCaRcurisFIaaP3ZtJ23WKZlT9O5yvw2id96sC2y3KhWPgoYeA7XGyv2aB9vID26qRPlKAaYOa7jjhGP2C/Ssal8139cCizdOOgQJ/mvwq7JPfj0y3xZfBjEc8SnmpaowKUiYR/mVYRHlS/4e++x1DYCQACkfNa5TrWIENya4MFVtH9max+0DY7osfSw80Vsnh0FjX2ok9JJnTSUjq5Io35RX1wum/tTTJjHtBmC6UwiFJLQNWb4rbNufoQ2HdkFN0DRjaeqcNoByooul0+OM6DEoJmOO/1C1yUJwdcD0uKorkc/PkfEjZBbLEHLE6C/ECntmHSkjWDxP0CL4r1bOppQDSL5p9WFATe+nU3XlsLj5C3RQ875P+Lt7+p3+BqS+WCjmp3514mI6l4toLu81md7sddvOM//Tv/jk+5kUfh92dt2OaNthgi43sMGEXdTgQ0baVqbPUHikJwbGdSvyzPoWcw4EtzJNAKjGUMgC/LJIdH+mZ6ylnunzRr2Mpb16RSG7GNZtlYXWljigrSKI7hmkpIZAY7fHpNAViHrZf82rU1ZRHehJvzVxcFxXA3KZkj48xv/dW1DvuaJtboMlcUPuoTnsuuwja23wE7bnuzQbTtIFAsN3u8H92rMh8cK7GFxWgQjFDsfNPxQ6KWVsSI1r7M+iZ/fswJgeJWNG3Xo6xDEjfm2qMWr/nWIO0FTMC0qYWAbIJ+MZbVsAIGEB2YMSY7cr4cQVcjptn+vibuayISBx4XFMHHizAZdmnTnBX5hxwhNwUOrddWjDP8dadEWgGVIvsiH67xfR7OeKnSM8dCXywBClitTlXX3ncbuYFJM2I+/3usCxD4QCH+sKd74GP36Mhdwdl0x2nmZ3CELg4PJEgFNBxk1K6nGnKGm2ZrLcvZHz8vtKUmSp9wh0wrdrnotgRp4yYX73Yd+2puy2mi07j+PgYf+MlX4Dbbr0dm1JcL2KQbH9wulxp0GzF9q5VbXPA2+0WAPA/f+Db8ZRnPB3zfXdhKoKiuzZbp3U5H+68i92n2Ib9zUxCcky2yeLJXAvJho67gzVGWlu0WtVfHdn7nuZT3T2xtiiVd2LglYkVJ+VjXe1ycPuibAhMvzhx6Xlak53IuLNUr9tfhUj80T4tYW07C6XZMLFUOyIlE6QAKfc55Cu1Qi6cg9QtRNuQMuxvnSE6o0CxEWBTCjYA5Pg89O57sb31fcD2QcgM4sXSh5MQ6KtEsOD2QaMeGOTRutey19pHfvorK9H1XKTg7PF5HNubxMCvtCQSzAeYfzAf6OSwbrA3jToYoSxA4mRj7UgcGZLClJyoYBP1yPJ2W5mSKtzb7lAu7l3MhQ3XA/TEnfVCrMNJJUZGD/YoQ6BTKhfDCzmmCVMbutsjUq0z5NQRrn/2s/Hw/ffj/j/7M0g5SG2xAji9sqixX2zXbIGR3ZuHlDVoV1IRb4P5QQ6Jrns80O81I0/KamjgNypiyziqeQzIlBpTDsSanGMIiOgfDCLzi+gfFYLLcXBil0dAMf9uQ3rpSN4CvgE+XVXkhTU5o2pDYtbDComt5+YZmzOX4L7778OLX/ZFeP0v/RhOX3Iau7nC39LW36JimSon0KZPCV40nDT6PZtpwlwrLrn4FH79x78Xf+3jX4q7770XmzOXQOf2/tuC2u63+NqyBY8Ke3DSAx5wn3u5NHrKuswBRMJHAudeTZoXZlUOeKY4IObLKVkmmYifS4cT6YQtQCH5AuOD8XuhPwEWqX/kJJLNDnxisDF9Gf2Auf+FD5NML3dSDdT80+bpWzYISJ/GanP5E4ADlDJhggC7GfXCw5Dz5zHJDjfedCM++AXPxfOe+xx8xLM+GM97/ocDaBlvA8lxbYaxmAITZ0LIyACt2msY0fa4KtJ2uiqq7ZV9U7Rzvs74i7N34i13347fvPMW/PJd78UHXXEFvvMjPxFPOH0pKiLAKkvGZPnQO7b3QVe4xKFv/d8IzmiR2gn1qMuRFE8Um0TY0Mxapa3NMCqeCA+ah4cLdL3D5I7zveTIc+QQX9QumjIqdzKUY7XhoeIYBqbggLN2K2O8mys2Z87g9HXXo24m3F/YiSvxOBqWjlkGREl43eExzUrG71VKlNF+X6OrZhCTXJfA6m/0iYN35lXISd0HB1ZnJ7GUT7S/1j9lp0Z1Gl+NHv9XqR/E1uAxPa5jPPQoHN7XvYah8UhIvMd2TVHU64s5SAoehvoU4pm5oG1IMV12Of78be/Ap33ul+B//eT3Qopgrn14TBHvRzVOpqAjy0kRvhUAihQoFJtJsNvucN0NV+JXf/z78byXfCbOnTtGOXUKorvuMvoaCLDTCMA0+WpYdb9gesXyG/SJ+CJ+jYHC5BO65d5DBvsZAiBQs/4ojhWNaIAEz/QjBQHxHC3rO/sr1u8AewN3hXej97Pzi80v2XKMsDSDygFf+ED1H9ZDvyZGoTEDRLGClhHB9h0XaBp+3c0zdufOo567AN1MOHXRaXzohz4TL3juh+OjnvsReN5HfTiuuvJSjIeU0sU+RBns41ccueuqACrqK/LbUegtggU7rXj/Qw/grWfvxW/c9l781l3vwVsfuBPHu2No2aCeFtx5+534wbddha/+sBeidoAuiOkz1hklPrJPXMObJIu1zB0ITIm7Unv5MA+mSYYAGtiSy/JvEasPDRuIcIdWCSSHTGHp3sVTTqvurbMXcKBNXXG/EEqrj6U9GT5mFMZPYVa3oa2qFZCC7W7GPFtHV+KmIeQWklGii54jDdBo52xBR6yopfkIYdAYuiUy8NGAkLtuQ3w5IIrrAh8+01RNlFX+MpQhWQDao2B4Hzg7sqE4Y33rcwb2ELJzIWRDgVWQSucMpRa0j30Tb4aIJGBedpOe4PQ6W6VtmHiejzFdfz3+9+t+A1/wxf8UP/y934YqDSgb0Fpj+7YqD7BQJUfmhDYHPm0a4D7tGU/Ez//Qf8UnvOzlqLsD4OCgBSelZ7YSrluKtKkGoVicRigcWYxEgMBjCAxSkBrgmq4jzMxcyartUHnmdOY9XQ9nQ05WQ5yDcq1OV6kBG93vdYZXBAj6SF1aUeldH40y+BIsIoZyv4X/tnZVqH2xFd3aholRmx4LoLKBqKDOM3bnzwHnLwCqOHXRxfigpz4Jz3rmM/HJH/838dyPeA5ufvwN2Gyi7d12C0XLZoXf+IO1/gT9qm0o2O3SxKExxQQfvWm8fHh3Ae968F687tb34DX33oI33nkb7js+h1m3KEeHKKc2OKoXQWvBcd2h1gkPnj/vyYUH72uH0SWZ7nUt49vCDtKxF+vWazQoGYtu4h5SrhPhLhtQoidlZSQozrjsHIeC/R6uI3eHBOjtif+NIcretjf3KP1Yu6ym5Ap7tbQarWaAqu3xC4xVWMMWvVtkrAu2mR25TZMDS04eFAlbREkRuWWN9jiGr6aLdIMyEF6EFYurzEDsO2fXEc3nuRdxGavTgSRSSU4ZQY63F+dK3KhBG9cX50b5am+r89wyXosTXOd41AOB25RdjyMA7ptNHjzaAJDmUaBEuqAQVFVImVDnY2xueiJ+4sd+Ek983OPwrd/4VfQIkKIqUFBhLyofDwWDbP9u/aV2y0aw2814/kc9Bz/46n+Pv/sPXwVMVwMbBUAbI5jW0KhIzLN2XqSRFFpJbBIe9Mn4yYClQOiyGlCRPzCl6ADCgcAIiGLyoAxWu942WzP5JanQb8qquR+QpAdkXSxsVuA4rxojVoXrIa1zV6MRS5OrTX5EKv1qfGEeNj62YeKWuW4AnaG7HebjY8wPnwO0Yjp1Gk95whPxtCc/BZ/2qR+P537Yh+ApT3k8Th0eYOojKfNc+8YrM6S/+KJIrHrm5CiNtBFzQxf7XKraWIx0F9v+q1rx3nP343/f+h784f1347fffyve9fBZnN8+gnrRKcjmAOWSi/saA0Wpc1u9PiumqTHpA6++FqVIS3BYwHRkEgloWSZspwO4Ov1DoLE+byuLX5J+uxOCCLBZRecTdrZImMFawkJpX8DF/FxKrYIBjwqMHhEuyzHgykDHo2e3A01MsHQXQ4ARfY4hmz5ARzfHYhAvzpehJHzJQOtNq/OHwcczfzP+VC3xwMGK+cIAQou6kkCtGgUKOUNukxxW5kkvZoBqnHAdMX5SldSPNBTn9bWgp50zZ+Vu1P86K4SMzPkVABOG1EYNUlms0O36owTccF2UgXeZH9KfaQSKCko9j8PHPQHf8R3fgafedD3+4Ze+Art5xtzfDiRlD9Aq/KUGPJQM1aSa6KA3lQKdK1726X8L77nr6/G1X/l12NzwBKjOHni42Edeuk6Sw6duWUPiZUNfFgN15mtyb/ya8zoqzs48BTakYGo5Pa03MPBcsYlxamrET5+TJ58X4CfZdgYgt/r4eeJsyxqJhHfWRqzEmiC9sXPae9jrFoFiA5SCogVSd8CF86gPPQKp53BwuMFN11+HJz/5uficz3opnvucZ+FxN1+PU6cOfZRL0RbT6RTvyZ2mCWWaPOM0sRfyo4YGtUZAVrS/WL53YBJgQumP6gC7WnHXhYfwu7ffgt+863b8we234K333YWHzz0MOZggR0copw6Aiy7DhAKgAnMbCWoLoFo9FnxeNB3gBTc9qQc19MSqBM9McmsIgUcp4ddOxIqV+tZhki6GTW/ipNJ/++tYBfh+IakYe80VBXUQXIsa9mTF3AWrzfkdsWMvLuNtI8H7LkRQYKAztt28H1RrG1LWphqelVQCoU7EOC+aQlwnRWAvzc6OwuZhzB5pkU7zwIlHlrGCeOGgqSzdyExspx7vq6I/P2zAY7RGBhBN5EUt0R1xUPCMKgUPkfm3P7GakacDLJvVUcepfSF+LNjaeRIpRWQjS/4YmUpOlIa9nV9xr2WFkdGIE+tQLxVF2osJDq59Iv7x1/wLXHHZFXjp53wyao0RhBwcWV8JaD2+IEDrMopFVq0fda74qi/+XLz/1tvwn//jd+Pw+psx746hEFRXb+oMq5HaPPsyGzPHbfjkXLW4arR3q54CEddRQzzWXWejpPaYvvAfwZcxAxnbN16meMjCj65Qo79IgavRwPqL+G3A6HK0YIPp7UzggNS9lwN+y9LbqvMJGymYZ8U87zA/+Ajq8SOYJuDGJ96MD3r+R+KTP+Fj8REf8Rw89SlPxEVHB85T1fZct7diL7cQQXtLEPwF8R4wpUw2Vkdb9jrTu6iLGEi3CZOzF87hj+++E2+461b8xq3vwRvvvg33PPIgtLQNM6ZTh9hcfmlbZ6AAZgC6a/QMcaavSJ5a+9cfXoKbLrq0zfsaT+NLN4LsJMYALSS+7vvHZC7WH6yV7/7sUcBZJerd+H0e/ydITI0bQWzvQiVzOck3rZC63gnsRXRd+2U2uLfPJzAjNAkGJAyu45DQomkCunh4PprkuWrAhmiJMgdNBpNMb4qkGX+ikgxMTqISeHll0XaqL69ItvvtXJJVaqe7QXdINIyWDBjJGXWySf8pJ0o0xpw1jF53SEgrITPPFmcaHfZ1uC0vksjGqGykrvi9CuqXN2MMM2K7c66YmuEpUKYCXP04fO4rvwavuelGfPTHfjh2u/Zc4zzbO3ALOT5056mh7+aUYUAL/0R3KmoV/Idv+Arccdsd+Mmf/DlsrrsZu90WVQt8blkAVRn6gTaSgKgz2Gb/kn5p6AtIruh/lHjGiix+fdhGQZvFmN0w4ke8Go43FgMSgDs5AdTUQu8jg0ushxhHyEK2I0BKqtDXUCQ+mKMJGQG2LpwWc/UdnQR9WmXeoT58DttzD0N0xtU3XI9nf/hH4ONe9Dfw3Oc8Gx/6nA/ERaeO+hagPSvUGX3hOUSAaTNF9g5bIAcmLrLX7v/MblEbBoq0saWpCA4IMs7NO7zv/rN43Z234DXvfw9+79478P6HzmKet9BpQjk8wHTFZX11vnGst1WMGcEr5yfxXNHmn59y1XW4aDrsgWmWYaDv4DtJ6ELleCSUlzF5v82eWElZf8gHxQnp9mAC7pZpXfHVyCuPO+w7NM2Z5WsZXFYKYHROUU7pd/bne6gJnV//zfQsbuXMj40pEeqCjydfuiL0T9u0m5pcRBxRzzicllZFpuLhpGWN0ebgx4DA7jUX1RUiA485J+l0B1D63CzxMK22BN9n3wlgk0aaRWuwMmXWTSF5FbABsvEmhv1yFjGWSY6bovGUgVIGlLIfDg6Yl8plSQTmjIQHpvfITgBohS2pacPnLauQCkybApy5HH/rFV+CN//Kj+LpH/hk7HY7tNGS1lTpw2WWVUDHmDwCGIueYw64rdis84xSCn7o1d+Mj37vbXjjH7wV09XXArtt1lf67nxzgHWP4aI1ULNAIIGukN4QP9KcP2fu1hiE5NsCgATvXq7L3zVEAuyTW/UbvY8BysD4NixzbTlDDt00sMKgM4bBtlZAe5DLvtKCBm9fta/IlbZIToG626Je2GK+cAzRGYeXXoIP+/APxsd+5Ifjw5/9wXj+8z4C1117ZdKAeZ6x225Ra8+E+9umHNSMPkodjSRVTYsQFcNQsbRHdFgPb33oAfzene/Ha295D9509na8/cH78IhusdsAcnQK5bLTOKingV3zj9X4XwxYIyhSIsj8jljMZb5GFLo9xgdceqXL02XvqMuwS/6AO+tnbA48Oj2OhraTEvXoUE1vcol/Q1Mgd6dpGJlKnHQkA40Or2eA4YwXVdC93jI58EelwYtwWDQ2n+drhf8qf8/0OeCYg1UWQq7fQWEEHNakRG/cC5EYciY6YuicutbraIpCi3hA/EQ+t8pFGpowx2FAZOdsDi26KkGL38/Awg4seCBiK11HYgY9GQKIdsqcmdG8Z5qiE+3D78u0NkWoo9N0Xg26uqTHlTYAAQAASURBVDoN4QaqJANqZVhEZmxjYYgqChTYXcDmaAM9p/iYT/98/M4v/g888Yk343i7bYtUVLGbd1mPlpzrfQ7HANLHXb/j/PExNpsD/OwPfQee84kvx9133ImD05dA9bgvahHfnm9hwsxD1gG2Bcmlk/qmzJDqSgC8R+4WLHb9EY0598Aw4YoRQ72jJWjYczbwXk37HgsvjWwNHQTdquG0+VlgC2KhBq/BG19IWAqkbKDzjPncBeDCOch2i0uuuxpPevwH4EUvfD4+8jnPwXOe/Uw84QnXp32K53kHoM+X9lXDBwcHbj9hQ2EztJmsf2B6aAEkGuhP9oYgBbZa8b6H78cf3nMnfveOW/CGe27D2+6/B+d2x23e9+gA5cwhSjmNTUVLPvre3xCFTkGLvxNcmOvOzPhuINUBWhUoVfGca29A6fXYCKC43IaqSOXIc+fD1Ff2zeCyr88U87EGulRDgqkNX5Q9FS4q0BVWqeYy/mMA2uHeRvDSyS3bZdDju/M9C2f7qOA9imONe4xOQY/tQetlKPI2WpaOaV8mmFfB8Rw0A1GbltBUFyqt1IQ5o+WQGHkDZw0sxlS06JNAjelXHeQUqAzPgDngErQnEsgxcXYT7E/ryXPmunJPGlZnQPRmFebmWoYRfV5dG8AZo+pQb9Yra4ZB5MRV39YzY5XW7iBaVqO7Y5TTF+G+e8/ikz/7i/GGX/lRnLn0Emy32/a2oL4iE9Kc62pAadwgtrsHUO2Pp804Pt7hzOVn8Os/+p/x/E95Bc5fOAZK21moagG0kAxq1k7qY+ivMWKQkUjrp2UfBnymhwOPWAyRLVNWDCX9Mj6CGyYZBUE8nSHKoGd8y/4kTZOQrHOmHteNL+q6RQyxFpSnUBojRArqufOoFx7B4aWX4slP/wC8+GM/Cs979rPxvL/+LFx3zZU4PDgAELsqXbhwobdX0rxr6XSWacp9Uw2+rPTffArEEs6mXzMEd5x7EG+550684bZb8cZ7bsMf3nM7HtALmEVRTp1COXUImS5x/zRrhe7mJOtayBmh+QrpYCu2Otc51e6zeNGuuh5X4FSZ8Jyrrm9gC8CWpUZglMMauzX79mw84UcGHLFgWaP+tS3K11xJatHUs/dLkHaQAu3/Of6lShf/nhA9rByLoeZFJzLoeqm10MQbJ4Yt4snWluqyCh3+Li5aBMVeNtFKRrrgPgcTdn8sSLI2AlRz8DHW5c4KSsMa3emVXJeVgQxKyF/VaGQnyUUDoExxs3MMhnp2MmbktLgmfFTPAId+8nBj1LmUP4Nh7kz2wa2dsIDIoDQcKoESwPqf6/V2qe08LI51oLamYEs51Ncjzb39uj3GdOkVePvb3o7P/Pwvw//4vn+Hi89chNJXjNbS0GVwT2Bp+8Ko5DjaP5vN1B7x2M6AAgcHR6gVfaFLaaucQaCGGtjtSkmW4jyJ/kU/pfPB+JIE7zxgXWJwY2a7I+WMkpQhyYMDXvvLNxAG+pRIAsaoy2S4GOGw0gncmeScqhjrpFYU6W8EmzaYH3wQl19zJb7hy/8ZPuHjX4AbrrsKp442ZE+KebdrdlcaCJaDAyKxL4QjjvmcK2zoOHhkgUtV7W/fEbTX67XNUM4eP4I/OXsXfvv9t+F377wVb7r7/Th7/AiqKMrpQ8jpA0zTJZj8XdMVmGdfTe1t0tuFBpcc5rp0awhHKVS4yU+KoO4qrr/sCjzpksta3YK+dlncr0AaoPMw/VpL6YysyH+8Y60qwIXLMc2+FrkK2tRibHudGL7ZlG/hiJAdV7pncEr9ZJS1KNIiSmsptL3XaV45GtDh2hjPrfF2TThsu2Pf2LnqSdxWeKboc12joxKrxxxLGE4OGsTpT/MLGq4jSpnTDF4lPKXv60Qjkl8JjvKNaS5tAB1+BCLaN6sId2v/NNAt7iACLEmjyTA4CLOzCvhbPJSvcfRqZPbzNh9r0WdgMC2KM7YLubauRrYKM7pKDQwg3CqqzSaqorIuiaDiGOWa6/Crr/lNPPMFL8Hll16Cw1NHKJsJU+nZgG+LQwOdrgNN5jJwQHsfJwHm4wopBX9x62148MGHUC66qD/nW0iWbcBxXL0e/Aya0/x2v8efczVSiZ/h+Dv1rDfm2Tx7ZH1KmkT60L67jzB1aQJLAa3rD6sUoh/BV5rD7YCf1phYsJHozk2Mh0BbBjoJ6sMP44qrL8Nrf/yH8MwPeiKAlr3anKvN305laovoutnw0LAQ783/GtBWba9xNNuPYWVBkfZIzdn5PG555AG8+c478Rt33oLXv/8WvH97HtvjC5gODzBtJkyn++M4AtQ6o+4E8W5BdV6KyYDA3Rji0w4NDMJYk1yCeY4XvV8qaMPI84zHX3Q5LimbBuh9x7S0BkZDXmsyYH6Y3riQuVyKnsjmB9k2f7NoPgHs+FEoNs1IzLET6BlNg1New5YF6UzocDh/T/D6y3nWoG8s3QyCqTCDG2j3MIhrFYxga8MrYUFA2hi/r+V2XwqHDyRX7wJicMmMCF4GyBkocQQeBs8S1rbzlJJfZwDk4hSFrh28SjC406+4BjGfSE/G8ROug/xogGj2l0EvyU9BDj8qjACE6Q0j5SOLf5gP9uyT5+MaI82BWKOxOGjZtyRmMADtMVqvizk9o1aB6g7TlVfg7nvP4u4774L2FxrY41ew1ynC5NXptjcAlQkibb5NitBfk25bLalTgZy+yJ/tjY41R+oOtP9NPhFD4EE6E3ZjYNccND+yn7K/JC8xUyH+mC6brGIo12whZScl6GbwbXbmBIAWJfi9EdwZHyJcTzrUbw/e023gNkzvBYoJKqWt7J3P4fv/3X/Cs571ZBxfuOD9LdOEaRO+yIDKtDzWsfQ1IgrYUH8RaXsdQ9pmFQZWAHaoeHB3Hu988H781m3vw2/e/j780Z23445zj+D8vAMOC8rREabDDQ5OH7bFSRWos0KlunzFEgvnj4st/NJoH84Sikjy1f6TdEiE6uyimgqeecXVbXshdzVdt7iuddeWfJ4vFvOEYAUn0r1B8Vh9Rsr+10bKxm5237UBlni3DygBpIUl+8ry6lEjbEGwOSWKZhmsU10IQPAio5J3YvKcMCnwylBVayoLTLzNlYBBTeFb2aranWBzVMnSVfpqRFppS7Q4UDCgsDvqIMAjAeMcan/q2xlsQUbMFZKbdJloAL0QzCqczvZX+jkrTHOyXC+ojNObgXL/KmHja/Xr4W957tPqJkERHZGlSgKJJDp3rMG/mE/fY6kIVYzxBhNOdsXwqrTTZCeNP0L1WBUxVwwAOu/6VnWHkP4mocAFD6WCS9LeRwopgATYusUIBanad8+tvNYgHCjz2+TuQazxlTNd05XeTSXHylml6z7phOmndPTi7JKnZWLONkQUmR2cdzH/y+VpTo9o4OuOAwqqg3wAtQ+6R0gbLMtK7oj6ryKomwPUu+/F3/q4j8UnfdILUWvFtNn4RiVTkXjetbfjc8SIkT4I+kr1GvsDT1Pyl4/MW/z5vXfhtbe+G7937234w7tvx63nHsYjF9qeyNNmg83RBqewabqiAHYzdK4eQCjxewRShiBfjwDyo4q+WUzzfSAdyf5OnPfW5gLCVCFzxcfc9HgA4tn/AmjXyAPyanB6KcWgCfQ0F5dfYtC+Y0GLBWJC6hAvIiA05s9qxUHI0qHxD8qUPGIbK9vHsMz0URABqssoYt8CqyWljrZDvSuUJmyRpqRSABSklyAHEWHsBoJcFUfa6W7mIIFL9zamgOkmzsS9Owa6S6BdlRkXoyZhdXWn2P6YUQk5q3BSqRXjWQJK60JuNC0Cgxk8SX5U+JwaL9iX9WZpODFqFeC7zLiJn1bX4ExXDzcyAplUnkcRuv70e2pvtwU7tlPO0C7rW0V3JLXzOvfX+sjzeuYoQ58I4AIhgz86nIuKqRVdDYCT03bl6v3RXDZ0OevEyOY8eiC9avJJqskOWH84GRYl4HZ7XShqAnXvq/MLpGxN+23fYruoRYD5GC/+m38DpRTUWtsiJ3vMhkC2Qh2EBdo223daBJs+imFUPLDb4l0P3offv/39eMv9d+F3br8F73zoXlzYXoAeTsBmg3L6EAenT/VN71qbCtAcLolSoh9xgkYMRl+X5Cu+eFOJ1zGtoMRWzfe636URhFpxWAQfdPnVjWbX74TXmY7R/a/ZDPtBITIscjAiT8ASS2IXiezwRej3xpsmJTzxWDO6x3iMK5F18GwecQyO1VxwvHc1z0kuVpTta3/4QQMYTsP+IyH6ADT2I/rC/RASYOgXOTPuC2mp6Z/HcTzs2RU2JKEsGsT8RZ5bS5nwcB2m0OYsYDoXK0s94/EoMCsoK3F0lR1jd/OLLJnqcEA3RxRtJ4kQiLhDIn7Fc7zU4Vx1svmcW2dnMWqclR98jfPEMiMfJfG2omB0J8C0egQ2UWTu7rHrAfNBwDtvZb1g2whdHxe3MW3NLkM3eW7WdMW4NGaD1q4o2apf1YW8OmdCi7tO+FxpB0HQeXaOYWPcf+Z7L2UbIZDO8uiLARvbhB+m641ZgQkEQLF+ROmaBtD0m2649iqutDtrSXVXrW2FrwKTtNGJ9uhP4/sj8xbvffgBvPHO9+M377gFb7jrVrxv+yDOz8fQTXukqFx6iEmPgLm2aYgZaNMSgE5w9PNhW5apB9Hsg8JnCAkvklS2G+qPRNlWhXrbID0jxw+f9FBAUXERCq7dnG6r8xWxRSTpUHLssqb7GVMSDpEtLRYherAlyeRi1IoAlc2s9yVH7vv2Rh47wH3Zf4nujYZ4In9RvSPD/jneREpoevo3aBOMQM0kcUm/wzrkEf54v5BE+31lQj13Dtuz96PsYvuyRHBypOSKDDQIoNKQRT8nsOHnTDKN1rjyh8O0YeKVG5GdEwNqKkb6zwBn+jVmaTwEPcojeOFMzqzyjJeclf1yp5mNhnnLkrJm3FlSG0jnwkAWquJ0ijv+0ZjTKnkyhgTcxjejnbzD2mwgCEQySeap4rvKwI9eLvVFhi/+LLemTivT5udWLKwDzhKISMfWgJlLx1ACcYAGZMVr6sVMTuTwYfqmznBz9h7zevvd91RGh9xTB/NOP5Nqj1wRonqffTTCHDObmpuXepO2AuP89jx8SBgxDxorjAGRCRMsc1XctzvGO+6/D2+68za88e7b8Pv33oZbzj2A47oDDgrK4SHk1BE2eqq/zrYBrFbbRlb9eVXrREpyhv7pGnBCM+v6OS636m2U7nXktXuR5dETFOnz/Nrn4J925VW4uEyYLUhXbXPU7u+YIlsoOJAJkK6tY8cCS2hExdcdrIJU2N4YA1vzxtJNnGcjor+LBga2D9nqeNsIfikS5gxmtR+0ICYN46w44NX7B7rXypkDSTS0NjniZeOSItALF3D2j98KmUoCzBgJC4cwekJd9AXhLCI0coecInygzT9zVmGgFIjo/FUEeep8XNan5KT8hiHrZvfJCf24KjV3V1L/IqMwR5jLmhNKym59pfnvDPJZoGmFKsgVEJ88ZtBm4CwLMH+U5uQk5BGSUqqHETwctdsXZ7p+dx4F2RMFQFJns6V5acpSo1R3QcRrzzJANDMyEm8g0hfIhB5Gxp+dsWdI3vX+r8uMZAnAGCukIOP8v/VDLVPSob5EeDh49HvIJOC6Yc8Be/1KYhN/jIVHpjL9Ic8oJ2G/lhFphapA5xmoM9781j/H59WKOrd9EK3JgpbFzlDcuz2HPz17F95y5+34/ftuxRvufD9u2z7cwPXwCOXgENMlp/rmEy0o0D4PrxVQ2Ds/FSNEZlvJYzUuxb5BTHRRkBeVkYqMdjN8Y7n4Wg4CPOEgiXWv61a9sMPTL7sWQDwql9YDmZ521o9rRTqR/Xv2wRH/B71pu1zuMtnL8iD+rfkjgy8oNmbweWf2Fb4t6z7x0l78W3rHFeKWoDqw6uQ64C4mt+vBVURJaShZFfzquEwT1SdAUUDnHbBVIL0WLTsuGoFKww3jwieAF+0g6jDHb5VY1e50rH9OaNA5tDk6Mb+5CNWt5DeG2WZSXns4PYsiBwBZCcL1G/pK6iOV9IyW6OY+Cnz/16iZD/WzMUCmq8YQGflaf3hOTggYsFIJOWYM8jUqnX/B6+ykNDOC+zPQtfg66hXYQSxj+hgOpCvCtEUD+aUNuT2o9lfLDaf7v6ZHY1cIE3NrOn6hegjQnF6l21cClrSgU2JhVn7MAwEs/Z5RV3wWU5mLnRarT4PTMVQ/o8wVeunF+IEf+2n8X694GZ7wtKfh+HiL2vsylQlHBwf4nt99Db7hrb+Jhy7eYKs7yOEGsjlCOX2EU3JxWwzX26z9DU4q7e04xLhOpA1lD4Lx75rAhK+xbLKOkqRk+A3zdSv6S3WxfrHOmU5KD26lAFIVH3rtjcF7smteM7KvvZUffi5WuWdksT/JLextZM/FlIlEcdsLe3m/rKC0FVL6WAY0fHxF3eA8fMjEhk2sT1beGI9BB4gYhgAWIN/EKxHTUKiGuF031hycXexACG3RY+t3fx6xSHuIEerDNjGnmYMEj56dJ9pBJpbYp+ZHB7LgZ8zjGY2qRiegdM4+kUHkurUSD8kB8gKldTmSHkAB1LjHsyVN38PBmxFr51vnr8Nj1GMA4pvVM0CoEotsxKB5SyGeMKuc/6RrANxpmvjEeNjpDJPv99L80DL6JfqDib0//RaiK7KhLlkvW4O9xkvri9Ei5qiiTrX/xoCS5ao03Oh0yUBP2BaXSQmEbeZsOo2QD8vP2zGZW59or0hrY5yuEOdX77jbl7p++qcSyHe9j99h/xa8pfLUpsuPbNFB1W2N7BlZZlZG5i3KQcHZu+/G53zRl+Ph+x+EimC33WG3m9trFlXxwqd9CHR7DjtVbC65CgebS1DKAbROqFX7vGXtC6i0TQ9UQGa1Zcq+1WoTRAu8fZDK3HMH2uSyYTpv+tz0WzpwG+8CFEOHZeBF4lliqCJfkFzCbbTxcKqKp11yBbuk8PaL4IEqSvVY9qyx1aNwQaqGeBFGOtr1/mNVhzRstIwN7g8Xch3j90XDBKgLB+8d4dAxehpsWIzAU9sxlNiYSG2kW4b7F9VlR5SsO5UxE4132Dr4SrwfcsgFc9O0d67xxUKOMejIxhv3BMssBI0QM+aCNbE2O1nqLwUh5vi4u56detGRroGTi9/k6C2oSLK3eRqJ9pJB9n47nbzgKHPXgwnn9WDIQAQHXa9YN2NBGcnNx4vVmW+A7kPVnWR78sv56bKAOyz2gyzMEaSl3yP0nS3CGnEHyfVaHUwTyTb0LLYaTcOp/lpF+6zbnwezQ9MNuHK/0kIrM1gYYUHj4PqYJSuuUYlX5m/ggAJVEIs7eES1HIDHwq3Wf+e5BQmst0THqhNWwF9XCaC/LA467zBdcRXe9OY341Ne+vk4Pn8Bh4cHONhssCkT6jzjiZddiV/6zH+CSx8+xnzuIdTNBvNubgBb5yYb/6h/F1VIVQ+0QvYkHZWYezRkYzMzVZfgq6lN8kesi+pVA5xAWZMjtg5yjdEAa7u3IgrVHS47OMQzLrvCdX1VFWX9dFwOTQ3xE9aoZt0ioteSxXysXZP0h4mjt/CuVLWqS5KJ42aGrLWf7M68dSJ1ql/PyBAOXskRjkbPmXDQtgK4e5nF9T0KQy2aRiVhmDNU0DbuSYFTrTIMtSlrOJVUWslYazceDYePVHTZI6U5LcookBRHu3GEI/co3CWM6CfVB6rPvvs1AuQMxjVlNH6fU81OV6lOu2yy7qSDvng/eg3JWIIvlvFEO8Q3UmimwQIQA2mFDZma3okPnQVr83w8ELzzgMWdTK/Td+UZRh94zFadOpZ29JlZYrcaoGRsIz2IAGNNpoke61fXBf8LCmyIV2YAQvR5q1acesG6amDHozPmD8aMN/PZLnX5eCCkuZ8gncW4cIaum1wXDrgSy/g8Qrmcx20lMaQB6sFVN+G3fu/38Ddf8vk4/9A5HB0c2n4cmOcZT7viWvzmy16Jqx85xu7++1DKBGx3gGevTiLU0SkY2UCJ+W06QF5UEMCoWT98PwLjmytN5gNLMIITOx82nW2DBE/6700IUAugk6DOimsPL8Gl0ybxPiqIr/sAcVzj4xwIcMrYM/hh/qy3sO+wqC+fLTkuBfmrPdWrJlBd6xiQbUFF2s4zYybLndpzJMNxEsLI99Fg7FnbRHoBsynkXekAAN9EHmjguttBjy9Aj4+h8+zdkSWPE32yVlByGXOCHrQYqHj7XVvF+klOCWuyi/4xYC6iun2HBz3ozlCSE+VupAUwIIeF9YZU4joPWWbnQXT0PvvQl3eAgKPTtqYfWTbEX+JEDJ+rB4M8SpOdkVUVABlcET+feYQAAu5g0ocMsElOFC1EuLnkHYOwl2ag7X/MEWPgj8JAkPIDNR1V76smwsS7vWqbIrksdVo1X/avJnMqzV2G0Snh+HnNgFJ51xlrk+sc9XB8P6oFHxLBQcqQ0Z26jXJJgcoGVQ6gsmm7fGGL09fdiD95yx/guZ/4+Xjg/kcwHWxaf0uBKPCEy6/E6//OP8bNVTDffw/KwdEq76ydJZCEcTC+QeDz76rIC4SbQrvMUxoz+Il03QIZ/9OTithqCzF3vO6XWnHpn4IqBVornnP9TThVNs5nfuxH6T/+LSEIbiLRvH+0lOzMR1qXC8lCT6KNHBcPfq8fBeOxiFxG/gzuyobU9oDmojbuAEW8NvYfk+xZOAwgq050pIucwz6ChH8HqlHZQUns+zxDNhMuferTcenTP7D1x1Z76lC3hEItANbBI/phtOcFRnnIM7JQkCFoAKgOfDMfyIbXr3nG6DQ59dnIyKiChijj5d3pxQKosV8L+pgeNIM1L5joY0Cke/k7O1if/wuJ+EUTRboX4bRTwMLAMWZ/xE8j2zO/7oF84Y2nPkLtEFCoAXh4RFNBga3l1H4pRgqMz2kHnNGOVnQDgNOQeM3BZwgXlLo5cAVLgmYLKDwzakMjHjYYaMnAexc6FGl/Y3QLGoKIxfwu0cJZceiC9msS9A/tu91qyIz1L+LB4KuBQdBrYFigKFCZoNJ2ehKZAN3h6Nrr8L4/exue/4mvwH13ncVms2n7YJfmS667+FK8/mWvxBOmS7B98Cx0016j15Jb6zcji2S5dTrYrcXbwrJ4s0aYBUb/PEIxIDHflYwNyV/uC+MzP4NWY7kWQCdAtzt8xFU3toWoNQd8YLmxX1Lrs5VNCkQtrWNGNg1J37ikDmWT2Mc+uz6uzdkulGa4PPxmA3ZHkxwVUxUKnF7TR06ds4nB2laPR13d7B5w/VLi1FgVXbchQJvXKhddgotvfjwuvuEGyMFBOCKm2/wG06lkFF1pQw/yoqE4wmlU29PW6SEyF7tzs0JmFVclPms48VReJFYHukcPMCFMjBhiyGBM/9J8cnGYS+aWslVqr9EyDOW4zjHgZAN0XoKGagHwsHBiCrp7IoCM5sxRhaO2x1Q8P2K1r7m88YbBYS3QSNllZ8Zy4MV4JU5vcp7dIVMl6ybl+tcBkOuLKhe6yHw2YOXO5yCHLpFceP2Adhqy36ERjxU+uswZQAhgk/TU5D60RX4r4ZTA9cXV1s1WE7+D6VYdBSwivk81yoRaNpjLAXblFHYKbK69Ae/6i3fiYz/j7+OR+x7AVArqPON4t8O5C8e4eDrCaz7jS3D9qctQLzwMTG2LRwdcMJ/ZyUn48S6grgUD4XyYvQ5AlVwwjS6Yb9PccggsfqT1C6Tfez23VkwCPPeaG9rL643+QX8NyPK9Y49Wql8JPFkf12/K9e6DnUUNxEaas9VE4D4Q2zcf5SA7fF8o/QjE5vT3HHkOeKksMTzQhxGG/8bmo14MJVrdDPrGkXDaAGhR1Ha7w+7CcWwWj9yAU21OFuiPFSzBDxp98agxLvTamXd+p3+3ZQ32/Fo4djPM7GRC1vD6ldpjJ+VyEgz1hdWlobvR27oy92El4ywbEBkV8ycexYhnHN041Prb+GU7Fwn1xWE70qm+O1MvEwUYYQg0dJCZ0U/OrYNlLDRTH+K2AFLpXrOTheGbzFYsmmM4X00i4Ro5uDAu+L2IgCcWbI36RDogUQvEdHPdUY0uxstKtiWel0Xnra16HSpI9uDgbDwZfIiQTI0PrO8GnB7SW39orjyajVXmwt6dRS/IXXafl0kzzseCugkzNthhgx0OsaszNldejXe+4134qL/9+Xjg7vsgUrCbZ+xUsZsrrjy8CL/zaX8PTzy8CruHHwQ2G6jObX2UKtrK51h8mHTMAN91yYKuHNCN3n+JYbGOJHdN/LoHhUvoNS4kOgDyZ0NbWisuKqfwxEsuA7TvAZ0CBusbuv8gHrPvG2hdz2ZDl4VlbUmGyXst8RvB3+5l9hhPBCihHEzIfvDTUdGp9Ni5MRTJTgH5+lroDTZua2EpyH2n07HEab9ZVoot5vfMiTrm9o31qi2SGbmgSYEHrYZ3R4j0Dla8zRlIYKIjTdSWBTdjZ6iH5rRcyVV92DIFJ6xXQjUQtrjzNhokhu7CTXdt5aW6oIyFnKrR48DmDk19OFKpf/w8coZA+PyP67RwWJUzZBmFbDIhfxVycNR34I95wvaXtzp0uYk91E98cCcRfsNpcFK5ZwobNqTwoZ0n1drjE6JqjROyKGS0wwExBhgkwN3NVBefCMBC7O5vxEOg3mdNtuOBCiubnTN+qIK5wvowDuxE8JcBM/kwMbOLc+xrYn2EBQfmRMmhkBCT3+BsiX2UAtC2Snm3u4ByxTX483e+Gx/6KS/HnbfejouPTuH0wQabqWA373BGDvDaF38WPvji6zE/cD9QjtpU1m6G1AqZ2+pkn4oDHxZimPCj30G+gSnxNjtzuNFbB1wu6rxQ4sVeBFG4Yhgbw992QN7NeNLl1+DKo6NwORI2lufJly2R6VG76r5vMeU4gjDbRDKSle5oVtG0bshl3s6VRtOKhz7pSFG+uPOx6H3EPca5dJ0AVrhcpGVr9uwOehFhp6+DYu2haSEs1jZvq1/w9hVaZ9R5B+0Plw+SDTTtziqCQIruqRl28EAsFjFnxIrJzqeRo15v20UGYRsdIMTp6gHSoIhJSOZhhfpsN1EUn3Sg09H9CMz8fONz5WdwsfrdnHUG5uQGk6jGwGKcjzRDMSfpQZtlyDbiQODumR0QICkC27TeVUEDRD2r7nzhDNyCkMR/MZmyLrhLhANb4pGJyoIVicDEWKOKeL2duT8GJ4WtNzclsT454Pi8r61CB60T4rAt83+IwUOW9NuV3QCcnMISvIE09E82b30JwYbDNh4FxTrQRhJe1JX1LbWnmuzPgoVQSQJmqO+6lXwZ+qM6/SmDtvNTwbzdQi67Gre++3Z85Etegdv+8r246OgUNn1P5N1uh0unI/zKiz8Lz7j0Zsz3nkWRgmnetpXKWqGz9rdYhDo1dkvQaKpCwVbWvywCUckBPhUJoCbfTdkjD0aHejNgIwIWv6/r4XbG0y69AhPiUT+TcWBFOCyl/3K+SP6LiE+xVkoG4794wcwJeDjwNdcpi2tlCTfDnWsHZ6FDQLCaqtsnGUFuKcqsUzJ2Ow0Vp3vCWWrSjrV+AFLYHWGFt2yE8Z+NEUa2tSS84VOUFcA3m4qMi5tUWnwgXlFkRJ1Si9i9LLKSkYHIkJ20aH+Qmyume/ReFVml94uAA1Seggg2zhYwUA89Go46LANxI+Ygih3DAKjuzKxdA9QkzxhmdhvQwcgoS/aFSpTFGucto0nOpjuLcejXANWDIHf65jgGS3VySJ9NP9imJGTtYiFnae0ILzV1gCa20KiED+t7hqKpjTbHqcR/AyADt1DJVo96Vmvlk08w5+c3dKtKxqAwK7cy7owtYKT698/DZdvwTMr7wIBJNjsco1uIOfaow326i9QQrw/11or2mGCFR8V1BnQHPT6Hw8suw9l778fz/vYr8J73vA+HBwc4mDY4dXCIAym4bHOE13/S5+ATrr4J5a47sJEJU62ouxk+nKyEuBylGa3E+hSsdZ6LDevbNEO4oSUvTsChwVkPss1ez3nu/mXGC66/GaXro5hdcsbs/nCUFfk2xqdUTP3f5XTIiExLhExNSW7Svglds6PEkBA3vB9wT1qQxJENH24IS1pXO7DsrjliSW0sI6m1GgNwOZuLNgSLFpkPOa2Iv6qh3MLXooXImNTBoOlvl4Jq/94MUqysKRJhrmU0I663HoiT6Y6EsqVYQ+KDnT7c5MDJjpei+aAlN8pzeAaOYwbn2sYOzUGZ2dyNxsdD3RU0mtyRB7C5kxQZnOMQDKi1GVmpO2erc5SxgbYFAZ4BSciR+cPByZANRZrhJdL1xibrtz02od7X8Qg8D+21LKp1zWgeHIkrv0aWaP0leRq/G8kmA+LP4lEtcf2DiZwCUw82uj6Iy5tNRTM9QwC1ZMPI30z/AmRAthfCS/2P/kn+vVaG2uNMuWWq4RvUni+vFVpnOOgmwK1tSLhW1OPzODxzBmfvfxAv+JSX4x1v/0scHWxwtNngYNMegTklE37ixZ+Nlz3hmcA9twOlQKT4UpKK0AW3Ig0e+1kdnn03X9O9QoeMCFhc0nzdL6Svy2saZcYhXCCtc0CdsakVz7vuZio0QlmW9xJZ0AGQF/DB9SJswwL9UV+4Ewj+jIdSURlOrhQsVJwYsR9Qxzlbp21k4pA5nHR9PLy8ZNI5a320IxykVYqhW8QppVOavnCF6a85vFDFcIR5eG1JL7uaGMLCUuAwOfMKZKThtdBW8hPcjYCZ7tzrUjGUKvcwzYySsyKmT+K+tSCLggwD3caf4NVidEQie3SjFt6VK1aSJlFSnQtT7vWZY83RJi3O8UAIqa4YxGGgNecUw9E2wmL3jIsuUjcpeIjrEvhqnw7mi5ETJhTWvkO5eS8vGjpOiq7hiGIEiMCLirvz7sEhJcXeHmed5BVWbS50IOgMsWQJpqDB8ZAezeq88UCVK6PmOQN2nfTgEKFDIfDU5kBQIjM96tZacXD3sV1YcD434K0zoDMMJe0dttvtMQ4uvhT33vcAXvTSf4C3/MGfQURQdcauVhxvt1AFXv2iv4MveuZHAPfeBZkK4onhvkgoJJDZv4IrbsapvKwU4ivL5MYDD9MtDRt2QNLBfrui2eZAWmdcfuoSPOnMFZhr9ff7rlDkbTJtaYRjkBFI7yxB6xfD3taO0bHonu8rBPpUEXxvZBrmOQEEvW4yymBaGGlyNAPoRvHcsbWs2JzHCLI+vLH2GdoaU/m9cUQXuvaFC7piVCMoDvH5UNdwDzngiOS7AXYLSBlRB1Gjh43cOc2OsffXs0uuC5YNUlvI1+2eLE9rPw/R5SSAXCsjlSolqrxwKwBPmH6o6ztH05HBDvy09rpz9+FFIdAzuhN9mnjE87X8thPQ1poKGe4xeoiPwr+in01XhWTQb1YDDUBpRVwDQAJ2xwZJLJABqFtZHh1Rp9F46fQbM8xPaear0rB/lnA+a8Pzpp8xvEuw6Tzgtq2GYcSE9cQyELMy6xP5VgZY7fLzq84H9jUm75iLDwdsi97I5tUvZ92XNpcJqssDrwS00a5lsW1XuArVGag7oDbw1VoxzxVaBfMMVD3Ane/5S/zeH/wxgLbyeK5tX+RZ26jLN77g0/F3nvah0AfuRZkO+oiF/P9Y++9425LjPAz9aq29T7j33Jzmzp0EDAYY5EhkgERgJkgJpGhLsij/RNl6EiVRJh8l65m0pWcFK1mmZJn2k34SFU1KtkRRImmCBBiQCIIYAoMBZoDJ+eZ44t57rXp/dFfq1eucM7QXMPfsvXaH6uqq+qo6ItxkI0SL3GZ9srONzUCOWDM9U5h3SZPSOd7nv7ZfN+u7yHQJXplffdfj9pWj6Vq9vkeXHZFQcbYR4tSEtRPlE/rY4Yz/jtT/TMWaoxI7QmN3YYT7PZtREOf7bMPNGDWCRxCfir/1+RIKNKmQF+kjyDqFcrS7xOHl7tFuxUMj9579DxVfgx1XifKeYKdc/q7Qsk0VWrWcXLaYQhEcZ8dTOqFVNpUHjx5qtKVuD4DsUIp8m6VOB8QiWCzWrCJkUrZEn2KMGCni4SIfWQIIkAx4ocBqRiu2BUJYrgelMGgxRh/5onUftxnqMQ3ykgf4IVM1EtKkIKBswMJexlnfGftdf6iOhJYMfDwqGEdeUEhzBfnw/1LWcQXysrmGKEKYE6881UEGouZ4QPMVUq95pGLVBemDspFaFLvfxFqRS8tarGVCpEc+u34igs74pPRF5eWBIMwuPzm9IivTdW66/9YtICPRicI2qVMivO4hMU9DDbDoML96Ce981zvwd//6P8Ob3nQfur5DQ4Rp24KbxrWd8Pff/1E8tzPDJy89h/bQUfBiC0DjWpeQLZgfIdE7RQMTGufZwyJaL9BeXRwiqB1xJagOenlW/GUdTn7jyTNoieRUaZViDb5o2H/ioHp8icbIK6175796++UFp5rX/eeao04lGUckp0a2PqLYDbLV0JJb1eiUTv/TV8OyRr0QV1TZjsAWLjqSEelQWiMzi753bS4LqBgCMvmSFcKeZ2EeUYsiBx6edjMoUSGtU3XulNJnv7VBFxQxQt26CtYbQ3f4fmgMJzMqRjnMwepeNVIhHvRF0X/seZaNthgjH4EKvfqXZeWms45sUW4wpHGVhWKDAYOf88yZPCCwRF6uPi1I2o4Ccz39cZGQRZ4+gvarlHVtI2QIFmyyr0fp+XfSdm2fyQ97UPSulModWz8UfeanA+SzOsQqj6T9oWUBoZ0CVOmj03+tzxwPuO9Wvxut8fzXYlxfhPqdvCl9Vgd8EmEe+/6AGU4UdWiEnsvte+NVwT8iBP4wQ2/NUocTJothsFXlvQdxB+I8lNx3IGZ0G7eA9cv483/2h/Cx//DTeMubX5lu+ul6EBLYLuWLC4ga9MxYogY//aHfj/eeuBvdlRvApM3RMqeLCqSNhUmTVcZlcOG1etT+SgRY2ICkOhJIeD11uq9/nb6ANYih+RzvO3sXABs+joY765QbCTXfg4r2DADBsKt05kAmNgylzutrnRnlw1FUM3Awwj7bCsBUSmdPUfYy7BhMcgI9pMtHu4NIVsHKD87KAqISeqWznHEpaK8tlhq+MYVRodSUFWZ4h4kaR6dbVezJVaDzBh5RwjNYhLk7R4lY1KTQNjdYbaN3crygifFVwQxWyVqtBtMrol8QhJDbVWyAqHyS4VaBjugg6AfHalXWjKCBBkeHyGpgY+F9+vlFlHxXRc0tJRo2ipJgh6FaIdbQXWlO/HN0OMVnR6x3lMMh8Fl44h5Co12dCs+vCs2W3+qrjTj5Blu3caTH7I2WKdoZ+YoMXlKeWKwsX2zzlgLKKi9i/AoHJrWPAg+CEUTohvCe3ZnAoQGS2vWFKwDqUOhvuc+pWE1NIg+AP5DDO4x+ikT5Sz0a6tBgAbucA+CO0V29gPvuOod//y9/Gv/dX/ozaFvCfLEAiNA0LZp8s1jcYkno+g4nJyv4N9/6vfjIffejv7GNBu3g0oIaqJoz64RKm0PuX6Hf5NBPY3g2R/5VnmAoPN/S+6br8MbjpxVU/DSNt78Rf0t8KhpZgCXnfwL2CZOcTPii9noUpBlBMf2akIlWnrWrWrhquQFj+EkLtmn6gSeqxVBIX6bxn1UXK0l8xTbRXSN++DCAsIfUGQLv4ccCOXQieU11xjrob88huw5LslsFBzPQia4sZDycs4N6/WL0WZlEmscNc1E29JLPHyHo20R5Ra9D1SFN7IwigjH2C160p3OdqTg3+84iJ6xsZgVFBBrESdDfHb3Gi1SfDpQxawSo/AAifSyLfCwKlXaw63/7Lddf5PH89qZBHCKzW8ZLK9P4SdRoRGeyl8tzPBbnxea0Od8FK6a36HsFLZH5os3a79Kf0i9xHpJcXut7i8ClXg/sJmIc+ksK0O1sDDsIhM0C6ZAea4XWf5Tz+7aw56c0XuyIGRHfV0pvHur2chBlzfoAzGkFsPCUC147vTAa8gIqZjTcZVlo0aMBbm6iWSH86A//afz4X/zTWD24gsViDgbQti1adQxNplV+xDlmArgPzonqc2kz/c0EFNhbeTwy+O6QeiJilPpUe4iR9dO0Ugpj7nGgWcKZ5YPB2Gv4NYLgEY+KvgstERq8XXbluqM4xU4n3dfJlErdsQhtk1ZvuDmRD5xtdxXYiifMuYqQ50YU8FRI4bCMKvWB5JAJpVTYUv5xegM9cM0X5RyloZBUsQBNA7QN0DTpNqMmb4L2IK03YqdiPBylZH3hLRtg+gjFxBxmEAo+kIJYFkyy9NF5iEVG+VCLawDleRv6S8BIwNIpov0z7Hv2wBxpSkbQDbdqflPswaO/5yEo7dOUQa7D02F3bzzEoeNe8w3o9qCWaR84M+IUKSDA/hZglX7JZTYU+UEiX8NHDKjwUJvv65I+sRxOHN1sWojqvMIbbZzTqeRl1ojtLo2LOoOIQ+COeqvHCLHGcFmPEaVzzfIhlOumbpyR9w6KgaH0peOQII30ozHGCNWGeCYYp7QPFNiMh2IyGuqQZiAZPbUAA/3WDNi6gje/6934yb/2E3jHN7wRAKNbLNA0TTgTGEA+E9mgrQEhnXnR4t+9+Bj+4q/8Ap5fbKI5dCABr+s/lUn27PP9YilFLqhsvodV9hDrnlCW8cI+OyDM6ZMjnRjFXYf7T5zBqZUDTq8sOztZj6azXJ0uLfb59wEQTsAiPg2B1uu05tH/WZUpsk2ztRORkbA+gH3ishYzkurpVQw6l3n0owNqio1QYWc/lFwWEyffgxdFCAcojD08+kVNBeoCIwKaRVgBqnGfHX8gxpicUXCKrTQkXtg8gfzJq+3g+oKgQK5G0RsERj44wwAirX404+M9OF+/GYqhAROaxKhGtjs1cIpITmPNgPu+EzHO/a1lG5r58tJ3I4bJPHl965A5jCx4Q859eKd94gFDaPbdhPh45Q+GuPTwff+y6zONoFxNDMcRWP7c/kGkmEIFy+FVUQwnqNA31kUm4ph4wHSeWyaxGLGA6C/gRwmM/ZneptHDChieLnuX8mReuwjTOzUWtbq+AvL51jlJD7Mz6mClDKZv4nwVdkOenMdGESJffJ8ORveKSFK2fBClGBZE6GmCftGDr1/B8TvvwE/8yF/GD/7R78XSdIL5fA5qCG3bJpAlQtM0IhJ5FXKvMjlpGiwY+Otf/Cz+5hd/Hd0qoVlbQ98BoD43hyyKy2LirZp2dwkmykZnz7Nyeb6LvQ7pnB3xbovIGWBEqEwQ0h22sw73rR3HhAiL3obuhzrIRkt2InRsi6w1oY+rYAZbBwFrzyCNszmBjkKE1OFXmQFYbq9issi2R/lEIxsc1OBJOHPj3aEK0YMhBm+Yfc0hqrPfa40O5e8BtCWwy6IIAwBnFYxoM6gi6U2biXEgIczNeaKB8pU6EEL8bM4fh3fe5hhCyDs3rIkMtI6vAmi6LYJKTqRKuGdQ4+6lyJlVAH2fKmgZN8szd31XCMV+0YsonRi/oO5FR9mQ3VCuRO1kWDIMv4sHLHw3JqaiueC9A1o1nA68HTabspUhHryT4e1/NEDaYgVKb8CMNr24IvCVHTGkoBArEBAWKY2fVNS1mMLoSN+z029DP8D9FoFW2jzcRmNlev45cdP8lFf3WsdJWUF8xXYHk8AIlciqYJjsDaJuuDlZ7e/c7iBuBcACsfJccIMejaEu0EzA3IBvbWDaMv7wD/4x/Pc/8cM4eeIYuq7DoptjstQ6HEpC27O13Xdv0zR4fmsD/9UnP4b/+PyXQWtreZ6W0DROEaUBajesEI17Q4cMmjkox5tgAT7TCwq8lYshQnFkxSnoKkAz7j9+CvKT9FvcbWEYE6XRiJLRvfEhbQrpB+ZQyt1XNCzlWYO8U0OuvZNMdyKSo50nT4koRm4wlQZYC4JFHFrhsDVJD3xlSh5C9xQdK0l8hOT89Wpd4RkYP0qLCeAbL6Lj6yYnKA36nR3wfJGZln53EOgMmYcDRtm7PsApPWfz7g1QU3SYeG8g64yxeIQ+ugqIY9YtRH6ZGKWuKKM+tykKFhe2mLMRowSTocxVs1hQDlLKX/KhNADaNy7qkaMpzQ+0vlEeqhF3vcRDhTZeswM/FyV6PohsON0IEVTZHy6veuTsQCHLQoxoYXwu5MMAlAPvfITrR038kCdnWlS3pRsLPqR8EdR1CB6FDqqRjPakNJYmC7aQTUCdwaDcVybfjt/w8i9t7V2Zrp0mLNm3EVOe6WhI65b8KpGe530RcZdIwmlemZCOZWwI6DFFvzkHzzbwrve9D3/jx38U73rXm9AteuzMZjmabdItfE0DuWtXLIUfWUpXUwK//PxT+DOf/AW8ML8KOnII6Ccqp6HdrukqASxTG+zod5bL94f85NvpHChyWQsfRR2uzEWw/uuLo5QwV9YsFnjbyXPwwBWdwGjbgxMqaXwn+vaT54SVNgYXZVRPLprwvniJx17+Gx+IgjHZHbzJWhIw1TWyKEAU1QNuXHiwx+M452U6fsisIqeYTtlDmkrx0v0AcOzYUYvofCO8fVevLuduWvBshsXGRjoEZjFXaUvDGqyUkBaIHP0VBgBsAh7o9JbKwC2Aof6J4Gf5fYMUD0zBFH/tIDFZWOH7TgZspGu8ASiNeIbIIPQ6Z+oAyRpqWs32EUqcq0+HOV3fD4uJUpNSu3LUUERgGiqXWFjfM4Wyq6URgMxvnUoEb98ZbgMWG/JTg+/e+74QegcjAZnPonvqU2k/FWsAvMqGURaRD8+bKFupK9naEnhlDkZwvoRzuf8V4I3BUeczaClBWjzDpSr45fuWtC5rxxBcvKMLck5PJcpP/HEGnCIbG3RoMtAmZrVYLDr061dx17334q/81z+K7/9PvhMExmxnBhBhaWmaymtsqBFg9CqxCDRtLBb4Gw98Gn//od9AtzLFZPlgsj/UOxvIQV6cwYA6G5C6gDB/aK0zGTIiLImzj0Fl3eOnypiMWdouRWfpix4Hl5bx+pNnQADaRvbZitxVbHnQUWebKIiU44mzmbviXlmP5bXvcGA9QCr3GJcmlsgEiXIDzZgUWcVAFRSZd+E8Tk/d7sg+SGNLX+x7+Qyju90APbdOjAoBt99+xnmCaj0suciiCm5uZ99h+8JFcDsBNw3SakCOAAREYXa9zLIiTY0VK00qzGxl2HpbLvjpyuyRF954wyN8lTYIWFkCHRHIaXSeVN8JbWbUY5QWajIrVkRaxpLsjBUGq1RskjQDuXG8AoF1QQir7FqaIlr0PFTAg9YnXqwPWFOTCuPP3libhIb8oPC7zZPm/nTX8Q3mPMnYH0YWyLPXRdps5VhEbbwQ+Q7zt1mWZd5Lh/NcXRBni6OciPESMPDXQvoIOK7RQGwvOXqcrASZFXfJCgz2JzopnkfDRUuZmSpF3jmMTpXLXxRh/DAaGjAa7jGhdO3mYsGYb6xjcuggfuS/+nP4if/6T+HQ2goWiw6z+SJFs9SkhVAyL8tsMpZLFnlmIjxw6Tx+9LMfw+cvfx2Tg4fRYIJ0TZ8BiMqO6KpaUI8uEYJIpzFg8ufkW/P4fbNyeIe3a04mfb8Lz6pApLLM4K7H6ckajk1XVQaoaNtgys1xSskmeyNt00J8VlPsapnepjEXP4Y0pQUr2yk9QJggdETgaZ2gQZFmkUJWDwiiSGXRIcyuP0FZR95VI+baK48xWdFPHD0CmrQ676oKrG31UueMATN4exM4ehzN4cPg+TbQyQrjIXCqxnrmeWGWl4ERKeOAP1x2sPCzUn6Q+fQiBAxkxkxkx6ujGhsnWGqTA51FHukbH2mKzXNATKW3PeCNk5XMw7TK2BlHZ7x9fgOkzEVvUYI8WX0ydSJJ2LWhaKXpr8pjkUgX2ECNlw0z5Vr8XLozXoEOOPnPPPCGUI2MdlQlOkM2317UpM8VO7jIU/RHlgE1REKLd+IcbaongTliQK1gARTN4yMyR5e2yOmVOhVynmBpCwgG6Fo2uzLJlScAKnLPxalCpH8IaY0poQMBaNsG6IH5jXU0S1N870e+Cz/+X/8wXv26V6ABYzabg5oGk+kEBAI1xQIo11QipGv4mhbzvsf/8OVP4Se/9Cls0QzTtSNoODtqBOhqG39KlHZbXgjH7HrWpMpfUOLlUvolPsaIwGEnt96h8mxL/VsqtP/IADq8+vhJTMXhld/I6bnXX2djfJnDtR8VIEjE1t9XiFSR8XmJ9i4CgjmprEksyFlhsQMF05MeUFBU+y1Yds2gnuuAkBFGVIl2AMhu3rh82P0dKz4beSLg2NEjzhA2qnCaFFn55D8Bo74HdR1oZSUZ/5vXwbN1UNtq/T7aktKi2QhWI4CGn3+0FW0uTeZJGK7JRRHbXKPQMWABWA0059WSpuzOaDqnSVWNc0u0bw3YNGIUz58ZRImvqisSfej8smeH45CKkI/YvF03GowHbqgWYjytPTrnJuXB8aeMXqW/9XcDNc9zi0zZ3jnJUQBE6ks1PNL1yt9K35IAv9GmpXonIzieAmissi3yoxCukav0qZsz1nJqQ+Jx7lkbDIDddreYxltg6wfkaM6vmlWT442p8Nv1ueijtEePnM3t8XPeQaNLusn1FNfkAZArK2M5AFGPNk/BdDduAQ3w4Q9/ED/+Y38W3/CON6JtKC+A6rVfUjTr14MweoY7LalPe2vbCb5y/QL+1Cc/ht+68gSalRVM+BCo68GNyKQtslNOF0Y5Aa2TP2eDzJfhwK8AntqDzilxrJE+FdsQ6Yj6I6TZARVkZS96vP22uwFm9D0nR8Sbrax7VuwQaAftHwPDgeh6ma8krwWbjg9jj9nT9H3i0aleFaH8IbUnvhzQ6TvPC68vA0N+hEUUo89waDK9HebzC6kSKSlNO0knstx7z504fPQIbnY9qElDM04KfUGqzCQvujnQd+ibKbB2CNi4Fdpcnc92X5zNUKEvE3qzYgt2hALPX196Fp5QrkkqQzwux28BsMJ5suE0RWarQdvqQKWIIGRRh+c9XF4/dKZRsApHmv8KbAxK7NoGM/ZykH4YRlLyYh0DiSlklH0av8hL2+odT2/gs6xUIi1ICg+S+Z3SCccfmGOpYOkcE5R8gzc6nO5szp1ebuU1Y5u/OXkwqBL+cvhb8s34RJFxInBF+vHy2Iy5lun/Sr78Qq1aUQacg2itdWWK8+J0wSfL8t8QA+gdZKV99kQEvrWJKW/hbe98O37iL/wIvukD7wYR0Pcdui7JY9OmGLhpSBfN9Lndzv1JOtm0mHOPn/rq5/FXH/gN3GwXWDp0DNyl+3DRNnBSkGl3zBY7leUjjlTmkaSgw8JSk0Ptdw+uJQxY5ShfV5QKNRxBbkXT95igwTeduxsNNWDZuhQEGqbzMNtUK3FAY25e4JMmMSkvF/CN4WhFlOvtlqAi24E8Z+sMhKtiSFrpOXhRkf5yxnZgRJ0xRlQy6+roEVPgHbm8GDw6p1QpP5Ti2nDbmdO44/Zz+Mqjz6JZW0YvJ/KQi0kVaI1PDRg8nwHzBYAGdOAgeDIFz+egpoWhqWNJ/keocjpti6eywZNIk8CQ22i0P8o5QQVQmysXYykgYHNkUiowtGjGSccuF81AjXEASTGORVpb0CS964y2i0rhaC/n2ZIBlLSSrtckafEEw8+Bw6U3O8s6J6lRFfk51fRbjFQdR0pR6nvrLxj4BsOloOPnwM3SpdW8xvHBHDVZFwkwqwwNLKaVNJhm0eLI9qZq2WYQQmNFrop+DeUWbVK+Wous/5wJCDoeos+y/d5a5hr974gRotl0scoRtJk40MvMqnfce972wQGV1cWgBkwtgAb9xgb6+SZe9/rX4S/92A/jI9/9IbTtBD2ns4zZ0Sv7ZrVPwfmQitT+hqAnRX3lygX8yG99HJ+8/BiatYOY0irQJRuAJk4usAMwG2ot+tOMgO/gnEzsjcmfyYHoCiAni7GP8CvgEG0vBo+aOPdGRl8O0gR3LB/K5TRw7HJ5Y6Em8pG3+rvzNNSsDDhB+q/XIQ9lic9sPFbnyPCphpUAnP7oAqkiQe2lyxyh0VfFZUID3V2i3FBzKMYNOSEycsxLGvdHzPgTpeX2YMZ0OsVb3/YmfOUrX0PTHI5CGlokL+RACQa6BWh7C5i04K4DHT4MvnwJQFu2KpBMRWdquyseIDuAFGiLmeW3AtAUVM2IaP6Ca9FYu7qz4noDqBEQuezyhwtnx9wVK0+rNcUmIA8pB6ak1og3qgDRWx7X/qQSFA8YL71Ujb44spksTWBDABKrlUNCVz8hdKHCsHYVB6pLDR04h8JmMtrLkRoB8VE+w5KXCx6D46zNYRsxIIQ+CZ6/Vugcg2Hh5nApwBUNdw6b8tYaUogrRxOhDpQyKTitIg+SNuV1FqJwWNjR3IBBecFTsmHTROXGFrCzjrd8w9vwo3/qT+C7P/IBLC9NATAW+fQnksM8IAY5ldsD6Xq8LAdy4l7TtFjv5vj7v/vb+LuPfA7r0zkmR46nW/moA7VQQDFZclzxDoYHWpeUAuMKeSlNspiE0qa7PvDpTc3MBhmE1WRaaLElsLetHcbJ5QP54A7K8+EOLLUdBa3SNik7Rmeheu+axSTR9qkN9ZWNoekej1cXBVt2/3lCqo96oxRtjiWw3GL0SpClilSA4hm9SB1YWwg1OtRcwdpweAFZ3q7v0bYtXv3KVwDdDoh7NLD7W7U8FSJR1HybBjP6m9dAqyvg7W3QygqwtATMF6B2kqMty2dc8VJQvPUd7CIwib4GCz08H0IoRyiX9WvUmdOOzflp7xaRsv0GF/2RtiesMs0AbRFZosdHjuknMg4wh/J9xGnixC4/OVYREJvibYu2VzpC59PdHKp48bpKXLvfRcPww6xClzE5UexlPfMs3yyjyu35L+31dWkvSl2uAgEGx0vDGDdH5/tD6FWd5aIPvbFMacPK5fyDzoln257a0bi2WV8OH3NUiGVkYJimlDvfN8b/KAdhrp5t/plcu4y/0Hb5URbx64gA6tPBFA0RuCfM19fB8y3c//rX4r/9kR/G9/6Bb0NDhEXXYTabo20bNHm9RuJVis68eUwRbT7NDT0mTYsehH/79NfwV774aXxt43m0hw6h5QN2ZR+JXbApgEJlXWdo7cY4N3KQRqBIZT9wnVVSIbYj7IDwHqQ6M2IGnf6otXPpHZnqY4njSS140eMVaycxpQaLzuSrpQIeqZAJKTc4+EV9msbZWTe9FLlQjJS491Vg2ePx6ydAkNXIpNWIcu9a9hjQCaHqvVQAthLlqvGvuA82hu7eedAZpWHohZNruI9OvvkD78N/s7wK7haJRO7A3Kf9br0WCI1MxOg2DXhrE7S5DlpaSnUeOQq+fBmOzc7YZQcFI92nVix/rUVkgBoLH3VI7/nhtMgz44vywHt4JCaWFbSsXvIjNQowZhRJ8wueGbh5xTMroaYhWGj7zEWbo9H1gAYtW+oNMqTgb7Qo2OQWR7uUDFcp4mL8THhyU5yC+n7yfpAUq+KYZc8Ph0YnCmr0FaA8fRWw8UpLjlEW+Fl7rRukfv/O8d47nCU/XIfICEgc2raUg0/MbrFLgRwa6UYeqcRI/4fI2dkJjMhNQUvprFOekyVOAEttA/SM2a1N0HwL73rXu/CnfvA/x+/76LdiOp2A+x7zntE0hOl0ohGsLGhDBrSeczSb624YeV/tBF9av4S//Nu/iY9f+Dq6pRaTQ0eALjewsb5Radd/SgX3bRnaRbU9ilTOkcr5g/rl/nTMstLJkMJ+cnbeyVv1URuakzYAdx3efvbODO4yckhFe2PTPA3B1xjDBa87Y9jJxRx3qGuXYssvqq8c+JOOaxwprQycpOYwCFF6LpDfGaUCjUW5sYpgvoKSVftPQGMX7FUPN9POSKv/uE/njb7q/lfhjnvuwbNPPYv20EGgnydjxg3QUyxHjbpAZo/++nXQqVPAogMmU9CRI+Cb63lhhJ8Jz+auBBf/UTusXEUIFRRbWOKNUsictSabGBd1pORmIJMjwKEMm68i16c2L2z7cKW8TK8CqZUX5vlKo1qAh5Qp5Ru98oOTjEp0G7baSH9pW6R8U9wyApT2pT4qBS4CbeQ5xZ8g/ePnhL2Bc2jKbNbQ0QrpeRUWGd6FDj+W856+P2xOneFiPNfXFYXRU7Jg9CBGgmEPLaSPbQ2Bp0db4SJsky8DoLxQwh0uk9pczud7R0QeMyXRlgTeKBvjgGESK866zmgJaJpkFxa3NtF3Hd789rfjv/vRH8Z3fPv70bSEbtFhNpuBiNBOWjRti7Y4FMcvtOq4R8dphe0knxZ1fbGD//HBz+IfPfo7uElbaNaOoOkI3AFwR1qoM+L0hKU/fCvy78Iagu9bW6URWOLsT+hfx18LABnmHTmmw/2upLBmLudYNS8boDMz2q7Hm4/f5k1fFfQG5XgS/LcqTkTZLBoAaEDheZ8+CXbs9RSiqdVJ1dU5W6mtVv6gsECwvItDYZaZKo0dlj9gXv7DZUL9GEGovgKUVHiZOV3K3PfgvsdkuoTv+vYP4x/83Z/E9NAqwAtwz+i5ATjOv0r5rGU24K4D1jdAa2spOj5wAFh04O1tyFLQYBzJaBmEP4h/KbRTCQhe6UC4iGI/FRhnZbkv+ei9eDB37t3Qbc5Z4KKf2dKT0k7GM9T7RvrcyXoE6dxGcnnshRfxrOChClNqGe5k95sf/RjYBvZlOF4FJyTzRA4OKvvLjQ74iD6ufJTuj/1tTHc8381mkLCKAzNt1TYcACMcGq+pHcim5E5SFCCtb0KfKa+8rEPr89+17MKjl5+ll8i/h/Ep+CaV35VvgUmpk9PZxbJyHeCmVT2eXb+ByfISPvzBb8QP/fE/hg9++L1YWU6R7GLeAQ1hMk1ms20aXV2sPOQUm/V9l+rue7QETNsGczB+9umH8De++Fk8vv4CpsfWsNwdwoLhtoMNT6kX+yX+jI1wGO/l89Dgm/0M6iLfC/0NU4MlCb7Mqhn3BLn5dwfUnB0bHf7vOqwtreAVh487h02cLWt70FVkjFHN8sPiVlfYX+zkLLgiZNIZbKL7yFxlbK7DlzhMQO4/OxsZ7P4bzateUiHe+dMIkI54IeHAg0EPC4x7QLDctW0+g6EhD2SqtUlauWf0XY+eGdT1+IH/9Pfjf/n7P4V+NkdDHcSjTBGOU2eyv5zpIAZ4YwM0aUHLK+DFAnTwYGrB9rYaFdsPmIkKLiqrEbE2ZiOeV/uzo194oFtDPCDodWTssDjObYX5Or/qQqyYsi69kxOG5Gxh6lnPlFVpYjPAAqxlBOXnO72tT+TmdjWiaJlytt/LeU6L7j1PfcTr6udhO5V/lPgQeKJta1Sp2Nfviwz9YX3KigoSYRofdF+qUwNJb55/LjnYRN//GUzdKmPdZw3TEwVGJ8vk6PP8N56yI8pYZ46Wx/DUntDnJgixPk+XT8huwVNwRpzsSh422vzJXE5YnGpRNjGMdNJbhwY9qGnQYYJuaw7evIbp4WP43j/wUfzYn/2TeMMb7sckX9G4yDfyoEly0jT5IvfQRge0zFj06XL4adNg0jT4/JUX8P/90mfxGy98Df2hFUyOngR3aQ5XeAPPGyeHfr7dusLNw3uvw7DVwEOdolyK7MsVPhGcXZFRnSAliE8GP+0LhBEPE6Lcx8l4FIiRS+0Yp1YO4/hkyfShCvY1OoycsNPBFRHqrAV6xWiZke9xzWxk6bAEe+2RVWnK/zH82ciRvDjpXTwKzv5d9A+MAFOYWkOtwLKiSmnqmQxBd+DDVkPCWDxR3vfGPd7w2lfjPe99Nz71m5/C5PBB9Nwl31eFHsZNkvIlWsuXSd/aAHV9Aty+B60eSFHhzk5uIhekcOWzaC7MyxRwgjOa8m+lg/xxg6FID0I9G6gFwIDDLIcCqlx+VXQ0wswCwPLK589vnB0O6QIm+v7V6rWYMF8L1u5hIF0q4UHYp0+FwzsTJV2uMQYSFcAuldk3qDQq0bkSQPNMH25h8QP/oS9UHKX/A2P0r24P4chbiJNU0g9YpOktdsXQWpXOyZOoXEAYBd/LSwyil2XpCpmLTlGixxZRVuhUHpiDkkZZ7HeiCZh79Osb4NkWXn7fq/D9f+BP4D/7vt+HV9x7Vy6uR9dnG9G2kEgqTnEJidK2/DeDLIjwws5N/NUHfwv/5xMPYaOdY3LsEBpu0XeMXgx4yWJFQlc+CpmRtuiBFracSTsgsIRNLtj0JTiXomzOZHv5Nl0UeozvXs5Mx6MR0qkrzZf69ZXHjuNAM0Hf9zoaJjBl5rCw774fKnLq8HDXh52e+yDGg7sfofPlD9e8DB9tPemhFtXeDgZnQGQuKBxEUJz1WHaIN9X+rROTXQn3Hr031MnLLAyOo7H22GKGFOU2kwZ/4c/9Sfzmx38Vi+5IsI8pis11EBnoa5SWy+t78MZmAtyl5cSOlVWgnQDb20DfpS1CDuRsjlDa4drpvHnbAxcNjciBRRgASqVUZniQcgpSSKUZTTfH6MC6VBoZriFqwL2PKITA3O+hXJ/AiBeadK4VNkecohcZr0WRDhBjF8EOwdBL21i+cFCZzCLHW9c3xv5iFTH78kUmvA4Zv3V+2EduTlJzEKC6R7kMD8bEjcq9RMHGHw4yoTN22mak606Ff9pGD8CF8yHyJQDG1jZbWGd9YFtQ4vwsFf07mJMV/oKMfgLS6n/rr7iKmgMY24Ip+TmBf9O0Kd9ijv7mTQA93vjWN+OP/aE/jD/yh38fDq4uo+t6zBcLMBhtTk+i+8VQqH/kGkRpb9M0uD7fxE8/8iD+wdd/G+cXG6DVJbTNGrhjAJ0gXehfFRWVUdK+K9mrfFLdkfUKZgwYBuReokufCoj9G8yMkwFrb6xDwds7ySJsYiCRpcSbDgJ4vsCrj55OcsppqgcoplMQGpHJ8TjipM8HNHE4yBpSYIRyx11J6THFp9Hf3bcxvDLaUknjc7Yjj7fLgzlI5waVBAKRQdHLd4U7IB1tADvjPZoo/mxLRIyWpiEwU97Hxvjwh96PN7z9HXjwgS+DDh8B9QukzewpN1Ojx6ShFEQ1jpzmaudz0PJyuqSgaYDVVaBbAPMZeNFBOmk4zGmLeoKvw14ArRWiUIEfBQLHFd1Ri8zMO2ESxfP9kN/5LRaqTwB0H6D/UenJiqQ0lgUDouXe2IhTofOEYpRUga1HA3a7MpWELFYGwFaHGDwvv8oHYWVfpFVemfXwhk4fH4FJeseaIR9Q9HVMIjzUyNZhjo/+YkOLx2/BkjKcfoQWZPop8NUl4vKdN7CG6BaJK2LlX13HEKye0tgbA+yvAHCuigA0JHfJMoAG3E7QgMA72+DNWzh45BC++aMfwR//gT+MD37gXWiI0HV9OruYCJNJq4VlilNVQrYHXAFFlRPCZt/hZ7/2JfxPX/0tPLl9Cc3BA2gPHEpp3FWeNjrjAEpB0PVj+QhdRXZWB8UcIAqlOJ0fHAdlc++Omli/OjcwZ8w5SFH1yo7jWIZrQAPGe26/Ay0IvfalBDaRC36eNrKEbPverqAgpVkacv96hrGzB2UwKG8F5MdiUqOXASZMxOZUn73oHhht7zIEN8TSkG+oaySzSXJoWp25A7ALdFSycVFqSMRp2Ldp8Lf+0o/jW7/z90O2fzRZcHsipLOTC+By9ErdhB5Y9OC+S0A7nSQBIgKmU6Dv0/FrWTATELiozRv5ApdSWmuMRlwEF2GSGmz1YLMmqG12jhKzCJQzckX0J0CjxtiXLx6xi1q90VTAyT9YYMTaBnMEXDk5orHoyOSHff2+U73ka30WYVmbzalJ/hMNeBJMzwhPvOMn97uGiE07TRSzMLSuPVZXtKShTEh/Ga+cL+Ii8BgBKi1FnX64zOykrHolLUf6T0x44L8blvbztRSirQIkJJGLuJW2zHu1TYUshajWAy447ZWnPu2P5R7z9XV08x2cu+tO/OHv+6P4z/7g9+HVr75P6Z3PF6nfGgI1Ddo8H8sZRMOCOqeaAMB9D85zv/Oe8R+efBR/84ufxldvPIv2yEEsHTmCruOk687wknBAaBfT59oVcMl6PoKhA3nV6dBnBVxL/2XWaX94MyZlaEicP+e/XBZadfBcIobmD/BNALjH6nSC1xw5lUYESC5mqANSDUiT7DjHQkY2hB9FE5UkKdNjWOk4Ojsc6Rg+KudFLR6PJhkdgtUaw970m4d/qzkMDY4QGRoEY543otEzKiiptdInLXBwLDoohYI5H53W9fjGD7wb3/Kd34mP/dIvoz1+HE0/TxEtGoAa12Bn4TId0sHCXOI+RbHdIhmkJh9Sq3MT0oasIE0z4J1TP8cRGe4k854cEPiOD0ZZhcgtlsl65HCm4FehTKargyQCuImnpCCmZ2sEQxkfmVPTRTAh4jeeBIdgYGyHJaeItFQkN2Sfy7BhTsefweMAL9cfRh4Ac5ik7MDD0rFQbyU4EbXH8Jet5KITdBhZRTOWpX0OCnKhi31c+eJcDGnyPJcFNwECwvo8xzZbHKiRu+sT1w59xVnCB+0E0ulO0nfpJlnRn26+wGLjFtqlJXzDW9+KP/Gf/xF817d/AEePHQaQTnoiSttw2kkD7pNRlGMVZQiRs7PQMaejbjzTiYGmwYIJHz//JP7HBz6Nz5x/HO3qMlaOHgW4Ac97A61cnuqOiwrDX5WxDPbOwPnqAyB5ngFqA3zd8t6zfCBpBfDa0D7bH2+npV6RN5jkaxkeD/z+dSJw1+P2g4dw+/JBgDmNQAgwi6NBCG1WzHBtC26I0IooVuqElg+PQLuwrGYJ1LYSCuEtvttbMMdhZC46tJ6XrZKynpryDHqQ4k+AY5V4UT5rxWCEujN6KgaOIawjA5lR2dj0zNmDZbTU4n/5O38Vb/rcb2E+n6NZmqQbOaiBXKplfLCOinObcPNoKS336b9kLPycnftc6A+RzSGWna6K7yKyEL0x8tm/XhDVRoY+UrPpoyL4OWLJI/S6rnFl2mri/Fm8YdUD1mIE/HUVpo8sFVDTfFn02IUO95c5VZXv8xVAH6xMrPEYRstASIQGH6kyw2/P8H2oKuC6QfvOxCb0H8FGBaRJcXqGqwBsztMgNjVekhgEdj8ZPzWPqmXq0Dgn6ukBNGrKZXj6SCyk9rOs25B+IGW6RMbl6EQZbRN5++B42vfpTP4mtW/R9eg2ttDNtnH0tpP4ru/6VvwXf+yP4h3veBOm0xZd12F7ZweEtD920rb5eGvK++ELGgRw3bs+63xDhAUzfv3CY/ifvvh5/PrFx9C3jJWjR9AsCDzvwU0PbtRaJaDg9C20xa0iVzNWmLCSP5LYuYtSWCF7zumT8rM94EIuQhZRbFe5PzTCLHohlx7QKsGb6m7+yx3j9PIalqjJI4uEgahHZjmkKJyQSr3eCfdpqEJbmb4a8ZZJK/1k2VxZOcOkBCByCar+fUDj+txsSZR34mpQaIkqYF0aKQDlodCh4HoFMNDwRghoGpnh6UHUggDc+4q78FN/86/jj//JP41++Qz6pgO4TQtte7aFUXIIwEj7vJdn3p8YqfSbdAT63i2MacxgMgcAEWVMJJSgY3ULaGo0UfAx9CP7XBRBm5R7qQh31JnSbl9i2argrjhyvzlGlZGsXzxk7TeBlkVyjNhGS2fGWioJ3r6sWvZkDyKEqMoxGGGlwetDKr/UHDFqoqEOkYstE8FWsJnFUrDDO8fgEDFWHj/XaF3GrglZpl3TQlRdDJVVa6LiY+4XP9+PUP5wgZPIOlGfjnYE5xEmSnpKaV9sv7WNfnsLkwMH8A1veyO+9yPfiY/+vu/AHXfehrZJC/a6+QIMwnQ6BQDdG6vRk2sNZ1bYDVJJB1sAE2rQocenrzyFn3zgs/iN809ge9phcngN1DVAB/TUpbUggee5LGoC1PoFQ0EVI3pU2BuUODgFHrhTnT6jDGsaj7XbU6MHVXIvvVzYfD3b0oxLwJnCJqU1L8i2j0AtgTrgNafPQnZ2JBK9I2FVsBaZnQUNVsYfkdcyVQkXXJSz1yhT+pG078Rp3I0cgi6QikZAItd65prlrhReyTxKy26NqmVmmCce5a7I4pDCCNOimnzIAQCNAgV8/7Mf+D785md/G//kX/xLNEduB2GmQJ1INsHUuTBI1CeAHn0IrQuOPwHUXDQsEQASwEtlpQGElBX2VrrUAbi8Flr5UoY1yQw3c3Yu8mdR7Lj9wpQtRXgZsHUI1+rlDDpatus8Lc15yMEQgzW/KryAufLemwWK4pr5Uc7leOfCR78KJUpDVl6VmdTvfmiYJJ+ijKQLr1Ja72Sqo0BqcLyHMhj9EOHyIwJSBpn5tZ/KqKAwrGLN+jxKoO2k1P+97aFlsQ3ZQPs+suF4hpdHD7qml9Ju6dGgAUh7TPsEuPnGnZ4J/fYM3eYNtCvLuO/lL8d3fNuH8H3f851485tfh6VJm3WmR991yr+G8t5YAdrMHDlzWKiVe2VltIsoHV7BzPjc5efwPz74W/j4849ittxieuwolmc9ujmD0eniSXOPmgS0bmTGy7Tpl/VDdWrNGTA3Cwi/MEgfAaYgI8XvCmhSBoBO5CXRabaL1UFr2im468DcQe6otmg240aj3BWC9Q8rKqW2TTrGu2672xLmkbABPBIZPTAbVF9sWDbWrVORsgrvX7nsP/vo1xldgZ0wAlt9guEBAEzYSjNaPfYOnpGxb59iBOJFn+ObXWgcwXQz6vHdsKhdGOIyNI2dLNR1aTN60zT4yb/zV/DlRx/BFz77O5icOIO+m+WzTmW4FUD2um1owoyYURgN4oAmlh9ksZQkdWJHw84LN+LAFqyEqM4bF/go0BRO02RJiuIgToHYVgOHogGufaz2Rcp1o18gBz6BFcHoSNFuQQkyCOih/qTNN2Puy3OclDnhnoMRI5dJ5Eqrk6Y7fnKfrlobDv+xZSOjWGXQleWHW6VineuvPdrNLhplyye0KZecgSX1RqJ8KKALAZKfsgEWGZFQLzhskb/mXBg/yX4ZZDO9ZBATCD1IFrlkMGdq0kESNEXbd+CdGbBzC0st4d5XvRLf8R0/iO/61g/hja+9HwcPrkCmg+bzdCmAbtsR3XK6YPRQuuou91RapJMkfpL3i2/zHP/+/JP4R1/5Aj57/inMJz2mxw5h0rfoFgswgKYhZJSJpp59xzs+OSENugHrz/KzdS65r9I3vh8LOaKYR9HC6Q0J4CPLC/fJ6WKJaXsQWnS3bqGZLAGry+DFLF8l2oOphWxDGw4XZH2FrTNpwCBeYBUN3nbiNACgJ651T3iGI2SkfLKvpodwrGHL5AuI9qfAFPeD0aRvKvoQqdV/cyyfI9tRYK0ZeBoKgfst0+za5QRrQIz7bWB1YUNeAgwD7GTdkjEYLiiGvAYOQBZ+25dH6Psenbv0eXllCf/hX/5jfOi7/lN8/eGH0R49Bu4XyUDI8Ip49AUomH2ydoaIJaOq2jTIBxcZZPbnkUmVQFKFjcOrbgWKdTVHQLXy7V3pCPhSzADmvodfJRo7ZLD1ZbBSRrtSIzChNQG5pfc2UocfqVF6jMmINGRwEf7ZnCoUnDVCzowX8C+lmmH9YTTnivUELdfnmtbaJnyRSC9GszG/Q0MzWkKURIEuEvN8V1nR5Nbvdmxd5rfoMDkyKlG0kemmMdxCtoHARMR3dFs7vTyZcUxzsA0hR0xtOolptkC/uQFabnHvPXfjQx98L77r274F73vvO7GysgQg6ex8vshOEGWglftQo/MahhXZItku25G2IUzaZBJvzDbxi089hn/49QfwwM3z2JkyJkcPYMotuGMwd0ndGhFHF/Wo/IhMetlAXigl+m+y4mM6i6YAivMkzoGxOr2DZwddWBSocqK/yG+5jAZyo73Kuv6vm+PUosV//+6P4O9+/mP42voG2oOr4H6BtJ8lg2zTmAA6WUgRo+k2MYBFj6NYwsl2GV2fTvJrSIBJmJDjeDL5HRvitdEB0xtyHRLsv/tcjWChRShYDkYQUAHm0jnIuYUPbhjZozdrYQPc5pje6LfFNe7PMK92RhQea38EyABo+R8mwvZsG9S2WG4nSTDCyThCuyxAGXofNR9GhpG1bmacPHMSv/of/3d850d/AA/8zufRHj+FludoOZ192jGhR2PGWgweJ/CQ6NP6XYZhERwEUUh5EYXD88VFnkUTzM7H9vp+CR8ZgLvqbHhuuDeKQwMunoDa00w/gUJb2IrTbyIvwoFy2FPo0WiOHT2euh7RyOfEKqHB6XJy5Bhv/VYsxVGQl6SuXeTMgjuxS/Oza52xwhqoNoGNQcHpifooXAo6JOV650Pzi6mFnuPtI96SX1A2ck4qIwe55sLJHuirO87O6vPpOOtjPpeYGT1LBNuAqAWY0W3vgLeuAcS44+Uvw4fe/xH8Jx/9CN759jdh7dBavqKOMZvN87GJDSaTSXRmvJPtmgpCXuRk+iZHTDY5Gn52cx3/8pEH8U8ffxDP7lxBvzLF9PAalrjJflCvx6dSH5gdGOP7Vepm98KmKJzBD04IaZ95SVDagWKhj9em2PqoC0KPWsckiz1bvdSAmy79tpjjQNfiH3/TR/DBl70Sr1tbw4d+/h9jfmgVDbXpuNuWdBrOyig6QEQkV9N3Pe48ehSHJ1PIEH4RHwnVIZodBnqZO35y2iep2P5QoAsQfLRsozN1rNCKnNEM3Gckp8rZl4l2tsiM+69avHhoYh4dX2NU44mo06lzQzBhCYYlp5M/vv825gv81iNfxR1nTuANZ+7K9052Kki+5jCZ7jxDGpQMNG2bAZdytMs4deYUfvkXfhbf/4d+CB//lf+I5SOH0VKHvu8BbtGjhQwjpSq8ihcCqNU5GrNxjSDp5sUKIRMPTA3bAGCL0Qct38tZsVq3iGx8ZCZKr8O2LvoGLArSwAzWFs97G/LM9582rlpHs587EU9MnC7v1NlnAwpfjpdL6/80DMwuY8ANtXs+TwE2rk8G82qZET5SNN6boxEMbs6nGuD701ugCtAmTC9+kOZIf/uOL3DBpmPKRUq+rbENNu/J7t88j+b1mEybxag0+c5oIqBhxmLRo9vaRrezDpou4/S5c/jOb/n9+O5v+zZ84IPvweFDB3O39ZjNF/lIvwyOehGAyb53dtSHyf0pc5UJVxJfG2ox4w5funQB//TRB/Fvn3kYNxbraA6uYnL0EJoe6POpTzaPzQhdJ8yE19PScXMdqMc0FgEKeafc+pQdveHxQYhaUdJBEZMxCvmJBBwBsB/lSos0mTqAWvQ7G7hn5Tj+9Xd+P15z4jT6vsdb7n4F/tq7vx0/9ju/Aj5xEtTNE18bAjfmOvsRBeUXc14TwOhnc7z88EkQ0r3iacRmiBT+/I1gA10feNtnixYDC0NfBLzyzpnw2WXPFZRU+VLsrbcHFfWly1eucLr9Jo3Rz+dzHDh4AEePHBk0JFBAHsk5/LQr0NY8jcJr3u1R4STCixs38FO/+Qlc2LqKP/meb8abz9yVEuUhJVCek8mGoqHhLR2h7CzkRgrn4lJ9i/kcP/4Tfws/+fd+EgygPbwKdB2AHswNerTo4U6ZAoC8MAMuSvCfzWzt0n5vLBGNdpizYw++vgVaqxpyM4mymjq8KXKi6G9n5BUYnGEIK2xLdICCdqzVf0ME05BfDIa9toLHFcAPnZo9JEe/N1mRlIDCrj3qZOTXg0VzQq9zmkqd0T/eQBb9HRyCsn0IyexlyFCps3A+h3pq9MA5OGK6kwiTjXb4PEgRrA1mNuiRhr+JO2C2A97aQD+fgaYrePvb34xvevd78OEPvR9veesbcCgDbKqS0+KmRqYGbEqjaRqQOKWaPvGeM6hqxOvFI8vr9W4Hv/jsY/gnX/9dfO7C01g0HaYrq5hMltMJkU2aS2xy1K0dqQKSeSJ2I7BYANV/w8A2Bi0rQCOYobFLIcIHGuipYo8IKZFuSQreepccmj4v6OL1a3jv7W/AP/um78CJpVUwM1oitNSAGuAHP/Z/4GefewQ4ehToGNymsgPWKLsY1AHU9XnXRY9ufR0/9Y3fix+497VY5CsWW2rQEqEpnKfhyGQ9jo88yTwcDteFXGNWt2IBXaYkTBsbG7h16xam06naGJVLifQB+3758hXmvk/eBacN3wcOHMDRo3Ww1X6vEa4ryQqPy2uzjzrIM7XOAZuLyGUWkekCjJ/+4mfw137+X+Nb7n81fuRbfj/uP35W61p0HbpsiKUzY9RgrHWjOarY6X26j1Ly/eYnfht/4s//N3jiKw9gemAZS8sNuGMsMMECE/R5T66CmhyGkT3K5PkZ8IYW+iElB8gedGQRit4fK4beGelyRa95wTaSYMbSzWkC2m51T8mIKAHeArjGolu5n9Rpno+w/MrnMAzjy87/sqQRsNJypF3p9wCgri+DnBHlFdJuzlbTIJQZFc0MvKsinFEb+c9xhan2he8faH97qA99PaLxaogVx815CRd/SyWeGdqHvmVQXRB++XKGfrCBbfEWQJp7S6c4pfr6jjHfnqGfzYDFDMfOnsHb3/g6vPed78AH3/d+vPUbXou2bVWOF4tF0reG0Ob7Ym0edkCJtlMcHNHfDowuy2JDhJYIPRgP37yCf/P4w/jZZx7G01efB68uoZ0so22noC63u5GOBtKSHjff7mTZO1mJ1ezymSANFztFfU1mklQd/BSFnuIkchb0VNJHPRIh1iH9JncuiR0SOrKj3+eh/W4O2tjAD7/2g/iJt70XE6TjLCnzryXCpG2x1c3wzp/9KTzKC2B1BT06B7ZOmhlg7kEdo1l04K5HRx2wNcMnP/on8cYjJ9D1adSgIUKLGBBJeQKucfRl+HjxVwHx+BM/xn4J9bpUIluhEsL6+jrW19erYIvcHiAdC6xgq3e7MmO+WGDt4EEcPXI4GJh6ywY0lj8VmhqtRzDGIZO8LoE+CrXN0zR49PJ5/OC/+l/xyLOP4KPv+hD+9Dd+B9506k6loe/7dAqMmHGiPMUbhyx1YRKsfMC/T3m2t7fxt//OT+Enf+p/w+aVF0AHDoJWD6KTNWd9l/mStiwwGrDsnxXADY1jR0TRuQUXyJJZHhhYWX+o9YQOqxWCB/nqIhxvMHy9ZtEjMPsFOgk84gYFM0jJaOhQD0F7RJTJrBMM1QqCzXkYjgg4DI08EHTKBjlkM7tZPJbQVlP6ctnK9ZFPnexAowdd/Uo0IM2MMiy9VlvQNKjT0S/tE3YI/9llZvu9WhwSx5PNln6jdP43NcmDZ4DQgWc7wOYGsJhjuraG28+cxVu/4S344Hveg2/+8Ptx9txp27fODO57tK2c0sYqLzFSqPOSs3PFSAdONKB8lGLiHQNYX8zw6xeewT979Mv4tRcew8Z8He3aMppmCYwJ8hU/Jp+ub3SlsXMGa5SYeXDgL8wfy6b6bj3m+7vkfkVAht9VDLOOEJLDT9DtNwLCSY56NNyg397AYZ7i773zI/iee+5LtPSsFwLZVXzAtG3x9csv4j0//4+xdegY+ski85qTDVBzloCcegYtejD3WPRzHKNlPPD9fxonpkvpQAsFWyrANjWmZHscOjYtNTuSwdnZ772xzDlKFJQjsFhs7Pr6BtbXNzCdTkAyakqEtsn2PQ+rU5NidQNb7tH3FtkeP3qkDrbiZA2ahmDlakvYB4rr01MEnzgMMwRdBqPr032QBMKkTcO3f/NTv4i/9nM/DVpZxgfe/G786bd+Iz58z2tBAPq+x6xbgDmF9m1jAxYKMkl7DWgzIHi9Qfa6AcIzzzyPv/G//EP8zM/8H1i/+DzQLKE5fBiTSYtWTmdkQo827RMEQY99VKvG2rHGKw6dbZGpwyBJ78HP8BDxE/tiDIPBkFOIpLwwzKzevDP6MjeT33lD7sHXvHMT0LjC1yJGzsbBovX4u8qLcwR4RBlEQf0qWt82ScNAGtZSTnnHQNJwHpkwgPLG2K/KZZFVQtyH7BTXR8AWmWfaxDiILkgfZ3Q0nhjwKH/Ytdf9qCQFZ8CMueqwd/bye/K/Q4CW0VBeOdokme6YwPMFeDYD5ptopxOcPHkSb33bW/CN73oXPvzB9+Dee+7GoUMHtI/6vkfXycr/tNXO1kqgeOSdGFGjnJGPU8wjCg0IS22rPH761lX8u2e+jp9+9GF87eZ5LNoe7coKWkwSt/t8labTG5tWiG6jTxScS6eQ4gSJwKjtCGDhnSAzLH56xeutHn2ayw4azZZGKyEDO71FKgOBAC6L/IOApgFt3MCbT96Jf/K+78YrVo+i6zswI0WzWb8XSCOJDGAKYDqZ4p888gX8mV/7j+jOnADzXPU7tbnPK5y7tACrS9HzfL6D+w+cwCe/77/EStMqDxukyHkItlAbYyqmAhz8jxJH5ImL+4bWsfZozzPycHS0O7du3cLm5pZGtnLcZ3IOcz0S8ULAll1kO19gdWUFx48fGxBWPuQV2ymDEFoZf4r5R77VorpalMsse+SgW4CahvDolRfwR//1T+PhJ7+CydoRnL3tHH7gDe/A97/2Lbhj7Vg0ZL5OhnplXNQ2eHIayl73pUtX8PO/9Mv46Z/513joC1/CfP0mmnYCTFeAA6vgdgncTPI8Eun5yMTJA+dequdg8D0Q12hQ/QwKX3Ar4q1xuCg2OjsGgsP25/JJlNwBD5GNfElOR6e3+Wq7vE+hVRjRozOWXst8/qBw3liW391ws3kLoe4EbBSzB/qGj1PL4W+G7OqwyDBw4o8D2+wIJcAvGy70yRvPDD8nP1BNo19kWMxu8iTzQRKs/ElGI23JYU6LnHi+A2xtgRczTJaXceLUSbzq1a/Be9/1TnzwG9+NV73i5Th9+kTgijizTdvq2945chHoXHPU6aB8cA+j4UwvM7oMIGLYNvoZPv7C0/hXjz2EX3/2SWx0m+iXWtDKCggTUN9DEZCHfeWdROOm77QKduoH+0Xhl31S7yrAgGnPxzsa9qRWeHCXfpQ+JVCT12ATpYVMlOYyuSHQvMeR6zfxR9/yjfjLb/kApkjbqYTShoAmf+7AcvZFAuG8c+NPfuoX8NOPPoD+6BHwfJZclK63U6k4zdXKrUez7S187z2vwz/98PdlJw4ZbFNd6VyMIeDGhg9tUpVBmjymHzjw5ePfSxcpm5PQ3Lp5E1ub25hMJ2EERg9QyXPjEvGGyFYWSC0tLeHUyRPwS/+VaADh4HHxPJwgBhB2jHEi6/xlX2YhiAXzok9nP3TcY9F36HpGA2B5MkWHDj/+az+Pf/jrH8MtmgM8wdryCr7jFa/Bf/H29+Odd92LaTNBx4yu73QRVIOyv7zRj50hxpFAeRVziiwef/QJ/O6XHsLvfPnL+NjHP40nnngS2zdupLigXQYdPACaTtG2APp0t2Xf9eg5n1wDW+kLrziOiWZEje8hgsJQWNWYC5fdiIPscY3eowxL21/AhE3AyUeQlBGVK/mlTClDIkdkgy7AbAGfAI2kIxdNRoUZRJgELTdXaLKjbCKjKYT8EbStub695pBop7jIO47mSHRiw/zixAjIh/Q+Qi0jYWultasS0Rp/XL/AaHbqBnHoiHPUmlcLJ1oY6HosthfoZjPwfBvt0hJOnj6Nt7zlDXj9q+7HN3/4/Xjd61+D0ydPpFPZwPlu2Dn6rlcj1MoKYhlWczZC5z294WOL0JgZPQGd9Gvfo+U0bNxTg210eOjKRfy7J76Of//s1/DEzSvopwCtLqOdTPO55I45VklakOPrDYaeQ/dqLu+QWdiZxUtGZJyusOO7B3YWlw5wE6lxZEjrSWk0lchOdkCSucjwmzu44VxJlnVO6JlkZnsDt00P4x++6zvx4XOvwIIZHSd+NGILfTDFyMGNs5NEmKPH+//N/4ovbF4DVlZA80VuokQQedFVfjdfX8ffePdH8Gfe9E5wnw4FIRio1yJbR0Jq+0ikCsdeGZn072plFtnUrdHvXJSVCMD1Gzews7ODyWSi4NrIdAq5BVIS3V6+fIWZ8wKpvsei6zCdTHHq1Mldo1qp0I1vqBEoQckL8pgTF2OR3V09NTk5S1pxnJwFBkB9GpZC0+ATj38Ff+4XfhZPnH8ezeET6DbX0S4Ybzh7N/7gW96Ob3nla3D38ZNQFen67G2RuFypNrYtSTYZ7pwNZt1Yn96l/PP5HE898zw+9anfwSOPfx2/88CD+Pqjj+H6hUvokYdZVqbgyTLQTnQFZd93KcLgLu1L7Dh5pfmGEwblTeQEEwwHNqN8K3phkJaiUEmyEmzNgkAWWMWITIrzAC2g4USC9J+6k1M5OSuVJ0ULwLumFA4HFUMV5cxOzYsx8sMX5bS0d/DUtHfwozkEoTwU6uIMuhp8V8wAMLUAzxsx5L2Crw3HN3rggA5N9x2wmIFnc/BsG5jPsHxwFadPncLrXvcavPENb8Q3vv/dePWr7sNtZ09r3Wl0JjmelA/7KKc0/CKSOGQqxaQ26KlO2b5R/k0ANznFhK7v8fSNa/gPzzyGn3vy63jg+nnMeAY6sIy2XUrD3HnxTVK0wrZw1ByR6cJnMf6T57/TJv1YhAMqOk7YVXVyvV5Gcoey68+6BY51s9BgCpD0LCeg3PYEtk1ypjbX8ZF73oa//Y4P4tzyGjrWc7QUZH2/aStc4NSD9WrSp29ew1v/9/8J62sH0HIDzDugccPo2vA5eHMLH//on8I7Tt+hdoVA4VCLYBHIOLvvOdjyKQNALd4pXC2Nw7WiQFy7fgPz2SwFWhLRNhbhChZou67krT9yTOFi0WEyaXH69KlqY8YXCZghiiSVDoF1VvAwXIfW0tfoKCthpFXDXXYe0lxui/X5Dv7SL/4c/tFnP47FyiraA4ex2LiFbmsTBw+u4T0vuw8ffd1b8W2vfDVOrh6ws2+RhE+PAc2tDEZDDR/nE6iS0yLD2pNJqwegy3P58hV89jOfxyOPPYrf/PQX8LUnH8XTjz2DxWyWTqdpG6AhtKsTtAD0UpKmSYsG0aQtRk0LzgcDBF4AkM36XjniiEOcGxOPmxNzg/HRYgtECHOERWTmIzKQ+vr6XQwoKjLgKrT6LFXsdGmLN42S10XU7gdE107KN0DTs4xdBOiHaT0AC79khMMKJs8WZElyxsK1T3+vgLgvxLXLWW1HmWQhzZqMbt76loHWIgdGN+/QLxbotnYgoyjLR9dw+vhJvP4N9+P1r3wdvuvbP4BXvuJlOH7sSPbtUn45vUloadvs1fu1EEX/1oCE3W/MrNv1GHlxTmPg3PU9Xtxcx688+yR+7tnH8Bvnn8LmYhPUEtrlFRA1eb8mQfb7pL6Tqw8LXqqkmyxSdr7Yp8vOA2UPwEZMEM4almjT5t+heYP8S4exC05YV6oEHoWg23MuH4OY9sZ6PiewNRTucmsa0GIHh3rg777je/CH7nu92kwBBgM6J+de3HIfdcxYcK9z5W3T4ucffxh/8D/8I7QnbgMWWS5Itt8w0BD6bobDM+B3/8iP4ezKgezzSb0umg56J10wYITxyMuS0q9dV9F3a0vtc8S+QsNyP129dg3dfIFm0oLQoG39nK05lRKU0ZU8Z9tlgEjLvIEzZ07raUqRThoQJgQVuyKHT9VzQDQoRV1+eKkGziUnS2VVownGbz35FH7o538GDz//BKZHjmGysoLFzhyL7S3wYo4zR07go/e9Fr//dW/A68/diUOrq5AjAnUVZm6lDJs3zngxm5CrWSdrR1y4k37rGdiZzfHwVx/HQ488jN/9wlfw+OOP4asPfRWXrl7A+rWrqd52CWhbYJLmnjCZgiZTMKfoJF1W0KdV0Jz2OGY9yI6ItAKuNcN+MHWPvw97u/iR3AffJwHsfG4BccrGK74P6QN4OIOteaC2VTI6W6bvhi2m8EeMex3Qy0ZXlFHpdMociRg+bLSW9EUAzbKcwdPa4+dzxfim+VXIPlTu0xwaFuDtGbCYA/MZ0DaYLK/gzjtvx32veBVe89pX4eV3vRwf+KZ34OzZ0zh4YFW3cQGs0aV48ETp0BfvFHkDo20S562IkNLpgLYK3pzDpEeU6WcAF2ab+MTzT+HnnngEHz//FG5srwNLDdqlJVAzBRZChwBHrt05Sp6/POjaso948FXuo/UOFcqPY/atfIIDlZMVYEtF0lBkzpwWOpEugvKykA6syHrSd+D1G3j7qZfjf3v/d+M1R0+rrRT/TtySAHIVuhmyKE3A1mj685/6GP7BA59Ac/IMaL6dDhtCum6Q2wbdbAdvOnQGn/re/xeWKNohkQEDfG2l8aogq8SjchHkgHnq9LgmgUMZZdlVNvQ9rly9Cu4ZTdtmkM2LpBpbmUxOBm2BVJfAVhZLnTlzBpNJW4++LZyLprkAvdrnKmBWGrrXU4tsS++Ls/fV5RWn1DTYmO/gb/3ax/E/f+KXsJg2mK4dRdsSup4x295Bt72FSTvBq0+exkde83p8yytfjTeeuxMHptN0Shsn77rLNLSZyWOCqluURLD7tOq77zt1Zlo9tQppKwSA7e0dXLp4BQ99+VE89ewzeOrpp/DAA1/CY48/hWvr17B16xaomaR7EFZWACJMVqYgMCYNIJeYJ/zPR+PB/ycdVgeTilx75qu1ykuI1JHyEZ6Bl/yW+ZPHvLjsxwD2pidDLxMQYJHPIYk7S9bPUVMhIyI07OgP+1R9kWKR2La8KDU1kPUKUQFUAYOwEM6KivqQmaG956JVAueD8LNN7dPc/2Leo5/NgfkctDwBzTscOnEEt508jXe++204e+I2vPKVL8eb3vB63PuKu3Ho4OpAH+fzBRaLBYA0r9Zmo1LrD9tyVjhMni9ErsfyucQugm1yVJAuA2Bcn2/hc+efx//xzKP4xWcfxeWdG+jBaJZW0DSTNJfGPfqebMiazBikoTyTNyh026pviPzKsaO+v9SBs96T28a03zVtrsuFU2H4VaPZOCDJDlTJ3dwFdnaEZeV1LtcSACD0uW5v3PVgyp7Asw0c6gk/9qYP44de9w1Ya+R4S+/yWnQZ7bg0M9pzlr/5s4Buxz2+7d//U3zm4jOYHl5DM5+BGkbXEPq2wWJrE99/x5vxr771+9IK5YZ0ygCU5233gQu1oe2xNMpDJ3yiMaFd/mjdUHccBQSAvutw+UoKhGS9DpFt+2ncFJ86MmnONu9Dzf91XYczZ86k4c8R45NICC0LvwVPo/J7mbcawTq9VaOuWQpkKB5drcxpWFlGVdLmPsbvPvUU/j+//O/wqScexfTIUWBlGUAPXvSgBaNfzNFNCJOlZbz15O343vtfjW959Wtw/7HTmDR23J8esoAkNJ0b/tF5D2dQRUiFbmmXrMrsmXWhlamVGfPtnRkuX76C3/rs5/HgQ1/BpUtX8fRzz+Hxx57E1etXsXH9OsBdqnM6BYjQLE9B02UgR8JoGtih/33yqJkNaAbjVuSiZIsBzAuPaWO3FB68d7Y03bgH6RPWvG0epCl/GHnBwyRUJpBPKock/3eRkXc0o+MwfGy+VHitJoMZ/sYWzvUlmU17tImQgJZ79PMFiDvwfJ6G7GYzUJP2qE4OHMDa2iG88lWvwF2334l3vfNNuOPsnXjjm16DE8ePYe3gKtTZyfX1XYemaXWRhxh9H7kOgTa32QOS6wBm453v/uScyRwhQ+6RBoArsw18+vwz+MWnH8enLj2N525cwXwVwGQVbbuEvKghT9NwWFDoh/qFXgWtPUQs/s7Fx1If4PrenD7xQc18FfVSBRdKtslrsZvimAodkt6N7PQqexQOr+C+B21v44NnX46/+tYP4g3HbI4dbuopkBhGZQolka8O/DmPUKT5WwY1hAvbm3jrv/r7WJ8Spm0DcIeuJfQTwuLmTfzNd/8+/Ojr3qmXeciuEgX8ERoGUWvBr/BkOfPOTMHywm6NPObxh9fdYoHLV66maLZp3ErkPLqj87aAnIlFV65cZQPaLu+17XD69CksLy8rRdoY9faEhrqBGfVIXDs9+Rw+7aUZ3rPhcKamn6PzUSUjCYQOezQN5v0c/+Izv4m//Gu/isubNzE5dgRtD0wWHUBAt7KEeTsFujloe4bV1YN4zZnb8b333Y9vfcV9eO2pc4HSrsv7eJGi3YlEvFQRIjEY8llaI1FwNnIy90wAJtOpRhdwbel6xubmNi5dvIxHn3gSjz/1FL7wwJdx9fJFPP7ok7h4/SouX74EzHYAaoHJSjL4kxbNdII2b8qmtoVAX1gdyjav4wMxdt8HQFN4x6HvcppgGj24FI6V2HNvvMLtgiNPiKOc02b1AZGILMLMMa0k2mVYKeWNy21AQnjKr0CLHJ2KXUxHLhnwAmnen4F+3qNfLNLpS+Aki9NlEBhLB1dx4tARvPwVL8M9d96FO+48i9PHTuBNr381Xvaye3D77afM4cut0ZGVrkuGSIxE25ihEGBX8DA++tGGJKvyk4G3STNM77KsN+A0t5v1ggFc2LyB33z+Wfzic0/hEy88hauzW+gmDZqDK+mYRpqA+y7t0wxAaPqi0UoGX0eyRZsCjT4iDR0vH2Md7gvU4RqKlvKllIkkp04GJcpVsZJRn1gviZMreSVi0HdOhygNKfdNA25bYGcLR5dW8N+95UP4wZe9Bstyty5kmgFVcHOtrIxOUvYLc/9SGpXoGboFs+cek3aCX3rhCfyhn/snaI4dQ9vN0bXAomV0167jY9/3Q/jAqXu0IvZyVdCzn8g2XMigOgftO5ELa59T+pGR1iAf3oPKz2w2w9UrV9FOWlttn0cndc42R7fSprxAykW23GMx73Dq1AmsrKyoN1F6ORQ+DGMO00EfqcZIr8rGgLWOKe69X2jiH/FkPNgmstkJSfbEGODs3F2+eQP/w69+DP/8dz+NnckC0wNHE83TBl3TYtEA1E5SK3fmoMUCy9MJXnP6LN571734wD334g2nb8OZlQNoHfATEOal5CXl9ugcb8EL57Tq8BwhdZ7KfD5ebcA+101pTq3HrfV1PPX0c3jmxRfx/IsX8MILL+DBLz6EF88/jyuXr+DWzVvY3tjUhV1ESSFpupSqmBC4adPqTjRpxRaLYPcq4JwJSD52tgplwxJhZe9aHxegxmzph2A3Bn4e7FQSy4rCR43XNYQfyp1R7JwJle/0vgcBTZsih3x4iSodNbl5DOS5de4WoMUCmM3B3RxY7EBWztJkiqWVA7jj7rtw9vZzuP32Mzh2+Cje8Lr7cf8r78O5s2dw5PChdJaw9oHN5QLQ1aISdfitR34tgY9ay++1R/pa5bsEL6GDkSMv49+cOzx+7RI+cf4Z/NITj+JL1y7i+vY2sERoVpbRLE3BaME5+k1NS9tIwuEbGezJg36EPtWj8hf3Wr84/As8HDxkf4J4DNL50MLnpUBbMZsckiZbUIItK3BSR2iJ0VOPrm3QcYdmcxPf8/I34a+941txz+pazidy6kBKHTHPJ98ijibG6bj1gotytaS0G+QvfeET+Puf+zXwyaPAYo6eO7SLHTz4B/887l4+nM6sr7Jtb7Dd7xOAliq96oA0yoPZjmjCEh93dnZw9epVTKZTdVJbvzBK1jWoc0a2GrnXucQei8UCx44dxdraQaeU5qg7yA/Rgyc5rhyrew9xT51xx5dZxDjOBrKXifh4sBV+Musma0Y6CaXL8zTCpC8+8xT+3//Xz+HzT30NOHoEk7W0QGRBeRhP5lYprQLuFgvQbIa2bXFieRXvOHU7vv2el+OD99yLu4+fRJOHanruMe962yyuq+88GNnwrOw7K0cNPDgJ2JaRsPyVVXEAbB+YgEQut+97rG9s4vq167h08QpeuPAinnnqWVy7chXPvXgezzz/PJ5//gKuXL+B69duYmdrA123gFziSXI4AaXtSDRJK1HbaZsiJZm3UMFx/aNeLcyQ+G4WhRZQLzo4FKeRAWAn+pfCwYXDZnUGFWSb0VZc1chUht4kJJE/rAuJup7T/n3Z1ymeXbdA2m+4gKxib5eXsbS6gpPHj+Lk0eM4d+dZnDl1ErefvQ33vuwenLvjdtx2+gxe/rI70pFwrt2cnbW03qLLh9IYP5JnLfv+rNHDYbXi25inn9OaDbC5ul7BlrUf5NhEAjAH4+L6Tfz2+efxK888gd+++Dy+dvUyZrQALbWYrK7oNXvJWWZ36hFCu23sQ5ng/R594pCj6FnqsGBT5K5USevti9RcjEyEFC5K1p8HXqQUT06estT5EboBOJNzzvL7PIyehuEpbXMEoW+Abucm7jp4En/l7d+G77nrVemMLJY5abHOWeY5gq7RaYQH6z6IcnNpPrixVgFE6AB823/8x/jc+ScwPX4K3dYGTjLhoT/8F7AM0iuhG1mESp5xuSTn246uAwIGF7AoGfLRt9F3kAPUco7dVRbqJRA2tzZx8+ZNtO1ET4zS9QZqe1M/yzpjunLlCnOfhivl9p9Ft8Da2hqOHDmcO6Duu4kxDMZqF2+49BxqXkv0MQrGF0awTlD5yvKQS9eTeeWyIq9tGjB6/PyXfgc/8fFfxjObl8CH1sDLB5JSNy04z5+lLmsyoFI69m82Ay3mWG2X8MpDx/GuO+/C++6+G284fRtOHzqMJTHWnJwa5KE1GU7TMzT90AO87ooAZqMmQ2jaSrfYoohUOAO98iMrP+W+ELpK3s3nHbZ3dnD1ynVcvHwFFy5ewubGBq5cvobnXnwOjz36FK7duI7N9S1szbZx68Yt3Fq/ic31jTRUKWfUqrETApu0upopjTBQY/cRizGa5CHzpoVqnPdCqSxTfnPl+DaVR4NlwErjtZxfZCcmr+5Oxi3vcwaD5eaSfpGNXuea1IImU6wcOIC1gwdx+NBaOmf86CEcPnIYZ87chrvuugNHjh7B6RMnceedZ3HyxHGcOHEES0vLWMpz7LETcs/2vVoV2ceqckOo6lLVY68mERBKvAtOnThmDmQaSSH8a6QM275zfXsTj1y5jM+++Bw+dfFZfPr8C7gx3wCI0Swvo2mnaCatTaWAk6EXgdfRjJJiDn+iZjjnrZanhoKhDtEXbR4UZNXocHA4RquBQDVHWaUon6oWA1m2MkBpP74FDEDfd7lvGvBsG8uLDj/42vfgx974LpyYHoDYgsZvCyybK2S74yBNEqop878iKcNfbfFUj6ZpcWG+ie/6hX+Cr116Dm0zxX95/zvxN9/z7ejyQlAB291uY4u0cvhbe4LzMPw1tGWXQpwsDdPevHkTW1tbeVovT8U0FMCW0KhzRUA5Z2uXEawsL+PkyRMIAggVt0HjfZqywbVw3Bv5YVOss4Ojsp8hBYclbhGii8zjitOek6PR5Yhm0rSYtC1u7azjb3/6E/ifP/1JbDQd6OBhNNPkeXPToKc0VKh312YlIkZa1T2boZ/vgPoFlpeW8MpDx/CNd70cH7r7Xrzp7O04cXANrdJrCz00KoGcpGILB9TcyR2UKva5frLRhaC/LrL0kTA7sJbvBtJsQtT6e0O9p8N6I4i4lbPZAteuXsfly1ewsbmFjc1N3Fxfx8b6Bra2trG9tYXtzW2sb6zj2eeex/mLV7E938H6+ga2dnawszPDYtFhPp9hY3sL29s76XSttME4j1LIdpTMAx+hijEL9oIgURIUtJDaN51iMp2gadp0ED5kjQlheWmKlaVlHD60htWVVaysLmF5aQlHjhzG8WPHcfLUSRw9ehRHDq/h8NohHD16BIcOreH48aM4tHYQBw6uYGk6wZIc5ya8dY6Q9EVaL2H73SX6TZ6xHcQf51TNmQo64srOH4xHogvZ8Pu1GKI/3hzJLGkvC5p6xqTJe2rzAf0dM67vbOPZWzfwuRefxydfeAafOv8cLsxuYdHPgKUJaGkpHdPYI61CFb1sSrlyEamji52jJGdFy2iPl0nVE2171hLveGl+kyIfbQ6Qm2SOtQba7PhsfLUyiznkor9A2aFx/SkOlBXEkK2z6hQSoVvMwVtbeMvRO/C33/Pt+IYTt6f0ecqgkdGsWr0hWvOscLIE/4zZecsjC516Gd5HCmBu9HP804cfwImDh/EH7n4VlqnRVehyWpXxjSG3HBn7C3kuPhMo7I33xFFIXwHaIGTWtr2w5urVq5jPZmgnE7OTWUd1sVTTOh0VsGVbhQwG5vMFJpMWt912xg3RZaOfUSygfuE+eFEMjzMEiYD9eTPmzDovOMCK98Zy2RyjuAHQOzplT67qIkMB5okrF/E3Pvnr+NdfegCzSQ9eWwNPW/TUpCg305fOO0Y+rzWvBmaAOqQ9btub4Pk20DMOHjiAN528De+752V417l7cP+Z23D8wEGsLC2ljhNeJRfRscwPn0YBkS0PEnOb7Yg8VpCW6HjQU/Xe8/lSpCwVi+3abaUgNJ38bovX0rsuR8CLLIOL+QI3bqzjxo2b2J7NsJgv0HWMTqLlvJ0rLTTrs3IXXq8AWx7eadycZdM0mE6mOHR4DQcOrGLStlhaXkpD+NlQLS1P0bYTTGUY3imORT4wPQgfObQZwrds/G2hmxkAAQkBzGAApSw36lHjdSTJga1/7/+K7GdKCHLHjekGMiBKnp4Z13a28PVrV/DbLz6Hz158Dl+4fB6XtzYw7+eg6QTN0jJomqSRZb8n0lxjafLKGGnQpEoT2fOX62mkkgCR6nSInHNRIRUfy4ksc+wGi+0KQpyPqwUKOJmDinyRO1kHwH12R0NpP3GHfnMDJ6ZH8Odf/z784CvfhCVqwMy68IxgQBiBtGKZK5e2+4aVoOsBtrYquPe5mGErn9n1Vw3eX8qzW6dDaSvXGkUnfJADVf4USbhnXL58GX3f5xX8TbrnNztMsg2oadrgeNGVq1dZgNaGkRNYnLv9dt1OEENz88Ai3XXPIwDdPsDWA+dgpXGt/WPlBBq8Z1anQaJcmbif5GO4AODBZ5/DX//kx/ELDz+I+cFl8Nph8ESmUnLpPYM7BnX5EIEuXS3V9gs0nFYLdm2b6lhsA12PSdPi+ME13H/0KN5+x514+7m78bqzd+C2g4dxYLqEhgxA0tnJ0OhIZwWkQyERrVNeGLhVeQfXj5V0g+/2gwNMA27xIPt80cKYg8iAXUWlBggW2Ttwi/Tk3KJDDkik7aXRCpGSb3vFGZE2xxGAvmhjRbYYeW5UO0NHA3y74Lx4D5q+7lI+y6g0tAEIl81r+gzYof9c5GTTJ5xH0RMINg1hkj11IMn3TtfhxY1b+NrN6/jM88/gCxeex1euXMTV+S3MFjvAyjKayRTtRIbBKfcPo8+XVchtLGKKwbZVZ7d9sArMWQ9sqx3bNa9q2ClXXeTNdanhzfmpZKiF/QXLSJ1e+Vnr8PWT9V+qywGl0kNGm4iLA1qREaOBAMpTGwR0sy2sLHr853e/HX/xLe/HqaVVvYtcrnlzUmj6MNBDczLC+IAfGfH23IFWlE/jT+ncy3y+HKdLsKFWXY3OhYPsuwLR/kdjVaSt2BmfPOqB/ygVIfTX4JhY91PXdbh0+XLWl3zeN8Uzv9P7OE2nYBv32aZFF2fPnsV0Oqk0QsU4EGSeXukt1p/9gKSvM3R+1IlsvArD5SWM7Z3WW+ThDBZ5GikNJzKgd0GC8bnHHsXf+syv41eefByzg8voVg8CSJEWuh6kkVeOAhlo+i7dlAKgp3SSSlKsFsT5aur5DNxto+l7HDqwilcePoU33X4Obzx7B95421ncdeQ4jh44mPJk+pts0EjppeFiIlUoMWYRfKiSVhhs3TAYN1CG+kVou3qFFSVRGc9fBJQMgCtgH8DW/c2FD/DTGV0xguXQmuVxy28Yo4ZA6ypp5JJPVodSR25IkUqJ9aVjdx3Kdakx8Q4IbKGSqqLwV0G4dzxpNGrqmbHZzfD41ct46MpFPHD+RXz5xkV89dJl3NzZRMdzNCtLaKZLaVoFlLeAZUAjqQgK9r32soBr0c6wukUVtRBOz1lJX7wOhdZ4Jr4ARRPlh160Xg5FeYvnCSRJy+63YeKBsVITRHL6E7JsGNgKQFODdJvO1g7ee9sr8N++/v1466mz6ZIBFjqyU1daQfUDIoB6O0gjjNxFm0O7Ah647pO/ZXRJrv3Vx9lqIOpPTcNK0B7gih/p2qsx+2i1bPvRo0mbJjsReaGUu/UndWe+D7kcRhZvfj6b4fTp0zhwYDUK/kAJynFxR7djRjWrj0ocI5RxZfqQ1bxJ7/3IopGChF1p88bepxevDJRONpF9VADj0489jL/wGx/Hbz/9LPq1FWB5BdTNQbO06rRnBjeiC6yLoUB5Ww0nsGzAsDWuDfomHXDRzxdpKwj3WG4nOL12CK89cwavPnkKbzt3B15/+izuOXoSS+0EbdOqmDCngzXKwwjkr3iXHmjNxpG+lFWr7Dphr2H/GIVJhBX5n5TcOsFHAbXiI4Z7Z6sG8mNKvJtyk2/2rm2zCiOf5H2Idl0YRMUwnRY1XlnhL7gMFGVZF6TIZzbQlEwy0tHKcHrubwaw4AWe27iJz51/AZ+/dB4PXjyPJ29ewwvXr2PO8wTKy8toJhOdg0q2I9dLKE4w8n+NLgQ3J7q4lL2CNLfpZEY+F222sAdBQEyuONirtK81gxK4OEfYIl4BAf1OzngXcqZHN/oOVSeHgu8QLwnQEpRPnHlK2VnWldhNmxbjbW7gVUeO4y+95YP49rP3YgkTzPsFegZaatA2FPYt24rqghV+gaCL3IKdFCfCtSs4GFKe/Ob4E4HQlS/ODQrZJScRyuNxWz32+Mi2nMstbaBmUCI4nPZWxTJ516dGbG5u4ubNWzoV1LRp10VLbn1FtrNie4iavPWHZYFG3m/LCWyPHT2KI0eORP45ikohZN/JFQNWGzIbMm44tFDzVKqXBHt0JgoeNLt/ta7Bm9xBuQzZ0iDem67qzVq0YMb/9fBD+O8/8+t48Kkn0a9MgeUDoL4HLebakR0RejnZBZSVzAEeI91vmwVWFkyIFBEzsLMA5h2YF2hawvK0xZkjR3HnkRN49dkzeOPJU3jr7XfizqMncGT5AFoyH9cEKP3jI/uk86JUeYjU8cf3C5WfiQbpBl2ShzQ9Xoo9ikIvZY+V4xIV72rO0uCpyAvVhDT8vgtBQ0IQKfQjA/YDFS9SZDhIFosvaZLPBF1g7bdgWJ70okc6tnRjMcOj167g4euX8dCli3hm4zqeuXYVz6zfws2tHXQNwC2hmbagpaXkGDKl+1/lpDEpvzEizFY5fga2caBnyFHnLHkOqrc39kQNlmsdYy9InRGQkww6Ky3tCKAhVKcyJbk3M2W7g18opJAfKncJsiOWB84AEPqW0jnC1IE3NnB6+Rj+wuvfhz9y3xtwqJnq7WZZgey+2YGN9B9HlLryROCNOjJmr0OVzgkWXlPR9Oh4D8FWad7l2efgqdEZPsS6fILdFkbJbzdu3MDW1hYmkwngAFaGkcO9tkC+15aKfbacFqAAwHw2x+rqKk6fPjWsUIU6OJBOMWK4PzZHup/VxS91njakidQF1amW7wxF8L1dpC3zD13H+aiuFIn+8lcewl/7zK/jgaceBS8voZ2sokWHnjssmhZd2+rFzUpFRlsBQQVWhl6M3fQ9Gs6nDjVpuww3LfqG0qXZXQegQ9N3mLYtDtES7lk7hnvWjuENt5/FfcdO4PVnzuDk2mEcOXgwXJwAsq0ashJdI9mMiCIs4vWL0xGx0guvM3Rc/2zemjOXXMhJAMKynNKgYg+jLM2ty2FttePu5cTq9lotyU4vZI5Ph3MJ+TD5EqhZ+4aBfNhIdnTyfy1JRGPpFn2HmztbeObaVTx98wa+fv0qHl2/gcevXcGT6zdwaWcLC6R7YNASqG3RLuUDW4jCcYhpXtJ5Cc5ma4vI/818cJ/1CEq2QpKjbIuyvN2g2lwZ0rxvrDh/CQ4GKbilnwRUoy1i99lGH3Ijcn7hp1Yj25uy/MlCu9RexwSNHmUxkxbuHAnpbQJxA6IucaZp0BOh39nAGlr8kfveiR95/Ttw1+oRdNxhlhcFttRg0jRoA9C5kaisO8LbPaU6mEDPe+uL3aLWUIxvYnHW8MAB9VXt4mVrkSFqhZt9qOu1b5zfQUNO3mLKQmdHcODylStYzOd2fgE1YREmIIArFxLk2mzrT45sWa7aW2DSTnD77bcNiBpjSmxefHYDx+o4eyXNcHgNEMHXNHvUNQDbEVEci8J1QYlEgXqHbTqE+5e/+iD+zid/DZ9/8gn0qxPQyiq4mWi65LU2Gr36q7fID/1mACY3TEPJbUrGuW3AkwTg1DR6Zi51HWjRAbMulbGYo5kQVmkJLz9yHHccPIL7Th7DvUdO4DW3n8Wpg4dx8vBhLE+nmIjABEfKFkAFjpD3ps25itzkYKAzI6Hebtmf/l/y70KJhYG29wPAjb5WpN1XsstTkw7zK4YmSD+V7Zaq2fgqLgOTnEGcvWBldgZAASkk6e24x+ZshvX5Dp66cgUPX72Ip2/cwMXZNp65fhWP37qOC5sbmHOX5Ktt0p7lpXRzlJxoJQTI2dgGArYYTIDIQc+ebCsXt3oXigUgC+eMhokV+wzklLVDGsiBrbAuUlW8jCBQaYXHFEtN5U82DGlAzqEYBX8P+pzoJQBoKdnd2SaWugbfc9fr8WNvejdef/Q2yDoS74w12dEacxL3M4JY+KuOrnrnhSHoPR8KvHsJGVPuMdvLtaH7/ZWj2B8Khslj8d4KKX5ixsWLF9H3jMlELubIxzW2doKU3mkrQQpR3GfLObr1FxLcfvvt1UVSJSPEgEWfwQ0fBbdnd8bsJ/q1NNFbGl91WyufTUlRygarM655i7GLnnss+j5t0GbWObGee/zKww/hr37mE/jCE4+CV5bQTg4AbZP2oVEG3MZ5ZwDSWafezXQeMwj5ssdEb5MNcV5gRXk1qey1tavi0lFufV70xosFCD1o0YFAmFBaDX1yuoZ7TpzAfbedwR0H13D3oSO4//QZnFhdw7HVVbQjG88586GTE8jY7g2VKYGw6ElsHtlQuucxxX+qbl4NbNOrHI0V3i58eucghCRiuCrt82VEcDVQVWejdDpLQ5iNsuzJK+uR+a1532GzW+Dixjpe3NrAY9eu4bn1dVzaWscT16/iiauXca3bxvrODjr06NGnK/WoQTO1+dUElrltRHr5OowNkDiTAOjWHAU3Aym1nzo6Y05B0EHfz+G99EEq10oxqxHOJR6zA1xPYw0qTskq+GzzhFCDm0lyMgvVSx2N8lGx0sFutCq3xy6rTVsQ3dyztTetHmYm8GwLbdfjm257Bf7im9+H95y5E8SEru/y7WJ2IpesNpa2eJaYuaDwPrCAgtsEsZ9m41y5QT/s69gIDg10yC3L8nQ42asC/j76PQxvu7we46lQMFvA6ygrEdgUMZbMDDSExXyBixcv5VHNNlwYn67Xi/fZAvlgEYIDW85X7GXA5b7HYjHHiRMnsbZ2cMiR38OzlwdWe1dfmVyUO1pXZV53pJBBveGTVyZWa5JO4nM3CuV6xZj26PGxh7+Cv/5bv4kvPP4oummLfvVAOjmp7zUaBdKcLuu+LIu8OP9VGtXTFLBN6qsCJguxJFJhVgUzQ2SgniLoHrzIxwkuuhTpND3a6RQHlg7grrXDOHfwMM4cPoTTBw7i3MHDeNmxEzh36AiOrx7E2vIKliYTTJpWAVSVigvDJ+zMws+Z/qIzCj2PfVOba+XMe+/8Wfrxh2qJXH9aO+Qnr/DuU7AiEt+Y8ZHVvpzbvdN1WJ/v4NLmBl7YuIUnr1/D8zdv4OrWBi5s3sIL6zfxwvYGrm5tY953iU9NA24ING3TJRJNo3Igw4ckx/khW19ZhEK2+Ibh5F1QZtB4kQ8PtjTENtjvkKIUbDk4kP7fwEMqnXREEJXfB7ZAQCw6ZuYkDx+NJj14jDho3twaMPvMlbZoicK/CAo9IY1GEaPb2cKka/D+M6/AD7/u7fjm21+GlhrdQ+55IJeqU1FT3frt/Qy2PblWlCv2a/y0hYGoMnrk9aBsX9Z+pgat8GEN6bV5HWHRlQNawLLahIY9pcT6Z2NjA9ev3whDyBLR+vtsCRSm30AEunrVX0SQV+B2HQDGbDbH2toaTp48MTrUS1kKBdrMrNe9k5on5D+X9Yx7NoGIQf3aH5W69lo1HdJQkSgImXV42uKQtg1R1sq2SR7NjBm//tij+Hu//Rl84tGHMCNGs3QAbcOgbgEw0v7b6QTcyImyJt1U0iBCREA67jB60CT0s3yPn2W4mnKbZYl6Kjtdwde3hL6ZJCPfLzIYL5KTAKChFMkvty0ON0s4Ol3G0ZVVHFk5iDOHDuH2Q0dx+uBBrE2nOLW6glMHD+P0gUNYaSdYmrSYNi1WJlPjeRghGZqU0N2FcVcwEwD35WmZ7glzhMbSgVPgf/evVdrs3bzvsd3NsT7fwcZsGxvzOW7N57i4tYln1m/i+Vs3cX1nC7dmO7ixs43zm+t4YWcd61tbCUx71uFXalqgaROoUo5W+3RpO/t2Z5kTw+zFhMk7Z43SbItS2NqXnRTVHzHEOZmzWWrA/PAbQaI5L5fs+G4OYDSRAtTyO+nR1t4hkLq0NO/AsesRr79uURI7wLMkOYoOeyvNSHubXI7eCQ1JgdwCPQHtQkosoifdKzvpe7z/tlfiz73xPfjQmbsxzeeN9+yGpVG739V45+0CFbbI0o/YW9gT+oTMSSTlLeX6/GFG0k6TpTDnWQHVkh5T4xHbXNAcyjHPZzS9L3tfNt/TLDLu6CICrly5iu3tHUzydEzjItk2T880IL1Ni3QEi0DXrl3lvk/H7vmbf5gZ3aLDdDrF2bNnIoWVZwAInjH76Px9PZXhowHohvF9qncoLM2edHhLk3OPPf1AUNJcXJ+LWHCPLz7zNP7B5z+N//DwQ9judtKWoXaqBpNlEVRrhjUKd3zH3ljpe+cQsKRi++zS2Mpi59E1EgWl84rzLrFsg/PiHgVwBuUpiGS08zCkLNoGo2kJTTPF0qTFhAiTKXBosoR7j5zE2ZVDODyZYqlpsbo0xdrSCg4tr2ClmWB5OsHKZIIDkylW839LbYOV6RRLkykmbZuG7rNHOSFCC8pboSj3SZ+doF4BigFwPqKz6zt0fY9F12PWL3B9exM35jPM+yQni0WPBXfYni+w2c1xa7aDazvbuLGzhY3FPIFqN8fF7S1cWWxhY76NBffoFgkIu26BriFwjzR3igSmTAC1dlg592JebUERg/WkrjR332Tjbh6AHlzpLabIvIx+VPXSgWn5k9lPdX5VwqgQSn3HMXOwbVzmiHQMyq7Q41oRARvF26Iudrwo6/CRtyrBPgCpoNuvmiZwPpIyX95OALeJrsVsG8t9gw/deT/+zP1vxTvP3oVlatEg0dFkMDbsH7qdOpcuNFZY5nujnPqqPaFHQ+aRMvWdc4bCEzYQqe+WyNkdTF9ylJsyGf0ub1zhvI+FYpEylC3mvseFixfBPetFK0QGuE3Wt0YiW7L/QABdu3qV0yrkeD6y7L3tux63334W0+nUFG+v6BTe66mD7ejk/qCJI6yo1FsrzyWKXuke6WNnl2ondPr2WlJfplxen05UIh2/f+TiC/ipBz6Hf/6lL2Nr8yba6RTN6jJAaUi5byfgNg8Qc++AE06x80dZ9ee9MVFK9g5HFLlkZOxuS81G+msSFlF+jZYNcCl78po/L9hC/o8bAijNVdseQk5XzM078HyRr5rrIOihvoMOw6QbYZLjyKCW9PByysM2CWyb9F9eqSkOzoJ7dHKecv6b9iPn1eVAmkIBY97N8t2cjTlamdF2Ew2lYDG3DZMJqG0TeArNwmM2Y6z8k67JEWWv/Wp6E6MEc2ZVr5zQeQn2Pq8NFWedzVaPnIM22Ecq9ZBbC0E+hrFo30ecrvhIkY9CnRrVtE6G29RG5OhRQMvLux7Hqg32867SnPw+AKxnECsfKUtxwltnW7T/oHX4VkiPpEXHafqNOH9u0lnqi9k2lhvGt73s1fizr34b3nHqLrRodCRR9meWCxPN2/beRt12jUWtXlDG7Op+RhKt5AK8ncEu90LTMMmuNL8UMKRd6h2Wn0Y3qvZfPRuMLg6TZzab4dLFS6mvFGzl7HgbSibk06Mc6BMR6Pq1a9xxj76ToeROF0kx95gvOpw+eRIHDx7cMyqlQijKvhobig7DQv79oHz/pVb/PjrMuVljQxFa16CO4ANGQr0Sux8YYlSRI5W8ejkDxIX1G/g3X/4S/n+/81t46vIL6Fem4LXD6Js2aXrXZXwot4e4OlwIbGszvNLEvZxlk2yxwLAN4Zu5pzrEFNYX+Oihcf9lzy4tChMBFICm3IbcF8wD02DFemNIVZ77hWHWyyniNgckvy9pl2HXMLQEHaLjsl4FJiqUHPHRegVspYVe/qz9RfOH4FmWPRBTmSeK/HExcUlcUY/84jVK1g+4EosPAz32Q7yRlDoFNJYkDj97lkU63KMA6pMQbOonA7UbYrbRMlLwlDzmQJlnlNI0qZbsxPVEWc/n4M11HJwcwn/yyjfjj7/qDXjDsbMmmWLjKZWsC+Yq9qic0RKHpjqaKPrsnbox3dc8xaKrMDpYoQdDWfT5Ah0Ygm0YXqZKvxZlDAKi8v1o9D5kaOJNtA76XrKEvFbGrVu3cOP6TbR5FXKbQbZp3RytniRF2rc6d3v9+vXBcY193+t5m4v5AgcOHMSpUyfhJMSURxdARAO1Hw8sPCPeScXm1PNUyt+PpxT2QFLtfZ1mL1wiUlymF93Oj0S5XTa6kzZFYQBh1i3wSw9/FX/v85/Bbz//JGYTgNYOgLgBOgYv+hTxNq4eibb8pQvi7PuhlXDHq4FNCRqS3vYGZr4U/BBA9EZS+GdHz8FAKH9mQwBAIw7WvZ0WOQ9lSrsgl2llk9YHNIUBEp70Duign3W7C1u50q9BdgR8MhCHCNf9J5FZIjOaZjNgkTRAWC3zpqUT4IyWL3M3b97bMjeClPxMdsltCFUXFHpR97oUcdd9SIYu6IvIlxg2FTHbQsbO2fLbgaKqWaVhXytz+H2gd5l2ze1HKPIHErq1PQ4CFPUoH9fKUVVymziDWkNWVtclkD21cgw/cP/b8Ede8Vrcf/gkAOjtYsjg2pLb8y4UDNpon0tQGhvd87K111xl6auNj/oZbeQz+v5luC1Ccb1DzRZrOY426a8gBhWnanxE0hJGm1VWPCzfrz8q6WQAFy5cxHw+t5OjZPi4acIKZB1GdodcgJHAlrnXYWSWIWW2SwmapsHtZ29DK5eF156y14wrnguDBnimRGEfL37XvDn/bh1c7aYR+k3JafB+WLJUL8bRlY3UjT1745AMkzjQjLR/98HnnsI//sJv499+7cu4sb2B/sABYLIMblu7viobZoDRo1HQTRLPsZFsPJF66pzxn/2GKKeALmUJtqGDMgZF8IkRtrNp6W+I6pzx9lqevUXIiVyVaNRbBXVNPNAKwLrPZpSdsjklj22Fq1vqEv5SpKUQOHXC2fHSt5frvI6FuUKVHuktKjMV1tTqUlwmqbcYmq3ps9ajpbj80gRpiyBoRYrIMdKdLzjuixcCrSjJAx4YqTIVUjIBmo/hmRA+OieHRaShkRH3aX0FNWDu0M820c4XeM3RO/BfvuZt+O6X3YeTS2spv5MpEynbxuO1bUCjtt3Rpw10f6gSAfoKg7xEJUwyyJUs/p3r8bFOKuslo7q24jclc3LvZVgT1g0zO/p8YOvzlguc9Pcq+XkabrAZNz1d1+HFF8+nLVhu9THJBQRNgzYsisrTX0A9smV2q5J9dLtY4MzpUzhw4EARsXsvPAKcsBKwztnVi/LN3k9njpQTTG4RXST6SioMOqwFNNJR+TuZCFmaIdiKsRf7ZitvTRDkcAx/29A0L/x55tpF/MwXv4R/8ciD+PqF81gsNcDKajqYoGNQvsqvp9Z52nbvq5lDMyjexrFru0cUW60KjURKABwAivLG1eP5MADD3BOkJkzfyT/BxHi8bcIXjxhafjjbXrOzleqH2VD7POJ9wVgV2giEfjdyKmWQ1a+DaoMIxPqEwTo8bquJLa2PVAHBOL+wya+1iMOhKsPeA2hkjrdol+Smkj0RcHWYExR0R2/uAWC3AMECT1k9rGJpjm4ZcalZ9sPCvmXOufQOgu966PRAZpq219oq7SWfJR8u3S3m6GbbWOUJvunsffihN3wD3n/mDiw3Ez2fXFajhrUPLnKzoW6xpQ6egrF0/Je8Xu8q9koarXk8DwMNvp6YplbmviPqagVja2dccm+3He+9yO2VN6Wv82Qgz66gcshdpj431tdx5co1TOVuarnVhyyqtS1AjdYT/rt+/TrLYRYebLuus+h2scDaoTWcPHEC9Ycjo4UpAy84tEJaPmjcYBhhl2e39LuVYYbeyPe2ozYEMTB0gQ5XpzNS5bxwOczBuVwWQy9pGXov4ozn+K3Hn8K/eOhB/PuvfxU35xvopxPQ8lKie5FuHBLTKRd+63BnYTAKBMqGbhdmjTbQffYf5b1UUfIs4KLP743mkCBy5cbvIxpZjDDU5ugjuPqP0W2UcqKH7oddCQOBK/kTfzCCeeQnT8bg5zoY6tAou2F6AXdBNQXaLNOhDw2ACgwffKHQX8ZfKzPqkDoooRgKIAw2UNYmRrILSlyHk28ZDGhq/eKysX+f/6T/nJ4QpUNDmLGYb6NZLHDXgdP4vntfhz9476tw/6Hj2aHpoY61jMIUqhOAwTl4XBLijYGAcFA3326To7EVv2Wp1WdkemLP9ToCkH50ap9GvGp/nHxE1Wb9rG+Dk2J5axdA7EbbaHJO99dub21jMk1Hm8bVyD7S9adHFYB74/o1ZmZ0vdzdmfbZyjnJvXpowB3nblfUrvElGKlRUNq908o0Pu1+Vg6XK+tKARsYf+8WeS0svTSfZA+a9xOZCxDrYoacR89ezktUGwCTNnUqADx/4zr+z4e+jJ958AE8eOUF7PQ9mulydrbzXl9CutyeKC1IclbOR7kaoZdzYJklcltKHRfNarJYyQA+MMPv682aZb6WM5mVfhTSNVqqRdTkld2BgAMjdWb0u/0eoq9yngrizDlQybwOc2zCIJG50onwYEexeKVByXZgIXe0armShrOYFjyX/uDIK5ujZH98b+5n40t6zYO+YCej/r20Po7yOpQcWDaWhjl+cgGsbPTrCIDjqXP8kuhJOVafzgmLY5nd2ppT5my14io4rXgmENA2YO7R72xjignefupO/OB9b8Z33nMfjkyWQEhnUi9yJKt3AsMV7NpRirCyjuvcSr08riOpeK5+fqnpa3Zb3yiO7t+Ge/BL74eQNpCOkcgzjjCy9pvJACPe6ORKd0Mx+7Hnko6IsFgs8MKLL+qdtfG/CLAytCwAC8Ai3RvXr2ewlYPoE9h2vWz/SY1aLOY4feoUDh44UCWsBDVrcLFqzLgQ0gyYUGm4T1ulYZdyIp46Qy7iTGXHutY4IfMgo6rg0g4MrSuvDlZRvbQPXC1ElPdb2nrSnX6BB556Ej/z5S/i33/tEVxcvwpemoCXVtKZyT2nc5IBAGkVMDfuTGY1ROYRx6jHWZ/gerr3WdJH21xqWijBy4IvE/AjFcHIVsHSDRf6Gshl02aaQ2C6Z7I5Ln1evmuSTsNm6ivXt+V7FSFxcEqex79UsMmZy92NpMh2MHpOJ6XcsoLKY2BRJqoQHKFEv+tQtMur3UFC2y69MaCPtLpYmyyk8zS6T9oO0zZ2vCIGeN4BizlOLx/GR17+Gvyn99yPt5w6g5UmRTh6oYQrPdzEw4NaI+VjQQTXv3gwiuN5fq1BXR72eljyevrG0rkEfgHfoC3Mgeb4U1HXYAQsTrGIzu5OU+muDJ/kOvN4cpGlDLa3bt3C1atXMZ1OAZBbIOXusVXQpRwYWaSr/XXjxo3BnG0C3HQ2TQJhoFt0WFlZxpkzp5WI2AAEo+h9EDuJpJ5eOnk/HaL5X0JU7NMnz95HXOY7xoB3b08x1OtbV0pjJW+oS/7JCq5Dea5eWcm86NKhEW2e1yUA5zdv4P/62lfwzx/+Mj7z+FOYLWZopuk2lxYN0Cfw7tpJOqiCKHiAYuxFqCn+Y2BVcxZoOJSammCeZ94jAbIf6/wkx5iaLGgVDmydAmqfFqChPoW/wzO/jEPG0XsOZ/yaJwAZsgsrWnOZtm9PDAUcryuRuTSK7aVFrQjGzw9NlXNW4YYVPfi+JnvisO0Btma5o96G9o74zxLBhwgXiHfVktbvT0zyS4m8g+3xQ0/acv5fnPUxsDSeWbmm9fL0WfbyYTJ9D57toO17vPbkOfzx+9+C77nj5bh95QiY03WFYgPTfu8M7N6GcNxoRb6LjUrljeWRj/X9ycGesG+HK93dE+vrfKmjirvaOh6mGYucx569InDFBa03/w6EOefRVcf+CWpXGl/5WLp/6Tl/4QJmOzNMphM01IIIFtmGqDatH/HDyHLtHjWUwNZA1hZHyeeO+7xzIl1McMe5c5hMWqV+6ESZwNW8nL08rrKDx4aUtTyM89dliPJay0BRiEL9VHSQZBgprByKNKUZUb6aN1kILsPdr4uof0ykC60eu3IBv/T1r+Jff/l38eiF57HT7aA7sAIsHQRPpumqtq7PRzYSuJE53mAtiwoi0BnuOO/dsEj/jOlb4GS+6zGjl6ubBv2mbpFznKTipIAZcEpaRFykIcFpcO2r9X9BedXujYp06TiMyT/FT+JZg3W01YbHi0ct0C564klw7uUwfa14YZgz4E4E3CSDRrwBq327FBTH7YCfQ1c6A2BHvSHYnK+ryb4x8hq6aJAZAvINWmL03IEX28B8gaOrx/DhO16JP/qqN+Jdp85hrZmq/vlq0kInndktaqeSlLKh7k8Jw2zN1uKG9ifAaSHXPk85sjhwSkPlw74pLV057DystqzXCvFRZS1o2+3xdtQDcXA4GENeeZSGOG+78M09s9kML774Itp2Erb4+JXICrqUbZYcaJHto646v3HjBgNpu0+MbPN8bX4nFZ84dhxHjh7ZHQSLpzYnQMX7MQ9p9NnHnEMoZ2SY0A+JvZR5D/NbreOreVHLG+WBnRIEyDOUgL/iyqf3fURNOp+zpQYdejz4wtP4+Ye+ip978hF8/eIFzNGBlpbQTiZo8u3fHffoqUGfwS0yR1YHk3mSYlDzXxsq5rioJudzRGvrvMH0w3xc8pko1+WMBDOi5+sMuebVX2NEJ+T4vwXP4wp5Wysq3618R6f+bv9a+TRMQzEZCHZgPUPN0dCpjGlCaCktGWm7lyW4CFz7QsHcDGGmPqX1RlWqJRRz+k0kA7bQKgzbZ7CrRdKB/3Z0mWQepLftGn6ExTGXASKZpza+MOVLRPoF2p0dHJgu40233YXve9nr8d0veyXOLR1CA8o3e1n07YeIaUhOeIay4bvHvCgFMW1ULHA/0WMJzOaD1e0SO9mp2pxcTjVvsI1wGDdit2vMGRKNUvZKekbX44ykDyMLTuF3nzBy5RPh6tWruHnjJibTabwkntzq47BIyvb6y66JRi6Pv3nzJgeQ7ePtP/5GoEW3QNM0uPOOc1n59u+V7Kdhyph9gO1gHtg/pbdFcdhNX5dl+rJrHts+O6sGtpTpsPx+XrLWhgjUNWeBc16JFhT0GXZyE4BZ3+Grzz2DX33s6/i3X/sqvnb5AmaLGXipBS8vo58uAR1cxJt50SAfsUjgvJc3zoGZ8S+ZFexFOZyov7GCKjv+eA/UWW7r6yAfZliVFG8FgxEuDFrxWH/Ii+IND5uqw6oVZ2hAf1mvFutA3Fnl3fXLeQ1GcAaxol2+v8o/6qSU0p3fCiYEORZjV3or0g4nFGFKpESRSqvcsLalKyR/0GwHGpJd9CCDra5VYEY/3wYWcxyYHsTbTt6J33fPq/Dec3fgtcfO6pGJYLZ5VyKNainz86XaPu/UA3B972XrpUV6sbBoPwfzoUAB7HU7O+Y4jFddcYQGSYanRpW1pnqLmnks/VCN6lyLb8vyx/Olp+8ZL7zwAvq+R9u27njGJBdyBnsJwiBZFJVsjzhmCrYsK5HDflsD3C4PLe/MZjh75jasrR3ck1ht8n4i3pH0o15LGKcf9/A0SazYpfemv563tiIupTcFDJsdnOENToRbmBUMBA3lKhpAX+9QsTxt6dCMtIK8R+rXJm+4bogw7xf4+vPP4Vcf/xp+8elH8bnnnsdGNwPRBO3SUhoKyfKgJ1ZRo5cSgBzRJTVsUWgwhhkA5NA7i9KzUyNOiANyi14doAMgjWJk7pTNuFptxkwRdMrGzJcpfSiYANLyvTFiV77+GjqsNBVFb5aypFjkeVX2qQdsZZUyfDhnCzsvWHnuywQEjMs6MnooWNlqa/fdtchxEZpRnNPg7Qh/KVx+IQxXf1nrM3AW1PS23C9mVJ2NY9r5ykgOV62Be/TdHDzfwVJzAG85eQ4fveeV+I6X3YeXHT6OpaYFc15RnB3/Np+vrYusgHg4xT7mNv3z/5QNDHO5KPqwXsEYQfuqq5Ym1OTNcPAlggEoqlXJKUoTHRuZjw2OmksTbKzT35DTE+okMXi4VqcsjLp8+Qqm02k+htHd7NM0FtHmQyv8nC1g87Vqg27euMGcK/CAKxFtr6uS0+fFYo6VlRWcPXs269j4lpzyGYzlFyzct09XDK/p6yLZnlTtRndNeEN/jeete3EjvvCA6GHJnsd++LosguW/Ym4G7p0OGwLowHj6yiX8+pOP4+e/8jA+9/RTuLWzniLelVVgeZIEOV3cq/mTsUwRby8HTAzcBFe/i2x9Kh0KBRVRs/tbFubAWECQRuRJ+pBqkRHV+sgoQ/ZKA4BWivEu0JjLZIbB1ymHPvjXheHxoyvezkDkj1yw70AKvr9l+L/WXtum5MnwC5B8k0f1U+vwvR/bMczPQ96ZBXSuHOAvYw+0sGVjrUecmR48nwGLDivtMt547E585GX34oPn7sbrT57BhNrs79i5x0zOGYG/qH24DoVjx9nQYeEISVmlgySN0MV+Y0+mwddLjp8e/AfrXdIP1fRWfJGnBPZdHAmqfNvPEG2oW/1NLqWm+DD4MpQryhKtXtyAyPCI/5f6PrYCAF54/kXMFwu0kzYDa4xiw2fKw8dkK5BlTl/90Vs5su3yvGyIbDnN3TIQjnOcz+e48447sLKyXBcUcg3epcWj3mGIUlBNUxOCUjj+76yIKw8vqJkRuDdh/XXtNClndGxhT9yr+XuhOVCyi7fau/9ke1E6Yixf7QXgxRs38KsPP4JfePwRfPqZp3FlvoGOAVpaQjNpQS3p+cUMoG8b9E0bVtsaD2BzpD7KQBSPMNTqwLZc9Qp2w7UonDxGjGRki5RiPJsxFhkhGnamWnBFdCWUhVZG8Jv9sLR2C7liOFZj7WJr99ACAmCUjmxcemQ8N2oc2Lr4gJTP6Zvua01W3C1uKwFZotW4rUSNt4yCuPTZTzEjSlqK/hz4Jp9Y9KLiexCHqAkAqOd841SqI8l0j36+ALoey0sreP2Jc/iWu16B77n7Prz+yHEsNRMAOYLterCLYOMZxUJPaWc8EDlaStmGxf7a3pcYwYY0ruYxa/pSbYLP91JtJiptF92kQRpvGwjllIDmcBH76Bqc4PyN2W2nA7tE5l6eB2pLhK2tLbz44ouYTKZ6q08E2grwunp0GFnvCifQ+q1bLBEskME2DxunQy7y1p++00Mv5vM5Dh86lC8nGD7JSESGDFu591Odd6h4yXsVWXqDe+UZm7MdOAFqPCi832VxZPXxxqjKt0DDrgWlPwMPN0mpnMs8GIJ3IJdhCdc21/Hgs0/jE088gY8/9zQevnIRs8VOujpveQqeLNmdu3mut8kOm9yFm9Zg6XIfM8gFzeR/U7D1363damxMR+FU1t4nQqIBKEFlWHwFcAbk7q+fXLleHjQ/fLtrtYRB7/BbaTPdwIGCRDD1ZTXk+FjSk/NG+mxrWNBBqc8VJGukzIhao9OfCsiKFR3wNC9QS2PDbpoh/aW+B88W6OczUMdYWz2Mbzh1F77znnvx3tvuwCuOncRK06a5V7lnGbIGwThNmad1VR0HW6JhmmHfvASDt9fDxcK5WhITgEzPONjuRdtYZFufrx9/dp2vVb12Cg4eMhIj8GFe+zDVwIk1mR5ru7y/cOEitre3MZlM3IIou4BAIlcBWgC6OCrVIWkAWThIt27dYgDDfba93wbEGuX2zOA8zHznHXdgMpmgNrGfPDw/HOQNSE7D3it3Da40vkzjlT6kr7IQYahxPyvuBnUVadK+3EpvOp89vREaZW1rbs8e0e+AnhEF4liZ/dH7SjMVFYCQLUUMO7mq7znNTbTponciwlY/x2NXL+KTzz2FX33iCXzp4iU8d/UaFv0MPGnQTCdoqUGTCgIj3xHrD9LIAlgDW1UCiOGOK5/9o7qV/1GjGYDG88oYaFFlsWgq55VhIE+bwo5f6ONBmqXcuAikHGZU66zyTK78ikyy5PGv64bT+tUzRHHSfcj1BS+f3BCak182MtLrxFzfJSLPYYGX52Ecmyu0o9w/mcq3wQqd4U8Gq0mnofVg9PM5eD7DtCHcdeg43nHubnzg7MvwnjN34a7VQ1imdGFKxz0WfQdwMpCtnOzjeCgsHqywHeWzURzTR0uHosyxZ3zlrVUT14nUadtfmXvburFyano7cEOcctbtGyqZKnVV+F/ixLitLnTOCrLX3m4XNBARtre38eKL5xVoyyFjAdHBTT/ihBZRrg4pr6+vc4p63D5bZrA7qlGGmQV4welEqaNHjuDY8WMDD4jcv6PPiHcxNq8bnjC0Voj+Ll5fpG+Ydj8rluHrq6Qf8zwHUXpIM/TZ4jwtdN1InM2q05kMJDuBr8wDuzIYHnjl8Ak3ICMglevf7js8cv55fPLZp/CJpx7HFy8+i8vXr6Hv5+C2BS0vA9NlYDJJ0735QvgGlOZ+KR8jSWTzZDK061rj1UzdtVInCzYGMA6J6t6yj3LlQ0FG+Cwg6kEcu3+MjwNb6ScjhfS3UTpL0gQQfWfC0egcEJKtXN5QloaQnQMAn7doGJVLC+NoRNRJ/8d1kAA4s0ZkSX/SqAgTgL5HO9sG+jlaAg6tHMJrTt6B95+9B9987mW478hxHJ2uuHvg3d5k2KiKGD8CMMJJ1xrvOBXyUXRsajLXTEH1Gdi3YoqlmmdY7f7T7KP8sef3EpX/3lZTm+O2V3l70RTBFohf99ee8xcuYGd7B5NJC8pztXL/uJyHXIItUdoCBEJ459tAG+vr3Pe9Glzd+pMXRXFv+zh1tWuet+v7HnfccTvadlIdclBPuTh4wEd7VYZ5L0TLKhhdAK6mHTNKsQJN7/OGckbKH0vj6fRD3b6FL3UFo8uJ2JKae1hEa+xoHSCQ0cAZyUksJDng5XzWcp+cLaJ0B+c0D6dI2Ze3N/HQC8/jk88/jU8+/QQeuXIeV25ex5x6cNOiX5mioaW0MTxbewbQN43eVqR9J7iobQuz4WrkI0sMPdgZ2wEXB++cMmjxHnyi3CpJoV5BM5snHhLoEK/qbcdFb2MjLz4yHn00VPPlFOvmBQy9tyKfWX6X9sYRnDBHJ94NeXcIri9cnSWZMrzPaZG7TF8wevBiBl4sQD1jdWkFrzp6Gm85fhu+8a6X4+23ncM9K0fRUpNSc7oGtMug0lA5B2ujOqUNGVPBOHpiiTRgL/prXyt4S+Ws1VsnZ9Qe1uyPUTWkJ6TZR8QbhqQLk1O1QPuItP0zSoPKXqpY5XW0HEfgSDQe9grUhsez/Ozs7OCFF15Mt/s0BII//9idHkVyCQHZftoMwjpsLPtrRS021tdZQFYI6dzeWj+kLFtK5GaLxWKOtbVDOHnyeKa1ZuFKzlT5tecz4lgaoyBGsUaDeXejQO7KGasbLtoce2qwqDkqhrZcaZyMW0k+R4Gq0F/SG7YiVbk29CXDcJiLdFMAwjkqyB6bGy72NTAYW90Mjzz/LD717JP4jaeexldvXsELt26h6xZpiGXSgpemwNI0bysicJejnL5PC1/U1nOeA84ElswJfIkmYCgzBFE78nk90JLGnNCIPsB9BljNZPOZvixPRzEaPHyKeaewvsCH2WRpg+wGB6UmF36NbfpBeRKEtTJu4ptaMYgReoVG3ziCOHAEytvHkmSh78FdD17sgPsODRhrS2t41ZGTeOvJc3jPHXfj1cdP4t5Dx7GUh4DFsUkgnWun+j5Y4Z+xjZ3fM1ycqG0rmFMOfjAKfeS4gCw8uzjV4Zf9jOjt8ngb5ekonf2X4uTvJ/3uI3YG2PtZnFV9yGLVfS0yC44thv3LTnZFnlyaixcvYntrB+0kbunxQ8UW0RoQA/GYRo104bBHwTYDqF4gX65OFkDWzwwwYz5f4Ny5s1haWho03DMVcD6uCm8dLgIAjHiKgZ/78BT3WpXn6RwAZsXzq/WjSzTIW4J5rS2+fPWIuExFZiz9UC/qbTTDIsXU6fGNsbmsWKfPx0BY3dz1veJQ27a6R5HB2FzM8MyVK/j8C8/gM888i69fv4qvXLuEW4ut5NhNJkDTgpYmaEBoe07bjSgv6iLb74tcriqgO13Kg9TQvzXgHO1f8jxkdwCWzdlael+aUqBlRok0A6AAyjGVzf0O+9H3r0VdLm8O3XQkKZcf96V6ByYOVIepVbNsof6hT2MjVgGzgkjleppcXL9Av+jA/Rzc91huJjizehQvP3oC966dwAfveRneduY23Ll6CFNqVMa6vlN7JDeqSPQaHRIbzg2r031bCx2UOfhCIuzTWCQ8oteikwCC47+viHeEzt/rSuPd8u7rGXO09kMb6napRps6gDxMH/SxesFvIcuhL+oE+dP4RBeJgJ2dHbz44oU8fJzsryyKKudm5TNEDimCrqc9DCMzALvTNoKuH0LWYeQ8zMwMLOYLHDiwitOnT9UZO4ZKQSmjyfJP0G+iwe8Dw1kpg53hKB/vEb4kwSyi5cH+tLL8QcXDtmi52FtQQyKItx0QU38ZzGO4ugZbKkY8bCstFuUjYHlJRIN2eLDuAVzfWsfDly7gk089g69cuYSHz1/A0+vXsLWzle4VbFpguQFPl4DJBJwFG3nLB/rh0KS3hna70fAJMqMdFRUDGio6xS/qCC5fWaDzoMuqIjEFhSORO7nPL/2JTm1qP4dffbPV6fDK1GQqhF4fzclpZQ5xmRm8WKCfL0DMaBg4sryKO1eP49UnT+F1x07jfefuwCuOHcex6UrYeqNzuUKlgLu6Tfm/wtDWHvGLtKcK53UYiaHanekjhXdVHeGy13cjbH/PXtHjvsvBUHpK21jaslBnYW/GS/2/RZBUGOiS/qdB2mKPeCTSnAWU43hDWs5fuICdnRkmbQuQDBfn+dpyfrZYkQzIymPSBVLiCChvNzc2WPbUJvpttbEHWBlm7jqLeCWqmc/mOHv2NqyurkKF2BupEGV5nbQoI4ype8+mMvQqdJbll59H51Icj2sAJd6qduC+hi/cU6mrlKvy1p1qQSMeXvq/DI8Fr6VKmxTK+k/FSAVbN8K36Nrnd8njlJ/8kHjPUKdMTrYCA22bzm9us7D2YMy6Di9ev44vPPccvn79Er7y4nl8/eYlPHL9Orb6Hj0ItDRJnuSEQNTmM0f7vPc38YTzHtt0l28ju38cJ5w37ZrCmd/le2un+6z/eJkNrHYdXhvOdg8XDmINa4ORjwY/nQ3sEhfiwC5t6WhpgE7iO0bARL6T1e7H9fSk730PMHr0i0Vy1DtG0zCWaIKXHTqJuw+fwH1HjuOdZ+/Em06fxdnlFRxsJiovfhW8gL4MwTW+qSxAYM6c2gxnULXtjld+ZfjoqmPPnjGZH7EtTrEw6EB9a85bnAutp99XNDuWfhDwZJ0sHZq9ygz0x7w1ed3Lzpd0+mH8Wr0CWCUtADudpsD/kI6M7rDmovJsbm7iwoVLmE7TXmy7q7YGtJUFUmjShRdFdOv5QpsbG5xANdHBfbpaT/bbDiJbN3crQ8/dYoHJdIJzt98+8P4pinHkhGv9GFjVnoFDVItYRyK0WFD0onZNU9RbtrNuSIsN45UyA80Qw0nF+zFzLYJYetjj7dnvirz9PEMgyHVItMtWo69XVzsTgfs+7d119En6Rd/j0vVbeOzGZTx67TIev34dD77wAp7euIUXNjYw42zgW0plTFugTf/JdIU4ThnxU71pLKdQZoKiif6V38UolHzl4u9evKo8o1mHxlOHlAuQ0E+7iLE4acnms34t9Y+IIChHcqg6UeJz34MXPfpFByx6NMRoQTh9cA13rx3HvceO486Dh/Hak6fx6qMnce7wEay0E0yK9suULSl/pd9NosgZSo//3m6UliM4REROzYo2FpwZ2AqXL+nkroyNjwJbqomK967W6sdBOYnAinMsCwUr9nOUtMJO7LNdoic1/ggtMX3ZR5Y++gRjjkn8EvZsB2fZv68XsB97x8x4/vnnweyPWnQXDDS28MlHtekgC1sgRbpAikLbmqZJ8r65sZGakFcdAxKN2LGNuoAqDCsjzOPO5jOcOnkSR44cKVpdAoFrJDmWOaEJN1WMdNyomIxFuT7JSOQ2UKqx4ZRaOSPeYShupGyfkwtJSxxkhAiIyhSWxui0Or1g+uHesf1m+xkpqKanCLASjXh6fDkMuzbQ/5X0k7ZNeyMlLRgdM+Z9hws3b+DR6xfw5Ysv4sVbG3jk0iU8trGO5zc3MevmYCbwJC3FRz44HE2TDjhQzziDcNFjTLADFPw+YWP6kKM1B8pnKcHaG6y97EEGnrLvw9fgFMCEJTsWGliFfNkhIQMHZoD7Dtx1IO6BBYMawrQBji8v4/blNdxz7DjuOHQUrzt1G1537DTuPnwERyZLmOb9rYR8bSP3ec41TcBrZCDDa8i47s431si1cKkDe4PcerAdtjAl8WmcRtBI+Vy3On6FxJ5zpNoEK8nIr+tX7TKLnKievggEamn2N0pVoX+faVJCmK5zfAfA5kiD8S+KGBnF89Bq7aXiIKo6r/ZcgZyJunHjBq5euYql5bTuSADXXxJPWb+aPGUiV+pRuLs2KZKBr/0lItDW5mZSx7zy2IaO47GNPDj0wqXrGX3fgZlx1113oW1bVB/mwIzA7IIBFTZWUwRRLsrfpW93f8boHAhZ8K/Cu1raUaO8xxPKZ1ZvL7gy+yp26PzUK5FXEWAUJBUQaZhupIYB1uRhwDSiwgPMUQFVB5BDIZLWxzfzvsfVrXVc2riFhy6fx9evXcHFzU1c2rqFZ2/ewPntddza3sRi0YE7Sgt3wOjbBmgaUDvJfxtwHkJKDlCJYFCwkDa4huXfZaGSoVx1xKEqD76fPLJnUCplXN45wFWu5Eie+xyZ9j3AHSTKBfdosjRNJi0OtMs4feAgTi6t4a5jx3DXoeN41fETuO/wUZxdPYTD02WsTqaBB9ITalNpd3nwC9liyvFxsPjsR9idtxmMMWs9IVoraHAc3P9T1jUgqdZa/yIqgel23R7tJzL9vdqcQvqK3wazp6MFhJW/gzQvwZ6G9MHNjUUMbFG97TK1sFjM8fwLL6SLWtwq40EE6/5KNKv31xLpymVpq/znQZ62traYe5tPs7nZLjvGbig5b/uRrUBgRueOdJzPZzh8+BBOnz5db6BnWBga4eis7ieyCgyu1FO834+n6Bc2jT17lTMKNLuVU/t9JB+5vKVhCl5geOONs0UNwS8u9b5S+5jg1uaHAa9LYz00BO702UUR2f70BThzllUGp/1tACZt3ngOGvBl1ne4MdvCxVs3cWH9Ji5t3cILm7fw6KUreHbzFi5tbuPGfIabO5vY7LYx7+bpjl8m9LKaloxAIqSha73KkPL3tP/OobHJiUTLgQ3sPgMSxdo8lzMsedomh58QMNV+7gE/SU0AGgYmTYOVyQQnlg/i1PIajqys4vDSMk4eXMPZtcO47eABHFtewR1rR3Bq5QCOLq1iiRpMMl8FmKS/Os7HuTLbUBpB+0GGgCWfyizFPh2TjtozHKkx9un3IJ5e5odg61k+rMvbBNcD0jfSHp/I01l0aWiAlL+XoRiJSEejXJ/VFecBez+2NJQT6rXC4hyvyfRLjaLro3uwwCTntfa4vhvFgjGe1Gk7f/4CdnbyARYNgdgviJK9sxlcPejCAFUj2QJwffsZGWwBA1lbaZyj3F4ONvD33fYW2RYR73w+x7nbz+LgwYOQ5U8ytFjCw6iSUUGwG3YUZpE3YMK8lxrZjkWhPknxPXibvoyX8NgCD1fWbuXk9GZUrP0v1fMeDq0zvAUTQxAXcezWGAGH4XuLhCVdaM5LITsOT8NXlwon2O0tQN6aFobo0j+WP8t7ztFnAN9cbOPq5joub9zCzdk2bm5v48rOFq5sbuHGzg42ZjNsLhbYnM2wsVhgfT7Ddr/AVtfjVr+D9cUsOaBdjw5sq/yV+niASGyLZx4B1GuL22aCpXaCZWpxsJ3i4GSa5kMnDabTFkeWlnHq4GEcXVrB2vISjq2s4NzBwzh9cA3HlldxdHkVx1cOYEp1g2COZl636UYxCLa9QWjtAZVbMqpzuVJO/C6NDY5Q7tdS/Dk7KVbGLvDshGJ4cMkQWl+SzlBhvsuhW5aFXcK98WdQb+FR11YCB8di3ySPKFjx/iXxwT17matU9t7Rby240fZWKyjDC7MIXqbD3HKtmPz+1q1buHTpct62yi6i9YujUgF22QCF4xh1NTLl70BwysIojoCtAivbauP012/56dH1HRiMvhteNi/Dyg0R7rrrTjRNu6sHpasLi5jp97TibqR8l7ma9yWvWB6hR4WjlMQRD0/EhnIa/RwAYlgOl3k96Bp6uwZEIIwOyD7ULbDN8S0ORVTKLjK7Zy9+DnXEvFly7SIyx0MMn+T3W5KYfdk5Ks5ymujJS/w1Qtt9MEpPuXbOCAPY7hbYnM/saNM+nW603S2wMZthq1sUUzV5UZBDK2KghR39hibNXR+cLuHI0jJWJlMsT6aYNi3aHFVLdpnf9lzzc/pdjkplQWRoGec5p8wD9dwB+54BMHZQdnaoKHMsCgp9bbQpwSPyVoKtF/X4WFmxF8Xx3w/EGG2jc6R7RZuFEL/kqM89L3UO9qW6/4EjI2VGB2kkzT7atecq62jICjtvArLfusZ+WywWeP755w0sYcApw8dtm96Xv4dhZNhws5AogN80jdJAAGh7e5s5WSN3FKMYK1t1HCPZvoh0/YplYNEtcGjtIM6cOTPqXPw/9uzixQ2M/z7DKUlrdn3Ygv14nH64N9BbKSdnSOXtUp+vs4z8x+oYIzSu59zdE6XSMNae3To7/0a+pkE0Y4BYRuFCxSCbN2iSW4w+uzbqSMSwYir+amaYLHBITOVH9+MYf3bRghHve9cYJGKPfXcjLgK2NgoSV4bvFXkMIlRfr/bNbvLgOr1G+9j7SED5MaTdj8Po9Tj0pzPG1Z7zQ+Ch7mHPDGS1APvasPNoXtSBolw1vefq4t1G3yrhaWn3CKhHmAX9Y49fILTntFklylUqRIRcOTLiooS+xOfCxQvY2tzCpJ3osYo2TFw5vEJB1V1EIFdckXNQG5MnHZGk5BRPhM4+B0OsBh/OQJJ6lhpNIOqdMJTBaJoWN27ewurqARw+fGi0wSY8gNfJvfeYMZitE/a1NL8i7LHMaAPYml/1ojh/rtpJAdmaI1AoQMAnST82BOQ+67da2qBInrmMMM5WBBS1xQyj8zz78FsG7k6p+yPgnONG56xYhrhoy9rDEs07VCSCrQUgEzAVbWdMJWBTUksiWWvRpjAcTxTYh4x5KUPmez3l3DYAXd2a9LDRBnr5FODNCmO6w3VjyK4pEYhEtrIOFrQUxGKEJfBzp+rIEfQmMKnL1eCIQ/WzjbaQWwPidKE2clU4J2VjxiLJ8hmsPShku9AEfacyVLElZZm7Ahb5yzrq9i2UnQrUvKN0elvC+k+gv05O3VHw5Q1krkLD6ODkwFP3mSKB5lill7du3cL6rQ0sLU3V7fSnQMnCSC2I04p8kXtd/KT0JQefGotoNZ9rwIRzi+wYx/SjDCOrQmfFUWKIQejRUAMGg6hPY9l9WrgxmbS4dPkSVldXMJ1Oq4a1tjhm7IlpkjnezeDvJgjSKCrfVZRR+TNShjyjirCb5+zLKUFYPL2yHqJImxFQL8+ndA5NSUzdVo4oeU0rBpnLtE5hufL7SN2xyOG7ENk45zDWWzaWvCqpbJeGpEKVx6pAP2uB8sFA2FcWqCmt7m6fHd1DqiLBFDq60gKf1us3vE6WuTj/To7PNjYioO2fct6OQAEQC7JV3muk1/VLjF7plPmC97YtWv7YSJGUtIedkumBaqQ6LCxQp0GOT2IFV72Z0Wky7LfVlbwF8LJPQ0mQSxF9Sc9+olx4vvhKVNpy3ZmHTHFaKyYPdnS2s4PLly9jMmlhIJt56f6mLJTXP0o9siAwFa7O7Ehwog5QBueJT9Qzg5ombQ9wBJMyWBahJIIaNOip14YT0l2oPdJk82LR4cKFSzh37mxq8siwR1zwI4x0/NoLjCvCwiPvBwzx9PgiK+92yzv2+EUlYWgahQIWij4cliqUE1EZdJtJMeoQyiq9vzGgc/RGQK+UCaDcryse5IBgX2+FwcRu9j7IbJ3nLqgM+kgB74Zehc39UijHMhlzaqaFXNmU52XsB4S0eqNSKF9I5SJ5/j0UU8qtyYfNe9aRerCaFKZrtUBgdyMo8seOrfF0LLEPfh64LMLBdtV5Sq98/hHZ1ZfeOvk0Tj693rmpHa+N8dhd53Ttw268lKChpM2XPbZmJNC0WxRaeT9qb/b5aP+OjKztJ8jwT22kQFKa9nkdkZdO1nnoWNnoCI82tO97XLx0SWsT12EAtAw3HJx/g/QRdMQssqSQt8IWMLMNI7MWxhnR7VgxzrwTZQ8r74jSmfENgbgB+h5EDbhnTNoJtra3cO3qNRw/cTywvgoGrkz/fVevz6VnBzaDZ5fhC09DAOmxoRBH/wCzKhGqTz9oR6VtZfk1mgdOQKXOKh+G2DEgalQpXXpPdZibgsyZ7lO1K8nK+eG9POHSuMTkhbkROz5KowCq5yU5UTAQLdOOUafakgF1d+O817sMLDyUKG/eRGf1CzsSJNWYR4nSYBTGTz45h6WUUx8hWA7vwJTHFg4q0BdiEDW9866CHPoIpzJEGXTEpRnxyawcAZeaHZIhxYqM7im3g9GECgh70iqRc1mDsnPEWR9zJISOsZ0e/mIHT4+nsygs+NS7PdoLRIU0FZ8UiEYKUmeuXuuVq1exM5thOplovylQE6mc+YWS6SebvwVEtv1Qsr0XJz7IRKZ3osSJ4ElkRJT3WIvPasjeNHImaq6ALaRmSvsc+7xtYTqZ4PKVK1hZWcHBtYNVICgjjeDf7OE5waWxeePQxsFTnYMdiYJ9mvAOGAiTKLOAPlB4hLV6d6MNdeUp7VIJ+OVc8YD6SgEhuttrzmc3bHHP/uaOajwpDWXdWx2NOlxaZtdcp6ejKzkDmbb62ZKPA3QsMxDq6BkzP4VTUKFtfOW88S04wpK2zpoAvrXHDynXqa7oxW6Oh+DgWP9qRRF8yhE1WcQZSGBfzoiO18nZtVUCsoP0xahc1Y6MyX/Fvgyi2prdyLY22JYKbaN1VWRGK+RK343ZxEobPegoPSNBS+0ZXyeipUXvsVQX1dOhjhARbt68iZs3bmA6nQZAFT40RQSrziIZADPsBKkSaF1LCv4bH2i2s8MajbB5zLq6GEA62CL9Hs9JLm4GcqdQpWP32L3rceedd2IymeD38niPa2wusQRnb3jk7X5WCO/3qZvHSEOt/NF5nV0jUvM2NRp23uYYT3ZrZxXEZGjyJbCkCgiRIfGTE/KSln2vMBzxqIwPRfKstHsEoRXaRX68IRlbuT003+JElmDNWqL8O3ILVCiHB+2qpNz32yFe7Vl4xbvchRIHIuUK81oEYjIQCollZhqGTkN01ErnmfTjS7vdq6rju4x8eRvkh68J2HUh5+j6CMk7QtuuLZEAqLSTRSS9H56M8YH9bxn8SzUKoOQdhIodtCmvUoEzFZ6h4ee6Qw4Am5tbePHFFy2izYdPUONPirItP36/LREG99p6OhWYRbZH7BEANHIAu3hTPqMV6I6pGosmyFdGdmUWmRC++OJ5nQ8WUJb/xhilv+/yzsqoF1J6pAORr9RRq29XgZT6S7CjuBhH3tUeKmjz+eRzGHaugJzvN0BklKoOhQyfhN9IPL7dbanUM1AWyenaHRfJDIEW7h2DB0bY16X/U6VE6OCwwIdcAhLFzhS4pvtyQ9U5q3ap1kW1roYMI0VdoZBO88mBxI5+4zkP/hu2KzBPWF48vozhW/k25LgjhspX8i+NFT8qF9Fe8CCdzKO5gjDGB5+mBNpaU2r0jclwWb78pyzxgFBGUiMjSuFuW+xiw8qynAMudcswZq1toY1STqWOGsjtPh3iG1O0G04EKN+4VZQd8lbeh/oLhVF4GCFvDD+ICPPZHBcvXEh70h3B3ukLelsB05Te0UWFo8DOYeGsUczer0jZdnZ2bEWNRLL5+EY5hhGQwy3i1XtldMvMmreMgAmE+XyOtbz/1ijIxDoPP+nx/r3PwMWaIaf6kLQ0G/JbIcC1PN6iBWXy5eR0Q8Mx9DJ382hrwziBZtRbXH7fi5Oj3qTLO/CGpRbpq5JNhX9b9cwLjzpFAlaullNldKZpVzspvK1kHtApKWppJKeAsdQbwWOkCtQaUAZHsd0SwXpjhKItVrT6FAP6xWBAdVtJKOst3g8EbeSpzrvu6xlWIPo2Jr+1kao6TUU5e4BINSIt85Qd4OzFIF1tdMnxf9CFtXIq9mjMhtQCiJcSvdeel7zoC6K/laewmZ4Pu5ZeqNlLbREz47nnnsN8NkM7meSDYsii2abJN/vIOzuwQiNc+Y0cRpFFxyxg7RuIOt8mqfHpXxXqhsB9WlGcLpM3lKbsbcpnVQAZfmwA9BFEiFJ5k8kEt26tYzqZ4sTJE6Ec4aafnxEzrWa7Aj6ufRh0dZmmYEAAU6cksr1GDsEXoRjYFO/B8fA6Lkbdg9xt+CSAj/+9fOfoLunaTYjH5qu9tzwIxbQ8GjJhRANs/jBzzl34OhrZe3CpImydZ1LfgAaW6GnYLA9OoV4yufNKrrcEZTISj73BHR+KGzr2VIqigSygvIp4Hve1ugb4RNHJoUFqV9fwYbfoC769GBoTqyKhfXUeFYX8a5mFk1UD3eIZjNbI50I+S5tRPnuu1yjLHfNyiqgs0BZs4pDmWIwrZ8S++c+jTvleaUo6yyi6ksb/NjaiWZ3KK+stf1c5icsszaX1dqZmB3Z3JiQaPX/+PLa3t/NxjEmtiKB7ZskVT/k+MHFeNdoFbJQ2tJ/cNkxb0wQMeZjJwSRriiYy5qaNt2krjxiujKRIngFz2nfU970eTdUzgIbR9GkLUNMQuCdwk6LkyWSKq9euYTJtceTIUYRj2MQuj3i8/rs/lNpnD/kcWNbSmGEt7ARzvmKtiM98eRUlHFA0ElF72mLyukGpPuIcjHmTY9leQtpB+OVKGXLWebYlbwTwMjAwD/OWxNVXO5dxm2pKaYGrNBSN0wo5uNAck2gqV5dvvRr7oQGqORVJx+p0aCnkf/PiU5FkgpNLcoukK47RXo95FZkW40+VBE+1dDAPHZjaOoKke0PejdJV8SCl38ppCpTfRZ8x0idF06rOoHfGc5m14VFy6f0CJi1j2Izwe1Xv9+EM7GvOlevjhb6McsHXXk85OjUAa6Hfj0qI6BaOoulfdB7sVyczQjN4KJPMuHjxEm7duoWlpeWUkyr/Nf5zql4i2lSHRbbSBtPUor1V9pPqE4EwCWPLhTOV3rkoTzglJ2AA2jlSY9p2m5jSUJPOWiYASPt3idI9gRcuXkJDDQ4dPhz5VDBPALG0p7GF0mCXiorffZRaAUrXzb7EgndD5apRNDZHsZfHObYSefQhCt7wSwLS/Twj0Tcw5hmPAFwpXMEAvSSCAGLQrp1U1OFo8MmDs+DkN5ZhfwYB2iBN4RyM0lZzF9yokgdL7DNadp+4BrJ7ClKRvig/+B+1yBCxP3cDWqWSBMwFoL0hLvqMECLnwMFdIi5t/kiUSAVt5g+W4B3rpSJN1RbISFel3rEn+ouRz+bsFKBeAVAao38scq7kK79zqU8jdA7KrORxaDFI7wGq9qjG5P20hHwHuDofwJXLV3Dt2jUsLy8npjaJNj1vHKRnoQN2f613MvTOZRFMB7SQQCw7zn6brJwiJSPAJFsgmDEhkeZBA207DmeC0p2iqXbKXnAEFlIctkOY02lT3DGoleFpwiQDLlGDtUNrqLquvnN8Y0d7YiB2iaxCQLkYdjEeDt+VClBNs08vs/x9L+9xTHg5JtL3o+XsWgsCTSJIA6VOifZJZ8of+SyWkjTJrrR4ox0bHPOX+Mh1BR9kKPsi/+P0NmSpzQ9XI7NKu8blwVeU5F+OLBwWYkmDH1nUXz1JR3hZLbZwEkJluz9BH5xgVvWEDWQlDZBlx7eZY/3abAc4QY8rNA3yagNj3SWAhehrZFSsxpmxcrwe7esp0ldBc5fIvFoexuVP87ro1PfdYNFlHkkbtdRlBDta62hTPFXJjPjga6Rir+/Xr13HpctXsJyHjnXlsQdR95/M00LBV+ZgK4v3aCiZ4jDqSA0XToqjb+IzmsHVV6BMYF9GBgQw+/kwdsc1SlmZQD14Gc7rb0DU44Xz53EWZ3BobQ31QQ7P1MH9QBoZ7JqP4v7bTKD+5tPZz1z9XM6PeA92oHRFmWPvajI3aJHnf+Gpk0tTVDTwfMei7vBOALdMM+IZj3nAfnWmN+Rjc60xst+DKxYyhO8DoB1ErbFdgzlFijItWSSyImCwhaMc2hpQPSoP9c9h80Rp7ZWg8j0XacpXzlmoqgu5/bj7cGxR4Z2vuuRvHpGoOaajDt2InI85q6Ogsg+9Hp2HLOipsXCsHC+L+5ojHSunSFNrZeDEWFtG0g/mXffoo11lw+l/lVe+jKr8FA7L2ChYpVnXr13HxYuXEtA6GyYfJXiUOVd/7zSF9KSV2QiMmAezNzoq7ABzuC3QWkzz2SzbEYELskLEy+R8ebesUu77lJp58J+uWs7pe+7DXwE9drcGzbsFbr/tNhw+fHg0ehxT/+B/Bs/Kn9w67KthBbmG0jMei4Lz+xoo+vx+0tx7yx44fb1VRSp/28W73VURaWQOWYfrinIdzTXvv0bLnnNHvvFj9AQSIpjWI7H43iUYl5tgUOEbhCoXx0gcEapqKYUgjs7RO8NDXPB3pJ36sSyzgsE+AQPwl81r6mDfI1Dsdz5v0Lcjo1Plu0ELK/l+T6ttawZ8v88eIFKtbo80pV0q5z+xy/v9zNWWdAbQ9HpcKV/6brc57sFIQQnKlQg/+ojD0YqagIy1MaMVAODa1eu4dPkylqZTrZPI7qEF7Mq8dD1eXIUMonxRvN3mY/txk3NLbvsQOTmgpkE5cuNZJORPEsJzXvfkxpsd0PoRNPnd/kqB5g31IMvEueH53FsZjtAFC02Dlls8/8KLYABHijlc6w2xiLF7CF53zOP3Z2SSJVcagSGOhiHFEGVFcgiwFcvunXC3HLb2ZZfv9xNJlqIWBbb+vhohVEC2+r3qVQ6BuPp4cIwMyP3gftit7aNV0PAjD77kj+QXQcdACYUkebmp1roHsBcUeGm1hVzREdt7X+g40I45HT51YAUXK4o1QiLoWgcq8lfgYjTi8pQVAF9zdqt5C73xl26Uz34XBpXl+whmt0jY2zt5F4ZRiSrcQVyB7C3tbqAVqh6+LYfGqUJ7fS59+JR9IeUNho7zb9VRhJHIeax/WfNwWBSlwVwgiAaMKWkr+XH1ylVcvnIFS0tLqT1N6hs7hKK4kzaDqi9bho0lqI1yUtgOx1+C7a/1uBgbn54JgDwX65hOriAk74FZiGjMcMLmdXXVMhgNCFyuUgahgR3a3mS+dh2jbRpgMsELL7wA7nscOXrE+iAIjlhEwK/yUt+gfCrGwwPpfob9PL9K41EzIrngarmuAk0zltKv7PVKPVbnYAGDB7BadL6LEdBnDKR3yRPmG5VYUgDS8qT9no5CQVObxo191SEaRNpQBaob1wpvyjYlQsuaaiUNUtDIL15dYxnFnNiogOwNsuReSdlltZampKME50pNbO2ikcQ+27C1Lk2tb8aGTB2IaW2FjI9FiSFC3U+EXgNMtvUIo+2p0KT1wvHOpRmLan1b9kHxIMKstcX3xV5DzaKLfmHpS3BxnDM7sFrOvjsL9xIKv3z5Mq5eu4alpRTRihNk87L+ZCgD1BTRkuX5/9d2tW1u27j20PZk0qbbJO1227v//7f1vc1LkyZjj8X7gQRwAIKSnHT5tBlbAkEQBHEAkpbIHgyAu/wFyX156QYoYpF+8gQznZ9Q+p7s4gddURrQE4KllPYEqN6h/lENr1e2uv0hyjpQB7QDUuJqlqr7wYdScDye8ONPP+O6XPHy5TdqlMOkoOzITjZimADDUiEsKpUJmk64MFEjyBpPMtxJxD/b/9maNLMlxmm90A8HPgK4oX56SjMD4Xiv63kbfqSh2IM6tjMuM2xxnTTlbWDqT13WTh+5XzNwju1RXaGYhHFBoAhwfK2O9E7kkn7GYPPyMe+vXdOwWoncATAdpplO8h4z9E7thDOVMEcsXsv7uLqMmgSLbmyTDLAwvdhRBMMky438QfUy+Z1PET/CQUTwxVkmHwGY9ZXqjWWP7XL/WQfxGs2P2Oc81xdehYh9HwfyDriywpo9Ua7Wil9/+w2vX79uv6Ot0Iw2AqNkqQy0RmOfa62aHLalZZgc1LYzaPU3rJfgi0WW8+VSfaQltLIcVFVfsi8LyN5sv9c/t6dItf3cRfZ1aW/W7e8ui/KoteK6tIdnLHXB9fGKl9+8wHf//m6INtZK3N/bCpGqi8jziVsxc7pD406Grb2U7O4nLY31Et1dCfc649jg0HZKF0twYim1C2TCwTZ2EsnknTab8WJ5FWS7HkvQQwJExcjbh9Qe5nCxuYepS0Iy7oUC2DGKT/AhYwqXKegfaSQZF53eYzAymIUJG2+oI5wGq7MOJJlnBoJR9r37w0OwlnVsZTVnFoTGuZ/OW870JvK6q/9Q3+cH7xzR2M5aHV51yup0mjgzlF+qY+IUA0Yxl8mr8dr06XOo29v1uuDnn3/G+/fvcXd36kDa+MkerAAof9YlZMp02/2DgbDM1WL7tQ5sOciVebfiw1gLJwZajZSqOZHqdFDUTkrPKJdlUSU3etrP1XsmfDvVXHEFUA7t0JQJ3paay6ng1Z+vcX284ofvv6d3hnpwHAeGsmYaWO9Q4YzJxWVJRhqby0CMgW5XpN0Ic/knUazPxCaR9ISGr033jmeFJys50jKhmTDxYsSqyaMO9+wR+b5IFEzkFXF1dCIZ20NWVu7MovOo5yDb7LWbIz6YhE3/TCD3xJK7/acZXT7u2dBV2MEsF2Y4R9m+Dnt6AsBZNuh4edumITOavUCb0a5ly9ncnmZZYxAbQ689jnYq76TvrFsOjhy4TdrOfNTYfBgPoZ/Mu0zO2OLct0yk4KYmqyeCCxIEXM4X/PjTj3h4OOPu7q5fryjglwfQwafeV/2flo5tGTkAbfclQstxnPpoxKV9XhL3PdfA9nI+K9pJljkOViXbbVktKmW2HZwlg13AGSyfVvbZrNLXRSNm473gel3w9OlT/Pe/P+B0OvVOr5lw3EOZR3WqpeQGn2TOqkSe6SGCWC/cuyV7nQF/GnXG9ootmUcnMZPP7SdF/kkfY2Se8fQV1jOBNSc4yDY42YyJRN0EOtFrpWUW26+P3XBy1EXDHCjZ/Gn3jD61v0/y6qNscVlsXNXybTpH6FYo/LW415WDfiqU1bthpUNAKD2py9nX1uoD5jY3szevN/GSJtMnlaCnQeaVLHs+pj5YXvee8ULJxy6uIujl2fy3OcNj4aQp2z7xw4cP+PHHn3C9XnE6nQwkC2DvnD24t/gAZdizFUA+aEZ7GE8aU9IjAMzhSXcnjW6IyExvvMXawFbTVf/j5pkiBSTV0HuU3paODURrbdeACLBM046ELPL7XP55kbRzOOC/P/yAL589c3LEJebBf06i22nEHCJ3uagnp0PdaZYVDH+rzPhkZQ1wU7ANNJjQzORhHa6C4Ix+a1ImulrFQXZsdN9Fk5OxyGSwvZYxYCqaSc4DpeyQULsUZKj0WWUegWuUmaRz9hn4MBgmbc2K4+PGhT66FwGzZDGGT9rdtSrB5J9mtzHgnR76mcgzBAgJzazsaStUYKJcnlnmOQlcdq2w7JBnl0/Y1RawFQXOxiIrb1+/wS+//tpA8njU+j5DPdAycf8Zz4FA+OhPKRfYsjIAl/UOfzlIKOFdtt1F+BUm0ov09/F8brmsH9G+vEefg1LaG4Hshr71p06AtS7tsBTgstulNpAd9nQlc+48rtcrvv/+P3j+/Hk6WPx9GLiq2thVZKNfHZzzHcEZrBjJ3v2mYRn/xnqDHoDcUZEeYo3tB4oEVrfQTHTEBpuBZuTrn6m6niVNAyrk47bXlmRrhSP1GY9G1cBvzCli/hoNTWgiqI28pg8GcbpdH2N2FByI6N9pfDryTElphUXknI7QjhWiWRaVJQlDADXYY3jkH9dfk2+SmIx2UNSXBuFyvpMS50iasSerCe67ZLchsZoFG6vyBJ3n8nihXWZbzOYGRffkb1kW/PprOwh1d9feRwvJPEFgq5mqLRfL06EOCr6U5UrdUgACa8mWYx8BeyFBTe7pnNT+jkFRuVwuiqbN4OLSTHMCLdtET4LtoFQNyzWSoS799Xx6TcGXM14DafTsVjPcKhluG4haKy6XC148f47v/vMdjscD2c9W9gKfQZFj4bIn0opZhyqSnstcfYV2pe6MGqdt7aDPaDj6ChGXi6pTjp8n856MPY4NVXByGuDSmUcXBeo/0+xInMrgaieTax5t01gnme3YFc6guK2cxkVD4fKWnPO2WCfb2VqWaVeSoegF+r2uiL0SXJGgJOeE5uZxQUozzRK5qYlscQ/TfOl6gDPIzMHUZOXI8ceNheaFs/EYCCT8Y4afgQnLxsWPhfVxry/NE6PG5uPHj/jpp5/x8PCA0+lke7CHgoLD8FJ3AVkFWxR9QTzTSSbsHl4hAYAsPZPftL7IYxlH/RQ/mZ1GlKaBrV3WbKMGgyImAo4NICtAweJadqtg20FUouj2f3/CFKBLyErXs+tagcfHC+7v7/H9f77D0y++yDuLSZQloyifatUMQrzHOPb8/Nd8j8hxj3KADDipt7XstZc+RuwabYZ6Tpbe9xZjZRH/jUUmZGgbdE3oxmLRLcFXQj6CRszwM0Ddzj7WsqPW2vqKg0m9u0y9/XhflorzDJkAlP4MLOOFnSJPwVDur64oYT1bChkXg4T6os8oa12cca5hbhhxSW0713VyfmR1elVxvtqgjWl11zNG2dDusdbseqqr6F9WeDd5Yu9v8C214tWrV/3Z+QWn07FxLLI/W4DSwFOzWcpYD0d/ArktLxe/hwsPsHwKWcZOggH2QzJEtv203Rfl5zJb1XQx2+pLv1a3KuCI064g566ZKnymmwFubXuz7f7i6nAWLKAufK/XVv+7f3+DFy9e6m+jYvETVaJz/wg8F5BQT2/Z94s0W/TRoHdlKSv81aHMMskdDmsuQ5S4DvSzqG4a4a1knkqTZmXedc72GLnsycDX9U9RLSgY3WhrP/+RZlV+iftYP5jwt5wTKPS72dkRbZfITCL1HXYVM6WM5x5HNeinjrb3SXySz9NA80Y9eFvd+s12FJTbpUt+8uQVeBWPS8hO0+CjTqAwZPL8OePPefnwxDK5UzDXNYDr9RE///QL3rx9004bh8y1NUnLxMWeDnU4+KVkO43Mj2a0ZXQFUclsO4i6vdku6yGMcQ33RxtrwZOG/wUoj5cz0dFbYovPxszx1P5fpc8j2PKeawWBLfzhKAVrAdh+bal2SEqu19roCgqWuuDxesXT+3v88H/f4+n9U5KLOw1V4jDGFche5yR9zYwlKz6LLl1N0UlSZHhLxC9ixgmdGGyoMfIsOqjTZmdL7KlsUX4n10okTwEdUdutjBwN7vS+sA/jF2F5q2QrIlp/Av4KeCXuQ2YqSQKDUNb6vlohlAK4nzr5vbixBTfWQQiJ3EuwZQ/m86XzTyq6dOc76LaDRO7i1ZDtzdY430I7URujYmPnkuBxJQNPYVHm35bipnFkiUipc8EnDhjm6RCkZD6k5is4qSYEpIcsHgBtq20advcbb968xS+//ILlesVJ9mclo0XRA0yHQ9Gl5PbZThfLHqyCLqAvi5fDUIc+URRgGcT7/5keStRhZjIT31gAlMfzxdyL+MrAxFJpOThlBEvtb/PALKOljJXv16UZyeIBeFkaiNtfOjilmS40s75er6gV+Pabl/j3t992BxgAt8To3/et0Xl42RP9zwlyb+gmHw3KENBmjtlFkI6RXuSgaZ6lZDL469keHYCbM2fez3Rd4UvTKDkVGXFaR/c31NvMXkogyft46/7nP7bHWLzdloQ+DB5chYxP8UFLRj/LoIatpYnMWbi3Z5VhSj+RjUHD782aUaerXoHPiFTxcw3tTuyEfOPU52QJQSwObJOxCHHJ59jknj3b3asz7FIcs1QkoBScz2f88vMvePvXW9wdTzgdj81+dHlXwLCBKy8Ho2e+/PMeefqTgnERkD5QPQNXcUgHZw+md01uev80JiSauW1Dk4RyOV8EvoZ9O9aVTHSbRH75GJq1ApphSgbb6WqlA1FCH04myz3LcOWtQZwt9+c5y2RagPPlgi+e3uM/332HZ8+eAaWmhui02fvBf6Rntv/Hvd0uXmf+bTop2NJ9x6eGFrM+TAaYI21Xq4Qqsy4V90fbH51fRkisJ1Fy3n7N9RBmK/s+zjA1EBTZYv91hgwNuAWOfJyrjzw2Ay7H3tlDBHfQvSx7tq8xyMgAxJ85cIAX9DHUDk7Rn66sSKbJTWXWbnGR11hGJ7YuS5qVhSUHBmi9PlktcnZGOnE8lLTJpk4aVvc2vclxKu+D1mSrWSsR6MpI8r8p/hxBRZ30oeLVq9f47Y8/sFwfcTrdNVCiLNYvHyegivg7Wk8DwD01inlKcJBluGwy8SyI2nIJY5OtFFBgWy4P5+p+R0oqgryvNjjauDzDzkRBWYARdEAKcHu4ELBFlgkv+oALXVIGFJBFBKEH2l7udbni5fOv8e233+LJk7sQEA8eDKgEpzXcS+rNom0GVbvso1APttxWBjIxaqS6xG0cX76byD+SJiWPvGd1b4+qST62q8nD/m8JUiLPbN9+IM+5oMWkY7t8prswGE2BwwBikDmLHiKbIWis+rxyANMVh4k5e+DZk1HDj1c2Si6GoxWNFgfVkaf6HOGe8c3lnK2Y8KVCOv+f7PFO6KfzogSasj52mLU76YCbdzvmZgzEFIeDQ0m3QWY+NTzdgVc6Gfxqrfjr7Vv8+tvveHj4iLu7OwJPD3riV+V+CZ/tzT4NjAFopis80lfmgYIZzW4j4Hq5tZsoaMmcBc5xq0PVRIBczuezwGNn4wHUg0gDyLb/KYpsg+gGqlqU10CM9lwjAFe777PdxbJbOhyly8/K035iJCs41+sVFW1p+eXLF+1H0MnEM+XZv9UhwUqZAC3rbkY/CpA3OHF3FtwMdHS9VjeZPNdKhPOGo4N2B7wq01kFt/+3UQSnnNwwp5BqZQpoUlkH2vMoYQic/EMDJtyGqnzbEzZyiwbMoCY4txDy5ogZsmNeBQlZ3CcVcRAkgqh9CDbJIdaaKWsEkIE+Nr6lk41iW0PBBgbvtl5fKvvlxERcrpPNizV6bdR/qaHdbF45ExjVNsgw6/vq6hO3seLDnJ1Ti2aOjeL9+/f47bff8O79e5xORxwPR5dpukyWTg3b8nBb7o3g2+yQDkFxVqs0HkzlrwNWr5hV3awmYbRiInFWuVzOFf1ds36SVTtsQXDslg97I7xfGxuuBLjiFBzIyu9uBURhmSzQM1cF10Xfi7u4w1NWV5bjaq24PD7ieDzi22+/wYsXz3E8HKdRK1DcK3N1Yhf6DLjzOHFgss/TfScqzp9yRJtSf2Z0PskWuPhoNec5pZ/IwHvU7v0YtDceD/fc0tY0m92zKpHQZ1E+0+jU2BPxJzAxC9CGAKTmBrdnT7js6csg1ARoVc5JW95Qcvpbg4CJPjlL3GXPDnByIF3dh0z5ZEFuHiTEGrMsNFQOX2RActnc74EHPQiw9Narb4BXH3aNkQvu9B+4S6F8+Ptv/P7HH3j79i8cDgXH00nBrRwO/Texfn9VQNq9i/bQD0EV+r0sZbcRkAEDXFGFB1xbvUWVba8W2MhvbnXPFt02KMA0lUzAlqwgB9uoW0B/kyovDoiGIxnrELDJwEzA1u3HIoBn5T1aeTAGAfwSfkbUrwldKe0NEY/LI07HUwPd589xOBzVfDXo8t1yna9l3HNIyD671FqdUYwZQokVLFuIyz0cFEUn7RKQ27MIJ2cq6yzSFbkiYQnE1V9P27UWOJOZthtl3GirxGtB7sg/7tetJDXrtlJ8QFeTYd9TVE+53/WFdJHJNgUr4ulerDDYbbfesDSaZ4MTPhwIlBFYnd3O5nLoyzi8bmIMNG7uJCtgkbeTJZu+YjOaga8/5StbqlwFx8Gf19z4AlCv2We0YV1RtOqufPz4Eb/9/jvevnmLUoDj8YTDoYXbblm4lHaqGLCDT/2aAF7+v+cjWa6BrT/4FPeC2acY0Da+bUVBxr3qENpQbsyLoLMBbGV4GsPONgyAW6ahewKOvBjN6/b2V04bWx05SOWfINVGL/4GF4Dt9V7tVX7y6EcGZfS+XK9XXK9X3J1O+OablumeTicnmync9/W2fRsfcKR1w1Lf2vLMQBOccSbPEGw6GexGpaULNh4feU9kuyHDjL7PZRHKprj9q8294gieOwBplgW5lYvZWKdZevunooZfIBXHdU/mf+uKxq59xQG1+ngUG2kZAA2IpUYxOfw4MpjlGf6eVYkx65N/J6sGO5TiA8m87riHmQR6g12NKcitKw7x/IXMvXJjXS7Tg1MbPIdau9qNWxfMKMhXgfd/f8Aff/6BN2/eAGggewxv4QE6UOpvYOUnPK09e4YxUIrfmy2HHHCFZ7PNDpri3Q7NPuJLB6iHQGm/qWW/H89H1E7bAmH2Bawb8/U6j+R9to3GGxqLEZFbI7saolQIgNogaIbq7jMQL1gqwjXLamX/tob/QZmxHZyyOg2EKRhYKpblimVZcDqd8OLlCzz/+uv28mEqg4GWqVkrfbpXyZlnI7Rbcn9CD3UclSpkjU+uqw0UR8PvjRwcyIQHs9gOCxLROMhgHpFZcX9c3eke1w6QNfbbYDs4laQZk78OGRvzG6wm6GEupy+36DwtE11p9p4BFAmzvVTrI5/Vvb2oXOe0Ay+Wi+bgPAOMEN59Acbn8XZBc9XEqTyiEwl/Wxky8j3LtjtKjD03pGgrEbHtruMoo/gqiotDQtH+LsuCN2/e4s9Xr/D+3TscDoeWyR4PqEvVzFX2VTUDVZAlMKVM1WWph2KPVNQlZTh6/Z+EKx18mwBQ3BKS6r5noSD0np8vY9A0qrv7g/PlTOdx4bS4x+nZcoqNQMxiq+zed8MXIG7guACw1/vxb3FboiqZb+Mlr/ADAa7bv5VTzugP0pB2+yGrtlJQca0LrsuCQyn417++wtf/+hpfffVM1/crTcQtsG0kfhJDNerCTL3u1KhfoqPnJ9AYR06jzLHTfSA8JStG80Ij8lW3X4pJ3fU3ACSlxA9J/SSLqK5uYFVr1OqqSH4vkT5S0DG63K7TSca4ZyXCyZDoP3mWClfYbGtXBuXCZa48ays2MpLP9qg9RnqbnEVENdGzuz/rC8sczVPjGZ4jPvBjW8LwuSTm+Wn2sDVGlDBpYyrFygrLaP/0ABKiie26qQzusjOIEBMGuXvjvEr3cD7jzz9f4fWb13j4+BHH0wl3xzt9sl8t8gQmzkKhp4/HE8VEh76XS3T89Kh2X+RuPHi/VpaVpZ+yGltin2FBWSE6yHXBSAo++RyK6JRdSQy6y/l89n7WiZAExYWempOFU2GgM3CW+pqdEgjz3q3Q6HXKYO0eH6jqJ5epba4PVNpzNnmuy4LlesX9/T2+/tdXeP7iOe6f3K94KOE3ZkFOJZzZst4mZTVerkbDUB4SV5KNHBSBngQbrp3gmKxfE4nc8mEiQ+Uak7oOd9nLYCjj0ujI0wK8dj868MFUrfMhch2FCLEksfDPTeX2uTPbjtnb0SaYy4QP4DbrO+APpaXcS3DA/hZcUDbM+X53KyLdKMNizhD4J+jvCbYDwULaYNCjkrFwW2dOZnO8wx5sXPEYfGFrbT27LT3zWumY9CmjySJTaZyC21uGTrbz3r1/h1d/vMbfH97jer3ieDzicDi2PVl1fbyXCpepxodT2PKyZbSI9KXA/ZYWBf7VeLbfKtfasjDC8nFXHPnoWmsHeFabnf8BoEvKAs7sl1nlWRnANsz6gUHpNGKsuoTMn4tlqnFvScC20t4rANvDdRmvGZk+HKO/GUjYVtrrtUza7wkvoKdVheyby7IseLw+4nA44Iv7e3z9/Gt8+eUz3N/frzrM2d5e1Gfmp2L9tX2eSeXkYqybR8nzttLZCTYpdjLtQv8jEUDM3onlrTLIwYVBte3mJ/Rl7ryyPZyb+YfA4XOyoIxGAImdgRHZODmH0i/EbGXmadUX93rqXIyxt3XHZy/yJX2b6FmaHafXNkyUTN7tSqvyxO0ZplFHr3zEYY9iOPpwX8bvVtvWCDjScKDNAiW8ua78vV6vePfuHd6+fYu/3v6Fx+u1LxXLz3cAMQRrl34/qwAZs1oAsN/G8jONFZzdwSb/MIuDjEUHZ2n5QL+nVXmK4ZAYlCRCBzEwuS694XnH34dgEI5OaFQT7Xe2VsMvu9WhcubzaQydc+LokXkqIMtLDii7RbWnQzFYG5iG1/PxQzH0vq+HItlv700lEFfUtsi11vb+3KUvcT99eo9nXz7DV199hadP7/VxYINy4JU+A0Ikhn67g6rk4G6JSz+lrZyF2sIaGxlXjECW77vlbQmvTy7OcEV3QW8ReErx9E4GDjI29E9+uUY+twzdDXqIWeKn8PisItHhp7Yz008acG7JslJ3q1L5jD5M2Dp/mbeK6XLj3jIJdO0+AXiUgcDkfD7j/fv3ePv2L/z94QMeHy8NYMvBvcQdYY7rHml4f+yY3fLPemyf1fZr+xJzqCt1irRZBJzR71l/DuVgq1AlBvLijov6/qh6iV97D23Ks2/jDDmLCgGU8/lSNUx2b2oQEIIyGCPpCj22WA2oGKJnexUR7GLGuWjG6zNWWb7l9+Yy0MqBqIWAfKEsWQ9QwZaUa2iflbnUiutyxfW64FAOOJ2O+OLLL/DF/VM8e/Yl7u/vLRIzdYXRGvTe6HdE5avFh8A76KXhz2t2yn6y1Da7/jnyTHnuq9zb/QR5avLlc/jMwOQfHKNdurqx3Zv1fwt4cvknwHajDNsuN/DctG3kwebI6LZ2t+UKQtANf4bAl8vlgr///hvv3r3Dhw8f8PDwoD7XMtiwJwpJKuM1pvP7s6Xws4r5N7V8GOowgC+A/jIByVot+4xPoEKnKJJEFn9Nv1EWrtl5BRR2KcsFtWsjC7rWaAwim+4K0E4js9rt4IYiKGLZszeQ7dWGCwpyWRbs91zD/ivQlpkr9ClSckOy4viWIV1f12tQfqD2GXRjL+vS9ndr3zc+HA84HU54cv8ET57c4dmXDXzv7u7sIdrIE6TPKWpgxja9m/upQK1R7Hjvf16Cg+Eg51ZpckdZc51PwHZPAuRo5J/IR35Os3oKygm6QWW7w3z4qLoPn1loLD4lEbSlWvkT5zvgh4jf17rGeEXWNRonW6/mhp2XZ/sy706wlcMzMp8kMxorVrWRSu3eUgRsvL1hc3CknivVxmXpj7b9+PEj/v7wAR8+fMDlcsH54UETnePx0PZgO1BaTwxIJastERgBBU0BV67De7J2+tjqNNA99GvMO4BpB1J/yEoAkR0L3D3pTcu4D6rQUa10fDgJiByoltHnOjnP50sH8D4baFKUzqQA7pi4nIfjDNVHeGS8AqpNV0Oma1krHJ8GmL21sJzssuFKwNnl9W8aWhytXe/8agXcvnG1iVQsw5Z6ut4vfK6LZtcy4Hd3J9zd3eHJkyc4ne7w9Ok9ntzd4XTqvzVzkV9ryAcjYcLiUyeq5zObn+OqR/CMQwlO0kV70WxXAo5aCWGDb5gKS7cr0boJ5flU/pJIau2b7TbxxlfUjUA0jlukWd3j/8fKuKfNbU11wpV4HNUmsnEsw/VBmmG9fJu2rJOFSkhsZ3yNZrsc7VXanTFfR7Nsz44aoybiKiAmppeHxWpvnCkpSQxmKo2ZlWVZcL1e8fDwgIfzBZfzGY+Pjzifz7g8PuJ6fdQDpodycE9o4o6NmaBlyC6j7L9l1T3Zwr9/NXoDT95/hatT9FV5cD5T//Zh4vaVLzy9YlYx3XG23FQ4zgX9aJO581PVtD8CGGpbVe+rLJeLPBtZm0Q6mfKZbBljLLVF4zIobvJVDI7IddRlu01R0yyXwNplpfw/aMlYMt8OvgrcC+0bw/hz++VQ7GAXaVwGQ/aO256vgbzsT7TTegccjs2YTscjTqc7+346qcGr6qu3+y0YtAlq362mU7G7Xv1FswLu40a7Y5lHe9GwU/aJnx4uhQujKZK9bQB4+7juaFmfM57qbsOD2cswJmtCRdKVASBBViUPUzULv8RZZczSy5MvmRyzHsxoayQo7s8q90qV5E6cR6netmMDX4YJGW059i6bjwY0cV4K/wqglENbVUPFcm33JbForxptwLostYGo/l3UvwGwLJMejyi66MdUJFGz+/K5+gBO+EAzWNujRWnAKYAjq33xFXeN1jJgd3gKfq9X6qnmGDAleakwvqJy0SP5U/dKvWSkshHLvWkwgbAqqnJfzmd7gv+0GY4+q/7LjARsqD2XyRbmw9khxKkHp98HP55SBsI7cvXzCNxyX3hqJgx6/KPSUd0A8NJBn5W3/i2S+YvM3na173G5fImnrTWdogZoGDLHPgLg+jKGK5VuFLo9s6bIi8WtFqA7OYun1+eKycSeyJwuL07kH/aHXUWaZWmf8mx/K5jxrZVRd0ON0o421ChCdf+SCxkcuP8ojLzC/YziZvLBzKDWfOs6NIYwwu5FVVcyl+rHfxeYMbOpDa9XA8T5JiyzwePO8X3Wta567JkwnS6VPz6ClH2YIke/2zcUdD4V+ymKAF9cxs1A8mCoU4Pfiaedq8pXSFa/nMv7pZzJ8lt2RPt8MpkPOrV7/Png6RtyW7/oL9st3H3ATpr1Cejqid9qfVOVCyrLV0ji6OtWMhR++p0HW5pTFz6NPCmZz3O+OsUJetxVBFwWl5kzYPc/8XCTA06ExzsKSOqpY/8e3EqGrBmuRHwEvHIPlQ5wwUAYTq+136VN9Gr+jYMMMV4bVKFho58PR7wzz3iLd+zRyGZNbDmz1Dk2w4zhmrNzx6/6rwXuARzqrKd68HHmFKhjWUPV/uNR94jCgBop31L8ScVkWXEPaGUiCf/VEh1kCtB1HJihxZFgCwfroP95f8KwT+RdbSyKl99bqVr0nzAmesPP3wGECWvFB2Tiq/YKLLjQm7nweS48arJEZ0tAO0ijIrDiDYCzoExkr31JWudC4eRK2qQlW/pfX2cnGScHAVKvCEDV24aKAAAM+klEQVSXNvekrmS89KQpB+y9bX5ohfhV1REFFxarcNAwKdnqGgUi7BtEWXUAZavnX1vbq1zOl+qWeJNGB1uXjoIQnYBSnKg80Nn428Rmg+XbvC+qABeWh8UgbAmZwdeDMDof/rmQ8ALQl5dDZittgQ9MYbhvul2GTF4H2dGZy2YjaVGyRFcr3mOHc1rJbdlvTJjVcaxTHhlo70Hwmnyal+le5wyhpjib3/BQUaf3Zpwymr18dpWdYBtbjuPLh1o2C/GMPrwmNLEvM/1Y3TEgQXJvzifR3Zo6ky7r0uQmozEIjEuEke8n8dxZ+MRADdd4b5L9jnhc6bMCabEHT8j1Dof+rUoCWB19a616ilj9SfEHlCLgCkD739EWfTLULJsF9a1QW7xsLJ1gPg1siwUcbP+D/RX6SHbm4kE5gwQLukJxmS0HJ6qnSj/9mRSDR2MUUVw/Zgx4kZy+RhASwTiz5WxSM8p+O/4Wl0HRX+PMFrZMzNluAHStQ/LpHm6QGSQjXxfjjfxFTw1sWU/8gd+7OYzAatnjUKeAPKu6icBCk5rhpE4d7H7a7poP2+mwZkFM0enEjFeglgB/rgpzdDTjHQUJgN2d2Ftq+tGGYqdJ5WFScqE7E1Nx8becy0u5jWUTU/fNCc76Kkye3RoPhHFlax8vMlYKeCvInJIYZC1s8/7B95MTu5RD0QsG1tSqy2SlJscIDHbwb+kBgaFlsjH7LQr4DJ5aX3kbWEtywvvBmTz6e1dVbvX05KdqrO+UVXSOC7VjMejWipsaDOZn2bMdnFGBvCGm3bKmJNrxUN8nkyhawapCMlxQxCVgsywhEhNRBHN7SCF7JAKmcs/vrRYFxTYpKvhJVPFNQ/zZZdqwg1M5vfiXRucycZLL0Jpk5uHocvoMmCMt0X2la8X0EkeMB9bVMjmEbojPaeKllbcsrAmV0Mxd0ei4hI0FX2k7LM9ngq2VqPdcvxrxEo0uWxEr29PLxdZ6gwze7nK67ZLbk+c/w9y4IpM3gFT3qQkMVXeMhWPkw5dRkAkXWl5ck2cmwtBSXGkJRHFtge94ecagh2sOK2LSEtFLID9ksoV/azrapwEpP+lKAsIOBSgkR38LjlAW4yM+o+Oi/USIQRHZK/BavXhQymTp7dN9XQmsFfoGIFVngeyb8f606ORwODQs0MBmEnhTwKKgX2GvWBVMUygMFiB4yfeKjaw7jRyDb57jQyDbpHZEFfFVY2Ndq2phgzcui5AFXIW3MFMgRQ0/zfFADL3PmanPUuXdudKu7tf2f1smHIAXCKebuZ9+z1eBn/s9fI5ujxVf4UeUqQg0i3wnvdkcGlmU+LVM77myBXIryzQZr8zxDmAb24tVNrznNtD21nQyIgSae4RYHUXYHMvRKHPcbP/iCCT2UrVOQE/5UHMqX0mqbPAZaJmpKyNQs0+0aVzjpZw/WGc5iMktcddNR8nD5ml8U9FTofOgsESidGQZHf0IZ/XJi7urXXpj1w2jwuzG70kKYNCzu1HA4y8yif/lS9oigw/dsyc12Q057NS+EnjSz3dsD9aCh7jULD1yJ6URAxVvwLoni4S+2uftII94Qqu7sRtcT+JbnLWyPi/yUAvNvFhgBgYewM6lIrx1Q2ZStSdOhWy2XZIowYxRs8NkoioMM1AtltUy6NjeLR2ckhPJfJ/AFwNIC6gy0FbI24ssG+79oNlrPKtOemnPdGnD4QCXTzWtpAgehJIJWrmCObXIJ/KK4P1ZJQRiOQ1/3D8RhD0wNjHLBrcAdyt7TKuX2Q25Pee51d+5/DxeQZa1Ut2fcWi2gqgJv8HpcbdmqKaX4woLfZuoxx/Fy8c6KzN9DnUHTxl8F4FXkJhC9Hm7ev3WCebkMWAepxlpVTNB2Y3tPkaklOsKunOZ3d5jKbSvaiAqAG17sJ2/e1GA8WI6oANyl4f3WQWIo1wu43Wy0Gdd8dTYwgJp+UdWAYK5qpYJuCs/e5yNvXq9Kp9imFou8aEW1JArxLhk911t4qFLGCE61B5xdJovXw3Xql/mFRoHmAR2S/UgXuleJZ4MvrYnrD3xmbGQKl1wG3JAq5dFUk1U7zjr6HY7lVOTSQG6LiNRTM0J3znQjpwAOF4eymcjn8jvgojkfuyU2KAYf7CLqKcZ2M5Avib8RJIYKcdukgnA5glNug66fSQ6lY+0A7dVLdKounnirmVGs1b4dT3DePg3ee0b5bn0mRfRh+JIcMz+pA/HMBMSIdg8RNNxvAf52fkpo0oX6E6NhELOsys6ffMN0rjHbJ8ZZVC2WlbkGTJehLksAgo1kxv6uOyW29TF4E4aX18XwW04QQxs0ssytTwpyvsyDPxEviJC8eU9gZf7EugVQ6SNRlPD/YEPcnjTuhX9rT9xfaW3wgPGy7zZdBq6KNGCEgnQ2Gchq8FzupN03Xk6ZykgV7xcVa4z8MpdyUa953QArfsgBKq8TN0mkbx/dxnqA+OLDWIW6/ZYKtRYPBi0f3SIVV0xGJFDVoUrujLf9+PrW+51DhpBwLRMgVGrB3Cd8au0gpEEI5Gf41DhIma+Hrw3sUmCvxFrXQRtNp5VSIUN90d3HDOXyH10TfNvuRxzmiShzh1a9XK7/eGgRw+2ftyz6zplva91baUrF4OcElxFsjL4i6FkKwvFj6uTQ+xPQGG18Pwlu87ULHdDfyOIDcGl0PTYRG22jBmj+G7bI41gOQdTL8tIp8FB4ecbG083p/pcGjLa/pQqzcoBzXDlEGMRH05yIPGFlRQ91AF9HzAygna3rM7DyDVqac9GztadwQ2ERirflihu6tTJHN2Esc4wDQNtxsOM2b7HJWRORfh3su05Fh6sqhMugGdNfioENBDskykCuO7p1gU2vjyZGbz9/rQ6JTVCVlj8bPJLXZ6qOjbCr/rlFr/HI02uHYyhCLfSSeo6woPgF0f4HpwC6xT/MuBin54YfY2sfMCnuEp1YiCQYMsggMk3L21c2GaocQDyA90E40fxS1K/3+ezDzmLAm824zwmSsjmjvnzwDxkiXqwsAC6p8TOGn7OeXuP85Gbin5hHDu22Wgv6fiE6cM9c/t6PEWFrlKQLPMrsJVvuv1URgoaUtMxZ77ViEocOiAMvw9ODMwMSF2wraBn/BVoKBBtS790DwbQAn5Zlip//d5xTWnHQ1GeT+SbXTNdFp0j5Bk7ILuKWk9K/oaeEmjM6tawMvMd7F/aiwgmaG0GqFU7A1IOR4Q6sMSpBoDZcPB+eamk1+V7thdsB5da4wzEmvkiTh44o3X7tg5khX5sm0Fb6vlIt+lsWRaXzbc5WUYd1XBIvJg7jHqgiqtApu2Qt4rkzmBDADXuscW2xudoayelX64x6mB3TuIsxnGJ0mXf+7jqPbqOeOo757IGNHvqz0p2AIq+KP+MZtC/swnf9rDcOdjDDGx7jZUYYqv/vJ9pDsrGl3XMibBQxdUr+5i0ORF0NhZxBWdYhjVxPLCt2F+cFbQWlcvsBdqUWpd5SZ4kwdK61kfjWbit4nuo4+WC/GoZpzzDmGQuYN0zwNr9ZkcG7A4POmhz266/2u8K9FPEg05cD+FkinOhJPViEhkDukgvo2uuM9qEhYZWTc4vmF8rlws/1IINosA9Hofl46Ymk9ehO5IiNl49jTkUmpxkDAV9abdregS19k+2pyvAnmW3OjAEhPL8ZPG+3FN5lZ/Wh+1FVXnAKPVMWJUSl7KNzl0GYZFzBjbbakI3uKBuQPqcapbKgW10NTOMHOlcYypvsAD3CJbgXGp0Tub0JYueJtzOgQJ6AtP5+nH/emaTww0BtDohnHh3PixUmEZ1QDEuDaTXWtwmiPThcgaEWfRVJ/23SqMd2c3eZeu/nOuzPcCkWg3ww8jhbL/aPVUg5wPFmdcIPrwC0/hlOpzFf0FoTVB5rllhwyxGSLYb7Uc1GwKNWRmDNC/HqO4yyqu67l+cqP68B4PTmHkWByYKIjoW8dCUgK0HVGORZ8f6WX2aD/KdTVdeoZsnAxkeab+z+cv0DuC9prQqAbu7zvPjHE4jKwFIEnHWVXUOcxb5cvAoMF01CRVw6bW4rgx7PepYq9dWNVoDQT9ACrgdzMXJc8bbaKGAXsNbf+JfFYPAvpYKD/7hvlNkVV25DJ0ncVbECNlrhCAiTuyRB48FA8gM3by8rZV1On8tKxF0rX03sbuRrGXWDgTcjdCf5KNPNAI9dWcWgNjYcYUUdTy/cNmJEL5QWEGCRXtZ00/QXwa6Bab/4YaJ0xyvB0EvvAjsbVqDwlr6ma1xfo0Z9NjfrJ/tahJcRPkG+6zp1YH/LLMfrs84leQTSzA+UtDszes/nnPxjAQASZ/9q/HJT/Hakrxc9wAqGSz3cpapyu9oFU+oA2Zmtq8rvlT0aXvMgjDePuyshNh20AevrrjpbHOzaiCB6RKxf/Qi1aUpXriNSnjXwRYA/h+zeWpG+oOanAAAAABJRU5ErkJggg==";
  const slides=[
    {icon:"💰",title:"Welcome to Money Flow",text:"A simple personal finance app designed to help you keep track of income, expenses and current balance.",points:["Keep your money records organized","See your financial position at a glance"]},
    {icon:"📊",title:"Manage Your Money",text:"Add income or expenses and let Money Flow keep your running balance updated for you.",points:["Credit / Income adds to your balance","Expense / Debit subtracts from your balance","Every transaction stays in your records"]},
    {icon:"➕",title:"Add Transactions Easily",text:"Record the important details of every transaction so your history remains useful and clear.",points:["Date, type and amount","Category, payment mode and description","Remarks and other useful details"]},
    {icon:"🔐",title:"Security: PIN & Biometric",text:"Your PIN protects sensitive actions such as Edit and Add Transaction. When biometric protection is enabled, the device can provide an additional verification method.",points:["PIN is entered locally and the stored PIN is represented by a hash","Biometric verification is handled by the device when supported","Never share your PIN with anyone"]},
    {icon:"🔑",title:"If You Forget Your PIN",text:"Money Flow provides a Recovery Code for PIN recovery. Save that code somewhere safe when it is shown during PIN setup.",points:["Forgot PIN → enter the Recovery Code → create a new PIN","The same PIN protects Edit and Add Transaction","If both PIN and Recovery Code are lost, the original protected actions cannot be recovered by guessing or bypassing security"]},
    {icon:"🧭",title:"If PIN & Recovery Code Are Both Lost",text:"Do not delete the old profile just to start again. While you still have access to your records, export your transactions as PDF/Excel first. Then use Profile / Mode to create or switch to a separate workspace.",points:["Your old profile remains separate on the device","A new profile starts with its own transactions and security","Switching profiles is not a recovery of the old profile and does not copy its transactions"]},
    {icon:"👥",title:"Profile / Mode for Family & Friends",text:"Profile / Mode can be used for separate personal, family, friend or other-relative workspaces on the same app.",points:["Each profile has separate transactions","Each profile can have its own PIN and recovery code","Switching mode keeps the selected profile's data separate"]},
    {icon:"🛡️",title:"Your Data & Privacy",text:"Your current Money Flow data is stored on this device. This version does not claim cloud backup or Google-account restoration.",points:["Keep your device secure","Do not share your PIN or Recovery Code","Export transaction records when you need a separate backup copy"]},
    {icon:"🎯",title:"You’re Ready",text:"You now know the purpose, transaction system, security, recovery options and Profile / Mode system of Money Flow.",points:["Use the dashboard to see your balance","Add transactions whenever you need","Review or export your records anytime"]}
  ];  let index=0;
  function esc(v){return String(v).replace(/[&<>"]/g,function(c){return ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])})}
  function button(label,cls,fn){const b=document.createElement("button");b.type="button";b.className="mf-ob-btn "+cls;b.textContent=label;b.onclick=fn;return b}
  function render(){
    const congrats=index===slides.length;
    if(congrats){
      progress.style.width="100%";step.textContent="All set";
      body.className="mf-ob-body mf-ob-congrats";
      body.innerHTML='<div class="mf-ob-spark"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="mf-ob-icon">✓</div><h2>🎉 Congratulations!</h2><p>You’re all set to use Money Flow.</p><div class="mf-ob-points"><div class="mf-ob-point"><div class="mf-ob-check">✓</div><div><b>Ready to manage your money</b><span>Track income, expenses and balance from one place.</span></div></div><div class="mf-ob-point"><div class="mf-ob-check">🔐</div><div><b>Your security setup is ready</b><span>Use the app’s available PIN and biometric protection features.</span></div></div></div>';
      actions.className="mf-ob-actions single";actions.innerHTML="";actions.appendChild(button("Start Using Money Flow →","primary",finish));return;
    }
    const s=slides[index];progress.style.width=((index+1)/(slides.length+1)*100)+"%";step.textContent="Step "+(index+1)+" of "+slides.length;body.className="mf-ob-body";
    let extra="";
    if(index===3){extra='<div class="mf-ob-security"><div class="mf-ob-security-card"><strong>🔢 PIN</strong><span>Protects Edit and Add Transaction.</span></div><div class="mf-ob-security-card"><strong>👆 Biometric</strong><span>Device-level verification when enabled.</span></div></div>';}
    if(index===4){extra='<div class="mf-ob-security"><div class="mf-ob-security-card"><strong>1. Forgot PIN</strong><span>Use Forgot PIN / Recovery Code.</span></div><div class="mf-ob-security-card"><strong>2. Recovery Code</strong><span>Create a new 4–6 digit PIN after verification.</span></div></div><div class="mf-ob-warning">⚠️ If both the PIN and Recovery Code are lost, do not expect the app to bypass its security. Keep an exported copy of important transactions.</div>';}
    if(index===5){extra='<div class="mf-ob-security"><div class="mf-ob-security-card"><strong>📄 Export first</strong><span>Take a PDF/Excel copy of the current records while you still have access.</span></div><div class="mf-ob-security-card"><strong>🔄 Switch Mode</strong><span>Create a separate workspace without deleting the old profile.</span></div></div><div class="mf-ob-warning">Note: a new profile starts fresh. It does not automatically import or restore the old profile’s transactions.</div>';}
    if(index===6){extra='<div class="mf-ob-security"><div class="mf-ob-security-card"><strong>👨‍👩‍👧 Family</strong><span>Separate workspace for another family member.</span></div><div class="mf-ob-security-card"><strong>🤝 Friend / Relative</strong><span>Separate records without mixing transactions.</span></div></div>';}
    body.innerHTML='<div class="mf-ob-icon">'+esc(s.icon)+'</div><h2>'+esc(s.title)+'</h2><p>'+esc(s.text)+'</p>'+extra+'<div class="mf-ob-points">'+s.points.map(function(x){return '<div class="mf-ob-point"><div class="mf-ob-check">✓</div><div><span>'+esc(x)+'</span></div></div>'}).join("")+'</div>';
    actions.className="mf-ob-actions";actions.innerHTML="";
    if(index>0)actions.appendChild(button("← Back","secondary",function(){index--;render()}));
    actions.appendChild(button(index===0?"Get Started →":(index===slides.length-1?"Continue →":"Next →"),"primary",function(){index++;render()}));
  }
  function finish(){localStorage.setItem(KEY,"1");ob.classList.add("mf-hidden");document.body.style.overflow="";try{if(typeof render==="function")render()}catch(e){};try{if(typeof mfOpenAccount==='function')mfOpenAccount(true)}catch(e){}}
  document.body.style.overflow="hidden";render();
})();



/* FINAL MORE MENU BEHAVIOR FIX
   - Tap More to toggle the menu.
   - Tap anywhere outside the menu to close it.
   - Opening any submenu/modal from More closes More first.
   - Close / X also returns to the dashboard underneath.
*/
(function(){
  function menu(){return document.getElementById('menuPanel')}
  function more(){return document.getElementById('moreNavBtn')}
  document.addEventListener('click',function(e){
    const m=menu(); if(!m || m.style.display!=='block')return;
    if(m.contains(e.target) || (more() && more().contains(e.target)))return;
    if(typeof closeMenu==='function')closeMenu();
  },false);
  window.addEventListener('resize',function(){if(typeof closeMenu==='function')closeMenu()});
  window.addEventListener('scroll',function(){if(typeof closeMenu==='function')closeMenu()},{passive:true});
  const itemIds=['customModal','historyModal','pfExportModal','mfBackupModal','v10ProfileModal','v10PinModal','v10AddTxPinModal','v10AddTxSettingGate','v10AddTxGate'];
  itemIds.forEach(function(id){
    const el=document.getElementById(id);
    if(!el)return;
    el.addEventListener('click',function(e){
      if(e.target===el && typeof closeMenu==='function')closeMenu();
    });
  });
})();



/* FINAL PROFILE/MODE FRESH-START FIX
   Any Mode created before the profile-security marker existed is treated as a
   fresh workspace on its first switch, so it cannot inherit the old Mode PIN.
*/
(function(){
  const PK='money_manager_profiles_v10', AK='money_manager_active_profile_v10';
  function profiles(){try{const x=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(x)?x:[]}catch(e){return[]}}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function freshSecurity(){return {mode:'NONE',pinHash:'',recoveryCode:'',editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true}}
  const oldSwitch=window.v10SwitchProfile;
  window.v10SwitchProfile=function(id){
    const a=profiles(),p=a.find(x=>x.id===id); if(!p)return;
    // Old inactive Modes may contain a copied legacy/global PIN. Reset only
    // those unmarked Modes; the current/established profile remains untouched.
    if(!p.security || p.security.profileSecurityInitialized!==true){
      p.security=freshSecurity();
      if(!Array.isArray(p.transactions))p.transactions=[];
      save(a);
    }
    if(typeof oldSwitch==='function')return oldSwitch(id);
  };
})();



/* V24 — FINAL COMMON PIN / PROFILE SECURITY
   One canonical PIN per active Profile/Mode.
   - First security action with no PIN => Create PIN.
   - After creation, that exact PIN is used everywhere in the active profile.
   - Switching Profile/Mode never carries PIN or recovery state across profiles.
   - Biometric is an authentication method only; it never owns a second PIN.
   - Backup & Restore is protected by the same profile PIN.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){
    const ps=profiles(), id=localStorage.getItem(AK);
    const p=ps.find(x=>x&&x.id===id)||ps[0]||null;
    if(p){
      p.security=p.security||{};
      if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
      if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false;
    }
    return p;
  }
  function save(ps){localStorage.setItem(PK,JSON.stringify(ps))}
  function hash(v){
    v=String(v||"");let h=2166136261;
    for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }
  function persistSecurity(s){
    const ps=profiles(),p=active();if(!p)return false;
    p.security=s||{};
    const q=ps.find(x=>x.id===p.id);if(q)q.security=p.security;
    save(ps);
    try{localStorage.removeItem("money_manager_edit_security_v1")}catch(e){}
    return true;
  }
  function gate(){return document.getElementById("editPinGate")}
  function body(){return document.getElementById("editPinGateBody")}
  function closeGate(){const e=gate();if(e)e.style.display="none"}
  function show(title,markup){
    const e=gate(),b=body();if(!e||!b){alert("Security screen is unavailable.");return false}
    const h=e.querySelector("h2");if(h)h.textContent=title;
    b.innerHTML=markup;e.style.display="block";return true;
  }
  function ask(onSuccess,onCancel,context){
    const p=active();if(!p){alert("Active profile is unavailable.");return}
    const s=p.security||{};
    if(!s.pinHash){
      show("🔐 Create Security PIN",`
        <h3>🔐 Create PIN</h3>
        <p>Create one 4–6 digit PIN for this Profile / Mode. This same PIN will protect all Money Flow security actions in this profile.</p>
        <input id="mfCommonNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
        <input id="mfCommonConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
        <button type="button" id="mfCommonCreatePin">Create PIN</button>
        <button type="button" class="secondary" id="mfCommonCancelPin">Cancel</button>`);
      document.getElementById("mfCommonCreatePin").onclick=function(){
        const a=document.getElementById("mfCommonNewPin")?.value||"",b=document.getElementById("mfCommonConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return}
        p.security=p.security||{};
        p.security.pinHash=hash(a);
        p.security.recoveryCode=p.security.recoveryCode||recovery();
        p.security.editPinLost=false;
        if(!persistSecurity(p.security))return;
        body().innerHTML=`<h3>✅ PIN Created</h3><p>Your security PIN is now active for this Profile / Mode.</p><p><b>Recovery Code:</b></p><div class="v10code">${p.security.recoveryCode}</div><p class="v10small">The same PIN will be used for Edit, Add Transaction security, security settings, biometric setup and Backup & Restore in this profile.</p><button type="button" id="mfCommonContinue">Continue</button>`;
        document.getElementById("mfCommonContinue").onclick=function(){closeGate();if(typeof onSuccess==="function")onSuccess()};
      };
      document.getElementById("mfCommonCancelPin").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
      setTimeout(()=>document.getElementById("mfCommonNewPin")?.focus(),0);
      return;
    }
    show("🔐 Security Verification",`
      <h3>🔐 Enter PIN</h3>
      <p>Enter the PIN for <b>${String(p.name||"this Profile / Mode").replace(/[<>&"]/g,"")}</b>.</p>
      <input id="mfCommonPin" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">
      <button type="button" id="mfCommonVerify">Continue</button>
      <button type="button" class="secondary" id="mfCommonForgot">Forgot PIN?</button>
      <button type="button" class="secondary" id="mfCommonCancel">Cancel</button>`);
    document.getElementById("mfCommonVerify").onclick=function(){
      const v=document.getElementById("mfCommonPin")?.value||"";
      if(typeof mmV19CheckPin==="function"){
        if(!mmV19CheckPin(v,s.pinHash,hash))return;
      }else if(hash(v)!==s.pinHash){alert("Incorrect PIN.");return}
      closeGate();if(typeof onSuccess==="function")onSuccess();
    };
    document.getElementById("mfCommonForgot").onclick=function(){
      if(!s.recoveryCode){alert("No Recovery Code is available for this Profile / Mode.");return}
      const code=prompt("Enter your Recovery Code:");
      if(code===null)return;
      if(code.trim().toUpperCase()!==String(s.recoveryCode).toUpperCase()){alert("Incorrect Recovery Code.");return}
      body().innerHTML=`<h3>🔐 Create New PIN</h3><p>Create a new 4–6 digit PIN for this Profile / Mode.</p><input id="mfRecoveryNewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN"><input id="mfRecoveryConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN"><button type="button" id="mfRecoverySave">Save New PIN</button><button type="button" class="secondary" id="mfRecoveryCancel">Cancel</button>`;
      document.getElementById("mfRecoverySave").onclick=function(){
        const a=document.getElementById("mfRecoveryNewPin")?.value||"",b=document.getElementById("mfRecoveryConfirmPin")?.value||"";
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PIN and Confirm PIN do not match.");return}
        s.pinHash=hash(a);s.editPinLost=false;persistSecurity(s);closeGate();if(typeof onSuccess==="function")onSuccess();
      };
      document.getElementById("mfRecoveryCancel").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
    };
    document.getElementById("mfCommonCancel").onclick=function(){closeGate();if(typeof onCancel==="function")onCancel()};
    setTimeout(()=>document.getElementById("mfCommonPin")?.focus(),0);
  }

  window.mfRequestCommonSecurity=function(onSuccess,onCancel,context){ask(onSuccess,onCancel,context||"security")};

  /* PIN Setup / Change — single canonical profile PIN.
     Important UI rule: PIN Security modal is closed before the verification gate opens.
     Change PIN verifies current PIN first; Verify/Recovery verifies Recovery Code first.
     Both paths then create one new PIN for the active Profile / Mode. */
  function pinSecurityModalClose(){
    const m=document.getElementById("v10PinModal"); if(m)m.style.display="none";
  }
  function showNewPinAfterVerification(successTitle, successText){
    show("🔐 Create New PIN",`
      <h3>🔐 Create New PIN</h3>
      <p>Create a new 4–6 digit PIN for this Profile / Mode.</p>
      <input id="mfChangeNewPin2" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">
      <input id="mfChangeConfirmPin2" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">
      <button type="button" id="mfSaveNewPin2">Save New PIN</button>
      <button type="button" class="secondary" id="mfCancelNewPin2">Cancel</button>`);
    document.getElementById("mfSaveNewPin2").onclick=function(){
      const a=document.getElementById("mfChangeNewPin2")?.value||"",b=document.getElementById("mfChangeConfirmPin2")?.value||"";
      if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
      if(a!==b){alert("PIN and Confirm PIN do not match.");return}
      const q=active();if(!q)return;
      q.security=q.security||{};
      q.security.pinHash=hash(a);
      q.security.recoveryCode=q.security.recoveryCode||recovery();
      q.security.editPinLost=false;
      persistSecurity(q.security);
      closeGate();
      alert(successTitle||"PIN changed successfully.");
      if(typeof v10OpenPin==="function")v10OpenPin();
    };
    document.getElementById("mfCancelNewPin2").onclick=function(){closeGate();if(typeof v10OpenPin==="function")v10OpenPin()};
    setTimeout(()=>document.getElementById("mfChangeNewPin2")?.focus(),0);
  }
  window.v10OpenPin=function(){
    if(typeof closeMenu==="function")closeMenu();
    const p=active();if(!p)return;
    const s=p.security||{},actions=document.getElementById("v10PinActions"),status=document.getElementById("v10PinStatusText");
    if(s.pinHash){
      status.textContent="One PIN protects all security actions in this Profile / Mode.";
      actions.innerHTML='<button type="button" id="mfPinChangeBtn">🔄 Change PIN</button><button type="button" id="mfPinRecoveryBtn">🔑 Verify / Recovery</button>';
      document.getElementById("mfPinChangeBtn").onclick=function(){
        pinSecurityModalClose();
        mfRequestCommonSecurity(function(){showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.")},function(){if(typeof v10OpenPin==="function")v10OpenPin()},"change");
      };
      document.getElementById("mfPinRecoveryBtn").onclick=function(){
        pinSecurityModalClose();
        const q=active();
        if(!q || !q.security || !q.security.recoveryCode){alert("No Recovery Code is available for this Profile / Mode.");v10OpenPin();return;}
        show("🔑 Recovery Verification",`
          <h3>🔑 Verify Recovery Code</h3>
          <p>Enter the Recovery Code for <b>${String(q.name||"this Profile / Mode").replace(/[<>&"]/g,"")}</b>.</p>
          <input id="mfRecoveryCode2" type="text" autocomplete="off" placeholder="Enter Recovery Code">
          <button type="button" id="mfVerifyRecovery2">Verify & Continue</button>
          <button type="button" class="secondary" id="mfCancelRecovery2">Cancel</button>`);
        document.getElementById("mfVerifyRecovery2").onclick=function(){
          const code=document.getElementById("mfRecoveryCode2")?.value.trim().toUpperCase()||"";
          if(code!==String(q.security.recoveryCode||"").toUpperCase()){alert("Incorrect Recovery Code.");return}
          showNewPinAfterVerification("PIN recovered and changed successfully. The new PIN now works everywhere in this Profile / Mode.");
        };
        document.getElementById("mfCancelRecovery2").onclick=function(){closeGate();v10OpenPin()};
        setTimeout(()=>document.getElementById("mfRecoveryCode2")?.focus(),0);
      };
    }else{
      status.textContent="No PIN created for this Profile / Mode. Create it now.";
      actions.innerHTML='<button type="button" id="mfPinCreateBtn">🔐 Create PIN</button>';
      document.getElementById("mfPinCreateBtn").onclick=function(){
        pinSecurityModalClose();
        mfRequestCommonSecurity(function(){if(typeof v10OpenPin==="function")v10OpenPin()},function(){if(typeof v10OpenPin==="function")v10OpenPin()},"create");
      };
    }
    document.getElementById("v10PinModal").style.display="block";
  };
  /* Keep the old public function name for compatibility, but route it through the real change flow. */
  window.v10ShowChangePin=function(){
    pinSecurityModalClose();
    mfRequestCommonSecurity(function(){showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.")},function(){v10OpenPin()},"change");
  };
  window.mfSaveChangedPin=function(){
    /* Compatibility fallback: the canonical flow above owns PIN changes. */
    showNewPinAfterVerification("PIN changed successfully. The new PIN now works everywhere in this Profile / Mode.");
  };

  /* Edit always uses the common profile PIN. */
  window.v10RequestEdit=function(id){
    const t=Array.isArray(window.txs)?window.txs.find(x=>x.id===id):null;if(!t)return;
    if(typeof canEditTransaction==="function"&&!canEditTransaction(t)){alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");return}
    ask(function(){
      document.getElementById("editId").value=id;
      const d=document.getElementById("editDate");if(d)d.max=typeof localToday==="function"?localToday():"";
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },null,"edit");
  };

  /* Add Transaction: only requires PIN when its protection setting is ON.
     If ON and no PIN exists, the same first-time Create PIN flow is used. */
  window.v109RequestAddTransaction=function(){
    const p=active();if(!p)return false;
    if(!p.security.addProtection){
      if(typeof addTx==="function")return addTx()!==false;
      return false;
    }
    ask(function(){
      if(typeof addTx==="function")return addTx()!==false;
      return false;
    },null,"add");
    return false;
  };

  /* Add Transaction security ON/OFF uses the same common PIN. */
  window.v10ChooseAddTxSecurity=function(desired){
    const wanted=!!desired,p=active();if(!p)return;
    const current=!!p.security.addProtection;
    if(current===wanted){try{v10RefreshAddTxSecurityUI()}catch(e){};return}
    ask(function(){
      const q=active();if(!q)return;
      q.security.addProtection=wanted;persistSecurity(q.security);
      try{v10RefreshAddTxSecurityUI()}catch(e){}
      alert(wanted?"Add Transaction PIN is now ON.":"Add Transaction PIN is now OFF.");
    },function(){try{v10RefreshAddTxSecurityUI()}catch(e){}}, "settings");
  };
  window.v10SaveAddTxPinSetting=function(desired){window.v10ChooseAddTxSecurity(!!desired)};

  /* Biometric: no separate PIN. Register/disable it only after common profile PIN verification.
     If there is no PIN yet, the common Create PIN flow runs first. */
  const oldBio=window.v30OpenBiometricSettings;
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();
    mfRequestCommonSecurity(function(){
      if(typeof oldBio==="function"){try{oldBio()}catch(e){alert(e&&e.message?e.message:"Biometric settings unavailable.")}}
    },null,"biometric");
  };

  /* Backup & Restore: opening the backup area is a protected security action. */
  const oldBackup=window.mfOpenBackup;
  window.mfOpenBackup=function(){
    if(typeof closeMenu==="function")closeMenu();
    mfRequestCommonSecurity(function(){
      if(typeof oldBackup==="function")oldBackup();
      else {const m=document.getElementById("mfBackupModal");if(m)m.style.display="block";}
    },null,"backup");
  };

  /* Profile switch: canonical security always comes from the selected profile only.
     Clear legacy/global PIN artifacts so another Mode can never inherit them. */
  const oldSwitch=window.v10SwitchProfile;
  if(typeof oldSwitch==="function"){
    window.v10SwitchProfile=function(id){
      oldSwitch(id);
      try{localStorage.removeItem("money_manager_edit_security_v1");sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
      const p=active();
      if(p&&p.security){p.security.pinHash=p.security.pinHash||"";p.security.recoveryCode=p.security.recoveryCode||"";persistSecurity(p.security)}
    };
  }

  /* New profile: force a completely independent security object. */
  const oldCreate=window.v10CreateProfile;
  if(typeof oldCreate==="function"){
    window.v10CreateProfile=function(){
      oldCreate();
      const p=active();
      if(p){
        p.security={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false,pinFailedAttempts:0,pinLockUntil:0,profileSecurityInitialized:true};
        persistSecurity(p);
      }
    };
  }
})();



/* Firebase Analytics feature telemetry for Money Flow / PaisaFlow.
   Deliberately logs feature/action names only — never PINs, transaction amounts,
   descriptions, balances, recovery codes, or other financial/user-entered data. */
(function(){
  function logFeature(name){try{if(window.AndroidAnalytics&&AndroidAnalytics.logFeature)AndroidAnalytics.logFeature(name)}catch(e){}}
  function logAction(name){try{if(window.AndroidAnalytics&&AndroidAnalytics.logAction)AndroidAnalytics.logAction(name)}catch(e){}}
  window.pfAnalytics={feature:logFeature,action:logAction};

  var featureMap={
    'v10ProfileModal':'profile_mode',
    'mfBackupModal':'backup_restore',
    'v10PinModal':'pin_security',
    'v10AddTxPinModal':'add_transaction_pin',
    'historyModal':'transaction_history',
    'pfExportModal':'transaction_export',
    'customModal':'customisation'
  };
  document.addEventListener('click',function(e){
    var el=e.target&&e.target.closest?e.target.closest('button'):null;
    if(!el)return;
    var id=el.id||'';
    if(id==='v10AddTxButton'){logAction('transaction_added');return;}
    if(id==='v30BioEnable'){logAction('biometric_enable');return;}
    if(id==='v30BioDisable'){logAction('biometric_disable');return;}
    var t=(el.textContent||'').replace(/\s+/g,' ').trim();
    var low=t.toLowerCase();
    if(low.indexOf('profile / mode')>=0){logFeature('profile_mode');return;}
    if(low.indexOf('backup & restore')>=0){logFeature('backup_restore');return;}
    if(low.indexOf('pin setup / change')>=0){logFeature('pin_security');return;}
    if(low.indexOf('add transaction pin')>=0){logFeature('add_transaction_pin');return;}
    if(low.indexOf('transaction history')>=0){logFeature('transaction_history');return;}
    if(low.indexOf('transaction export')>=0){logFeature('transaction_export');return;}
    if(low.indexOf('widgets')>=0){logFeature('widgets');return;}
    if(low.indexOf('customisation')>=0){logFeature('customisation');return;}
    if(low.indexOf('backup now')>=0){logAction('backup_now');return;}
    if(low.indexOf('restore backup file')>=0){logAction('restore_backup_file');return;}
    if(low==='save changes'){logAction('transaction_edited');return;}
  },true);

  // Track successful/failed native biometric callback without collecting biometric data.
  var oldBio=window.v30BioGateResult;
  if(typeof oldBio==='function'){
    window.v30BioGateResult=function(ok){logAction(ok?'biometric_gate_success':'biometric_gate_failed');return oldBio.apply(this,arguments);};
  }
})();



(function(){
  const pad=n=>String(n).padStart(2,'0');
  const today=()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
  const monthBounds=ym=>{const [y,m]=String(ym).split('-').map(Number);return {from:y+'-'+pad(m)+'-01',to:y+'-'+pad(m)+'-'+pad(new Date(y,m,0).getDate())};};
  const arr=()=>{try{return Array.isArray(txs)?txs:[]}catch(e){return[]}};
  const norm=v=>String(v==null?'':v).toLowerCase().trim();

  /* 1) Transactions opens as Daily + TODAY. */
  function selectToday(){
    const s=window.__pfTxFinalState;if(!s)return;
    const td=today();s.view='daily';s.month=td.slice(0,7);s.weekAnchor=td;
    const dp=document.getElementById('pfTxDayPicker');if(dp){dp.value=td;dp.min=monthBounds(s.month).from;dp.max=monthBounds(s.month).to;}
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view==='daily'));
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');
    if(d)d.style.display='flex';if(w)w.style.display='none';if(c)c.style.display='none';
  }
  const nav0=window.pfNav;
  window.pfNav=function(name,btn){if(name==='transactions'){window.__pfCategoryHistoryFilter='';selectToday();}return typeof nav0==='function'?nav0.apply(this,arguments):undefined;};

  /* 2) Fast, reliable search with a cached index. */
  let sKey='',sIndex=[];
  function index(){
    const a=arr();const key=a.length+'|'+a.map(t=>String(t.id||'')+':'+String(t.updatedAt||t.createdAt||t.date||'')).join(',');
    if(key===sKey)return sIndex;sKey=key;
    sIndex=a.map(t=>({t,text:[t.date,t.type,t.amount,t.category,t.description,t.desc,t.remark,t.remarks,t.note,t.mode,t.paymentMode,t.payment_mode,t.other,t.otherInfo,t.other_info].map(norm).join(' ')}));return sIndex;
  }
  function renderSearch(q){
    const list=document.getElementById('pfSearchResults');if(!list)return;const query=norm(q);const rows=query?index().filter(x=>x.text.includes(query)):index();
    if(!rows.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}
    list.innerHTML=rows.slice(0,150).map(({t})=>{const credit=t.type==='CREDIT';const meta=[t.date,t.mode||t.paymentMode||'',t.description||t.desc||'',t.remark||t.remarks||t.note||''].filter(Boolean).join(' • ');return `<div class="pf-search-result" data-search-id="${escapeHtml(String(t.id))}"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(meta)}</small></div><strong style="color:${credit?'#2fa65b':'#e3483d'}">${credit?'+':'-'}${money(t.amount)}</strong></div>`;}).join('');
  }
  window.pfOpenSearch=function(){openFeatureFixed('pfSearchModal');const i=document.getElementById('pfSearchInput');if(i){i.value='';requestAnimationFrame(()=>i.focus());}renderSearch('');};
  if(!document.__mfSearchBound){document.__mfSearchBound=true;document.addEventListener('input',e=>{if(e.target&&e.target.id==='pfSearchInput')renderSearch(e.target.value);});}

  /* 3) Category -> transaction history. */
  function openCategoryHistory(category,range,type){
    window.__pfCategoryHistoryFilter=String(category||'');
    window.__pfCategoryHistoryRange=range||null;
    window.__pfCategoryHistoryType=type||'';
    const s=window.__pfTxFinalState;if(s){s.view='monthly';s.month=today().slice(0,7);s.weekAnchor=today();}
    document.querySelectorAll('.pf-feature-modal.open').forEach(m=>m.classList.remove('open'));
    const page=document.getElementById('pfTransactionsPage');if(page){document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(x=>x.style.display='none');page.style.display='block';}
    const btn=document.querySelector('.pf-tx-tabs button[data-view="monthly"]');document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===btn));
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');if(d)d.style.display='none';if(w)w.style.display='none';if(c)c.style.display='none';
    renderCategoryHistory();
    if(typeof window.pfSetNav==='function')window.pfSetNav(document.querySelector('.pf-bottom-nav button:nth-child(2)'));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  function categoryRange(){const r=window.__pfCategoryHistoryRange;if(r&&r.from&&r.to)return r;const s=window.__pfTxFinalState||{},b=monthBounds(s.month||today().slice(0,7));return {from:b.from,to:b.to};}
  function renderCategoryHistory(){
    const q=categoryRange(),cat=String(window.__pfCategoryHistoryFilter||'');let data=arr().filter(t=>String(t.date||'')>=q.from&&String(t.date||'')<=q.to&&String(t.category||'')===cat&&(!window.__pfCategoryHistoryType||String(t.type||'')===String(window.__pfCategoryHistoryType))).slice().sort(compareTransactionsLatestFirst);
    const list=document.getElementById('pfTransactionsList'),sum=document.getElementById('pfTransactionsSummary');if(!list||!sum)return;
    let inc=0,exp=0;data.forEach(t=>t.type==='CREDIT'?inc+=Number(t.amount)||0:exp+=Number(t.amount)||0);sum.textContent=`Category: ${cat} • ${q.from} → ${q.to} • ${data.length} transaction(s) • Income ${money(inc)} • Expense ${money(exp)} • Balance ${money(inc-exp)}`;
    list.innerHTML='';if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this category.</div>';return;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));const credit=t.type==='CREDIT',sign=credit?'+':'-',icon=credit?'↓':'↑';
      const desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',mode=t.mode||t.paymentMode||'Not specified',other=t.other||t.otherInfo||t.other_info||'';
      row.innerHTML=`<div class="pf-detail-main"><div class="pf-swipe-icon ${credit?'income':'expense'}">${icon}</div><div class="pf-detail-summary"><div class="pf-detail-title">${escapeHtml(t.category||'Uncategorized')}</div><div class="pf-detail-meta">${escapeHtml(t.date||'')} • ${escapeHtml(mode)}</div><div class="pf-detail-secondary">${desc?escapeHtml(desc):'No description'}${remark?' • Remark: '+escapeHtml(remark):''}</div></div><div class="pf-swipe-amount ${credit?'income':'expense'}">${sign}${money(t.amount)}</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-field"><span>Date</span><b>${escapeHtml(t.date||'—')}</b></div><div class="pf-detail-field"><span>Type</span><b>${credit?'Credit':'Expense'}</b></div><div class="pf-detail-field"><span>Amount</span><b>${sign}${money(t.amount)}</b></div><div class="pf-detail-field"><span>Category</span><b>${escapeHtml(t.category||'Uncategorized')}</b></div><div class="pf-detail-field"><span>Payment Mode</span><b>${escapeHtml(mode)}</b></div><div class="pf-detail-field"><span>Description</span><b>${escapeHtml(desc||'—')}</b></div><div class="pf-detail-field"><span>Remark</span><b>${escapeHtml(remark||'—')}</b></div><div class="pf-detail-field"><span>Other</span><b>${escapeHtml(other||'—')}</b></div><div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>`;
      const main=row.querySelector('.pf-detail-main'),panel=row.querySelector('.pf-detail-panel'),expBtn=row.querySelector('.pf-expand-btn'),edit=row.querySelector('.pf-swipe-edit');
      expBtn.addEventListener('click',()=>{const open=row.classList.toggle('expanded');panel.style.display=open?'block':'none';expBtn.textContent=open?'⌃':'⌄';expBtn.setAttribute('aria-expanded',open?'true':'false');});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      let sx=0,sy=0,moved=false;main.addEventListener('touchstart',e=>{sx=e.touches[0]?.clientX||0;sy=e.touches[0]?.clientY||0;moved=false},{passive:true});main.addEventListener('touchmove',e=>{if(!e.touches[0])return;const dx=e.touches[0].clientX-sx,dy=e.touches[0].clientY-sy;if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){moved=true;e.preventDefault();main.style.transition='none';main.style.transform=`translateX(${Math.max(-92,Math.min(0,dx))}px)`;}},{passive:false});main.addEventListener('touchend',e=>{if(!moved)return;const dx=(e.changedTouches[0]?.clientX||sx)-sx;main.style.transition='transform .18s ease';if(dx<-45){main.style.transform='translateX(-92px)';row.classList.add('open');}else{main.style.transform='translateX(0)';row.classList.remove('open');}});
      list.appendChild(row);
    });
  }
  if(!document.__mfCategoryHistoryBound){document.__mfCategoryHistoryBound=true;document.addEventListener('click',e=>{const r=e.target.closest?.('.pf-category-row');if(r){const c=r.querySelector('.pf-category-name')?.textContent?.trim();if(c){let range=null;let type='';const modal=document.getElementById('pfCategoryModal');if(modal&&modal.classList.contains('open')){type=document.getElementById('pfCatIncome')?.classList.contains('active')?'CREDIT':'EXPENSE';const active=modal.querySelector('[data-cat-period].active')?.getAttribute('data-cat-period')||'all';if(active==='month'){range=monthBounds((window.__pfTxFinalState||{}).month||today().slice(0,7));}else if(active==='year'){const y=Number(((window.__pfTxFinalState||{}).month||today().slice(0,7)).slice(0,4));range={from:y+'-01-01',to:y+'-12-31'};}else if(active==='custom'){range={from:document.getElementById('pfCatFrom')?.value||today(),to:document.getElementById('pfCatTo')?.value||today()};}}openCategoryHistory(c,range,type);}}});}

  /* 4) Analytics: fast category aggregation + category click-through. */
  let aCache={key:'',data:null};
  function analyticsData(){
    const s=window.__pfTxFinalState||{};const q=typeof window.pfTxFinalFiltered==='function'?window.pfTxFinalFiltered():{data:arr()};
    const key=[s.view,s.month,s.weekAnchor,document.getElementById('pfTxDayPicker')?.value||'',document.getElementById('pfTxFrom')?.value||'',document.getElementById('pfTxTo')?.value||'',arr().length].join('|');
    if(key!==aCache.key)aCache={key,data:q.data||[]};return aCache.data;
  }
  let analyticsType='EXPENSE';
  function drawAnalytics(){
    const data=analyticsData().filter(t=>t.type===analyticsType),by=Object.create(null);for(const t of data){const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0);}const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((s,x)=>s+x[1],0),donut=document.getElementById('pfDonut'),legend=document.getElementById('pfAnalyticsLegend');if(!donut||!legend)return;
    document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}
    const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;donut.style.background='conic-gradient('+entries.map((x,i)=>{const end=start+x[1]/total*100,z=pal[i%pal.length]+' '+start+'% '+end+'%';start=end;return z}).join(',')+')';legend.innerHTML=entries.map((x,i)=>`<button type="button" class="pf-legend-row" data-analytics-category="${escapeHtml(x[0])}"><i class="pf-legend-dot" style="background:${pal[i%pal.length]}"></i><b>${escapeHtml(x[0])}</b><span>${money(x[1])} · ${(x[1]/total*100).toFixed(1)}%</span></button>`).join('');
  }
  window.pfOpenAnalytics=function(){window.__pfCategoryHistoryFilter='';openFeature('pfAnalyticsModal');analyticsType='EXPENSE';document.getElementById('pfAnalyticsExpense')?.classList.add('active');document.getElementById('pfAnalyticsIncome')?.classList.remove('active');drawAnalytics();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense')?.classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome')?.classList.toggle('active',type==='CREDIT');drawAnalytics();};
  if(!document.__mfAnalyticsCategoryBound){document.__mfAnalyticsCategoryBound=true;document.addEventListener('click',e=>{const b=e.target.closest?.('[data-analytics-category]');if(b)openCategoryHistory(b.getAttribute('data-analytics-category'),null,analyticsType);});}

  /* Period/view changes remove a previous category drill-down. */
  const sv=window.pfTxSetView;window.pfTxSetView=function(){window.__pfCategoryHistoryFilter='';return typeof sv==='function'?sv.apply(this,arguments):undefined;};
  const sm=window.pfTxShiftMonth;window.pfTxShiftMonth=function(){window.__pfCategoryHistoryFilter='';return typeof sm==='function'?sm.apply(this,arguments):undefined;};
  const sw=window.pfTxShiftWeek;window.pfTxShiftWeek=function(){window.__pfCategoryHistoryFilter='';return typeof sw==='function'?sw.apply(this,arguments):undefined;};

  function boot(){selectToday();sKey='';aCache.key='';}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();




(function(){
  'use strict';

  // ---------------- Notes step history ----------------
  var noteHistory=[];
  var noteCurrent='list';
  function notePush(next){
    if(!next)return;
    if(next===noteCurrent)return;
    noteHistory.push(noteCurrent);
    noteCurrent=next;
  }
  function noteReset(){noteHistory=[];noteCurrent='list';}

  if(typeof window.mfnShow==='function'&&!window.__mfV8MfnShow){
    window.__mfV8MfnShow=true;
    var oldShow=window.mfnShow;
    window.mfnShow=function(v){notePush(v);return oldShow.apply(this,arguments);};
  }
  if(typeof window.mfnOpen==='function'&&!window.__mfV8MfnOpen){
    window.__mfV8MfnOpen=true;
    var oldOpen=window.mfnOpen;
    window.mfnOpen=function(id){notePush('detail');return oldOpen.apply(this,arguments);};
  }
  if(typeof window.mfnNew==='function'&&!window.__mfV8MfnNew){
    window.__mfV8MfnNew=true;
    var oldNew=window.mfnNew;
    window.mfnNew=function(){notePush('create');return oldNew.apply(this,arguments);};
  }
  if(typeof window.mfnEdit==='function'&&!window.__mfV8MfnEdit){
    window.__mfV8MfnEdit=true;
    var oldEdit=window.mfnEdit;
    window.mfnEdit=function(){notePush('create');return oldEdit.apply(this,arguments);};
  }
  if(typeof window.mfnUseTemplate==='function'&&!window.__mfV8MfnTemplate){
    window.__mfV8MfnTemplate=true;
    var oldTemplate=window.mfnUseTemplate;
    window.mfnUseTemplate=function(i){notePush('detail');return oldTemplate.apply(this,arguments);};
  }
  if(typeof window.pfOpenNotes==='function'&&!window.__mfV8PfOpenNotes){
    window.__mfV8PfOpenNotes=true;
    var oldOpenNotes=window.pfOpenNotes;
    window.pfOpenNotes=function(){noteReset();return oldOpenNotes.apply(this,arguments);};
  }
  window.mfnBack=function(){
    var prev=noteHistory.length?noteHistory.pop():null;
    if(prev){noteCurrent=prev;if(typeof window.mfnShow==='function')window.mfnShow(prev);return true;}
    noteCurrent='list';
    return false;
  };

  // ---------------- Generic overlay closing ----------------
  function isDisplayed(el){
    if(!el)return false;
    var cs=getComputedStyle(el);
    return cs.display!=='none' && cs.visibility!=='hidden' && el.getAttribute('aria-hidden')!=='true';
  }
  function closeTopOverlay(){
    // Notes' More sheet is above the page and should close before its parent Notes screen.
    var more=document.getElementById('mfnMoreModal');
    if(more&&more.classList.contains('open')){if(typeof window.mfnCloseMore==='function')window.mfnCloseMore();else more.classList.remove('open');return true;}

    // Feature modals (Analytics/Search/Category/Notes/Calculator).
    var features=Array.from(document.querySelectorAll('.pf-feature-modal.open'));
    if(features.length){var m=features[features.length-1];if(typeof window.pfCloseFeature==='function')window.pfCloseFeature(m.id);else m.classList.remove('open');return true;}

    var exp=document.getElementById('pfExportModal');
    if(exp&&exp.classList.contains('open')){if(typeof window.pfCloseExport==='function')window.pfCloseExport();else exp.classList.remove('open');return true;}

    var add=document.getElementById('addTransactionModal');
    if(add&&isDisplayed(add)){if(typeof window.pfCloseAddTransaction==='function')window.pfCloseAddTransaction();else add.style.display='none';return true;}

    // Legacy/application modals. Close functions are used where available so any
    // associated state/scroll-lock is cleaned up as well.
    var legacy=[
      ['editModal','closeEdit'],
      ['historyModal','closeHistory'],
      ['customModal','closeCustomization'],
      ['mfBackupModal','mfCloseBackup'],
      ['mfAccountModal','mfCloseAccount'],
      ['v10ProfileModal','v10CloseProfileModal'],
      ['v10PinModal','v10ClosePinModal'],
      ['v10AddTxPinModal','v10CloseAddTxPinSettings'],
      ['v10AddTxSettingGate','closeSettingGate'],
      ['v10AddTxGate','closeG'],
      ['profilePhotoModal','pfCloseProfilePhotoMenu']
    ];
    for(var i=0;i<legacy.length;i++){
      var el=document.getElementById(legacy[i][0]);
      if(el&&isDisplayed(el)){
        var fn=window[legacy[i][1]];
        if(typeof fn==='function')fn();else el.style.display='none';
        document.body.style.overflow='';
        return true;
      }
    }

    // Dynamically-created biometric/security overlays.
    var v10s=Array.from(document.querySelectorAll('.v10modal')).filter(isDisplayed);
    if(v10s.length){v10s[v10s.length-1].style.display='none';document.body.style.overflow='';return true;}

    // The old menu panel is a non-modal step.
    var menu=document.getElementById('menuPanel');
    if(menu&&isDisplayed(menu)){if(typeof window.closeMenu==='function')window.closeMenu();else menu.style.display='none';return true;}

    return false;
  }

  // ---------------- Android system Back contract ----------------
  // Return true when the WebView consumed the back press. Return false only when
  // the user is already at Home with no overlay/inner step; the native Activity
  // then closes. This gives Android a deterministic one-step-at-a-time sequence.
  window.mfHandleAndroidBack=function(){
    if(closeTopOverlay())return true;

    var notes=document.getElementById('pfNotesModal');
    if(notes&&notes.classList.contains('open')){
      if(window.mfnBack&&window.mfnBack())return true;
      if(typeof window.pfCloseFeature==='function')window.pfCloseFeature('pfNotesModal');else notes.classList.remove('open');
      document.body.style.overflow='';
      return true;
    }

    // Category history is a transaction sub-step, so Back returns to Category.
    if(window.__pfCategoryHistoryFilter){
      window.__pfCategoryHistoryFilter='';
      if(typeof window.pfOpenCategory==='function')window.pfOpenCategory();
      return true;
    }

    var tx=document.getElementById('pfTransactionsPage');
    if(tx&&getComputedStyle(tx).display!=='none'){
      var homeBtn=document.querySelector('.pf-bottom-nav button:nth-child(1)');
      if(typeof window.pfNav==='function')window.pfNav('home',homeBtn);
      else{
        tx.style.display='none';
        document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(function(x){x.style.display='';});
      }
      if(typeof window.pfSetNav==='function')window.pfSetNav(homeBtn);
      window.scrollTo({top:0,behavior:'smooth'});
      return true;
    }

    // Home is the root. Returning false tells the native Activity to finish.
    return false;
  };
})();



(function(){
  'use strict';
  var stack=[], current='home';
  function setScreen(s, push){
    if(push && s!==current) stack.push(current);
    current=s;
  }
  function resetHome(){stack=[];current='home';}

  // Track the two real page-level screens. Existing calls continue to work normally.
  if(typeof window.pfNav==='function'&&!window.__mfV8NavWrap){
    window.__mfV8NavWrap=true;
    var nav=window.pfNav;
    window.pfNav=function(name,btn){
      if(name==='transactions')setScreen('transactions',true);
      else if(name==='home')setScreen('home',true);
      return nav.apply(this,arguments);
    };
  }

  // Notes has its own internal sequence: list → detail/create/categories/templates.
  var noteCurrent='list', noteStack=[];
  function notePush(next){if(next&&next!==noteCurrent){noteStack.push(noteCurrent);noteCurrent=next;}}
  function noteReset(){noteCurrent='list';noteStack=[];}
  function noteBack(){
    var prev=noteStack.length?noteStack.pop():null;
    if(prev){noteCurrent=prev;if(typeof window.mfnShow==='function')window.mfnShow(prev);return true;}
    noteCurrent='list';return false;
  }
  function wrap(name,next){
    if(typeof window[name]!=='function'||window['__mfV8W_'+name])return;
    window['__mfV8W_'+name]=true;
    var old=window[name];
    window[name]=function(){var r=next.apply(null,arguments);return old.apply(this,arguments);};
  }
  // Dedicated wrappers are installed directly because the earlier Notes script
  // is loaded before this final coordinator.
  if(typeof window.mfnShow==='function'&&!window.__mfV8W_mfnShow){
    window.__mfV8W_mfnShow=true;var os=window.mfnShow;
    window.mfnShow=function(v){notePush(v);return os.apply(this,arguments);};
  }
  if(typeof window.mfnOpen==='function'&&!window.__mfV8W_mfnOpen){
    window.__mfV8W_mfnOpen=true;var oo=window.mfnOpen;
    window.mfnOpen=function(id){notePush('detail');return oo.apply(this,arguments);};
  }
  if(typeof window.mfnNew==='function'&&!window.__mfV8W_mfnNew){
    window.__mfV8W_mfnNew=true;var on=window.mfnNew;
    window.mfnNew=function(){notePush('create');return on.apply(this,arguments);};
  }
  if(typeof window.mfnEdit==='function'&&!window.__mfV8W_mfnEdit){
    window.__mfV8W_mfnEdit=true;var oe=window.mfnEdit;
    window.mfnEdit=function(){notePush('create');return oe.apply(this,arguments);};
  }
  if(typeof window.mfnUseTemplate==='function'&&!window.__mfV8W_mfnUseTemplate){
    window.__mfV8W_mfnUseTemplate=true;var ot=window.mfnUseTemplate;
    window.mfnUseTemplate=function(i){notePush('detail');return ot.apply(this,arguments);};
  }
  if(typeof window.mfnSaveForm==='function'&&!window.__mfV8W_mfnSaveForm){
    window.__mfV8W_mfnSaveForm=true;var sf=window.mfnSaveForm;
    window.mfnSaveForm=function(){var r=sf.apply(this,arguments);noteCurrent='detail';return r;};
  }
  if(typeof window.mfnDelete==='function'&&!window.__mfV8W_mfnDelete){
    window.__mfV8W_mfnDelete=true;var md=window.mfnDelete;
    window.mfnDelete=function(){var r=md.apply(this,arguments);noteCurrent='list';noteStack=[];return r;};
  }
  if(typeof window.pfOpenNotes==='function'&&!window.__mfV8W_pfOpenNotes){
    window.__mfV8W_pfOpenNotes=true;var pon=window.pfOpenNotes;
    window.pfOpenNotes=function(){noteReset();return pon.apply(this,arguments);};
  }

  function displayed(el){
    if(!el)return false;
    var cs=getComputedStyle(el);
    return cs.display!=='none'&&cs.visibility!=='hidden';
  }
  function closeOverlay(){
    var more=document.getElementById('mfnMoreModal');
    if(more&&more.classList.contains('open')){window.mfnCloseMore&&window.mfnCloseMore();return true;}

    // Notes is a modal, but its internal views must be traversed before closing it.
    var notes=document.getElementById('pfNotesModal');
    if(notes&&notes.classList.contains('open')){
      if(noteBack())return true;
      window.pfCloseFeature&&window.pfCloseFeature('pfNotesModal');
      document.body.style.overflow='';
      return true;
    }

    var fs=Array.from(document.querySelectorAll('.pf-feature-modal.open'));
    if(fs.length){var f=fs[fs.length-1];window.pfCloseFeature?window.pfCloseFeature(f.id):f.classList.remove('open');return true;}
    var ex=document.getElementById('pfExportModal');
    if(ex&&ex.classList.contains('open')){window.pfCloseExport?window.pfCloseExport():ex.classList.remove('open');return true;}

    var maps=[
      ['addTransactionModal','pfCloseAddTransaction'],['editModal','closeEdit'],['historyModal','closeHistory'],
      ['customModal','closeCustomization'],['mfBackupModal','mfCloseBackup'],['mfAccountModal','mfCloseAccount'],
      ['v10ProfileModal','v10CloseProfileModal'],['v10PinModal','v10ClosePinModal'],
      ['v10AddTxPinModal','v10CloseAddTxPinSettings'],['v10AddTxSettingGate','closeSettingGate'],
      ['v10AddTxGate','closeG'],['profilePhotoModal','pfCloseProfilePhotoMenu']
    ];
    for(var i=0;i<maps.length;i++){
      var el=document.getElementById(maps[i][0]);
      if(el&&displayed(el)){
        var fn=window[maps[i][1]];if(typeof fn==='function')fn();else el.style.display='none';
        document.body.style.overflow='';return true;
      }
    }
    var vm=Array.from(document.querySelectorAll('.v10modal')).filter(displayed);
    if(vm.length){vm[vm.length-1].style.display='none';document.body.style.overflow='';return true;}
    var menu=document.getElementById('menuPanel');
    if(menu&&displayed(menu)){window.closeMenu?window.closeMenu():menu.style.display='none';return true;}
    return false;
  }

  window.mfHandleAndroidBack=function(){
    if(closeOverlay())return true;

    // Category history is a sub-step of Transactions.
    if(window.__pfCategoryHistoryFilter){
      window.__pfCategoryHistoryFilter='';
      if(typeof window.pfOpenCategory==='function')window.pfOpenCategory();
      return true;
    }

    var tx=document.getElementById('pfTransactionsPage');
    if(tx&&getComputedStyle(tx).display!=='none'){
      var hb=document.querySelector('.pf-bottom-nav button:nth-child(1)');
      if(typeof window.pfNav==='function')window.pfNav('home',hb);
      else tx.style.display='none';
      if(typeof window.pfSetNav==='function')window.pfSetNav(hb);
      window.scrollTo({top:0,behavior:'smooth'});
      return true;
    }

    // Home is the root. Native Activity will close here.
    return false;
  };
})();



(function(){
  'use strict';
  function today(){
    return typeof localToday==='function' ? localToday() : new Date().toISOString().slice(0,10);
  }
  function hide(el,yes){ if(el) el.style.display=yes?'block':'none'; }
  function resetForm(){
    const d=document.getElementById('date');
    const type=document.getElementById('type');
    const amount=document.getElementById('amountPreset');
    const customAmount=document.getElementById('customAmount');
    const category=document.getElementById('categorySelect');
    const customCategory=document.getElementById('customCategory');
    const mode=document.getElementById('mode');
    if(d){d.max=today();d.value=today();}
    if(type) type.value='';
    if(amount){amount.innerHTML='<option value="" selected>Select amount</option>';amount.value='';}
    if(customAmount){customAmount.value='';customAmount.style.display='none';}
    if(category){category.innerHTML='<option value="" selected>Select category</option>';category.value='';}
    if(customCategory){customCategory.value='';customCategory.style.display='none';}
    if(mode) mode.value='';
    ['description','remark','other'].forEach(function(id){const el=document.getElementById(id);if(el)el.value='';});
  }
  window.pfResetAddTransactionForm=resetForm;

  // Fresh state whenever Add Transaction is opened. Date is the only default.
  const oldOpen=window.pfOpenAddTransaction;
  if(typeof oldOpen==='function' && !window.__mfV17OpenPatched){
    window.__mfV17OpenPatched=true;
    window.pfOpenAddTransaction=function(){
      try{if(typeof closeMenu==='function')closeMenu();}catch(e){}
      resetForm();
      const m=document.getElementById('addTransactionModal');
      if(!m)return;
      m.style.display='block';
      document.body.style.overflow='hidden';
    };
  }

  // Keep dependent choices empty until Type is explicitly selected.
  function applyTypeState(){
    const type=document.getElementById('type');
    if(!type)return;
    const value=type.value;
    if(!value){
      resetForm();
      return;
    }
    // Populate type-specific choices, but do not restore a previous transaction's selection.
    if(typeof window.updateCategories==='function') window.updateCategories();
  }
  const type=document.getElementById('type');
  if(type && !type.__mfV17Bound){
    type.__mfV17Bound=true;
    type.addEventListener('change',applyTypeState);
  }

  // After any successful save, the wrapper also guarantees a clean next-entry state.
  const oldRequest=window.v109RequestAddTransaction;
  if(typeof oldRequest==='function' && !window.__mfV17RequestPatched){
    window.__mfV17RequestPatched=true;
    window.v109RequestAddTransaction=function(){
      const result=oldRequest.apply(this,arguments);
      if(result) resetForm();
      return result;
    };
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',resetForm);
  else resetForm();
})();



(function(){
'use strict';
const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
const sets={
 male:[
  ['M1','#c9e5ff','#253b57','#111827'],['M2','#d8f0e4','#384a3b','#172116'],['M3','#f4ddc7','#5a4030','#20150f'],['M4','#e4d9ff','#463b62','#17131e'],
  ['M5','#d9edf7','#3e5568','#171d23'],['M6','#f0dfc9','#31483b','#101814'],['M7','#e6e7ea','#4b3d35','#171513'],['M8','#d8e9ff','#5c4851','#151218']
 ],
 female:[
  ['F1','#ffdce8','#55394a','#24151c'],['F2','#e5ddff','#4b4164','#17141f'],['F3','#ffe4cf','#6a4b37','#21160f'],['F4','#dff1ea','#3f554d','#18201d'],
  ['F5','#dce9ff','#47556a','#171c25'],['F6','#f5e2d2','#5d3f48','#21151a'],['F7','#e9e0d3','#4a443e','#161513'],['F8','#e4dcff','#4c3a57','#18111c']
 ],
 other:[
  ['O1','#dff4ff','#315267','#111b22'],['O2','#eee2ff','#57416d','#1a1221'],['O3','#e6f1d8','#40543b','#151c13'],['O4','#ffe6d5','#5d493a','#20170f'],
  ['O5','#dce6ef','#42525e','#141b20'],['O6','#f0dff2','#5c415c','#1c121c'],['O7','#e7e7e7','#444','#111'],['O8','#dff1ee','#3c5750','#111b18']
 ]
};
function svgAvatar(kind,bg,shirt,hair){
 const female=kind[0]==='F', other=kind[0]==='O';
 const face=female?'#e2aa86':other?'#c99a7c':'#c78d69';
 const skin2=female?'#b9785c':other?'#a8735b':'#a8664d';
 const eye='#27211e', hair2=hair;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${bg}"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs><rect width="200" height="200" rx="100" fill="url(#g)"/><ellipse cx="100" cy="188" rx="69" ry="50" fill="${shirt}"/><path d="M82 130h36v25c-7 8-29 8-36 0z" fill="${skin2}"/><ellipse cx="100" cy="89" rx="48" ry="57" fill="${face}"/>
 ${female
 ? `<path d="M49 95c-8-42 10-78 51-80 39-2 57 29 51 77l-15-10-9-29c-18 17-38 25-69 26z" fill="${hair2}"/><path d="M52 82c-10 30-3 70 17 89l-12 4c-24-24-27-63-14-94zM148 82c10 30 3 70-17 89l12 4c24-24 27-63 14-94z" fill="${hair2}"/><path d="M73 79q10-8 19 0M108 79q10-8 19 0" fill="none" stroke="${hair2}" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="4.5" ry="6" fill="${eye}"/><ellipse cx="119" cy="93" rx="4.5" ry="6" fill="${eye}"/><path d="M87 117q13 9 26 0" fill="none" stroke="#a35f52" stroke-width="4" stroke-linecap="round"/>`
 : other
 ? `<path d="M52 82c0-43 20-66 48-66 34 0 52 25 48 69-10-5-18-12-27-22-17 19-39 28-69 28z" fill="${hair2}"/><circle cx="100" cy="51" r="8" fill="#6b8cff"/><path d="M72 79q10-7 19 0M109 79q10-7 19 0" fill="none" stroke="#343943" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="5" ry="6" fill="${eye}"/><ellipse cx="119" cy="93" rx="5" ry="6" fill="${eye}"/><path d="M87 116q13 7 26 0" fill="none" stroke="#865b52" stroke-width="4" stroke-linecap="round"/>`
 : `<path d="M52 84c0-43 20-66 48-66 32 0 51 24 48 64-14-8-25-17-39-29-17 22-35 29-57 31z" fill="${hair2}"/><path d="M67 111q7 24 33 24t33-24q-3 35-33 39t-33-39z" fill="${hair2}"/><ellipse cx="81" cy="92" rx="5" ry="7" fill="${eye}"/><ellipse cx="119" cy="92" rx="5" ry="7" fill="${eye}"/><path d="M87 115q13 8 26 0" fill="none" stroke="#8e5148" stroke-width="4" stroke-linecap="round"/><path d="M73 77q8-7 16 0M111 77q8-7 16 0" fill="none" stroke="${hair2}" stroke-width="5" stroke-linecap="round"/>`}</svg>`;
 return 'data:image/svg+xml;charset=UTF-8,'+encodeURIComponent(svg);
}
function read(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function active(){const a=read(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId');return a.find(p=>p&&String(p.id)===String(id))||null}
function photoKey(id){return 'money_flow_profile_photo_'+String(id||'') }
function save(a){localStorage.setItem(PK,JSON.stringify(a))}
function safeSaveProfilePhoto(id,photo){try{localStorage.setItem(photoKey(id),photo);return true}catch(e){return false}}
function getStoredPhoto(p){try{const x=localStorage.getItem(photoKey(p&&p.id));if(x&&x.startsWith('data:image/'))return x}catch(e){}return p&&typeof p.profilePhoto==='string'&&p.profilePhoto.startsWith('data:image/')?p.profilePhoto:''}
function avatarData(g){return (sets[g]||sets.other).map(x=>({id:x[0],src:svgAvatar(x[0],x[1],x[2],x[3])}))}
function ensureGender(p){if(!p)return 'male';if(!['male','female','other'].includes(p.profileGender))p.profileGender='male';return p.profileGender}
function currentPhoto(p){const stored=getStoredPhoto(p);if(stored)return stored;const g=ensureGender(p),arr=avatarData(g);return arr[0].src}
function ensureModal(){
 if(document.getElementById('mf19PhotoModal'))return document.getElementById('mf19PhotoModal');
 const m=document.createElement('div');m.id='mf19PhotoModal';m.className='mf19-photo-modal';m.innerHTML=`<div class="mf19-photo-box" role="dialog" aria-modal="true" aria-labelledby="mf19Title"><div class="mf19-photo-head"><div><h2 id="mf19Title">Choose Profile Photo</h2><p>Select an avatar or upload from your gallery</p></div><button class="mf19-x" type="button" id="mf19Close">×</button></div><div class="mf19-preview" id="mf19Preview"></div><label class="mf19-gallery" for="mf19GalleryInput"><div class="mf19-gallery-icon">🖼️</div><div><b>Click to upload from Gallery</b><small>Choose your own photo</small></div></label><input id="mf19GalleryInput" class="pf-profile-input" type="file" accept="image/*"><div class="mf19-label">Select default avatar</div><div class="mf19-tabs"><button type="button" data-g="male">♂ Male</button><button type="button" data-g="female">♀ Female</button><button type="button" data-g="other">◈ Other</button></div><div class="mf19-grid" id="mf19Grid"></div><div class="mf19-pager"><button type="button" id="mf19Prev">‹</button><span class="mf19-page" id="mf19Page">1 / 2</span><button type="button" id="mf19Next">›</button></div><button type="button" class="mf19-ok" id="mf19OK">OK</button><div class="mf19-hint">This photo belongs only to the current Profile / Mode.</div></div>`;
 document.body.appendChild(m);
 m.addEventListener('click',e=>{if(e.target===m)close()});
 document.getElementById('mf19Close').onclick=close;
 document.getElementById('mf19OK').onclick=commit;
 document.getElementById('mf19Prev').onclick=()=>{state.page=Math.max(0,state.page-1);renderGrid()};
 document.getElementById('mf19Next').onclick=()=>{state.page=Math.min(1,state.page+1);renderGrid()};
 document.querySelectorAll('#mf19PhotoModal .mf19-tabs button').forEach(b=>b.onclick=()=>{state.gender=b.dataset.g;state.page=0;const p=active();state.photo=currentPhoto(p);renderGrid()});
 document.getElementById('mf19GalleryInput').onchange=function(){const f=this.files&&this.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const src=String(r.result);const im=new Image();im.onload=()=>{const max=720,scale=Math.min(1,max/Math.max(im.naturalWidth||im.width,im.naturalHeight||im.height));const w=Math.max(1,Math.round((im.naturalWidth||im.width)*scale)),h=Math.max(1,Math.round((im.naturalHeight||im.height)*scale));const cv=document.createElement('canvas');cv.width=w;cv.height=h;const cx=cv.getContext('2d');cx.drawImage(im,0,0,w,h);state.photo=cv.toDataURL('image/jpeg',0.82);state.gallery=true;renderPreview()};im.onerror=()=>{state.photo=src;state.gallery=true;renderPreview()};im.src=src};r.readAsDataURL(f)};
 return m;
}
let state={gender:'male',page:0,photo:'',gallery:false};
function renderPreview(){const e=document.getElementById('mf19Preview');if(e)e.innerHTML=state.photo?'<img alt="Selected profile photo" src="'+state.photo+'">':''}
function renderGrid(){const grid=document.getElementById('mf19Grid');if(!grid)return;const arr=avatarData(state.gender),start=state.page*4,items=arr.slice(start,start+4);grid.innerHTML=items.map(x=>`<button type="button" class="mf19-avatar ${state.photo===x.src?'active':''}" data-src="${x.src}"><img alt="${x.id} avatar" src="${x.src}"></button>`).join('');grid.querySelectorAll('button').forEach(b=>b.onclick=()=>{state.photo=b.dataset.src;state.gallery=false;renderGrid();renderPreview()});document.getElementById('mf19Page').textContent=(state.page+1)+' / 2';document.getElementById('mf19Prev').disabled=state.page===0;document.getElementById('mf19Next').disabled=state.page===1;document.querySelectorAll('#mf19PhotoModal .mf19-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.g===state.gender));renderPreview()}
function open(){const m=ensureModal(),p=active();state.gender=ensureGender(p);state.page=0;state.gallery=false;state.photo=currentPhoto(p);m.classList.add('open');m.setAttribute('aria-hidden','false');renderGrid()}
function close(){const m=document.getElementById('mf19PhotoModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}}
function commit(){const a=read(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId'),i=a.findIndex(x=>x&&String(x.id)===String(id));if(i<0)return;const q=a[i],photo=state.photo||avatarData(state.gender)[0].src;q.profileGender=state.gender;q.profilePhoto=photo;try{save(a)}catch(e){return}if(!safeSaveProfilePhoto(q.id,photo))return;close();try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}try{if(typeof window.render==='function')window.render()}catch(e){}}
window.pfOpenProfilePhotoMenu=open;window.pfCloseProfilePhotoMenu=close;
// New Profile / Mode starts with a gender-specific default avatar. The user can change it immediately.
const oldCreate=window.v10CreateProfile;
if(typeof oldCreate==='function'&&!window.__mf19CreateWrapped){window.__mf19CreateWrapped=true;window.v10CreateProfile=function(){const r=oldCreate.apply(this,arguments);setTimeout(()=>{const p=active();if(!p)return;const a=read(),i=a.findIndex(x=>x&&String(x.id)===String(p.id));if(i<0)return;const q=a[i];if(!['male','female','other'].includes(String(q.profileGender||'').toLowerCase()))q.profileGender='male';if(!q.profilePhoto)q.profilePhoto=avatarData(q.profileGender)[0].src;save(a);try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}},0);return r;}}
// Replace the old click target with the new picker.
function bind(){const b=document.getElementById('profilePhotoBtn');if(b&&!b.__mf19){b.__mf19=true;b.onclick=open;b.setAttribute('aria-label','Choose profile photo')}const p=active();if(p&&!p.profileGender){p.profileGender='male';if(!p.profilePhoto)p.profilePhoto=avatarData('male')[0].src;const a=read(),i=a.findIndex(x=>x&&x.id===p.id);if(i>=0){a[i]=p;save(a);if(p.profilePhoto)safeSaveProfilePhoto(p.id,p.profilePhoto)}}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();setTimeout(bind,300);setTimeout(bind,1000);
// Keep photo and gender strictly tied to the active mode.
const oldSwitch=window.v10SwitchProfile;
if(typeof oldSwitch==='function'&&!window.__mf19Switch){window.__mf19Switch=true;window.v10SwitchProfile=function(id){const r=oldSwitch.apply(this,arguments);setTimeout(bind,0);setTimeout(()=>{try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}},80);return r;}}
})();



(function(){
'use strict';
const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
function read(){try{const x=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(x)?x:[]}catch(e){return[]}}
function save(a){try{localStorage.setItem(PK,JSON.stringify(a));return true}catch(e){return false}}
function activeId(){return localStorage.getItem(AK)||''}
function safeId(v){return String(v||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}
function isUntouchedAuto(p){
  if(!p)return false;
  const sec=p.security||{};
  return (p.autoGeneratedProfile===true||p.createdManually===false||
    (String(p.name||'')==='My Money' && !Array.isArray(p.transactions)?true:false)) &&
    String(p.name||'')==='My Money' &&
    (!Array.isArray(p.transactions)||p.transactions.length===0) &&
    !p.profilePhoto && !sec.pinHash && !sec.recoveryCode;
}
function editName(id){
  const a=read(),p=a.find(x=>x&&String(x.id)===String(id));if(!p)return;
  const current=String(p.name||'My Money');
  const next=prompt('Edit profile name',current);
  if(next===null)return;
  const name=String(next).trim();
  if(!name){alert('Profile name cannot be empty.');return}
  p.name=name;p.createdManually=true;p.autoGeneratedProfile=false;
  if(save(a)){
    try{if(typeof window.pfScheduleCloudSync==='function')window.pfScheduleCloudSync()}catch(e){}
    try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}
    window.v10OpenProfiles&&window.v10OpenProfiles();
  }
}
window.v33EditProfileName=editName;
function render(){
  const list=document.getElementById('v10ProfileList');if(!list)return;
  const a=read(),aid=activeId()||(a[0]&&a[0].id);if(!a.length)return;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  list.innerHTML=a.map(p=>{
    const src=typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0?p.profilePhoto:'';
    const avatar=src?'<img class="mf-v33-profile-list-photo" alt="Profile photo" src="'+esc(src)+'">':'<div class="mf-v33-profile-list-photo mf-v33-profile-placeholder">👤</div>';
    const id=safeId(p.id),name=esc(p.name||'My Money'),isA=String(p.id)===String(aid);
    return '<div class="v10row mf-v33-profile-row">'+avatar+'<div class="mf-v33-profile-info"><b>'+name+'</b><div class="v10small">'+(isA?'Active profile':'Separate profile')+'</div></div><div class="mf-v33-profile-actions"><button type="button" class="secondary" onclick="v33EditProfileName(\''+id+'\')">✎ Edit Name</button><button type="button" class="mf-v33-switch-btn" '+(isA?'disabled':'')+' onclick="v10SwitchProfile(\''+id+'\')">'+(isA?'Active':'Switch')+'</button></div></div>';
  }).join('');
}
function cleanupPlaceholders(){
  const a=read();if(!a.length)return;
  const auto=a.filter(isUntouchedAuto),real=a.filter(p=>!isUntouchedAuto(p));
  let kept;
  if(real.length){
    /* Manual/real profiles always win; synthetic My Money placeholders are
       never allowed to remain beside them. */
    kept=real;
  }else if(auto.length){
    /* If the entire list consists only of synthetic defaults, keep exactly
       one. Prefer the currently active one so switching is not disturbed. */
    const aid=activeId();
    const one=auto.find(p=>String(p.id)===String(aid))||auto[0];
    kept=[one];
  }else{return}
  if(kept.length!==a.length){
    const aid=activeId();
    const activeKept=kept.find(p=>String(p.id)===String(aid))||kept[0];
    save(kept);
    if(activeKept)localStorage.setItem(AK,String(activeKept.id));
    try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}
  }
}
// Install after the later legacy profile modules have finished defining their globals.
function installV33(){
  const oldOpen=window.v10OpenProfiles;
  if(typeof oldOpen==='function'&&!oldOpen.__mfV33){
    function wrapped(){oldOpen.apply(this,arguments);setTimeout(render,0)}
    wrapped.__mfV33=true;window.v10OpenProfiles=wrapped;
  }
}
installV33();setTimeout(installV33,250);setTimeout(installV33,900);
function installRestoreHook(){
  const oldRestore=window.mfCloudRestoreResult;
  if(typeof oldRestore==='function'&&!oldRestore.__mfV33){
    function wrappedRestore(){const r=oldRestore.apply(this,arguments);setTimeout(function(){migrateMarkers();cleanupPlaceholders();render()},180);return r}
    wrappedRestore.__mfV33=true;window.mfCloudRestoreResult=wrappedRestore;
  }
}
setTimeout(installRestoreHook,250);setTimeout(installRestoreHook,900);setTimeout(installRestoreHook,1800);
// Mark all profiles that clearly predate the manual-create marker without changing their data.
function migrateMarkers(){
  const a=read();if(!a.length)return;
  let changed=false;
  const myMoney=a.filter(p=>String(p&&p.name||'')==='My Money');
  const firstMyMoney=myMoney[0]&&myMoney[0].id;
  a.forEach((p)=>{
    if(!p||typeof p!=='object')return;
    if(typeof p.createdManually!=='boolean'&&typeof p.autoGeneratedProfile!=='boolean'){
      const hasRealData=(Array.isArray(p.transactions)&&p.transactions.length>0)||!!p.profilePhoto||!!(p.security&&p.security.pinHash);
      if(hasRealData)p.createdManually=true;
      else if(String(p.name||'')==='My Money' && myMoney.length>1 && String(p.id)!==String(firstMyMoney))p.autoGeneratedProfile=true;
      else p.createdManually=true;
      changed=true;
    }
  });
  if(changed)save(a);
}
migrateMarkers();
// This cleanup is intentionally conservative: it removes only untouched auto placeholders.
cleanupPlaceholders();
window.addEventListener('storage',function(e){if(e&&e.key===PK){migrateMarkers();cleanupPlaceholders();render()}});
window.addEventListener('load',function(){setTimeout(function(){migrateMarkers();cleanupPlaceholders()},250);setTimeout(render,300)});
})();



/* V24 PROFILE/MODE ISOLATION FINAL
   A Profile/Mode is a separate app environment for security.
   Switching profiles NEVER asks for the previous profile PIN.
   Security belongs only to the active profile object.
*/
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function ps(){try{const x=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
  function active(){const a=ps(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function ensure(p){
    if(!p)return null;
    if(!p.security || typeof p.security!=="object") p.security={};
    const d={mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,addProtection:false,bioEnabled:false};
    for(const k in d) if(p.security[k]===undefined) p.security[k]=d[k];
    return p;
  }
  // Remove only legacy GLOBAL security storage. Per-profile security is retained.
  try{
    ["money_manager_edit_security_v1","mm_global_pin","globalPin","globalPinHash","pinHash"].forEach(k=>localStorage.removeItem(k));
  }catch(e){}
  let p=ensure(active()); if(p){const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=p.security;save(a)}}

  // Replace the security getter used by the final flows so it can never migrate
  // a PIN from another profile.
  window.mmV24ActiveSecurity=function(){
    const a=ps(),p=ensure(active());
    if(!p)return null;
    const q=a.find(x=>x.id===p.id); if(q){q.security=p.security;save(a)}
    return p.security;
  };

  // Profile switch is deliberately security-free. The destination profile's
  // own security is loaded only after the switch.
  window.v10SwitchProfile=function(id){
    const a=ps(),p=a.find(x=>x.id===id);if(!p)return;
    ensure(p);
    localStorage.setItem(AK,id);
    localStorage.setItem("money_manager_active_profile_v10",id);
    // Clear only transient attempt/lock state; destination profile starts with its own.
    try{sessionStorage.removeItem("mm_v19_pin_attempts");sessionStorage.removeItem("mm_v19_pin_lock_until")}catch(e){}
    if(typeof txs!=="undefined"){
      txs=Array.isArray(p.transactions)?p.transactions:[];
      try{localStorage.setItem(typeof KEY!=="undefined"?KEY:"transactions",JSON.stringify(txs))}catch(e){}
    }
    if(typeof config!=="undefined" && p.config) config=p.config;
    if(typeof render==="function") render();
    const badge=document.getElementById("profileBadge");if(badge)badge.textContent=p.name;
    const m=document.getElementById("v10ProfileModal");if(m)m.style.display="none";
  };

  // Profile-aware 5-attempt protection. Each profile gets its own counter.
  window.mmV19CheckPin=function(pin, expectedHash, hashFn){
    const p=active(); if(!p)return false; ensure(p);
    const s=p.security;
    const now=Date.now();
    const until=Number(s.pinLockUntil||0);
    if(until>now){alert("Too many incorrect PIN attempts. Please wait "+Math.ceil((until-now)/1000)+" seconds.");return false;}
    if(until && until<=now){s.pinLockUntil=0;s.pinFailedAttempts=0;}
    if(hashFn(pin)!==expectedHash){
      s.pinFailedAttempts=Number(s.pinFailedAttempts||0)+1;
      if(s.pinFailedAttempts>=5){s.pinFailedAttempts=0;s.pinLockUntil=Date.now()+30000;}
      const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=s;save(a)}
      if(s.pinLockUntil){alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");}
      else alert("Incorrect PIN. Attempts remaining: "+(5-s.pinFailedAttempts)+".");
      return false;
    }
    s.pinFailedAttempts=0;s.pinLockUntil=0;
    const a=ps(),q=a.find(x=>x.id===p.id);if(q){q.security=s;save(a)}
    return true;
  };

  // Prevent the older v10ActiveSecurity/mmSec implementations from importing
  // the legacy global PIN into the current profile.
  const cleanSecurity=function(){return window.mmV24ActiveSecurity()};
  window.mmV24CleanSecurity=cleanSecurity;

  // Add/edit gate wrappers use the active profile's security only.
  const oldAsk=window.mmAskPin;
  window.mmV24AskPin=function(onSuccess,onCancel){
    const s=cleanSecurity();
    if(!s){alert("Profile is not ready.");return;}
    if(!s.pinHash){
      // Delegate to existing custom gate, but its PIN creation is stored on active profile.
      if(typeof oldAsk==="function") return oldAsk(onSuccess,onCancel);
      return;
    }
    if(typeof oldAsk==="function") return oldAsk(onSuccess,onCancel);
  };
})();



/* V26 — ONE PROFILE SECURITY STATE
   Fixes:
   1) Edit must never create a second PIN if Menu already created one.
   2) Menu/Edit/Add must read/write the SAME active profile.security object.
   3) Legacy global edit PIN storage is no longer authoritative.
*/
(function(){
  const PK="money_manager_profiles_v10";
  const AK="money_manager_active_profile_v10";

  const freshSecurity=()=>({
    mode:"NONE",pinHash:"",recoveryCode:"",editPinLost:false,
    addProtection:false,bioEnabled:false,
    pinFailedAttempts:0,pinLockUntil:0,
    profileSecurityInitialized:true
  });

  function profiles(){
    try{
      const a=JSON.parse(localStorage.getItem(PK)||"[]");
      return Array.isArray(a)?a:[];
    }catch(e){return[]}
  }
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function active(){
    const a=profiles(),id=localStorage.getItem(AK);
    return a.find(p=>p.id===id)||a[0]||null;
  }
  function activeSecurity(){
    const p=active();
    if(!p)return null;
    if(!p.security||typeof p.security!=="object")p.security=freshSecurity();
    if(typeof p.security.addProtection!=="boolean")p.security.addProtection=false;
    if(p.security.profileSecurityInitialized!==true){
      // The active profile is the only profile whose pre-existing security
      // can safely be retained; inactive uninitialized profiles are fresh.
      p.security.profileSecurityInitialized=true;
    }
    const a=profiles(),q=a.find(x=>x.id===p.id);
    if(q)q.security=p.security;
    save(a);
    return p.security;
  }

  // Stop the old v109Profiles routine from importing money_manager_edit_security_v1.
  window.v109Profiles=profiles;
  window.v109ActiveProfile=active;
  window.v109SaveProfiles=save;

  // Stop legacy global storage from participating in security decisions.
  try{
    localStorage.removeItem("money_manager_edit_security_v1");
    localStorage.removeItem("mm_global_pin");
    localStorage.removeItem("globalPin");
    localStorage.removeItem("globalPinHash");
    localStorage.removeItem("pinHash");
  }catch(e){}

  function H(v){
    let h=2166136261;v=String(v||"");
    for(let i=0;i<v.length;i++){h^=v.charCodeAt(i);h=Math.imul(h,16777619)}
    return (h>>>0).toString(16);
  }
  function recovery(){
    const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";
    for(let i=0;i<12;i++){if(i&&i%4===0)s+="-";s+=c[Math.floor(Math.random()*c.length)]}
    return s;
  }

  function persist(sec){
    const p=active();if(!p)return;
    p.security=sec;
    const a=profiles(),q=a.find(x=>x.id===p.id);
    if(q)q.security=sec;
    save(a);
  }

  // Shared PIN verifier used by both the normal PIN gate and native biometric settings.
  // This prevents the biometric settings screen from using a different/stale PIN source.
  window.mmV26VerifyPin=function(pin){
    const s=activeSecurity();
    if(!s || !s.pinHash) return false;
    return H(String(pin||""))===s.pinHash;
  };

  // Unified PIN gate. It uses the same custom Add/Edit gate already in V25.
  window.v26AskPin=function(ok,cancel){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return false;}

    const gate=document.getElementById("v10AddTxGate");
    const body=document.getElementById("v10AddTxGateBody");
    if(!gate||!body){alert("PIN security screen is unavailable.");return false;}

    if(!s.pinHash){
      body.innerHTML=
        '<h3>🔐 Create PIN</h3>'+
        '<p>Create one 4–6 digit PIN. This same PIN will be used for <b>Edit</b>, <b>Add Transaction</b>, and security settings.</p>'+
        '<input id="v26NewPin" type="password" inputmode="numeric" maxlength="6" placeholder="New 4–6 digit PIN">'+
        '<input id="v26ConfirmPin" type="password" inputmode="numeric" maxlength="6" placeholder="Confirm PIN">'+
        '<button type="button" id="v26CreatePin">Create PIN</button>'+
        '<button type="button" class="secondary" id="v26CancelPin">Cancel</button>';
      gate.style.display="block";
      document.getElementById("v26CreatePin").onclick=function(){
        const a=document.getElementById("v26NewPin").value;
        const b=document.getElementById("v26ConfirmPin").value;
        if(!/^\d{4,6}$/.test(a)){alert("PIN must contain 4–6 digits.");return}
        if(a!==b){alert("PINs do not match.");return}
        s.pinHash=H(a);
        s.recoveryCode=s.recoveryCode||recovery();
        s.profileSecurityInitialized=true;
        persist(s);
        body.innerHTML=
          '<h3>✅ PIN Created</h3>'+
          '<p>Save this Recovery Code safely:</p>'+
          '<div class="v10code">'+s.recoveryCode+'</div>'+
          '<p class="v10small">This PIN is shared by Edit and Add Transaction.</p>'+
          '<button type="button" id="v26ContinuePin">Continue</button>';
        document.getElementById("v26ContinuePin").onclick=function(){
          gate.style.display="none"; if(typeof ok==="function")ok();
        };
      };
      document.getElementById("v26CancelPin").onclick=function(){
        gate.style.display="none";if(typeof cancel==="function")cancel();
      };
      return false;
    }

    body.innerHTML=
      '<h3>🔐 Enter PIN</h3>'+
      '<p>Enter your existing profile PIN.</p>'+
      '<input id="v26PinInput" type="password" inputmode="numeric" maxlength="6" placeholder="Enter PIN">'+
      '<button type="button" id="v26VerifyPin">Continue</button>'+
      '<button type="button" class="secondary" id="v26CancelVerify">Cancel</button>';
    gate.style.display="block";

    document.getElementById("v26VerifyPin").onclick=function(){
      const pin=document.getElementById("v26PinInput").value;
      const now=Date.now(),until=Number(s.pinLockUntil||0);
      if(until>now){
        alert("Too many incorrect PIN attempts. Please wait "+Math.ceil((until-now)/1000)+" seconds.");
        return;
      }
      if(until&&until<=now){s.pinLockUntil=0;s.pinFailedAttempts=0;persist(s);}
      if(H(pin)!==s.pinHash){
        s.pinFailedAttempts=Number(s.pinFailedAttempts||0)+1;
        if(s.pinFailedAttempts>=5){
          s.pinFailedAttempts=0;s.pinLockUntil=Date.now()+30000;
          persist(s);
          alert("5 incorrect PIN attempts. Please wait 30 seconds before trying again.");
        }else{
          persist(s);
          alert("Incorrect PIN. Attempts remaining: "+(5-s.pinFailedAttempts)+".");
        }
        return;
      }
      s.pinFailedAttempts=0;s.pinLockUntil=0;persist(s);
      gate.style.display="none";if(typeof ok==="function")ok();
    };
    document.getElementById("v26CancelVerify").onclick=function(){
      gate.style.display="none";if(typeof cancel==="function")cancel();
    };
    return false;
  };

  // Add Transaction always uses the active profile's addProtection.
  window.v109RequestAddTransaction=function(){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return false;}
    if(!s.addProtection){
      return typeof v109RealAdd==="function" ? v109RealAdd() : false;
    }
    return window.v26AskPin(
      function(){ if(typeof v109RealAdd==="function")v109RealAdd(); },
      function(){}
    );
  };

  // Edit always uses the SAME gate/state.
  window.v10RequestEdit=function(id){
    const t=(typeof txs!=="undefined"?txs:[]).find(x=>x.id===id);
    if(!t)return;
    if(typeof canEditTransaction==="function"&&!canEditTransaction(t)){
      alert("This transaction is locked. Editing is allowed only within 5 days of adding it.");
      return;
    }
    window.v26AskPin(function(){
      document.getElementById("editId").value=id;
      const editDate=document.getElementById("editDate");
      if(editDate)editDate.max=localToday();
      document.getElementById("editDate").value=t.date;
      document.getElementById("editType").value=t.type;
      document.getElementById("editAmount").value=t.amount;
      document.getElementById("editCategory").value=t.category||"";
      document.getElementById("editMode").value=t.mode||"UPI";
      document.getElementById("editDescription").value=t.description||"";
      document.getElementById("editRemark").value=t.remark||"";
      document.getElementById("editOther").value=t.other||"";
      document.getElementById("editModal").style.display="block";
    },function(){});
  };

  // Menu ON/OFF uses the same active profile security and the same PIN gate.
  window.v10SaveAddTxPinSetting=function(desired){
    const s=activeSecurity();
    if(!s){alert("Profile is not ready.");return;}
    desired=!!desired;
    if(!!s.addProtection===desired){
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
      return;
    }
    window.v26AskPin(function(){
      const ss=activeSecurity();
      if(!ss)return;
      ss.addProtection=desired;
      persist(ss);
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
    },function(){
      if(typeof v10RefreshAddTxSecurityUI==="function")v10RefreshAddTxSecurityUI();
    });
  };
  window.v10ChooseAddTxSecurity=function(desired){window.v10SaveAddTxPinSetting(!!desired);};

  // Expose the same security object to any later V25/V24 compatibility calls.
  window.mmV26ActiveSecurity=activeSecurity;
  window.mmV24ActiveSecurity=activeSecurity;
})();



/* V27 — EXPORT/PRINT ALWAYS READS THE ACTIVE PROFILE'S TRANSACTIONS */
(function(){
  function activeProfileTransactions(){
    try{
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x.id===id);
      if(p && Array.isArray(p.transactions)) return p.transactions.slice();
    }catch(e){}
    return (typeof txs!=="undefined" && Array.isArray(txs)) ? txs.slice() : [];
  }

  // Make date-range filtering use the active profile, not a stale global txs array.
  window.v27FilteredTransactions=function(){
    const r=typeof getDateRange==="function"?getDateRange():{from:"",to:""};
    if(!r)return null;
    return activeProfileTransactions()
      .filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to))
      .sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  };

  // Replace the function used by Excel/PDF export.
  window.filteredTransactions=function(){
    return window.v27FilteredTransactions();
  };

  // Keep global txs synchronized whenever export is opened/used.
  window.v27SyncTransactions=function(){
    const data=activeProfileTransactions();
    try{
      if(typeof txs!=="undefined"){
        txs.length=0;
        data.forEach(t=>txs.push(t));
      }
    }catch(e){}
    return data;
  };

  // Ensure profile data is persisted immediately before export.
  window.v27PersistCurrentTransactions=function(){
    try{
      if(typeof txs==="undefined"||!Array.isArray(txs))return;
      const ps=JSON.parse(localStorage.getItem("money_manager_profiles_v10")||"[]");
      const id=localStorage.getItem("money_manager_active_profile_v10");
      const p=ps.find(x=>x.id===id);
      if(p){
        p.transactions=txs.slice();
        localStorage.setItem("money_manager_profiles_v10",JSON.stringify(ps));
      }
    }catch(e){}
  };

  // Patch the existing export functions without changing their UI.
  const oldCSV=window.exportCSV;
  if(typeof oldCSV==="function"){
    window.exportCSV=function(){
      v27SyncTransactions();
      v27PersistCurrentTransactions();
      return oldCSV.apply(this,arguments);
    };
  }
  const oldExcel=window.exportExcel;
  if(typeof oldExcel==="function"){
    window.exportExcel=function(){
      v27SyncTransactions();
      return oldExcel.apply(this,arguments);
    };
  }
  const oldPDF=window.exportPDF;
  if(typeof oldPDF==="function"){
    function makeTransactionTablePDF(data, from, to, income, expense, finalBalance){
    // Spreadsheet-style PDF: same 9-column order as Excel.
    const width=842, height=595, margin=28, top=38, bottom=30;
    const colW=[60,58,70,70,80,125,100,100,90];
    const headers=["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"];
    const fontSize=7.2, lineH=10, headerH=18, pad=3;
    const usableW=colW.reduce((a,b)=>a+b,0);
    const maxY=height-bottom;
    const rows=[];
    let bal=0;
    data.forEach(t=>{
      const amount=Number(t.amount)||0;
      bal += t.type==="CREDIT" ? amount : -amount;
      rows.push([
        t.date||"", t.type||"", amount.toFixed(2), bal.toFixed(2), t.category||"",
        t.description||"", t.remark||"", t.mode||"", t.other||""
      ]);
    });

    // Conservative wrapping for Helvetica so long values never overlap adjacent columns.
    function safeText(v){
      return String(v??"").replace(/[^\x20-\x7E]/g,"?");
    }
    function wrap(text, w){
      text=safeText(text);
      const approx=Math.max(5,Math.floor((w-pad*2)/(fontSize*0.52)));
      if(!text)return [""];
      const out=[];
      let cur="";
      text.split(/\s+/).forEach(word=>{
        if(!word)return;
        if(word.length>approx){
          if(cur){out.push(cur);cur="";}
          for(let i=0;i<word.length;i+=approx) out.push(word.slice(i,i+approx));
        }else if(!cur) cur=word;
        else if((cur+" "+word).length<=approx) cur+=" "+word;
        else {out.push(cur);cur=word;}
      });
      if(cur)out.push(cur);
      return out.length?out:[""];
    }

    function rowLines(row){
      const cells=row.map((v,i)=>wrap(v,colW[i]));
      return {cells,n:Math.max(...cells.map(c=>c.length)),h:Math.max(18,Math.max(...cells.map(c=>c.length))*lineH+4)};
    }
    const prepared=rows.map(rowLines);
    const pages=[]; let page=[]; let y=top+28;
    for(const r of prepared){
      if(y+r.h>maxY && page.length){pages.push(page);page=[];y=top+28;}
      page.push(r); y+=r.h;
    }
    if(page.length||!pages.length)pages.push(page);

    let objs=[]; const add=o=>{objs.push(o);return objs.length;};
    const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    const pageIds=[], contentIds=[];

    function esc(s){return pdfEscape(safeText(s));}
    pages.forEach((pg,pi)=>{
      let stream="q\n";
      // Title / period
      stream+=`BT\n/F1 10 Tf\n1 0 0 1 ${margin} ${height-28} Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n`;
      stream+=`/F1 8 Tf\n1 0 0 1 ${margin} ${height-40} Tm (${esc(`Period: ${from} to ${to}`)}) Tj\nET\n`;

      const tableTop=height-55;
      let yy=tableTop;
      function drawCell(x,y,w,h,texts,bold){
        stream+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\n`;
        stream+=`BT\n/F1 ${bold?7.5:fontSize} Tf\n`;
        texts.forEach((tx,i)=>{
          const ty=y-pad-7-i*lineH;
          stream+=`1 0 0 1 ${x+pad} ${ty} Tm (${esc(tx)}) Tj\n`;
        });
        stream+="ET\n";
      }
      // Header row
      let x=margin;
      headers.forEach((h,i)=>{drawCell(x,yy,colW[i],headerH,[h],true);x+=colW[i];});
      yy-=headerH;

      pg.forEach(r=>{
        x=margin;
        r.cells.forEach((cell,i)=>{drawCell(x,yy,colW[i],r.h,cell,false);x+=colW[i];});
        yy-=r.h;
      });

      if(pi===pages.length-1){
        yy-=12;
        stream+=`BT\n/F1 8.5 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("SUMMARY")}) Tj\n`;
        yy-=12; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Total Credit: Rs.${income.toFixed(2)}`)}) Tj\n`;
        yy-=11; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Total Expense: Rs.${expense.toFixed(2)}`)}) Tj\n`;
        yy-=11; stream+=`1 0 0 1 ${margin} ${yy} Tm (${esc(`Net Balance: Rs.${finalBalance.toFixed(2)}`)}) Tj\nET\n`;
      }
      stream+="Q";
      const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
      contentIds.push(cid); pageIds.push(null);
    });
    const pagesId=add("PAGES_PLACEHOLDER");
    pages.forEach((_,i)=>{
      pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`);
    });
    objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;
    const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let pdf="%PDF-1.4\n", offsets=[0];
    objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});
    const xref=pdf.length;
    pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
    for(let i=1;i<=objs.length;i++)pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
    pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return new Blob([pdf],{type:"application/pdf"});
  }
  window.mm31MakeTransactionTablePDF=makeTransactionTablePDF;

  window.exportPDF=function(){
    const data=mm31Filtered();
    if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const r=mm31Range();
    const from=r.from||data[0].date;
    const to=r.to||data[data.length-1].date;
    let income=0,expense=0,balance=0;
    data.forEach(t=>{
      const amount=Number(t.amount)||0;
      if(t.type==="CREDIT") income+=amount; else expense+=amount;
      balance+=t.type==="CREDIT"?amount:-amount;
    });
    downloadBlob(
      makeTransactionTablePDF(data,from,to,income,expense,balance),
      `money_transactions_${from}_to_${to}.pdf`
    );
  };
}
})();



/* V30 — FINAL ADD TRANSACTION CORE
   Fixes the actual failure point by making one function responsible for:
   form validation -> transaction creation -> active-profile persistence ->
   legacy-store persistence -> render.
   It intentionally does not alter PIN/profile UI or Edit logic.
*/
(function(){
  function mm30Profiles(){
    try{
      const ps = JSON.parse(localStorage.getItem("money_manager_profiles_v10") || "[]");
      return Array.isArray(ps) ? ps : [];
    }catch(e){ return []; }
  }

  function mm30Active(ps){
    const id = localStorage.getItem("money_manager_active_profile_v10");
    return ps.find(p => p && p.id === id) || ps[0] || null;
  }

  function mm30Save(ps){
    localStorage.setItem("money_manager_profiles_v10", JSON.stringify(ps));
  }

  function mm30Today(){
    if(typeof localToday === "function") return localToday();
    return new Date().toISOString().slice(0,10);
  }

  function mm30Sort(a,b){
    const d = String(b.date||"").localeCompare(String(a.date||""));
    if(d) return d;
    const ca = new Date(a.createdAt || 0).getTime();
    const cb = new Date(b.createdAt || 0).getTime();
    return cb-ca || Number(b.id||0)-Number(a.id||0);
  }

  function mm30Read(id){
    const e = document.getElementById(id);
    return e ? e.value : "";
  }

  function mm30AddCore(){
    try{
      const dateEl = document.getElementById("date");
      const typeEl = document.getElementById("type");
      const amountPresetEl = document.getElementById("amountPreset");
      const customAmountEl = document.getElementById("customAmount");
      const categoryEl = document.getElementById("categorySelect");
      const customCategoryEl = document.getElementById("customCategory");

      if(!dateEl || !typeEl || !amountPresetEl || !categoryEl){
        alert("Add Transaction form is not ready.");
        return false;
      }

      const today = mm30Today();
      dateEl.max = today;

      const date = dateEl.value;
      const type = typeEl.value;
      const preset = amountPresetEl.value;
      const amount = preset === "CUSTOM"
        ? Number(customAmountEl && customAmountEl.value)
        : Number(preset);

      const selectedCategory = categoryEl.value;
      const category = selectedCategory === "CUSTOM"
        ? String(customCategoryEl && customCategoryEl.value || "").trim()
        : selectedCategory;

      if(!date || date > today){
        dateEl.value = today;
        alert("Please select today or an earlier date.");
        return false;
      }

      if(type!=="CREDIT" && type!=="EXPENSE"){
        alert("Please select Credit or Expense.");
        return false;
      }

      if(!Number.isFinite(amount) || amount <= 0){
        alert("Please enter a valid amount.");
        return false;
      }

      if(!category){
        alert("Please select or enter a category.");
        return false;
      }

      const ps = mm30Profiles();
      const p = mm30Active(ps);

      if(!p){
        alert("Profile is not ready. Please open Profile / Mode once and try again.");
        return false;
      }

      p.transactions = Array.isArray(p.transactions) ? p.transactions : [];

      // Active profile is authoritative. This prevents stale/old global txs
      // from replacing the current profile's transaction list.
      const current = p.transactions.map(t => ({...t}));

      const tx = {
        id: Date.now() + Math.floor(Math.random()*1000),
        createdAt: new Date().toISOString(),
        date: date,
        type: type,
        amount: amount,
        category: category,
        description: mm30Read("description").trim(),
        remark: mm30Read("remark").trim(),
        mode: mm30Read("mode").trim(),
        other: mm30Read("other").trim()
      };

      current.push(tx);
      current.sort(mm30Sort);

      // Save to the active profile first.
      p.transactions = current;
      const index = ps.findIndex(x => x && x.id === p.id);
      if(index < 0){
        alert("Active profile could not be saved.");
        return false;
      }
      ps[index] = p;
      mm30Save(ps);

      // Keep the legacy transaction store and in-memory list synchronized.
      txs = current.map(t => ({...t}));
      localStorage.setItem(
        typeof KEY !== "undefined" ? KEY : "money_manager_v1",
        JSON.stringify(txs)
      );

      // Render only after persistence succeeds.
      if(typeof render === "function") render();

      // Reset the complete Add Transaction form after a successful save.
      // Only today's date is preselected for the next transaction.
      if(typeof window.pfResetAddTransactionForm === "function") window.pfResetAddTransactionForm();
      if(typeof v10RefreshAddTxSecurityUI === "function") v10RefreshAddTxSecurityUI();

      // Close the actual Add Transaction sheet only after the final save succeeds.
      // This is inside the authoritative save core, so it also works after PIN verification.
      if(typeof window.pfCloseAddTransaction === "function") window.pfCloseAddTransaction();

      return true;
    }catch(err){
      console.error("V30 Add Transaction error:", err);
      alert("Transaction could not be saved. Please try again.");
      return false;
    }
  }

  // Replace only the transaction-writing core. Existing PIN/recovery gate
  // remains responsible for authentication before this function is called.
  window.v109RealAdd = mm30AddCore;

  // Final request handler: OFF -> direct save; ON -> existing common PIN gate.
  window.v109RequestAddTransaction = function(){
    try{
      const ps = mm30Profiles();
      const p = mm30Active(ps);

      if(!p){
        alert("Profile is not ready.");
        return false;
      }

      p.security = p.security || {};
      const protection = !!p.security.addProtection;

      if(!protection){
        return mm30AddCore();
      }

      // Reuse the existing unified PIN gate from V26/V19.
      if(typeof window.v26AskPin === "function"){
        return window.v26AskPin(
          function(){ mm30AddCore(); },
          function(){}
        );
      }

      alert("PIN security interface is unavailable.");
      return false;
    }catch(err){
      console.error("V30 Add Transaction request error:", err);
      alert("Add Transaction could not be started.");
      return false;
    }
  };

  console.log("Money Manager V30: Add Transaction core loaded.");
})();



/* V30 Android native biometric integration.
   The browser/WebAuthn path remains intact outside APK. In the APK, AndroidBiometric
   uses the real Android BiometricPrompt and falls back to the existing PIN gate. */
(function(){
  const PK="money_manager_profiles_v10", AK="money_manager_active_profile_v10";
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||"[]");return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=profiles(),id=localStorage.getItem(AK);return a.find(p=>p.id===id)||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function sec(){const p=active();if(!p)return null;p.security=p.security||{};if(typeof p.security.bioEnabled!=="boolean")p.security.bioEnabled=false;return p.security}
  function setStatus(){const s=sec();const on=!!(s&&s.bioEnabled);const item=document.getElementById("v30BioMenuItem");if(item)item.textContent=on?"🔐 Fingerprint / Biometric: ON":"🔐 Fingerprint / Biometric: OFF";const st=document.getElementById("v30BioStatus");if(st)st.textContent=on?"ON — biometric first; PIN fallback":"OFF — PIN is used normally"}
  function nativeAvailable(){try{return !!(window.AndroidBiometric&&AndroidBiometric.isAvailable&&AndroidBiometric.isAvailable())}catch(e){return false}}

  // Override the biometric settings UI only; all existing app data/settings remain untouched.
  // IMPORTANT: biometric setup follows the same PIN prerequisite as the other
  // security actions. If this active Profile X has no PIN yet, show the
  // canonical Create PIN flow first; never jump directly to PIN verification.
  window.v30OpenBiometricSettings=function(){
    if(typeof closeMenu==="function")closeMenu();

    // Use the same canonical active-profile security state used by PIN Setup
    // and Transaction Log. Biometric setup must NEVER request a PIN that does
    // not exist. First create the active Profile / Mode PIN, then return here.
    const current=active();
    const currentSec=(typeof window.v10ActiveSecurity==="function")
      ? (window.v10ActiveSecurity()||{})
      : (current&&current.security||{});
    if(!currentSec.pinHash){
      if(typeof window.mfRequestCommonSecurity==="function"){
        window.mfRequestCommonSecurity(function(){
          window.v30OpenBiometricSettings();
        },null,"biometric");
      }else{
        alert("Please create your Profile PIN first. Biometric setup requires the Profile PIN.");
      }
      return;
    }
    let m=document.getElementById("v30NativeBioModal");
    if(!m){
      m=document.createElement("div");m.id="v30NativeBioModal";m.className="v10modal";
      m.innerHTML='<div class="v10box"><h2>🔐 Fingerprint / Biometric</h2><p id="v30NativeBioStatus" class="v10small"></p><button type="button" id="v30NativeBioToggle">Turn ON</button><button type="button" class="secondary" id="v30NativeBioClose">Close</button></div>';
      document.body.appendChild(m);
      document.getElementById("v30NativeBioToggle").onclick=function(){
        const p=active(),s=sec();if(!p||!s)return;

        // Defensive second check at the moment the user taps Turn ON/OFF.
        // This prevents a stale biometric modal from bypassing the normal
        // first-time Create PIN flow after a Profile / Mode switch.
        if(!s.pinHash){
          m.style.display="none";
          if(typeof window.mfRequestCommonSecurity==="function"){
            window.mfRequestCommonSecurity(function(){
              window.v30OpenBiometricSettings();
            },null,"biometric");
          }else{
            alert("No PIN is created for this Profile / Mode. Please create the PIN first.");
          }
          return;
        }

        if(!nativeAvailable()){alert("Biometric is not available on this Android device. PIN remains available.");return;}
        const pin=prompt(s.bioEnabled?"Enter your current PIN to disable Biometric:":"Enter your current PIN to enable Biometric:");
        if(pin===null)return;
        // Verify against the exact same active-profile PIN used by Edit/Add/security.
        if(typeof window.mmV26VerifyPin!=="function" || !window.mmV26VerifyPin(String(pin||""))){alert("Incorrect PIN.");return;}
        if(s.bioEnabled){s.bioEnabled=false;const ps=profiles();const q=ps.find(x=>x.id===p.id);if(q)q.security=s;save(ps);setStatus();refresh();alert("Biometric is OFF. PIN will be used.");return;}
        window.__v30BioTogglePending=function(ok){
          window.__v30BioTogglePending=null;
          if(!ok){alert("Biometric verification was cancelled or failed. Biometric remains OFF.");return;}
          s.bioEnabled=true;const ps=profiles();const q=ps.find(x=>x.id===p.id);if(q)q.security=s;save(ps);setStatus();refresh();alert("Biometric is ON. Security actions will show the biometric prompt first; PIN is the fallback.");
        };
        AndroidBiometric.authenticate("v30BioToggleResult");
      };
      document.getElementById("v30NativeBioClose").onclick=function(){m.style.display="none"};
    }
    function refresh(){const s=sec(),on=!!(s&&s.bioEnabled);const st=document.getElementById("v30NativeBioStatus");const b=document.getElementById("v30NativeBioToggle");if(st)st.textContent=on?"ON — biometric first; if unavailable/cancelled, PIN is shown.":"OFF — PIN is used normally.";if(b)b.textContent=on?"Turn OFF":"Turn ON / Verify Biometric";setStatus();}
    refresh();m.style.display="block";
  };
  window.v30BioToggleResult=function(ok){if(typeof window.__v30BioTogglePending==="function")window.__v30BioTogglePending(!!ok)};

  // Native biometric-first gate for the unified PIN flow used by Edit/Add/security.
  const original=window.v26AskPin;
  if(typeof original==="function" && !window.__v30NativeBioWrapped){
    window.__v30NativeBioWrapped=true;
    window.v26AskPin=function(ok,cancel){
      const s=sec();
      if(s&&s.bioEnabled&&nativeAvailable()){
        window.__v30PendingGate={ok:ok,cancel:cancel};
        AndroidBiometric.authenticate("v30BioGateResult");
        return false;
      }
      return original(ok,cancel);
    };
  }
  window.v30BioGateResult=function(ok){
    const p=window.__v30PendingGate;window.__v30PendingGate=null;if(!p)return;
    if(ok){if(typeof p.ok==="function")p.ok();return;}
    // Biometric cancelled/unavailable: show the normal PIN gate.
    if(typeof original==="function")original(p.ok,p.cancel);
  };
  function boot(){
    const item=document.getElementById("v30BioMenuItem");
    if(item){item.onclick=window.v30OpenBiometricSettings;setStatus();}
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,300);setTimeout(boot,1000);
})();



(function(){
  const originalAdd=window.v109RequestAddTransaction;
  window.pfOpenAddTransaction=function(){
    closeMenu();
    const m=document.getElementById("addTransactionModal"); if(!m)return;
    const d=document.getElementById("date"); if(d)d.value=localToday();
    m.style.display="block"; document.body.style.overflow="hidden";
  };
  window.pfCloseAddTransaction=function(){const m=document.getElementById("addTransactionModal");if(m)m.style.display="none";document.body.style.overflow="";};
  window.v109RequestAddTransaction=function(){
    const result=originalAdd?originalAdd():false;
    if(result)window.pfCloseAddTransaction();
    return result;
  };
  function pfShowScreen(name){
    const homeSections=document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)');
    const txPage=document.getElementById('pfTransactionsPage');
    if(name==='transactions'){
      homeSections.forEach(el=>el.style.display='none');
      if(txPage)txPage.style.display='block';
      pfRenderTransactionsPage();
      window.scrollTo({top:0,behavior:'smooth'});
    }else{
      if(txPage)txPage.style.display='none';
      homeSections.forEach(el=>el.style.display='');
      window.scrollTo({top:0,behavior:'smooth'});
    }
  }
  const pfTxState={view:'monthly',month:(new Date()).toISOString().slice(0,7),weekOffset:0};
  function pfTxPad(n){return String(n).padStart(2,'0')}
  function pfTxMonthLabel(ym){
    const [y,m]=ym.split('-').map(Number);
    return new Date(y,m-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  }
  function pfTxMonthBounds(ym){
    const [y,m]=ym.split('-').map(Number);
    const first=new Date(y,m-1,1);
    const last=new Date(y,m,0);
    return {from:`${y}-${pfTxPad(m)}-01`,to:`${y}-${pfTxPad(m)}-${pfTxPad(last.getDate())}`};
  }
  function pfTxShiftMonth(delta){
    const [y,m]=pfTxState.month.split('-').map(Number);
    const d=new Date(y,m-1+delta,1);
    pfTxState.month=`${d.getFullYear()}-${pfTxPad(d.getMonth()+1)}`;
    pfTxState.weekOffset=0;
    pfTxSyncControls();
    pfTxRender();
  }
  function pfTxOpenMonthPicker(){
    const el=document.getElementById('pfTxMonthPicker');
    if(!el)return;
    el.value=pfTxState.month;
    if(typeof el.showPicker==='function'){try{el.showPicker();return}catch(e){}}
    el.style.display='block';el.focus();
  }
  window.pfTxSetMonth=function(value){
    if(!/^\d{4}-\d{2}$/.test(value))return;
    pfTxState.month=value;pfTxState.weekOffset=0;
    const el=document.getElementById('pfTxMonthPicker');if(el)el.style.display='none';
    pfTxSyncControls();pfTxRender();
  };
  function pfTxWeekStart(){
    const b=pfTxMonthBounds(pfTxState.month);
    const base=new Date(b.from+'T00:00:00');
    const day=base.getDay();
    base.setDate(base.getDate()-day+(pfTxState.weekOffset*7));
    return base;
  }
  function pfTxShiftWeek(delta){pfTxState.weekOffset+=delta;pfTxSyncControls();pfTxRender();}
  function pfTxDateString(d){return `${d.getFullYear()}-${pfTxPad(d.getMonth()+1)}-${pfTxPad(d.getDate())}`}
  function pfTxSyncControls(){
    const b=pfTxMonthBounds(pfTxState.month);
    const mb=document.getElementById('pfTxMonthButton');if(mb)mb.innerHTML=`${pfTxMonthLabel(pfTxState.month)} <span>⌄</span>`;
    const dp=document.getElementById('pfTxDayPicker');if(dp){if(!dp.value||dp.value.slice(0,7)!==pfTxState.month)dp.value=b.from;dp.min=b.from;dp.max=b.to;}
    const from=document.getElementById('pfTxFrom'),to=document.getElementById('pfTxTo');
    if(from&&!from.value)from.value=b.from;if(to&&!to.value)to.value=b.to;
    if(from){from.max='9999-12-31';}if(to){to.min='0001-01-01';}
    const ws=pfTxWeekStart(),we=new Date(ws);we.setDate(we.getDate()+6);
    const wl=document.getElementById('pfTxWeekLabel');if(wl)wl.textContent=`${pfTxDateString(ws)} → ${pfTxDateString(we)}`;
  }
  window.pfTxSetView=function(view,btn){
    pfTxState.view=view;pfTxState.weekOffset=0;
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.remove('active'));
    if(btn)btn.classList.add('active');
    const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');
    if(d)d.style.display=view==='daily'?'flex':'none';
    if(w)w.style.display=view==='weekly'?'flex':'none';
    if(c)c.style.display=view==='custom'?'grid':'none';
    pfTxSyncControls();pfTxRender();
  };
  function pfTxFiltered(){
    const b=pfTxMonthBounds(pfTxState.month);
    let from=b.from,to=b.to;
    if(pfTxState.view==='daily'){
      from=to=document.getElementById('pfTxDayPicker')?.value||b.from;
    }else if(pfTxState.view==='weekly'){
      const ws=pfTxWeekStart(),we=new Date(ws);we.setDate(we.getDate()+6);
      from=pfTxDateString(ws);to=pfTxDateString(we);
    }else if(pfTxState.view==='custom'){
      from=document.getElementById('pfTxFrom')?.value||b.from;to=document.getElementById('pfTxTo')?.value||b.to;
      if(from>to){const tmp=from;from=to;to=tmp;}
    }else if(pfTxState.view==='history'){
      const dates=txs.map(t=>t.date).filter(Boolean).sort();
      from=dates[0]||b.from;to=dates[dates.length-1]||b.to;
    }
    return {from,to,data:txs.filter(t=>t.date>=from&&t.date<=to).slice().sort(compareTransactionsLatestFirst)};
  }
  window.pfTxRender=function(){
    const summary=document.getElementById('pfTransactionsSummary'),list=document.getElementById('pfTransactionsList');
    if(!summary||!list)return;
    const q=pfTxFiltered();let income=0,expense=0;
    q.data.forEach(t=>{if(t.type==='CREDIT')income+=Number(t.amount)||0;else expense+=Number(t.amount)||0});
    const viewLabel={daily:'Daily',weekly:'Weekly',monthly:'Monthly',custom:'Custom',history:'History'}[pfTxState.view]||'Transactions';
    summary.textContent=`${viewLabel} • ${q.from} → ${q.to} • ${q.data.length} transaction(s) • Income ${money(income)} • Expense ${money(expense)} • Balance ${money(income-expense)}`;
    list.innerHTML='';
    if(!q.data.length){list.innerHTML='<div class="pf-empty">No transactions found for this view.</div>';return;}
    q.data.forEach(t=>{
      const div=document.createElement('div');div.className='pf-swipe-row';
      const title=escapeHtml(t.category||'Uncategorized');
      const meta=escapeHtml(`${t.date} • ${t.mode||''}${t.description?' • '+t.description:''}`);
      const amt=(t.type==='CREDIT'?'+':'-')+money(t.amount);
      const icon=t.type==='CREDIT'?'↓':'↑';
      div.innerHTML=`<div class="pf-swipe-content"><div class="pf-swipe-icon ${t.type==='CREDIT'?'income':'expense'}">${icon}</div><div class="pf-swipe-main"><div class="pf-swipe-title">${title}</div><div class="pf-swipe-meta">${meta}</div></div><div class="pf-swipe-amount ${t.type==='CREDIT'?'income':'expense'}">${amt}</div></div><div class="pf-swipe-actions"><button class="pf-swipe-edit" type="button">Edit</button></div>`;
      const content=div.querySelector('.pf-swipe-content'),edit=div.querySelector('.pf-swipe-edit');
      let sx=0,sy=0,moved=false;
      content.addEventListener('touchstart',e=>{if(!e.touches[0])return;sx=e.touches[0].clientX;sy=e.touches[0].clientY;moved=false},{passive:true});
      content.addEventListener('touchmove',e=>{if(!e.touches[0])return;const dx=e.touches[0].clientX-sx,dy=e.touches[0].clientY-sy;if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){moved=true;e.preventDefault();content.style.transition='none';const x=Math.max(-92,Math.min(0,dx));content.style.transform=`translateX(${x}px)`;}},{passive:false});
      content.addEventListener('touchend',e=>{if(!moved)return;content.style.transition='transform .18s ease';const dx=(e.changedTouches[0]?.clientX||sx)-sx;if(dx<-45){document.querySelectorAll('.pf-swipe-row.open').forEach(r=>{if(r!==div){r.classList.remove('open');const c=r.querySelector('.pf-swipe-content');if(c)c.style.transform='translateX(0)';}});div.classList.add('open');content.style.transform='translateX(-92px)';}else{div.classList.remove('open');content.style.transform='translateX(0)';}});
      edit.addEventListener('click',()=>{div.classList.remove('open');content.style.transform='translateX(0)';if(canEditTransaction(t))v10RequestEdit(t.id);else alert('This transaction is locked. Editing is allowed only within 5 days of adding it.');});
      list.appendChild(div);
    });
  };
  window.pfRenderTransactionsPage=function(){
    pfTxSyncControls();
    const active=document.querySelector('.pf-tx-tabs button[data-view="'+pfTxState.view+'"]');
    document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===active));
    document.getElementById('pfTxDailyControls').style.display=pfTxState.view==='daily'?'flex':'none';
    document.getElementById('pfTxWeeklyControls').style.display=pfTxState.view==='weekly'?'flex':'none';
    document.getElementById('pfTxCustomControls').style.display=pfTxState.view==='custom'?'grid':'none';
    pfTxRender();
  };
  window.pfNav=function(name,btn){
    pfShowScreen(name==='transactions'?'transactions':'home');
    pfSetNav(btn);
  };
  window.pfSetNav=function(btn){document.querySelectorAll('.pf-bottom-nav button').forEach(b=>b.classList.remove('active'));if(btn)btn.classList.add('active');};
  function boot(){
    const el=document.getElementById("pfTodayLabel"); if(el){const d=new Date();el.textContent=d.toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"});}
    render();
    pfTxSyncControls();
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
  setTimeout(boot,500);
  document.addEventListener("click",function(e){const m=document.getElementById("addTransactionModal");if(e.target===m)pfCloseAddTransaction();});
})();



/* V31 — COMPLETE EXPORT FIELDS FIX
   Excel and PDF exports now preserve every transaction detail:
   Date, Type, Amount, Balance, Category, Description, Remark,
   Payment Mode and Other.  Export-only patch; transaction/security logic
   remains untouched.
*/
(function(){
  function mm31ReadArray(key){
    try{
      const v=JSON.parse(localStorage.getItem(key)||"[]");
      return Array.isArray(v)?v:[];
    }catch(e){return[]}
  }

  function mm31ProfileTxs(){
    const ps=mm31ReadArray("money_manager_profiles_v10");
    const id=localStorage.getItem("money_manager_active_profile_v10");
    const p=ps.find(x=>x&&x.id===id);
    return p&&Array.isArray(p.transactions)?p.transactions.slice():[];
  }

  function mm31LegacyTxs(){
    const a=[];
    try{
      if(typeof txs!=="undefined"&&Array.isArray(txs)) a.push(...txs);
    }catch(e){}
    try{
      const legacy=JSON.parse(localStorage.getItem(typeof KEY!=="undefined"?KEY:"money_manager_v1")||"[]");
      if(Array.isArray(legacy)) a.push(...legacy);
    }catch(e){}
    return a;
  }

  function mm31Text(v){return String(v==null?"":v).trim()}
  function mm31First(obj,keys){
    for(const k of keys){
      if(obj&&obj[k]!==undefined&&obj[k]!==null&&mm31Text(obj[k])!=="") return obj[k];
    }
    return "";
  }

  function mm31Normalize(t, fallback){
    const x=Object.assign({},fallback||{},t||{});
    return {
      id:x.id,
      createdAt:x.createdAt||fallback?.createdAt||"",
      date:mm31First(x,["date"]),
      type:mm31First(x,["type"]),
      amount:Number(x.amount)||0,
      category:mm31First(x,["category"]),
      description:mm31First(x,["description","desc"]),
      remark:mm31First(x,["remark","remarks","note"]),
      mode:mm31First(x,["mode","paymentMode","payment_mode"]),
      other:mm31First(x,["other","otherInfo","other_info"])
    };
  }

  function mm31Same(a,b){
    if(a&&b&&a.id!=null&&b.id!=null&&String(a.id)===String(b.id)) return true;
    return a&&b&&String(a.date||"")===String(b.date||"")&&
      String(a.type||"")===String(b.type||"")&&
      Number(a.amount||0)===Number(b.amount||0)&&
      String(a.category||"")===String(b.category||"");
  }

  function mm31ExportData(){
    const profile=mm31ProfileTxs();
    const legacy=mm31LegacyTxs();
    const out=[];
    const used=new Set();

    profile.forEach(p=>{
      let matchIndex=-1;
      for(let i=0;i<legacy.length;i++){
        if(used.has(i))continue;
        if(mm31Same(p,legacy[i])){matchIndex=i;break;}
      }
      const merged=matchIndex>=0?Object.assign({},p,legacy[matchIndex]):p;
      if(matchIndex>=0)used.add(matchIndex);
      // Prefer whichever source contains the actual field value.
      const n=mm31Normalize(merged,p);
      if(matchIndex>=0){
        const l=mm31Normalize(legacy[matchIndex],p);
        ["description","remark","mode","other","category"].forEach(k=>{
          if(!n[k]&&l[k])n[k]=l[k];
        });
      }
      out.push(n);
    });

    // Include legacy transactions only when they are not already represented
    // in the active profile. This also protects older data during migration.
    legacy.forEach((l,i)=>{
      if(used.has(i))return;
      const exists=out.some(o=>mm31Same(o,l));
      if(!exists)out.push(mm31Normalize(l));
    });

    // Preserve the exact transaction order used by the app/Excel export.
    // Do not sort by date or createdAt here: same data, same sequence in
    // both Excel and PDF exports.
    return out;
  }

  function mm31Range(){
    const from=document.getElementById("pdfFrom")?.value||"";
    const to=document.getElementById("pdfTo")?.value||"";
    if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
    if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }

  function mm31Filtered(){
    const r=mm31Range();if(!r)return null;
    return mm31ExportData().filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
  }

  window.exportExcel=function(){
    const data=mm31Filtered();if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    let balance=0;
    const rows=[["Date","Type","Amount (Rs.)","Balance (Rs.)","Category","Description","Remark","Payment Mode","Other"]];
    data.forEach(t=>{
      balance+=t.type==="CREDIT"?t.amount:-t.amount;
      rows.push([t.date,t.type,t.amount,balance,t.category,t.description,t.remark,t.mode,t.other]);
    });
    const sheetRows=rows.map((r,rowIndex)=>`<row>${r.map((v,i)=>((rowIndex>0)&&(i===2||i===3))?xlsxNumber(Number.isFinite(Number(v))?Number(v):0):xlsxText(v)).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
    const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([
      {name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},
      {name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},
      {name:"xl/worksheets/sheet1.xml",data:sheet}
    ]);
    downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions.xlsx");
  };

  window.exportPDF=function(){
    const data=mm31Filtered();if(!data)return;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const r=mm31Range();
    const from=r.from||data[0].date;
    const to=r.to||data[data.length-1].date;
    let income=0,expense=0,balance=0;
    data.forEach(t=>{
      const a=Number(t.amount)||0;
      if(t.type==="CREDIT")income+=a;else expense+=a;
      balance+=t.type==="CREDIT"?a:-a;
    });
    downloadBlob(window.mm31MakeTransactionTablePDF(data,from,to,income,expense,balance),`money_transactions_${from}_to_${to}.pdf`);
  };
})();



/* V33 — STATEMENT-STYLE EXPORT + CORRECT OPENING BALANCE
   Export order: oldest -> latest.
   Opening balance: latest running balance immediately BEFORE the selected From date.
   Financial columns: Withdrawal / Deposit; Type and Amount are not printed.
   Closing balance must reconcile with the full transaction history through the
   selected To date. PDF and XLSX use the same calculation and same rows.
*/
(function(){
  function v33DateKey(v){
    const s=String(v==null?"":v).trim();
    if(!s)return "";
    // Accept the formats used by browser date inputs and older saved data.
    let m=s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return s.slice(0,10);
  }
  function v33ReadArray(key){
    try{const v=JSON.parse(localStorage.getItem(key)||"[]");return Array.isArray(v)?v:[];}catch(e){return[];}
  }
  function v33Normalize(t){
    const x=t||{};
    return {...x,
      date:v33DateKey(x.date),
      type:String(x.type||"").toUpperCase(),
      amount:Number(x.amount)||0,
      category:x.category||"",
      description:x.description||x.desc||"",
      remark:x.remark||x.remarks||x.note||"",
      mode:x.mode||x.paymentMode||x.payment_mode||"",
      other:x.other||x.otherInfo||x.other_info||""
    };
  }
  function v33Same(a,b){
    return a&&b&&String(a.id||"")===String(b.id||"") && a.id!=null && b.id!=null ||
      a&&b&&v33DateKey(a.date)===v33DateKey(b.date)&&String(a.type||"").toUpperCase()===String(b.type||"").toUpperCase()&&Number(a.amount||0)===Number(b.amount||0)&&String(a.category||"")===String(b.category||"");
  }
  function v33All(){
    // Read the active profile first, then legacy/in-memory stores as fallback.
    // This prevents a valid transaction list from disappearing because one
    // storage copy is stale or the date was stored in a different format.
    const sources=[];
    const ps=v33ReadArray("money_manager_profiles_v10");
    const aid=localStorage.getItem("money_manager_active_profile_v10");
    const ap=ps.find(p=>p&&p.id===aid)||ps[0];
    if(ap&&Array.isArray(ap.transactions)) sources.push(ap.transactions);
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))sources.push(txs);}catch(e){}
    const legacy=v33ReadArray(typeof KEY!=="undefined"?KEY:"money_manager_v1");
    if(legacy.length)sources.push(legacy);
    const out=[];
    sources.forEach(arr=>arr.forEach(raw=>{
      const n=v33Normalize(raw);
      if(!n.date||!n.type||!(n.amount>0))return;
      if(!out.some(x=>v33Same(x,n)))out.push(n);
    }));
    return out;
  }
  function v33Range(){
    const from=document.getElementById("pdfFrom")?.value||"";
    const to=document.getElementById("pdfTo")?.value||"";
    if((from&&!to)||(!from&&to)){alert("Please select both From and To dates.");return null;}
    if(from&&to&&from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function v33Order(data){
    return data.map((t,i)=>({...t,__exportIndex:i})).sort((a,b)=>{
      const d=String(a.date||"").localeCompare(String(b.date||""));
      return d || a.__exportIndex-b.__exportIndex;
    });
  }
  function v33Calc(all, from){
    // Preferred source: a stored running balance from the last transaction
    // immediately before the selected range. This is the exact bank-statement
    // style opening-balance rule. Older records without balance fall back to
    // their cumulative movement rather than inventing a value.
    const before=v33Order(all).filter(t=>!from||String(t.date||"")<from);
    if(before.length){
      const last=before[before.length-1];
      const stored=Number(last.balance);
      if(Number.isFinite(stored))return stored;
    }
    let opening=0;
    before.forEach(t=>{const a=Number(t.amount)||0;opening+=t.type==="CREDIT"?a:-a;});
    return opening;
  }
  function v33Filtered(){
    const r=v33Range(); if(!r)return null;
    const all=v33Order(v33All());
    const data=all.filter(t=>(!r.from||String(t.date||"")>=r.from)&&(!r.to||String(t.date||"")<=r.to));
    return {r,all,data};
  }
  function v33Safe(v){return String(v==null?"":v).trim()}

  function buildRows(data, opening){
    let balance=opening, deposits=0, withdrawals=0;
    const rows=[];
    data.forEach(t=>{
      const a=Number(t.amount)||0;
      let withdrawal="", deposit="";
      if(t.type==="CREDIT"){deposit=a; deposits+=a; balance+=a;}
      else {withdrawal=a; withdrawals+=a; balance-=a;}
      rows.push([
        t.date||"", t.category||"", t.description||"", t.remark||"",
        t.mode||"", t.other||"", withdrawal, deposit, balance
      ]);
    });
    return {rows,deposits,withdrawals,closing:balance};
  }

  window.exportExcel=function(){
    const pack=v33Filtered(); if(!pack)return;
    const {r,all,data}=pack;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const from=r.from||data[0].date, to=r.to||data[data.length-1].date;
    const opening=v33Calc(all,from);
    const calc=buildRows(data,opening);
    const rows=[[
      "Date","Category","Description","Remark","Payment Mode","Other",
      "Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"
    ]];
    rows.push(...calc.rows);
    rows.push([]);
    rows.push(["ACCOUNT SUMMARY"]);
    rows.push(["OPENING BALANCE",opening,"TOTAL WITHDRAWALS",calc.withdrawals,
               "TOTAL DEPOSITS",calc.deposits,"CLOSING BALANCE",calc.closing,
               "No. of Transactions",data.length]);
    rows.push([]);
    rows.push(["******************* END OF REPORT *******************"]);

    const sheetRows=rows.map((row,rowIndex)=>`<row>${row.map((v,i)=>{
      const numeric = (typeof v==="number" && Number.isFinite(v));
      // Transaction financial columns: Withdrawal, Deposit, Balance = 6,7,8.
      if(rowIndex>0 && rowIndex<=data.length && (i===6||i===7||i===8)){
        return xlsxNumber(numeric?v:0);
      }
      if(rowIndex===data.length+2){
        return numeric?xlsxNumber(v):xlsxText(v);
      }
      return xlsxText(v);
    }).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
    const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const content=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([{name:"[Content_Types].xml",data:content},{name:"_rels/.rels",data:rootRels},{name:"xl/workbook.xml",data:workbook},{name:"xl/_rels/workbook.xml.rels",data:rels},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
    downloadBlob(new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${from}_to_${to}.xlsx`);
  };

  window.exportPDF=function(){
    const pack=v33Filtered(); if(!pack)return;
    const {r,all,data}=pack;
    if(!data.length){alert("No transactions in the selected date range.");return;}
    const from=r.from||data[0].date, to=r.to||data[data.length-1].date;
    const opening=v33Calc(all,from), calc=buildRows(data,opening);
    const width=842,height=595,margin=24,top=38,bottom=34;
    // Date, Category, Description, Remark, Payment Mode, Other, Withdrawal, Deposit, Balance
    const colW=[58,70,100,78,72,65,78,78,85];
    const headers=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"];
    const fontSize=6.8,lineH=9,headerH=20,pad=2.5,maxY=height-bottom;
    function safeText(v){return v33Safe(v).replace(/[^\x20-\x7E]/g,"?")}
    function esc(s){return pdfEscape(safeText(s))}
    function wrap(text,w){
      text=safeText(text); const approx=Math.max(5,Math.floor((w-pad*2)/(fontSize*.52)));
      if(!text)return [""]; const out=[]; let cur="";
      text.split(/\s+/).forEach(word=>{if(!word)return;if(word.length>approx){if(cur){out.push(cur);cur=""}for(let i=0;i<word.length;i+=approx)out.push(word.slice(i,i+approx));}
      else if(!cur)cur=word;else if((cur+" "+word).length<=approx)cur+=" "+word;else{out.push(cur);cur=word;}});
      if(cur)out.push(cur); return out.length?out:[""];
    }
    function rowLines(row){const cells=row.map((v,i)=>wrap(v,colW[i]));return {cells,n:Math.max(...cells.map(c=>c.length)),h:Math.max(18,Math.max(...cells.map(c=>c.length))*lineH+4)}}
    const prepared=calc.rows.map(row=>rowLines([
      row[0],row[1],row[2],row[3],row[4],row[5],
      row[6]===""?"":Number(row[6]).toFixed(2),
      row[7]===""?"":Number(row[7]).toFixed(2),
      Number(row[8]).toFixed(2)
    ]));
    const pages=[];let page=[],y=top+28;
    for(const rr of prepared){if(y+rr.h>maxY&&page.length){pages.push(page);page=[];y=top+28;}page.push(rr);y+=rr.h;}if(page.length||!pages.length)pages.push(page);
    let objs=[];const add=o=>{objs.push(o);return objs.length};
    const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pageIds=[],contentIds=[];
    pages.forEach((pg,pi)=>{
      let stream="q\n";
      stream+=`BT\n/F1 10 Tf\n1 0 0 1 ${margin} ${height-28} Tm (${esc("MONEY MANAGER - TRANSACTION REPORT")}) Tj\n`;
      stream+=`/F1 8 Tf\n1 0 0 1 ${margin} ${height-40} Tm (${esc(`Period: ${from} to ${to}`)}) Tj\nET\n`;
      let yy=height-55;
      function cell(x,y,w,h,texts,bold){stream+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fontSize} Tf\n`;texts.forEach((tx,i)=>{const ty=y-pad-7-i*lineH;stream+=`1 0 0 1 ${x+pad} ${ty} Tm (${esc(tx)}) Tj\n`});stream+="ET\n"}
      let x=margin;headers.forEach((h,i)=>{cell(x,yy,colW[i],headerH,[h],true);x+=colW[i]});yy-=headerH;
      pg.forEach(rr=>{x=margin;rr.cells.forEach((cc,i)=>{cell(x,yy,colW[i],rr.h,cc,false);x+=colW[i]});yy-=rr.h});
      if(pi===pages.length-1){
        yy-=14;stream+=`BT\n/F1 9 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("ACCOUNT SUMMARY")}) Tj\nET\n`;yy-=16;
        const sumW=[130,130,130,130,130];
        const labels=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"];
        const vals=[opening.toFixed(2),calc.withdrawals.toFixed(2),calc.deposits.toFixed(2),calc.closing.toFixed(2),String(data.length)];
        let sx=margin;labels.forEach((lab,i)=>{cell(sx,yy,sumW[i],16,[lab],true);sx+=sumW[i]});
        yy-=16;sx=margin;vals.forEach((val,i)=>{cell(sx,yy,sumW[i],16,[val],false);sx+=sumW[i]});
        yy-=27;stream+=`BT\n/F1 9 Tf\n1 0 0 1 ${margin} ${yy} Tm (${esc("******************* END OF REPORT *******************")}) Tj\nET\n`;
      }
      stream+="Q";const cid=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);contentIds.push(cid);pageIds.push(null);
    });
    const pagesId=add("PAGES_PLACEHOLDER");pages.forEach((_,i)=>{pageIds[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${contentIds[i]} 0 R >>`)});objs[pagesId-1]=`<< /Type /Pages /Kids [${pageIds.map(id=>id+" 0 R").join(" ")}] /Count ${pageIds.length} >>`;const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let pdf="%PDF-1.4\n",offsets=[0];objs.forEach((o,i)=>{offsets[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xref=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    downloadBlob(new Blob([pdf],{type:"application/pdf"}),`money_transactions_${from}_to_${to}.pdf`);
  };
})();



/* V34 — FINAL EXPORT RANGE PIPELINE FIX
   Uses the same active transaction set visible in the app, normalizes every
   stored date before filtering, and applies the selected From/To range only
   at the final export stage. PDF and XLSX share the exact same filtered rows.
*/
(function(){
  function v34Text(v){return String(v==null?"":v).trim()}
  function v34Date(v){
    const s=v34Text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return `${m[3]}-${String(m[2]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`;
    return s.slice(0,10);
  }
  function v34Arr(key){try{const x=JSON.parse(localStorage.getItem(key)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
  function v34Norm(t){
    const x=t||{};
    return {id:x.id,date:v34Date(x.date),type:v34Text(x.type).toUpperCase(),amount:Number(x.amount)||0,
      balance:Number.isFinite(Number(x.balance))?Number(x.balance):null,
      category:v34Text(x.category),description:v34Text(x.description||x.desc),remark:v34Text(x.remark||x.remarks||x.note),
      mode:v34Text(x.mode||x.paymentMode||x.payment_mode),other:v34Text(x.other||x.otherInfo||x.other_info),createdAt:x.createdAt||""};
  }
  function v34Same(a,b){
    if(a&&b&&a.id!=null&&b.id!=null&&String(a.id)===String(b.id))return true;
    return a&&b&&v34Date(a.date)===v34Date(b.date)&&v34Text(a.type).toUpperCase()===v34Text(b.type).toUpperCase()&&Number(a.amount||0)===Number(b.amount||0)&&v34Text(a.category)===v34Text(b.category);
  }
  function v34All(){
    const sources=[];
    let profiles=v34Arr("money_manager_profiles_v10");
    const activeId=localStorage.getItem("money_manager_active_profile_v10");
    const p=profiles.find(x=>x&&String(x.id)===String(activeId)) || profiles[0];
    // txs is the live array currently rendered by the app. Put it first.
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))sources.push(txs.slice())}catch(e){}
    if(p&&Array.isArray(p.transactions))sources.push(p.transactions.slice());
    // Only use legacy storage as a fallback/field-completion source.
    const legacy=v34Arr(typeof KEY!=="undefined"?KEY:"money_manager_v1");
    if(legacy.length)sources.push(legacy);
    const out=[];
    sources.forEach(arr=>arr.forEach(raw=>{
      const n=v34Norm(raw); if(!n.date||!n.type||n.amount<=0)return;
      const old=out.findIndex(o=>v34Same(o,n));
      if(old<0)out.push(n);
      else{
        const q=out[old];
        ["balance","category","description","remark","mode","other","createdAt"].forEach(k=>{
          if((q[k]===null||q[k]===""||q[k]===undefined) && n[k]!==null && n[k]!=="")q[k]=n[k];
        });
      }
    }));
    out.sort((a,b)=>v34Date(a.date).localeCompare(v34Date(b.date)) || (String(a.createdAt).localeCompare(String(b.createdAt))));
    return out;
  }
  function v34Range(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=v34Date(f&&f.value),to=v34Date(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function v34Pack(){
    const r=v34Range();if(!r)return null;
    const all=v34All();
    const data=all.filter(t=>(!r.from||t.date>=r.from)&&(!r.to||t.date<=r.to));
    return {r,all,data};
  }
  function v34Opening(all,from){
    if(!from)return 0;
    const before=all.filter(t=>t.date<from);
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(Number.isFinite(last.balance))return last.balance;
    let b=0;before.forEach(t=>b+=t.type==="CREDIT"?t.amount:-t.amount);return b;
  }
  function v34Rows(data,opening){
    let b=opening,w=0,d=0;
    const rows=data.map(t=>{
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b]
    });
    return {rows,withdrawals:w,deposits:d,closing:b};
  }
  function v34Esc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
  function v34XText(v){return `<c t="inlineStr"><is><t>${v34Esc(v)}</t></is></c>`}
  function v34XNum(v){return `<c t="n"><v>${Number(v)||0}</v></c>`}
  function v34MakeXlsx(pack){
    const {r,all,data}=pack,from=r.from||data[0].date,to=r.to||data[data.length-1].date,opening=v34Opening(all,from),calc=v34Rows(data,opening);
    const rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    rows.push(...calc.rows);rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",opening,"TOTAL WITHDRAWALS",calc.withdrawals,"TOTAL DEPOSITS",calc.deposits,"CLOSING BALANCE",calc.closing,"No. of Transactions",data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map((row,ri)=>`<row>${row.map((v,i)=>{const num=(ri>0&&ri<=data.length&&[6,7,8].includes(i))||(ri===data.length+2&&typeof v==="number");return num?v34XNum(v):v34XText(v)}).join("")}</row>`).join("");
    const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${xml}</sheetData></worksheet>`;
    const wb=`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const rel=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const root=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const ct=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const bytes=zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
    return {bytes,from,to};
  }
  function v34Pdf(pack){
    const {r,all,data}=pack,from=r.from||data[0].date,to=r.to||data[data.length-1].date,opening=v34Opening(all,from),calc=v34Rows(data,opening);
    const W=842,H=595,M=24,top=38,bottom=34,colW=[58,70,100,78,72,65,78,78,85],headers=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=v=>v34Text(v).replace(/[^\x20-\x7E]/g,"?"); const esc=v=>pdfEscape(safe(v));
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];const a=[];let c="";v.split(/\s+/).forEach(q=>{if((c+" "+q).trim().length<=n)c=(c?c+" ":"")+q;else{if(c)a.push(c);if(q.length>n){for(let i=0;i<q.length;i+=n)a.push(q.slice(i,i+n));c=""}else c=q}});if(c)a.push(c);return a.length?a:[""]}
    function rr(row){const cells=row.map((v,i)=>wrap(v,colW[i]));return {cells,h:Math.max(18,Math.max(...cells.map(c=>c.length))*lh+4)}}
    const prepared=calc.rows.map(x=>rr([x[0],x[1],x[2],x[3],x[4],x[5],x[6]===""?"":Number(x[6]).toFixed(2),x[7]===""?"":Number(x[7]).toFixed(2),Number(x[8]).toFixed(2)]));
    const pages=[];let pg=[],y=top+28;prepared.forEach(x=>{if(y+x.h>H-bottom&&pg.length){pages.push(pg);pg=[];y=top+28}pg.push(x);y+=x.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[];const add=o=>{objs.push(o);return objs.length};const font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach((page,pi)=>{let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(from+" to "+to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,texts,bold){s+=`0.75 w\n0 0 0 RG\n${x} ${y-h} ${w} ${h} re S\nBT\n/F1 ${bold?7.2:fs} Tf\n`;texts.forEach((t,i)=>s+=`1 0 0 1 ${x+2.5} ${y-2.5-7-i*lh} Tm (${esc(t)}) Tj\n`);s+="ET\n"}
      let x=M;headers.forEach((h,i)=>{cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(row=>{x=M;row.cells.forEach((c,i)=>{cell(x,yy,colW[i],row.h,c,false);x+=colW[i]});yy-=row.h});
      if(pi===pages.length-1){yy-=14;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (ACCOUNT SUMMARY) Tj\nET\n`;yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[opening.toFixed(2),calc.withdrawals.toFixed(2),calc.deposits.toFixed(2),calc.closing.toFixed(2),String(data.length)];x=M;labs.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach((q,i)=>{cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+=`BT\n/F1 9 Tf\n1 0 0 1 ${M} ${yy} Tm (******************* END OF REPORT *******************) Tj\nET\n`}
      s+="Q";cids.push(add(`<< /Length ${s.length} >>\nstream\n${s}\nendstream`));pids.push(null)
    });
    const pagesId=add("PAGES");pages.forEach((_,i)=>pids[i]=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${cids[i]} 0 R >>`));objs[pagesId-1]=`<< /Type /Pages /Kids [${pids.map(x=>x+" 0 R").join(" ")}] /Count ${pids.length} >>`;const cat=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);let pdf="%PDF-1.4\n",offs=[0];objs.forEach((o,i)=>{offs[i+1]=pdf.length;pdf+=`${i+1} 0 obj\n${o}\nendobj\n`});const xr=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${cat} 0 R >>\nstartxref\n${xr}\n%%EOF`;return {blob:new Blob([pdf],{type:"application/pdf"}),from,to};
  }
  window.exportExcel=function(){const p=v34Pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}const x=v34MakeXlsx(p);downloadBlob(new Blob([x.bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),`money_transactions_${x.from}_to_${x.to}.xlsx`)};
  window.exportPDF=function(){const p=v34Pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}const x=v34Pdf(p);downloadBlob(x.blob,`money_transactions_${x.from}_to_${x.to}.pdf`)};
})();



/* V35 — SINGLE SOURCE EXPORT FIX
   Final override: read the exact date controls at click time and use the live
   transaction array rendered by the app. No profile/legacy merging is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function dateKey(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return m[1]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[3]).padStart(2,"0");
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return m[3]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[1]).padStart(2,"0");
    return "";
  }
  function selectedRange(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=dateKey(f&&f.value),to=dateKey(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function liveTransactions(){
    let a=[];
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))a=txs.slice()}catch(e){}
    return a.map(function(x,i){
      return {id:x&&x.id!=null?x.id:i,date:dateKey(x&&x.date),type:text(x&&x.type).toUpperCase(),amount:Number(x&&x.amount)||0,
        balance:Number.isFinite(Number(x&&x.balance))?Number(x.balance):null,category:text(x&&x.category),description:text(x&&x.description||x&&x.desc),remark:text(x&&x.remark||x&&x.remarks||x&&x.note),mode:text(x&&x.mode||x&&x.paymentMode||x&&x.payment_mode),other:text(x&&x.other||x&&x.otherInfo||x&&x.other_info),createdAt:text(x&&x.createdAt)};
    }).filter(function(x){return x.date&&x.amount>0&&(x.type==="CREDIT"||x.type==="EXPENSE"||x.type==="DEBIT");})
      .sort(function(a,b){return a.date.localeCompare(b.date)||(a.createdAt.localeCompare(b.createdAt))||(Number(a.id)||0)-(Number(b.id)||0)});
  }
  function pack(){
    const r=selectedRange(); if(!r)return null;
    const all=liveTransactions();
    const data=all.filter(function(x){return (!r.from||x.date>=r.from)&&(!r.to||x.date<=r.to)});
    return {from:r.from,to:r.to,all:all,data:data};
  }
  function opening(all,from){
    if(!from)return 0;
    const before=all.filter(function(x){return x.date<from;});
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(last.balance!==null)return last.balance;
    let b=0;before.forEach(function(x){b+=x.type==="CREDIT"?x.amount:-x.amount});return b;
  }
  function calc(p){
    let b=opening(p.all,p.from),w=0,d=0;
    const rows=p.data.map(function(t){
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b];
    });
    return {rows:rows,opening:opening(p.all,p.from),withdrawals:w,deposits:d,closing:b};
  }
  function xesc(s){return text(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;")}
  function xtext(v){return '<c t="inlineStr"><is><t>'+xesc(v)+'</t></is></c>'}
  function xnum(v){return '<c t="n"><v>'+String(Number(v)||0)+'</v></c>'}
  function makeXlsx(p){
    const c=calc(p),rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    c.rows.forEach(function(r){rows.push([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8]])});
    rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",c.opening,"TOTAL WITHDRAWALS",c.withdrawals,"TOTAL DEPOSITS",c.deposits,"CLOSING BALANCE",c.closing,"No. of Transactions",p.data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map(function(row,ri){return '<row>'+row.map(function(v,i){const numeric=(ri>0&&ri<=p.data.length&&[6,7,8].indexOf(i)>=0)||(ri===p.data.length+2&&typeof v==="number");return numeric?xnum(v):xtext(v)}).join('')+'</row>'}).join('');
    const sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+xml+'</sheetData></worksheet>';
    const wb='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const rel='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const root='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const ct='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function makePdf(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=function(v){return text(v).replace(/[^\x20-\x7E]/g,"?")},esc=function(v){return pdfEscape(safe(v))};
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";v.split(/\s+/).forEach(function(q){if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}});if(cur)a.push(cur);return a.length?a:[""]}
    function rr(vals){const cells=vals.map(function(v,i){return wrap(v,colW[i])});return {cells:cells,h:Math.max(18,Math.max.apply(null,cells.map(function(z){return z.length}))*lh+4)}}
    const prepared=c.rows.map(function(r){return rr([r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)])});
    const pages=[];let pg=[],y=86;prepared.forEach(function(r){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=function(o){objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach(function(page,pi){let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(p.from+" to "+p.to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,vals,bold){s+="0.75 w\n0 0 0 RG\n"+x+" "+(y-h)+" "+w+" "+h+" re S\nBT\n/F1 "+(bold?7.2:fs)+" Tf\n";vals.forEach(function(t,i){s+="1 0 0 1 "+(x+2.5)+" "+(y-2.5-7-i*lh)+" Tm ("+esc(t)+") Tj\n"});s+="ET\n"}
      let x=M;heads.forEach(function(h,i){cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(function(r){x=M;r.cells.forEach(function(cc,i){cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (ACCOUNT SUMMARY) Tj\nET\n";yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[c.opening.toFixed(2),c.withdrawals.toFixed(2),c.deposits.toFixed(2),c.closing.toFixed(2),String(p.data.length)];x=M;labs.forEach(function(q,i){cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach(function(q,i){cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (******************* END OF REPORT *******************) Tj\nET\n"}
      s+="Q";cids.push(add("<< /Length "+s.length+" >>\nstream\n"+s+"\nendstream"));pids.push(null);
    });
    const pagesId=add("PAGES");pages.forEach(function(_,i){pids[i]=add("<< /Type /Page /Parent "+pagesId+" 0 R /MediaBox [0 0 "+W+" "+H+"] /Resources << /Font << /F1 "+font+" 0 R >> >> /Contents "+cids[i]+" 0 R >>")});objs[pagesId-1]="<< /Type /Pages /Kids ["+pids.map(function(x){return x+" 0 R"}).join(" ")+"] /Count "+pids.length+" >>";const cat=add("<< /Type /Catalog /Pages "+pagesId+" 0 R >>");let pdf="%PDF-1.4\n",offs=[0];objs.forEach(function(o,i){offs[i+1]=pdf.length;pdf+=(i+1)+" 0 obj\n"+o+"\nendobj\n"});const xr=pdf.length;pdf+="xref\n0 "+(objs.length+1)+"\n0000000000 65535 f \n";for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+="trailer\n<< /Size "+(objs.length+1)+" /Root "+cat+" 0 R >>\nstartxref\n"+xr+"\n%%EOF";return new Blob([pdf],{type:"application/pdf"});
  }
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions_"+p.from+"_to_"+p.to+".xlsx")};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(makePdf(p),"money_transactions_"+p.from+"_to_"+p.to+".pdf")};
})();

/* Money Flow V61 — Backup Money Flow V58 — Backup & Restore v5 Restore v6
   Local/offline backup is preserved. Google Drive appDataFolder is the cloud copy.
   Cloud backup is account-scoped and intentionally excludes PIN/recovery/security credentials.
*/
(function(){
  /*
   * V7 FINAL BACKUP ARCHITECTURE
   * ----------------------------
   * Cloud backup contains account-scoped transactions plus Profile/Mode metadata, profile photos and PIN/recovery settings. Notes remain device-local and are never included.
   *
   * Cloud is the synchronized transaction snapshot. Restore NEVER blindly
   * replaces local transaction work: it merges the incoming cloud snapshot
   * against the last successful sync baseline so local unsynced changes survive.
   * The merged transaction set is then recalculated/refreshed and uploaded as
   * the new synchronized snapshot. Existing device-local profile/security data
   * remains local.
   */
  let backupTimer=0, cloudTimer=0;
  let cloudSyncSuppressed=true;
  let autoReloadAfterCloudWrite=false;
  /* Transaction sync state: the last successfully uploaded transaction snapshot
     is the baseline. Local transactions created/edited after that baseline are
     protected from an incoming cloud restore until they are uploaded. */
  const MF_TX_SYNC_KEY='mf_cloud_tx_snapshot_v1';
  const MF_TX_PENDING_KEY='mf_cloud_tx_pending_v1';
  const MF_PROFILE_SYNC_KEY='mf_cloud_profile_snapshot_v1';
  const MF_PROFILE_PENDING_KEY='mf_cloud_profile_pending_v1';
  let cloudUploadBusy=false, cloudUploadQueued=false;

  function mfCloneTxList(list){
    return (Array.isArray(list)?list:[]).map(t=>{
      try{return mfEnsureTransactionUid(JSON.parse(JSON.stringify(t)))}catch(e){return mfEnsureTransactionUid(t)}
    });
  }
  function mfTxId(t){
    /* Stable transaction UID is the primary identity for every cloud/local merge.
       Legacy rows are upgraded deterministically from their old id. */
    if(t&&t.uid!==undefined&&t.uid!==null&&String(t.uid).trim()!=='')return String(t.uid);
    if(t&&t.id!==undefined&&t.id!==null&&String(t.id)!=='')return 'legacy-'+String(t.id);
    try{return 'legacy:'+JSON.stringify([t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other]);}catch(e){return 'legacy:'+String(t);}
  }
  function mfTxEqual(a,b){
    try{return JSON.stringify(a)===JSON.stringify(b)}catch(e){return String(a)===String(b)}
  }
  function mfReadSyncSnapshot(){
    try{
      const x=JSON.parse(localStorage.getItem(MF_TX_SYNC_KEY)||'null');
      return Array.isArray(x)?x:null;
    }catch(e){return null}
  }
  function mfWriteSyncSnapshot(list){
    try{localStorage.setItem(MF_TX_SYNC_KEY,JSON.stringify(mfCloneTxList(list)));}catch(e){}
  }
  function mfWritePendingSnapshot(list){
    try{localStorage.setItem(MF_TX_PENDING_KEY,JSON.stringify(mfCloneTxList(list)));}catch(e){}
  }
  function mfReadPendingSnapshot(){
    try{const x=JSON.parse(localStorage.getItem(MF_TX_PENDING_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}
  }
  function mfClearPendingSnapshot(){try{localStorage.removeItem(MF_TX_PENDING_KEY)}catch(e){} }

  function mfCloneObject(v){try{return JSON.parse(JSON.stringify(v))}catch(e){return v}}
  function mfProfileSecurityForCloud(sec){
    const s=sec&&typeof sec==='object'?sec:{};
    /* PIN/recovery belong to the Profile / Mode and are backed up. WebAuthn
       credential IDs are device-bound and therefore never copied to cloud. */
    return {
      mode:String(s.mode||'NONE'),
      pinHash:String(s.pinHash||''),
      recoveryCode:String(s.recoveryCode||''),
      editPinLost:!!s.editPinLost,
      addProtection:!!s.addProtection,
      bioEnabled:!!s.bioEnabled,
      profileSecurityInitialized:s.profileSecurityInitialized!==false
    };
  }
  function mfProfilesForCloudFrom(list){
    return (Array.isArray(list)?list:[]).map((p,i)=>({
      id:String(p&&p.id||('profile_'+i)),
      name:String(p&&p.name||'My Money'),
      transactions:mfCloneTxList(p&&p.transactions),
      security:mfProfileSecurityForCloud(p&&p.security),
      config:mfCloneObject(p&&p.config||{}),
      profileGender:['male','female','other'].includes(String(p&&p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',
      profilePhoto:(p&&typeof p.profilePhoto==='string'&&/^data:image\//i.test(p.profilePhoto))?p.profilePhoto:'',
      createdManually:p&&p.createdManually===true,
      autoGeneratedProfile:p&&p.autoGeneratedProfile===true
    }));
  }
  function mfProfilesForCloud(){
    try{return mfNormalizeProfileList(mfProfilesForCloudFrom(mfParseArray(localStorage.getItem('money_manager_profiles_v10'))))}catch(e){return[]}
  }
  function mfReadProfileSyncSnapshot(){
    try{const x=JSON.parse(localStorage.getItem(MF_PROFILE_SYNC_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}
  }
  function mfWriteProfileSyncSnapshot(list){try{localStorage.setItem(MF_PROFILE_SYNC_KEY,JSON.stringify(mfProfilesForCloudFrom(mfNormalizeProfileList(list))))}catch(e){}}
  function mfWritePendingProfiles(list){try{localStorage.setItem(MF_PROFILE_PENDING_KEY,JSON.stringify(mfProfilesForCloudFrom(mfNormalizeProfileList(list))))}catch(e){}}
  function mfReadPendingProfiles(){try{const x=JSON.parse(localStorage.getItem(MF_PROFILE_PENDING_KEY)||'null');return Array.isArray(x)?x:null}catch(e){return null}}
  function mfClearPendingProfiles(){try{localStorage.removeItem(MF_PROFILE_PENDING_KEY)}catch(e){} }
  function mfProfileMeta(p){
    return {name:String(p&&p.name||'My Money'),security:mfProfileSecurityForCloud(p&&p.security),config:mfCloneObject(p&&p.config||{}),profileGender:['male','female','other'].includes(String(p&&p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',profilePhoto:String(p&&p.profilePhoto||''),createdManually:p&&p.createdManually===true,autoGeneratedProfile:p&&p.autoGeneratedProfile===true};
  }
  function mfProfileMetaEqual(a,b){try{return JSON.stringify(mfProfileMeta(a))===JSON.stringify(mfProfileMeta(b))}catch(e){return false}}
  function mfMergeTxLists(cloudList,localList,baselineList){
    const remote=mfCloneTxList(cloudList),local=mfCloneTxList(localList),baseline=Array.isArray(baselineList)?mfCloneTxList(baselineList):null;
    const r=new Map(),l=new Map(),b=new Map();remote.forEach(t=>r.set(mfTxId(t),t));local.forEach(t=>l.set(mfTxId(t),t));if(baseline)baseline.forEach(t=>b.set(mfTxId(t),t));
    const changed=new Set(),deleted=new Set();
    if(baseline){b.forEach((bt,id)=>{if(!l.has(id))deleted.add(id);else if(!mfTxEqual(l.get(id),bt))changed.add(id)});l.forEach((_,id)=>{if(!b.has(id))changed.add(id)})}
    else l.forEach((_,id)=>changed.add(id));
    const out=new Map();r.forEach((t,id)=>{if(!deleted.has(id))out.set(id,t)});l.forEach((t,id)=>{if(changed.has(id))out.set(id,t)});
    return Array.from(out.values()).sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
  }
  function mfIsUntouchedAutoProfile(p){
    const sec=p&&p.security||{};
    return !!(p && p.autoGeneratedProfile===true && String(p.name||'')==='My Money' &&
      (!Array.isArray(p.transactions)||p.transactions.length===0) && !p.profilePhoto &&
      !sec.pinHash && !sec.recoveryCode);
  }
  function mfNormalizeProfileList(list){
    const all=Array.isArray(list)?list:[];
    const real=all.filter(p=>!mfIsUntouchedAutoProfile(p));
    const auto=all.filter(p=>mfIsUntouchedAutoProfile(p));
    /* If there are real/manual profiles, synthetic defaults must not survive.
       If the account contains only synthetic defaults, retain exactly ONE so
       a brand-new account still has one initial Active Profile. */
    if(real.length)return real;
    return auto.length?[auto[0]]:[];
  }
  function mfMergeProfiles(cloudProfiles){
    const rawRemote=mfProfilesForCloudFrom(cloudProfiles);
    const remote=mfNormalizeProfileList(rawRemote);
    const localAll=mfProfilesForCloud();
    const local=mfNormalizeProfileList(localAll),baseline=mfReadProfileSyncSnapshot();
    const lMap=new Map(local.map(p=>[String(p.id),p])),bMap=new Map((Array.isArray(baseline)?baseline:[]).map(p=>[String(p.id),p]));
    const merged=new Map();
    remote.forEach(cp=>{
      const id=String(cp.id),lp=lMap.get(id),bp=bMap.get(id);
      if(lp){
        const localMetaChanged=bp?!mfProfileMetaEqual(lp,bp):true;
        const q=mfCloneObject(cp);
        q.transactions=mfMergeTxLists(cp.transactions,lp.transactions,bp&&bp.transactions);
        if(localMetaChanged){q.name=lp.name;q.security=mfCloneObject(lp.security);q.config=mfCloneObject(lp.config);q.profileGender=['male','female','other'].includes(String(lp.profileGender||'').toLowerCase())?String(lp.profileGender).toLowerCase():'male';q.profilePhoto=lp.profilePhoto||'';q.createdManually=lp.createdManually===true;q.autoGeneratedProfile=lp.autoGeneratedProfile===true;}
        if(!q.createdManually && lp.createdManually===true)q.createdManually=true;
        if(lp.autoGeneratedProfile===true)q.autoGeneratedProfile=true;
        if(lp.security&&lp.security.bioCredentialId)q.security.bioCredentialId=lp.security.bioCredentialId;
        merged.set(id,q);
      }else{
        const q=mfCloneObject(cp);q.security=q.security||{};q.security.bioCredentialId='';merged.set(id,q);
      }
    });
    /* Never delete a local-only Mode during restore. */
    local.forEach(lp=>{const id=String(lp.id);if(!merged.has(id))merged.set(id,mfCloneObject(lp))});
    return Array.from(merged.values());
  }
  function mfApplyProfiles(profiles,activeId){
    const ps=Array.isArray(profiles)?profiles.map(p=>{const q=mfCloneObject(p)||{};q.id=String(q.id||('profile_'+Date.now()));q.name=String(q.name||'My Money');q.profileGender=['male','female','other'].includes(String(q.profileGender||'').toLowerCase())?String(q.profileGender).toLowerCase():'male';q.transactions=mfCloneTxList(q.transactions);q.security=q.security||{};q.createdManually=q.createdManually===true;q.autoGeneratedProfile=q.autoGeneratedProfile===true;if(!q.security.bioCredentialId)q.security.bioCredentialId='';return q;}):[];
    if(!ps.length)return false;
    localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps));
    let aid=String(activeId||'');if(!aid||!ps.some(p=>String(p.id)===aid))aid=String(ps[0].id);
    localStorage.setItem('money_manager_active_profile_v10',aid);
    const ap=ps.find(p=>String(p.id)===aid)||ps[0];
    try{if(typeof config!=='undefined'&&ap&&ap.config&&typeof ap.config==='object'){config=mfCloneObject(ap.config);localStorage.setItem('money_manager_config',JSON.stringify(config));}}catch(e){}
    try{if(typeof txs!=='undefined'&&Array.isArray(txs)){txs.length=0;mfCloneTxList(ap.transactions).forEach(t=>txs.push(t));localStorage.setItem(typeof KEY!=='undefined'?KEY:'money_manager_v1',JSON.stringify(txs));}}catch(e){}
    return true;
  }

  function mfMergeCloudWithLocal(cloudList){
    const remote=mfCloneTxList(cloudList);
    const local=mfTransactionSnapshot();
    const baseline=mfReadSyncSnapshot();
    const rMap=new Map(), lMap=new Map(), bMap=new Map();
    remote.forEach(t=>rMap.set(mfTxId(t),t));
    local.forEach(t=>lMap.set(mfTxId(t),t));
    if(Array.isArray(baseline))baseline.forEach(t=>bMap.set(mfTxId(t),t));

    /* With no prior successful cloud snapshot, treat existing local rows as
       unsynced rather than allowing the cloud to wipe them on first restore. */
    const hasBaseline=Array.isArray(baseline);
    const localChanged=new Set();
    const localDeleted=new Set();
    if(hasBaseline){
      bMap.forEach((b,id)=>{
        if(!lMap.has(id))localDeleted.add(id);
        else if(!mfTxEqual(lMap.get(id),b))localChanged.add(id);
      });
      lMap.forEach((_,id)=>{if(!bMap.has(id))localChanged.add(id)});
    }else{
      lMap.forEach((_,id)=>localChanged.add(id));
    }

    const merged=new Map();
    /* Start with cloud. Local changes/deletions then take precedence. */
    rMap.forEach((t,id)=>{if(!localDeleted.has(id))merged.set(id,t)});
    lMap.forEach((t,id)=>{if(localChanged.has(id))merged.set(id,t)});

    const out=Array.from(merged.values());
    out.sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
    return out;
  }

  function mfCommitCloudUploadSnapshot(snapshot){
    mfWriteSyncSnapshot(snapshot);
    mfClearPendingSnapshot();
  }

  function mfRequestCloudUpload(snapshot,after){
    if(cloudSyncSuppressed)return false;
    const snap=mfCloneTxList(snapshot||mfTransactionSnapshot());
    const profiles=mfProfilesForCloud();
    mfWritePendingSnapshot(snap);mfWritePendingProfiles(profiles);
    if(cloudUploadBusy){cloudUploadQueued=true;return true;}
    try{
      if(!(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup))return false;
      cloudUploadBusy=true;if(typeof after==='function')after();
      AndroidCloudBackup.uploadCloudBackup(JSON.stringify({
        version:5,app:'PaisaFlow',dataType:'transactions-and-profiles',createdAt:new Date().toISOString(),
        accountEmail:(()=>{try{return String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase()}catch(e){return''}})(),
        activeProfileId:mfActiveProfileId(),transactions:snap,profiles:profiles
      }));
      return true;
    }catch(e){cloudUploadBusy=false;return false}
  }

  function mfParseArray(raw){
    try{const x=JSON.parse(raw||'[]');return Array.isArray(x)?x:[]}catch(e){return[]}
  }

  function mfActiveProfileId(){
    try{return localStorage.getItem('money_manager_active_profile_v10')||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId')||''}catch(e){return''}
  }

  function mfReadLocalTransactions(){
    /* The legacy/current transaction store is the first source of truth. */
    try{
      const direct=mfParseArray(localStorage.getItem('money_manager_v1'));
      if(direct.length)return direct;
    }catch(e){}
    /* Fallback for a profile store whose active profile has the transaction list. */
    try{
      const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10'));
      const aid=mfActiveProfileId();
      const ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];
      return ap&&Array.isArray(ap.transactions)?ap.transactions:[];
    }catch(e){return[]}
  }

  function mfTransactionSnapshot(){
    const tx=mfReadLocalTransactions().map(t=>{
      try{return JSON.parse(JSON.stringify(t))}catch(e){return t}
    });
    tx.sort((a,b)=>String(b&&b.date||'').localeCompare(String(a&&a.date||''))||(new Date(b&&b.createdAt||0)-new Date(a&&a.createdAt||0)));
    return tx;
  }

  function collect(includeSecurity){
    const email=(()=>{try{return String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase()}catch(e){return''}})();
    const profiles=mfProfilesForCloud(),ap=profiles.find(p=>String(p.id)===String(mfActiveProfileId()))||profiles[0]||null;
    return {version:5,app:'PaisaFlow',dataType:'transactions-and-profiles',createdAt:new Date().toISOString(),accountEmail:email,activeProfileId:ap?String(ap.id):'',transactions:ap?mfCloneTxList(ap.transactions):mfTransactionSnapshot(),profiles:profiles};
  }

  function saveNative(){
    if(window.__mfV21CloudOnlyManualBackup)return false;
    try{if(window.AndroidBackup&&AndroidBackup.saveBackupSnapshot){AndroidBackup.saveBackupSnapshot(JSON.stringify(collect(false)));return true}}catch(e){}
    return false;
  }
  function schedule(){clearTimeout(backupTimer);backupTimer=setTimeout(saveNative,900)}
  function scheduleCloud(){
    if(cloudSyncSuppressed)return;
    clearTimeout(cloudTimer);
    cloudTimer=setTimeout(function(){
      try{mfRequestCloudUpload(mfTransactionSnapshot());}catch(e){}
    },250);
  }
  window.pfScheduleCloudSync=function(){try{scheduleCloud()}catch(e){}}
  window.pfCloudSyncNow=function(){
    if(cloudSyncSuppressed)return;
    try{mfRequestCloudUpload(mfTransactionSnapshot());}catch(e){}
  };
  window.mfBackupNow=function(){
    const localOk=saveNative();
    try{
      if(window.AndroidCloudBackup&&window.AndroidCloudBackup.uploadCloudBackup){
        const wasSuppressed=cloudSyncSuppressed;cloudSyncSuppressed=false;
        const started=mfRequestCloudUpload(mfTransactionSnapshot());cloudSyncSuppressed=wasSuppressed;
        if(!started)throw new Error('Cloud backup could not be started.');
      }else alert('Cloud backup service is not available on this build.');
    }catch(e){alert('Cloud backup failed: '+(e&&e.message?e.message:'Unknown error'))}
    /* Sync to Google Drive must not create a Downloads file. */
    return localOk;
  };
  window.mfOpenBackup=function(){
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    try{
      const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10'));
      const aid=mfActiveProfileId();
      const ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];
      const badge=document.getElementById('mfBackupAccount');
      if(badge&&ap)badge.textContent=ap.name||'My Money';
    }catch(e){}
    const m=document.getElementById('mfBackupModal');if(m)m.style.display='block';
    const st=document.getElementById('mfBackupStatus');if(st)st.textContent='Checking cloud backup status…';
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.getCloudStatus)AndroidCloudBackup.getCloudStatus();else if(st)st.textContent='Cloud backup is not available on this build.'}catch(e){if(st)st.textContent='Cloud backup status unavailable.'}
  };
  window.mfCloudStatusResult=function(text){const st=document.getElementById('mfBackupStatus');if(st)st.textContent=text;};
  window.logoutAfterBackup=false;

  window.mfCloudBackupResult=function(ok,backupMsg){
    const st=document.getElementById('mfBackupStatus');
    if(st && !autoReloadAfterCloudWrite)st.textContent=backupMsg;
    if(ok){
      try{if(typeof logAction==='function')logAction('cloud_backup_success')}catch(e){}
      const pending=mfReadPendingSnapshot();
      if(pending)mfCommitCloudUploadSnapshot(pending);
      const pendingProfiles=mfReadPendingProfiles();
      if(pendingProfiles){mfWriteProfileSyncSnapshot(pendingProfiles);mfClearPendingProfiles();}
    }
    cloudUploadBusy=false;
    if(window.logoutAfterBackup){
      window.logoutAfterBackup=false;
      if(ok){
        try{AndroidAuth.signOut()}catch(e){const x=document.getElementById('mfAccountMsg');if(x){x.textContent='Sign-out service unavailable.';x.className='mf-account-msg err';}}
      }else{
        const x=document.getElementById('mfAccountMsg');if(x){x.textContent='Backup failed. You are still signed in.';x.className='mf-account-msg err';}
      }
      return;
    }
    if(cloudUploadQueued && !window.logoutAfterBackup){
      cloudUploadQueued=false;
      setTimeout(function(){try{mfRequestCloudUpload(mfTransactionSnapshot())}catch(e){}},50);
      return;
    }
    if(autoReloadAfterCloudWrite){
      autoReloadAfterCloudWrite=false;
      cloudSyncSuppressed=false;
      setTimeout(function(){location.reload()},120);
    }
  };

  window.mfStartLogoutBackup=function(){
    if(window.logoutAfterBackup)return;
    window.logoutAfterBackup=true;
    cloudSyncSuppressed=true;
    clearTimeout(cloudTimer);
    autoReloadAfterCloudWrite=false;
    try{
      saveNative();
      if(window.AndroidCloudBackup&&AndroidCloudBackup.uploadCloudBackup){
        mfWritePendingSnapshot(mfTransactionSnapshot());
        cloudUploadBusy=true;
        AndroidCloudBackup.uploadCloudBackup(JSON.stringify(collect(false)));return;
      }
      throw new Error('Cloud backup service is not available on this build.');
    }catch(e){
      window.logoutAfterBackup=false;
      const x=document.getElementById('mfAccountMsg');
      if(x){x.textContent=e&&e.message==='Cloud backup service is not available on this build.'?e.message:'Cloud backup could not be started.';x.className='mf-account-msg err';}
    }
  };

  window.mfRestoreFromCloud=function(){
    try{if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return}}catch(e){}
    alert('Cloud restore is not available on this build.');
  };

  function mfParseCloudPayload(payload){
    try{
      const p=typeof payload==='string'?JSON.parse(payload):payload;if(!p||typeof p!=='object')return null;
      let profiles=Array.isArray(p.profiles)?p.profiles:null,transactions=Array.isArray(p.transactions)?p.transactions:null;
      if(!profiles&&p.storage&&typeof p.storage==='object'){
        const ps=mfParseArray(p.storage.money_manager_profiles_v10);if(ps.length)profiles=ps;
        if(!transactions){const direct=mfParseArray(p.storage.money_manager_v1);if(direct.length||Object.prototype.hasOwnProperty.call(p.storage,'money_manager_v1'))transactions=direct;}
        const aid=p.storage.money_manager_active_profile_v10||p.storage.activeProfileId||p.storage.currentProfileId||'';
        if(!transactions&&profiles&&profiles.length){const ap=profiles.find(x=>x&&String(x.id)===String(aid))||profiles[0];if(ap&&Array.isArray(ap.transactions))transactions=ap.transactions;}
      }
      return {profiles:profiles||[],activeProfileId:String(p.activeProfileId||''),transactions:transactions||[]};
    }catch(e){return null}
  }
  function mfNormalizeCloudTransactions(payload){const p=mfParseCloudPayload(payload);return p?mfCloneTxList(p.transactions):null;}

  function mfApplyTransactionSet(transactions){
    const tx=Array.isArray(transactions)?transactions.map(t=>{try{return mfEnsureTransactionUid(JSON.parse(JSON.stringify(t)))}catch(e){return mfEnsureTransactionUid(t)}}):[];
    try{localStorage.setItem('money_manager_v1',JSON.stringify(tx))}catch(e){throw e}
    try{if(typeof txs!=='undefined'&&Array.isArray(txs)){txs.length=0;tx.forEach(x=>txs.push(x));}}catch(e){}
    try{const ps=mfParseArray(localStorage.getItem('money_manager_profiles_v10')),aid=mfActiveProfileId(),ap=ps.find(x=>x&&String(x.id)===String(aid))||ps[0];if(ap){ap.transactions=tx.map(x=>mfCloneObject(x));localStorage.setItem('money_manager_profiles_v10',JSON.stringify(ps));}}catch(e){}
    return tx;
  }
  function mfRecalculateAfterRestore(){
    try{if(typeof sortTransactionsLatestFirst==='function')sortTransactionsLatestFirst()}catch(e){}
    try{if(typeof render==='function')render()}catch(e){}
    try{if(typeof window.pfRenderTransactionsPage==='function'&&document.getElementById('pfTransactionsPage')?.style.display!=='none')window.pfRenderTransactionsPage()}catch(e){}
    try{if(typeof window.pfRenderAnalytics==='function')window.pfRenderAnalytics()}catch(e){}
    try{if(typeof window.pfRenderAnalyticsFixed==='function')window.pfRenderAnalyticsFixed()}catch(e){}
    try{if(typeof window.pfRenderCategory==='function')window.pfRenderCategory()}catch(e){}
    try{if(typeof window.pfRenderSearch==='function')window.pfRenderSearch('')}catch(e){}
    try{window.dispatchEvent(new CustomEvent('moneyflow:transactions-restored',{detail:{count:mfReadLocalTransactions().length}}))}catch(e){}
  }

  let autoSync=false;
  window.mfAutoSyncAfterAuth=function(){
    let syncMarker='pf_tx_cloud_sync_done_signed_in';
    try{
      const em=String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase();
      syncMarker='pf_tx_cloud_sync_done_'+(em||'signed_in');
      if(sessionStorage.getItem(syncMarker)==='1')return;
      sessionStorage.setItem(syncMarker,'1');
    }catch(e){}
    clearTimeout(cloudTimer);cloudSyncSuppressed=true;autoSync=true;autoReloadAfterCloudWrite=false;
    try{
      if(window.AndroidCloudBackup&&AndroidCloudBackup.restoreCloudBackup){AndroidCloudBackup.restoreCloudBackup();return}
    }catch(e){}
    autoSync=false;cloudSyncSuppressed=false;
    try{
      autoReloadAfterCloudWrite=true;
      mfRequestCloudUpload(mfTransactionSnapshot());
    }catch(e){autoReloadAfterCloudWrite=false}
  };

  function mfShowCloudMessage(text){const st=document.getElementById('mfBackupStatus');if(st)st.textContent=text;}

  window.mfCloudRestoreResult=function(ok,payload){
    if(!ok){
      if(autoSync){
        autoSync=false;
        try{if(window.AndroidCloudBackup&&window.AndroidCloudBackup.uploadCloudBackup){autoReloadAfterCloudWrite=true;cloudSyncSuppressed=false;mfRequestCloudUpload(mfTransactionSnapshot());return;}}catch(e){}
      }
      cloudSyncSuppressed=false;mfShowCloudMessage(payload||'No cloud backup was found. Your current local data has not been changed.');return;
    }
    try{
      const cloud=mfParseCloudPayload(payload);if(!cloud)throw new Error('Invalid cloud backup.');
      if(Array.isArray(cloud.profiles)&&cloud.profiles.length){
        let mergedProfiles=mfMergeProfiles(cloud.profiles);
        const localAll=mfProfilesForCloud();
        /* On a fresh install, local automatic placeholders must never survive a cloud restore.
           Only profiles explicitly created/saved by the user are eligible to remain local-only. */
        const remoteIds=new Set(cloud.profiles.map(p=>String(p&&p.id)));
        const cleanedLocal=localAll.filter(p=>{
          const sec=p&&p.security||{};
          const untouched=String(p&&p.name||'')==='My Money' && (!Array.isArray(p&&p.transactions)||p.transactions.length===0) && !p.profilePhoto && !sec.pinHash && !sec.recoveryCode;
          if(untouched && p&&p.autoGeneratedProfile===true && !remoteIds.has(String(p.id)))return false;
          return true;
        });
        if(cleanedLocal.length!==localAll.length){
          const cleanedIds=new Set(cleanedLocal.map(p=>String(p.id)));
          mergedProfiles=mergedProfiles.filter(p=>cleanedIds.has(String(p.id)) || remoteIds.has(String(p.id)));
        }
        mfApplyProfiles(mergedProfiles,cloud.activeProfileId);
      }else{
        const mergedTransactions=mfMergeCloudWithLocal(mfCloneTxList(cloud.transactions));mfApplyTransactionSet(mergedTransactions);
      }
      mfRecalculateAfterRestore();saveNative();cloudSyncSuppressed=false;
      if(autoSync){autoSync=false;autoReloadAfterCloudWrite=true;mfRequestCloudUpload(mfTransactionSnapshot());return;}
      autoReloadAfterCloudWrite=true;
      if(mfRequestCloudUpload(mfTransactionSnapshot()))mfShowCloudMessage('✓ Cloud restored. Profiles/Modes, profile photos and PIN settings were restored; local unsynced transactions were preserved. Syncing merged data…');
      else{autoReloadAfterCloudWrite=false;mfShowCloudMessage('✓ Cloud restored. Profiles/Modes, profile photos and PIN settings were restored; local unsynced transactions were preserved.');setTimeout(function(){location.reload()},120);}
    }catch(e){cloudSyncSuppressed=false;autoSync=false;autoReloadAfterCloudWrite=false;mfShowCloudMessage('Cloud restore failed: '+(e&&e.message?e.message:'Invalid backup.'));}
  };

  window.mfCloseBackup=function(){const m=document.getElementById('mfBackupModal');if(m)m.style.display='none'};
  window.mfRestoreFromFile=function(){try{if(window.AndroidBackup&&AndroidBackup.openBackupFile){AndroidBackup.openBackupFile();return}}catch(e){}alert('Backup file picker is not available on this build.');};
  window.mfApplyBackup=function(json){
    try{
      const cloud=mfParseCloudPayload(json);if(!cloud)throw new Error('Invalid backup file');
      if(!confirm('Restore this backup? Profiles/Modes, profile photos and PIN settings will be restored, while local unsynced transactions will be preserved and merged. Notes remain local to this device.'))return;
      if(Array.isArray(cloud.profiles)&&cloud.profiles.length)mfApplyProfiles(mfMergeProfiles(cloud.profiles),cloud.activeProfileId);
      else mfApplyTransactionSet(mfMergeCloudWithLocal(mfCloneTxList(cloud.transactions)));
      mfRecalculateAfterRestore();saveNative();autoReloadAfterCloudWrite=true;
      if(mfRequestCloudUpload(mfTransactionSnapshot()))alert('Backup restored. Profiles/Modes, photos and PIN settings were restored, and local unsynced transactions were preserved and merged. Syncing the merged backup now.');
      else{autoReloadAfterCloudWrite=false;alert('Backup restored. Profiles/Modes, photos and PIN settings were restored, and local unsynced transactions were preserved and merged.');location.reload();}
    }catch(e){alert('Backup restore failed: '+(e&&e.message?e.message:'Unknown error'))}
  };
  // V46 FIX: never auto-restore the legacy device-wide recovery snapshot.
  // That snapshot is not account-scoped, so restoring it at startup can
  // re-introduce another account's transactions into a newly signed-in user.
  // Account-isolated local data is now loaded only by v46Activate(uid).
  // Google Drive account backup is the automatic recovery mechanism.
  window.mfMaybeRestoreNative=function(){ return false; };
  const oldSet=Storage.prototype.setItem;
  Storage.prototype.setItem=function(k,v){
    const r=oldSet.apply(this,arguments);
    /* IMPORTANT: auto cloud sync is transaction-only. Notes, profile/security,
       UI settings and other localStorage writes must never trigger cloud sync. */
    if(this===localStorage && k===KEY){
      schedule();
      if(!cloudSyncSuppressed)scheduleCloud();
    }
    return r;
  };
  window.addEventListener('load',function(){
    setTimeout(function(){
      saveNative();
      mfMaybeRestoreNative();
    },1200);
  });
})();


/* Money Flow V34 — strict Google-account data isolation
   When authentication changes from one account to another on the same install,
   detach the previous account's device-local working set before restoring the
   newly authenticated account. Cloud data is preserved; only the active local
   cache/sync context is cleared. */
(function(){
  const ACCOUNT_LOCAL_KEYS=[
    'money_manager_v1',
    'money_manager_profiles_v10',
    'money_manager_active_profile_v10',
    'activeProfileId',
    'currentProfileId',
    'money_manager_config',
    'money_manager_edit_security_v1',
    'mm_global_pin',
    'globalPin',
    'globalPinHash',
    'pinHash',
    'mf_cloud_tx_snapshot_v1',
    'mf_cloud_tx_pending_v1',
    'mf_cloud_profile_snapshot_v1',
    'mf_cloud_profile_pending_v1'
  ];

  function clearAccountLocalContext(){
    try{ACCOUNT_LOCAL_KEYS.forEach(k=>localStorage.removeItem(k));}catch(e){}
    try{
      const remove=[];
      for(let i=0;i<localStorage.length;i++){
        const k=localStorage.key(i);
        if(k && k.indexOf('money_flow_profile_photo_')===0)remove.push(k);
      }
      remove.forEach(k=>localStorage.removeItem(k));
    }catch(e){}
    try{
      for(let i=sessionStorage.length-1;i>=0;i--){
        const k=sessionStorage.key(i);
        if(k && (k.indexOf('pf_tx_cloud_sync_done_')===0 || k.indexOf('pf_auto_cloud_sync_done_')===0))sessionStorage.removeItem(k);
      }
    }catch(e){}
  }

  window.mfPrepareAccountContext=function(newEmail){
    const next=String(newEmail||'').trim().toLowerCase();
    let previous='';
    try{
      previous=String(localStorage.getItem('mf_account_email')||localStorage.getItem('mf_last_account_email')||'').trim().toLowerCase();
    }catch(e){}
    if(previous && next && previous!==next){
      clearAccountLocalContext();
      try{localStorage.setItem('mf_last_account_email',previous)}catch(e){}
      return true;
    }
    return false;
  };

  window.mfClearAccountSessionMarkers=function(){
    try{
      for(let i=sessionStorage.length-1;i>=0;i--){
        const k=sessionStorage.key(i);
        if(k && (k.indexOf('pf_tx_cloud_sync_done_')===0 || k.indexOf('pf_auto_cloud_sync_done_')===0))sessionStorage.removeItem(k);
      }
    }catch(e){}
  };
})();

/* Money Flow Firebase Account / Login */
(function(){
  let mode='login', autoSyncPending=false, authGateActive=false;
  function el(id){return document.getElementById(id)}
  function msg(text,ok){const x=el('mfAccountMsg');if(!x)return;x.textContent=text||'';x.className='mf-account-msg '+(ok?'ok':'err')}
  function showVerification(message,email){
    const panel=el('mfEmailVerificationPanel');
    const text=el('mfEmailVerificationText');
    const signedOut=el('mfAccountSignedOut');
    const note=el('mfAccountRequiredNote');
    if(signedOut)signedOut.style.display='block';
    if(panel)panel.style.display='block';
    if(note)note.style.display='none';
    if(text)text.textContent=(message||'Your email address is not verified yet.')+(email?' Verification email/account: '+email+'.':'');
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').classList.remove('active');
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').classList.remove('active');
    ['mfAccountNameWrap','mfAccountConfirmWrap','mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='none'});
  }
  function hideVerification(){
    const panel=el('mfEmailVerificationPanel');
    if(panel)panel.style.display='none';
    ['mfAccountPrimary','mfGoogleBtn','mfGuestBtn','mfAccountReset'].forEach(id=>{const x=el(id);if(x)x.style.display='block'});
    if(el('mfAccountNameWrap'))el('mfAccountNameWrap').style.display='none';
    if(el('mfAccountConfirmWrap'))el('mfAccountConfirmWrap').style.display='none';
    if(el('mfAccountLoginTab'))el('mfAccountLoginTab').style.display='block';
    if(el('mfAccountSignupTab'))el('mfAccountSignupTab').style.display='block';
  }
  function signedIn(email,name){
    /* A different authenticated account must never inherit the previous
       account's local transactions/profiles/config/sync baseline. */
    try{if(typeof window.mfPrepareAccountContext==='function')window.mfPrepareAccountContext(email)}catch(e){}
    el('mfAccountSignedOut').style.display='none';
    el('mfAccountSignedIn').style.display='block';
    el('mfAccountEmail').textContent=email||'';
    el('mfAccountName').textContent=name||'Money Flow Account';
    const b=el('mfAccountSignedMsg');if(b)b.textContent='Signed in. Cloud Backup is linked to this account.';
    const badge=el('mfBackupAccount');
    if(badge){
      try{
        const ps=JSON.parse(localStorage.getItem('money_manager_profiles_v10')||'[]');
        const aid=localStorage.getItem('money_manager_active_profile_v10') || localStorage.getItem('activeProfileId') || localStorage.getItem('currentProfileId') || '';
        const ap=Array.isArray(ps)?(ps.find(x=>x&&x.id===aid)||ps[0]):null;
        badge.textContent=ap&&ap.name ? ap.name : (email||'Signed in');
      }catch(e){badge.textContent=email||'Signed in';}
    }
    try{
      const normalized=String(email||'').trim().toLowerCase();
      localStorage.setItem('mf_account_mode','account');
      localStorage.setItem('mf_account_email',normalized);
      localStorage.setItem('mf_last_account_email',normalized);
    }catch(e){}
    if(authGateActive){authGateActive=false;const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}}
  }
  function signedOut(){
    el('mfAccountSignedOut').style.display='block';
    el('mfAccountSignedIn').style.display='none';
    const badge=el('mfBackupAccount');if(badge)badge.textContent='Sign in with Google';
    try{
      const current=String(localStorage.getItem('mf_account_email')||'').trim().toLowerCase();
      if(current)localStorage.setItem('mf_last_account_email',current);
      localStorage.removeItem('mf_account_email');
      if(typeof window.mfClearAccountSessionMarkers==='function')window.mfClearAccountSessionMarkers();
    }catch(e){}
    if(authGateActive){const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}}
  }
  window.mfAccountMode=function(m){
    hideVerification();
    mode=m;
    const signup=m==='signup';
    el('mfAccountLoginTab').classList.toggle('active',!signup);
    el('mfAccountSignupTab').classList.toggle('active',signup);
    el('mfAccountNameWrap').style.display=signup?'block':'none';
    el('mfAccountConfirmWrap').style.display=signup?'block':'none';
    el('mfAccountPrimary').textContent=signup?'Create Account':'Login';
    el('mfAccountReset').style.display=signup?'none':'block';
    el('mfAccountPasswordInput').autocomplete=signup?'new-password':'current-password';
    msg('');
  };
  window.mfOpenAccount=function(mandatory){
    authGateActive=!!mandatory;
    try{if(typeof closeMenu==='function')closeMenu()}catch(e){}
    const m=el('mfAccountModal');
    if(m){m.classList.toggle('mf-account-modal-mandatory',authGateActive);m.style.display='block';}
    msg('');
    try{if(window.AndroidAuth&&AndroidAuth.getStatus)AndroidAuth.getStatus();}catch(e){}
  };
  window.mfCloseAccount=function(){if(authGateActive)return;const m=el('mfAccountModal');if(m)m.style.display='none'};
  window.mfContinueGuest=function(){
    if(authGateActive)return;
    try{localStorage.setItem('mf_account_mode','guest')}catch(e){}
    msg('Guest mode enabled. Your data remains on this device.',true);
    setTimeout(mfCloseAccount,450);
  };
  window.mfAccountSubmit=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    const password=el('mfAccountPasswordInput').value||'';
    if(!email){msg('Enter your email address.');return}
    if(mode==='signup') {
      const name=(el('mfAccountNameInput').value||'').trim();
      const confirm=el('mfAccountConfirmInput').value||'';
      if(password.length<6){msg('Password must be at least 6 characters.');return}
      if(password!==confirm){msg('Passwords do not match.');return}
      msg('Creating account…',true);
      try{AndroidAuth.signUp(name,email,password)}catch(e){msg('Account service unavailable.')}
    } else {
      msg('Signing in…',true);
      try{AndroidAuth.signIn(email,password)}catch(e){msg('Account service unavailable.')}
    }
  };
  window.mfGoogleLogin=function(){
    msg('Opening Google Sign-In…',true);
    try{AndroidAuth.signInWithGoogle()}catch(e){msg('Google Sign-In service unavailable.')}
  };
  window.mfAccountReset=function(){
    const email=(el('mfAccountEmailInput').value||'').trim();
    if(!email){msg('Enter your account email first.');return}
    msg('Sending password reset email…',true);
    try{AndroidAuth.resetPassword(email)}catch(e){msg('Account service unavailable.')}
  };
  window.mfCheckEmailVerification=function(){
    msg('Checking email verification status…',true);
    try{AndroidAuth.checkEmailVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfBackToLogin=function(){
    hideVerification();
    try{AndroidAuth.signOut()}catch(e){}
    window.mfAccountMode('login');
    msg('Please verify your email first, then log in.');
  };
  window.mfAccountLogout=function(){
    if(typeof window.mfStartLogoutBackup==='function'){
      window.mfStartLogoutBackup();
      return;
    }
    msg('Cloud backup service is not available on this build.');
  };
  window.mfResendVerification=function(){
    msg('Sending verification email…',true);
    try{AndroidAuth.resendVerification()}catch(e){msg('Verification service unavailable.')}
  };
  window.mfAuthResult=function(ok,action,message,email,name){
    if(action==='status'){
      const onboardingComplete=localStorage.getItem('money_flow_onboarding_complete_v1')==='1';
      if(message==='signed_in'){
        hideVerification();
        signedIn(email,name);
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      } else if(message==='verify_required'){
        authGateActive=true;
        showVerification('Your email address is not verified yet. Open the verification email and tap its verification link.',email);
        const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      } else if(onboardingComplete){
        authGateActive=true;
        signedOut();
      } else {
        signedOut();
      }
      return;
    }
    if(ok && action==='verify_required'){
      authGateActive=true;
      showVerification(message,email);
      const m=el('mfAccountModal');if(m){m.classList.add('mf-account-modal-mandatory');m.style.display='block';}
      msg(message,true);
      return;
    }
    if(ok && (action==='login'||action==='google'||action==='signup')){
      signedIn(email,name);
      msg(message,true);
      if(action==='login'||action==='google'){
        autoSyncPending=true;
        try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      }
      return;
    }
    if(ok && action==='logout'){
      signedOut();msg(message,true);return;
    }
    if(ok && action==='reset'){msg(message,true);return}
    if(ok && action==='verify_sent'){msg(message,true);return}
    if(ok && action==='verified'){
      hideVerification();
      authGateActive=false;
      const m=el('mfAccountModal');if(m){m.classList.remove('mf-account-modal-mandatory');m.style.display='none';}
      msg(message,true);
      try{if(window.mfAutoSyncAfterAuth)window.mfAutoSyncAfterAuth();}catch(e){}
      return;
    }
    if(!ok && action==='verify_check'){msg(message,false);return}
    msg(message||'Authentication failed.');
  };
  window.addEventListener('load',function(){
    try{
      if(localStorage.getItem('money_flow_onboarding_complete_v1')==='1' && window.AndroidAuth&&AndroidAuth.getStatus) AndroidAuth.getStatus();
    }catch(e){}
  });
})();



/* V64 — PROFILE SWITCH ADD-TRANSACTION SECURITY UI REFRESH
   Scope: UI-state refresh only.
   - Reads security state from the newly active Profile/Mode after switching.
   - Removes stale Add Transaction/PIN overlays from the previous profile.
   - Refreshes the Add Transaction lock/unlock indicator for the destination profile.
   - Does NOT modify PIN hashes, biometric credentials, transactions, backup/restore,
     dashboard data, authentication, or profile data.
*/
(function(){
  const PK="money_manager_profiles_v10";
  const AK="money_manager_active_profile_v10";

  function activeProfileFresh(){
    try{
      const ps=JSON.parse(localStorage.getItem(PK)||"[]");
      if(!Array.isArray(ps)) return null;
      const id=localStorage.getItem(AK);
      return ps.find(p=>p&&p.id===id)||ps[0]||null;
    }catch(e){return null;}
  }

  function refreshAddTransactionForActiveProfile(){
    const p=activeProfileFresh();
    const on=!!(p&&p.security&&p.security.addProtection);

    // Close any security UI belonging to the previous profile. The destination
    // profile must start with a clean Add Transaction security state.
    ["v10AddTxGate","v10AddTxSettingGate","v10AddTxPinModal"].forEach(function(id){
      const el=document.getElementById(id);
      if(el) el.style.display="none";
    });

    // Refresh every visible Add Transaction security indicator directly from
    // the currently selected profile instead of reusing the previous UI state.
    const toggle=document.getElementById("v10AddTxPinToggle");
    if(toggle) toggle.checked=on;

    const state=document.getElementById("v10AddTxPinState");
    if(state) state.textContent=on ? "ON — PIN required before adding" : "OFF — no PIN required";

    const menuStatus=document.getElementById("v10MenuAddTxStatus");
    if(menuStatus) menuStatus.textContent=on ? "🔒 ON" : "🔓 OFF";

    const addButton=document.getElementById("v10AddTxButton");
    if(addButton) addButton.textContent=on ? "🔒 Add Transaction (PIN)" : "Save Transaction";

    // If the app already exposes its normal refresh function, run it once too;
    // this keeps any existing UI elements synchronized without changing logic.
    try{
      if(typeof window.v10RefreshAddTxSecurityUI === "function")
        window.v10RefreshAddTxSecurityUI();
    }catch(e){}
  }

  const previousSwitch=window.v10SwitchProfile;
  if(typeof previousSwitch === "function" && !previousSwitch.__mfV64ProfileRefresh){
    const wrapped=function(id){
      const result=previousSwitch.apply(this,arguments);
      // The active profile ID is changed by previousSwitch first. Refresh only
      // after that change so the UI reads the destination profile's state.
      setTimeout(refreshAddTransactionForActiveProfile,0);
      return result;
    };
    wrapped.__mfV64ProfileRefresh=true;
    window.v10SwitchProfile=wrapped;
  }

  // Also repair the UI once on startup without changing any saved security state.
  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",function(){setTimeout(refreshAddTransactionForActiveProfile,0);});
  }else{
    setTimeout(refreshAddTransactionForActiveProfile,0);
  }
})();



/* FINAL TRANSACTIONS FUNCTIONALITY FIX
   - Analytics/Search/Category operate on the same active transaction data.
   - Weekly navigation uses a real week anchor and crosses month boundaries correctly.
   - Transaction rows expose all stored details with an expand/collapse control.
   - Edit uses type-specific categories and requires category re-selection after type changes.
   - Existing Sign-Out/Drive backup and unrelated app logic are untouched.
*/
(function(){
  function pfReadTx(){
    try{
      if(typeof txs!=='undefined' && Array.isArray(txs)) return txs.slice().sort(compareTransactionsLatestFirst);
    }catch(e){}
    return [];
  }
  function pad(n){return String(n).padStart(2,'0')}
  function dateStr(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
  function monthBounds(ym){
    const [y,m]=String(ym).split('-').map(Number);
    const first=new Date(y,m-1,1), last=new Date(y,m,0);
    return {from:dateStr(first),to:dateStr(last)};
  }
  function currentMonth(){return new Date().getFullYear()+'-'+pad(new Date().getMonth()+1)}

  // --- Transaction period state (fixes Weekly Previous/Next) ---
  const state=window.__pfTxFinalState||{view:'monthly',month:currentMonth(),weekAnchor:dateStr(new Date())};
  window.__pfTxFinalState=state;
  function ensureWeekAnchor(){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(state.weekAnchor)) state.weekAnchor=monthBounds(state.month).from;
    const d=new Date(state.weekAnchor+'T00:00:00');
    if(Number.isNaN(d.getTime())) state.weekAnchor=monthBounds(state.month).from;
  }
  function weekBounds(){
    ensureWeekAnchor();
    const d=new Date(state.weekAnchor+'T00:00:00');
    const day=d.getDay();
    d.setDate(d.getDate()-day);
    const e=new Date(d);e.setDate(e.getDate()+6);
    return {from:dateStr(d),to:dateStr(e)};
  }
  function filtered(){
    const b=monthBounds(state.month);let from=b.from,to=b.to;
    if(state.view==='daily'){
      const v=document.getElementById('pfTxDayPicker')?.value;from=to=v||b.from;
    }else if(state.view==='weekly'){
      const w=weekBounds();from=w.from;to=w.to;
    }else if(state.view==='custom'){
      from=document.getElementById('pfTxFrom')?.value||b.from;
      to=document.getElementById('pfTxTo')?.value||b.to;
      if(from>to){const x=from;from=to;to=x;}
    }
    return {from,to,data:pfReadTx().filter(t=>String(t.date||'')>=from&&String(t.date||'')<=to)};
  }
  function syncControls(){
    const b=monthBounds(state.month);
    const mb=document.getElementById('pfTxMonthButton');
    if(mb){const [y,m]=state.month.split('-').map(Number);mb.innerHTML=new Date(y,m-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'})+' <span>⌄</span>';}
    const dp=document.getElementById('pfTxDayPicker');
    if(dp){if(!dp.value||dp.value.slice(0,7)!==state.month)dp.value=b.from;dp.min=b.from;dp.max=b.to;}
    const f=document.getElementById('pfTxFrom'),t=document.getElementById('pfTxTo');
    if(f&&!f.value)f.value=b.from;if(t&&!t.value)t.value=b.to;
    const w=weekBounds(),wl=document.getElementById('pfTxWeekLabel');if(wl)wl.textContent=w.from+' → '+w.to;
  }
  function renderRows(data){
    const list=document.getElementById('pfTransactionsList');if(!list)return;
    list.innerHTML='';
    if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this view.</div>';return;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));
      const type=t.type==='CREDIT'?'income':'expense';
      const sign=t.type==='CREDIT'?'+':'-';
      const fields=[
        ['Date',t.date||'—'],['Type',t.type==='CREDIT'?'Credit':'Expense'],['Amount',sign+money(t.amount)],
        ['Category',t.category||'Uncategorized'],['Payment Mode',t.mode||t.paymentMode||'Not specified'],
        ['Description',t.description||t.desc||'—'],['Remark',t.remark||t.remarks||t.note||'—'],['Other',t.other||t.otherInfo||t.other_info||'—']
      ];
      row.innerHTML=`<div class="pf-detail-main"><div class="pf-swipe-icon ${type}">${t.type==='CREDIT'?'↓':'↑'}</div><div class="pf-detail-summary"><div class="pf-detail-title">${escapeHtml(t.category||'Uncategorized')}</div><div class="pf-detail-meta">${escapeHtml(t.date||'')} • ${escapeHtml(t.mode||'Not specified')}</div><div class="pf-detail-secondary">${t.description?escapeHtml(t.description):'No description'}${t.remark?' • Remark: '+escapeHtml(t.remark):''}</div></div><div class="pf-swipe-amount ${type}">${sign}${money(t.amount)}</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-panel-title">Transaction Details</div>${fields.map(([k,v])=>`<div class="pf-detail-field"><span>${k}</span><b class="${k==='Amount'?type:''}">${escapeHtml(String(v))}</b></div>`).join('')}<div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>`;
      const main=row.querySelector('.pf-detail-main'),exp=row.querySelector('.pf-expand-btn'),panel=row.querySelector('.pf-detail-panel'),edit=row.querySelector('.pf-swipe-edit');
      exp.addEventListener('click',()=>{const open=row.classList.toggle('expanded');exp.textContent=open?'⌃':'⌄';exp.setAttribute('aria-expanded',open?'true':'false');panel.style.display=open?'block':'none';});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      list.appendChild(row);
    });
  }
  function render(){
    syncControls();const q=filtered();let income=0,expense=0;q.data.forEach(t=>t.type==='CREDIT'?income+=Number(t.amount)||0:expense+=Number(t.amount)||0);
    const lab={daily:'Daily',weekly:'Weekly',monthly:'Monthly',custom:'Custom'}[state.view]||'Monthly';
    const sum=document.getElementById('pfTransactionsSummary');if(sum)sum.textContent=`${lab} • ${q.from} → ${q.to} • ${q.data.length} transaction(s) • Income ${money(income)} • Expense ${money(expense)} • Balance ${money(income-expense)}`;
    renderRows(q.data);
  }
  window.pfTxFinalFiltered=filtered;
  window.pfTxRender=render;
  window.pfTxShiftMonth=function(delta){const [y,m]=state.month.split('-').map(Number);const d=new Date(y,m-1+delta,1);state.month=d.getFullYear()+'-'+pad(d.getMonth()+1);state.weekAnchor=state.month+'-01';syncControls();render();};
  window.pfTxSetMonth=function(v){if(/^\d{4}-\d{2}$/.test(v)){state.month=v;state.weekAnchor=v+'-01';const el=document.getElementById('pfTxMonthPicker');if(el)el.style.display='none';syncControls();render();}};
  window.pfTxShiftWeek=function(delta){ensureWeekAnchor();const d=new Date(state.weekAnchor+'T00:00:00');d.setDate(d.getDate()+delta*7);state.weekAnchor=dateStr(d);state.month=state.weekAnchor.slice(0,7);syncControls();render();};
  window.pfTxSetView=function(view,btn){state.view=view;document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===btn));if(view==='weekly'){if(!state.weekAnchor)state.weekAnchor=dateStr(new Date());}else if(view==='daily'){const b=monthBounds(state.month);const dp=document.getElementById('pfTxDayPicker');if(dp&&!dp.value)dp.value=b.from;}document.getElementById('pfTxDailyControls').style.display=view==='daily'?'flex':'none';document.getElementById('pfTxWeeklyControls').style.display=view==='weekly'?'flex':'none';document.getElementById('pfTxCustomControls').style.display=view==='custom'?'grid':'none';syncControls();render();};
  window.pfRenderTransactionsPage=function(){syncControls();const active=document.querySelector('.pf-tx-tabs button[data-view="'+state.view+'"]');document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b===active));document.getElementById('pfTxDailyControls').style.display=state.view==='daily'?'flex':'none';document.getElementById('pfTxWeeklyControls').style.display=state.view==='weekly'?'flex':'none';document.getElementById('pfTxCustomControls').style.display=state.view==='custom'?'grid':'none';render();};

  // --- Analytics/Search/Category: no dependency on the private IIFE helpers ---
  function openFeature(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  function closeFeature(id){const m=document.getElementById(id);if(m)m.classList.remove('open');if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow='';}
  window.pfCloseFeature=closeFeature;
  let analyticsType='EXPENSE',catType='EXPENSE',catPeriod='all';
  function analyticsData(){return filtered().data.filter(t=>t.type===analyticsType);}
  function renderAnalytics(){const data=analyticsData(),by={};data.forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,x)=>a+x[1],0),donut=document.getElementById('pfDonut'),legend=document.getElementById('pfAnalyticsLegend');if(!donut||!legend)return;document.getElementById('pfDonutTotal').textContent=money(total);document.getElementById('pfDonutCaption').textContent=analyticsType==='EXPENSE'?'Total Expense':'Total Income';if(!entries.length){donut.style.background='conic-gradient(#e8e3d9 0 100%)';legend.innerHTML='<div class="pf-empty">No data available for this period.</div>';return;}const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];let start=0;donut.style.background='conic-gradient('+entries.map((x,i)=>{const end=start+x[1]/total*100;const z=palette[i%palette.length]+' '+start+'% '+end+'%';start=end;return z}).join(',')+')';legend.innerHTML=entries.map((x,i)=>`<div class="pf-legend-row"><i class="pf-legend-dot" style="background:${palette[i%palette.length]}"></i><b>${escapeHtml(x[0])}</b><span>${money(x[1])} · ${(x[1]/total*100).toFixed(1)}%</span></div>`).join('');}
  window.pfOpenAnalytics=function(){openFeature('pfAnalyticsModal');renderAnalytics();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense').classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome').classList.toggle('active',type==='CREDIT');renderAnalytics();};
  function renderSearch(q){const list=document.getElementById('pfSearchResults');if(!list)return;const query=String(q||'').trim().toLowerCase();let data=pfReadTx();if(query)data=data.filter(t=>[t.date,t.type,t.amount,t.category,t.description,t.remark,t.mode,t.other].some(v=>String(v??'').toLowerCase().includes(query)));list.innerHTML=data.length?data.slice(0,100).map(t=>`<div class="pf-search-result"><div><b>${escapeHtml(t.category||'Uncategorized')}</b><small>${escapeHtml(t.date||'')} • ${escapeHtml(t.mode||'')}${t.description?' • '+escapeHtml(t.description):''}${t.remark?' • Remark: '+escapeHtml(t.remark):''}</small></div><strong style="color:${t.type==='CREDIT'?'#2fa65b':'#e3483d'}">${t.type==='CREDIT'?'+':'-'}${money(t.amount)}</strong></div>`).join(''):'<div class="pf-empty">No matching transactions found.</div>';}
  window.pfOpenSearch=function(){openFeature('pfSearchModal');const input=document.getElementById('pfSearchInput');if(input){input.value='';setTimeout(()=>input.focus(),80);}renderSearch('');};
  window.pfOpenCategory=function(){openFeature('pfCategoryModal');const b=monthBounds(state.month);const f=document.getElementById('pfCatFrom'),t=document.getElementById('pfCatTo');if(f)f.value=b.from;if(t)t.value=b.to;renderCategory();};
  function catRange(){const b=monthBounds(state.month);if(catPeriod==='month')return b;if(catPeriod==='year'){const y=Number(state.month.slice(0,4));return {from:y+'-01-01',to:y+'-12-31'};}if(catPeriod==='custom'){let f=document.getElementById('pfCatFrom')?.value||b.from,t=document.getElementById('pfCatTo')?.value||b.to;if(f>t){const x=f;f=t;t=x;}return {from:f,to:t};}return {from:'0000-01-01',to:'9999-12-31'};}
  function renderCategory(){const r=catRange(),by={};pfReadTx().filter(t=>t.type===catType&&String(t.date||'')>=r.from&&String(t.date||'')<=r.to).forEach(t=>{const c=t.category||'Uncategorized';by[c]=(by[c]||0)+(Number(t.amount)||0)});const entries=Object.entries(by).sort((a,b)=>b[1]-a[1]),total=entries.reduce((a,x)=>a+x[1],0),list=document.getElementById('pfCategoryList');if(!list)return;document.getElementById('pfCategoryTotal').textContent=money(total);list.innerHTML=entries.length?entries.map(x=>`<div class="pf-category-row"><div class="pf-category-avatar">${escapeHtml(x[0].charAt(0).toUpperCase())}</div><div class="pf-category-name">${escapeHtml(x[0])}</div><div class="pf-category-amount">${money(x[1])}</div></div>`).join(''):'<div class="pf-empty">No transactions in this category view.</div>';}
  window.pfCategorySetType=function(type){catType=type;document.getElementById('pfCatIncome').classList.toggle('active',type==='CREDIT');document.getElementById('pfCatExpense').classList.toggle('active',type==='EXPENSE');renderCategory();};
  window.pfCategorySetPeriod=function(period,btn){catPeriod=period;document.querySelectorAll('[data-cat-period]').forEach(b=>b.classList.toggle('active',b===btn));document.getElementById('pfCatCustom').style.display=period==='custom'?'grid':'none';renderCategory();};
  document.addEventListener('input',e=>{if(e.target?.id==='pfSearchInput')renderSearch(e.target.value);if(e.target?.id==='pfCatFrom'||e.target?.id==='pfCatTo')renderCategory();});

  // --- Edit category/type consistency ---
  function profileConfig(){try{return JSON.parse(localStorage.getItem('money_manager_config')||'null')||{}}catch(e){return {}}}
  function getConfig(){const c=profileConfig();return {credit:Array.isArray(c.creditCategories)&&c.creditCategories.length?c.creditCategories:['Salary','Income','Gift'],expense:Array.isArray(c.expenseCategories)&&c.expenseCategories.length?c.expenseCategories:['Food','Travel','Grocery','Other']};}
  function editType(){return document.getElementById('editType')?.value||'CREDIT'}
  function editCats(){const c=getConfig();return editType()==='CREDIT'?c.credit:c.expense}
  let editCategoryNeedsSelection=false;
  function fillEditCategories(keep){const sel=document.getElementById('editCategory');if(!sel)return;const cats=editCats();const old=keep===undefined?sel.value:keep;sel.innerHTML='<option value="">Select category</option>'+cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')+'<option value="CUSTOM">Custom</option>';if(old&&cats.includes(old))sel.value=old;else if(old==='CUSTOM')sel.value='CUSTOM';else sel.value='';const custom=document.getElementById('editCustomCategory');if(custom){custom.style.display=sel.value==='CUSTOM'?'block':'none';if(sel.value==='CUSTOM'&&!custom.value)custom.focus();}}
  window.pfEditCategoryChanged=function(){const sel=document.getElementById('editCategory'),custom=document.getElementById('editCustomCategory'),notice=document.getElementById('editCategoryNotice');if(!sel)return;if(sel.value==='CUSTOM'){if(custom){custom.style.display='block';} }else if(custom){custom.style.display='none';custom.value='';}if(notice){notice.style.display='none';notice.textContent='';}editCategoryNeedsSelection=false;};
  window.pfGetEditCategoryValue=function(){const sel=document.getElementById('editCategory');if(!sel)return '';if(sel.value==='CUSTOM')return (document.getElementById('editCustomCategory')?.value||'').trim();return sel.value.trim();};
  function typeChanged(){fillEditCategories('');editCategoryNeedsSelection=true;const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='Transaction type changed. Please select a new category for this type.';}}
  function setupEditType(){const t=document.getElementById('editType');if(!t||t.__pfFinalBound)return;t.__pfFinalBound=true;t.addEventListener('change',typeChanged);}
  const originalV10Edit=window.v10RequestEdit;
  window.v10RequestEdit=function(id){
    if(typeof originalV10Edit==='function')originalV10Edit(id);
    setTimeout(function(){
      setupEditType();const t=pfReadTx().find(x=>String(x.id)===String(id));const sel=document.getElementById('editCategory'),custom=document.getElementById('editCustomCategory');if(!sel||!t)return;
      const cats=editCats();if(cats.includes(t.category)){fillEditCategories(t.category);editCategoryNeedsSelection=false;}else{fillEditCategories('');editCategoryNeedsSelection=true;const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='This saved category belongs to a different transaction type. Please select a new category before saving.';}}
      if(custom)custom.value='';
    },30);
  };
  // Keep direct openEdit callers consistent too.
  const originalOpenEdit=window.openEdit;
  window.openEdit=function(id){if(typeof originalOpenEdit==='function')originalOpenEdit(id);setTimeout(()=>{setupEditType();const t=pfReadTx().find(x=>String(x.id)===String(id));if(t){const c=getConfig(),cats=t.type==='CREDIT'?c.credit:c.expense;fillEditCategories(cats.includes(t.category)?t.category:'');}},30);};
  // Wrap saveEdit to enforce a valid category after a type change.
  const originalSaveEdit=window.saveEdit;
  window.saveEdit=function(){const cat=window.pfGetEditCategoryValue();if(!cat){alert('Please select a category for the selected transaction type.');return;}const cats=editCats();if(document.getElementById('editCategory')?.value==='CUSTOM' && !cat){alert('Please enter a custom category.');return;}if(!document.getElementById('editCategory')?.value || (document.getElementById('editCategory').value!=='CUSTOM'&&!cats.includes(cat))){alert('Please select a valid category for the selected transaction type.');return;}if(typeof originalSaveEdit==='function')return originalSaveEdit();};

  function boot(){try{setupEditType();syncControls();}catch(e){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(boot,300);setTimeout(boot,900);
})();



(function(){
  'use strict';
  const pad=n=>String(n).padStart(2,'0');
  const nowDate=()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  const txsNow=()=>{try{return (typeof pfReadTx==='function'?pfReadTx():(typeof txs!=='undefined'?txs:[]))||[]}catch(e){return[]}};
  const esc=v=>typeof escapeHtml==='function'?escapeHtml(v):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const money2=v=>typeof money==='function'?money(v):'₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
  const norm=v=>String(v==null?'':v).toLocaleLowerCase('en-IN').trim();
  const typeLabel=t=>String(t||'').toUpperCase()==='CREDIT'?'Credit':'Expense';
  const monthBounds2=ym=>{const [y,m]=String(ym).split('-').map(Number);const last=new Date(y,m,0).getDate();return {from:y+'-'+pad(m)+'-01',to:y+'-'+pad(m)+'-'+pad(last)};};
  const addDays=(ds,n)=>{const d=new Date(ds+'T00:00:00');d.setDate(d.getDate()+n);return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  const diffPct=(a,b)=>{a=Number(a)||0;b=Number(b)||0;if(b===0)return a===0?0:100;return ((a-b)/Math.abs(b))*100;};
  const pfState=()=>window.__pfTxFinalState||{};

  /* 1) Restore a real right-to-left swipe -> Edit reveal button. */
  function enhanceSwipeRows(root){
    const list=root||document.getElementById('pfTransactionsList');if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(row=>{
      const main=row.querySelector('.pf-detail-main');if(!main)return;
      let b=row.querySelector('.pf-swipe-reveal');
      if(!b){
        b=document.createElement('button');
        b.type='button';
        b.className='pf-swipe-reveal';
        b.textContent='Edit';
        b.setAttribute('aria-label','Edit transaction');
        b.addEventListener('click',e=>{
          e.stopPropagation();
          const id=row.getAttribute('data-tx-id');
          if(id!=null && id!=='' && typeof v10RequestEdit==='function') v10RequestEdit(id);
        });
        row.insertBefore(b,main);
      }
      if(row.dataset.swipeV8==='1')return;
      row.dataset.swipeV8='1';
      let sx=0,sy=0,moved=false;
      const closeRow=()=>{
        row.classList.remove('open');
        main.style.transform='translateX(0)';
      };
      main.addEventListener('touchstart',e=>{
        const t=e.touches&&e.touches[0];if(!t)return;
        sx=t.clientX;sy=t.clientY;moved=false;
        main.style.transition='none';
      },{passive:true});
      main.addEventListener('touchmove',e=>{
        const t=e.touches&&e.touches[0];if(!t)return;
        const dx=t.clientX-sx,dy=t.clientY-sy;
        if(Math.abs(dx)>8 && Math.abs(dx)>Math.abs(dy)){
          moved=true;
          e.preventDefault();
          const x=Math.max(-92,Math.min(0,dx));
          main.style.transform='translateX('+x+'px)';
        }
      },{passive:false});
      main.addEventListener('touchend',e=>{
        if(!moved)return;
        const t=e.changedTouches&&e.changedTouches[0];
        const dx=(t?t.clientX:sx)-sx;
        main.style.transition='transform .18s ease';
        if(dx<-45){
          list.querySelectorAll('.pf-detail-row.open').forEach(r=>{
            if(r!==row){
              r.classList.remove('open');
              const m=r.querySelector('.pf-detail-main');
              if(m)m.style.transform='translateX(0)';
            }
          });
          row.classList.add('open');
          main.style.transform='translateX(-92px)';
        }else{
          closeRow();
        }
        moved=false;
      },{passive:true});
    });
  }
  const obsTarget=document.getElementById('pfTransactionsList');
  if(obsTarget){new MutationObserver(()=>enhanceSwipeRows(obsTarget)).observe(obsTarget,{childList:true,subtree:true});enhanceSwipeRows(obsTarget);}
  const origRender=window.pfTxRender;
  if(typeof origRender==='function'&&!window.__mfV7RenderWrapped){window.__mfV7RenderWrapped=true;window.pfTxRender=function(){const r=origRender.apply(this,arguments);requestAnimationFrame(()=>enhanceSwipeRows());return r;};}

  /* 2) Category -> exact transaction history, including user-created Custom categories. */
  let catFilter=null;
  function renderFilteredCategoryHistory(){
    if(!catFilter)return false;
    const list=document.getElementById('pfTransactionsList'),sum=document.getElementById('pfTransactionsSummary');if(!list||!sum)return false;
    let data=txsNow().filter(t=>norm(t.category)===norm(catFilter.category)&&(!catFilter.type||String(t.type||'')===catFilter.type));
    if(catFilter.from)data=data.filter(t=>String(t.date||'')>=catFilter.from&&String(t.date||'')<=catFilter.to);
    data=data.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
    let inc=0,exp=0;data.forEach(t=>String(t.type)==='CREDIT'?inc+=Number(t.amount)||0:exp+=Number(t.amount)||0);
    sum.textContent='Category: '+catFilter.category+' • '+data.length+' transaction(s) • Credit '+money2(inc)+' • Expense '+money2(exp)+' • Balance '+money2(inc-exp);
    list.innerHTML='';
    if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this category.</div>';return true;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));row.setAttribute('data-tx-id',String(t.id||''));
      const credit=String(t.type)==='CREDIT',sign=credit?'+':'-',desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',mode=t.mode||t.paymentMode||t.payment_mode||'Not specified',other=t.other||t.otherInfo||t.other_info||'';
      row.innerHTML='<div class="pf-detail-main"><div class="pf-swipe-icon '+(credit?'income':'expense')+'">'+(credit?'↓':'↑')+'</div><div class="pf-detail-summary"><div class="pf-detail-title">'+esc(t.category||'Uncategorized')+'</div><div class="pf-detail-meta">'+esc(t.date||'')+' • '+esc(mode)+'</div><div class="pf-detail-secondary">'+(desc?esc(desc):'No description')+(remark?' • Remark: '+esc(remark):'')+'</div></div><div class="pf-swipe-amount '+(credit?'income':'expense')+'">'+sign+money2(t.amount)+'</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-field"><span>Date</span><b>'+esc(t.date||'—')+'</b></div><div class="pf-detail-field"><span>Type</span><b>'+typeLabel(t.type)+'</b></div><div class="pf-detail-field"><span>Amount</span><b class="'+(credit?'income':'expense')+'">'+sign+money2(t.amount)+'</b></div><div class="pf-detail-field"><span>Category</span><b>'+esc(t.category||'Uncategorized')+'</b></div><div class="pf-detail-field"><span>Payment Mode</span><b>'+esc(mode)+'</b></div><div class="pf-detail-field"><span>Description</span><b>'+esc(desc||'—')+'</b></div><div class="pf-detail-field"><span>Remark</span><b>'+esc(remark||'—')+'</b></div><div class="pf-detail-field"><span>Other</span><b>'+esc(other||'—')+'</b></div><div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>';
      const main=row.querySelector('.pf-detail-main'),panel=row.querySelector('.pf-detail-panel'),exp=row.querySelector('.pf-expand-btn'),edit=row.querySelector('.pf-swipe-edit');
      exp.addEventListener('click',()=>{const o=row.classList.toggle('expanded');panel.style.display=o?'block':'none';exp.textContent=o?'⌃':'⌄';exp.setAttribute('aria-expanded',o?'true':'false');});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      list.appendChild(row);
    });
    requestAnimationFrame(()=>enhanceSwipeRows(list));
    return true;
  }
  function openCatHistory(category,type,from,to){
    catFilter={category:String(category||''),type:type||'',from:from||'',to:to||''};
    document.querySelectorAll('.pf-feature-modal.open').forEach(m=>m.classList.remove('open'));
    const page=document.getElementById('pfTransactionsPage');if(page){document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(x=>x.style.display='none');page.style.display='block';}
    if(typeof window.pfSetNav==='function')window.pfSetNav(document.querySelector('.pf-bottom-nav button:nth-child(2)'));
    renderFilteredCategoryHistory();window.scrollTo({top:0,behavior:'smooth'});
  }
  function categoryRange(){
    const period=document.querySelector('[data-cat-period].active')?.getAttribute('data-cat-period')||'all';
    const st=pfState(),ym=st.month||nowDate().slice(0,7),b=monthBounds2(ym);
    if(period==='month')return b;
    if(period==='year'){const y=ym.slice(0,4);return {from:y+'-01-01',to:y+'-12-31'};}
    if(period==='custom'){let f=document.getElementById('pfCatFrom')?.value||b.from,t=document.getElementById('pfCatTo')?.value||b.to;if(f>t){const x=f;f=t;t=x;}return {from:f,to:t};}
    return {from:'0000-01-01',to:'9999-12-31'};
  }
  const oldCatOpen=window.pfOpenCategory;
  window.pfOpenCategory=function(){catFilter=null;if(typeof oldCatOpen==='function')oldCatOpen();setTimeout(()=>bindCategoryRows(),0);};
  function bindCategoryRows(){const list=document.getElementById('pfCategoryList');if(!list||list.dataset.v7bound==='1')return;list.dataset.v7bound='1';list.addEventListener('click',e=>{const row=e.target.closest('.pf-category-row');if(!row)return;const name=row.querySelector('.pf-category-name')?.textContent?.trim();if(!name)return;const type=document.getElementById('pfCatIncome')?.classList.contains('active')?'CREDIT':'EXPENSE';const r=categoryRange();openCatHistory(name,type,r.from==='0000-01-01'?'':r.from,r.to==='9999-12-31'?'':r.to);});}
  setTimeout(bindCategoryRows,200);

  /* Clear category drill-down whenever the normal period controls are used. */
  ['pfTxSetView','pfTxShiftMonth','pfTxShiftWeek','pfTxSetMonth'].forEach(name=>{
    const fn=window[name];if(typeof fn!=='function'||fn.__v7wrap)return;
    const w=function(){catFilter=null;return fn.apply(this,arguments)};w.__v7wrap=true;window[name]=w;
  });
  const oldTxRender=window.pfRenderTransactionsPage;
  if(typeof oldTxRender==='function'&&!window.__mfV7CatRenderWrapped){window.__mfV7CatRenderWrapped=true;window.pfRenderTransactionsPage=function(){if(catFilter){renderFilteredCategoryHistory();return;}return oldTxRender.apply(this,arguments);};}

  /* 3) Search: instant, case-insensitive, exact data-field index + clickable result. */
  function searchText(t){return [t.date,t.type,typeLabel(t.type),t.amount,t.category,t.description,t.desc,t.remark,t.remarks,t.note,t.mode,t.paymentMode,t.payment_mode,t.other,t.otherInfo,t.other_info].map(norm).join(' ');}
  function renderSearchFixed(q){
    const list=document.getElementById('pfSearchResults');if(!list)return;const query=norm(q),data=txsNow().filter(t=>!query||searchText(t).includes(query));
    if(!data.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}
    list.innerHTML=data.slice(0,200).map(t=>{const credit=String(t.type)==='CREDIT';return '<button type="button" class="pf-search-result" data-search-id="'+esc(String(t.id||''))+'"><div><b>'+esc(t.category||'Uncategorized')+'</b><small>'+esc([t.date||'',typeLabel(t.type),t.mode||t.paymentMode||'',t.description||t.desc||'',t.remark||t.remarks||t.note||'',t.other||''].filter(Boolean).join(' • '))+'</small></div><strong style="color:'+(credit?'#2fa65b':'#e3483d')+'">'+(credit?'+':'-')+money2(t.amount)+'</strong></button>';}).join('');
  }
  window.pfOpenSearch=function(){openFeatureFixed('pfSearchModal');const i=document.getElementById('pfSearchInput');if(i){i.value='';i.oninput=()=>renderSearchFixed(i.value);requestAnimationFrame(()=>i.focus());}renderSearchFixed('');};
  document.addEventListener('click',e=>{const b=e.target.closest?.('[data-search-id]');if(!b)return;const t=txsNow().find(x=>String(x.id)===String(b.getAttribute('data-search-id')));if(t)openCatHistory(t.category||'Uncategorized',t.type||'',t.date||'',t.date||'');});

  /* 4) Analytics V15: expense donut + totals + daily/monthly comparisons + drill-down. */
  let analyticsType='EXPENSE';
  function monthTotals(ym){const b=monthBounds2(ym),a=txsNow().filter(t=>String(t.date||'')>=b.from&&String(t.date||'')<=b.to);let c=0,e=0;a.forEach(t=>String(t.type)==='CREDIT'?c+=Number(t.amount)||0:e+=Number(t.amount)||0);return {credit:c,expense:e};}
  function catTotals(data,type){const o=Object.create(null);data.filter(t=>String(t.type)===type).forEach(t=>{const c=t.category||'Uncategorized';o[c]=(o[c]||0)+(Number(t.amount)||0);});return Object.entries(o).sort((a,b)=>b[1]-a[1]);}
  function analyticsRangeData(){return txsNow();}
  function pfAnalyticsIcon(category){const s=String(category||'').toLowerCase();if(/food|dining|grocery/.test(s))return '🍽️';if(/transport|travel|fuel|petrol/.test(s))return '🚗';if(/shop|shopping/.test(s))return '🛒';if(/bill|utility|recharge|electric/.test(s))return '🧾';if(/health|medical|medicine/.test(s))return '❤';if(/education|school|course/.test(s))return '🎓';if(/home|salary|income|money/.test(s))return '⌂';return '•••';}
  function pfAnalyticsEsc(s){return esc(String(s==null?'':s));}
  function pfAnalyticsPct(v,total){return total>0?(Number(v)/Number(total)*100).toFixed(1):'0.0';}
  function renderAnalyticsFixed(){
    const modal=document.getElementById('pfAnalyticsModal'),host=document.getElementById('pfAnalyticsBody');if(!modal||!host)return;
    const today=nowDate(),yesterday=addDays(today,-1),all=txsNow();
    const num=v=>Number(v)||0;
    function daySum(ds){let c=0,e=0;all.forEach(t=>{if(String(t.date||'')===ds){if(String(t.type)==='CREDIT')c+=num(t.amount);else e+=num(t.amount);}});return {credit:c,expense:e,net:c-e};}
    const td=daySum(today),yd=daySum(yesterday),cp=diffPct(td.credit,yd.credit),ep=diffPct(td.expense,yd.expense),np=diffPct(td.net,yd.net);
    const creditTotal=all.filter(t=>String(t.type)==='CREDIT').reduce((s,t)=>s+num(t.amount),0);
    const expenseTotal=all.filter(t=>String(t.type)!=='CREDIT').reduce((s,t)=>s+num(t.amount),0);
    const ex=catTotals(all,'EXPENSE'),cr=catTotals(all,'CREDIT');
    const maxEx=ex[0]||null,maxCr=cr[0]||null;
    const highestSingle=all.filter(t=>String(t.type)==='EXPENSE').slice().sort((a,b)=>num(b.amount)-num(a.amount))[0]||null;
    const st=pfState(),anchor=st.month||today.slice(0,7),months=[];let [yy,mm]=anchor.split('-').map(Number);for(let i=5;i>=0;i--){const d=new Date(yy,mm-1-i,1);months.push(d.getFullYear()+'-'+pad(d.getMonth()+1));}
    const mt=months.map(m=>({m,...monthTotals(m)})),maxMonth=Math.max(1,...mt.flatMap(x=>[x.credit,x.expense]));
    const top=[...ex.map(x=>({type:'EXPENSE',name:x[0],value:x[1]})),...cr.map(x=>({type:'CREDIT',name:x[0],value:x[1]}))].sort((a,b)=>b.value-a.value).slice(0,8);
    const topMax=Math.max(1,...top.map(x=>x.value));
    const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];
    let start=0;const stops=ex.map((x,i)=>{const end=start+(x[1]/Math.max(1,expenseTotal))*100,z=palette[i%palette.length]+' '+start+'% '+end+'%';start=end;return z;});
    const dayCard=(label,val,prev,pct)=>'<div class="mf15-day-card"><div class="mf15-day-label">'+label+'</div><div class="mf15-day-value">'+money2(val)+'</div><div class="mf15-day-sub">Yesterday: '+money2(prev)+' · <span class="mf15-change '+(pct>0?'up':pct<0?'down':'flat')+'">'+(pct>0?'↑ ':pct<0?'↓ ':'→ ')+Math.abs(Number(pct)||0).toFixed(1)+'%</span></div></div>';
    const legend=ex.length?ex.map(([c,v],i)=>'<div class="mf15-legend-row"><i class="mf15-dot" style="background:'+palette[i%palette.length]+'"></i><span class="mf15-cat-icon">'+pfAnalyticsIcon(c)+'</span><b>'+pfAnalyticsEsc(c)+'</b><span class="mf15-amount">'+money2(v)+'</span><span class="mf15-pct" style="color:'+palette[i%palette.length]+'">'+pfAnalyticsPct(v,expenseTotal)+'%</span></div>').join(''):'<div class="mf15-sub">No expense categories yet.</div>';
    const monthRows=mt.map(x=>'<div class="mf15-month"><span>'+pfAnalyticsEsc(x.m.slice(5))+'/'+pfAnalyticsEsc(x.m.slice(0,4).slice(2))+'</span><div class="mf15-lanes"><div class="mf15-lane"><i class="credit" style="width:'+((x.credit/maxMonth)*100).toFixed(1)+'%"></i></div><div class="mf15-lane"><i class="expense" style="width:'+((x.expense/maxMonth)*100).toFixed(1)+'%"></i></div></div><div class="mf15-values"><span class="credit">'+money2(x.credit)+'</span><span class="expense">'+money2(x.expense)+'</span></div></div>').join('');
    const exPct=maxEx?pfAnalyticsPct(maxEx[1],expenseTotal):'0.0';
    host.innerHTML='<div class="mf15-card"><div class="mf15-donut-row"><div class="mf15-donut" style="background:'+(stops.length?'conic-gradient('+stops.join(',')+')':'conic-gradient(#e8e3d9 0 100%)')+'"><div class="mf15-donut-center"><b>'+money2(expenseTotal)+'</b><span>Total Expense</span></div></div><div><div class="mf15-section-title">Expense by Category</div><div class="mf15-legend">'+legend+'</div></div></div></div>'+
      '<div class="mf15-total-grid"><div class="mf15-card mf15-total"><div class="mf15-total-icon">↑</div><div><div class="mf15-total-label">Total Credit</div><div class="mf15-total-value">'+money2(creditTotal)+'</div><div class="mf15-total-caption">All time income</div></div></div><div class="mf15-card mf15-total expense"><div class="mf15-total-icon">↓</div><div><div class="mf15-total-label">Total Expense</div><div class="mf15-total-value">'+money2(expenseTotal)+'</div><div class="mf15-total-caption">All time expense</div></div></div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Today vs Yesterday</div><div class="mf15-sub">'+today+' compared with '+yesterday+'</div><div class="mf15-day-grid">'+dayCard('Credit Today',td.credit,yd.credit,cp)+dayCard('Expense Today',td.expense,yd.expense,ep)+'</div><div class="mf15-net"><span>Today Net</span><span>'+money2(td.net)+'</span></div><div class="mf15-sub" style="margin-top:5px">Yesterday Net '+money2(yd.net)+' · <span class="mf15-change '+(np>0?'up':np<0?'down':'flat')+'">'+(np>0?'↑ ':np<0?'↓ ':'→ ')+Math.abs(Number(np)||0).toFixed(1)+'%</span></div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Monthly Comparison</div><div class="mf15-sub">Six-month trend ending '+anchor+'</div><div class="mf15-month-legend"><span class="mf15-legend-key"><i class="mf15-key-dot" style="background:#2fa65b"></i>Credit (Income)</span><span class="mf15-legend-key"><i class="mf15-key-dot" style="background:#e3483d"></i>Expense</span></div>'+monthRows+'<div class="mf15-sub" style="margin-top:9px">Each month has a separate green Credit lane and red Expense lane.</div></div>'+
      '<div class="mf15-highlights"><div class="mf15-card mf15-highlight" data-analytics-cat="expense">'+
        '<div class="mf15-section-title">Maximum Expense Category</div>'+(maxEx?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(maxEx[0])+'</div><div class="mf15-highlight-value">'+money2(maxEx[1])+'</div><div class="mf15-highlight-sub">'+exPct+'% of total expense</div>':'<div class="mf15-highlight-sub">No expense data</div>')+'</div>'+
        '<div class="mf15-card mf15-highlight" data-analytics-cat="credit"><div class="mf15-section-title">Maximum Credit Category</div>'+(maxCr?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(maxCr[0])+'</div><div class="mf15-highlight-value">'+money2(maxCr[1])+'</div><div class="mf15-highlight-sub">Highest income category</div>':'<div class="mf15-highlight-sub">No credit data</div>')+'</div>'+
        '<div class="mf15-card mf15-highlight" data-analytics-single="1"><div class="mf15-section-title">Highest Single Expense</div>'+(highestSingle?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(highestSingle.category||'Uncategorized')+'</div><div class="mf15-highlight-value">'+money2(highestSingle.amount)+'</div><div class="mf15-highlight-sub">on '+pfAnalyticsEsc(highestSingle.date||'')+'</div>':'<div class="mf15-highlight-sub">No expense data</div>')+'</div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Category Ranking</div>'+(top.length?top.map((x,i)=>'<div class="mf15-rank"><span class="mf15-rank-no">'+(i+1)+'</span><span class="mf15-rank-name">'+(x.type==='CREDIT'?'Cr ':'Exp ')+pfAnalyticsEsc(x.name)+'</span><div class="mf15-rank-track"><i style="width:'+((x.value/topMax)*100).toFixed(1)+'%;background:'+(x.type==='CREDIT'?'#2fa65b':'#e3483d')+'"></i></div><span class="mf15-rank-amt">'+money2(x.value)+'</span></div>').join(''):'<div class="mf15-sub">No category data yet.</div>')+'</div>'+
      '<button type="button" class="mf15-export" onclick="pfExportAnalyticsImage()">▣ Export Image · Save PNG</button>'+
      '<div class="mf15-tip">This chart shows category-wise distribution of your total expenses. Track your spending to manage your money better.</div>';
  }
  function pfShowAnalyticsSingleExpense(t){
    if(!t)return;
    let m=document.getElementById('pfAnalyticsDetailModal');
    if(!m){m=document.createElement('div');m.id='pfAnalyticsDetailModal';m.className='pf-feature-modal';m.setAttribute('aria-hidden','true');m.innerHTML='<div class="pf-feature-sheet"><div class="pf-feature-head"><div><span class="pf-feature-kicker">EXPENSE DETAILS</span><h2>Highest Single Expense</h2></div><button class="pf-feature-close" onclick="pfCloseFeature(\'pfAnalyticsDetailModal\')">✕</button></div><div id="pfAnalyticsDetailBody"></div></div>';document.body.appendChild(m);}
    const body=document.getElementById('pfAnalyticsDetailBody'),mode=t.mode||t.paymentMode||t.payment_mode||'Not specified',desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',other=t.other||t.otherInfo||t.other_info||'';
    body.innerHTML='<div class="mf15-card"><div class="mf15-section-title">'+pfAnalyticsEsc(t.category||'Uncategorized')+'</div><div class="mf-a-big" style="margin-top:8px;color:#e3483d">-'+money2(t.amount)+'</div><div class="mf15-sub" style="margin-top:7px">Date: '+pfAnalyticsEsc(t.date||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Payment Mode: '+pfAnalyticsEsc(mode)+'</div><div class="mf15-sub" style="margin-top:5px">Description: '+pfAnalyticsEsc(desc||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Remark: '+pfAnalyticsEsc(remark||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Other: '+pfAnalyticsEsc(other||'—')+'</div></div>';
    openFeatureFixed('pfAnalyticsDetailModal');
  }
  function pfExportAnalyticsImage(){
    try{
      const data=txsNow(), expense=data.filter(t=>String(t.type)!=='CREDIT'), credit=data.filter(t=>String(t.type)==='CREDIT');
      const totalE=expense.reduce((s,t)=>s+(Number(t.amount)||0),0),totalC=credit.reduce((s,t)=>s+(Number(t.amount)||0),0),cats=catTotals(data,'EXPENSE').slice(0,8),today=nowDate();
      const W=1200,H=1500,cv=document.createElement('canvas');cv.width=W;cv.height=H;const c=cv.getContext('2d');
      function rr(x,y,w,h,r,fill,stroke){c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.stroke()}}
      c.fillStyle='#faf8f2';c.fillRect(0,0,W,H);c.fillStyle='#51463a';c.font='700 46px Arial';c.fillText('Money Flow — Analytics',60,70);c.font='22px Arial';c.fillStyle='#8b8378';c.fillText(today,60,105);
      const cx=300,cy=300,r=175,ir=105;let a=-Math.PI/2;const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];
      if(totalE){cats.forEach((x,i)=>{const da=x[1]/totalE*Math.PI*2;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r,a,a+da);c.closePath();c.fillStyle=pal[i%pal.length];c.fill();a+=da;});}else{c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.fillStyle='#e8e3d9';c.fill();}
      c.beginPath();c.arc(cx,cy,ir,0,Math.PI*2);c.fillStyle='#faf8f2';c.fill();c.fillStyle='#51463a';c.textAlign='center';c.font='700 34px Arial';c.fillText('₹'+totalE.toLocaleString('en-IN',{minimumFractionDigits:2}),cx,cy-4);c.font='20px Arial';c.fillStyle='#8b8378';c.fillText('Total Expense',cx,cy+28);c.textAlign='left';
      c.font='700 26px Arial';c.fillStyle='#51463a';c.fillText('Expense by Category',570,165);cats.forEach((x,i)=>{const y=215+i*45;c.fillStyle=pal[i%pal.length];c.beginPath();c.arc(590,y-7,8,0,Math.PI*2);c.fill();c.fillStyle='#51463a';c.font='21px Arial';c.fillText(x[0],615,y);c.textAlign='right';c.font='700 20px Arial';c.fillText('₹'+x[1].toLocaleString('en-IN',{minimumFractionDigits:2}),1110,y);c.textAlign='left';});
      function box(x,y,w,title,val,sub){rr(x,y,w,110,18,'#fffdf9','#ded8cc');c.fillStyle='#51463a';c.font='700 20px Arial';c.fillText(title,x+22,y+32);c.font='700 30px Arial';c.fillText('₹'+val.toLocaleString('en-IN',{minimumFractionDigits:2}),x+22,y+70);c.fillStyle='#8b8378';c.font='17px Arial';c.fillText(sub,x+22,y+95);}
      box(60,540,520,'Total Credit',totalC,'All time income');box(620,540,520,'Total Expense',totalE,'All time expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Today vs Yesterday',60,720);c.font='18px Arial';c.fillStyle='#8b8378';c.fillText(today+' comparison',60,750);
      const d=(()=>{let cc=0,ee=0;data.forEach(t=>{if(t.date===today){if(t.type==='CREDIT')cc+=Number(t.amount)||0;else ee+=Number(t.amount)||0;}});return {cc,ee,net:cc-ee};})();box(60,780,330,'Credit Today',d.cc,'Income today');box(435,780,330,'Expense Today',d.ee,'Expense today');box(810,780,330,'Today Net',d.net,'Credit − Expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Category Ranking',60,970);const ranking=[...catTotals(data,'CREDIT').map(x=>['Cr',x[0],x[1]]),...cats.map(x=>['Exp',x[0],x[1]])].sort((a,b)=>b[2]-a[2]).slice(0,7);const rm=Math.max(1,...ranking.map(x=>x[2]));ranking.forEach((x,i)=>{const y=1015+i*58;c.fillStyle='#51463a';c.font='18px Arial';c.fillText((i+1)+'. '+x[0]+' '+x[1],60,y);c.fillStyle=x[0]==='Cr'?'#2fa65b':'#e3483d';rr(430,y-16,570*(x[2]/rm),18,9,x[0]==='Cr'?'#2fa65b':'#e3483d');c.fillStyle='#51463a';c.textAlign='right';c.font='700 18px Arial';c.fillText('₹'+x[2].toLocaleString('en-IN',{minimumFractionDigits:2}),1110,y);c.textAlign='left';});
      c.fillStyle='#8b8378';c.font='17px Arial';c.fillText('Generated from Money Flow transaction analytics',60,H-45);
      const b64=cv.toDataURL('image/png').split(',')[1],name='money_flow_analytics_'+today+'_'+Date.now()+'.png';
      if(window.AndroidFile&&typeof AndroidFile.saveFile==='function'){AndroidFile.saveFile(name,'image/png',b64);return true;}
      const aEl=document.createElement('a');aEl.href='data:image/png;base64,'+b64;aEl.download=name;document.body.appendChild(aEl);aEl.click();aEl.remove();return true;
    }catch(e){try{alert('Export Image failed: '+(e&&e.message?e.message:'Unknown error'))}catch(_){}return false}
  }
  document.addEventListener('click',e=>{const h=e.target.closest?.('[data-analytics-single]');if(h){const t=txsNow().filter(t=>String(t.type)==='EXPENSE').sort((a,b)=>(Number(b.amount)||0)-(Number(a.amount)||0))[0];pfShowAnalyticsSingleExpense(t);return;}const c=e.target.closest?.('[data-analytics-cat]');if(c){const type=c.getAttribute('data-analytics-cat');const arr=type==='expense'?catTotals(txsNow(),'EXPENSE'):catTotals(txsNow(),'CREDIT');if(arr[0])openCatHistory(arr[0][0],type==='expense'?'EXPENSE':'CREDIT','','');}});
  window.pfOpenAnalytics=function(){openFeatureFixed('pfAnalyticsModal');renderAnalyticsFixed();};
  window.pfAnalyticsSetType=function(){renderAnalyticsFixed();};
  window.__mfV7AnalyticsRender=renderAnalyticsFixed;
  function openFeatureFixed(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  window.pfOpenAnalytics=function(){openFeatureFixed('pfAnalyticsModal');renderAnalyticsFixed();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense')?.classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome')?.classList.toggle('active',type==='CREDIT');renderAnalyticsFixed();};
  window.__mfV7AnalyticsRender=renderAnalyticsFixed;

  /* 5) Type/category safety remains enforced, plus clear category when type changes. */
  const et=document.getElementById('editType');
  if(et&&!et.__mfV7Type){et.__mfV7Type=true;et.addEventListener('change',()=>{const sel=document.getElementById('editCategory');const custom=document.getElementById('editCustomCategory');if(sel){sel.value='';}if(custom){custom.value='';custom.style.display='none';}const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='Transaction type changed. Please select a category for the new type.';}});}

  /* Final nav override: Transactions always opens Daily with today's date. */
  const prevNavV7=window.pfNav;
  window.pfNav=function(name,btn){if(name==='transactions'){catFilter=null;const st=pfState();const td=nowDate();st.view='daily';st.month=td.slice(0,7);st.weekAnchor=td;const dp=document.getElementById('pfTxDayPicker');if(dp){dp.value=td;const b=monthBounds2(st.month);dp.min=b.from;dp.max=b.to;}document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view==='daily'));const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');if(d)d.style.display='flex';if(w)w.style.display='none';if(c)c.style.display='none';}return typeof prevNavV7==='function'?prevNavV7.apply(this,arguments):undefined;};

  function boot(){enhanceSwipeRows();bindCategoryRows();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(boot,250);setTimeout(boot,800);
})();

  window.pfOpenNotes=function(){
    if(typeof openFeature==='function') openFeature('pfNotesModal');
    else if(typeof pfOpenFeature==='function') pfOpenFeature('pfNotesModal');
    if(typeof window.pfSetNav==='function') window.pfSetNav(document.getElementById('notesNavBtn'));
  };
  window.pfOpenCalculator=function(){
    if(typeof openFeature==='function') openFeature('pfCalculatorModal');
    else if(typeof pfOpenFeature==='function') pfOpenFeature('pfCalculatorModal');
  };



(function(){
  'use strict';
  function bindSwipeEdit(root){
    const list=root||document.getElementById('pfTransactionsList');
    if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(function(row){
      const main=row.querySelector('.pf-detail-main');
      if(!main)return;
      let btn=row.querySelector('.pf-swipe-reveal');
      if(!btn){
        btn=document.createElement('button');
        btn.type='button';
        btn.className='pf-swipe-reveal';
        btn.textContent='Edit';
        btn.setAttribute('aria-label','Edit transaction');
        row.insertBefore(btn,main);
      }
      if(btn.dataset.finalSwipeEdit==='1')return;
      btn.dataset.finalSwipeEdit='1';
      function doEdit(e){
        if(e){e.preventDefault();e.stopPropagation();}
        const id=row.getAttribute('data-tx-id');
        row.classList.remove('open');
        main.style.transition='transform .15s ease';
        main.style.transform='translateX(0)';
        if(id!==null && id!=='' && typeof window.v10RequestEdit==='function'){
          setTimeout(function(){window.v10RequestEdit(id);},0);
        }
      }
      btn.addEventListener('click',doEdit,false);
      btn.addEventListener('touchend',doEdit,{passive:false});

      const exp=row.querySelector('.pf-expand-btn');
      if(exp && !exp.dataset.finalSwipeExpand){
        exp.dataset.finalSwipeExpand='1';
        exp.addEventListener('click',function(){
          /* Expanding must always close any active swipe-reveal state first. */
          row.classList.remove('open');
          main.style.transition='transform .15s ease';
          main.style.transform='translateX(0)';
        },true);
      }
    });
  }
  const list=document.getElementById('pfTransactionsList');
  if(list){
    new MutationObserver(function(){bindSwipeEdit(list);}).observe(list,{childList:true,subtree:true});
    bindSwipeEdit(list);
  }
  const oldRender=window.pfTxRender;
  if(typeof oldRender==='function' && !window.__mfFinalSwipeRender){
    window.__mfFinalSwipeRender=true;
    window.pfTxRender=function(){
      const r=oldRender.apply(this,arguments);
      requestAnimationFrame(function(){bindSwipeEdit();});
      return r;
    };
  }
})();



(function(){
  'use strict';
  function resolveOriginalId(raw){
    if(raw===null||raw===undefined||raw==='') return raw;
    const list=(typeof txs!=='undefined'&&Array.isArray(txs))?txs:[];
    const hit=list.find(function(t){ return String(t && t.id)===String(raw); });
    return hit ? hit.id : raw;
  }

  /* Keep the already-working Edit/PIN/security path untouched; only normalize
     IDs arriving from swipe DOM elements before forwarding to it. */
  function normalizeSwipeEditButton(btn,row){
    if(!btn||btn.dataset.swipeIdFix==='1') return;
    btn.dataset.swipeIdFix='1';
    let lastTouch=0;
    function forward(e){
      if(e){e.preventDefault();e.stopPropagation();}
      const now=Date.now();
      /* Android WebView can emit touchend followed by a synthetic click. */
      if(e && e.type==='click' && now-lastTouch<700) return;
      if(e && e.type==='touchend') lastTouch=now;
      const raw=row && row.getAttribute ? row.getAttribute('data-tx-id') : null;
      const id=resolveOriginalId(raw);
      if(id!==null&&id!==''&&typeof window.v10RequestEdit==='function'){
        window.v10RequestEdit(id);
      }
    }
    btn.addEventListener('click',forward,true);
    btn.addEventListener('touchend',forward,{capture:true,passive:false});
  }

  function patchRows(root){
    const list=root||document.getElementById('pfTransactionsList');
    if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(function(row){
      const btn=row.querySelector('.pf-swipe-reveal');
      if(btn) normalizeSwipeEditButton(btn,row);
    });
  }

  const list=document.getElementById('pfTransactionsList');
  if(list){
    new MutationObserver(function(){patchRows(list);}).observe(list,{childList:true,subtree:true});
    patchRows(list);
  }
})();



(function(){
  'use strict';
  const STORE='moneyflow_notes_v1';
  const CATS=['Shopping','Wish List','Personal','Work'];
  const TEMPLATES=[
    {name:'Shopping List',cat:'Shopping',type:'Checklist',icon:'🛒',items:['Groceries','Notebook','Shoes','Water Bottle','Backpack'],text:'',estimate:3500},
    {name:'To Do List',cat:'Personal',type:'Checklist',icon:'✓',items:['Task 1','Task 2','Task 3'],text:'',estimate:0},
    {name:'Wish List',cat:'Wish List',type:'Checklist',icon:'♥',items:['Item 1','Item 2'],text:'',estimate:0},
    {name:'Do Not Buy List',cat:'Shopping',type:'Checklist',icon:'−',items:['Item to avoid'],text:'',estimate:0},
    {name:'Travel Checklist',cat:'Personal',type:'Checklist',icon:'✈',items:['Tickets','ID','Hotel','Packing'],text:'',estimate:0},
    {name:'Project Ideas',cat:'Work',type:'Text Note',icon:'💡',items:[],text:'Write your project idea here.',estimate:0},
    {name:'Personal Notes',cat:'Personal',type:'Both',icon:'▤',items:['Important item'],text:'Add your personal note here.',estimate:0}
  ];
  let notes=[];
  let view='list', editId=null, filter='All', search='', draftType='Checklist';
  function uid(){return 'n_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8)}
  function load(){try{notes=JSON.parse(localStorage.getItem(STORE)||'[]')}catch(e){notes=[]}if(!Array.isArray(notes))notes=[];if(!notes.length){notes=[seed()];save()}}
  function seed(){return {id:uid(),title:'Shopping List',category:'Shopping',type:'Checklist',items:[{id:uid(),text:'Groceries',done:true},{id:uid(),text:'Notebook',done:false},{id:uid(),text:'Shoes',done:false},{id:uid(),text:'Water Bottle',done:true},{id:uid(),text:'Backpack',done:false}],text:'Buy only if needed. Compare prices online.',estimate:3500,pinned:true,created:Date.now(),updated:Date.now()}}
  function save(){localStorage.setItem(STORE,JSON.stringify(notes))}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function fmtDate(ts){return new Date(ts||Date.now()).toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'})}
  function icon(cat){return cat==='Shopping'?'🛒':cat==='Wish List'?'♥':cat==='Work'?'▣':'▤'}
  function get(id){return notes.find(n=>n.id===id)}
  function filtered(){let q=search.trim().toLowerCase();return notes.filter(n=>(filter==='All'||n.category===filter)&&(!q||[n.title,n.category,n.type,n.text,(n.items||[]).map(x=>x.text).join(' ')].join(' ').toLowerCase().includes(q))).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||((b.updated||0)-(a.updated||0)))}
  function ensureShell(){
    const m=document.getElementById('pfNotesModal');if(!m)return null;
    const sheet=m.querySelector('.pf-feature-sheet');if(!sheet)return null;
    if(sheet.dataset.mfn==='1')return sheet;
    sheet.dataset.mfn='1';
    sheet.innerHTML=`
      <div class="pf-feature-head"><div><span class="pf-feature-kicker">PERSONAL ORGANIZER</span><h2>Notes</h2></div><div class="mfn-head-actions"><button class="mfn-icon-btn" type="button" onclick="mfnToggleSearch()">⌕</button><button class="mfn-icon-btn" type="button" onclick="mfnShow('templates')">⋮</button><button class="pf-feature-close" type="button" onclick="pfCloseFeature('pfNotesModal')">✕</button></div></div>
      <div id="mfnRoot"></div>`;
    return sheet;
  }
  function show(){ensureShell();const m=document.getElementById('pfNotesModal');if(m){m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden'}render()}
  function render(){ensureShell();const root=document.getElementById('mfnRoot');if(!root)return;
    if(view==='list')renderList(root);else if(view==='create')renderCreate(root);else if(view==='detail')renderDetail(root);else if(view==='categories')renderCategories(root);else renderTemplates(root);
  }
  function renderList(root){
    const data=filtered();
    root.innerHTML=`<div class="mfn-filter-row">${['All'].concat(CATS).map(c=>`<button type="button" class="mfn-filter ${filter===c?'active':''}" onclick="mfnFilter(${JSON.stringify(c)})">${esc(c)}</button>`).join('')}</div>
      <div id="mfnSearchBox" style="display:${search?'block':'none'}"><input id="mfnSearchInput" class="mfn-search" value="${esc(search)}" placeholder="Search title, category, item or note..." oninput="mfnSearch(this.value)"></div>
      <div class="mfn-topbar"><h3>All Notes</h3><button type="button" class="mfn-back" onclick="mfnShow('categories')">Category-wise</button></div>
      <div class="mfn-list">${data.length?data.map(card).join(''):`<div class="mfn-empty">No notes found.<br>Create a note or change the filter.</div>`}</div>
      <button type="button" class="mfn-primary" onclick="mfnNew()">＋ New Note</button>
      <button type="button" class="mfn-secondary" onclick="mfnShow('templates')">▤ Note Templates</button>`;
    const inp=document.getElementById('mfnSearchInput');if(inp&&search){inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)}
  }
  function card(n){const count=(n.items||[]).length,done=(n.items||[]).filter(x=>x.done).length;const meta=(n.type==='Text Note'?'Text note':n.type)+(count?` • ${done}/${count} checked`:'')+` • ${fmtDate(n.updated||n.created)}`;const preview=n.text||((n.items||[]).map(x=>x.text).filter(Boolean).join(' • '));return `<div class="mfn-card" onclick="mfnOpen(${JSON.stringify(n.id)})"><div class="mfn-card-icon">${icon(n.category)}</div><div class="mfn-card-main"><div class="mfn-card-title">${esc(n.title||'Untitled')} ${n.pinned?'<span class="mfn-pin">📌</span>':''}</div><div class="mfn-card-meta">${esc(n.category)} • ${esc(meta)}</div>${preview?`<div class="mfn-card-preview">${esc(preview)}</div>`:''}</div><button type="button" class="mfn-more" onclick="event.stopPropagation();mfnCardMenu(${JSON.stringify(n.id)})">⋮</button></div>`}
  function renderCreate(root){const n=editId?get(editId):null;const d=n||{title:'',category:'Shopping',type:draftType,items:[],text:'',estimate:0};draftType=d.type||'Checklist';
    root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Back</button><h3>${n?'Edit Note':'Create Note'}</h3><button class="mfn-back" type="button" onclick="mfnSaveForm()">Save</button></div>
      <div class="mfn-form">
        <div class="mfn-field"><label>Title</label><input id="mfnTitle" value="${esc(d.title)}" placeholder="Note title"></div>
        <div class="mfn-field"><label>Category</label><select id="mfnCategory">${CATS.map(c=>`<option ${d.category===c?'selected':''}>${c}</option>`).join('')}</select></div>
        <div class="mfn-field"><label>Type</label><div class="mfn-type">${['Checklist','Text Note','Both'].map(t=>`<button type="button" class="${d.type===t?'active':''}" onclick="mfnSetType(${JSON.stringify(t)})">${t}</button>`).join('')}</div></div>
        <div id="mfnItemsWrap" class="mfn-field" style="display:${d.type==='Text Note'?'none':'grid'}"><label>Items</label><div id="mfnItems" class="mfn-items">${(d.items||[]).map(itemEditor).join('')}</div><button class="mfn-add-item" type="button" onclick="mfnAddItem()">＋ Add Item</button></div>
        <div id="mfnTextWrap" class="mfn-field" style="display:${d.type==='Checklist'?'none':'grid'}"><label>Notes</label><textarea id="mfnText" placeholder="Write your note...">${esc(d.text||'')}</textarea></div>
        <div class="mfn-field"><label>Estimated Total (optional)</label><input id="mfnEstimate" type="number" min="0" step="0.01" value="${Number(d.estimate||0)||''}" placeholder="0"></div>
      </div><button type="button" class="mfn-primary" onclick="mfnSaveForm()">✓ ${n?'Save Changes':'Create Note'}</button>`;
  }
  function itemEditor(it){return `<div class="mfn-item-editor" data-item-id="${esc(it.id)}"><span style="color:#9a9185;text-align:center">☷</span><input class="mfn-item-input" value="${esc(it.text)}" placeholder="Item"><button type="button" onclick="mfnRemoveItem(this)">×</button></div>`}
  function renderDetail(root){const n=get(editId);if(!n){view='list';render();return}const items=n.items||[];const done=items.filter(x=>x.done).length;
    root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><div style="display:flex;gap:4px"><button class="mfn-icon-btn" type="button" onclick="mfnEdit()">✎</button><button class="mfn-icon-btn mfn-danger" type="button" onclick="mfnDelete()">⌫</button><button class="mfn-icon-btn" type="button" onclick="mfnTogglePin()">${n.pinned?'📌':'☆'}</button></div></div>
      <h3 class="mfn-detail-title">${esc(n.title||'Untitled')}</h3><div class="mfn-detail-sub">${esc(n.category)} • ${esc(n.type)} • ${fmtDate(n.updated||n.created)}</div>
      ${items.length?`<div class="mfn-detail-section"><h4>Checklist <span style="font-weight:400;color:#8b8378">${done}/${items.length}</span></h4><div class="mfn-checklist">${items.map((it,i)=>`<label class="mfn-check-row ${it.done?'done':''}"><input type="checkbox" ${it.done?'checked':''} onchange="mfnToggleItem(${i},this.checked)"><span>${esc(it.text)}</span></label>`).join('')}</div><button class="mfn-add-item" style="margin-top:10px!important" type="button" onclick="mfnAddDetailItem()">＋ Add Item</button></div>`:''}
      ${n.estimate?`<div class="mfn-detail-section"><h4>Estimated Total</h4><div class="mfn-estimate"><strong>${money(n.estimate)}</strong><button type="button" class="mfn-secondary" style="width:auto;margin:0!important" onclick="pfOpenCalculator()">Open Calculator</button></div></div>`:''}
      ${n.text?`<div class="mfn-detail-section"><h4>Notes</h4><div class="mfn-text-note">${esc(n.text)}</div></div>`:''}
      ${!items.length&&!n.text&&!n.estimate?'<div class="mfn-empty">This note is empty. Tap Edit to add content.</div>':''}`;
  }
  function renderCategories(root){const counts=CATS.map(c=>({c,n:notes.filter(x=>x.category===c).length}));root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><h3>Category</h3></div><div class="mfn-cat-grid">${counts.map(x=>`<div class="mfn-cat-card" onclick="mfnFilter(${JSON.stringify(x.c)});mfnShow('list')"><b>${esc(x.c)}</b><span>${x.n} note${x.n===1?'':'s'}</span></div>`).join('')}</div><button type="button" class="mfn-secondary" onclick="mfnFilter('All');mfnShow('list')">View All Notes</button>`}
  function renderTemplates(root){root.innerHTML=`<div class="mfn-topbar"><button class="mfn-back" type="button" onclick="mfnShow('list')">‹ Notes</button><h3>Templates</h3></div><div class="mfn-template-list">${TEMPLATES.map((t,i)=>`<div class="mfn-template" onclick="mfnUseTemplate(${i})"><div class="mfn-template-icon">${t.icon}</div><div><b>${esc(t.name)}</b><small>${esc(t.type)} • ${esc(t.cat)}</small></div></div>`).join('')}</div>`}
  function money(v){return '₹'+Number(v||0).toLocaleString('en-IN',{maximumFractionDigits:2})}
  window.mfnShow=function(v){view=v;render()};
  window.mfnFilter=function(v){filter=v;render()};
  window.mfnSearch=function(v){search=v;render()};
  window.mfnToggleSearch=function(){view='list';const box=document.getElementById('mfnSearchBox');if(box){box.style.display='block';const x=document.getElementById('mfnSearchInput');if(x)x.focus();}else{render();setTimeout(function(){const y=document.getElementById('mfnSearchInput');if(y)y.focus()},0)}};
  window.mfnNew=function(){editId=null;draftType='Checklist';view='create';render()};
  window.mfnOpen=function(id){editId=id;view='detail';render()};
  window.mfnEdit=function(){view='create';render()};
  window.mfnSetType=function(t){draftType=t;document.querySelectorAll('.mfn-type button').forEach(function(b){b.classList.toggle('active',b.textContent.trim()===t)});const iw=document.getElementById('mfnItemsWrap'),tw=document.getElementById('mfnTextWrap');if(iw)iw.style.display=t==='Text Note'?'none':'grid';if(tw)tw.style.display=t==='Checklist'?'none':'grid';};
  window.mfnAddItem=function(){const wrap=document.getElementById('mfnItems');if(!wrap)return;const div=document.createElement('div');div.className='mfn-item-editor';div.dataset.itemId=uid();div.innerHTML='<span style="color:#9a9185;text-align:center">☷</span><input class="mfn-item-input" placeholder="Item"><button type="button" onclick="mfnRemoveItem(this)">×</button>';wrap.appendChild(div);div.querySelector('input').focus()};
  window.mfnRemoveItem=function(btn){const row=btn.closest('.mfn-item-editor');if(row)row.remove()};
  window.mfnSaveForm=function(){const title=(document.getElementById('mfnTitle')?.value||'').trim();if(!title){alert('Please enter a note title.');return}const category=document.getElementById('mfnCategory')?.value||'Personal';const type=draftType;const items=Array.from(document.querySelectorAll('#mfnItems .mfn-item-editor')).map(r=>({id:r.dataset.itemId||uid(),text:(r.querySelector('input')?.value||'').trim(),done:false})).filter(x=>x.text);const text=document.getElementById('mfnText')?.value||'';const estimate=Math.max(0,Number(document.getElementById('mfnEstimate')?.value||0));let n=editId?get(editId):null;if(n){n.title=title;n.category=category;n.type=type;n.items=items.map(x=>{const old=(n.items||[]).find(o=>o.id===x.id);return old?{...x,done:old.done}:x});n.text=text;n.estimate=estimate;n.updated=Date.now()}else{n={id:uid(),title,category,type,items,text,estimate,pinned:false,created:Date.now(),updated:Date.now()};notes.unshift(n);editId=n.id}save();view='detail';render()};
  window.mfnToggleItem=function(index,checked){const n=get(editId);if(!n)return;if(n.items&&n.items[index])n.items[index].done=!!checked;n.updated=Date.now();save();render()};
  window.mfnAddDetailItem=function(){const text=prompt('Item name');if(!text||!text.trim())return;const n=get(editId);if(!n)return;n.items=n.items||[];n.items.push({id:uid(),text:text.trim(),done:false});n.updated=Date.now();save();render()};
  window.mfnTogglePin=function(){const n=get(editId);if(!n)return;n.pinned=!n.pinned;n.updated=Date.now();save();render()};
  window.mfnDelete=function(){const n=get(editId);if(!n)return;if(!confirm('Delete this note?'))return;notes=notes.filter(x=>x.id!==editId);save();editId=null;view='list';render()};
  window.mfnCardMenu=function(id){const n=get(id);if(!n)return;const action=prompt('Type: pin, edit, or delete');if(!action)return;const a=action.toLowerCase();editId=id;if(a==='pin'){n.pinned=!n.pinned;n.updated=Date.now();save();render()}else if(a==='edit'){view='create';render()}else if(a==='delete'){mfnDelete()}};
  window.mfnUseTemplate=function(i){const t=TEMPLATES[i];if(!t)return;editId=null;draftType=t.type;const n={id:uid(),title:t.name,category:t.cat,type:t.type,items:(t.items||[]).map(x=>({id:uid(),text:x,done:false})),text:t.text||'',estimate:t.estimate||0,pinned:false,created:Date.now(),updated:Date.now()};notes.unshift(n);save();editId=n.id;view='detail';render()};
  window.pfOpenNotes=function(){load();filter='All';search='';view='list';show();if(typeof window.pfSetNav==='function')window.pfSetNav(document.getElementById('notesNavBtn'))};
  load();
})();



(function(){
  'use strict';
  function build(){
    if(document.getElementById('mfnMoreModal'))return;
    const d=document.createElement('div');d.id='mfnMoreModal';d.className='mfn-more-modal';d.setAttribute('aria-hidden','true');
    d.innerHTML='<div class="mfn-more-sheet"><div class="pf-feature-head"><div><span class="pf-feature-kicker">QUICK ACCESS</span><h2>More</h2></div><button class="pf-feature-close" type="button" onclick="mfnCloseMore()">✕</button></div><div class="mfn-more-profile" onclick="v10OpenProfiles()"><div class="mfn-more-avatar">👤</div><div><b>Profile</b><small>Manage your account</small></div><span style="margin-left:auto;color:#8b8378;font-size:20px">›</span></div><div class="mfn-more-menu"><button class="mfn-more-item" type="button" onclick="pfOpenCalculator();mfnCloseMore()"><span>▦</span>Calculator<small>›</small></button><button class="mfn-more-item" type="button" onclick="pfOpenNotes();mfnCloseMore()"><span>▤</span>Notes<small>›</small></button><button class="mfn-more-item" type="button" onclick="mfOpenBackup();mfnCloseMore()"><span>☁</span>Backup &amp; Sync<small>›</small></button><button class="mfn-more-item" type="button" onclick="openCustomization();mfnCloseMore()"><span>⚙</span>Settings<small>›</small></button><button class="mfn-more-item" type="button" onclick="mfnHelp()"><span>?</span>Help &amp; Feedback<small>›</small></button></div><div class="mfn-help" id="mfnHelpBox" style="display:none"><b>Money Flow Help</b><br>Notes are saved locally on this device. You can create, edit, pin, search, filter, complete checklist items, and use templates. Backup &amp; Sync remains available from this screen.</div></div>';
    d.addEventListener('click',function(e){if(e.target===d)mfnCloseMore()});document.body.appendChild(d);
  }
  window.mfnOpenMore=function(){build();const m=document.getElementById('mfnMoreModal');m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';if(typeof window.pfSetNav==='function')window.pfSetNav(document.getElementById('moreNavBtn'))};
  window.mfnCloseMore=function(){const m=document.getElementById('mfnMoreModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow=''};
  window.mfnHelp=function(){const b=document.getElementById('mfnHelpBox');if(b)b.style.display=b.style.display==='none'?'block':'none'};
  function wire(){const b=document.getElementById('moreNavBtn');if(b&&!b.__mfnMore){b.__mfnMore=true;b.onclick=function(e){if(e)e.preventDefault();mfnOpenMore()}}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wire);else wire();setTimeout(wire,300);setTimeout(wire,1000);
})();



(function(){
  'use strict';
  const PROFILE_KEY='money_manager_profiles_v10';
  const ACTIVE_KEY='money_manager_active_profile_v10';
  const FALLBACK='👤';
  const esc=function(s){return String(s==null?'':s).replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]})};
  function activeProfile(){
    try{
      const a=JSON.parse(localStorage.getItem(PROFILE_KEY)||'[]');
      const id=localStorage.getItem(ACTIVE_KEY);
      return Array.isArray(a)?(a.find(function(p){return p&&p.id===id})||a[0]||null):null;
    }catch(e){return null;}
  }
  function photo(p){
    const src=p&&typeof p.profilePhoto==='string'&&/^data:image\//i.test(p.profilePhoto)?p.profilePhoto:'';
    return src;
  }
  function closeEverythingBeforeOpen(){
    try{if(typeof window.mfnCloseMore==='function')window.mfnCloseMore();}catch(e){}
    try{if(typeof window.closeMenu==='function')window.closeMenu();}catch(e){}
  }
  function runAction(fn){
    return function(){
      closeEverythingBeforeOpen();
      setTimeout(function(){try{if(typeof fn==='function')fn();}catch(e){}},0);
    };
  }
  function legacyMarkup(){
    return ''+
      '<div class="mf-v10-more-profile" id="mfV10MoreProfile" role="button" tabindex="0" aria-label="Open Profile / Mode">'+
        '<div class="mf-v10-more-avatar" id="mfV10MoreAvatar">'+FALLBACK+'</div>'+
        '<div class="mf-v10-more-profile-main"><b id="mfV10MoreProfileName">Profile / Mode</b><small id="mfV10MoreProfileSub">Manage your account</small></div>'+
        '<span class="mf-v10-more-arrow">›</span>'+
      '</div>'+
      '<div class="mf-v10-legacy-menu">'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMorePin"><span class="mf-v10-icon">🔢</span><span class="mf-v10-label">PIN Setup / Change</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreAddPin"><span class="mf-v10-icon">➕</span><span class="mf-v10-label">Add Transaction PIN</span><span class="mf-v10-state" id="mfMoreAddPinState">OFF</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreBio"><span class="mf-v10-icon">🔐</span><span class="mf-v10-label">Fingerprint / Biometric</span><span class="mf-v10-state" id="mfMoreBioState">OFF</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreWidgets"><span class="mf-v10-icon">▦</span><span class="mf-v10-label">Widgets</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreExport"><span class="mf-v10-icon">⇩</span><span class="mf-v10-label">Transaction Export</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreNotes"><span class="mf-v10-icon">▤</span><span class="mf-v10-label">Notes</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreCalculator"><span class="mf-v10-icon">▦</span><span class="mf-v10-label">Calculator</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreCustom"><span class="mf-v10-icon">⚙</span><span class="mf-v10-label">Customisation</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreBackup"><span class="mf-v10-icon">☁️</span><span class="mf-v10-label">Backup &amp; Restore</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreHistory"><span class="mf-v10-icon">📊</span><span class="mf-v10-label">Transaction History</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreHelp"><span class="mf-v10-icon">?</span><span class="mf-v10-label">Help &amp; Feedback</span><span class="mf-v10-arrow">›</span></button>'+
        '<button type="button" class="mf-v10-legacy-item" id="mfMoreAccount"><span class="mf-v10-icon">👤</span><span class="mf-v10-label">Account / Login</span><span class="mf-v10-arrow">›</span></button>'+
      '</div>';
  }
  function updateProfileVisual(){
    const p=activeProfile(),src=photo(p),name=p&&p.name?p.name:'Profile / Mode';
    const av=document.getElementById('mfV10MoreAvatar'),nm=document.getElementById('mfV10MoreProfileName'),sub=document.getElementById('mfV10MoreProfileSub');
    if(av)av.innerHTML=src?'<img alt="Profile photo" src="'+esc(src)+'">':FALLBACK;
    if(nm)nm.textContent=name;
    if(sub)sub.textContent='Manage your account';
    const bioState=document.getElementById('mfMoreBioState');
    try{
      const s=p&&p.security;
      if(bioState)bioState.textContent=(s&&s.bioEnabled)?'ON':'OFF';
    }catch(e){}
    const addState=document.getElementById('mfMoreAddPinState');
    try{if(addState)addState.textContent=(p&&p.security&&p.security.addProtection)?'ON':'OFF';}catch(e){}
  }
  function updateProfileModal(){
    const modal=document.getElementById('v10ProfileModal'); if(!modal)return;
    const box=modal.querySelector('.v10box'); if(!box)return;
    let head=box.querySelector('.mf-v10-profile-modal-head');
    if(!head){
      head=document.createElement('div');head.className='mf-v10-profile-modal-head';
      box.insertBefore(head,box.firstChild);
    }
    const p=activeProfile(),src=photo(p),name=p&&p.name?p.name:'My Money';
    head.innerHTML='<div class="mf-v10-profile-modal-avatar">'+(src?'<img alt="Profile photo" src="'+esc(src)+'">':FALLBACK)+'</div><div><b>'+esc(name)+'</b><small>Active Profile / Mode</small></div>';
  }
  function bindLegacy(){
    const ids={
      mfMoreProfileMode:function(){if(typeof window.v10OpenProfiles==='function')window.v10OpenProfiles();},
      mfMoreAccount:function(){if(typeof window.mfOpenAccount==='function')window.mfOpenAccount();},
      mfMoreBackup:function(){if(typeof window.mfOpenBackup==='function')window.mfOpenBackup();},
      mfMorePin:function(){if(typeof window.v10OpenPin==='function')window.v10OpenPin();},
      mfMoreAddPin:function(){if(typeof window.v10AddTxPinSettings==='function')window.v10AddTxPinSettings();},
      mfMoreHistory:function(){if(typeof window.openHistory==='function')window.openHistory();},
      mfMoreExport:function(){if(typeof window.pfOpenExport==='function')window.pfOpenExport();},
      mfMoreWidgets:function(){if(typeof window.pfOpenWidgets==='function')window.pfOpenWidgets();},
      mfMoreCustom:function(){if(typeof window.openCustomization==='function')window.openCustomization();},
      mfMoreBio:function(){if(typeof window.v30OpenBiometricSettings==='function')window.v30OpenBiometricSettings();},
      mfMoreCalculator:function(){if(typeof window.pfOpenCalculator==='function')window.pfOpenCalculator();},
      mfMoreNotes:function(){if(typeof window.pfOpenNotes==='function')window.pfOpenNotes();},
      mfMoreHelp:function(){try{alert('Money Flow Help\n\nNotes are saved locally on this device. Transactions are backed up/restored separately. Use Profile / Mode for profiles and security settings.');}catch(e){} }
    };
    Object.keys(ids).forEach(function(id){const el=document.getElementById(id);if(el&&!el.__mfV10Bound){el.__mfV10Bound=true;el.addEventListener('click',function(e){e.preventDefault();closeEverythingBeforeOpen();setTimeout(ids[id],0);});}});
    const prof=document.getElementById('mfV10MoreProfile');
    if(prof&&!prof.__mfV10Bound){prof.__mfV10Bound=true;['click','keydown'].forEach(function(ev){prof.addEventListener(ev,function(e){if(ev==='keydown'&&e.key!=='Enter'&&e.key!==' ')return;e.preventDefault();closeEverythingBeforeOpen();setTimeout(function(){if(typeof window.v10OpenProfiles==='function')window.v10OpenProfiles();},0);});});}
    updateProfileVisual();
  }
  function patchBuild(){
    const old=window.mfnOpenMore;
    if(typeof old!=='function'||window.__mfV10MorePatched)return;
    window.__mfV10MorePatched=true;
    window.mfnOpenMore=function(){
      old();
      const modal=document.getElementById('mfnMoreModal'); if(!modal)return;
      const sheet=modal.querySelector('.mfn-more-sheet'); if(sheet)sheet.classList.add('mf-v10-more-sheet');
      const existing=sheet&&sheet.querySelector('.mfn-more-menu');
      if(sheet&&!sheet.querySelector('.mf-v10-legacy-menu')){
        sheet.innerHTML='<div class="pf-feature-head"><div><span class="pf-feature-kicker">QUICK ACCESS</span><h2>More</h2></div><button class="pf-feature-close" type="button" id="mfMoreSheetClose">✕</button></div>'+legacyMarkup();
        const close=document.getElementById('mfMoreSheetClose');if(close)close.onclick=function(){window.mfnCloseMore&&window.mfnCloseMore();};
      }
      bindLegacy();
      setTimeout(function(){
        const sh=document.getElementById('mfnMoreModal')?.querySelector('.mfn-more-sheet');
        if(sh)sh.scrollTop=0;
      },0);
    };
    window.mfnOpenMore.__mfV10More='1';
    const origClose=window.mfnCloseMore;
    if(typeof origClose==='function'&&!window.__mfV10ClosePatched){
      window.__mfV10ClosePatched=true;
      window.mfnCloseMore=function(){return origClose.apply(this,arguments);};
    }
  }
  function patchProfile(){
    const old=window.v10OpenProfiles;
    if(typeof old!=='function'||window.__mfV10ProfilePatched)return;
    window.__mfV10ProfilePatched=true;
    window.v10OpenProfiles=function(){
      closeEverythingBeforeOpen();
      old.apply(this,arguments);
      setTimeout(updateProfileModal,0);
    };
  }
  function watch(){patchBuild();patchProfile();updateProfileModal();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',watch);else watch();
  setTimeout(watch,250);setTimeout(watch,800);setTimeout(watch,1500);
  window.addEventListener('storage',function(){updateProfileVisual();updateProfileModal();});
})();



(function(){
  'use strict';
  const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
  function read(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=read(),id=localStorage.getItem(AK);return a.find(p=>p&&String(p.id)===String(id))||a[0]||null}
  function refresh(){
    const p=active();if(!p)return;
    const badge=document.getElementById('profileBadge');if(badge)badge.textContent=p.name||'My Money';
    const btn=document.getElementById('profilePhotoBtn');
    if(btn){const src=typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0?p.profilePhoto:'';if(src)btn.innerHTML='<img alt="Money Flow profile" src="'+src+'">';}
    const backup=document.getElementById('mfBackupAccount');if(backup)backup.textContent=p.name||'My Money';
    try{if(typeof window.v10RefreshAddTxSecurityUI==='function')window.v10RefreshAddTxSecurityUI()}catch(e){}
    try{if(typeof window.render==='function')window.render()}catch(e){}
    try{if(typeof window.pfRenderTransactionsPage==='function')window.pfRenderTransactionsPage()}catch(e){}
    try{if(typeof window.pfRenderAnalytics==='function')window.pfRenderAnalytics()}catch(e){}
  }
  const old=window.v10SwitchProfile;
  if(typeof old==='function'&&!window.__mfV18SwitchWrapped){
    window.__mfV18SwitchWrapped=true;
    window.v10SwitchProfile=function(id){const r=old.apply(this,arguments);setTimeout(refresh,0);setTimeout(refresh,60);setTimeout(refresh,220);return r;};
  }
  window.mfRefreshActiveProfileUI=refresh;
  window.addEventListener('load',function(){setTimeout(refresh,0);setTimeout(refresh,250)});
})();



(function(){
'use strict';

/* ================================================================
   MF V21 — TRANSACTION FORM STATE CONTROLLER
   Isolated module: does not replace the transaction-save core.
   ================================================================ */
(function(){
  const TYPE='type', CAT='categorySelect', AMT='amountPreset';
  function today(){return typeof localToday==='function'?localToday():new Date().toISOString().slice(0,10)}
  function getConfig(){
    try{
      if(typeof config==='object'&&config)return config;
      const x=JSON.parse(localStorage.getItem('money_manager_config')||'null');
      return x||{creditAmounts:[100,500,1000],expenseAmounts:[50,100,500],creditCategories:['Salary','Home Money','Other Income'],expenseCategories:['Food','Transport','Bills','Shopping','Other']};
    }catch(e){return {creditAmounts:[100,500,1000],expenseAmounts:[50,100,500],creditCategories:['Salary','Home Money','Other Income'],expenseCategories:['Food','Transport','Bills','Shopping','Other']}}
  }
  function reset(){
    const d=document.getElementById('date'),t=document.getElementById(TYPE),a=document.getElementById(AMT),c=document.getElementById(CAT);
    if(d){d.max=today();d.value=today()}
    if(t)t.value='';
    if(a){a.innerHTML='<option value="" selected>Select amount</option>';a.value='';}
    const ca=document.getElementById('customAmount');if(ca){ca.value='';ca.style.display='none'}
    if(c){c.innerHTML='<option value="" selected>Select category</option>';c.value='';}
    const cc=document.getElementById('customCategory');if(cc){cc.value='';cc.style.display='none'}
    const m=document.getElementById('mode');if(m)m.value='';
    ['description','remark','other'].forEach(id=>{const e=document.getElementById(id);if(e)e.value=''})
  }
  function populate(){
    const t=document.getElementById(TYPE),a=document.getElementById(AMT),c=document.getElementById(CAT);if(!t||!a||!c)return;
    const v=t.value, cfg=getConfig();
    if(v!=='CREDIT'&&v!=='EXPENSE'){reset();return}
    const amounts=v==='CREDIT'?(cfg.creditAmounts||[]):(cfg.expenseAmounts||[]);
    const cats=v==='CREDIT'?(cfg.creditCategories||[]):(cfg.expenseCategories||[]);
    a.innerHTML='<option value="" selected>Select amount</option>'+amounts.map(n=>'<option value="'+Number(n)+'">₹'+Number(n).toLocaleString('en-IN')+'</option>').join('')+'<option value="CUSTOM">Custom</option>';
    c.innerHTML='<option value="" selected>Select category</option>'+cats.map(x=>'<option value="'+String(x).replace(/"/g,'&quot;')+'">'+String(x).replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]))+'</option>').join('')+'<option value="CUSTOM">Custom</option>';
    a.value='';c.value='';
    const ca=document.getElementById('customAmount');if(ca){ca.value='';ca.style.display='none'}
    const cc=document.getElementById('customCategory');if(cc){cc.value='';cc.style.display='none'}
  }
  window.mfV21ResetTransactionForm=reset;
  window.mfV21RefreshTransactionType=populate;
  document.addEventListener('change',function(e){if(e.target&&e.target.id===TYPE)populate()},true);
  const oldOpen=window.pfOpenAddTransaction;
  if(typeof oldOpen==='function'&&!window.__mfV21AddOpen){
    window.__mfV21AddOpen=true;
    window.pfOpenAddTransaction=function(){reset();return oldOpen.apply(this,arguments)};
  }
  document.addEventListener('click',function(e){
    const b=e.target&&e.target.closest?e.target.closest('#v10AddTxButton'):null;
    if(!b)return;
    setTimeout(function(){
      const m=document.getElementById('addTransactionModal');
      if(m&&getComputedStyle(m).display==='none')reset();
    },80);
  },true);
  function boot(){reset()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

/* ================================================================
   MF V21 — PROFILE PHOTO / MODE ISOLATION
   A completely separate picker controller. Uses the active profile ID
   at both open and commit, so Profile B cannot save into Profile A.
   ================================================================ */
(function(){
  const PK='money_manager_profiles_v10',AK='money_manager_active_profile_v10';
  const sets={
    male:[['M1','#cfe8ff','#263b57','#111827','beard'],['M2','#dff4e7','#29463b','#111a16','beard'],['M3','#ffe3c9','#5b3d2e','#20140e','beard'],['M4','#e7dcff','#403657','#15111c','cap'],['M5','#dcecf7','#344b60','#151b22','beard'],['M6','#f1dfc9','#2f4a3b','#111710','beard'],['M7','#e9e9ea','#4c3a31','#141311','glasses'],['M8','#d9eaff','#51465b','#121016','beard']],
    female:[['F1','#ffdce9','#553246','#24151d','long'],['F2','#e7ddff','#4d4167','#18131f','long'],['F3','#ffe5d0','#704b36','#21150e','long'],['F4','#dff2e9','#3c554a','#151d19','long'],['F5','#dce9ff','#465a70','#161b24','bob'],['F6','#f5e0d2','#613e48','#201318','long'],['F7','#eee3d6','#4a423a','#151311','long'],['F8','#e5dcff','#503c59','#18111b','bob']],
    other:[['O1','#dff3ff','#315267','#121c23','short'],['O2','#eee2ff','#57416d','#191220','hood'],['O3','#e6f1d8','#40553b','#151c13','short'],['O4','#ffe5d5','#5d493a','#20170f','hood'],['O5','#dce7ef','#42525e','#141b20','glasses'],['O6','#f0dff2','#5c415c','#1c121c','short'],['O7','#e8e8e8','#444','#111','short'],['O8','#dff1ee','#3c5750','#111b18','hood']]
  };
  function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  function avatar(kind,bg,shirt,hair,style){
    const g=kind[0],female=g==='F',other=g==='O';
    const skin=female?'#d9a17f':other?'#c79576':'#bd805f';
    const skin2=female?'#a96d55':other?'#9d684f':'#95583f';
    let head='<ellipse cx="100" cy="91" rx="45" ry="56" fill="'+skin+'"/>';
    let hairPath='';
    if(female){
      hairPath=style==='bob'?'<path d="M50 96C44 48 68 16 101 18c35 2 55 29 49 77l-16 9-5-48c-20 17-42 24-71 23l-1 43-10-4z" fill="'+hair+'"/>':'<path d="M48 94C42 43 67 13 101 16c37 3 57 34 50 81l-15 5-7-42c-19 18-42 25-71 25l-1 62-12 4c-10-20-9-35 3-57z" fill="'+hair+'"/>';
    }else if(style==='cap'||style==='hood'){
      hairPath='<path d="M50 78c1-42 23-62 50-62 30 0 51 23 50 65l-17 10-10-31c-17 14-40 22-69 22z" fill="'+hair+'"/>';
      if(style==='cap')hairPath+='<path d="M54 42c15-22 77-26 94 7-26-8-63-7-94-7z" fill="#202733"/><path d="M119 47c23-2 38 1 47 9-17 7-32 5-47-1z" fill="#171c25"/>';
      if(style==='hood')hairPath+='<path d="M46 75c-8-28 1-56 24-67 25-13 53-3 72 21-19-8-37-9-57-2-14 5-26 17-39 48z" fill="'+shirt+'" opacity=".9"/>';
    }else{
      hairPath='<path d="M50 84c0-43 21-67 50-67 32 0 52 24 49 65-14-7-26-16-39-28-17 20-36 28-60 30z" fill="'+hair+'"/>';
    }
    const beard=(!female&&style!=='hood')?'<path d="M70 108c4 29 16 40 30 40s26-11 30-40c-6 13-18 20-30 20s-24-7-30-20z" fill="'+skin2+'"/>':'';
    const glasses=style==='glasses'?'<rect x="66" y="87" width="28" height="18" rx="7" fill="none" stroke="#28313b" stroke-width="5"/><rect x="106" y="87" width="28" height="18" rx="7" fill="none" stroke="#28313b" stroke-width="5"/><path d="M94 94h12" stroke="#28313b" stroke-width="5"/>':'';
    const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="'+bg+'"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><rect width="200" height="200" rx="100" fill="url(#bg)"/><ellipse cx="100" cy="190" rx="70" ry="52" fill="'+shirt+'"/>'+head+hairPath+'<path d="M82 79q9-7 18 0M108 79q9-7 18 0" fill="none" stroke="#352b27" stroke-width="5" stroke-linecap="round"/><ellipse cx="81" cy="93" rx="5" ry="7" fill="#241e1c"/><ellipse cx="119" cy="93" rx="5" ry="7" fill="#241e1c"/>'+glasses+beard+'<path d="M88 116q12 8 24 0" fill="none" stroke="#8b5148" stroke-width="4" stroke-linecap="round"/></svg>';
    return 'data:image/svg+xml;charset=UTF-8,'+encodeURIComponent(svg);
  }
  function profiles(){try{const a=JSON.parse(localStorage.getItem(PK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
  function active(){const a=profiles(),id=localStorage.getItem(AK)||localStorage.getItem('activeProfileId')||localStorage.getItem('currentProfileId');return a.find(p=>p&&String(p.id)===String(id))||a[0]||null}
  function save(a){localStorage.setItem(PK,JSON.stringify(a))}
  function getPhoto(p){return p&&typeof p.profilePhoto==='string'&&p.profilePhoto.indexOf('data:image/')===0?p.profilePhoto:''}
  function data(g){return (sets[g]||sets.other).map(x=>({id:x[0],src:avatar(x[0],x[1],x[2],x[3],x[4])}))}
  let modal,state;
  function ensure(){
    if(modal)return modal;
    modal=document.createElement('div');modal.id='mf21PhotoModal';modal.className='mf19-photo-modal';
    modal.innerHTML='<div class="mf19-photo-box"><div class="mf19-photo-head"><div><h2 id="mf21Title">Choose Profile Photo</h2><p>Select an avatar or upload from your gallery</p></div><button class="mf19-x" id="mf21Close">×</button></div><div class="mf19-preview" id="mf21Preview"></div><label class="mf19-gallery" for="mf21Gallery"><div class="mf19-gallery-icon">🖼️</div><div><b>Click to upload from Gallery</b><small>Choose your own photo</small></div></label><input id="mf21Gallery" class="pf-profile-input" type="file" accept="image/*"><div class="mf19-label">Select default avatar</div><div class="mf19-tabs"><button data-g="male">♂ Male</button><button data-g="female">♀ Female</button><button data-g="other">◈ Other</button></div><div class="mf21-avatar-grid" id="mf21Grid"></div><div class="mf19-pager"><button id="mf21Prev">‹</button><span class="mf19-page" id="mf21Page">1 / 2</span><button id="mf21Next">›</button></div><button class="mf19-ok" id="mf21OK">OK</button><div class="mf19-hint">This photo belongs only to the current Profile / Mode.</div></div>';
    document.body.appendChild(modal);
    document.getElementById('mf21Close').onclick=close;document.getElementById('mf21OK').onclick=commit;
    document.getElementById('mf21Prev').onclick=()=>{state.page=Math.max(0,state.page-1);render()};document.getElementById('mf21Next').onclick=()=>{state.page=Math.min(1,state.page+1);render()};
    modal.querySelectorAll('.mf19-tabs button').forEach(b=>b.onclick=()=>{state.gender=b.dataset.g;state.page=0;const p=active();state.photo=getPhoto(p)||data(state.gender)[0].src;render()});
    document.getElementById('mf21Gallery').onchange=function(){const f=this.files&&this.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const max=640,s=Math.min(1,max/Math.max(im.naturalWidth||im.width,im.naturalHeight||im.height)),w=Math.max(1,Math.round((im.naturalWidth||im.width)*s)),h=Math.max(1,Math.round((im.naturalHeight||im.height)*s));const cv=document.createElement('canvas');cv.width=w;cv.height=h;cv.getContext('2d').drawImage(im,0,0,w,h);state.photo=cv.toDataURL('image/jpeg',.8);renderPreview()};im.onerror=()=>{state.photo=String(r.result);renderPreview()};im.src=String(r.result)};r.readAsDataURL(f)};
    return modal;
  }
  function renderPreview(){const e=document.getElementById('mf21Preview');if(e)e.innerHTML=state.photo?'<img alt="Selected profile photo" src="'+esc(state.photo)+'">':''}
  function render(){const g=document.getElementById('mf21Grid');if(!g)return;const arr=data(state.gender),items=arr.slice(state.page*4,state.page*4+4);g.innerHTML=items.map(x=>'<button type="button" class="mf21-avatar '+(state.photo===x.src?'active':'')+'" data-src="'+esc(x.src)+'"><img alt="'+esc(x.id)+' avatar" src="'+x.src+'"></button>').join('');g.querySelectorAll('button').forEach(b=>b.onclick=()=>{state.photo=b.dataset.src;render()});document.getElementById('mf21Page').textContent=(state.page+1)+' / 2';document.getElementById('mf21Prev').disabled=state.page===0;document.getElementById('mf21Next').disabled=state.page===1;modal.querySelectorAll('.mf19-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.g===state.gender));renderPreview()}
  function open(){const p=active();if(!p)return;state={profileId:String(p.id),gender:['male','female','other'].includes(String(p.profileGender||'').toLowerCase())?String(p.profileGender).toLowerCase():'male',page:0,photo:getPhoto(p)||data(p.profileGender||'male')[0].src};ensure().classList.add('open');modal.setAttribute('aria-hidden','false');render()}
  function close(){if(modal){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}}
  function commit(){
    if(!state||!state.profileId)return;
    const a=profiles(),i=a.findIndex(p=>p&&String(p.id)===String(state.profileId));if(i<0)return;
    const q=a[i],photo=state.photo||data(state.gender)[0].src;q.profileGender=state.gender;q.profilePhoto=photo;a[i]=q;
    try{save(a);localStorage.setItem('money_flow_profile_photo_'+String(q.id),photo)}catch(e){alert('Profile photo could not be saved.');return}
    close();
    try{if(typeof window.mfRefreshActiveProfileUI==='function')window.mfRefreshActiveProfileUI()}catch(e){}
    try{if(typeof window.render==='function')window.render()}catch(e){}
    try{if(typeof window.pfScheduleCloudSync==='function')window.pfScheduleCloudSync()}catch(e){}
  }
  window.mfV21OpenProfilePhoto=open;
  const b=document.getElementById('profilePhotoBtn');
  function bind(){const x=document.getElementById('profilePhotoBtn');if(x&&!x.__mf21){x.__mf21=true;x.onclick=open;x.setAttribute('aria-label','Choose profile photo')}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();setTimeout(bind,250);setTimeout(bind,800);
})();

/* ================================================================
   MF V21 — ANALYTICS EXPORT: expose a real global handler.
   The previous function lived inside an IIFE, so inline onclick could
   not resolve it. This module owns the public export API.
   ================================================================ */
(function(){
  function money(v){return '₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2})}
  function tx(){try{if(typeof window.mfActiveProfileTransactions==='function')return window.mfActiveProfileTransactions()||[];if(typeof txs!=='undefined'&&Array.isArray(txs))return txs;return []}catch(e){return[]}}
  function catTotals(arr,type){const m={};arr.filter(t=>String(t.type||'').toUpperCase()===type).forEach(t=>{const c=t.category||'Uncategorized';m[c]=(m[c]||0)+(Number(t.amount)||0)});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
  window.pfExportAnalyticsImage=function(){
    try{
      const data=tx(),ex=data.filter(t=>String(t.type).toUpperCase()!=='CREDIT'),cr=data.filter(t=>String(t.type).toUpperCase()==='CREDIT'),te=ex.reduce((s,t)=>s+(Number(t.amount)||0),0),tc=cr.reduce((s,t)=>s+(Number(t.amount)||0),0),cats=catTotals(data,'EXPENSE').slice(0,8),W=1200,H=1550,cv=document.createElement('canvas');cv.width=W;cv.height=H;const c=cv.getContext('2d');
      if(!c)throw new Error('Canvas is unavailable on this device.');
      c.fillStyle='#faf8f2';c.fillRect(0,0,W,H);c.fillStyle='#51463a';c.font='700 46px Arial';c.fillText('Money Flow — Analytics',60,70);c.font='22px Arial';c.fillStyle='#8b8378';c.fillText(new Date().toLocaleDateString('en-IN'),60,105);
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Expense by Category',60,165);let y=215;const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];cats.forEach((x,i)=>{c.fillStyle=pal[i%pal.length];c.beginPath();c.arc(75,y-7,9,0,Math.PI*2);c.fill();c.fillStyle='#51463a';c.font='21px Arial';c.fillText(x[0],100,y);c.textAlign='right';c.font='700 20px Arial';c.fillText(money(x[1]),1140,y);c.textAlign='left';y+=45});
      function box(x,yy,w,title,val,sub){c.fillStyle='#fffdf9';c.strokeStyle='#ded8cc';c.lineWidth=2;c.beginPath();c.roundRect?c.roundRect(x,yy,w,110,18):(function(){c.moveTo(x+18,yy);c.lineTo(x+w-18,yy);c.quadraticCurveTo(x+w,yy,x+w,yy+18);c.lineTo(x+w,yy+92);c.quadraticCurveTo(x+w,yy+110,x+w-18,yy+110);c.lineTo(x+18,yy+110);c.quadraticCurveTo(x,yy+110,x,yy+92);c.lineTo(x,yy+18);c.quadraticCurveTo(x,yy,x+18,yy)})();c.fill();c.stroke();c.fillStyle='#51463a';c.font='700 20px Arial';c.fillText(title,x+22,yy+32);c.font='700 30px Arial';c.fillText(money(val),x+22,yy+70);c.fillStyle='#8b8378';c.font='17px Arial';c.fillText(sub,x+22,yy+95)}
      box(60,610,520,'Total Credit',tc,'All time income');box(620,610,520,'Total Expense',te,'All time expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Today vs Yesterday',60,760);box(60,800,330,'Credit Today',0,'Income today');box(435,800,330,'Expense Today',0,'Expense today');box(810,800,330,'Today Net',0,'Credit − Expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Category Ranking',60,980);const ranking=[...catTotals(data,'CREDIT').map(x=>['Cr',x[0],x[1]]),...cats.map(x=>['Exp',x[0],x[1]])].sort((a,b)=>b[2]-a[2]).slice(0,7),rm=Math.max(1,...ranking.map(x=>x[2]));ranking.forEach((x,i)=>{const yy=1025+i*58;c.fillStyle='#51463a';c.font='18px Arial';c.fillText((i+1)+'. '+x[0]+' '+x[1],60,yy);c.fillStyle=x[0]==='Cr'?'#2fa65b':'#e3483d';c.fillRect(430,yy-15,570*(x[2]/rm),18);c.fillStyle='#51463a';c.textAlign='right';c.font='700 18px Arial';c.fillText(money(x[2]),1110,yy);c.textAlign='left'});c.fillStyle='#8b8378';c.font='17px Arial';c.fillText('Generated from Money Flow transaction analytics',60,H-45);
      const b64=cv.toDataURL('image/png').split(',')[1],name='money_flow_analytics_'+Date.now()+'.png';
      if(window.AndroidFile&&typeof window.AndroidFile.saveFile==='function'){window.AndroidFile.saveFile(name,'image/png',b64);alert('Analytics image saved successfully.');return true}
      const a=document.createElement('a');a.href='data:image/png;base64,'+b64;a.download=name;document.body.appendChild(a);a.click();a.remove();return true;
    }catch(e){alert('Export Image failed: '+(e&&e.message?e.message:'Unknown error'));return false}
  };
})();

/* ================================================================
   MF V21 — CLOUD-ONLY MANUAL SYNC
   Manual Google Drive Sync must not create a local backup snapshot.
   Sign-out backup continues to use the existing native snapshot path.
   ================================================================ */
(function(){
  const old=window.mfBackupNow;
  if(typeof old==='function'&&!window.__mfV21CloudOnlyBackup){
    window.__mfV21CloudOnlyBackup=true;
    window.mfBackupNow=function(){
      const prev=!!window.__mfV21CloudOnlyManualBackup;
      window.__mfV21CloudOnlyManualBackup=true;
      try{return old.apply(this,arguments)}finally{window.__mfV21CloudOnlyManualBackup=prev;}
    };
  }
})();
})();
