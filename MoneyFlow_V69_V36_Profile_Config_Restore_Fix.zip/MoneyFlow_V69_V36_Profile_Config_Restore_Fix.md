# MoneyFlow V36 — Profile Config Restore Fix

## Issue fixed
After switching/signing into a profile/account, the Add Transaction form could show only `Custom` in the Amount and Category selectors. The selected profile could have a missing or incomplete `config`, which replaced the app's valid configuration.

## Fix
- Every new profile now receives a complete isolated default transaction configuration.
- Existing profiles with missing/incomplete configuration are repaired with defaults without overwriting valid custom amounts/categories.
- Profile switching and cloud profile application always load a validated profile configuration.
- Cloud restore normalizes missing profile configuration before applying it.
- Existing valid custom configuration remains unchanged.

## Preserved
- V35 default/duplicate `My Money` profile isolation fix.
- Account/profile transaction isolation.
- Google Drive backup/restore flow.
- Sign-out flow and backup verification.
- Analytics/PDF and other unrelated UI/functionality.
