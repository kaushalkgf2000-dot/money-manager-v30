# CivilNexa Step 29E — Navigation & UI Fix

## Navigation contract
- Android Back follows the exact in-app navigation stack, one screen at a time.
- Home is the root screen. Android Back at Home is not intercepted, so the Activity exits normally.
- Study flow: Home → Study → Subject → Chapter → Topic; Back reverses that exact path.
- Test flow: Home/Tests/Chapter → Live Test → Result; Back reverses the stack.
- Android Back during a live test opens an Exit Test confirmation; answers remain saved for resume.
- Bottom app navigation is hidden inside Study, nested Study screens, Live Test and Result.
- Test controls remain icon-only.
