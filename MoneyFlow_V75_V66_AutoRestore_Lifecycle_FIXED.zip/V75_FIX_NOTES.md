# MoneyFlow V75 — V66 Auto-Restore Lifecycle Fix

## Root cause confirmed
V74 replaced V66's reload-safe per-account `sessionStorage` one-shot marker with an in-memory `autoSyncStartedForCurrentAuth` guard. V74 still performs a WebView `location.reload()` after a successful automatic cloud restore. The in-memory flag is recreated after reload, so the next auth callback can start automatic restore again. This produces the repeated refresh/Home-screen behavior.

## Fix in V75
- Restored V66's account-scoped `sessionStorage` marker: `pf_auto_cloud_sync_done_<account>`.
- The marker is written **before** automatic Drive restore begins, so a reload cannot start the same automatic restore again in the same WebView session.
- Kept V74's in-memory duplicate-callback guard.
- Kept V74's existing Drive restore/retry behavior and sign-out-after-successful-backup flow.
- On deliberate logout, the current account's marker is cleared so the next login can perform a fresh automatic restore.
- Manual Restore behavior was not changed.

## Expected result
After login/app startup, automatic cloud restore runs at most once for that account during the current WebView session. If the restore applies data and the app reloads once, the reload will not trigger another automatic restore/reload cycle.
