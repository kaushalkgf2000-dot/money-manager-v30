# MoneyFlow V74 — Auto Restore Refresh Loop Fix

## Fixed

1. Removed the `location.reload()` that ran after the automatic first-time cloud backup.
   - Previously: auto-restore finds no backup -> auto-backup creates one -> page reloads -> auth/status runs again -> the cycle repeats.
   - Now the current local data remains in place without reloading the homepage.

2. Added an in-memory guard so repeated Firebase signed-in/status callbacks cannot start overlapping automatic restore attempts during the same app/page session.
   - The guard resets on sign-out.
   - It naturally resets on a real app/page restart, so automatic restore still runs after reopening the app.

3. Existing automatic backup/restore and sign-out logic is otherwise unchanged.
