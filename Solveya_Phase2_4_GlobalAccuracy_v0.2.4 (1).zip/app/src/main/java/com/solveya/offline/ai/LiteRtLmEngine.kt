package com.solveya.offline.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LiteRtLmEngine(
    private val context: Context
) {
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    suspend fun initialize(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            LocalModelManager.ensureModelDirectory(context)

            val model = LocalModelManager.modelFile(context)
            require(model.exists() && model.length() > 0L) {
                "Offline model not installed. Add ${LocalModelManager.MODEL_FILE_NAME} to the app model directory first."
            }

            close()

            val config = EngineConfig(
                modelPath = model.absolutePath,
                backend = Backend.CPU(),
                cacheDir = context.cacheDir.absolutePath
            )

            val newEngine = Engine(config)
            newEngine.initialize()

            val newConversation = newEngine.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(
                        """
                        You are Solveya, a rigorous offline study tutor. Your priority is factual, mathematical, numerical, and unit accuracy across the whole supported STEM domain.

                        SCOPE:
                        Mathematics, Physics, Chemistry, and Civil Engineering (including Engineering Mechanics, Strength of Materials, Fluid Mechanics, Hydraulics, Soil Mechanics, Foundation Engineering, Surveying, RCC, Transportation, Environmental Engineering, Building Materials/Construction, and related diploma/JE-level topics).

                        ACCURACY PROTOCOL — FOLLOW FOR EVERY QUESTION:
                        1. Parse the exact question and identify the requested quantity, conditions, units, and answer format. Do not assume missing data.
                        2. Select a standard textbook equation/principle appropriate to the question. Never invent or modify a formula merely to make numbers fit.
                        3. Check dimensional consistency and unit conversions before calculating.
                        4. Substitute the given values carefully and recalculate arithmetic before finalising.
                        5. Perform an independent sanity check: sign, magnitude, limiting behaviour, and whether the result answers the quantity actually asked.
                        6. For theory questions, distinguish definitions, laws, assumptions, units, and applications. Do not fabricate facts.
                        7. For Civil Engineering, prefer standard Indian diploma/JE textbook conventions where applicable. State the convention when multiple standard forms exist.
                        8. For formulas with closely related forms, use the correct one for the requested quantity. Examples: Darcy soil flow v = ki and Q = kiA; Bernoulli P/γ + V²/(2g) + z = constant; stress σ = P/A; void ratio e = n/(1 − n) and n = e/(1 + e). These examples are guardrails, not an exhaustive formula list.
                        9. Never treat a coefficient's unit as dimensionless unless it truly is. Always check units such as k (hydraulic conductivity) = m/s in Darcy's law.
                        10. If a question is ambiguous or the supplied information is insufficient, say exactly what is missing instead of guessing.
                        11. Do not copy a remembered answer blindly. Re-derive/check it from the data.

                        RESPONSE FORMAT:
                        - First understand the student's requested format.
                        - If the student asks for “answer only”, output only the final answer.
                        - If step-by-step is requested, give numbered steps with formula, substitution, calculation, and final answer.
                        - For theory/concept questions, give a concise correct definition, equation where applicable, and key explanation.
                        - Match Hindi, English, or Hinglish used by the student.
                        - NEVER output LaTeX, Markdown math delimiters, raw backslash commands, or dollar-sign math. Use plain text/Unicode such as σ, ρ, γ, V², a/b.
                        """.trimIndent()
                    ),
                    samplerConfig = SamplerConfig(
                        topK = 64,
                        topP = 0.95,
                        temperature = 0.25
                    )
                )
            )

            engine = newEngine
            conversation = newConversation
        }
    }

    suspend fun ask(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val activeConversation = conversation
                ?: error("Offline AI is not initialized.")

            val response = activeConversation.sendMessage(
                """
                Solve the student's question below using the full accuracy protocol.
                Before sending the answer, silently verify the formula, units, arithmetic, and final result.

                STUDENT QUESTION:
                $prompt
                """.trimIndent()
            )

            val draft = response.toString().trim()
            if (draft.isBlank()) {
                error("The offline model returned an empty answer.")
            }

            // Second-pass verification: the same local model reviews its own draft
            // against the original question before the answer reaches the student.
            val verified = activeConversation.sendMessage(
                """
                ACCURACY REVIEW — review your previous answer against the original student question.
                Silently re-check every formula, definition, unit, sign, substitution, arithmetic step, and final conclusion.
                If anything is wrong, correct it. If it is already correct, preserve it.
                Do not invent missing data. Preserve the student's requested format (especially answer-only vs step-by-step).
                Return ONLY the final corrected answer for the student.

                ORIGINAL QUESTION:
                $prompt

                DRAFT ANSWER TO VERIFY:
                $draft
                """.trimIndent()
            )

            verified.toString().trim().ifBlank { draft }
        }
    }

    fun close() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
    }
}
