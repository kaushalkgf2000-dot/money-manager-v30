# MoneyFlow V69 V53 — Profile/Mode Workspace Root Fix

Baseline: V48.

This build deliberately rolls back the V49–V52 profile-avatar patch stack and keeps the V48 functional baseline, then adds one final V53 profile workspace layer.

## Scope
- Canonical per-profile photo source: `profilePhoto`, with the existing per-profile local photo cache as fallback.
- Immediate same-device avatar refresh after photo changes; no app restart required.
- One circular avatar renderer for Home, More, Profile/Mode header, and profile-list rows.
- Per-profile photo isolation by `profileId`.
- Existing cloud profile serializer/restore from V48 is preserved: profile metadata, transactions and profile photos sync; device-local PIN/recovery/biometric security remains excluded.
- Unique Profile/Mode IDs are enforced. Legacy duplicate IDs are repaired without deleting profile data; when the active ID was duplicated, the newest duplicate remains active.
- Existing profile creation is wrapped so legacy fixed-ID creation cannot create duplicate Profile/Mode IDs.
- Existing switch/create/backup/restore functionality is otherwise retained.

## Validation
- 38 JavaScript blocks extracted from `index.html`: Node syntax check PASS.
- No V49/V50/V51/V52 profile patch modules are included in this build; V48 is the base.
