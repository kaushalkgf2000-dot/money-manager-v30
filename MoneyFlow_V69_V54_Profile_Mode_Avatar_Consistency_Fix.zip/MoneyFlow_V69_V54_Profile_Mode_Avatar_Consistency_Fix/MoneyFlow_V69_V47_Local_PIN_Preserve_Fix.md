# MoneyFlow V69 V47 — Local PIN Preservation Fix

Baseline: V46.

## Root cause fixed
V42/V46 correctly removed PIN/recovery/biometric security fields from cloud payloads, but the restore/merge path accidentally used the **cloud-sanitized profile representation** as its local source. That representation intentionally contains no security fields. During restore, the matching profile could therefore lose the device-local PIN and biometric state and be treated as a fresh security state.

## Fix
- Cloud serialization remains security-free: PIN hash, recovery code, biometric state/credential, and security flags are never uploaded.
- Restore/merge now reads the full local profile list directly from `money_manager_profiles_v10` solely for local-state preservation.
- For a matching profile ID, the local device `security` object is retained unchanged while cloud transactions/profile metadata are merged.
- Fresh profiles from cloud still receive fresh device-local security state.
- Restore cleanup also uses the full local profile list so an existing local PIN cannot be misclassified as an untouched placeholder.
- No changes to transaction logic, profile/account isolation, Notes, calculator, analytics, sign-out, or backup upload behavior.

## Validation
- `all-scripts.js` syntax: PASS
- Embedded `index.html` security/restore patch applied consistently
- Cloud profile serializer still emits no security object
- Local restore merge retains `security` for matching profile IDs
