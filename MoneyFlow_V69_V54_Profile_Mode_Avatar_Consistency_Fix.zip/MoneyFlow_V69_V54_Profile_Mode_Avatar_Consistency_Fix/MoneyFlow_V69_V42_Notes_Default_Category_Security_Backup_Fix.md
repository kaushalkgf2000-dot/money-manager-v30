# MoneyFlow V69 V42 — Notes Default Category + Device-Local Security Backup Fix

## Baseline
- V41 Notes Edit/Delete PIN + Biometric.

## Notes
- New notes no longer default to `Personal`.
- New Note category starts at `Select category` with no category selected.
- Existing saved notes keep their existing category.
- Empty category is displayed as `Uncategorized`.

## Security / Backup
- The existing Profile/Mode PIN remains device-local.
- PIN hash, Recovery Code, biometric state/credential and security flags are NOT included in cloud backup, native backup snapshots, pending profile snapshots, or profile sync snapshots.
- Restore never imports security from another device/account.
- For a profile that already exists locally, its current local PIN/biometric/security state is preserved unchanged during cloud/file restore.
- A profile that exists only in the cloud receives fresh local security defaults (PIN OFF / biometric OFF) on the new device.
- No PIN bypass or automatic PIN activation occurs after restore.
- Existing Edit Transaction/Add Transaction/Notes security behavior on the current device is preserved.

## UI messaging
- Backup/restore copy now explicitly states that device-local PIN/biometric security is never backed up or restored.

## Validation
- `all-scripts.js`: Node syntax check PASS.
- Android `index.html`: all inline JavaScript blocks syntax-check PASS.
- Cloud profile serialization contains no `security` property.
- Restore merge preserves local security for matching profiles and initializes new remote-only profiles with local security disabled.
- ZIP integrity verified.
