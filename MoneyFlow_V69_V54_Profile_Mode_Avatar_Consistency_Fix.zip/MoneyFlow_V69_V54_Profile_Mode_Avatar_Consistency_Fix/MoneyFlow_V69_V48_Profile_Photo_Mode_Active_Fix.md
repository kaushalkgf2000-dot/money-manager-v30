# MoneyFlow V69 V48 — Profile Photo / Mode Isolation / Last Active Fix

Baseline: V47 Local PIN Preserve Fix.

## Changes
1. Profile photo remains scoped to the exact Profile/Mode. Existing profilePhoto data is included in cloud profile metadata so the same profile photo can restore for an existing user. No PIN/security credentials are added to backup.
2. Home, More, and Profile avatar renderers use the active Profile/Mode photo and consistent centered object positioning.
3. Fixed duplicate Profile/Mode IDs caused by the old DEFAULT_PROFILE factory. New profiles receive unique IDs. Startup migration repairs duplicate/empty IDs without deleting profile data, preventing multiple profiles with the same ID from appearing active or switching unpredictably.
4. The active Profile/Mode is persisted locally. On an existing device, cloud restore no longer replaces a valid local active Profile with cloud's first/default profile. Cloud activeProfileId is used only when there is no valid local active profile (fresh restore). Profile switches also schedule the existing cloud sync.

## Preserved
- Device-local PIN, Recovery Code and biometric state remain excluded from cloud/native backup.
- Transactions, Notes, Calculator, Analytics, backup/sign-out and account isolation logic are otherwise unchanged.
