# MoneyFlow V69 V41 — Notes Edit/Delete PIN + Biometric

## Baseline
- V40 Notes functional implementation.

## Security behavior
- Notes **Edit** and **Delete** now use the existing Profile/Mode security PIN shared with Edit Transaction and Add Transaction.
- No separate Notes PIN is created.
- If Fingerprint/Biometric is enabled for the active profile, the existing unified security gate invokes biometric first and falls back to the same PIN when biometric is unavailable/cancelled.
- Notes header/detail view has no PIN requirement. Opening/viewing/reading notes remains unrestricted.
- Creating/saving a new note, searching, filtering, and pin/unpin remain unrestricted.
- Edit: tapping Edit invokes the shared security gate before entering the edit form.
- Delete: tapping Delete opens the normal confirmation; after confirmation, the shared security gate is required before the actual deletion.
- Wrong/cancelled authentication leaves the note unchanged.
- Existing note storage remains local-only.

## Validation
- `all-scripts.js`: Node syntax check PASS.
- `index.html`: all inline JavaScript blocks syntax-check PASS.
- Verified both bundled `all-scripts.js` and Android `index.html` contain the same security implementation.
