# MoneyFlow V69 V43 — Final Three Changes

Baseline: V42

## 1. First-launch One-of-Nine onboarding update
- Existing PIN/Recovery Code/account recovery implementation is unchanged.
- Updated the onboarding recovery text to match the current final behavior.
- Recovery Code remains the first recovery method.
- If both PIN and Recovery Code are forgotten, the onboarding now explains: successfully make the latest Cloud Backup, sign in again to the same Google account, restore the backed-up Money Flow data, and create a new device PIN.
- Explicitly states that the old device PIN is device-local and is not restored from Cloud Backup.
- Updated the Data & Privacy onboarding step to describe the current account-specific Cloud Backup architecture.
- Removed the obsolete claim that losing both credentials necessarily means permanent data loss.

## 2. Functional floating Calculator
- Replaced the placeholder calculator with a compact floating calculator.
- Functional digits, decimal, +, −, ×, ÷, %, ±, backspace, clear and equals.
- Division-by-zero returns Error rather than crashing.
- Keyboard input is supported while the calculator is open.
- Close (X) returns to the underlying screen.
- Calculator resets to 0 each time it is opened.

## 3. Remove Profile Data Reset option
- Removed the visible “Reset My Money Data” option from Profile / Mode.
- No reset control is exposed from the Profile UI.
- Existing transaction/profile/backup/security logic is otherwise unchanged.

## Security preservation
- PIN, Recovery Code and biometric/security credentials remain excluded from Cloud Backup.
- Cloud Backup continues to store transaction/profile data needed for account recovery.


V44 Calculator Functional Fix
- Replaced the V43 calculator wrapper with a direct, deterministic modal opener.
- Calculator is a true centered floating panel, not a bottom sheet.
- Scoped keypad event handling prevents duplicate/blocked clicks.
- Added working C, backspace, %, sign, decimal, +, -, ×, ÷, =, keyboard input, Escape, and close.
- Preserved all V43 recovery/onboarding and data-reset removal changes.
