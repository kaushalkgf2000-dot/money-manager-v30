MoneyFlow V76 — Auto-Restore + Auto-Backup lifecycle fix

Root cause found by comparing V66, V74 and V75:
1. V66 automatically restored the cloud snapshot and then uploaded the merged/current local state back to Google Drive before its one-time reload.
2. V75 restored the snapshot but removed that post-restore upload. That regressed the automatic backup side of the lifecycle.
3. V75 also temporarily suppressed normal cloud sync during the first-time automatic backup path.

V76 fixes both without reverting the V66 reload-loop protection:
- Keeps V66 account-scoped sessionStorage marker before automatic restore.
- After successful automatic restore, uploads the merged/current state to Drive, then reloads once after the backup callback.
- First-time automatic backup no longer leaves normal cloud sync suppressed.
- Existing transaction save() -> pfScheduleCloudSync() automatic backup path remains intact.
- Manual Backup/Restore and logout backup flow are preserved from V75.
