# MoneyFlow V26 build fix

This release fixes the GitHub Actions packaging/workflow problem.

Important: the project is packaged with `.github/workflows/build.yml` at the ZIP root.
The workflow intentionally does NOT use `android-actions/setup-android` and does NOT run
`sdkmanager tools`. It verifies the Android SDK already provided by the GitHub-hosted Ubuntu
runner (platform android-35 and build-tools 35.0.0), then builds with Gradle 8.11.1.

No MoneyFlow application source code was changed for this build-only fix.
