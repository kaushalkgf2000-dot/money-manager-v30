# Money Manager V30 Android build

This project wraps the existing Money Manager V30 web app in an Android WebView and adds native Android biometric authentication and native file export.

## Implemented
- Native Android BiometricPrompt (API 28+).
- Menu biometric ON/OFF.
- When biometric is ON, security gates attempt biometric first; cancel/unavailable falls back to the existing PIN gate.
- When biometric is OFF, existing PIN flow is used.
- PDF/Excel/CSV blob exports are saved by the Android bridge into `Downloads/Money Manager` on Android 10+.
- Existing HTML/localStorage app logic is bundled unchanged apart from the native bridges.

## Build
Open the project in Android Studio and build the `app` module. The project uses compileSdk 35 and requires Android SDK/build tools available to Android Studio.


## V30 biometric PIN fix
The Android biometric enable flow now verifies the current profile PIN using the same `v10HashPin` function used by the existing PIN system. This fixes the false `Incorrect PIN` message caused by the biometric script referencing a non-global `hash` function.
