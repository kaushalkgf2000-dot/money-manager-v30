Money Flow V18 — Profile / Mode Backup & Restore Fix

Changes:
- Restores the Profile / Mode layer that was dropped when V17 changed cloud payloads to transaction-only.
- Cloud backup now carries all account-scoped Profile / Mode records, their transactions, profile photo, configuration, and profile-local PIN/recovery settings.
- Notes remain device-local and are never included.
- WebAuthn biometric credential IDs remain device-bound and are not copied to cloud; an existing local credential is retained for a matching local Mode, while a restored cloud-only Mode can re-enrol biometric locally.
- Active Profile / Mode ID is backed up and restored.
- Restore merges each Mode's transactions by stable transaction UID and preserves local unsynced changes.
- Local-only Modes are preserved.
- A fresh-install empty placeholder Mode is replaced by the cloud account's real Modes so the correct Mode becomes active after restore.
- Profile badge, profile photo, transaction/security UI, and analytics refresh immediately after Mode switching.
- Manual “Sync to Google Drive” no longer creates a backup file in Downloads. Explicit file-restore/file workflows remain separate.
- Existing 250 ms silent transaction auto-sync trigger remains enabled.
- Existing sign-out → backup → sign-out flow is preserved.
