# Money Flow V16 — Analytics UI Update

- Replaced Analytics Expense/Income toggle with a unified expense-category donut and legend.
- Added Total Credit and Total Expense cards.
- Preserved Today vs Yesterday section.
- Monthly Comparison now uses separate green Credit and red Expense lanes for every month.
- Added Maximum Expense Category, Maximum Credit Category, and Highest Single Expense cards.
- Highest Single Expense opens a full transaction detail view.
- Maximum category cards open category transaction history.
- Added Category Ranking.
- Added Export Image (PNG) action.
- Existing transaction/backup/restore logic is otherwise preserved from the supplied V14 source.
