# CivilNexa Version Info

App: CivilNexa
Version: v1.2.7
Version Code: 12
Step: 39 — Study Material End-to-End UI/UX Implementation
Status: Study flow implementation ready for device verification

Changes:
- Reworked Style-8 subject glyphs with larger, recognisable engineering symbols.
- Added subject-specific accent treatment while preserving the common visual family.
- Enlarged and refined subject icon containers.
- Improved subject card hierarchy, metadata, progress presentation and spacing.
- Preserved root/nested navigation rules.
- No bulk study/test content population; content remains a later phase.
