package com.civilnexa.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF07051A)
private val Surface = Color(0xFF12102A)
private val Surface2 = Color(0xFF181437)
private val Purple = Color(0xFF8B4DFF)
private val Purple2 = Color(0xFFC18BFF)
private val Orange = Color(0xFFFF8A32)
private val Green = Color(0xFF45D483)
private val Red = Color(0xFFFF5C6C)
private val White = Color(0xFFF7F5FF)
private val Muted = Color(0xFFB8B2CC)
private val GlassBorder = Color(0xFF6D55A8).copy(alpha = 0.42f)
private val GlassGlow = Color(0xFF8B4DFF).copy(alpha = 0.12f)

private data class Question(val text: String, val options: List<String>, val answer: Int, val difficulty: String = "Medium", val negativeMarks: Double = 0.25)
private data class TestResult(
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val timeTakenSeconds: Int,
    val totalSeconds: Int
) {
    val attempted: Int get() = correct + wrong
    val marks: Double get() = correct * 4.0 - wrong * 0.25
    val totalQuestions: Int get() = correct + wrong + skipped
    val totalMarks: Int get() = totalQuestions * 4
    val accuracy: Int get() = if (attempted == 0) 0 else (correct * 100 / attempted)
}

private val demoQuestions = listOf(
    Question("The unit of normal stress is:", listOf("N", "N/m²", "N·m", "Pa·s"), 1),
    Question("For a simply supported beam with UDL over the full span, maximum bending moment occurs at:", listOf("Support A", "Midspan", "Support B", "Quarter span"), 1),
    Question("The relation between load, shear force and bending moment is represented by:", listOf("dV/dx = -w", "dM/dx = V", "Both A and B", "Neither"), 2),
    Question("Poisson's ratio is the ratio of:", listOf("Lateral strain to longitudinal strain", "Stress to strain", "Shear stress to shear strain", "Load to area"), 0),
    Question("The SI unit of Young's modulus is:", listOf("N", "N/m", "N/m²", "m/N"), 2),
    Question("A material that undergoes large plastic deformation before failure is generally called:", listOf("Brittle", "Ductile", "Elastic", "Rigid"), 1),
    Question("The centroid of a rectangle lies at:", listOf("One corner", "The midpoint of its diagonal", "One-third height", "The base"), 1),
    Question("Bernoulli's equation is based on conservation of:", listOf("Mass only", "Momentum only", "Energy", "Temperature"), 2),
    Question("Specific gravity is the ratio of density of a substance to:", listOf("Density of air", "Density of water", "Unit weight of soil", "Viscosity of water"), 1),
    Question("The primary purpose of a foundation is to:", listOf("Increase building height", "Transfer load safely to soil", "Reduce concrete strength", "Increase dead load"), 1)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CivilNexaApp() }
    }
}

@Composable
fun CivilNexaApp() {
    val backStack = remember { mutableStateListOf("home") }
    val screen = backStack.last()
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedSubject by remember { mutableStateOf("Strength of Materials") }
    var selectedChapter by remember { mutableStateOf("Simple Stress & Strain") }
    var selectedTopic by remember { mutableStateOf("Introduction") }
    var testResult by remember { mutableStateOf(TestResult(0, 0, demoQuestions.size, 0, 180)) }
    var showTestExitConfirm by remember { mutableStateOf(false) }

    fun navigate(target: String) {
        if (backStack.lastOrNull() != target) backStack.add(target)
    }

    fun navigateRoot(target: String) {
        backStack.clear()
        backStack.add("home")
        if (target != "home") backStack.add(target)
    }

    fun goBack() {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.lastIndex)
        }
        // Root tab selection must always reflect the screen actually visible after Back.
        // This prevents Study/Tests/etc. from remaining highlighted after returning Home.
    }

    // Keep the global bottom-navigation highlight synchronized with the actual root route.
    // Nested routes intentionally preserve the current root context until they are popped.
    LaunchedEffect(screen) {
        when (screen) {
            "home" -> selectedTab = 0
            "study", "chapters", "chapter", "topic" -> selectedTab = 1
            "tests", "test", "result" -> selectedTab = 2
            "pyq" -> selectedTab = 2
            "progress" -> selectedTab = 3
            "profile" -> selectedTab = 4
        }
    }

    // Single app-wide back dispatcher: every nested screen unwinds one level at a time.
    // At Home (root) the handler is disabled so Android performs the normal app-exit action.
    BackHandler(enabled = screen == "test" || backStack.size > 1) {
        if (screen == "test") {
            showTestExitConfirm = true
        } else {
            goBack()
        }
    }
    if (showTestExitConfirm) {
        AlertDialog(
            onDismissRequest = { showTestExitConfirm = false },
            title = { Text("Exit Test?", color = White) },
            text = { Text("Your current answers are saved. You can resume this test later.", color = Muted) },
            confirmButton = {
                TextButton(onClick = { showTestExitConfirm = false; goBack() }) { Text("Exit", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { showTestExitConfirm = false }) { Text("Stay", color = Purple2) }
            },
            containerColor = Surface2
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Surface)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (screen) {
                        "home" -> Home { target -> navigateRoot(target) }
                        "study" -> Study(
                            onBack = { goBack() },
                            onSubject = { selectedSubject = it; navigate("chapters") }
                        )
                        "chapters" -> Chapters(
                            subject = selectedSubject,
                            onBack = { goBack() },
                            onChapter = { selectedChapter = it; navigate("chapter") }
                        )
                        "chapter" -> ChapterContents(
                            subject = selectedSubject,
                            chapter = selectedChapter,
                            onBack = { goBack() },
                            onTopic = { selectedTopic = it; navigate("topic") },
                            onTest = { navigate("test") }
                        )
                        "topic" -> TopicDetail(
                            subject = selectedSubject,
                            chapter = selectedChapter,
                            topic = selectedTopic,
                            onBack = { goBack() },
                            onTopicNavigate = { selectedTopic = it }
                        )
                        "tests" -> Tests(onBack = { goBack() }, onStart = { navigate("test") })
                        "pyq" -> Pyq(onBack = { goBack() })
                        "progress" -> Progress(onBack = { goBack() })
                        "profile" -> Profile(onBack = { goBack() })
                        "test" -> LiveTest(
                            onExit = { showTestExitConfirm = true },
                            onSubmit = { result -> testResult = result; navigate("result") }
                        )
                        "result" -> Result(result = testResult, onBack = { goBack() }, onBackToTests = {
                            while (backStack.size > 2 && backStack.last() != "tests") { backStack.removeAt(backStack.lastIndex) }
                            if (backStack.lastOrNull() != "tests") { navigateRoot("tests") }
                        })
                    }
                }
                // GLOBAL BOTTOM NAVIGATION: root screens ONLY.
                // Never render it inside a nested Study flow, Live Test, or Result.
                // This explicit allow-list prevents the Home/Study/Tests/Progress/Profile
                // bar from leaking into child screens even when the back stack changes.
                val rootScreens = setOf("home", "tests", "pyq", "progress", "profile")
                val nestedScreens = setOf("study", "chapters", "chapter", "topic", "test", "result")
                val showBottomBar = screen in rootScreens && screen !in nestedScreens
                if (showBottomBar) {
                    BottomBar(selectedTab) { tab ->
                        selectedTab = tab
                        navigateRoot(listOf("home", "study", "tests", "progress", "profile")[tab])
                    }
                }
            }
        }
    }
}

@Composable
private fun Top(title: String, back: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back != null) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Back", tint = White) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = White)
            Text("CivilNexa", color = Purple2, fontSize = 11.sp)
        }
        action?.invoke()
    }
}

@Composable
private fun Home(go: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF0D0924), Bg))).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(com.civilnexa.app.R.drawable.civilnexa_icon),
                    contentDescription = "CivilNexa",
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("CivilNexa", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                    Text("Your Study. Your Success.", color = Purple2, fontSize = 11.sp)
                }
                Box(
                    Modifier.size(40.dp).background(GlassGlow, RoundedCornerShape(14.dp)).border(1.dp, GlassBorder, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.NotificationsNone, "Notifications", tint = Purple2) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Welcome back, Kumar 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
            Text("Let’s prepare for your next target.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            SearchField("Search topics, subjects...") { }
            Spacer(Modifier.height(18.dp))
            Text("Quick Actions", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("Study Material", Icons.Default.MenuBook, Purple2, Modifier.weight(1f)) { go("study") }
                ActionCard("Test Series", Icons.Default.Quiz, Color(0xFF55D7C8), Modifier.weight(1f)) { go("tests") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("PYQ Center", Icons.Default.Description, Orange, Modifier.weight(1f)) { go("pyq") }
                ActionCard("Mock Test", Icons.Default.Computer, Color(0xFF58A6FF), Modifier.weight(1f)) { go("tests") }
            }
            Section("Continue Learning")
            CardBox("Strength of Materials", "Simple Stress & Strain • 65% complete", Icons.Default.MenuBook)
            Section("Performance Snapshot")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("68%", "Progress", Purple2, Modifier.weight(1f))
                StatCard("73%", "Accuracy", Green, Modifier.weight(1f))
                StatCard("48", "Tests", Orange, Modifier.weight(1f))
            }
            Section("Recommended")
            CardBox("Practice SFD & BMD", "Improve weak topics with focused questions", Icons.Default.TrendingUp) { go("tests") }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.82f)),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Study(onBack: () -> Unit, onSubject: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) }
    val filtered = CivilNexaContentRepository.subjects.filter { it.name.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        Top("Study Material", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SearchField("Search subjects...", query) { query = it }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("All Subjects") })
                    FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Semester Wise") })
                }
                Spacer(Modifier.height(10.dp))
                Text("Civil Engineering Subjects", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Structured for chapter-wise learning, practice and PYQs", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            items(filtered) { subject ->
                val avg = subject.chapters.map { it.progress }.average().takeIf { !it.isNaN() }?.toInt() ?: 0
                SubjectMaterialCard(subject.name, subject.chapters.size, avg) { onSubject(subject.name) }
            }
        }
    }
}

@Composable
private fun SubjectGlyph(name: String, modifier: Modifier = Modifier) {
    val accent = when (name) {
        "Strength of Materials" -> Color(0xFFFF8A32)
        "Fluid Mechanics" -> Color(0xFF4DA6FF)
        "Surveying" -> Color(0xFF57D68D)
        "Soil Mechanics" -> Color(0xFFFFB84D)
        "RCC Design" -> Color(0xFFB58CFF)
        "Highway Engineering" -> Color(0xFFFF8A32)
        "Engineering Mechanics" -> Color(0xFFB58CFF)
        "Building Materials" -> Color(0xFFFFB84D)
        "Building Construction" -> Color(0xFF57D68D)
        "Concrete Technology" -> Color(0xFF9AA7FF)
        "Railways" -> Color(0xFF4DA6FF)
        "Bridges & Tunnels" -> Color(0xFFB58CFF)
        else -> Purple2
    }
    androidx.compose.foundation.Canvas(modifier.size(44.dp)) {
        val w = 3.2f
        val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val cx = center.x
        val cy = center.y
        // Style 8: bold, instantly recognisable engineering glyphs inside a common visual family.
        when (name) {
            "Strength of Materials" -> {
                drawLine(accent, Offset(cx - 14f, cy - 10f), Offset(cx + 14f, cy - 10f), w)
                drawLine(accent, Offset(cx, cy - 10f), Offset(cx, cy + 13f), w)
                drawLine(accent, Offset(cx - 12f, cy + 13f), Offset(cx + 12f, cy + 13f), w)
                drawCircle(accent, 4f, Offset(cx, cy + 13f), style = stroke)
            }
            "Fluid Mechanics" -> {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(cx, cy - 17f)
                    cubicTo(cx - 11f, cy - 4f, cx - 11f, cy + 7f, cx, cy + 15f)
                    cubicTo(cx + 11f, cy + 7f, cx + 11f, cy - 4f, cx, cy - 17f)
                }
                drawPath(path, accent, style = stroke)
                drawArc(accent, 205f, 130f, false, Offset(cx - 7f, cy - 1f), androidx.compose.ui.geometry.Size(14f, 10f), style = stroke)
            }
            "Surveying" -> {
                drawCircle(accent, 15f, Offset(cx, cy), style = stroke)
                val pth = androidx.compose.ui.graphics.Path().apply {
                    moveTo(cx, cy - 12f); lineTo(cx + 10f, cy + 10f); lineTo(cx - 10f, cy + 10f); close()
                }
                drawPath(pth, accent, style = stroke)
                drawCircle(accent, 3f, Offset(cx, cy))
            }
            "Soil Mechanics" -> {
                drawLine(accent, Offset(cx - 15f, cy - 10f), Offset(cx + 15f, cy - 10f), w)
                drawLine(accent, Offset(cx - 11f, cy - 2f), Offset(cx + 11f, cy - 2f), w)
                drawLine(accent, Offset(cx - 8f, cy + 6f), Offset(cx + 8f, cy + 6f), w)
                drawLine(accent, Offset(cx - 5f, cy + 14f), Offset(cx + 5f, cy + 14f), w)
            }
            "RCC Design" -> {
                drawRect(accent, Offset(cx - 14f, cy - 14f), androidx.compose.ui.geometry.Size(28f, 28f), style = stroke)
                drawLine(accent, Offset(cx - 14f, cy - 3f), Offset(cx + 14f, cy - 3f), w)
                drawLine(accent, Offset(cx - 4f, cy - 14f), Offset(cx - 4f, cy + 14f), w)
                drawLine(accent, Offset(cx + 6f, cy - 14f), Offset(cx + 6f, cy + 14f), w)
            }
            "Highway Engineering" -> {
                drawLine(accent, Offset(cx - 14f, cy + 16f), Offset(cx - 5f, cy - 16f), w)
                drawLine(accent, Offset(cx + 14f, cy + 16f), Offset(cx + 5f, cy - 16f), w)
                drawLine(accent, Offset(cx, cy + 13f), Offset(cx, cy + 5f), w)
                drawLine(accent, Offset(cx, cy - 1f), Offset(cx, cy - 9f), w)
                drawLine(accent, Offset(cx, cy - 15f), Offset(cx, cy - 16f), w)
            }
            "Engineering Mechanics" -> {
                drawCircle(accent, 11f, Offset(cx, cy), style = stroke)
                drawLine(accent, Offset(cx - 18f, cy), Offset(cx + 18f, cy), w)
                drawLine(accent, Offset(cx, cy - 18f), Offset(cx, cy + 18f), w)
                drawCircle(accent, 4f, Offset(cx, cy))
            }
            "Building Materials" -> {
                drawRoundRect(accent, Offset(cx - 15f, cy - 12f), androidx.compose.ui.geometry.Size(13f, 10f), androidx.compose.ui.geometry.CornerRadius(2f,2f), style = stroke)
                drawRoundRect(accent, Offset(cx + 2f, cy - 12f), androidx.compose.ui.geometry.Size(13f, 10f), androidx.compose.ui.geometry.CornerRadius(2f,2f), style = stroke)
                drawRoundRect(accent, Offset(cx - 15f, cy + 2f), androidx.compose.ui.geometry.Size(13f, 10f), androidx.compose.ui.geometry.CornerRadius(2f,2f), style = stroke)
                drawRoundRect(accent, Offset(cx + 2f, cy + 2f), androidx.compose.ui.geometry.Size(13f, 10f), androidx.compose.ui.geometry.CornerRadius(2f,2f), style = stroke)
            }
            "Building Construction" -> {
                drawLine(accent, Offset(cx - 16f, cy + 14f), Offset(cx + 16f, cy + 14f), w)
                drawLine(accent, Offset(cx - 12f, cy + 14f), Offset(cx - 12f, cy - 8f), w)
                drawLine(accent, Offset(cx + 12f, cy + 14f), Offset(cx + 12f, cy - 8f), w)
                drawLine(accent, Offset(cx - 14f, cy - 8f), Offset(cx, cy - 18f), w)
                drawLine(accent, Offset(cx, cy - 18f), Offset(cx + 14f, cy - 8f), w)
                drawLine(accent, Offset(cx - 5f, cy - 12f), Offset(cx - 5f, cy + 14f), w)
                drawLine(accent, Offset(cx + 5f, cy - 12f), Offset(cx + 5f, cy + 14f), w)
            }
            "Concrete Technology" -> {
                drawRoundRect(accent, Offset(cx - 15f, cy - 15f), androidx.compose.ui.geometry.Size(30f, 30f), androidx.compose.ui.geometry.CornerRadius(5f,5f), style = stroke)
                drawCircle(accent, 4f, Offset(cx - 6f, cy - 5f), style = stroke)
                drawCircle(accent, 4f, Offset(cx + 7f, cy + 7f), style = stroke)
                drawLine(accent, Offset(cx - 13f, cy + 5f), Offset(cx + 12f, cy - 7f), w)
            }
            "Railways" -> {
                drawLine(accent, Offset(cx - 11f, cy - 17f), Offset(cx - 11f, cy + 17f), w)
                drawLine(accent, Offset(cx + 11f, cy - 17f), Offset(cx + 11f, cy + 17f), w)
                listOf(-11f, -4f, 4f, 11f).forEach { y -> drawLine(accent, Offset(cx - 15f, cy + y), Offset(cx + 15f, cy + y), w) }
            }
            "Bridges & Tunnels" -> {
                drawLine(accent, Offset(cx - 17f, cy + 12f), Offset(cx + 17f, cy + 12f), w)
                val bridge = androidx.compose.ui.graphics.Path().apply { moveTo(cx - 14f, cy + 12f); quadraticTo(cx, cy - 13f, cx + 14f, cy + 12f) }
                drawPath(bridge, accent, style = stroke)
                drawLine(accent, Offset(cx - 8f, cy + 5f), Offset(cx - 8f, cy + 12f), w)
                drawLine(accent, Offset(cx + 8f, cy + 5f), Offset(cx + 8f, cy + 12f), w)
            }
            else -> drawCircle(accent, 14f, Offset(cx, cy), style = stroke)
        }
    }
}

@Composable
private fun SubjectMaterialCard(name: String, chapterCount: Int, progress: Int, onClick: () -> Unit) {
    val accent = when (name) {
        "Strength of Materials" -> Orange
        "Fluid Mechanics" -> Color(0xFF4DA6FF)
        "Surveying" -> Color(0xFF57D68D)
        "Soil Mechanics" -> Color(0xFFFFB84D)
        "RCC Design" -> Color(0xFFB58CFF)
        "Highway Engineering" -> Orange
        else -> Purple2
    }
    Card(
        Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.78f)),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.34f))
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(78.dp)
                    .background(accent.copy(alpha = 0.10f), RoundedCornerShape(22.dp))
                    .border(1.dp, accent.copy(alpha = 0.32f), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                SubjectGlyph(name)
            }
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text("$chapterCount Chapters  •  Notes  •  Formulas", color = Muted, fontSize = 12.sp)
                Text("Practice  •  PYQs", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { progress / 100f }, Modifier.fillMaxWidth().height(6.dp), color = accent, trackColor = Surface2)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$progress%", color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(6.dp))
                    Text("complete", color = Muted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.ChevronRight, contentDescription = "Open $name", tint = White.copy(alpha = 0.72f), modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun Chapters(subject: String, onBack: () -> Unit, onChapter: (String) -> Unit) {
    val data = CivilNexaContentRepository.subject(subject)
    val avg = data?.chapters?.map { it.progress }?.average()?.takeIf { !it.isNaN() }?.toInt() ?: 0
    Column(Modifier.fillMaxSize()) {
        Top(subject, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                CardBox("Overall Progress", "$avg% • Chapter progress tracked automatically", Icons.Default.Insights)
                Section("Chapters")
            }
            itemsIndexed(data?.chapters ?: emptyList()) { index, ch ->
                val status = when { ch.progress >= 100 -> "Completed"; ch.progress > 0 -> "In Progress"; else -> "Not Started" }
                val tint = when { ch.progress >= 100 -> Green; ch.progress > 0 -> Orange; else -> Muted }
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onChapter(ch.name) },
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).background(Purple.copy(alpha = 0.12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Text(String.format("%02d", index + 1), color = Purple2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(ch.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("${ch.topics.size} topics • ${ch.progress}% complete", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(progress = { ch.progress / 100f }, Modifier.fillMaxWidth().height(4.dp), color = tint, trackColor = Surface2)
                            Text(status, color = tint, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterContents(subject: String, chapter: String, onBack: () -> Unit, onTopic: (String) -> Unit, onTest: () -> Unit) {
    val data = CivilNexaContentRepository.chapter(subject, chapter)
    Column(Modifier.fillMaxSize()) {
        Top(chapter, onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text(subject, color = Purple2, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                CardBox("Chapter Progress", "${data?.topics?.size ?: 0} topics • ${data?.progress ?: 0}% complete", Icons.Default.Insights)
                Section("Topics")
            }
            itemsIndexed(data?.topics ?: emptyList()) { index, topic ->
                val status = if (topic.completed) "Completed" else if (index == 0) "In Progress" else "Not Started"
                val tint = if (topic.completed) Green else if (index == 0) Purple2 else Muted
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onTopic(topic.name) },
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Purple.copy(alpha = 0.12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Text(String.format("%02d", index + 1), color = Purple2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(topic.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Notes • Formulas • Concepts • Diagrams • Practice • PYQs", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(status, color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
            item {
                Section("Chapter Actions")
                CardBox("Chapter Test", "Timed test • review • auto-evaluation", Icons.Default.Timer, onTest)
                CardBox("Previous Year Questions", "Mapped by exam • year • chapter • topic", Icons.Default.History)
            }
        }
    }
}

@Composable
private fun TopicDetail(
    subject: String,
    chapter: String,
    topic: String,
    onBack: () -> Unit,
    onTopicNavigate: (String) -> Unit
) {
    val chapterData = CivilNexaContentRepository.chapter(subject, chapter)
    val data = CivilNexaContentRepository.topic(subject, chapter, topic)
    val topics = chapterData?.topics ?: emptyList()
    val topicIndex = topics.indexOfFirst { it.name == topic }.coerceAtLeast(0)
    var tab by remember(topic) { mutableIntStateOf(0) }
    var bookmarked by remember(topic) { mutableStateOf(false) }
    var notePage by remember(topic) { mutableIntStateOf(1) }
    val labels = listOf("Notes", "Formulas", "Concepts", "Diagrams", "Practice", "PYQs")
    val moduleIcons = listOf(
        Icons.Default.Description, Icons.Default.Functions, Icons.Default.Lightbulb,
        Icons.Default.AccountTree, Icons.Default.Quiz, Icons.Default.History
    )
    val previousTopic = topics.getOrNull(topicIndex - 1)?.name
    val nextTopic = topics.getOrNull(topicIndex + 1)?.name

    Column(Modifier.fillMaxSize()) {
        Top(topic, onBack, action = {
            IconButton(onClick = { bookmarked = !bookmarked }) {
                Icon(
                    if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    "Bookmark topic",
                    tint = if (bookmarked) Orange else White
                )
            }
        })

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
            item {
                Text(subject, color = Purple2, fontSize = 12.sp)
                Text(chapter, color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))

                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp)
                                    .background(Purple.copy(alpha = 0.14f), RoundedCornerShape(15.dp))
                                    .border(1.dp, GlassBorder, RoundedCornerShape(15.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MenuBook, null, tint = Purple2, modifier = Modifier.size(26.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Topic Learning", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("6 learning modules • distraction-free study", color = Muted, fontSize = 11.sp)
                            }
                            Text("${topicIndex + 1}/${topics.size.coerceAtLeast(1)}", color = Purple2, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { if (data?.completed == true) 1f else 0.25f },
                            Modifier.fillMaxWidth().height(5.dp),
                            color = Purple, trackColor = Surface2
                        )
                        Text(if (data?.completed == true) "Completed" else "In Progress", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    labels.forEachIndexed { i, label ->
                        FilterChip(
                            selected = tab == i,
                            onClick = { tab = i },
                            label = { Text(label, fontSize = 11.sp) },
                            leadingIcon = { Icon(moduleIcons[i], null, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            item {
                when (tab) {
                    0 -> {
                        Section("Handwritten Notes")
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Surface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Description, null, tint = Purple2)
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Page $notePage of 3", color = White, fontWeight = FontWeight.Bold)
                                        Text("Read-only • Zoom • Bookmark • No Download", color = Muted, fontSize = 10.sp)
                                    }
                                    IconButton(onClick = { notePage = (notePage - 1).coerceAtLeast(1) }, enabled = notePage > 1) {
                                        Icon(Icons.Default.ChevronLeft, "Previous page", tint = if (notePage > 1) White else Muted)
                                    }
                                    IconButton(onClick = { notePage = (notePage + 1).coerceAtMost(3) }, enabled = notePage < 3) {
                                        Icon(Icons.Default.ChevronRight, "Next page", tint = if (notePage < 3) White else Muted)
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                Box(
                                    Modifier.fillMaxWidth().height(300.dp)
                                        .background(Color(0xFFEEEAF8), RoundedCornerShape(14.dp))
                                        .border(1.dp, GlassBorder, RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(22.dp)) {
                                        Icon(Icons.Default.EditNote, null, tint = Color(0xFF4B3D70), modifier = Modifier.size(44.dp))
                                        Spacer(Modifier.height(12.dp))
                                        Text("Handwritten Note • $topic", color = Color(0xFF211B38), fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(10.dp))
                                        Text(data?.notes ?: "Notes coming soon.", color = Color(0xFF3E3658), fontSize = 14.sp, lineHeight = 21.sp)
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                LinearProgressIndicator(
                                    progress = { notePage.toFloat() / 3f },
                                    Modifier.fillMaxWidth(), color = Purple, trackColor = Surface2
                                )
                            }
                        }
                    }
                    1 -> {
                        Section("Formula Library")
                        ContentCard("Formula", data?.formula ?: "Formula not available.")
                        Spacer(Modifier.height(10.dp))
                        CardBox("Symbols & Units", "Meaning • symbols • units • sign convention • application", Icons.Default.Straighten)
                        CardBox("Worked Example", "Given → Formula → Substitution → Final answer", Icons.Default.Calculate)
                    }
                    2 -> {
                        Section("Important Concepts")
                        ContentCard("Core Concept", data?.concept ?: "Concept not available.")
                        Spacer(Modifier.height(10.dp))
                        CardBox("Key Points", "Definition • assumptions • units • sign convention • application", Icons.Default.Lightbulb)
                    }
                    3 -> {
                        Section("Engineering Diagrams")
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Surface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, GlassBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Diagram / Figure", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Spacer(Modifier.height(12.dp))
                                Box(
                                    Modifier.fillMaxWidth().height(220.dp)
                                        .background(Bg, RoundedCornerShape(16.dp))
                                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.AccountTree, null, tint = Purple2, modifier = Modifier.size(56.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text("Topic diagram area", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Labeled engineering figure", color = Muted, fontSize = 11.sp)
                                    }
                                }
                                data?.let {
                                    if (it.diagrams.isNotEmpty()) {
                                        Spacer(Modifier.height(10.dp))
                                        it.diagrams.forEach { description ->
                                            Text("• $description", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    4 -> {
                        Section("Practice Questions")
                        CardBox("Topic Practice", "MCQ • Numerical • Theory • Easy / Medium / Hard", Icons.Default.Quiz)
                        data?.practice?.forEachIndexed { i, q ->
                            CardBox("Q.${i + 1}", q, Icons.Default.Quiz)
                        }
                    }
                    5 -> {
                        Section("Previous Year Questions")
                        data?.pyq?.forEach { q ->
                            CardBox(q, "Exam → Year → Subject → Chapter → Topic", Icons.Default.History)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { previousTopic?.let(onTopicNavigate) }, enabled = previousTopic != null) {
                        Icon(Icons.Default.ArrowBack, "Previous topic", tint = if (previousTopic != null) White else Muted)
                    }
                    IconButton(onClick = { bookmarked = !bookmarked }) {
                        Icon(if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = if (bookmarked) Orange else White)
                    }
                    IconButton(onClick = { nextTopic?.let(onTopicNavigate) }, enabled = nextTopic != null) {
                        Icon(Icons.Default.ArrowForward, "Next topic", tint = if (nextTopic != null) White else Muted)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ContentCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Text(body, color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
        }
    }
}

@Composable
private fun Tests(onBack: () -> Unit, onStart: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val hasResume = remember { hasSavedTest(context) }
    val tests = listOf("Chapter Test • Strength of Materials", "Topic Test • SFD & BMD", "PYQ Test • Civil Engineering", "Full Mock Test • SSC JE", "Full Mock Test • RRB JE", "Custom Mock Test")
    val filtered = tests.filter { it.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Top("Test Series", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                SearchField("Search tests...", query) { query = it }
                Spacer(Modifier.height(8.dp))
                if (hasResume) {
                    CardBox("Resume Full Mock Test 01", "Saved answers • remaining time • marked questions restored", Icons.Default.PlayArrow, onStart)
                }
            }
            items(filtered) { test -> CardBox(test, "10 Questions • 40 Marks • 10 min • −0.25 marking", if (test.contains("Mock", true)) Icons.Default.Star else Icons.Default.Quiz, onStart) }
        }
    }
}

@Composable
private fun Pyq(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val papers = listOf("SSC JE Civil • 2024", "SSC JE Civil • 2023", "SSC JE Civil • 2022", "RRB JE Civil • Previous Papers", "UPSSSC JE Civil • Previous Papers")
    Column(Modifier.fillMaxSize()) {
        Top("PYQ Center", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item { SearchField("Search year, exam, subject...", query) { query = it }; Spacer(Modifier.height(8.dp)) }
            items(papers.filter { it.contains(query, true) }) { paper -> CardBox(paper, "Exam → Year → Subject → Chapter → Topic", Icons.Default.Description) }
        }
    }
}

@Composable
private fun Progress(onBack: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val prefs = remember(refresh) { context.getSharedPreferences(HISTORY_PREFS, Context.MODE_PRIVATE) }
    val attempts = prefs.getInt("attempts", 0)
    val correct = prefs.getInt("correct", 0)
    val wrong = prefs.getInt("wrong", 0)
    val skipped = prefs.getInt("skipped", 0)
    val answered = correct + wrong
    val accuracy = if (answered == 0) 0 else correct * 100 / answered
    val totalQuestions = correct + wrong + skipped
    val avgScore = if (attempts == 0) 0 else (prefs.getFloat("last_marks", 0f) * 100f / prefs.getInt("last_total", 1).coerceAtLeast(1)).toInt()
    val studyProgress = CivilNexaContentRepository.subjects.flatMap { it.chapters }.map { it.progress }.average().toInt()
    val weak = if (accuracy < 70) "Accuracy needs improvement" else "Keep strengthening your weakest topics"

    Column(Modifier.fillMaxSize()) {
        Top("Progress", onBack, action = {
            IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, "Refresh", tint = Purple2) }
        })
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Overall Content Progress", "$studyProgress% • Based on chapter content", Icons.Default.Insights)
                CardBox("Tests Attempted", "$attempts • Live test history", Icons.Default.Quiz)
                CardBox("Questions Solved", "$answered • $correct correct • $wrong wrong", Icons.Default.CheckCircle)
                CardBox("Accuracy", "$accuracy% • ${if (totalQuestions == 0) "No tests yet" else "$answered/$totalQuestions attempted"}", Icons.Default.BarChart)
                CardBox("Latest Score", "$avgScore% • Calculated from latest submitted test", Icons.Default.EmojiEvents)
                Section("Subject Performance")
                CivilNexaContentRepository.subjects.forEach { subject ->
                    val progress = subject.chapters.map { it.progress }.average().toInt()
                    CardBox(subject.name, "$progress% content progress • ${subject.chapters.size} chapters", Icons.Default.MenuBook)
                }
                Section("Weak Areas")
                CardBox("Performance Focus", weak, Icons.Default.Warning)
                Section("Study Time")
                val totalMinutes = prefs.getLong("time", 0L) / 60
                CardBox("Test Time Recorded", "${totalMinutes / 60}h ${totalMinutes % 60}m across submitted tests", Icons.Default.Schedule)
            }
        }
    }
}

@Composable
private fun Profile(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Profile", onBack)
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                CardBox("Kumar", "Civil Engineering Aspirant • CivilNexa Learner", Icons.Default.Person)
                Section("Account")
                listOf("Edit Profile", "Change Password", "Linked Email & Mobile", "Bookmarks", "Test History").forEach { CardBox(it, "Open", Icons.Default.ChevronRight) }
                Section("Preferences")
                CardBox("Language", "English • Default", Icons.Default.Language)
                CardBox("Notification Settings", "Manage alerts", Icons.Default.Notifications)
                CardBox("Clear Cache", "Manage local storage", Icons.Default.Delete)
                CardBox("Sync Data", "Cloud sync when connected", Icons.Default.CloudSync)
            }
        }
    }
}

private const val TEST_PREFS = "civilnexa_test_state"
private const val TEST_ID = "mock_01"
private const val HISTORY_PREFS = "civilnexa_test_history"

private data class SavedTestState(
    val current: Int = 0,
    val remaining: Int = 180,
    val answers: Map<Int, Int> = emptyMap(),
    val marked: Set<Int> = emptySet()
)

private fun loadSavedTest(context: Context): SavedTestState {
    val prefs = context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE)
    if (!prefs.getBoolean("has_$TEST_ID", false)) return SavedTestState()
    val answers = prefs.getString("answers_$TEST_ID", "")!!.split(',')
        .filter { it.contains(":") }
        .mapNotNull { pair ->
            val parts = pair.split(":")
            if (parts.size == 2) parts[0].toIntOrNull()?.let { q -> parts[1].toIntOrNull()?.let { a -> q to a } } else null
        }.toMap()
    val marked = prefs.getString("marked_$TEST_ID", "")!!.split(',')
        .mapNotNull { it.toIntOrNull() }.toSet()
    return SavedTestState(
        current = prefs.getInt("current_$TEST_ID", 0).coerceIn(0, demoQuestions.lastIndex),
        remaining = prefs.getInt("remaining_$TEST_ID", 180).coerceIn(0, 180),
        answers = answers,
        marked = marked
    )
}

private fun saveTestState(context: Context, state: SavedTestState) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean("has_$TEST_ID", true)
        .putInt("current_$TEST_ID", state.current)
        .putInt("remaining_$TEST_ID", state.remaining)
        .putString("answers_$TEST_ID", state.answers.entries.joinToString(",") { "${it.key}:${it.value}" })
        .putString("marked_$TEST_ID", state.marked.joinToString(","))
        .apply()
}

private fun clearSavedTest(context: Context) {
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).edit()
        .remove("has_$TEST_ID")
        .remove("current_$TEST_ID")
        .remove("remaining_$TEST_ID")
        .remove("answers_$TEST_ID")
        .remove("marked_$TEST_ID")
        .apply()
}

private fun hasSavedTest(context: Context): Boolean =
    context.getSharedPreferences(TEST_PREFS, Context.MODE_PRIVATE).getBoolean("has_$TEST_ID", false)

private fun recordTestResult(context: Context, result: TestResult) {
    val prefs = context.getSharedPreferences(HISTORY_PREFS, Context.MODE_PRIVATE)
    val attempts = prefs.getInt("attempts", 0) + 1
    val totalCorrect = prefs.getInt("correct", 0) + result.correct
    val totalWrong = prefs.getInt("wrong", 0) + result.wrong
    val totalSkipped = prefs.getInt("skipped", 0) + result.skipped
    val totalTime = prefs.getLong("time", 0L) + result.timeTakenSeconds
    prefs.edit()
        .putInt("attempts", attempts)
        .putInt("correct", totalCorrect)
        .putInt("wrong", totalWrong)
        .putInt("skipped", totalSkipped)
        .putLong("time", totalTime)
        .putFloat("last_marks", result.marks.toFloat())
        .putInt("last_total", result.totalMarks)
        .apply()
}

@Composable
private fun LiveTest(onExit: () -> Unit, onSubmit: (TestResult) -> Unit) {
    val context = LocalContext.current
    val totalSeconds = 3 * 60
    val saved = remember { loadSavedTest(context) }
    var current by remember { mutableIntStateOf(saved.current) }
    var remaining by remember { mutableIntStateOf(saved.remaining) }
    var showPalette by remember { mutableStateOf(false) }
    var showCalculator by remember { mutableStateOf(false) }
    var showSubmitConfirm by remember { mutableStateOf(false) }
    var answers by remember { mutableStateOf(saved.answers) }
    var marked by remember { mutableStateOf(saved.marked) }
    var submitted by remember { mutableStateOf(false) }

    fun buildResult(): TestResult {
        val correct = answers.count { (q, a) -> demoQuestions[q].answer == a }
        val wrong = answers.size - correct
        val skipped = demoQuestions.size - answers.size
        return TestResult(correct, wrong, skipped, totalSeconds - remaining, totalSeconds)
    }

    fun submit() {
        if (!submitted) {
            submitted = true
            val finalResult = buildResult()
            recordTestResult(context, finalResult)
            clearSavedTest(context)
            onSubmit(finalResult)
        }
    }

    LaunchedEffect(remaining, submitted) {
        if (!submitted && remaining > 0) {
            delay(1000)
            remaining--
        } else if (!submitted && remaining == 0) {
            submit()
        }
    }

    LaunchedEffect(current, remaining, answers, marked, submitted) {
        if (!submitted) {
            saveTestState(context, SavedTestState(current, remaining, answers, marked))
        }
    }

    val q = demoQuestions[current]
    val answeredCount = answers.size
    val paletteStatus = if (marked.contains(current)) "Marked for review" else if (answers.containsKey(current)) "Answered" else "Not answered"

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExit) { Icon(Icons.Default.Close, "Exit", tint = White) }
                Column(Modifier.weight(1f)) {
                    Text("Full Mock Test 01", color = White, fontWeight = FontWeight.Bold)
                    Text("SSC JE Civil", color = Purple2, fontSize = 11.sp)
                    Text("⏱ ${formatTime(remaining)}   •   Q ${current + 1}/${demoQuestions.size}", color = if (remaining <= 30) Red else Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { showPalette = true }) { Text("Questions", color = Purple2) }
            }
            LinearProgressIndicator(progress = { (current + 1f) / demoQuestions.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Purple)
            LazyColumn(Modifier.weight(1f).padding(16.dp)) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(onClick = {}, label = { Text("Q.${current + 1}") })
                        AssistChip(onClick = {}, label = { Text("MCQ") })
                        AssistChip(onClick = {}, label = { Text(q.difficulty) })
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("$answeredCount/${demoQuestions.size} answered   •   Negative marking: −${q.negativeMarks}", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    CardBox("Question", q.text, Icons.Default.Quiz)
                    q.options.forEachIndexed { index, option ->
                        OptionCard(option, selected = answers[current] == index) { answers = answers + (current to index) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { current = (current - 1).coerceAtLeast(0) },
                    enabled = current > 0
                ) {
                    Icon(Icons.Default.ChevronLeft, "Previous question", tint = if (current > 0) White else Muted, modifier = Modifier.size(30.dp))
                }
                IconButton(
                    onClick = {
                        marked = if (marked.contains(current)) marked - current else marked + current
                        saveTestState(context, SavedTestState(current, remaining, answers, marked))
                    }
                ) {
                    Icon(
                        if (marked.contains(current)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        "Save question",
                        tint = if (marked.contains(current)) Orange else White,
                        modifier = Modifier.size(27.dp)
                    )
                }
                IconButton(onClick = { showCalculator = true }) {
                    Icon(Icons.Default.Calculate, "Calculator", tint = Purple2, modifier = Modifier.size(28.dp))
                }
                IconButton(
                    onClick = { if (current < demoQuestions.lastIndex) current++ else showSubmitConfirm = true }
                ) {
                    Icon(
                        if (current == demoQuestions.lastIndex) Icons.Default.Done else Icons.Default.ChevronRight,
                        if (current == demoQuestions.lastIndex) "Submit test" else "Next question",
                        tint = Purple2,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
        if (showPalette) QuestionPalette(current, answers, marked, onClose = { showPalette = false }) { current = it; showPalette = false }
        if (showCalculator) CalculatorOverlay { showCalculator = false }
        if (showSubmitConfirm) SubmitConfirmation(
            answered = answers.size,
            marked = marked.size,
            total = demoQuestions.size,
            onCancel = { showSubmitConfirm = false },
            onSubmit = { showSubmitConfirm = false; submit() }
        )
    }
}

private fun formatTime(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)

@Composable
private fun QuestionPalette(current: Int, answers: Map<Int, Int>, marked: Set<Int>, onClose: () -> Unit, onQuestion: (Int) -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.BottomCenter) {
        Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Questions", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${answers.size}/${demoQuestions.size} answered", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("● Answered ${answers.size}", color = Green, fontSize = 11.sp)
                    Text("★ Marked ${marked.size}", color = Orange, fontSize = 11.sp)
                    Text("○ Not Answered ${demoQuestions.size - answers.size}", color = Muted, fontSize = 11.sp)
                    Text("● Current ${current + 1}", color = Purple, fontSize = 11.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    PaletteStat(answers.size.toString(), "Answered", Green)
                    PaletteStat(marked.size.toString(), "Marked", Orange)
                    PaletteStat((demoQuestions.size - answers.size).toString(), "Not Answered", Muted)
                    PaletteStat(demoQuestions.size.toString(), "Total", White)
                }
                Spacer(Modifier.height(12.dp))
                for (start in 0 until demoQuestions.size step 5) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in start until minOf(start + 5, demoQuestions.size)) {
                            val bg = when {
                                i == current -> Purple
                                marked.contains(i) -> Orange
                                answers.containsKey(i) -> Green
                                else -> Surface
                            }
                            Box(Modifier.size(48.dp).background(bg, RoundedCornerShape(12.dp)).clickable { onQuestion(i) }, contentAlignment = Alignment.Center) {
                                Text("${i + 1}", color = White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun SubmitConfirmation(answered: Int, marked: Int, total: Int, onCancel: () -> Unit, onSubmit: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.68f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(24.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Submit Test?", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Answered: $answered/$total\nMarked for review: $marked\nUnanswered: ${total - answered}", color = Muted)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(onClick = onSubmit, modifier = Modifier.weight(1f)) { Text("Submit Test") }
                }
            }
        }
    }
}

@Composable
private fun PaletteStat(value: String, label: String, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(min = 54.dp)) {
        Text(value, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun CalculatorOverlay(onClose: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "C", "+")
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(22.dp), colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Calculator", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = White) } }
                Box(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(14.dp)).padding(16.dp)) { Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) { Text(expression.ifEmpty { "0" }, color = Muted); Text(result.ifEmpty { "" }, color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.height(12.dp))
                keys.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            Button(onClick = { if (key == "C") { expression = ""; result = "" } else { expression += key; result = "" } }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (key == "C") Color(0xFF5A1C2A) else Surface)) { Text(key) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Button(onClick = { result = simpleCalculate(expression) }, modifier = Modifier.fillMaxWidth()) { Text("=") }
            }
        }
    }
}

private fun simpleCalculate(raw: String): String {
    return try {
        val expression = raw.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "")
        if (expression.isBlank()) return ""
        val parser = ExpressionParser(expression)
        val value = parser.parse()
        if (!value.isFinite()) "Error" else "%.4f".format(value).trimEnd('0').trimEnd('.')
    } catch (_: Exception) {
        "Error"
    }
}

private class ExpressionParser(private val input: String) {
    private var pos = 0

    fun parse(): Double {
        val value = parseExpression()
        if (pos != input.length) throw IllegalArgumentException("Unexpected input")
        return value
    }

    private fun parseExpression(): Double {
        var value = parseTerm()
        while (pos < input.length) {
            value = when (input[pos]) {
                '+' -> { pos++; value + parseTerm() }
                '-' -> { pos++; value - parseTerm() }
                else -> return value
            }
        }
        return value
    }

    private fun parseTerm(): Double {
        var value = parseFactor()
        while (pos < input.length) {
            value = when (input[pos]) {
                '*' -> { pos++; value * parseFactor() }
                '/' -> { pos++; val divisor = parseFactor(); if (divisor == 0.0) throw ArithmeticException(); value / divisor }
                else -> return value
            }
        }
        return value
    }

    private fun parseFactor(): Double {
        if (pos >= input.length) throw IllegalArgumentException("Missing number")
        if (input[pos] == '+') { pos++; return parseFactor() }
        if (input[pos] == '-') { pos++; return -parseFactor() }
        if (input[pos] == '(') {
            pos++
            val value = parseExpression()
            if (pos >= input.length || input[pos] != ')') throw IllegalArgumentException("Missing )")
            pos++
            return value
        }
        val start = pos
        var dots = 0
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
            if (input[pos] == '.') dots++
            if (dots > 1) throw IllegalArgumentException("Invalid number")
            pos++
        }
        if (start == pos) throw IllegalArgumentException("Number expected")
        return input.substring(start, pos).toDouble()
    }
}


@Composable
private fun Result(result: TestResult, onBack: () -> Unit, onBackToTests: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Top("Test Result", onBack)
        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${result.marks} / ${result.totalMarks} Marks", color = White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                        Text("${result.accuracy}% Accuracy", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${result.attempted}/${result.totalQuestions} Questions Attempted", color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Time: ${formatTime(result.timeTakenSeconds)}", color = Muted, fontSize = 12.sp)
                    }
                }
                CardBox("Correct", "${result.correct}", Icons.Default.CheckCircle)
                CardBox("Wrong", "${result.wrong} • Negative marking applied", Icons.Default.Cancel)
                CardBox("Skipped", "${result.skipped}", Icons.Default.RemoveCircleOutline)
                CardBox("Performance", "Result generated from actual answer selections", Icons.Default.BarChart)
                Button(onClick = onBackToTests, modifier = Modifier.fillMaxWidth()) { Text("Back to Tests") }
            }
        }
    }
}

@Composable
private fun SearchField(hint: String, value: String = "", onSearch: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onSearch,
        placeholder = { Text(hint, color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Purple2) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Surface.copy(alpha = 0.55f),
            focusedContainerColor = Surface.copy(alpha = 0.72f),
            unfocusedBorderColor = GlassBorder,
            focusedBorderColor = Purple
        )
    )
}

@Composable
private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier, click: () -> Unit) {
    Card(
        modifier.height(96.dp).clickable { click() },
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.86f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(tint.copy(alpha = 0.12f), RoundedCornerShape(15.dp)).border(1.dp, tint.copy(alpha = 0.28f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(27.dp)) }
            Spacer(Modifier.width(10.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun CardBox(title: String, subtitle: String = "", icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.AutoAwesome, click: (() -> Unit)? = null) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).then(if (click != null) Modifier.clickable { click() } else Modifier),
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.84f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Purple.copy(alpha = 0.14f), RoundedCornerShape(14.dp)).border(1.dp, GlassBorder, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Purple2, modifier = Modifier.size(23.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); if (subtitle.isNotEmpty()) Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 18.sp) }
            if (click != null) Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun Section(title: String) { Text(title, color = Purple2, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }

@Composable
private fun OptionCard(text: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (selected) Purple.copy(alpha = 0.18f) else Surface.copy(alpha = 0.78f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (selected) Purple else GlassBorder)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Purple2)); Text(text, color = White, fontSize = 15.sp) }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0D0922)) {
        val items = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Quiz, Icons.Default.Insights, Icons.Default.Person)
        val labels = listOf("Home", "Study", "Tests", "Progress", "Profile")
        items.forEachIndexed { i, icon -> NavigationBarItem(selected = i == selected, onClick = { onSelect(i) }, icon = { Icon(icon, null) }, label = { Text(labels[i]) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple2, selectedTextColor = Purple2, indicatorColor = Purple.copy(alpha = 0.16f), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
    }
}
