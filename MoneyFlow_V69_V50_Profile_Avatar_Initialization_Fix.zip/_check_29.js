
(function(){
  'use strict';
  if(window.__mfV45CalculatorReady)return;
  window.__mfV45CalculatorReady=true;
  var state={display:'0',first:null,operator:null,waiting:false,lastWasEquals:false,expression:''};
  function el(id){return document.getElementById(id);}
  function render(){
    var d=el('mfCalcDisplay'),x=el('mfCalcExpression');
    if(d)d.textContent=state.display;
    if(x)x.textContent=state.expression||'';
  }
  function reset(){state={display:'0',first:null,operator:null,waiting:false,lastWasEquals:false,expression:''};render();}
  function format(n){
    if(!Number.isFinite(n))return 'Error';
    var r=Number(n.toPrecision(12));
    var out=String(r);
    if(out.length>16)out=r.toExponential(10).replace(/(\.0+|(?<=[0-9])0+)e/,'e');
    return out;
  }
  function calculate(a,b,op){
    a=Number(a);b=Number(b);
    if(!Number.isFinite(a)||!Number.isFinite(b))return null;
    if(op==='+')return a+b;
    if(op==='−')return a-b;
    if(op==='×')return a*b;
    if(op==='÷')return b===0?null:a/b;
    return b;
  }
  function inputDigit(d){
    if(state.display==='Error')reset();
    if(state.waiting||state.lastWasEquals){
      state.display=d==='.'?'0.':d;
      state.waiting=false;state.lastWasEquals=false;
      if(state.first!==null&&state.operator)state.expression=format(state.first)+' '+state.operator+' '+state.display;
      else if(!state.operator)state.expression='';
      render();return;
    }
    if(d==='.'&&state.display.indexOf('.')!==-1)return;
    if(state.display==='0'&&d!=='.')state.display=d;
    else if(state.display.length<16)state.display+=d;
    if(state.first!==null&&state.operator)state.expression=format(state.first)+' '+state.operator+' '+state.display;
    render();
  }
  function chooseOperator(op){
    if(state.display==='Error'){reset();return;}
    if(state.operator&&state.waiting){state.operator=op;state.expression=format(state.first)+' '+op;render();return;}
    if(state.first!==null&&state.operator&&!state.waiting){
      var r=calculate(state.first,state.display,state.operator);
      if(r===null){state.display='Error';state.first=null;state.operator=null;state.waiting=true;state.expression='';render();return;}
      state.display=format(r);state.first=Number(state.display);
    }else if(state.first===null){state.first=Number(state.display);}
    state.operator=op;state.waiting=true;state.lastWasEquals=false;
    state.expression=format(state.first)+' '+op;
    render();
  }
  function equals(){
    if(state.display==='Error'||state.operator===null||state.first===null)return;
    var a=format(state.first),op=state.operator,b=state.display;
    var r=calculate(state.first,state.display,state.operator);
    state.expression=a+' '+op+' '+b;
    state.display=r===null?'Error':format(r);
    state.first=null;state.operator=null;state.waiting=true;state.lastWasEquals=true;render();
  }
  function percent(){
    if(state.display==='Error')return;
    var n=Number(state.display);if(Number.isFinite(n)){
      state.display=format(n/100);
      if(state.first!==null&&state.operator)state.expression=format(state.first)+' '+state.operator+' '+state.display;
      render();
    }
  }
  function sign(){
    if(state.display==='0'||state.display==='Error')return;
    state.display=state.display.charAt(0)==='-'?state.display.slice(1):'-'+state.display;
    if(state.first!==null&&state.operator)state.expression=format(state.first)+' '+state.operator+' '+state.display;
    render();
  }
  function backspace(){
    if(state.waiting||state.lastWasEquals||state.display==='Error')return;
    state.display=state.display.length>1?state.display.slice(0,-1):'0';
    if(state.display==='-'||state.display==='')state.display='0';
    if(state.first!==null&&state.operator)state.expression=format(state.first)+' '+state.operator+' '+state.display;
    render();
  }
  function open(){
    var m=el('pfCalculatorModal');if(!m)return false;
    reset();m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';return true;
  }
  function close(){
    var m=el('pfCalculatorModal');if(!m)return;
    m.classList.remove('open');m.setAttribute('aria-hidden','true');
    if(!document.querySelector('.pf-feature-modal.open'))document.body.style.overflow='';
  }
  window.mfResetCalculator=reset;window.mfOpenCalculatorDirect=open;window.pfOpenCalculator=open;window.mfCloseCalculator=close;
  var modal=el('pfCalculatorModal');
  if(modal&&!modal.__mfV45Bound){
    modal.__mfV45Bound=true;
    modal.addEventListener('click',function(e){
      if(e.target===modal){close();return;}
      var b=e.target.closest&&e.target.closest('[data-calc-digit],[data-calc-op],[data-calc-action]');if(!b)return;
      e.preventDefault();e.stopPropagation();
      if(b.hasAttribute('data-calc-digit'))inputDigit(b.getAttribute('data-calc-digit'));
      else if(b.hasAttribute('data-calc-op'))chooseOperator(b.getAttribute('data-calc-op'));
      else{var a=b.getAttribute('data-calc-action');if(a==='clear')reset();else if(a==='backspace')backspace();else if(a==='percent')percent();else if(a==='sign')sign();else if(a==='equals')equals();}
    },true);
  }
  document.addEventListener('keydown',function(e){
    var m=el('pfCalculatorModal');if(!m||!m.classList.contains('open'))return;
    if(/^[0-9.]$/.test(e.key)){e.preventDefault();inputDigit(e.key);return;}
    var ops={'+':'+','-':'−','*':'×','/':'÷'};
    if(ops[e.key]){e.preventDefault();chooseOperator(ops[e.key]);return;}
    if(e.key==='Enter'||e.key==='='){e.preventDefault();equals();return;}
    if(e.key==='Backspace'){e.preventDefault();backspace();return;}
    if(e.key==='%'){e.preventDefault();percent();return;}
    if(e.key==='Escape'){e.preventDefault();close();}
  });
})();
