# MoneyFlow V69 V49 — Unified Profile Avatar Renderer

Baseline: V48 Profile Photo / Mode / Active Fix.

## Scope
Only profile-avatar rendering consistency is changed.

## Fix
- Home profile photo, More profile photo, and Profile modal photo now use the same avatar image renderer class.
- Centralized display rule: width/height 100%, `object-fit: cover`, `object-position: 50% 50%`, no transform/margin/padding/border.
- Square avatar containers enforce a consistent aspect ratio and clipping.
- Original `profilePhoto` data is not modified or re-cropped during this fix.
- Profile photo isolation, cloud backup/restore, local PIN/security preservation, active-profile persistence, and other V48 functionality are untouched.

## Validation
- `all-scripts.js`: `node --check` PASS.
- Android `index.html`: all 37 inline JavaScript blocks PASS.
