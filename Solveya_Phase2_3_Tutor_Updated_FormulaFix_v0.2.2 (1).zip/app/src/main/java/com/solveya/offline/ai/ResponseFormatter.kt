package com.solveya.offline.ai

/**
 * Converts common Markdown/LaTeX emitted by the local model into clean,
 * phone-friendly plain text.  This intentionally stays dependency-free so
 * the offline app does not need a Markdown/LaTeX rendering library.
 */
object ResponseFormatter {
    fun clean(raw: String): String {
        var text = raw.trim()

        // Remove common response wrappers that are not useful to the student.
        text = text
            .removePrefix("```text")
            .removePrefix("```markdown")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        // Remove math delimiters. The actual math is converted below.
        text = text
            .replace("\\(", "")
            .replace("\\)", "")
            .replace("\\[", "")
            .replace("\\]", "")
            .replace("$$", "")
            .replace("\\$", "$")

        // Convert the most common LaTeX constructs produced by the local model.
        // Examples: \frac{10}{2} -> 10/2, \text{ N} -> N, \sigma -> σ.
        text = convertFractions(text)
        text = text.replace(Regex("\\\\(?:text|mathrm|mathbf|operatorname)\\s*\\{([^{}]*)\\}"), "$1")
        text = text.replace(Regex("\\\\(sqrt|sqrt\\s*)\\s*\\{([^{}]*)\\}")) { match ->
            "√(${match.groupValues[2]})"
        }

        // Common LaTeX commands -> Unicode/plain-text equivalents.
        val symbols = mapOf(
            "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\delta" to "δ",
            "\\epsilon" to "ε", "\\theta" to "θ", "\\lambda" to "λ", "\\mu" to "μ",
            "\\pi" to "π", "\\rho" to "ρ", "\\sigma" to "σ", "\\tau" to "τ",
            "\\phi" to "φ", "\\omega" to "ω", "\\Delta" to "Δ", "\\Gamma" to "Γ",
            "\\Theta" to "Θ", "\\Lambda" to "Λ", "\\Pi" to "Π", "\\Sigma" to "Σ",
            "\\Omega" to "Ω", "\\times" to "×", "\\cdot" to "·", "\\pm" to "±",
            "\\leq" to "≤", "\\geq" to "≥", "\\neq" to "≠", "\\approx" to "≈",
            "\\infty" to "∞", "\\degree" to "°", "\\rightarrow" to "→", "\\to" to "→",
            "\\therefore" to "∴", "\\propto" to "∝"
        )
        for ((latex, replacement) in symbols) {
            text = text.replace(latex, replacement)
        }

        // Clean leftover grouping braces and simple superscripts/subscripts.
        text = text.replace(Regex("\\{([^{}]*)\\}"), "$1")
        text = replaceSuperscripts(text)
        text = replaceSubscripts(text)

        // Normalize common Markdown emphasis while preserving readable headings.
        text = text.replace(Regex("\\*\\*(.*?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "$1")
        text = text.replace(Regex("__(.*?)__", RegexOption.DOT_MATCHES_ALL), "$1")
        text = text.replace(Regex("`([^`]+)`"), "$1")

        // Remove any remaining LaTeX spacing/control commands.
        text = text.replace(Regex("\\\\(?:,|;|:|!|quad|qquad)"), " ")
        text = text.replace(Regex("\\\\[a-zA-Z]+"), "")

        // Avoid excessive blank lines from model output.
        text = text.replace(Regex("[ \\t]+\\n"), "\\n")
        text = text.replace(Regex("\\n{3,}"), "\\n\\n").trim()

        return text.ifBlank { "Solveya could not generate an answer." }
    }

    private fun convertFractions(input: String): String {
        var text = input
        var start = text.indexOf("\\frac")

        while (start >= 0) {
            var cursor = start + "\\frac".length
            while (cursor < text.length && text[cursor].isWhitespace()) cursor++

            val numerator = readBracedGroup(text, cursor)
            if (numerator == null) {
                start = text.indexOf("\\frac", start + 5)
                continue
            }
            cursor = numerator.second
            while (cursor < text.length && text[cursor].isWhitespace()) cursor++

            val denominator = readBracedGroup(text, cursor)
            if (denominator == null) {
                start = text.indexOf("\\frac", start + 5)
                continue
            }

            val replacement = "${numerator.first}/${denominator.first}"
            text = text.substring(0, start) + replacement + text.substring(denominator.second)
            start = text.indexOf("\\frac", start + replacement.length)
        }
        return text
    }

    /** Returns content and the index immediately after the closing brace. */
    private fun readBracedGroup(text: String, openIndex: Int): Pair<String, Int>? {
        if (openIndex >= text.length || text[openIndex] != '{') return null

        var depth = 0
        for (index in openIndex until text.length) {
            when (text[index]) {
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) {
                        return text.substring(openIndex + 1, index) to (index + 1)
                    }
                }
            }
        }
        return null
    }

    private fun replaceSuperscripts(input: String): String {
        val superscript = mapOf(
            '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴',
            '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹',
            '+' to '⁺', '-' to '⁻', 'n' to 'ⁿ', 'x' to 'ˣ'
        )
        return Regex("\\^([0-9]+|[a-zA-Z])").replace(input) { match ->
            match.groupValues[1].map { superscript[it] ?: it }.joinToString("")
        }
    }

    private fun replaceSubscripts(input: String): String {
        val subscript = mapOf(
            '0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄',
            '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉',
            '+' to '₊', '-' to '₋', 'a' to 'ₐ', 'e' to 'ₑ', 'h' to 'ₕ',
            'i' to 'ᵢ', 'j' to 'ⱼ', 'k' to 'ₖ', 'l' to 'ₗ', 'm' to 'ₘ',
            'n' to 'ₙ', 'o' to 'ₒ', 'p' to 'ₚ', 'r' to 'ᵣ', 's' to 'ₛ',
            't' to 'ₜ', 'u' to 'ᵤ', 'v' to 'ᵥ', 'x' to 'ₓ'
        )
        return Regex("_([0-9]+|[a-zA-Z])").replace(input) { match ->
            match.groupValues[1].map { subscript[it] ?: it }.joinToString("")
        }
    }
}
