STEP 5A — PHONE/CLOUD APK BUILD

This project includes a GitHub Actions workflow that builds the APK in the cloud.
No PC, laptop, Android Studio, or local Android SDK is required.

Phone workflow:
1. Create/sign in to a GitHub account on the phone.
2. Create a new repository.
3. Upload this project's files/folders to the repository.
4. Open Actions -> Build Money Manager APK -> Run workflow.
5. Wait for the workflow to finish.
6. Open the completed run and download the artifact:
   Money-Manager-debug-apk
7. Extract the downloaded ZIP and install app-debug.apk on Android.

The workflow builds a DEBUG APK for personal phone installation.
No Play Store signing key is embedded.
