package com.solveya.offline.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LiteRtLmEngine(
    private val context: Context
) {
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    suspend fun initialize(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            LocalModelManager.ensureModelDirectory(context)

            val model = LocalModelManager.modelFile(context)
            require(model.exists() && model.length() > 0L) {
                "Offline model not installed. Add ${LocalModelManager.MODEL_FILE_NAME} to the app model directory first."
            }

            close()

            val config = EngineConfig(
                modelPath = model.absolutePath,
                backend = Backend.CPU(),
                cacheDir = context.cacheDir.absolutePath
            )

            val newEngine = Engine(config)
            newEngine.initialize()

            val newConversation = newEngine.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(
                        """
                        You are Solveya, an offline educational AI assistant.
                        Your primary scope is Class 8-10 Mathematics and Science.
                        Answer clearly and safely.
                        For mathematics, show step-by-step reasoning and do not invent calculations.
                        Match the user's requested language: Hindi, English, or Hinglish.
                        If the question is outside your reliable offline knowledge, say so rather than pretending.
                        """.trimIndent()
                    ),
                    samplerConfig = SamplerConfig(
                        topK = 64,
                        topP = 0.95,
                        temperature = 0.7
                    )
                )
            )

            engine = newEngine
            conversation = newConversation
        }
    }

    suspend fun ask(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val activeConversation = conversation
                ?: error("Offline AI is not initialized.")

            val response = activeConversation.sendMessage(prompt)
            response.text
        }
    }

    fun close() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
    }
}
