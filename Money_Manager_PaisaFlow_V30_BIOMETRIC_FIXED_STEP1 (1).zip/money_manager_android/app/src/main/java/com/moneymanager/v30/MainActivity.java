package com.moneymanager.v30;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import java.io.OutputStream;
import java.util.Base64;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler();
    private final Executor executor = command -> handler.post(command);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BioBridge(this), "AndroidBiometric");
        webView.addJavascriptInterface(new FileBridge(this), "AndroidFile");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class FileBridge {
        private final Context ctx; FileBridge(Context c){ctx=c;}
        @JavascriptInterface public void saveFile(String name, String mime, String b64){
            try{
                byte[] data=Base64.getDecoder().decode(b64);
                if(android.os.Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Manager");
                    Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null)throw new Exception("Could not create download file");
                    try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved to Downloads/Money Manager: "+name,android.widget.Toast.LENGTH_LONG).show());
                } else {
                    java.io.File dir=new java.io.File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Money Manager");
                    if(!dir.exists())dir.mkdirs();
                    java.io.File f=new java.io.File(dir,name);
                    try(java.io.FileOutputStream out=new java.io.FileOutputStream(f)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved: "+f.getAbsolutePath(),android.widget.Toast.LENGTH_LONG).show());
                }
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Export failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
    }

    public class BioBridge {
        private final Context ctx;
        BioBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean isAvailable(){
            if (android.os.Build.VERSION.SDK_INT < 28) return false;
            BiometricManager bm=(BiometricManager)ctx.getSystemService(Context.BIOMETRIC_SERVICE);
            if(bm==null)return false;
            int r=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return r==BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public void authenticate(final String callback){
            if(android.os.Build.VERSION.SDK_INT<28){send(callback,false);return;}
            if(!isAvailable()){send(callback,false);return;}
            BiometricPrompt prompt=new BiometricPrompt.Builder(MainActivity.this)
                .setTitle("PaisaFlow")
                .setSubtitle("Verify your identity")
                .setDescription("Use your registered fingerprint or biometric to continue.")
                .setNegativeButton("Use PIN", executor, (d,w)->send(callback,false))
                .build();
            CancellationSignal cs=new CancellationSignal();
            prompt.authenticate(cs, executor, new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){send(callback,true);}
                @Override public void onAuthenticationFailed(){ /* keep prompt open */ }
                @Override public void onAuthenticationError(int e, CharSequence msg){send(callback,false);}
            });
        }
        private void send(String cb, boolean ok){
            final String js="window."+cb+"("+(ok?"true":"false")+")";
            handler.post(()->webView.evaluateJavascript(js,null));
        }
    }
}
