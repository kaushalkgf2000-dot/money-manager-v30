# Google Drive Cloud Backup Migration

Baseline: PaisaFlow V44 RealtimeDB AutoSync working project.

Migration rule:
- Preserve the V44 app behavior and existing Firebase Authentication/Analytics.
- Permanently remove Firebase Realtime Database/Firestore backup and restore implementation.
- Replace only the cloud backup/restore provider with Google Drive appDataFolder.
- Use one account-scoped canonical Drive backup file per authenticated Firebase account.
- Keep local/manual backup and restore available.
- Legacy device-wide native recovery auto-restore is disabled so it cannot mix account data.
- Do not upload PIN, recovery code, or security credentials.
