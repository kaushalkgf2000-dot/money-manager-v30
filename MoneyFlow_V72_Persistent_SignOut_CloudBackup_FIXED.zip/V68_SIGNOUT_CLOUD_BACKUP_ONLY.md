# MoneyFlow V68 — Sign-out Cloud Backup Confirmation

Baseline: MoneyFlow V67 (Google-only authentication UI).

Requested change only:
- When the signed-in user taps Sign Out, show a confirmation asking whether to make a Cloud Backup first.
- On confirmation, open the existing Cloud Backup section.
- The user gets a dedicated `Backup & Sign Out` action.
- Sign-out occurs only after Google Drive reports a successful cloud backup.
- If backup fails or the backup section is closed, the user remains signed in.

No other application logic, features, authentication method, restore logic, automatic sync logic, profile logic, transaction logic, or UI outside this requested flow was intentionally changed.
