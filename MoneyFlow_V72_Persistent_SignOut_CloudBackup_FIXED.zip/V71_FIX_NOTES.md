# MoneyFlow V71 Fix

## Requested fix
Fix the regression where automatic cloud restore is already completed for the current authenticated session, but `cloudSyncSuppressed` remains true after the session marker causes `mfAutoSyncAfterAuth()` to return. This prevents later local edits from scheduling automatic Google Drive backup.

## Exact change
Only one existing condition in `app/src/main/assets/index.html` was changed:

- Before returning because the V66-style session marker is already set, explicitly set `cloudSyncSuppressed=false`.
- No new feature, UI, authentication flow, restore flow, transaction logic, or backup API was added.

This keeps the one-shot Auto-Restore protection while re-enabling the existing Auto-Backup path after startup.
