# MoneyFlow V72 — Persistent Sign-out Cloud Backup Fix

Base: MoneyFlow V71.

Only the existing sign-out-before-cloud-backup lifecycle was changed. The existing `pendingLogoutAfterBackup` intent is persisted in localStorage, restored after reload, and used to keep the existing Backup & Restore modal in `Backup & Sign Out` mode. The startup auto-restore path is bypassed while this sign-out intent is pending, preventing an older cloud snapshot from being restored before the protective backup completes. The automatic cloud-upload reload is also prevented from competing with the pending sign-out flow. The persisted flag is cleared on successful backup/sign-out, backup failure, cancellation, or completed logout.

No other project files were modified.
