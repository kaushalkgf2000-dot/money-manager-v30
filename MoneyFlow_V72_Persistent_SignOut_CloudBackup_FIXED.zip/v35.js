
/* V35 — SINGLE SOURCE EXPORT FIX
   Final override: read the exact date controls at click time and use the live
   transaction array rendered by the app. No profile/legacy merging is used.
*/
(function(){
  function text(v){return String(v==null?"":v).trim()}
  function dateKey(v){
    const s=text(v); if(!s)return "";
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if(m)return m[1]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[3]).padStart(2,"0");
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
    if(m)return m[3]+"-"+String(m[2]).padStart(2,"0")+"-"+String(m[1]).padStart(2,"0");
    return "";
  }
  function selectedRange(){
    const f=document.getElementById("pdfFrom"),t=document.getElementById("pdfTo");
    const from=dateKey(f&&f.value),to=dateKey(t&&t.value);
    if(!from&&!to)return {from:"",to:""};
    if(!from||!to){alert("Please select both From and To dates.");return null;}
    if(from>to){alert("From date cannot be after To date.");return null;}
    return {from,to};
  }
  function liveTransactions(){
    let a=[];
    try{if(typeof txs!=="undefined"&&Array.isArray(txs))a=txs.slice()}catch(e){}
    return a.map(function(x,i){
      return {id:x&&x.id!=null?x.id:i,date:dateKey(x&&x.date),type:text(x&&x.type).toUpperCase(),amount:Number(x&&x.amount)||0,
        balance:Number.isFinite(Number(x&&x.balance))?Number(x.balance):null,category:text(x&&x.category),description:text(x&&x.description||x&&x.desc),remark:text(x&&x.remark||x&&x.remarks||x&&x.note),mode:text(x&&x.mode||x&&x.paymentMode||x&&x.payment_mode),other:text(x&&x.other||x&&x.otherInfo||x&&x.other_info),createdAt:text(x&&x.createdAt)};
    }).filter(function(x){return x.date&&x.amount>0&&(x.type==="CREDIT"||x.type==="EXPENSE"||x.type==="DEBIT");})
      .sort(function(a,b){return a.date.localeCompare(b.date)||(a.createdAt.localeCompare(b.createdAt))||(Number(a.id)||0)-(Number(b.id)||0)});
  }
  function pack(){
    const r=selectedRange(); if(!r)return null;
    const all=liveTransactions();
    const data=all.filter(function(x){return (!r.from||x.date>=r.from)&&(!r.to||x.date<=r.to)});
    return {from:r.from,to:r.to,all:all,data:data};
  }
  function opening(all,from){
    if(!from)return 0;
    const before=all.filter(function(x){return x.date<from;});
    if(!before.length)return 0;
    const last=before[before.length-1];
    if(last.balance!==null)return last.balance;
    let b=0;before.forEach(function(x){b+=x.type==="CREDIT"?x.amount:-x.amount});return b;
  }
  function calc(p){
    let b=opening(p.all,p.from),w=0,d=0;
    const rows=p.data.map(function(t){
      if(t.type==="CREDIT"){d+=t.amount;b+=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,"",t.amount,b]}
      w+=t.amount;b-=t.amount;return [t.date,t.category,t.description,t.remark,t.mode,t.other,t.amount,"",b];
    });
    return {rows:rows,opening:opening(p.all,p.from),withdrawals:w,deposits:d,closing:b};
  }
  function xesc(s){return text(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;")}
  function xtext(v){return '<c t="inlineStr"><is><t>'+xesc(v)+'</t></is></c>'}
  function xnum(v){return '<c t="n"><v>'+String(Number(v)||0)+'</v></c>'}
  function makeXlsx(p){
    const c=calc(p),rows=[["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"]];
    c.rows.forEach(function(r){rows.push([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8]])});
    rows.push([]);rows.push(["ACCOUNT SUMMARY"]);rows.push(["OPENING BALANCE",c.opening,"TOTAL WITHDRAWALS",c.withdrawals,"TOTAL DEPOSITS",c.deposits,"CLOSING BALANCE",c.closing,"No. of Transactions",p.data.length]);rows.push([]);rows.push(["******************* END OF REPORT *******************"]);
    const xml=rows.map(function(row,ri){return '<row>'+row.map(function(v,i){const numeric=(ri>0&&ri<=p.data.length&&[6,7,8].indexOf(i)>=0)||(ri===p.data.length+2&&typeof v==="number");return numeric?xnum(v):xtext(v)}).join('')+'</row>'}).join('');
    const sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+xml+'</sheetData></worksheet>';
    const wb='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const rel='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const root='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const ct='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    return zipStore([{name:"[Content_Types].xml",data:ct},{name:"_rels/.rels",data:root},{name:"xl/workbook.xml",data:wb},{name:"xl/_rels/workbook.xml.rels",data:rel},{name:"xl/worksheets/sheet1.xml",data:sheet}]);
  }
  function makePdf(p){
    const c=calc(p),W=842,H=595,M=24,colW=[58,70,100,78,72,65,78,78,85],heads=["Date","Category","Description","Remark","Payment Mode","Other","Withdrawal (Rs.)","Deposit (Rs.)","Balance (Rs.)"],fs=6.8,lh=9;
    const safe=function(v){return text(v).replace(/[^\x20-\x7E]/g,"?")},esc=function(v){return pdfEscape(safe(v))};
    function wrap(v,w){v=safe(v);const n=Math.max(5,Math.floor((w-5)/(fs*.52)));if(!v)return [""];let a=[],cur="";v.split(/\s+/).forEach(function(q){if((cur?cur+" ":"")+q.length<=n)cur=(cur?cur+" ":"")+q;else{if(cur)a.push(cur);while(q.length>n){a.push(q.slice(0,n));q=q.slice(n)}cur=q}});if(cur)a.push(cur);return a.length?a:[""]}
    function rr(vals){const cells=vals.map(function(v,i){return wrap(v,colW[i])});return {cells:cells,h:Math.max(18,Math.max.apply(null,cells.map(function(z){return z.length}))*lh+4)}}
    const prepared=c.rows.map(function(r){return rr([r[0],r[1],r[2],r[3],r[4],r[5],r[6]===""?"":Number(r[6]).toFixed(2),r[7]===""?"":Number(r[7]).toFixed(2),Number(r[8]).toFixed(2)])});
    const pages=[];let pg=[],y=86;prepared.forEach(function(r){if(y+r.h>561&&pg.length){pages.push(pg);pg=[];y=86}pg.push(r);y+=r.h});if(pg.length||!pages.length)pages.push(pg);
    const objs=[],add=function(o){objs.push(o);return objs.length},font=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),pids=[],cids=[];
    pages.forEach(function(page,pi){let s="q\nBT\n/F1 10 Tf\n1 0 0 1 24 567 Tm (MONEY MANAGER - TRANSACTION REPORT) Tj\n/F1 8 Tf\n1 0 0 1 24 555 Tm (Period: "+esc(p.from+" to "+p.to)+") Tj\nET\n",yy=540;
      function cell(x,y,w,h,vals,bold){s+="0.75 w\n0 0 0 RG\n"+x+" "+(y-h)+" "+w+" "+h+" re S\nBT\n/F1 "+(bold?7.2:fs)+" Tf\n";vals.forEach(function(t,i){s+="1 0 0 1 "+(x+2.5)+" "+(y-2.5-7-i*lh)+" Tm ("+esc(t)+") Tj\n"});s+="ET\n"}
      let x=M;heads.forEach(function(h,i){cell(x,yy,colW[i],20,[h],true);x+=colW[i]});yy-=20;page.forEach(function(r){x=M;r.cells.forEach(function(cc,i){cell(x,yy,colW[i],r.h,cc,false);x+=colW[i]});yy-=r.h});
      if(pi===pages.length-1){yy-=14;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (ACCOUNT SUMMARY) Tj\nET\n";yy-=16;const sw=[130,130,130,130,130],labs=["OPENING BALANCE","TOTAL WITHDRAWALS","TOTAL DEPOSITS","CLOSING BALANCE","No. of Transactions"],vals=[c.opening.toFixed(2),c.withdrawals.toFixed(2),c.deposits.toFixed(2),c.closing.toFixed(2),String(p.data.length)];x=M;labs.forEach(function(q,i){cell(x,yy,sw[i],16,[q],true);x+=sw[i]});yy-=16;x=M;vals.forEach(function(q,i){cell(x,yy,sw[i],16,[q],false);x+=sw[i]});yy-=27;s+="BT\n/F1 9 Tf\n1 0 0 1 "+M+" "+yy+" Tm (******************* END OF REPORT *******************) Tj\nET\n"}
      s+="Q";cids.push(add("<< /Length "+s.length+" >>\nstream\n"+s+"\nendstream"));pids.push(null);
    });
    const pagesId=add("PAGES");pages.forEach(function(_,i){pids[i]=add("<< /Type /Page /Parent "+pagesId+" 0 R /MediaBox [0 0 "+W+" "+H+"] /Resources << /Font << /F1 "+font+" 0 R >> >> /Contents "+cids[i]+" 0 R >>")});objs[pagesId-1]="<< /Type /Pages /Kids ["+pids.map(function(x){return x+" 0 R"}).join(" ")+"] /Count "+pids.length+" >>";const cat=add("<< /Type /Catalog /Pages "+pagesId+" 0 R >>");let pdf="%PDF-1.4\n",offs=[0];objs.forEach(function(o,i){offs[i+1]=pdf.length;pdf+=(i+1)+" 0 obj\n"+o+"\nendobj\n"});const xr=pdf.length;pdf+="xref\n0 "+(objs.length+1)+"\n0000000000 65535 f \n";for(let i=1;i<=objs.length;i++)pdf+=String(offs[i]).padStart(10,"0")+" 00000 n \n";pdf+="trailer\n<< /Size "+(objs.length+1)+" /Root "+cat+" 0 R >>\nstartxref\n"+xr+"\n%%EOF";return new Blob([pdf],{type:"application/pdf"});
  }
  window.exportExcel=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(new Blob([makeXlsx(p)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"money_transactions_"+p.from+"_to_"+p.to+".xlsx")};
  window.exportPDF=function(){const p=pack();if(!p)return;if(!p.data.length){alert("No transactions in the selected date range.");return}downloadBlob(makePdf(p),"money_transactions_"+p.from+"_to_"+p.to+".pdf")};
})();
