PaisaFlow V36 — Firebase Analytics integration

Changes in this build:
- Added Firebase Google Services Gradle plugin.
- Added Firebase Analytics using Firebase Android BoM 34.17.0.
- Added app/google-services.json for Firebase project money-flow-c4e7a.
- Added INTERNET permission required for network analytics delivery.
- Added a safe JavaScript-to-Firebase Analytics bridge.
- Added non-sensitive feature/action telemetry for major app features, including transaction history/export, widgets, backup/restore, profiles, PIN security, biometric use, customisation, add/edit transaction.

Privacy design:
Analytics telemetry intentionally does NOT send PINs, recovery codes, transaction amounts, balances, descriptions, categories, or other user-entered financial data.

Build note:
This source package was statically patched. A Gradle build was not run in this environment because a Gradle executable/wrapper was not available.
