package com.moneymanager.v30;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class PaisaFlowWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "paisaflow_widget";
    static final String BALANCE = "balance";
    static final String EXPENSE = "expense";
    static final String CREDIT = "credit";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    static void update(Context context, AppWidgetManager manager, int appWidgetId) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_paisaflow);
        views.setTextViewText(R.id.widget_balance, p.getString(BALANCE, "₹0.00"));
        views.setTextViewText(R.id.widget_expense, p.getString(EXPENSE, "₹0.00"));
        views.setTextViewText(R.id.widget_credit, p.getString(CREDIT, "₹0.00"));

        Intent launch = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        manager.updateAppWidget(appWidgetId, views);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, PaisaFlowWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(name);
        for (int id : ids) update(context, manager, id);
    }
}
