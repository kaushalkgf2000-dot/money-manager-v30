# Money Flow V70 — Option C Local Priority Sync

Base: Money Flow V68 (accepted V67 Google-only auth + V68 sign-out cloud-backup confirmation).

Requested change only: protect newer local changes from being overwritten by an older Google Drive snapshot after an app restart.

Implementation:
- Persist an account-scoped `pf_cloud_sync_pending_<account>` marker whenever a cloud-eligible local change is scheduled for sync.
- Keep the marker until Google Drive confirms a successful upload of the latest local revision.
- Serialize cloud uploads so an older in-flight upload cannot clear the pending state for a newer local change.
- On app/auth startup, check the pending marker before the existing automatic restore/session marker. If pending, upload local data first instead of restoring cloud data.
- After a successful local-first sync, the existing one-time reload behavior is retained.
- Failed uploads leave the pending marker intact so the next startup can retry.
- Existing cloud restore, Google-only authentication, sign-out backup confirmation, profile, transaction, and other features are otherwise left unchanged.

Verification performed:
- JavaScript syntax check passed for all script blocks extracted from `index.html`.
- Compared V70 against V68: the only source-code change is the cloud synchronization lifecycle block in `index.html`; this note is the only additional file.
