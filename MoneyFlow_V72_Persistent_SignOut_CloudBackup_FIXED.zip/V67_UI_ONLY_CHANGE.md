MoneyFlow V67 — UI-only change from V66 baseline

Requested change:
- Removed the Email/Password Login UI.
- Removed Create Account UI.
- Removed Forgot Password UI.
- Removed Continue as Guest UI.
- Kept only the Sign in with Google action in the signed-out account dialog.

No authentication/backend JavaScript logic, Firebase configuration, backup/restore logic, transaction logic, or other app features were intentionally changed.
