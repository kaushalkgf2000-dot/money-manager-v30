
(function(){
  'use strict';
  const pad=n=>String(n).padStart(2,'0');
  const nowDate=()=>{const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  const txsNow=()=>{try{return (typeof pfReadTx==='function'?pfReadTx():(typeof txs!=='undefined'?txs:[]))||[]}catch(e){return[]}};
  const esc=v=>typeof escapeHtml==='function'?escapeHtml(v):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const money2=v=>typeof money==='function'?money(v):'₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
  const norm=v=>String(v==null?'':v).toLocaleLowerCase('en-IN').trim();
  const typeLabel=t=>String(t||'').toUpperCase()==='CREDIT'?'Credit':'Expense';
  const monthBounds2=ym=>{const [y,m]=String(ym).split('-').map(Number);const last=new Date(y,m,0).getDate();return {from:y+'-'+pad(m)+'-01',to:y+'-'+pad(m)+'-'+pad(last)};};
  const addDays=(ds,n)=>{const d=new Date(ds+'T00:00:00');d.setDate(d.getDate()+n);return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  const diffPct=(a,b)=>{a=Number(a)||0;b=Number(b)||0;if(b===0)return a===0?0:100;return ((a-b)/Math.abs(b))*100;};
  const pfState=()=>window.__pfTxFinalState||{};

  /* 1) Restore a real right-to-left swipe -> Edit reveal button. */
  function enhanceSwipeRows(root){
    const list=root||document.getElementById('pfTransactionsList');if(!list)return;
    list.querySelectorAll('.pf-detail-row').forEach(row=>{
      const main=row.querySelector('.pf-detail-main');if(!main)return;
      let b=row.querySelector('.pf-swipe-reveal');
      if(!b){
        b=document.createElement('button');
        b.type='button';
        b.className='pf-swipe-reveal';
        b.textContent='Edit';
        b.setAttribute('aria-label','Edit transaction');
        b.addEventListener('click',e=>{
          e.stopPropagation();
          const id=row.getAttribute('data-tx-id');
          if(id!=null && id!=='' && typeof v10RequestEdit==='function') v10RequestEdit(id);
        });
        row.insertBefore(b,main);
      }
      if(row.dataset.swipeV8==='1')return;
      row.dataset.swipeV8='1';
      let sx=0,sy=0,moved=false;
      const closeRow=()=>{
        row.classList.remove('open');
        main.style.transform='translateX(0)';
      };
      main.addEventListener('touchstart',e=>{
        const t=e.touches&&e.touches[0];if(!t)return;
        sx=t.clientX;sy=t.clientY;moved=false;
        main.style.transition='none';
      },{passive:true});
      main.addEventListener('touchmove',e=>{
        const t=e.touches&&e.touches[0];if(!t)return;
        const dx=t.clientX-sx,dy=t.clientY-sy;
        if(Math.abs(dx)>8 && Math.abs(dx)>Math.abs(dy)){
          moved=true;
          e.preventDefault();
          const x=Math.max(-92,Math.min(0,dx));
          main.style.transform='translateX('+x+'px)';
        }
      },{passive:false});
      main.addEventListener('touchend',e=>{
        if(!moved)return;
        const t=e.changedTouches&&e.changedTouches[0];
        const dx=(t?t.clientX:sx)-sx;
        main.style.transition='transform .18s ease';
        if(dx<-45){
          list.querySelectorAll('.pf-detail-row.open').forEach(r=>{
            if(r!==row){
              r.classList.remove('open');
              const m=r.querySelector('.pf-detail-main');
              if(m)m.style.transform='translateX(0)';
            }
          });
          row.classList.add('open');
          main.style.transform='translateX(-92px)';
        }else{
          closeRow();
        }
        moved=false;
      },{passive:true});
    });
  }
  const obsTarget=document.getElementById('pfTransactionsList');
  if(obsTarget){new MutationObserver(()=>enhanceSwipeRows(obsTarget)).observe(obsTarget,{childList:true,subtree:true});enhanceSwipeRows(obsTarget);}
  const origRender=window.pfTxRender;
  if(typeof origRender==='function'&&!window.__mfV7RenderWrapped){window.__mfV7RenderWrapped=true;window.pfTxRender=function(){const r=origRender.apply(this,arguments);requestAnimationFrame(()=>enhanceSwipeRows());return r;};}

  /* 2) Category -> exact transaction history, including user-created Custom categories. */
  let catFilter=null;
  function renderFilteredCategoryHistory(){
    if(!catFilter)return false;
    const list=document.getElementById('pfTransactionsList'),sum=document.getElementById('pfTransactionsSummary');if(!list||!sum)return false;
    let data=txsNow().filter(t=>norm(t.category)===norm(catFilter.category)&&(!catFilter.type||String(t.type||'')===catFilter.type));
    if(catFilter.from)data=data.filter(t=>String(t.date||'')>=catFilter.from&&String(t.date||'')<=catFilter.to);
    data=data.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
    let inc=0,exp=0;data.forEach(t=>String(t.type)==='CREDIT'?inc+=Number(t.amount)||0:exp+=Number(t.amount)||0);
    sum.textContent='Category: '+catFilter.category+' • '+data.length+' transaction(s) • Credit '+money2(inc)+' • Expense '+money2(exp)+' • Balance '+money2(inc-exp);
    list.innerHTML='';
    if(!data.length){list.innerHTML='<div class="pf-empty">No transactions found for this category.</div>';return true;}
    data.forEach(t=>{
      const row=document.createElement('div');row.className='pf-detail-row';row.setAttribute('data-tx-id',String(t.id??''));row.setAttribute('data-tx-id',String(t.id||''));
      const credit=String(t.type)==='CREDIT',sign=credit?'+':'-',desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',mode=t.mode||t.paymentMode||t.payment_mode||'Not specified',other=t.other||t.otherInfo||t.other_info||'';
      row.innerHTML='<div class="pf-detail-main"><div class="pf-swipe-icon '+(credit?'income':'expense')+'">'+(credit?'↓':'↑')+'</div><div class="pf-detail-summary"><div class="pf-detail-title">'+esc(t.category||'Uncategorized')+'</div><div class="pf-detail-meta">'+esc(t.date||'')+' • '+esc(mode)+'</div><div class="pf-detail-secondary">'+(desc?esc(desc):'No description')+(remark?' • Remark: '+esc(remark):'')+'</div></div><div class="pf-swipe-amount '+(credit?'income':'expense')+'">'+sign+money2(t.amount)+'</div><button type="button" class="pf-expand-btn" aria-label="Expand transaction" aria-expanded="false">⌄</button></div><div class="pf-detail-panel"><div class="pf-detail-field"><span>Date</span><b>'+esc(t.date||'—')+'</b></div><div class="pf-detail-field"><span>Type</span><b>'+typeLabel(t.type)+'</b></div><div class="pf-detail-field"><span>Amount</span><b class="'+(credit?'income':'expense')+'">'+sign+money2(t.amount)+'</b></div><div class="pf-detail-field"><span>Category</span><b>'+esc(t.category||'Uncategorized')+'</b></div><div class="pf-detail-field"><span>Payment Mode</span><b>'+esc(mode)+'</b></div><div class="pf-detail-field"><span>Description</span><b>'+esc(desc||'—')+'</b></div><div class="pf-detail-field"><span>Remark</span><b>'+esc(remark||'—')+'</b></div><div class="pf-detail-field"><span>Other</span><b>'+esc(other||'—')+'</b></div><div class="pf-detail-actions"><button type="button" class="pf-swipe-edit">Edit</button></div></div>';
      const main=row.querySelector('.pf-detail-main'),panel=row.querySelector('.pf-detail-panel'),exp=row.querySelector('.pf-expand-btn'),edit=row.querySelector('.pf-swipe-edit');
      exp.addEventListener('click',()=>{const o=row.classList.toggle('expanded');panel.style.display=o?'block':'none';exp.textContent=o?'⌃':'⌄';exp.setAttribute('aria-expanded',o?'true':'false');});
      edit.addEventListener('click',()=>{if(typeof v10RequestEdit==='function')v10RequestEdit(t.id);});
      list.appendChild(row);
    });
    requestAnimationFrame(()=>enhanceSwipeRows(list));
    return true;
  }
  function openCatHistory(category,type,from,to){
    catFilter={category:String(category||''),type:type||'',from:from||'',to:to||''};
    document.querySelectorAll('.pf-feature-modal.open').forEach(m=>m.classList.remove('open'));
    const page=document.getElementById('pfTransactionsPage');if(page){document.querySelectorAll('.pf-page > section:not(#pfTransactionsPage)').forEach(x=>x.style.display='none');page.style.display='block';}
    if(typeof window.pfSetNav==='function')window.pfSetNav(document.querySelector('.pf-bottom-nav button:nth-child(2)'));
    renderFilteredCategoryHistory();window.scrollTo({top:0,behavior:'smooth'});
  }
  function categoryRange(){
    const period=document.querySelector('[data-cat-period].active')?.getAttribute('data-cat-period')||'all';
    const st=pfState(),ym=st.month||nowDate().slice(0,7),b=monthBounds2(ym);
    if(period==='month')return b;
    if(period==='year'){const y=ym.slice(0,4);return {from:y+'-01-01',to:y+'-12-31'};}
    if(period==='custom'){let f=document.getElementById('pfCatFrom')?.value||b.from,t=document.getElementById('pfCatTo')?.value||b.to;if(f>t){const x=f;f=t;t=x;}return {from:f,to:t};}
    return {from:'0000-01-01',to:'9999-12-31'};
  }
  const oldCatOpen=window.pfOpenCategory;
  window.pfOpenCategory=function(){catFilter=null;if(typeof oldCatOpen==='function')oldCatOpen();setTimeout(()=>bindCategoryRows(),0);};
  function bindCategoryRows(){const list=document.getElementById('pfCategoryList');if(!list||list.dataset.v7bound==='1')return;list.dataset.v7bound='1';list.addEventListener('click',e=>{const row=e.target.closest('.pf-category-row');if(!row)return;const name=row.querySelector('.pf-category-name')?.textContent?.trim();if(!name)return;const type=document.getElementById('pfCatIncome')?.classList.contains('active')?'CREDIT':'EXPENSE';const r=categoryRange();openCatHistory(name,type,r.from==='0000-01-01'?'':r.from,r.to==='9999-12-31'?'':r.to);});}
  setTimeout(bindCategoryRows,200);

  /* Clear category drill-down whenever the normal period controls are used. */
  ['pfTxSetView','pfTxShiftMonth','pfTxShiftWeek','pfTxSetMonth'].forEach(name=>{
    const fn=window[name];if(typeof fn!=='function'||fn.__v7wrap)return;
    const w=function(){catFilter=null;return fn.apply(this,arguments)};w.__v7wrap=true;window[name]=w;
  });
  const oldTxRender=window.pfRenderTransactionsPage;
  if(typeof oldTxRender==='function'&&!window.__mfV7CatRenderWrapped){window.__mfV7CatRenderWrapped=true;window.pfRenderTransactionsPage=function(){if(catFilter){renderFilteredCategoryHistory();return;}return oldTxRender.apply(this,arguments);};}

  /* 3) Search: instant, case-insensitive, exact data-field index + clickable result. */
  function searchText(t){return [t.date,t.type,typeLabel(t.type),t.amount,t.category,t.description,t.desc,t.remark,t.remarks,t.note,t.mode,t.paymentMode,t.payment_mode,t.other,t.otherInfo,t.other_info].map(norm).join(' ');}
  function renderSearchFixed(q){
    const list=document.getElementById('pfSearchResults');if(!list)return;const query=norm(q),data=txsNow().filter(t=>!query||searchText(t).includes(query));
    if(!data.length){list.innerHTML='<div class="pf-empty">No matching transactions found.</div>';return;}
    list.innerHTML=data.slice(0,200).map(t=>{const credit=String(t.type)==='CREDIT';return '<button type="button" class="pf-search-result" data-search-id="'+esc(String(t.id||''))+'"><div><b>'+esc(t.category||'Uncategorized')+'</b><small>'+esc([t.date||'',typeLabel(t.type),t.mode||t.paymentMode||'',t.description||t.desc||'',t.remark||t.remarks||t.note||'',t.other||''].filter(Boolean).join(' • '))+'</small></div><strong style="color:'+(credit?'#2fa65b':'#e3483d')+'">'+(credit?'+':'-')+money2(t.amount)+'</strong></button>';}).join('');
  }
  window.pfOpenSearch=function(){openFeatureFixed('pfSearchModal');const i=document.getElementById('pfSearchInput');if(i){i.value='';i.oninput=()=>renderSearchFixed(i.value);requestAnimationFrame(()=>i.focus());}renderSearchFixed('');};
  document.addEventListener('click',e=>{const b=e.target.closest?.('[data-search-id]');if(!b)return;const t=txsNow().find(x=>String(x.id)===String(b.getAttribute('data-search-id')));if(t)openCatHistory(t.category||'Uncategorized',t.type||'',t.date||'',t.date||'');});

  /* 4) Analytics V15: expense donut + totals + daily/monthly comparisons + drill-down. */
  let analyticsType='EXPENSE';
  function monthTotals(ym){const b=monthBounds2(ym),a=txsNow().filter(t=>String(t.date||'')>=b.from&&String(t.date||'')<=b.to);let c=0,e=0;a.forEach(t=>String(t.type)==='CREDIT'?c+=Number(t.amount)||0:e+=Number(t.amount)||0);return {credit:c,expense:e};}
  function catTotals(data,type){const o=Object.create(null);data.filter(t=>String(t.type)===type).forEach(t=>{const c=t.category||'Uncategorized';o[c]=(o[c]||0)+(Number(t.amount)||0);});return Object.entries(o).sort((a,b)=>b[1]-a[1]);}
  function analyticsRangeData(){return txsNow();}
  function pfAnalyticsIcon(category){const s=String(category||'').toLowerCase();if(/food|dining|grocery/.test(s))return '🍽️';if(/transport|travel|fuel|petrol/.test(s))return '🚗';if(/shop|shopping/.test(s))return '🛒';if(/bill|utility|recharge|electric/.test(s))return '🧾';if(/health|medical|medicine/.test(s))return '❤';if(/education|school|course/.test(s))return '🎓';if(/home|salary|income|money/.test(s))return '⌂';return '•••';}
  function pfAnalyticsEsc(s){return esc(String(s==null?'':s));}
  function pfAnalyticsPct(v,total){return total>0?(Number(v)/Number(total)*100).toFixed(1):'0.0';}
  function renderAnalyticsFixed(){
    const modal=document.getElementById('pfAnalyticsModal'),host=document.getElementById('pfAnalyticsBody');if(!modal||!host)return;
    const today=nowDate(),yesterday=addDays(today,-1),all=txsNow();
    const num=v=>Number(v)||0;
    function daySum(ds){let c=0,e=0;all.forEach(t=>{if(String(t.date||'')===ds){if(String(t.type)==='CREDIT')c+=num(t.amount);else e+=num(t.amount);}});return {credit:c,expense:e,net:c-e};}
    const td=daySum(today),yd=daySum(yesterday),cp=diffPct(td.credit,yd.credit),ep=diffPct(td.expense,yd.expense),np=diffPct(td.net,yd.net);
    const creditTotal=all.filter(t=>String(t.type)==='CREDIT').reduce((s,t)=>s+num(t.amount),0);
    const expenseTotal=all.filter(t=>String(t.type)!=='CREDIT').reduce((s,t)=>s+num(t.amount),0);
    const ex=catTotals(all,'EXPENSE'),cr=catTotals(all,'CREDIT');
    const maxEx=ex[0]||null,maxCr=cr[0]||null;
    const highestSingle=all.filter(t=>String(t.type)==='EXPENSE').slice().sort((a,b)=>num(b.amount)-num(a.amount))[0]||null;
    const st=pfState(),anchor=st.month||today.slice(0,7),months=[];let [yy,mm]=anchor.split('-').map(Number);for(let i=5;i>=0;i--){const d=new Date(yy,mm-1-i,1);months.push(d.getFullYear()+'-'+pad(d.getMonth()+1));}
    const mt=months.map(m=>({m,...monthTotals(m)})),maxMonth=Math.max(1,...mt.flatMap(x=>[x.credit,x.expense]));
    const top=[...ex.map(x=>({type:'EXPENSE',name:x[0],value:x[1]})),...cr.map(x=>({type:'CREDIT',name:x[0],value:x[1]}))].sort((a,b)=>b.value-a.value).slice(0,8);
    const topMax=Math.max(1,...top.map(x=>x.value));
    const palette=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];
    let start=0;const stops=ex.map((x,i)=>{const end=start+(x[1]/Math.max(1,expenseTotal))*100,z=palette[i%palette.length]+' '+start+'% '+end+'%';start=end;return z;});
    const dayCard=(label,val,prev,pct)=>'<div class="mf15-day-card"><div class="mf15-day-label">'+label+'</div><div class="mf15-day-value">'+money2(val)+'</div><div class="mf15-day-sub">Yesterday: '+money2(prev)+' · <span class="mf15-change '+(pct>0?'up':pct<0?'down':'flat')+'">'+(pct>0?'↑ ':pct<0?'↓ ':'→ ')+Math.abs(Number(pct)||0).toFixed(1)+'%</span></div></div>';
    const legend=ex.length?ex.map(([c,v],i)=>'<div class="mf15-legend-row"><i class="mf15-dot" style="background:'+palette[i%palette.length]+'"></i><span class="mf15-cat-icon">'+pfAnalyticsIcon(c)+'</span><b>'+pfAnalyticsEsc(c)+'</b><span class="mf15-amount">'+money2(v)+'</span><span class="mf15-pct" style="color:'+palette[i%palette.length]+'">'+pfAnalyticsPct(v,expenseTotal)+'%</span></div>').join(''):'<div class="mf15-sub">No expense categories yet.</div>';
    const monthRows=mt.map(x=>'<div class="mf15-month"><span>'+pfAnalyticsEsc(x.m.slice(5))+'/'+pfAnalyticsEsc(x.m.slice(0,4).slice(2))+'</span><div class="mf15-lanes"><div class="mf15-lane"><i class="credit" style="width:'+((x.credit/maxMonth)*100).toFixed(1)+'%"></i></div><div class="mf15-lane"><i class="expense" style="width:'+((x.expense/maxMonth)*100).toFixed(1)+'%"></i></div></div><div class="mf15-values"><span class="credit">'+money2(x.credit)+'</span><span class="expense">'+money2(x.expense)+'</span></div></div>').join('');
    const exPct=maxEx?pfAnalyticsPct(maxEx[1],expenseTotal):'0.0';
    host.innerHTML='<div class="mf15-card"><div class="mf15-donut-row"><div class="mf15-donut" style="background:'+(stops.length?'conic-gradient('+stops.join(',')+')':'conic-gradient(#e8e3d9 0 100%)')+'"><div class="mf15-donut-center"><b>'+money2(expenseTotal)+'</b><span>Total Expense</span></div></div><div><div class="mf15-section-title">Expense by Category</div><div class="mf15-legend">'+legend+'</div></div></div></div>'+
      '<div class="mf15-total-grid"><div class="mf15-card mf15-total"><div class="mf15-total-icon">↑</div><div><div class="mf15-total-label">Total Credit</div><div class="mf15-total-value">'+money2(creditTotal)+'</div><div class="mf15-total-caption">All time income</div></div></div><div class="mf15-card mf15-total expense"><div class="mf15-total-icon">↓</div><div><div class="mf15-total-label">Total Expense</div><div class="mf15-total-value">'+money2(expenseTotal)+'</div><div class="mf15-total-caption">All time expense</div></div></div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Today vs Yesterday</div><div class="mf15-sub">'+today+' compared with '+yesterday+'</div><div class="mf15-day-grid">'+dayCard('Credit Today',td.credit,yd.credit,cp)+dayCard('Expense Today',td.expense,yd.expense,ep)+'</div><div class="mf15-net"><span>Today Net</span><span>'+money2(td.net)+'</span></div><div class="mf15-sub" style="margin-top:5px">Yesterday Net '+money2(yd.net)+' · <span class="mf15-change '+(np>0?'up':np<0?'down':'flat')+'">'+(np>0?'↑ ':np<0?'↓ ':'→ ')+Math.abs(Number(np)||0).toFixed(1)+'%</span></div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Monthly Comparison</div><div class="mf15-sub">Six-month trend ending '+anchor+'</div><div class="mf15-month-legend"><span class="mf15-legend-key"><i class="mf15-key-dot" style="background:#2fa65b"></i>Credit (Income)</span><span class="mf15-legend-key"><i class="mf15-key-dot" style="background:#e3483d"></i>Expense</span></div>'+monthRows+'<div class="mf15-sub" style="margin-top:9px">Each month has a separate green Credit lane and red Expense lane.</div></div>'+
      '<div class="mf15-highlights"><div class="mf15-card mf15-highlight" data-analytics-cat="expense">'+
        '<div class="mf15-section-title">Maximum Expense Category</div>'+(maxEx?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(maxEx[0])+'</div><div class="mf15-highlight-value">'+money2(maxEx[1])+'</div><div class="mf15-highlight-sub">'+exPct+'% of total expense</div>':'<div class="mf15-highlight-sub">No expense data</div>')+'</div>'+
        '<div class="mf15-card mf15-highlight" data-analytics-cat="credit"><div class="mf15-section-title">Maximum Credit Category</div>'+(maxCr?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(maxCr[0])+'</div><div class="mf15-highlight-value">'+money2(maxCr[1])+'</div><div class="mf15-highlight-sub">Highest income category</div>':'<div class="mf15-highlight-sub">No credit data</div>')+'</div>'+
        '<div class="mf15-card mf15-highlight" data-analytics-single="1"><div class="mf15-section-title">Highest Single Expense</div>'+(highestSingle?'<div class="mf15-highlight-name">'+pfAnalyticsEsc(highestSingle.category||'Uncategorized')+'</div><div class="mf15-highlight-value">'+money2(highestSingle.amount)+'</div><div class="mf15-highlight-sub">on '+pfAnalyticsEsc(highestSingle.date||'')+'</div>':'<div class="mf15-highlight-sub">No expense data</div>')+'</div></div>'+
      '<div class="mf15-card"><div class="mf15-section-title">Category Ranking</div>'+(top.length?top.map((x,i)=>'<div class="mf15-rank"><span class="mf15-rank-no">'+(i+1)+'</span><span class="mf15-rank-name">'+(x.type==='CREDIT'?'Cr ':'Exp ')+pfAnalyticsEsc(x.name)+'</span><div class="mf15-rank-track"><i style="width:'+((x.value/topMax)*100).toFixed(1)+'%;background:'+(x.type==='CREDIT'?'#2fa65b':'#e3483d')+'"></i></div><span class="mf15-rank-amt">'+money2(x.value)+'</span></div>').join(''):'<div class="mf15-sub">No category data yet.</div>')+'</div>'+
      '<button type="button" class="mf15-export" onclick="pfExportAnalyticsImage()">▣ Export Image · Save PNG</button>'+
      '<div class="mf15-tip">This chart shows category-wise distribution of your total expenses. Track your spending to manage your money better.</div>';
  }
  function pfShowAnalyticsSingleExpense(t){
    if(!t)return;
    let m=document.getElementById('pfAnalyticsDetailModal');
    if(!m){m=document.createElement('div');m.id='pfAnalyticsDetailModal';m.className='pf-feature-modal';m.setAttribute('aria-hidden','true');m.innerHTML='<div class="pf-feature-sheet"><div class="pf-feature-head"><div><span class="pf-feature-kicker">EXPENSE DETAILS</span><h2>Highest Single Expense</h2></div><button class="pf-feature-close" onclick="pfCloseFeature(\'pfAnalyticsDetailModal\')">✕</button></div><div id="pfAnalyticsDetailBody"></div></div>';document.body.appendChild(m);}
    const body=document.getElementById('pfAnalyticsDetailBody'),mode=t.mode||t.paymentMode||t.payment_mode||'Not specified',desc=t.description||t.desc||'',remark=t.remark||t.remarks||t.note||'',other=t.other||t.otherInfo||t.other_info||'';
    body.innerHTML='<div class="mf15-card"><div class="mf15-section-title">'+pfAnalyticsEsc(t.category||'Uncategorized')+'</div><div class="mf-a-big" style="margin-top:8px;color:#e3483d">-'+money2(t.amount)+'</div><div class="mf15-sub" style="margin-top:7px">Date: '+pfAnalyticsEsc(t.date||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Payment Mode: '+pfAnalyticsEsc(mode)+'</div><div class="mf15-sub" style="margin-top:5px">Description: '+pfAnalyticsEsc(desc||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Remark: '+pfAnalyticsEsc(remark||'—')+'</div><div class="mf15-sub" style="margin-top:5px">Other: '+pfAnalyticsEsc(other||'—')+'</div></div>';
    openFeatureFixed('pfAnalyticsDetailModal');
  }
  function pfExportAnalyticsImage(){
    try{
      const data=txsNow(), expense=data.filter(t=>String(t.type)!=='CREDIT'), credit=data.filter(t=>String(t.type)==='CREDIT');
      const totalE=expense.reduce((s,t)=>s+(Number(t.amount)||0),0),totalC=credit.reduce((s,t)=>s+(Number(t.amount)||0),0),cats=catTotals(data,'EXPENSE').slice(0,8),today=nowDate();
      const W=1200,H=1500,cv=document.createElement('canvas');cv.width=W;cv.height=H;const c=cv.getContext('2d');
      c.fillStyle='#faf8f2';c.fillRect(0,0,W,H);c.fillStyle='#51463a';c.font='700 46px Arial';c.fillText('Money Flow — Analytics',60,70);c.font='22px Arial';c.fillStyle='#8b8378';c.fillText(today,60,105);
      const cx=300,cy=300,r=175,ir=105;let a=-Math.PI/2;const pal=['#2689e6','#2fa65b','#e3483d','#b3975a','#7c7654','#8e6bb5','#d28b45','#5a8d9e'];
      if(totalE){cats.forEach((x,i)=>{const da=x[1]/totalE*Math.PI*2;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r,a,a+da);c.closePath();c.fillStyle=pal[i%pal.length];c.fill();a+=da;});}else{c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.fillStyle='#e8e3d9';c.fill();}
      c.beginPath();c.arc(cx,cy,ir,0,Math.PI*2);c.fillStyle='#faf8f2';c.fill();c.fillStyle='#51463a';c.textAlign='center';c.font='700 34px Arial';c.fillText('₹'+totalE.toLocaleString('en-IN',{minimumFractionDigits:2}),cx,cy-4);c.font='20px Arial';c.fillStyle='#8b8378';c.fillText('Total Expense',cx,cy+28);c.textAlign='left';
      c.font='700 26px Arial';c.fillStyle='#51463a';c.fillText('Expense by Category',570,165);cats.forEach((x,i)=>{const y=215+i*45;c.fillStyle=pal[i%pal.length];c.beginPath();c.arc(590,y-7,8,0,Math.PI*2);c.fill();c.fillStyle='#51463a';c.font='21px Arial';c.fillText(x[0],615,y);c.textAlign='right';c.font='700 20px Arial';c.fillText('₹'+x[1].toLocaleString('en-IN',{minimumFractionDigits:2}),1110,y);c.textAlign='left';});
      function box(x,y,w,title,val,sub){c.fillStyle='#fffdf9';c.strokeStyle='#ded8cc';c.lineWidth=2;c.beginPath();c.roundRect(x,y,w,110,18);c.fill();c.stroke();c.fillStyle='#51463a';c.font='700 20px Arial';c.fillText(title,x+22,y+32);c.font='700 30px Arial';c.fillText('₹'+val.toLocaleString('en-IN',{minimumFractionDigits:2}),x+22,y+70);c.fillStyle='#8b8378';c.font='17px Arial';c.fillText(sub,x+22,y+95);}
      box(60,540,520,'Total Credit',totalC,'All time income');box(620,540,520,'Total Expense',totalE,'All time expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Today vs Yesterday',60,720);c.font='18px Arial';c.fillStyle='#8b8378';c.fillText(today+' comparison',60,750);
      const d=(()=>{let cc=0,ee=0;data.forEach(t=>{if(t.date===today){if(t.type==='CREDIT')cc+=Number(t.amount)||0;else ee+=Number(t.amount)||0;}});return {cc,ee,net:cc-ee};})();box(60,780,330,'Credit Today',d.cc,'Income today');box(435,780,330,'Expense Today',d.ee,'Expense today');box(810,780,330,'Today Net',d.net,'Credit − Expense');
      c.fillStyle='#51463a';c.font='700 27px Arial';c.fillText('Category Ranking',60,970);const ranking=[...catTotals(data,'CREDIT').map(x=>['Cr',x[0],x[1]]),...cats.map(x=>['Exp',x[0],x[1]])].sort((a,b)=>b[2]-a[2]).slice(0,7);const rm=Math.max(1,...ranking.map(x=>x[2]));ranking.forEach((x,i)=>{const y=1015+i*58;c.fillStyle='#51463a';c.font='18px Arial';c.fillText((i+1)+'. '+x[0]+' '+x[1],60,y);c.fillStyle=x[0]==='Cr'?'#2fa65b':'#e3483d';c.beginPath();c.roundRect(430,y-16,570*(x[2]/rm),18,9);c.fill();c.fillStyle='#51463a';c.textAlign='right';c.font='700 18px Arial';c.fillText('₹'+x[2].toLocaleString('en-IN',{minimumFractionDigits:2}),1110,y);c.textAlign='left';});
      c.fillStyle='#8b8378';c.font='17px Arial';c.fillText('Generated from Money Flow transaction analytics',60,H-45);
      const b64=cv.toDataURL('image/png').split(',')[1],name='money_flow_analytics_'+today+'.png';
      if(window.AndroidFile&&AndroidFile.saveFile){AndroidFile.saveFile(name,'image/png',b64);}else{const a=document.createElement('a');a.href='data:image/png;base64,'+b64;a.download=name;a.click();}
    }catch(e){try{alert('Export Image failed: '+e.message)}catch(_){} }
  }
  document.addEventListener('click',e=>{const h=e.target.closest?.('[data-analytics-single]');if(h){const t=txsNow().filter(t=>String(t.type)==='EXPENSE').sort((a,b)=>(Number(b.amount)||0)-(Number(a.amount)||0))[0];pfShowAnalyticsSingleExpense(t);return;}const c=e.target.closest?.('[data-analytics-cat]');if(c){const type=c.getAttribute('data-analytics-cat');const arr=type==='expense'?catTotals(txsNow(),'EXPENSE'):catTotals(txsNow(),'CREDIT');if(arr[0])openCatHistory(arr[0][0],type==='expense'?'EXPENSE':'CREDIT','','');}});
  window.pfOpenAnalytics=function(){openFeatureFixed('pfAnalyticsModal');renderAnalyticsFixed();};
  window.pfAnalyticsSetType=function(){renderAnalyticsFixed();};
  window.__mfV7AnalyticsRender=renderAnalyticsFixed;
  function openFeatureFixed(id){const m=document.getElementById(id);if(!m)return;m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
  window.pfOpenAnalytics=function(){openFeatureFixed('pfAnalyticsModal');renderAnalyticsFixed();};
  window.pfAnalyticsSetType=function(type){analyticsType=type;document.getElementById('pfAnalyticsExpense')?.classList.toggle('active',type==='EXPENSE');document.getElementById('pfAnalyticsIncome')?.classList.toggle('active',type==='CREDIT');renderAnalyticsFixed();};
  window.__mfV7AnalyticsRender=renderAnalyticsFixed;

  /* 5) Type/category safety remains enforced, plus clear category when type changes. */
  const et=document.getElementById('editType');
  if(et&&!et.__mfV7Type){et.__mfV7Type=true;et.addEventListener('change',()=>{const sel=document.getElementById('editCategory');const custom=document.getElementById('editCustomCategory');if(sel){sel.value='';}if(custom){custom.value='';custom.style.display='none';}const n=document.getElementById('editCategoryNotice');if(n){n.style.display='block';n.textContent='Transaction type changed. Please select a category for the new type.';}});}

  /* Final nav override: Transactions always opens Daily with today's date. */
  const prevNavV7=window.pfNav;
  window.pfNav=function(name,btn){if(name==='transactions'){catFilter=null;const st=pfState();const td=nowDate();st.view='daily';st.month=td.slice(0,7);st.weekAnchor=td;const dp=document.getElementById('pfTxDayPicker');if(dp){dp.value=td;const b=monthBounds2(st.month);dp.min=b.from;dp.max=b.to;}document.querySelectorAll('.pf-tx-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view==='daily'));const d=document.getElementById('pfTxDailyControls'),w=document.getElementById('pfTxWeeklyControls'),c=document.getElementById('pfTxCustomControls');if(d)d.style.display='flex';if(w)w.style.display='none';if(c)c.style.display='none';}return typeof prevNavV7==='function'?prevNavV7.apply(this,arguments):undefined;};

  function boot(){enhanceSwipeRows();bindCategoryRows();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(boot,250);setTimeout(boot,800);
})();

  window.pfOpenNotes=function(){
    if(typeof openFeature==='function') openFeature('pfNotesModal');
    else if(typeof pfOpenFeature==='function') pfOpenFeature('pfNotesModal');
    if(typeof window.pfSetNav==='function') window.pfSetNav(document.getElementById('notesNavBtn'));
  };
  window.pfOpenCalculator=function(){
    if(typeof openFeature==='function') openFeature('pfCalculatorModal');
    else if(typeof pfOpenFeature==='function') pfOpenFeature('pfCalculatorModal');
  };
