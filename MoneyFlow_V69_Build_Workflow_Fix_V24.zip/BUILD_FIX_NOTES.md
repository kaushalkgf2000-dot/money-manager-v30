# Build workflow fix

The previous GitHub Actions failure was in **Setup Android SDK**, before Gradle reached the Android project.

The old workflow used `android-actions/setup-android@v3` and its default/legacy `tools` package path. The workflow here uses `android-actions/setup-android@v4`, disables the legacy package install, and installs only the SDK packages required by this project: platform-tools, Android 35 platform, and Build Tools 35.0.0.

The project uses Android Gradle Plugin 8.9.2, so the workflow uses JDK 17 and Gradle 8.11.1.

No application source code was changed by this build-only fix.
