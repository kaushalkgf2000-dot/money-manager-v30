# CivilNexa Step 29E - Navigation Fix v2

## Android Back behavior
- A single app-wide BackHandler now consumes Android Back on every nested screen.
- Study flow unwinds one screen at a time: Home -> Study -> Subject -> Chapter -> Topic/Content.
- Test flow unwinds one screen at a time: Tests/Chapter -> Live Test -> Result -> parent.
- Live Test Android Back opens the Exit Test confirmation; choosing Exit pops exactly one route.
- At Home, the custom BackHandler is disabled so the normal Android behavior exits the Activity/app.
- Global bottom navigation remains hidden inside nested Study screens, Live Test, and Result.
