# CivilNexa v1.2.1 Build Error Fix — Video 60329

## Errors observed in the build video
- `MainActivity.kt:233:17` — unresolved receiver for `Icons.Filled.Image` / missing Compose `Image` import.
- `MainActivity.kt:285:18`, `895:18`, `911:18`, `931:18` — unresolved reference `BorderStroke`.

## Fixes applied
- Added `androidx.compose.foundation.Image` import.
- Added `androidx.compose.foundation.BorderStroke` import.
- Preserved the Step 30 UI changes.
- Corrected question default negative marking to `0.25`.
- Corrected result score calculation to `correct × 4 − wrong × 0.25` and stored marks as a float.

## Verification note
This environment does not have the Gradle executable/wrapper available, so a local compile could not be run here. The fixes target the exact compiler errors visible in the supplied build video.
