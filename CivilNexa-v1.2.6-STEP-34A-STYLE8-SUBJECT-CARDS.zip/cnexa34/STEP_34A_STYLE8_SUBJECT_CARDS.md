# Step 34A — Premium Style-8 Subject Cards & Study Dashboard

Goal: bring the Study Material subject list closer to the approved Style-8 visual direction and the CivilNexa dashboard reference.

Implemented in source:
- Larger subject-specific engineering glyphs for each supported subject.
- Consistent rounded glass container with subject-specific accent.
- Stronger icon-to-card visual hierarchy.
- Two-line module metadata: Chapters / Notes / Formulas / Practice / PYQs.
- Progress bar plus explicit completion percentage.
- Preserved Study root and nested navigation behavior.

Not implemented yet:
- Final chapter-by-chapter content population.
- Final notes/formula/PYQ bulk data.

Verification:
- Device build/visual verification is still required before marking this step PASS.
