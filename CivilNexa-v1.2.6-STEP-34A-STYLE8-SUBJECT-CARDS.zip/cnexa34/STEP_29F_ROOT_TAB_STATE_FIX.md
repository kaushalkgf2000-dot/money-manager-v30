# Step 29F — Root Tab Selection State Fix

Fixes the bottom-navigation selected icon state after back navigation.

Rule:
- Home route => Home icon selected.
- Study route and nested Study routes => Study context retained while inside the flow.
- Tests/Test/Result => Tests context.
- Progress => Progress.
- Profile => Profile.
- Returning to Home via Android Back or in-app Back resets selection to Home.

The visible bottom bar remains restricted to root screens only; nested Study/Test/Result screens do not render it.
