# CivilNexa Release Candidate Checklist

- [ ] Clean Gradle build
- [ ] Debug APK install
- [ ] Release APK/AAB build
- [ ] App launch and splash
- [ ] Home dashboard
- [ ] Study > Subject > Chapter > Topic
- [ ] Notes / Formula / Concepts / Practice
- [ ] Test Series
- [ ] Live Test
- [ ] Hidden question palette
- [ ] Icon-only test controls
- [ ] Calculator overlay
- [ ] Timer and auto-save/resume
- [ ] Submit and dynamic result
- [ ] Result analytics
- [ ] PYQ
- [ ] Progress
- [ ] Profile/Settings
- [ ] Android Back stack
- [ ] Exit confirmation during active test
- [ ] No unwanted global bottom navigation in nested flows
- [ ] Real-device regression
- [ ] Performance / memory / crash check
- [ ] Privacy / store assets / signing

Production status remains pending until the checklist is executed on a real Android build.
