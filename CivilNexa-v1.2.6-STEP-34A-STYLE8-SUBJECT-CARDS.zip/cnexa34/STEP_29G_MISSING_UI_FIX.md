# Step 29G Missing UI Fix
- Added live Question Palette summary block: Answered, Marked, Not Answered, Total.
- Added Current status indicator.
- Updated test cards with a dedicated star accent for mock tests and explicit 10 Questions / 40 Marks / 10 min / -0.25 marking metadata.
- These changes are source-level; compile/device verification must be done in Android Studio.
