# CivilNexa v1.1.1 — Step 29F Final Regression Pass

## Final UX rules
- Global bottom navigation is shown only on root-level Home / Tests / PYQ / Progress / Profile screens.
- Nested Study screens and Live Test / Result screens use their own back-stack and do not show global navigation.
- Android Back unwinds exactly one navigation level at a time.
- At Home (root), Android Back exits the Activity normally.
- During an active test, Android Back opens an Exit Test confirmation before leaving the test.
- Test controls are icon-only: Previous, Save/Bookmark, Calculator, Next/Submit.
- Question palette is hidden by default and opens as an overlay.
- Calculator is an overlay and closes back to the same question.

## Result format
- `<marks> / <totalMarks> Marks`
- `<accuracy>% Accuracy`
- `<attempted> / <totalQuestions> Questions Attempted`
- `Time: <mm:ss>`
- Correct / Wrong / Skipped / Performance

## 29F refinements implemented
- Test header now shows exam context and explicit question position.
- Question metadata shows question number, type, difficulty, answered count and negative marking.
- Question palette shows Answered, Review, Current and Not Answered states with counts.
- Removed duplicate Attempted card from Result screen.
- Version bumped to 1.1.1 (versionCode 2).

## Validation note
Source was reviewed and updated in the working environment. Android/Gradle execution is not available in this environment, so device/compile PASS must be verified in Android Studio on the target phone before calling this a release candidate.
