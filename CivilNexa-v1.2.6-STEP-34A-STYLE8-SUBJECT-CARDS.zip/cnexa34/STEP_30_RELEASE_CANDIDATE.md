# CivilNexa — Step 30 Release Candidate

Version: 1.2.0-rc1
Version code: 3

## Scope
- Final navigation state refinement
- Root-tab selection state consistency
- Study/test nested navigation isolation
- Test controls remain icon-only
- Global bottom navigation hidden inside nested Study, Live Test and Result screens
- Dynamic result marks/accuracy/attempted/time presentation
- Explicit Result -> Back to Tests action returns to Test Series root
- AI remains parked/planned

## Device QA checklist
- [ ] Build debug APK successfully
- [ ] Install / uninstall
- [ ] Home -> Study -> Subject -> Chapter -> Topic -> Back each level
- [ ] Home -> Tests -> Live Test -> Result
- [ ] Android Back unwinds one route at a time
- [ ] Home root Back exits app
- [ ] Live Test Back shows exit confirmation
- [ ] Bottom nav absent from nested Study/Test/Result
- [ ] Root tab highlight matches visible root screen
- [ ] Question palette opens/closes without losing current question
- [ ] Calculator opens/closes without losing current question
- [ ] Result shows marks, accuracy, attempted questions and time
- [ ] Result 'Back to Tests' returns to Test Series

## Release gate
Do not publish until the above device checks pass on the target Android devices.
