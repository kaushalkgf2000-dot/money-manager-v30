# CivilNexa Version Info

App: CivilNexa
Version: v1.2.6
Version Code: 11
Step: 34A — Premium Style-8 Subject Cards & Study Dashboard Refinement
Status: UI refinement ready for device verification

Changes:
- Reworked Style-8 subject glyphs with larger, recognisable engineering symbols.
- Added subject-specific accent treatment while preserving the common visual family.
- Enlarged and refined subject icon containers.
- Improved subject card hierarchy, metadata, progress presentation and spacing.
- Preserved root/nested navigation rules.
- No bulk study/test content population; content remains a later phase.
