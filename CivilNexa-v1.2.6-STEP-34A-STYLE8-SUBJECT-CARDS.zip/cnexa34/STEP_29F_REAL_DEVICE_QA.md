# CivilNexa — Step 29F: Real Device QA & Release Candidate Prep

## Scope
This build starts the final QA phase using the latest Step 29E navigation-fixed source.

## Locked UX checks
- Global bottom navigation is hidden inside Study Material nested screens.
- Global bottom navigation is hidden inside Live Test and Result.
- Live Test controls are icon-only: Previous, Save/Bookmark, Calculator, Next/Finish.
- Question palette opens from the Questions action and remains hidden by default.
- Calculator opens as a compact overlay and closes without leaving the test.
- Android Back unwinds the navigation stack one screen at a time.
- Live Test Android Back requires exit confirmation.
- Home is the root; only Back from Home exits the activity.
- Result header uses dynamic values: Marks, Accuracy, Questions Attempted, Time.
- Total marks are calculated from test configuration, not hard-coded.

## Device QA matrix
Run on at least:
1. Android 13 / 14 mid-range device
2. Android 14/15 higher-density device
3. Low-end Android device
4. Small display device

For each device verify:
- launch / cold start
- portrait layout
- touch targets
- scrolling
- back navigation
- test timer
- answer selection
- mark/save state
- clear response
- question palette
- calculator overlay
- submit/result
- Study navigation
- PYQ navigation
- Progress navigation
- Profile navigation
- no clipped icon-only controls
- no unexpected bottom navigation in nested flows
- no crash on repeated Back presses

## Release gate
Do not label the build production-ready until:
- all P0/P1 issues are fixed
- core test flow passes end-to-end
- navigation stack passes on real devices
- no clipped/overlapping UI remains
- result values match submitted answers
- APK/AAB release build compiles successfully

## Current status
Phase: Step 29F — QA / Release Candidate preparation
AI: Parked as previously decided
Production release: Not yet claimed
