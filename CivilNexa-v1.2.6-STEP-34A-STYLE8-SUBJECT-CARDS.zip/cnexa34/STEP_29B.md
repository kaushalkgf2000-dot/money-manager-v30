# CivilNexa v1.1.0 — Step 29B Real Test Engine

## Implemented in this build
- Dynamic demo question state and answer selection/update
- Correct/wrong/skipped calculation
- Negative marking: +4 correct, -1 wrong
- Live countdown timer with auto-submit on timeout
- Hidden question palette overlay
- Mark/unmark for review
- Clear response
- Previous/Next navigation
- Review & Submit confirmation
- Calculator overlay with arithmetic precedence and parentheses
- Local auto-save of current question, remaining time, answers and marked questions
- Resume entry shown in Test Series when a saved test exists
- Saved test state is cleared after successful submission
- Result screen with marks, accuracy, correct/wrong/skipped and time taken
- Premium CivilNexa UI/icon treatment retained

## Important scope
- This is a local functional Test Engine build. Firebase persistence, production question database, cloud sync, authentication, and AI remain later integration phases.
- The release is not claimed to be Play Store ready until a real Android build and device QA pass is completed.
