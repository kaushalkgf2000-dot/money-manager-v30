package com.civilnexa.app

data class TopicContent(
    val name: String,
    val completed: Boolean = false,
    val notes: String,
    val formula: String,
    val concept: String,
    val practice: List<String>,
    val pyq: List<String>
)

data class ChapterContent(
    val name: String,
    val progress: Int,
    val topics: List<TopicContent>
)

data class SubjectContent(
    val name: String,
    val chapters: List<ChapterContent>
)

object CivilNexaContentRepository {
    private fun chapter(name: String, progress: Int, topics: List<TopicContent>) = ChapterContent(name, progress, topics)
    private fun topic(name: String, notes: String, formula: String, concept: String, practice: List<String>, pyq: List<String>) =
        TopicContent(name, notes = notes, formula = formula, concept = concept, practice = practice, pyq = pyq)

    val subjects = listOf(
        SubjectContent("Strength of Materials", listOf(
            chapter("Simple Stress & Strain", 75, listOf(
                topic("Introduction", "Stress is the internal resisting force developed per unit area.", "σ = P / A", "Normal stress acts perpendicular to the resisting area.", listOf("Unit of normal stress", "Calculate stress from load and area"), listOf("SSC JE • Strength of Materials • Stress")),
                topic("Types of Stress", "Normal, shear, bearing and thermal stresses are common classifications.", "τ = V / A", "The stress type depends on the direction of internal force relative to the area.", listOf("Identify stress from loading diagram"), listOf("SSC JE • Stress classification")),
                topic("Strain", "Strain is deformation per unit original dimension.", "ε = ΔL / L", "Longitudinal strain is dimensionless.", listOf("Find strain from elongation"), listOf("RRB JE • Strain")),
                topic("Stress-Strain Diagram", "The diagram relates applied stress to resulting strain for a material.", "E = σ / ε (elastic range)", "Important regions include proportional, elastic and plastic ranges.", listOf("Identify proportional limit"), listOf("SSC JE • Stress-strain curve"))
            )),
            chapter("Elastic Constants", 55, listOf(
                topic("Young's Modulus", "Ratio of normal stress to longitudinal strain within elastic limit.", "E = σ / ε", "Young's modulus measures axial stiffness.", listOf("Calculate E"), listOf("SSC JE • Elastic constants")),
                topic("Poisson's Ratio", "Ratio of lateral strain to longitudinal strain in magnitude.", "ν = lateral strain / longitudinal strain", "Poisson's ratio links axial and transverse deformation.", listOf("Find lateral strain"), listOf("RRB JE • Poisson ratio"))
            )),
            chapter("Shear Force & Bending Moment", 40, listOf(
                topic("Shear Force", "Algebraic sum of vertical forces on one side of a beam section.", "dV/dx = −w", "Shear force changes with distributed load intensity.", listOf("Draw SFD for UDL"), listOf("SSC JE • SFD")),
                topic("Bending Moment", "Internal moment developed at a beam section due to external loads.", "dM/dx = V", "Maximum or minimum bending moment occurs where shear force is zero, subject to boundary conditions.", listOf("Find maximum BM"), listOf("SSC JE • BMD"))
            ))
        )),
        SubjectContent("Fluid Mechanics", listOf(
            chapter("Properties of Fluids", 60, listOf(
                topic("Density & Specific Gravity", "Density is mass per unit volume; specific gravity compares density with water.", "ρ = m/V; SG = ρ/ρw", "Specific gravity is dimensionless.", listOf("Calculate SG"), listOf("SSC JE • Fluid properties")),
                topic("Viscosity", "Viscosity represents resistance to relative motion between fluid layers.", "τ = μ du/dy", "Dynamic viscosity links shear stress with velocity gradient for a Newtonian fluid.", listOf("Find shear stress"), listOf("RRB JE • Viscosity"))
            )),
            chapter("Bernoulli Equation", 50, listOf(
                topic("Bernoulli's Equation", "Energy equation for steady, incompressible flow along a streamline under stated assumptions.", "P/ρg + V²/2g + z = constant", "Pressure, velocity and elevation heads form the ideal-flow energy balance.", listOf("Apply Bernoulli between two sections"), listOf("SSC JE • Bernoulli equation"))
            ))
        )),
        SubjectContent("Surveying", listOf(
            chapter("Chain Surveying", 45, listOf(
                topic("Principles of Chain Surveying", "Chain surveying is based primarily on linear measurements and triangulation.", "Area by coordinate/offset methods", "Well-conditioned triangles improve survey control.", listOf("Select suitable triangle"), listOf("SSC JE • Chain surveying"))
            )),
            chapter("Levelling", 35, listOf(
                topic("Rise and Fall Method", "A levelling method for computing reduced levels from consecutive staff readings.", "RL(next) = RL(previous) ± rise/fall", "The arithmetic check helps verify the level-book calculations.", listOf("Compute RL from staff readings"), listOf("RRB JE • Levelling"))
            ))
        )),
        SubjectContent("Soil Mechanics", listOf(
            chapter("Index Properties", 50, listOf(
                topic("Void Ratio & Porosity", "Void ratio compares void volume with solid volume; porosity compares void volume with total volume.", "e = Vv/Vs; n = Vv/V", "For the same soil state, e and n are related by n = e/(1+e).", listOf("Convert e to n"), listOf("SSC JE • Index properties"))
            ))
        )),
        SubjectContent("RCC Design", listOf(
            chapter("Limit State Design", 25, listOf(
                topic("Limit States", "Limit state design checks safety against collapse and serviceability requirements.", "Design actions ≤ design resistance", "Partial safety factors account for uncertainties in loads and materials.", listOf("Identify limit state"), listOf("SSC JE • RCC basics"))
            ))
        )),
        SubjectContent("Highway Engineering", listOf(
            chapter("Highway Materials", 20, listOf(
                topic("Bitumen Tests", "Common tests assess consistency and temperature susceptibility of bituminous binders.", "Penetration, ductility, softening point", "Material selection depends on climate, traffic and pavement requirements.", listOf("Match test with property"), listOf("SSC JE • Highway materials"))
            ))
        ))
    )

    fun subject(name: String): SubjectContent? = subjects.firstOrNull { it.name == name }
    fun chapter(subject: String, name: String): ChapterContent? = subject(subject)?.chapters?.firstOrNull { it.name == name }
    fun topic(subject: String, chapter: String, name: String): TopicContent? = chapter(subject, chapter)?.topics?.firstOrNull { it.name == name }
}
