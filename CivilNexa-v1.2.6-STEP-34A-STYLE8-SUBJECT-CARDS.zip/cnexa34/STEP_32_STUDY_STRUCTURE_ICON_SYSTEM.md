# Step 32 — Study Material Structure & Subject Icon System

## Purpose
Refine the Study Material information architecture and visual system before final content entry. Content population remains a later phase.

## Implemented
- Subject-specific premium icons instead of one generic book icon.
- All Subjects / Semester Wise filter affordance.
- Subject cards with chapter count, learning modules, progress bar and percentage.
- Chapter list with chapter number, progress, and Completed / In Progress / Not Started state.
- Existing nested Study bottom-navigation suppression preserved.
- Existing back-stack behavior preserved.
- Existing crystal-clear deep-purple/glass visual language preserved.

## Content policy for next phases
Do not bulk-load final notes, formulas, practice questions, PYQs or test-series content yet. First finish structure, design, navigation, and data schemas. Final content should be entered last, chapter-by-chapter and topic-by-topic.

## Subject icon mapping
Engineering Mechanics → Architecture
Strength of Materials → Straighten
Fluid Mechanics → WaterDrop
Surveying → Explore
Building Materials → Construction
Building Construction → Domain
Concrete Technology → Foundation
Soil Mechanics → Layers
RCC Design → AccountTree
Highway Engineering → AltRoute
Railways → Train
Bridges & Tunnels → Terrain
