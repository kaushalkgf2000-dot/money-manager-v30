# Money Flow V36 — Firebase Account + Cloud Backup

This build keeps local/offline data and adds account-based Firebase backup/restore.

## Firebase Console one-time setup
1. Authentication → Sign-in method → enable **Email/Password**.
2. For Google login, enable **Google** provider.
3. For Google Android login, open Project settings → Your apps → Android app and add the app's **SHA-1** release fingerprint. Download the updated `google-services.json` and replace the copy in `app/` before rebuilding.
4. Firestore Database → Create database.
5. Deploy the `firestore.rules` file from this project.

## Account behavior
- Create Account requires Name, Email, Password and Confirm Password.
- Firebase sends an email verification link after account creation.
- Unverified Email/Password accounts cannot log in to cloud features.
- Forgot Password uses Firebase's password-reset email flow.
- Google Sign-In uses Firebase Authentication and the same cloud-account key (verified email) so the same email can recover the same backup even when the Firebase provider differs.
- Continue as Guest remains available; guest/local data stays on the device until an account is used.

## Automatic cloud behavior
- After a verified Email/Password or Google login, the app automatically checks the account's cloud backup.
- If cloud data exists, it is restored automatically.
- If no cloud backup exists, the current local data is uploaded as the first account backup.
- Later local changes trigger a debounced cloud backup while signed in.
- Manual Backup to Cloud / Restore from Cloud remains available.

## What is stored
- App/profile data and transaction records required to restore the Money Flow workspace.
- PIN, recovery code, PIN hashes and other security credentials are deliberately excluded.

## Important
Firebase email delivery is handled by Firebase. If a verification/reset email is not visible, check Spam/Promotions and the Firebase Authentication email templates/settings. The app only reports success after Firebase accepts the email request.
