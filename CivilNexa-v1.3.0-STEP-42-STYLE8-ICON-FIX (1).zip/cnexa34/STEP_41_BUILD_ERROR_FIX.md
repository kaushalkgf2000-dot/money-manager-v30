# Step 41 — Build Error Fix

## Root cause fixed
The subject icon PNG assets were placed under `res/drawable/subject_icons/`.
Android resource directories are not arbitrary nested folders; the Kotlin code referenced them as `R.drawable.<name>`, so the generated resource symbols were unresolved.

## Fix
All 16 Style-8 subject icon PNGs are now placed directly under `app/src/main/res/drawable/`, matching the existing `R.drawable.*` references in `MainActivity.kt`.

## Subject icons
- strength
- fluid
- surveying
- soil
- rcc
- highway
- railways
- bridges_tunnels
- irrigation
- wastewater
- building_construction
- environmental
- geotechnical
- construction_management
- estimation_costing
- engineering_math

## Version
- Version: 1.2.9
- Version code: 14
- Step: 41

## Verification note
The source/resource mismatch causing the reported unresolved `R.drawable.*` references has been corrected. A full Android/Gradle compile still requires an Android SDK + Gradle environment.
