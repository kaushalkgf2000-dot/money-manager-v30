# PaisaFlow V36 — Firebase Cloud Backup

This build keeps the existing local/offline backup and adds Firebase Cloud Backup as an additional copy.

## Firebase Console one-time setup
1. Open Firebase Console → project **money-flow-c4e7a**.
2. Authentication → Sign-in method → enable **Anonymous** sign-in.
3. Firestore Database → Create database. For production, use locked/production mode.
4. Set Firestore Rules to the contents of `firestore.rules` in this ZIP.

## What is stored in the cloud
- App/profile data and transaction records needed for backup/restore.
- PIN, recovery code, PIN hashes and other security credentials are deliberately excluded from cloud backup.
- Analytics remains separate from backup. Financial amounts are not sent as Analytics events.

## Behavior
- Existing local backup remains available.
- **Backup to Cloud** uploads the current cloud-safe snapshot.
- **Restore from Cloud** downloads the latest snapshot for this Firebase app installation and keeps the existing local security settings.
- Local changes trigger a debounced cloud backup attempt.
- Manual JSON backup/restore remains available.

## Important limitation
This first cloud-backup implementation uses Firebase Anonymous Authentication. It provides cloud storage for the current app installation, but it is not yet a cross-device Google-account login. A later Google Sign-In/Account linking step can make the same backup recoverable on a new phone.


## Firebase Account / Login (added in this build)
1. Firebase Console → Authentication → Sign-in method → Email/Password must be Enabled.
2. The app provides Create Account, Login, Forgot Password, and Sign Out.
3. Cloud Backup now requires a signed-in Firebase account; anonymous sign-in is not used.
4. Cloud backup documents are scoped to the signed-in Firebase UID by the Firestore rules.
5. Existing local backup/recovery and manual backup-file export remain unchanged.

Google Sign-In is intentionally not required for this build. It can be enabled later as a separate provider.
