package com.solveya.offline.ai

import java.util.Locale
import kotlin.math.abs

/**
 * High-confidence deterministic STEM solver.
 *
 * The router intentionally handles only patterns whose variables and units are
 * unambiguous. Everything else is delegated to the local LLM.
 */
object FormulaSolver {
    fun solve(question: String): String? {
        val q = normalize(question)

        // Exact answer-only linear equations such as 2x + 5 = 15.
        solveLinearEquation(q)?.let { return it }

        // Soil phase relation: w, S, e, Gs.
        solveSoilPhaseRelation(q)?.let { return it }

        // Soil phase volumes: V, Vv -> n and e.
        if ((q.contains("total volume") || q.contains("total volume of soil")) &&
            (q.contains("volume of voids") || q.contains("volume of void")) &&
            (q.contains("porosity") || q.contains("void ratio"))) {
            val vt = findNumberAfterAny(q, listOf("total volume", "total volume of soil")) ?: return null
            val vv = findNumberAfterAny(q, listOf("volume of voids", "volume of void")) ?: return null
            if (vt <= 0.0 || vv < 0.0 || vv >= vt) return null

            val vs = vt - vv
            val n = vv / vt
            val e = vv / vs
            return """Given:
Total volume, V = ${fmt(vt)}
Volume of voids, Vv = ${fmt(vv)}

Step 1 — Volume of solids:
Vs = V − Vv = ${fmt(vt)} − ${fmt(vv)} = ${fmt(vs)}

Step 2 — Porosity:
n = Vv / V = ${fmt(vv)} / ${fmt(vt)} = ${fmt(n)}
Porosity = ${fmt(n * 100.0)}%

Step 3 — Void ratio:
e = Vv / Vs = ${fmt(vv)} / ${fmt(vs)} = ${fmt(e)}

Final Answer:
Porosity = ${fmt(n * 100.0)}%
Void ratio = ${fmt(e)}"""
        }

        // Soil: porosity <-> void ratio.
        if (q.contains("porosity") && q.contains("void ratio")) {
            val e = findNumber(q, "void ratio")
            if (e != null && e >= 0.0) {
                val n = e / (1.0 + e)
                return "Given: e = ${fmt(e)}\n\nFormula: n = e / (1 + e)\n\nCalculation: n = ${fmt(e)} / (1 + ${fmt(e)}) = ${fmt(n)}\n\nFinal Answer: Porosity = ${fmt(n * 100.0)}%"
            }
            val nRaw = findNumber(q, "porosity")
            if (nRaw != null) {
                val n = if (nRaw > 1.0) nRaw / 100.0 else nRaw
                if (n in 0.0..0.999999999) {
                    val e = n / (1.0 - n)
                    return "Given: n = ${fmt(n)}\n\nFormula: e = n / (1 − n)\n\nCalculation: e = ${fmt(n)} / (1 − ${fmt(n)}) = ${fmt(e)}\n\nFinal Answer: e = ${fmt(e)}"
                }
            }
        }

        // Soil: dry unit weight / void ratio inverse pair.
        if (q.contains("dry unit weight") &&
            (q.contains("specific gravity") || q.contains("gs"))) {
            val gs = findNumber(q, "specific gravity")
                ?: findNumberAfterAny(q, listOf("gs =", "gs=", "gs ")) ?: return null
            val gammaW = findNumber(q, "unit weight of water")
                ?: findNumberAfterAny(q, listOf("γw", "gw =", "gammaw")) ?: 9.81
            if (gs <= 0.0 || gammaW <= 0.0) return null

            val suppliedE = findExplicitVariable(q, 'e')
                ?: findNumberNearLabel(q, "void ratio")
            val gammaD = findNumberNearLabel(q, "dry unit weight")
                ?: findExplicitVariable(q, 'd')
                ?: findNumberAfterAny(q, listOf("γd =", "γd:", "gd =", "gammad ="))

            if (suppliedE != null && suppliedE >= 0.0) {
                val calculatedGammaD = gs * gammaW / (1.0 + suppliedE)
                return """Given:
e = ${fmt(suppliedE)}
Gs = ${fmt(gs)}
γw = ${fmt(gammaW)} kN/m³

Formula:
γd = (Gs × γw) / (1 + e)

Calculation:
γd = (${fmt(gs)} × ${fmt(gammaW)}) / (1 + ${fmt(suppliedE)})
γd = ${fmt(calculatedGammaD)} kN/m³

Final Answer: γd = ${fmt(calculatedGammaD)} kN/m³"""
            }

            if (gammaD != null && gammaD > 0.0) {
                val e = gs * gammaW / gammaD - 1.0
                if (e >= -1e-9) {
                    return """Given:
γd = ${fmt(gammaD)} kN/m³
Gs = ${fmt(gs)}
γw = ${fmt(gammaW)} kN/m³

Formula:
e = (Gs × γw / γd) − 1

Calculation:
e = (${fmt(gs)} × ${fmt(gammaW)} / ${fmt(gammaD)}) − 1
e = ${fmt(e)}

Final Answer: e = ${fmt(e)}"""
                }
            }
        }

        // Saturated/submerged unit weight.
        if ((q.contains("saturated unit weight") || q.contains("saturated") && q.contains("unit weight")) &&
            (q.contains("void ratio") || q.contains("e =") || q.contains("e=")) &&
            (q.contains("specific gravity") || q.contains("gs"))) {
            val e = findExplicitVariable(q, 'e') ?: findNumberNearLabel(q, "void ratio") ?: return null
            val gs = findNumber(q, "specific gravity") ?: findNumberAfterAny(q, listOf("gs =", "gs=", "gs ")) ?: return null
            val gammaW = findNumber(q, "unit weight of water") ?: findNumberAfterAny(q, listOf("γw", "gw =", "gammaw")) ?: 9.81
            if (e < 0.0 || gs <= 0.0 || gammaW <= 0.0) return null
            val gammaSat = ((gs + e) / (1.0 + e)) * gammaW
            return """Given:
e = ${fmt(e)}
Gs = ${fmt(gs)}
γw = ${fmt(gammaW)} kN/m³

Formula:
γsat = ((Gs + e) / (1 + e)) × γw

Calculation:
γsat = ((${fmt(gs)} + ${fmt(e)}) / (1 + ${fmt(e)})) × ${fmt(gammaW)}
γsat = ${fmt(gammaSat)} kN/m³

Final Answer: γsat = ${fmt(gammaSat)} kN/m³"""
        }

        if ((q.contains("submerged unit weight") || q.contains("buoyant unit weight")) &&
            (q.contains("void ratio") || q.contains("e =")) &&
            (q.contains("specific gravity") || q.contains("gs"))) {
            val e = findExplicitVariable(q, 'e') ?: findNumberNearLabel(q, "void ratio") ?: return null
            val gs = findNumber(q, "specific gravity") ?: findNumberAfterAny(q, listOf("gs =", "gs=", "gs ")) ?: return null
            val gammaW = findNumber(q, "unit weight of water") ?: findNumberAfterAny(q, listOf("γw", "gw =", "gammaw")) ?: 9.81
            if (e < 0.0 || gs <= 1.0 || gammaW <= 0.0) return null
            val gammaSub = ((gs - 1.0) / (1.0 + e)) * gammaW
            return "Given:\ne = ${fmt(e)}\nGs = ${fmt(gs)}\nγw = ${fmt(gammaW)} kN/m³\n\nFormula:\nγsub = ((Gs − 1) / (1 + e)) × γw\n\nCalculation:\nγsub = ((${fmt(gs)} − 1) / (1 + ${fmt(e)})) × ${fmt(gammaW)}\nγsub = ${fmt(gammaSub)} kN/m³\n\nFinal Answer: γsub = ${fmt(gammaSub)} kN/m³"
        }

        // Darcy: distinguish discharge velocity from total discharge.
        if (q.contains("darcy") || q.contains("darcy's law")) {
            val k = findScientificNumberAfter(q, "permeability")
                ?: findScientificNumberAfter(q, "coefficient of permeability")
                ?: findScientificNumberAfter(q, "k =")
                ?: findScientificNumberAfter(q, "k=")
                ?: findNumberAfterAny(q, listOf("permeability", "coefficient of permeability", "k =", "k="))
            val i = findNumberAfterAny(q, listOf("hydraulic gradient", "gradient", "i =", "i="))
            if (k != null && i != null && k >= 0.0 && i >= 0.0) {
                val area = findNumberAfterAny(q, listOf("cross-sectional area", "cross sectional area", "area", "a =", "a="))
                val asksQ = q.contains("discharge") || q.contains("flow rate") || q.contains("quantity of water") || q.contains("q =")
                if (asksQ && area != null && area > 0.0) {
                    val discharge = k * i * area
                    return "Given:\nk = ${fmtSci(k)} m/s\ni = ${fmt(i)}\nA = ${fmt(area)} m²\n\nDarcy's law:\nQ = k i A\n\nCalculation:\nQ = ${fmtSci(k)} × ${fmt(i)} × ${fmt(area)}\nQ = ${fmtSci(discharge)} m³/s\n\nFinal Answer: Q = ${fmtSci(discharge)} m³/s"
                }
                if (!asksQ || q.contains("discharge velocity") || q.contains("darcy velocity") || q.contains("velocity of flow")) {
                    val v = k * i
                    return "Given:\nk = ${fmtSci(k)} m/s\ni = ${fmt(i)}\n\nDarcy's law:\nv = k i\n\nv = ${fmtSci(k)} × ${fmt(i)}\nv = ${fmtSci(v)} m/s\n\nFinal Answer: v = ${fmtSci(v)} m/s"
                }
            }
        }

        // Common high-frequency Civil/Physics numericals.
        solveBasicEngineering(q)?.let { return it }

        return null
    }

    private fun solveSoilPhaseRelation(q: String): String? {
        val hasSoilVars = q.contains("void ratio") || q.contains("specific gravity") || q.contains("degree of saturation") || q.contains("water content")
        if (!hasSoilVars) return null

        val wRaw = findNumber(q, "water content")
        val gs = findNumber(q, "specific gravity") ?: findNumberAfterAny(q, listOf("gs =", "gs=", "gs "))
        val sRaw = findNumber(q, "degree of saturation") ?: findNumberAfterAny(q, listOf("saturation", "s =", "s="))
        val e = findNumber(q, "void ratio") ?: findNumberAfterAny(q, listOf("e =", "e="))
        val w = wRaw?.let { if (it > 1.0) it / 100.0 else it }
        val s = sRaw?.let { if (it > 1.0) it / 100.0 else it }

        if (w != null && gs != null && s != null && s > 0.0 && gs > 0.0 && q.contains("void ratio")) {
            val value = w * gs / s
            return "Given:\nw = ${fmt(w)}\nGs = ${fmt(gs)}\nS = ${fmt(s)}\n\nFormula:\ne = wGs / S\n\nCalculation:\ne = (${fmt(w)} × ${fmt(gs)}) / ${fmt(s)}\ne = ${fmt(value)}\n\nFinal Answer: e = ${fmt(value)}"
        }
        if (w != null && gs != null && e != null && e > 0.0 && q.contains("degree of saturation")) {
            val value = w * gs / e
            return "Given:\nw = ${fmt(w)}\nGs = ${fmt(gs)}\ne = ${fmt(e)}\n\nFormula:\nS = wGs / e\n\nCalculation:\nS = (${fmt(w)} × ${fmt(gs)}) / ${fmt(e)}\nS = ${fmt(value)} = ${fmt(value * 100.0)}%\n\nFinal Answer: Degree of saturation = ${fmt(value * 100.0)}%"
        }
        if (s != null && gs != null && e != null && gs > 0.0 && e >= 0.0 && q.contains("water content")) {
            val value = s * e / gs
            return "Given:\nS = ${fmt(s)}\nGs = ${fmt(gs)}\ne = ${fmt(e)}\n\nFormula:\nw = Se / Gs\n\nCalculation:\nw = (${fmt(s)} × ${fmt(e)}) / ${fmt(gs)}\nw = ${fmt(value)} = ${fmt(value * 100.0)}%\n\nFinal Answer: Water content = ${fmt(value * 100.0)}%"
        }
        if (w != null && gs != null && q.contains("fully saturated") && q.contains("void ratio")) {
            val value = w * gs
            return "Given:\nw = ${fmt(w)}\nGs = ${fmt(gs)}\nS = 1.0\n\nFormula:\ne = wGs\n\nFinal Answer: e = ${fmt(value)}"
        }
        return null
    }

    private fun solveBasicEngineering(q: String): String? {
        // Density: ρ = m/V.
        if (q.contains("density") && q.contains("mass") && q.contains("volume")) {
            val m = findNumberAfterAny(q, listOf("mass", "m =", "m=")) ?: return null
            val v = findNumberAfterAny(q, listOf("volume", "v =", "v=")) ?: return null
            if (m > 0.0 && v > 0.0) {
                val rho = m / v
                return "Given:\nm = ${fmt(m)}\nV = ${fmt(v)}\n\nFormula:\nρ = m / V\n\nFinal Answer: ρ = ${fmt(rho)}"
            }
        }
        // Stress: σ = P/A.
        if (q.contains("stress") && (q.contains("load") || q.contains("force")) && q.contains("area")) {
            val p = findNumberAfterAny(q, listOf("load", "force", "p =", "p=")) ?: return null
            val a = findNumberAfterAny(q, listOf("area", "a =", "a=")) ?: return null
            if (a > 0.0) {
                val stress = p / a
                return "Given:\nLoad/force = ${fmt(p)}\nArea = ${fmt(a)}\n\nFormula:\nσ = P / A\n\nFinal Answer: σ = ${fmt(stress)}"
            }
        }
        // Hydraulic power: P = ρgQH.
        if (q.contains("hydraulic power") && q.contains("discharge") && q.contains("head")) {
            val rho = findNumberAfterAny(q, listOf("density", "rho")) ?: 1000.0
            val g = findNumberAfterAny(q, listOf("gravity", "g =", "g=")) ?: 9.81
            val qv = findNumberAfterAny(q, listOf("discharge", "flow rate", "q =", "q=")) ?: return null
            val h = findNumberAfterAny(q, listOf("head", "h =", "h=")) ?: return null
            if (rho > 0 && g > 0 && qv > 0 && h > 0) {
                val power = rho * g * qv * h
                return "Formula:\nP = ρgQH\n\nCalculation:\nP = ${fmt(rho)} × ${fmt(g)} × ${fmt(qv)} × ${fmt(h)}\nP = ${fmt(power)} W\n\nFinal Answer: P = ${fmt(power)} W"
            }
        }
        return null
    }

    private fun solveLinearEquation(q: String): String? {
        if (!q.contains("=") || !Regex("[a-z]").containsMatchIn(q)) return null
        val cleaned = q
            .replace("find x", "")
            .replace("find y", "")
            .replace("solve for x", "")
            .replace("solve for y", "")
            .trim()
        val eq = Regex("([0-9x y+\\-*/().]+)\\s*=\\s*([0-9x y+\\-*/().]+)").find(cleaned) ?: return null
        val left = eq.groupValues[1].replace(" ", "")
        val right = eq.groupValues[2].replace(" ", "").trimEnd('.')
        val variable = when {
            left.contains('x') || right.contains('x') -> 'x'
            left.contains('y') || right.contains('y') -> 'y'
            else -> return null
        }
        if (left.count { it == variable } != 1 || right.count { it == variable } > 1) return null

        fun sideCoefficients(expr: String): Pair<Double, Double>? {
            var s = expr.replace("-", "+-")
            if (s.startsWith("+")) s = s.drop(1)
            val terms = s.split('+').filter { it.isNotBlank() }
            var a = 0.0
            var b = 0.0
            for (term0 in terms) {
                val term = term0.trim()
                if (term.count { it == variable } > 1) return null
                if (term.contains(variable)) {
                    val coefficient = term.replace(variable.toString(), "").let {
                        when (it) { "", "+" -> 1.0; "-" -> -1.0; else -> it.toDoubleOrNull() }
                    } ?: return null
                    a += coefficient
                } else {
                    b += term.toDoubleOrNull() ?: return null
                }
            }
            return a to b
        }

        val (aL, bL) = sideCoefficients(left) ?: return null
        val (aR, bR) = sideCoefficients(right) ?: return null
        val coefficient = aL - aR
        val constant = bR - bL
        if (abs(coefficient) < 1e-12) return null
        val value = constant / coefficient
        val result = "$variable = ${fmt(value)}"
        return if (q.contains("answer only")) result else "Final Answer: $result"
    }

    private fun normalize(question: String): String = question
        .lowercase(Locale.US)
        .replace("γw", " γw ")
        .replace("gamma w", " gammaw ")
        .replace("specific gravity (gs)", "specific gravity")
        .replace("specific gravity, gs", "specific gravity")
        .replace("void ratio (e)", "void ratio")
        .replace("void ratio, e", "void ratio")
        .replace("degree of saturation (s)", "degree of saturation")
        .replace("degree of saturation, s", "degree of saturation")
        .replace("×", "*")

    private fun findExplicitVariable(q: String, variable: Char): Double? {
        val pattern = Regex("(?<![a-z])" + Regex.escape(variable.toString()) + "\\s*=\\s*([-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)")
        return pattern.find(q)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
    }

    private fun findNumberNearLabel(q: String, label: String): Double? {
        val idx = q.indexOf(label)
        if (idx < 0) return null
        val tail = q.substring((idx + label.length).coerceAtMost(q.length))
        val match = Regex("^\\s*(?:(?:of|is)\\s+|[:=]\\s*)?([-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)").find(tail)
        return match?.groupValues?.getOrNull(1)?.toDoubleOrNull()
    }

    private fun findNumberAfterAny(q: String, labels: List<String>): Double? {
        for (label in labels) findNumber(q, label)?.let { return it }
        return null
    }

    private fun findNumber(q: String, label: String): Double? {
        val idx = q.indexOf(label)
        if (idx < 0) return null
        val tail = q.substring(idx, (idx + 140).coerceAtMost(q.length))
        return Regex("[-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?").find(tail)?.value?.toDoubleOrNull()
    }

    private fun findScientificNumberAfter(q: String, label: String): Double? {
        val idx = q.indexOf(label)
        if (idx < 0) return null
        val tail = q.substring(idx, (idx + 160).coerceAtMost(q.length))
        val match = Regex("([-+]?\\d+(?:\\.\\d+)?)\\s*(?:×|x|\\*)\\s*10\\s*\\^?\\s*([-+]?\\d+)").find(tail)
            ?: Regex("([-+]?\\d+(?:\\.\\d+)?)e([-+]?\\d+)").find(tail)
        return match?.let { it.groupValues[1].toDoubleOrNull()?.times(10.0.pow(it.groupValues[2].toInt())) }
    }

    private fun percentOrDecimal(value: Double?): Double? = value?.let { if (it > 1.0) it / 100.0 else it }

    private fun fmt(v: Double): String = when {
        abs(v - v.toLong()) < 1e-10 -> v.toLong().toString()
        else -> String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    private fun fmtSci(v: Double): String {
        if (v == 0.0) return "0"
        return String.format(Locale.US, "%.3E", v).replace("E+", " × 10^").replace("E-", " × 10^-")
    }

    private fun Double.pow(n: Int): Double = Math.pow(this, n.toDouble())
}
