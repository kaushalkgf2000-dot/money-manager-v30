# Solveya — Phase 3.0 Accuracy Engine

## v0.3.0 — Soil Numerical Accuracy Hotfix

- Adds a deterministic dry-unit-weight solver before LLM inference.
- Correct relation enforced: γd = Gs·γw/(1+e).
- Prevents the previous incorrect substitution of (Gs + e) for dry unit weight.
- Uses γw = 9.81 kN/m³ when the question does not provide a different value.
- Keeps the existing saturated unit-weight solver: γsat = (Gs+e)γw/(1+e).
- Keeps the water-content/saturation/void-ratio solver: e = wGs/S.
- Keeps automatic model recovery and low-latency inference for questions not handled deterministically.

### Validation target

Question:
A soil has a void ratio of 0.75 and specific gravity of solids 2.70. Calculate its dry unit weight. Take γw = 9.81 kN/m³.

Expected:
γd = (2.70 × 9.81)/(1 + 0.75) = 15.135 kN/m³ ≈ 15.14 kN/m³.

# Solveya — Phase 2: Real Offline AI Core



This phase replaces the placeholder AI with the LiteRT-LM Android runtime.

## Product identity

- App: Solveya
- Scope: Class 8–10 Maths + Science
- Priority: Class 9–10
- Architecture: Offline-first
- Current AI candidate: Gemma 4 E2B LiteRT-LM
- Current runtime: LiteRT-LM Android 0.16.1
- Current backend for first validation: CPU

## Phase 2 milestone

Text question
→ local `.litertlm` model
→ on-device conversation
→ response

The model is intentionally NOT bundled in this ZIP because it is a multi-gigabyte model artifact with its own license/distribution terms. The app checks its private model directory for:

`gemma-4-E2B-it.litertlm`

## Important device note

The official LiteRT-LM model registry currently lists Gemma 4 E2B at about 2.59 GB and a minimum device memory requirement of 8 GB. The model is multimodal and supports image input, which will be useful for the later Camera/Gallery milestone.

For the first phone validation we use CPU to avoid GPU-driver-specific failures. GPU/NPU acceleration can be benchmarked after the CPU path is proven.

## Phase 2.3 — Solveya Tutor layer

## Phase 2.3.1 — Math/LaTeX display cleanup

- Converts common `\frac{a}{b}` expressions into readable `a/b` form.
- Converts common Greek symbols and operators to Unicode equivalents.
- Converts simple powers/subscripts to readable Unicode characters.
- Removes leftover Markdown/LaTeX wrappers so students do not see raw commands such as `\frac`, `\text`, or `\sigma`.
- Keeps the implementation dependency-free for offline use.


This build keeps the validated offline model path intact and adds a lightweight tutor/response layer.

- Stronger educational system instruction for Maths + Science.
- Explicit handling for “answer only” requests.
- Phone-friendly plain-text math output.
- Cleanup of common Markdown/LaTeX wrappers such as `$x = 5$`.
- Cleaner answer card in the UI.
- Existing model import/load flow remains unchanged.

## Next milestone

1. Put the model file in the app's model directory.
2. Initialize it.
3. Run `2x + 5 = 15`.
4. Confirm the response with Airplane Mode ON.
5. Then build the deterministic Math Engine and connect it as a tool/router.
6. After that: Camera → Gallery → Science.

## Source

LiteRT-LM Kotlin API documentation:
https://github.com/google-ai-edge/LiteRT-LM/blob/main/docs/api/kotlin/getting_started.md


## Build fix — Phase 2.1

The previous build failed in `LiteRtLmEngine.kt` because `Conversation.sendMessage()` returns a
`Message`, not an object with a `.text` property. The current LiteRT-LM Kotlin API exposes the
message text through `Message.toString()` / its `contents`.

Fixed:
- `response.text` → `response.toString()`
- Root project name → `Solveya`

This change addresses the exact compiler error shown in the supplied build video.


## Phase 2.2 — Model Test Layer

This build adds a safe, explicit local-model workflow:

1. Select a `.litertlm` model file with Android's document picker.
2. Solveya copies it into its private model directory.
3. Press **LOAD MODEL** to initialize LiteRT-LM on a background coroutine.
4. When the status becomes **OFFLINE AI READY**, the text question button becomes active.
5. Test inference with internet disabled.

The model is intentionally not bundled in the APK because the official Gemma 4 E2B LiteRT-LM file is about 2.59 GB and the official model allowlist specifies an 8 GB minimum device-memory requirement.

The first target remains Gemma 4 E2B. The official LiteRT-LM Kotlin documentation shows `Engine(modelPath=...)`, `initialize()`, `createConversation()`, and `sendMessage()` for Android/JVM.

The selected model is copied to private app storage because LiteRT-LM requires a filesystem model path. This also avoids requiring broad storage permissions.

## Phase 2.4 Global Accuracy & Verification — v0.2.4

Changes in this build:
- Stronger offline tutor instruction for numerical verification and standard Civil Engineering formulas.
- Model temperature reduced for more deterministic answers.
- Expanded LaTeX/Markdown sanitisation: dollar delimiters, \frac/\dfrac/\tfrac, \text/\mathrm, roots, Greek symbols, powers, subscripts, and common operators.
- Plain-text/Unicode math is enforced for phone readability.
- Version bumped to 0.2.3 (versionCode 5).


## Phase 2.4 — Global Accuracy & Verification

This build applies accuracy controls globally rather than patching individual questions:
- Broader STEM scope: Mathematics, Physics, Chemistry, and Civil Engineering.
- Explicit formula selection, dimensional/unit checks, arithmetic verification, and sanity checks.
- Ambiguity/missing-data handling without guessing.
- Standard textbook conventions for Civil Engineering, including correct distinctions between related formula forms.
- A second local verification pass reviews every generated answer before it is shown to the student.
- Existing offline model loading and phone-friendly response formatting remain intact.

Version: 0.2.4 (versionCode 6)


## v0.2.8 — Accuracy + Latency tuning

- Adds bounded reasoning (96 tokens) and a 384-token output cap to reduce mobile latency.
- Uses deterministic low-temperature sampling with a fixed seed.
- Adds concise formula hints for Soil Mechanics, Darcy flow, Bernoulli, and camber questions.
- Explicitly prioritizes the standard soil relationships including e = w Gs / S.
- Keeps one inference per question and automatic engine recovery on native task failure.

The LiteRT-LM Kotlin API supports conversation-level output-token and thinking configuration; these controls are used here to bound generation cost.


## Phase 3.1 — Soil multi-step accuracy
- Added deterministic multi-step solver for total volume + volume of voids questions.
- Computes Vs first, then porosity and void ratio without delegating to the LLM.
- Prevents incomplete answers on the Phase 3.0 Test 5 pattern.
- Version: 0.3.1 / versionCode 13.
