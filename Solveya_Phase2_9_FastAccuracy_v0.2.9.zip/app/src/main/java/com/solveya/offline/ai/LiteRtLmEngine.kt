package com.solveya.offline.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Stable, low-latency wrapper around the local LiteRT-LM engine.
 *
 * Design goals:
 *  - One inference pass per question (the previous self-review pass doubled latency).
 *  - A fresh conversation per question so context does not grow across questions.
 *  - Serialised requests so two native inference jobs cannot overlap.
 *  - One automatic engine recovery/retry after a native task failure, so the user
 *    does not have to manually re-import the model.
 */
class LiteRtLmEngine(
    private val context: Context
) {
    private var engine: Engine? = null
    private val requestMutex = Mutex()

    suspend fun initialize(): Result<Unit> = withContext(Dispatchers.IO) {
        requestMutex.withLock {
            runCatching { initializeInternal() }
        }
    }

    private fun initializeInternal() {
        LocalModelManager.ensureModelDirectory(context)

        val model = LocalModelManager.modelFile(context)
        require(model.exists() && model.length() > 0L) {
            "Offline model not installed. Add ${LocalModelManager.MODEL_FILE_NAME} to the app model directory first."
        }

        closeInternal()

        val config = EngineConfig(
            modelPath = model.absolutePath,
            backend = Backend.CPU(),
            cacheDir = context.cacheDir.absolutePath
        )

        val newEngine = Engine(config)
        newEngine.initialize()
        engine = newEngine
    }

    suspend fun ask(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        requestMutex.withLock {
            runCatching {
                FormulaSolver.solve(prompt)?.let { return@runCatching it }
                val activeEngine = engine
                    ?: error("Offline AI is not initialized.")

                try {
                    runSingleInference(activeEngine, prompt)
                } catch (firstFailure: Throwable) {
                    // Native task failures can leave the current engine state unusable.
                    // Recover the engine in-process and retry once; no model re-import is needed.
                    closeInternal()
                    initializeInternal()
                    val recoveredEngine = engine
                        ?: throw firstFailure
                    runSingleInference(recoveredEngine, prompt)
                }
            }
        }
    }

    private fun runSingleInference(activeEngine: Engine, prompt: String): String {
        val conversation = activeEngine.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(SYSTEM_INSTRUCTION),
                samplerConfig = SamplerConfig(
                    // Lower sampling overhead while keeping deterministic STEM answers.
                    topK = 24,
                    topP = 0.85,
                    temperature = 0.10,
                    seed = 0
                ),
                // Keep reasoning bounded so simple questions do not spend most of their
                // time generating hidden reasoning tokens. Hard questions still get a
                // small reasoning budget.
                thinkingConfig = ThinkingConfig(
                    enableThinking = true,
                    thinkingTokenBudget = 32
                ),
                // Prevent very long answers from dominating latency on a phone.
                maxOutputToken = 240
            )
        )

        return try {
            val response = conversation.sendMessage(
                """
                Answer the student's question below.
                Use the accuracy hints when they apply. Think briefly through formula, units, arithmetic, and final result before responding.
                Do not guess missing information. Do not invent equations.
                Follow the student's requested answer format and stay concise.

                ACCURACY HINTS:
                ${accuracyHints(prompt)}

                STUDENT QUESTION:
                $prompt
                """.trimIndent()
            )

            response.toString().trim().ifBlank {
                error("The offline model returned an empty answer.")
            }
        } finally {
            runCatching { conversation.close() }
        }
    }

    private fun accuracyHints(question: String): String {
        val q = question.lowercase()
        val hints = mutableListOf<String>()

        if (listOf("void ratio", "porosity", "water content", "degree of saturation", "specific gravity", "soil").any { it in q }) {
            hints += "Soil relations: w = S·e/Gs; e = w·Gs/S; S = w·Gs/e; n = e/(1+e); e = n/(1−n); γd = Gs·γw/(1+e); γsat = (Gs+e)·γw/(1+e); γsub = (Gs−1)·γw/(1+e)."
        }
        if (listOf("darcy", "permeability", "hydraulic gradient", "coefficient of permeability").any { it in q }) {
            hints += "Darcy: discharge velocity v = k·i; total discharge Q = k·i·A. Do not omit A when Q is requested."
        }
        if (listOf("bernoulli", "velocity head", "pressure head").any { it in q }) {
            hints += "Bernoulli head form: P/γ + V²/(2g) + z = constant."
        }
        if (listOf("camber", "road drainage").any { it in q }) {
            hints += "Road camber is the transverse slope provided primarily for surface-water drainage."
        }
        return if (hints.isEmpty()) "No special formula hint; derive from the supplied data and standard principles." else hints.joinToString(" ")
    }

    private companion object {
        const val SYSTEM_INSTRUCTION = """
            You are Solveya, a rigorous offline STEM study tutor for diploma/JE-level students.

            COVERAGE: Mathematics, Physics, Chemistry, and Civil Engineering including Engineering Mechanics, Strength of Materials, Fluid Mechanics, Hydraulics, Soil Mechanics, Foundation Engineering, Surveying, RCC, Transportation, Environmental Engineering, Building Materials/Construction, and related topics.

            ACCURACY RULES — apply to every question:
            1. Parse exactly what is asked: quantity, given data, conditions, units, and requested format.
            2. Select the standard textbook equation/principle. Never invent a formula or force data to fit one.
            3. Convert units consistently and check dimensional consistency.
            4. Substitute values carefully and re-check arithmetic before the final answer.
            5. Sanity-check sign, magnitude, limiting behaviour, and whether the result answers the requested quantity.
            6. For theory, give the correct definition, equation (when applicable), assumptions, units, and key explanation without fabrication.
            7. For Civil Engineering, prefer standard Indian diploma/JE textbook conventions. If multiple conventions exist, state the convention used.
            8. Important guardrails: Darcy soil flow v = k i and Q = k i A; Bernoulli P/γ + V²/(2g) + z = constant; stress σ = P/A; n = e/(1+e); e = n/(1−n).
            9. Soil-mechanics relationships must be selected from the variables actually given. For water content w, degree of saturation S, specific gravity Gs, and void ratio e: w = S e / Gs, therefore e = w Gs / S. Also S = w Gs / e; n = e/(1+e); e = n/(1−n); γd = Gs γw/(1+e); γsat = (Gs+e)γw/(1+e); γsub = (Gs−1)γw/(1+e). Never substitute n for e or S for e.
            10. For soil-flow numericals, distinguish Darcy discharge velocity v = k i from total discharge Q = k i A. Keep k in m/s, i dimensionless, A in m², and Q in m³/s.
            11. Treat engineering coefficients with their actual units.
            12. If information is insufficient or ambiguous, say what is missing instead of guessing.
            13. Re-derive/check the result from the supplied data; do not blindly repeat a remembered answer.

            RESPONSE RULES:
            - Respect “answer only” requests and output only the final answer.
            - For step-by-step questions, use numbered steps with formula, substitution, calculation, and final answer.
            - For theory questions, be concise but technically complete.
            - Match the student's language (English/Hindi/Hinglish).
            - Never output LaTeX delimiters, raw LaTeX commands, or dollar-sign math. Use readable plain text/Unicode such as σ, ρ, γ, V², a/b.
"""
    }

    fun close() {
        closeInternal()
    }

    private fun closeInternal() {
        runCatching { engine?.close() }
        engine = null
    }
}
