package com.solveya.offline.ai

/**
 * Normalises common Markdown/LaTeX emitted by a small local model into
 * readable, phone-friendly plain text. No rendering dependency is required.
 */
object ResponseFormatter {
    fun clean(raw: String): String {
        var text = raw.trim()

        // Remove fenced-code wrappers and common math delimiters.
        text = text
            .replace(Regex("```(?:text|markdown|latex|tex)?\\s*", RegexOption.IGNORE_CASE), "")
            .replace("```", "")
            .replace("\\[", "")
            .replace("\\]", "")
            .replace("\\(", "")
            .replace("\\)", "")
            .replace("$$", "")
            .replace("$", "")

        // Normalise LaTeX commands before stripping the remaining backslashes.
        text = convertFractions(text)
        text = convertTextCommands(text)
        text = text
            .replace("\\left", "")
            .replace("\\right", "")
            .replace("\\displaystyle", "")
            .replace("\\,", " ")
            .replace("\\;", " ")
            .replace("\\:", " ")
            .replace("\\!", "")
            .replace("\\quad", " ")
            .replace("\\qquad", " ")

        // Greek letters, operators and common mathematical symbols.
        val symbols = linkedMapOf(
            "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\delta" to "δ",
            "\\epsilon" to "ε", "\\varepsilon" to "ε", "\\theta" to "θ", "\\vartheta" to "θ",
            "\\lambda" to "λ", "\\mu" to "μ", "\\pi" to "π", "\\rho" to "ρ",
            "\\sigma" to "σ", "\\tau" to "τ", "\\phi" to "φ", "\\varphi" to "φ",
            "\\omega" to "ω", "\\Delta" to "Δ", "\\Gamma" to "Γ", "\\Theta" to "Θ",
            "\\Lambda" to "Λ", "\\Pi" to "Π", "\\Sigma" to "Σ", "\\Omega" to "Ω",
            "\\times" to "×", "\\cdot" to "·", "\\pm" to "±", "\\mp" to "∓",
            "\\leq" to "≤", "\\le" to "≤", "\\geq" to "≥", "\\ge" to "≥",
            "\\neq" to "≠", "\\approx" to "≈", "\\equiv" to "≡", "\\infty" to "∞",
            "\\degree" to "°", "\\circ" to "°", "\\rightarrow" to "→", "\\to" to "→",
            "\\therefore" to "∴", "\\propto" to "∝", "\\div" to "÷", "\\sum" to "Σ"
        )
        for ((latex, replacement) in symbols) {
            text = text.replace(latex, replacement)
        }

        // Simple roots and remaining grouped expressions.
        text = convertSqrt(text)
        text = text.replace(Regex("\\{([^{}]*)\\}"), "$1")

        // Markdown emphasis/backticks should never leak into the final answer.
        text = text
            .replace(Regex("\\*\\*(.*?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "$1")
            .replace(Regex("__(.*?)__", RegexOption.DOT_MATCHES_ALL), "$1")
            .replace(Regex("\\*([^*\\n]+)\\*"), "$1")
            .replace(Regex("`([^`]+)`"), "$1")

        // Convert superscripts/subscripts to Unicode where possible.
        text = replaceSuperscripts(text)
        text = replaceSubscripts(text)

        // Clean common model artifacts and any unsupported LaTeX control word.
        text = text
            .replace(Regex("\\\\[a-zA-Z]+"), "")
            .replace(Regex("\\\\[{}]"), "")
            .replace(Regex("[ \\t]+\\n"), "\\n")
            .replace(Regex("\\n{3,}"), "\\n\\n")
            .replace(Regex(" {2,}"), " ")
            .trim()

        // Make a few common engineering expressions consistently readable.
        text = normaliseCommonEngineeringNotation(text)

        return text.ifBlank { "Solveya could not generate an answer." }
    }

    private fun convertFractions(input: String): String {
        var text = input
        var start = findFractionCommand(text)
        while (start >= 0) {
            val commandLength = when {
                text.startsWith("\\dfrac", start) -> 6
                text.startsWith("\\tfrac", start) -> 6
                else -> 5 // \frac
            }
            var cursor = start + commandLength
            while (cursor < text.length && text[cursor].isWhitespace()) cursor++
            val numerator = readBracedGroup(text, cursor)
            if (numerator == null) {
                start = findFractionCommand(text, start + commandLength)
                continue
            }
            cursor = numerator.second
            while (cursor < text.length && text[cursor].isWhitespace()) cursor++
            val denominator = readBracedGroup(text, cursor)
            if (denominator == null) {
                start = findFractionCommand(text, start + commandLength)
                continue
            }

            // Recursively clean nested fractions inside each side.
            val num = convertFractions(numerator.first)
            val den = convertFractions(denominator.first)
            val replacement = "$num/$den"
            text = text.substring(0, start) + replacement + text.substring(denominator.second)
            start = findFractionCommand(text, start + replacement.length)
        }
        return text
    }

    private fun findFractionCommand(text: String, from: Int = 0): Int {
        val candidates = listOf("\\frac", "\\dfrac", "\\tfrac")
        var best = -1
        for (candidate in candidates) {
            val index = text.indexOf(candidate, from)
            if (index >= 0 && (best < 0 || index < best)) best = index
        }
        return best
    }

    /** Returns content and the index immediately after the closing brace. */
    private fun readBracedGroup(text: String, openIndex: Int): Pair<String, Int>? {
        if (openIndex >= text.length || text[openIndex] != '{') return null
        var depth = 0
        for (index in openIndex until text.length) {
            when (text[index]) {
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) return text.substring(openIndex + 1, index) to (index + 1)
                }
            }
        }
        return null
    }

    private fun convertTextCommands(input: String): String {
        var text = input
        val commands = listOf("text", "mathrm", "mathbf", "mathit", "mathsf", "operatorname")
        for (command in commands) {
            var index = text.indexOf("\\$command")
            while (index >= 0) {
                var cursor = index + command.length + 1
                while (cursor < text.length && text[cursor].isWhitespace()) cursor++
                val group = readBracedGroup(text, cursor)
                if (group == null) {
                    index = text.indexOf("\\$command", index + command.length + 1)
                    continue
                }
                text = text.substring(0, index) + group.first + text.substring(group.second)
                index = text.indexOf("\\$command", index + group.first.length)
            }
        }
        return text
    }

    private fun convertSqrt(input: String): String {
        var text = input
        var index = text.indexOf("\\sqrt")
        while (index >= 0) {
            var cursor = index + 5
            while (cursor < text.length && text[cursor].isWhitespace()) cursor++
            val group = readBracedGroup(text, cursor)
            if (group == null) {
                index = text.indexOf("\\sqrt", index + 5)
                continue
            }
            val replacement = "√(${convertFractions(group.first)})"
            text = text.substring(0, index) + replacement + text.substring(group.second)
            index = text.indexOf("\\sqrt", index + replacement.length)
        }
        return text
    }

    private fun replaceSuperscripts(input: String): String {
        val superscript = mapOf(
            '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴',
            '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹',
            '+' to '⁺', '-' to '⁻', 'n' to 'ⁿ', 'x' to 'ˣ', 'a' to 'ᵃ', 'b' to 'ᵇ'
        )
        return Regex("\\^([0-9]+|[a-zA-Z])").replace(input) { match ->
            match.groupValues[1].map { superscript[it] ?: it }.joinToString("")
        }
    }

    private fun replaceSubscripts(input: String): String {
        val subscript = mapOf(
            '0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄',
            '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉',
            '+' to '₊', '-' to '₋', 'a' to 'ₐ', 'e' to 'ₑ', 'h' to 'ₕ',
            'i' to 'ᵢ', 'j' to 'ⱼ', 'k' to 'ₖ', 'l' to 'ₗ', 'm' to 'ₘ',
            'n' to 'ₙ', 'o' to 'ₒ', 'p' to 'ₚ', 'r' to 'ᵣ', 's' to 'ₛ',
            't' to 'ₜ', 'u' to 'ᵤ', 'v' to 'ᵥ', 'x' to 'ₓ'
        )
        return Regex("_([0-9]+|[a-zA-Z])").replace(input) { match ->
            match.groupValues[1].map { subscript[it] ?: it }.joinToString("")
        }
    }

    private fun normaliseCommonEngineeringNotation(input: String): String {
        var text = input
        // Keep common units and symbols clean when the model wraps them in punctuation.
        text = text.replace(Regex("(?i)N\\s*/\\s*mm\\s*²"), "N/mm²")
        text = text.replace(Regex("(?i)N\\s*/\\s*mm2"), "N/mm²")
        text = text.replace("rho", "ρ")
        text = text.replace("gamma", "γ")
        text = text.replace("sigma", "σ")
        return text
    }
}
