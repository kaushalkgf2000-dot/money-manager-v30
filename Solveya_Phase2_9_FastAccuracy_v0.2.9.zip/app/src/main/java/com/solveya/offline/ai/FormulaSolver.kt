package com.solveya.offline.ai

import java.util.Locale
import kotlin.math.abs

/**
 * Fast deterministic solver for high-confidence diploma/JE engineering numericals.
 * Returns null unless the question contains a complete, unambiguous data pattern.
 */
object FormulaSolver {
    fun solve(question: String): String? {
        val q = normalize(question)

        // Soil: water content, Gs, saturation -> void ratio.
        if (q.contains("void ratio") && q.contains("water content") &&
            q.contains("specific gravity") && q.contains("saturation")) {
            val w = percentOrDecimal(findNumber(q, "water content")) ?: return null
            val gs = findNumber(q, "specific gravity") ?: return null
            val sRaw = findNumber(q, "saturation") ?: return null
            val s = if (sRaw > 1.0) sRaw / 100.0 else sRaw
            if (s <= 0.0 || gs <= 0.0) return null
            val e = w * gs / s
            return "Given:\nwater content, w = ${fmt(w)}\nGs = ${fmt(gs)}\ndegree of saturation, S = ${fmt(s)}\n\nFormula:\ne = wGs / S\n\nSubstitution:\ne = (${fmt(w)} × ${fmt(gs)}) / ${fmt(s)}\n\ne = ${fmt(e)}\n\nFinal Answer: e = ${fmt(e)}"
        }

        // Soil: void ratio -> porosity.
        if (q.contains("porosity") && q.contains("void ratio")) {
            val e = findNumber(q, "void ratio") ?: return null
            if (e < 0.0) return null
            val n = e / (1.0 + e)
            return "Given:\ne = ${fmt(e)}\n\nFormula:\nn = e / (1 + e)\n\nCalculation:\nn = ${fmt(e)} / (1 + ${fmt(e)})\nn = ${fmt(n)}\n\nFinal Answer: Porosity = ${fmt(n * 100.0)}%"
        }

        // Darcy total discharge.
        if (q.contains("darcy") && q.contains("discharge") &&
            q.contains("cross-sectional area") && q.contains("permeability") &&
            q.contains("hydraulic gradient")) {
            val area = findNumber(q, "cross-sectional area") ?: return null
            val k = findScientificNumberAfter(q, "permeability") ?: findNumber(q, "permeability") ?: return null
            val i = findNumber(q, "hydraulic gradient") ?: return null
            val discharge = k * i * area
            return "Given:\nk = ${fmtSci(k)} m/s\ni = ${fmt(i)}\nA = ${fmt(area)} m²\n\nDarcy's law:\nQ = k i A\n\nQ = (${fmtSci(k)}) × ${fmt(i)} × ${fmt(area)}\nQ = ${fmtSci(discharge)} m³/s\n\nFinal Answer: Q = ${fmtSci(discharge)} m³/s"
        }

        // Soil: saturated unit weight. High-confidence fast path; never delegate this
        // standard relation to the LLM.
        if (q.contains("saturated unit weight") &&
            (q.contains("void ratio") || q.contains("e =")) &&
            (q.contains("specific gravity") || q.contains("gs"))) {
            val e = findNumber(q, "void ratio") ?: findNumberAfterAny(q, listOf("e =", "e=")) ?: return null
            val gs = findNumber(q, "specific gravity") ?: findNumberAfterAny(q, listOf("gs =", "gs=")) ?: return null
            val gammaW = findNumber(q, "unit weight of water") ?:
                findNumberAfterAny(q, listOf("γw", "gw =", "gammaw")) ?: 9.81
            if (e < 0.0 || gs <= 0.0 || gammaW <= 0.0) return null
            val gammaSat = ((gs + e) / (1.0 + e)) * gammaW
            return """Given:
e = ${fmt(e)}
Gs = ${fmt(gs)}
γw = ${fmt(gammaW)} kN/m³

Formula:
γsat = ((Gs + e) / (1 + e)) × γw

Calculation:
γsat = ((${fmt(gs)} + ${fmt(e)}) / (1 + ${fmt(e)})) × ${fmt(gammaW)}
γsat = ${fmt(gammaSat)} kN/m³

Final Answer: γsat = ${fmt(gammaSat)} kN/m³"""
        }

        // Saturated unit weight: γsat = ((Gs + e)/(1+e)) γw.
        if (q.contains("saturated unit weight") && q.contains("void ratio") &&
            q.contains("specific gravity")) {
            val e = findNumber(q, "void ratio") ?: return null
            val gs = findNumber(q, "specific gravity") ?: return null
            val gammaW = findNumber(q, "unit weight of water") ?: findNumber(q, "γw") ?: 9.81
            val gammaSat = ((gs + e) / (1.0 + e)) * gammaW
            return "Given:\ne = ${fmt(e)}\nGs = ${fmt(gs)}\nγw = ${fmt(gammaW)} kN/m³\n\nFormula:\nγsat = ((Gs + e) / (1 + e)) γw\n\nCalculation:\nγsat = ((${fmt(gs)} + ${fmt(e)}) / (1 + ${fmt(e)})) × ${fmt(gammaW)}\nγsat = ${fmt(gammaSat)} kN/m³\n\nFinal Answer: γsat = ${fmt(gammaSat)} kN/m³"
        }

        // Fully saturated soil: e = w Gs.
        if (q.contains("void ratio") && q.contains("specific gravity") &&
            q.contains("water content") && q.contains("fully saturated")) {
            val w = percentOrDecimal(findNumber(q, "water content")) ?: return null
            val gs = findNumber(q, "specific gravity") ?: return null
            val e = w * gs
            return "Given:\nw = ${fmt(w)}\nGs = ${fmt(gs)}\nS = 1.0 (fully saturated)\n\nFormula:\nw = Se/Gs  →  e = wGs/S\n\nCalculation:\ne = ${fmt(w)} × ${fmt(gs)} / 1.0\ne = ${fmt(e)}\n\nFinal Answer: e = ${fmt(e)}"
        }

        return null
    }

    private fun percentOrDecimal(value: Double?): Double? = value?.let { if (it > 1.0) it / 100.0 else it }

    private fun normalize(question: String): String = question
        .lowercase(Locale.US)
        .replace("\u03b3w", " γw ")
        .replace("gamma w", " gammaw ")
        .replace("specific gravity (gs)", "specific gravity")
        .replace("specific gravity, gs", "specific gravity")
        .replace("void ratio (e)", "void ratio")
        .replace("void ratio, e", "void ratio")
        .replace("degree of saturation (s)", "degree of saturation")
        .replace("degree of saturation, s", "degree of saturation")

    private fun findNumberAfterAny(q: String, labels: List<String>): Double? {
        for (label in labels) {
            findNumber(q, label)?.let { return it }
        }
        return null
    }

    private fun findNumber(q: String, label: String): Double? {
        val idx = q.indexOf(label)
        if (idx < 0) return null
        val tail = q.substring(idx, (idx + 100).coerceAtMost(q.length))
        return Regex("[-+]?\\d+(?:\\.\\d+)?").find(tail)?.value?.toDoubleOrNull()
    }

    private fun findScientificNumberAfter(q: String, label: String): Double? {
        val idx = q.indexOf(label)
        if (idx < 0) return null
        val tail = q.substring(idx, (idx + 120).coerceAtMost(q.length))
        val match = Regex("([-+]?\\d+(?:\\.\\d+)?)\\s*[×x*]\\s*10\\s*\\^?\\s*([-+]?\\d+)").find(tail)
            ?: Regex("([-+]?\\d+(?:\\.\\d+)?)e([-+]?\\d+)").find(tail)
        return match?.let { it.groupValues[1].toDoubleOrNull()?.times(10.0.pow(it.groupValues[2].toInt())) }
    }

    private fun fmt(v: Double): String = when {
        abs(v - v.toLong()) < 1e-10 -> v.toLong().toString()
        else -> String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    private fun fmtSci(v: Double): String {
        if (v == 0.0) return "0"
        return String.format(Locale.US, "%.3E", v).replace("E+", " × 10^").replace("E-", " × 10^-")
    }

    private fun Double.pow(n: Int): Double = Math.pow(this, n.toDouble())
}
