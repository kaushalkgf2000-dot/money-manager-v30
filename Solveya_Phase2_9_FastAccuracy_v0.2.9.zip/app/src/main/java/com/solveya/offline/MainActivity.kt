package com.solveya.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.solveya.offline.ai.AiModelState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolveyaApp() }
    }
}

@Composable
fun SolveyaApp(vm: SolveyaViewModel = viewModel()) {
    val state by vm.modelState.collectAsState()
    val answer by vm.answer.collectAsState()
    var question by remember { mutableStateOf("") }

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(Modifier.height(20.dp))

                Text("Solveya", color = Color.White, fontSize = 34.sp)
                Text(
                    "Your Offline AI Study Assistant",
                    color = Color(0xFFFFB52E),
                    fontSize = 16.sp
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    "Phase 2.4 • Solveya Tutor",
                    color = Color(0xFF9BB56A),
                    fontSize = 14.sp
                )

                Spacer(Modifier.height(18.dp))

                ModelStatusCard(
                    state = state,
                    onSelectModel = {
                        modelPicker.launch(
                            arrayOf(
                                "application/octet-stream",
                                "application/x-binary",
                                "*/*"
                            )
                        )
                    },
                    onLoadModel = { vm.initializeModel() }
                )

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { /* Camera: next milestone */ },
                        modifier = Modifier.weight(1f)
                    ) { Text("📷 Camera") }

                    OutlinedButton(
                        onClick = { /* Gallery: next milestone */ },
                        modifier = Modifier.weight(1f)
                    ) { Text("🖼 Gallery") }
                }

                Spacer(Modifier.height(10.dp))

                TextField(
                    value = question,
                    onValueChange = { question = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    placeholder = {
                        Text("Ask a Maths or Science question…")
                    },
                    shape = RoundedCornerShape(18.dp)
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = { vm.ask(question) },
                    enabled = state is AiModelState.Ready && question.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("ASK SOLVEYA OFFLINE")
                }

                Spacer(Modifier.height(18.dp))

                answer?.let { text ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF151515)
                        ),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            Text(
                                "Solveya Answer",
                                color = Color(0xFFFFB52E),
                                fontSize = 17.sp
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = text,
                                color = Color.White,
                                fontSize = 16.sp,
                                lineHeight = 24.sp
                            )
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ModelStatusCard(
    state: AiModelState,
    onSelectModel: () -> Unit,
    onLoadModel: () -> Unit
) {
    val (title, detail) = when (state) {
        AiModelState.NotConfigured ->
            "Model not installed" to
                "Select the official .litertlm model file from your phone."
        AiModelState.ModelInstalled ->
            "Model file installed" to
                "The local model file is ready. Load it to start offline inference."
        AiModelState.Importing ->
            "Importing model…" to
                "Copying the model into Solveya. A large model can take a while."
        AiModelState.Loading ->
            "Loading offline AI…" to
                "The model is initializing. Do not close Solveya."
        AiModelState.Ready ->
            "● OFFLINE AI READY" to
                "The local model is initialized. Internet is not required for inference."
        is AiModelState.Error ->
            "Offline AI error" to state.message
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text(detail, color = Color(0xFFCCCCCC), fontSize = 13.sp)

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSelectModel,
                    enabled = state !is AiModelState.Importing &&
                        state !is AiModelState.Loading
                ) {
                    Text("SELECT MODEL")
                }

                if (state is AiModelState.ModelInstalled ||
                    state is AiModelState.Error
                ) {
                    Button(
                        onClick = onLoadModel,
                        enabled = state !is AiModelState.Loading
                    ) {
                        Text("LOAD MODEL")
                    }
                }
            }
        }
    }
}
