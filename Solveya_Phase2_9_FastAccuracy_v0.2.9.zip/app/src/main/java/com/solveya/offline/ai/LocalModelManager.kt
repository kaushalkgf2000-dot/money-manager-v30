package com.solveya.offline.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LocalModelManager {
    const val MODEL_FILE_NAME = "gemma-4-E2B-it.litertlm"

    fun modelFile(context: Context): File =
        File(File(context.filesDir, "models"), MODEL_FILE_NAME)

    fun isInstalled(context: Context): Boolean =
        modelFile(context).let { it.exists() && it.length() > 0L }

    fun ensureModelDirectory(context: Context) {
        modelFile(context).parentFile?.mkdirs()
    }

    suspend fun importModel(context: Context, uri: Uri): Result<Long> =
        withContext(Dispatchers.IO) {
            runCatching {
                ensureModelDirectory(context)

                val resolver = context.contentResolver
                val target = modelFile(context)
                val temp = File(target.parentFile, "$MODEL_FILE_NAME.part")

                resolver.openInputStream(uri)
                    ?: error("Could not open the selected model file.")

                resolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Could not open the selected model file." }
                    temp.outputStream().use { output ->
                        input.copyTo(output, bufferSize = 1024 * 1024)
                    }
                }

                require(temp.length() > 0L) { "The selected model file is empty." }

                if (target.exists()) target.delete()
                check(temp.renameTo(target)) {
                    "Could not finalize the model file."
                }

                target.length()
            }
        }
}