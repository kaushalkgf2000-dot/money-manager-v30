package com.solveya.offline.ai

sealed interface AiModelState {
    data object NotConfigured : AiModelState
    data object ModelInstalled : AiModelState
    data object Importing : AiModelState
    data object Loading : AiModelState
    data object Ready : AiModelState
    data class Error(val message: String) : AiModelState
}