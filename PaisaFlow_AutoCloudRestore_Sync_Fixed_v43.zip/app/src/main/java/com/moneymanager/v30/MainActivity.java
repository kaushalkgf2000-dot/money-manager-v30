package com.moneymanager.v30;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetHost;
import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.webkit.ValueCallback;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.database.Cursor;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.util.Base64;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;
import android.os.Bundle;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    // Holds a Google credential only for the short account-linking flow when
    // the Google email already belongs to an email/password Firebase user.
    private AuthCredential pendingGoogleCredential;
    private String pendingGoogleEmail;
    private WebView webView;
    private FirebaseAnalytics firebaseAnalytics;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private ValueCallback<Uri[]> filePathCallback;
    private final Handler handler = new Handler();
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int BACKUP_FILE_REQUEST = 4102;
    private static final int GOOGLE_SIGN_IN_REQUEST = 6201;
    private final Executor executor = command -> handler.post(command);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
                    startActivityForResult(i,FILE_CHOOSER_REQUEST);
                    return true;
                }catch(Exception e){
                    filePathCallback=null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new BioBridge(this), "AndroidBiometric");
        webView.addJavascriptInterface(new FileBridge(this), "AndroidFile");
        webView.addJavascriptInterface(new WidgetBridge(this), "AndroidWidget");
        webView.addJavascriptInterface(new BackupBridge(this), "AndroidBackup");
        webView.addJavascriptInterface(new CloudBackupBridge(this), "AndroidCloudBackup");
        webView.addJavascriptInterface(new AuthBridge(this), "AndroidAuth");
        webView.addJavascriptInterface(new AnalyticsBridge(this), "AndroidAnalytics");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        // Google Sign-In callback. The previous build started the Google
        // account picker but never consumed its result, so Firebase never
        // received the Google ID token.
        if(requestCode==GOOGLE_SIGN_IN_REQUEST){
            if(resultCode!=RESULT_OK || data==null){
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google','Google Sign-In was cancelled.','','')", null));
                return;
            }
            try{
                GoogleSignInAccount account=GoogleSignIn.getSignedInAccountFromIntent(data)
                    .getResult(ApiException.class);
                if(account==null || account.getIdToken()==null || account.getIdToken().isEmpty()){
                    webView.post(() -> webView.evaluateJavascript(
                        "window.mfAuthResult && window.mfAuthResult(false,'google','Google did not return a valid ID token.','','')", null));
                    return;
                }
                AuthCredential credential=GoogleAuthProvider.getCredential(account.getIdToken(),null);
                FirebaseUser current=firebaseAuth.getCurrentUser();
                if(current!=null && current.getEmail()!=null && account.getEmail()!=null
                    && current.getEmail().equalsIgnoreCase(account.getEmail())){
                    boolean alreadyGoogle=false;
                    for(com.google.firebase.auth.UserInfo info: current.getProviderData()){
                        if("google.com".equals(info.getProviderId())){ alreadyGoogle=true; break; }
                    }
                    if(!alreadyGoogle){
                        current.linkWithCredential(credential)
                            .addOnSuccessListener(authResult -> {
                                pendingGoogleCredential=null;
                                pendingGoogleEmail=null;
                                FirebaseUser u=firebaseAuth.getCurrentUser();
                                String email=u!=null && u.getEmail()!=null?u.getEmail():account.getEmail();
                                String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():account.getDisplayName();
                                String js="window.mfAuthResult && window.mfAuthResult(true,'google','Google Sign-In linked successfully to this Money Flow account.',"
                                    +org.json.JSONObject.quote(email==null?"":email)+","
                                    +org.json.JSONObject.quote(name==null?"":name)+")";
                                webView.post(() -> webView.evaluateJavascript(js,null));
                            })
                            .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript(
                                "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(authErrorForGoogle(e))+",'','')", null)));
                    }else{
                        FirebaseUser u=current;
                        String email=u.getEmail()==null?account.getEmail():u.getEmail();
                        String name=u.getDisplayName()==null?account.getDisplayName():u.getDisplayName();
                        String js="window.mfAuthResult && window.mfAuthResult(true,'google','Google Sign-In is already linked to this account.',"
                            +org.json.JSONObject.quote(email==null?"":email)+","
                            +org.json.JSONObject.quote(name==null?"":name)+")";
                        webView.post(() -> webView.evaluateJavascript(js,null));
                    }
                }else{
                    firebaseAuth.signInWithCredential(credential)
                    .addOnSuccessListener(authResult -> {
                        pendingGoogleCredential=null;
                        pendingGoogleEmail=null;
                        FirebaseUser u=firebaseAuth.getCurrentUser();
                        String email=u!=null && u.getEmail()!=null?u.getEmail():account.getEmail();
                        String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():account.getDisplayName();
                        String js="window.mfAuthResult && window.mfAuthResult(true,'google','Signed in with Google successfully.',"
                            +org.json.JSONObject.quote(email==null?"":email)+","
                            +org.json.JSONObject.quote(name==null?"":name)+")";
                        webView.post(() -> webView.evaluateJavascript(js,null));
                    })
                    .addOnFailureListener(e -> {
                        if(isAccountExistsConflict(e)){
                            pendingGoogleCredential=credential;
                            pendingGoogleEmail=account.getEmail();
                        }
                        String message=authErrorForGoogle(e);
                        webView.post(() -> webView.evaluateJavascript(
                            "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(message)+",'','')", null));
                    });
                }
            }catch(ApiException e){
                String message="Google Sign-In failed (code "+e.getStatusCode()+").";
                if(e.getStatusCode()==10) message="Google Sign-In configuration error (DEVELOPER_ERROR). Check the package name and SHA-1 in Firebase, then rebuild with the latest google-services.json.";
                final String finalMessage=message;
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(finalMessage)+",'','')", null));
            }catch(Exception e){
                String message=e.getMessage()==null?"Google Sign-In failed.":e.getMessage();
                webView.post(() -> webView.evaluateJavascript(
                    "window.mfAuthResult && window.mfAuthResult(false,'google',"+org.json.JSONObject.quote(message)+",'','')", null));
            }
            return;
        }

        if(requestCode==BACKUP_FILE_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
                    while((n=in.read(buf))!=-1)out.write(buf,0,n);
                    String json=out.toString("UTF-8");
                    final String js="window.mfApplyBackup("+org.json.JSONObject.quote(json)+")";
                    webView.post(()->webView.evaluateJavascript(js,null));
                }catch(Exception e){
                    webView.post(()->android.widget.Toast.makeText(this,"Restore failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());
                }
            }
            return;
        }
        if(requestCode!=FILE_CHOOSER_REQUEST)return;
        if(filePathCallback==null)return;
        Uri[] result=null;
        if(resultCode==RESULT_OK && data!=null){
            Uri u=data.getData();
            if(u!=null)result=new Uri[]{u};
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback=null;
    }

    public class FileBridge {
        private final Context ctx; FileBridge(Context c){ctx=c;}
        @JavascriptInterface public void saveFile(String name, String mime, String b64){
            try{
                byte[] data=Base64.getDecoder().decode(b64);
                if(android.os.Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Manager");
                    Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null)throw new Exception("Could not create download file");
                    try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved to Downloads/Money Manager: "+name,android.widget.Toast.LENGTH_LONG).show());
                } else {
                    java.io.File dir=new java.io.File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Money Manager");
                    if(!dir.exists())dir.mkdirs();
                    java.io.File f=new java.io.File(dir,name);
                    try(java.io.FileOutputStream out=new java.io.FileOutputStream(f)){out.write(data);}
                    webView.post(()->android.widget.Toast.makeText(ctx,"Saved: "+f.getAbsolutePath(),android.widget.Toast.LENGTH_LONG).show());
                }
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Export failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
    }


    public class BackupBridge {
        private final Context ctx; BackupBridge(Context c){ctx=c;}
        private java.io.File snapshot(){return new java.io.File(ctx.getFilesDir(),"money_flow_backup_snapshot.json");}
        @JavascriptInterface public void saveBackupSnapshot(String json){
            try{java.io.File f=snapshot();try(java.io.FileOutputStream out=new java.io.FileOutputStream(f,false)){out.write(json.getBytes(StandardCharsets.UTF_8));} }
            catch(Exception e){ }
        }
        @JavascriptInterface public String getBackupSnapshot(){
            try{java.io.File f=snapshot();if(!f.exists())return "";return new String(java.nio.file.Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);}catch(Exception e){return "";}
        }
        @JavascriptInterface public String getBackupMeta(){
            try{java.io.File f=snapshot();if(!f.exists())return "No recovery snapshot created yet.";return "✓ Recovery snapshot available • "+new java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a",java.util.Locale.getDefault()).format(new java.util.Date(f.lastModified()));}catch(Exception e){return "Backup status unavailable.";}
        }
        @JavascriptInterface public void exportBackupFile(String json,String name){
            try{
                android.content.ContentValues v=new android.content.ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/json");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Money Flow Backup");
                Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Could not create backup file");
                try(OutputStream out=ctx.getContentResolver().openOutputStream(u)){out.write(json.getBytes(StandardCharsets.UTF_8));}
                webView.post(()->android.widget.Toast.makeText(ctx,"Backup saved to Downloads/Money Flow Backup",android.widget.Toast.LENGTH_LONG).show());
            }catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"Backup failed: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBackupFile(){
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,BACKUP_FILE_REQUEST);}catch(Exception e){webView.post(()->android.widget.Toast.makeText(ctx,"File picker unavailable",android.widget.Toast.LENGTH_SHORT).show());}
        }
    }

    public class CloudBackupBridge {
        private final Context ctx;
        CloudBackupBridge(Context c){ctx=c;}

        private void ensureSignedIn(final Runnable action, final java.util.function.Consumer<Exception> onError){
            // Cloud backup/restore requires an authenticated Firebase session,
            // not email verification. Verification is enforced only during signup.
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u!=null){ action.run(); return; }
            onError.accept(new Exception("Please sign in to your Money Flow account first."));
        }
        private String accountKey(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            String email=u!=null?u.getEmail():null;
            // Use the normalized email as the cloud identity. This keeps the
            // backup stable when the same Google/email address gets a different
            // Firebase UID on another auth path/device.
            if(email==null || email.trim().isEmpty()) return u!=null?u.getUid():"unknown";
            return email.trim().toLowerCase(java.util.Locale.US);
        }

        private void toast(final String message){
            webView.post(() -> android.widget.Toast.makeText(ctx,message,android.widget.Toast.LENGTH_LONG).show());
        }

        @JavascriptInterface public void uploadCloudBackup(String json){
            if(json==null || json.length()==0){ toast("Cloud backup failed: empty backup"); return; }
            ensureSignedIn(() -> {
                String uid=accountKey();
                Map<String,Object> doc=new HashMap<>();
                doc.put("backupJson", json);
                // Client-side revision lets Firestore reject an older in-flight
                // upload from overwriting a newer transaction snapshot.
                long revision=System.currentTimeMillis();
                doc.put("syncRevision", revision);
                doc.put("updatedAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
                doc.put("appVersion", "PaisaFlow V43");
                FirebaseUser currentUser=firebaseAuth.getCurrentUser();
                if(currentUser!=null){
                    doc.put("uid", currentUser.getUid());
                    doc.put("email", currentUser.getEmail());
                }
                firestore.collection("users").document(uid).collection("backup").document("latest")
                    .get()
                    .continueWithTask(task -> {
                        if(!task.isSuccessful()) throw task.getException();
                        com.google.firebase.firestore.DocumentSnapshot old=task.getResult();
                        Long oldRevision=old!=null?old.getLong("syncRevision"):null;
                        if(oldRevision!=null && oldRevision.longValue()>revision){
                            // A newer snapshot is already stored; never overwrite it
                            // with an older asynchronous write.
                            return com.google.android.gms.tasks.Tasks.forResult(null);
                        }
                        return firestore.collection("users").document(uid).collection("backup").document("latest")
                            .set(doc, SetOptions.merge());
                    })
                    .addOnSuccessListener(v -> webView.post(() -> webView.evaluateJavascript("window.mfCloudBackupResult && window.mfCloudBackupResult(true,'Cloud backup updated successfully.')",null)))
                    .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudBackupResult && window.mfCloudBackupResult(false,"+org.json.JSONObject.quote("Cloud backup failed: "+e.getMessage())+")",null)));
            }, e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudBackupResult && window.mfCloudBackupResult(false,"+org.json.JSONObject.quote("Cloud backup unavailable: "+e.getMessage())+")",null)));
        }

        private void deliverCloudSnapshot(com.google.firebase.firestore.DocumentSnapshot snapshot){
            String json=snapshot.getString("backupJson");
            if(json==null || json.length()==0){
                webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,'Cloud backup is empty.')",null));
                return;
            }
            webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(true,"+org.json.JSONObject.quote(json)+")",null));
        }

        @JavascriptInterface public void restoreCloudBackup(){
            ensureSignedIn(() -> {
                String uid=accountKey();
                firestore.collection("users").document(uid).collection("backup").document("latest").get()
                    .addOnSuccessListener(snapshot -> {
                        if(snapshot.exists()){
                            deliverCloudSnapshot(snapshot);
                            return;
                        }
                        String legacyUid=firebaseAuth.getCurrentUser().getUid();
                        if(!legacyUid.equals(uid)){
                            firestore.collection("users").document(legacyUid).collection("backup").document("latest").get()
                                .addOnSuccessListener(legacy -> {
                                    if(legacy.exists()) deliverCloudSnapshot(legacy);
                                    else webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,'No cloud backup found for this account.')",null));
                                })
                                .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,"+org.json.JSONObject.quote("Cloud restore failed: "+e.getMessage())+")",null)));
                        }else webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,'No cloud backup found for this account.')",null));
                    })
                    .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,"+org.json.JSONObject.quote("Cloud restore failed: "+e.getMessage())+")",null)));
            }, e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudRestoreResult && window.mfCloudRestoreResult(false,"+org.json.JSONObject.quote("Cloud restore unavailable: "+e.getMessage())+")",null)));
        }

        @JavascriptInterface public void getCloudStatus(){
            if(firebaseAuth.getCurrentUser()==null){
                webView.post(() -> webView.evaluateJavascript("window.mfCloudStatusResult && window.mfCloudStatusResult('☁️ Sign in to your PaisaFlow account to use Cloud Backup.')",null));
                return;
            }
            String uid=accountKey();
            firestore.collection("users").document(uid).collection("backup").document("latest").get()
                .addOnSuccessListener(snapshot -> {
                    if(snapshot.exists()){
                        webView.post(() -> webView.evaluateJavascript("window.mfCloudStatusResult && window.mfCloudStatusResult('☁️ Cloud backup available')",null));
                        return;
                    }
                    FirebaseUser u=firebaseAuth.getCurrentUser();
                    String legacy=u!=null?u.getUid():"";
                    if(legacy.isEmpty() || legacy.equals(uid)){
                        webView.post(() -> webView.evaluateJavascript("window.mfCloudStatusResult && window.mfCloudStatusResult('☁️ No cloud backup created yet')",null));
                        return;
                    }
                    firestore.collection("users").document(legacy).collection("backup").document("latest").get()
                        .addOnSuccessListener(old -> webView.post(() -> webView.evaluateJavascript(
                            "window.mfCloudStatusResult && window.mfCloudStatusResult("+org.json.JSONObject.quote(old.exists()?"☁️ Cloud backup available":"☁️ No cloud backup created yet")+")",null)))
                        .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudStatusResult && window.mfCloudStatusResult('☁️ Cloud backup unavailable')",null)));
                })
                .addOnFailureListener(e -> webView.post(() -> webView.evaluateJavascript("window.mfCloudStatusResult && window.mfCloudStatusResult('☁️ Cloud backup unavailable')",null)));
        }
    }

    private boolean isAccountExistsConflict(Exception e){
        String m=e==null?"":String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.US);
        return m.contains("account-exists-with-different-credential")
            || m.contains("email already exists")
            || m.contains("credential is already associated");
    }

    private String authErrorForGoogle(Exception e){
        String m=e==null?"Google Sign-In failed.":e.getMessage();
        if(m==null)m="Google Sign-In failed.";
        String low=m.toLowerCase(java.util.Locale.US);
        if(isAccountExistsConflict(e))
            return "This Google email already has a Money Flow email/password account. Log in with that email and password once; Google will then be linked automatically. No new verification is required for an already verified account.";
        if(low.contains("network")) return "Network error. Check your internet connection.";
        if(low.contains("credential")) return "Google account authentication failed. Please try again.";
        return m;
    }

    private void linkPendingGoogleIfApplicable(FirebaseUser fresh, String loginEmail){
        if(pendingGoogleCredential==null || pendingGoogleEmail==null || fresh==null || fresh.getEmail()==null
            || !pendingGoogleEmail.equalsIgnoreCase(loginEmail)
            || !pendingGoogleEmail.equalsIgnoreCase(fresh.getEmail())){
            resultLoginSuccess();
            return;
        }
        AuthCredential credential=pendingGoogleCredential;
        pendingGoogleCredential=null;
        pendingGoogleEmail=null;
        fresh.linkWithCredential(credential)
            .addOnSuccessListener(r -> resultLoginSuccess("Email/password login succeeded and Google Sign-In is now linked to the same Money Flow account."))
            .addOnFailureListener(e -> {
                String m=e.getMessage()==null?"Google could not be linked automatically.":e.getMessage();
                resultLoginSuccess("Signed in successfully. Google could not be linked automatically: "+m);
            });
    }

    private void resultLoginSuccess(){ resultLoginSuccess("Signed in successfully."); }
    private void resultLoginSuccess(String message){
        FirebaseUser u=firebaseAuth.getCurrentUser();
        String email=u!=null&&u.getEmail()!=null?u.getEmail():"";
        String name=u!=null&&u.getDisplayName()!=null?u.getDisplayName():"";
        String js="window.mfAuthResult && window.mfAuthResult(true,'login',"+org.json.JSONObject.quote(message)+","+org.json.JSONObject.quote(email)+","+org.json.JSONObject.quote(name)+")";
        webView.post(()->webView.evaluateJavascript(js,null));
    }

    public class AuthBridge {
        private final Context ctx;
        AuthBridge(Context c){ctx=c;}

        private String q(String s){ return org.json.JSONObject.quote(s==null?"":s); }
        private void result(boolean ok, String action, String message){
            com.google.firebase.auth.FirebaseUser u=firebaseAuth.getCurrentUser();
            String email=u!=null && u.getEmail()!=null?u.getEmail():"";
            String name=u!=null && u.getDisplayName()!=null?u.getDisplayName():"";
            String js="window.mfAuthResult && window.mfAuthResult("+ok+","+q(action)+","+q(message)+","+q(email)+","+q(name)+")";
            webView.post(()->webView.evaluateJavascript(js,null));
        }

        @JavascriptInterface public void getStatus(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u==null){ result(true,"status","signed_out"); return; }
            // A successful Firebase session is sufficient to remain signed in.
            // Email verification is required only during account creation; it
            // must never block an already-created account at login/startup.
            result(true,"status","signed_in");
        }

        @JavascriptInterface public void signUp(String name, String email, String password){
            if(email==null || email.trim().isEmpty()){ result(false,"signup","Email is required."); return; }
            if(password==null || password.length()<6){ result(false,"signup","Password must be at least 6 characters."); return; }
            firebaseAuth.createUserWithEmailAndPassword(email.trim(),password)
                .addOnSuccessListener(r->{
                    FirebaseUser u=firebaseAuth.getCurrentUser();
                    Runnable sendVerification=()->{
                        FirebaseUser current=firebaseAuth.getCurrentUser();
                        if(current==null){result(false,"signup","Account was created, but the verification session is unavailable.");return;}
                        current.sendEmailVerification()
                            .addOnSuccessListener(v->{
                                firebaseAuth.signOut();
                                result(true,"verify_required","Account created. We sent a verification link to your email. Verify it, then log in. Check Spam/Promotions if you do not see it.");
                            })
                            .addOnFailureListener(e->{
                                firebaseAuth.signOut();
                                result(false,"signup","Account created, but the verification email could not be sent: "+authError(e));
                            });
                    };
                    if(u!=null && name!=null && !name.trim().isEmpty()){
                        com.google.firebase.auth.UserProfileChangeRequest req=new com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build();
                        u.updateProfile(req).addOnCompleteListener(x->sendVerification.run());
                    }else sendVerification.run();
                })
                .addOnFailureListener(e->result(false,"signup",authError(e)));
        }

        @JavascriptInterface public void signIn(String email, String password){
            if(email==null || email.trim().isEmpty() || password==null || password.isEmpty()){ result(false,"login","Enter your email and password."); return; }
            firebaseAuth.signInWithEmailAndPassword(email.trim(),password)
                .addOnSuccessListener(r->{
                    FirebaseUser u=firebaseAuth.getCurrentUser();
                    if(u==null){ result(false,"login","Authentication succeeded but the account session was unavailable."); return; }
                    // Login is credential-based. Do not gate it on email
                    // verification: verification is handled once during signup.
                    // Refresh the user only to obtain the latest Firebase profile,
                    // then continue immediately to the existing Google-link flow.
                    u.reload().addOnCompleteListener(reload -> {
                        FirebaseUser fresh=firebaseAuth.getCurrentUser();
                        if(fresh!=null){
                            linkPendingGoogleIfApplicable(fresh, email.trim());
                        }else{
                            result(false,"login","Authentication succeeded but the account session was unavailable.");
                        }
                    });
                })
                .addOnFailureListener(e->result(false,"login",authError(e)));
        }

        @JavascriptInterface public void signInWithGoogle(){
            try{
                int id=getResources().getIdentifier("default_web_client_id","string",getPackageName());
                if(id==0){ result(false,"google","Google Sign-In is not configured in this Firebase Android app yet. Enable Google provider and add the Firebase-generated OAuth client, then rebuild."); return; }
                String clientId=getString(id);
                if(clientId==null || clientId.trim().isEmpty()){ result(false,"google","Google Sign-In is not configured yet. Enable Google provider in Firebase and rebuild with the updated google-services.json."); return; }
                GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail().requestProfile().requestIdToken(clientId).build();
                Intent intent=GoogleSignIn.getClient(MainActivity.this,gso).getSignInIntent();
                startActivityForResult(intent,GOOGLE_SIGN_IN_REQUEST);
            }catch(Exception e){ result(false,"google","Google Sign-In failed to start: "+e.getMessage()); }
        }

        @JavascriptInterface public void resendVerification(){
            FirebaseUser u=firebaseAuth.getCurrentUser();
            if(u!=null){
                u.sendEmailVerification().addOnSuccessListener(v->result(true,"verify_sent","Verification email sent. Check Inbox, Spam and Promotions."))
                    .addOnFailureListener(e->result(false,"verify_sent",authError(e)));
                return;
            }
            result(false,"verify_sent","Please enter your email and password and log in again to resend verification.");
        }

        @JavascriptInterface public void signOut(){
            pendingGoogleCredential=null;
            pendingGoogleEmail=null;
            firebaseAuth.signOut();
            try{
                int id=getResources().getIdentifier("default_web_client_id","string",getPackageName());
                if(id!=0){String clientId=getString(id); if(clientId!=null&&!clientId.isEmpty()){
                    GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestIdToken(clientId).build();
                    GoogleSignIn.getClient(MainActivity.this,gso).signOut();
                }}
            }catch(Exception ignored){}
            result(true,"logout","Signed out successfully.");
        }

        @JavascriptInterface public void resetPassword(String email){
            if(email==null || email.trim().isEmpty()){ result(false,"reset","Enter your account email first."); return; }
            firebaseAuth.sendPasswordResetEmail(email.trim())
                .addOnSuccessListener(v->result(true,"reset","Password reset email sent. Check your inbox."))
                .addOnFailureListener(e->result(false,"reset",authError(e)));
        }

        private String authError(Exception e){
            String m=e==null?"Authentication failed.":e.getMessage();
            if(m==null)m="Authentication failed.";
            if(m.contains("password is invalid") || m.contains("INVALID_LOGIN_CREDENTIALS")) return "Incorrect email or password.";
            if(m.contains("email address is badly formatted")) return "Please enter a valid email address.";
            if(m.contains("email address is already in use")) return "This email is already registered. Please log in.";
            if(m.contains("password should be at least 6 characters")) return "Password must be at least 6 characters.";
            if(m.contains("network error")) return "Network error. Check your internet connection.";
            return m;
        }
    }

    public class WidgetBridge {
        private final Context ctx;
        WidgetBridge(Context c){ctx=c;}

        @JavascriptInterface public void updateStatus(String balance, String expense, String credit){
            ctx.getSharedPreferences(PaisaFlowWidgetProvider.PREFS, Context.MODE_PRIVATE)
                .edit().putString(PaisaFlowWidgetProvider.BALANCE, balance)
                .putString(PaisaFlowWidgetProvider.EXPENSE, expense)
                .putString(PaisaFlowWidgetProvider.CREDIT, credit).apply();
            webView.post(() -> PaisaFlowWidgetProvider.updateAll(ctx));
        }

        @JavascriptInterface public void requestPinWidget(){
            if(android.os.Build.VERSION.SDK_INT < 26){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            AppWidgetManager manager=AppWidgetManager.getInstance(ctx);
            ComponentName provider=new ComponentName(ctx, PaisaFlowWidgetProvider.class);
            if(!manager.isRequestPinAppWidgetSupported()){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Long-press the Home screen and choose Widgets to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
                return;
            }
            PendingIntent callback=PendingIntent.getBroadcast(ctx, 9321,
                new Intent(ctx, PaisaFlowWidgetProvider.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            boolean requested=manager.requestPinAppWidget(provider, null, callback);
            if(!requested){
                webView.post(() -> android.widget.Toast.makeText(ctx,
                    "Open your Home screen's Widgets panel to add Money Flow.",
                    android.widget.Toast.LENGTH_LONG).show());
            }
        }
    }

    public class AnalyticsBridge {
        private final Context ctx;
        AnalyticsBridge(Context c){ctx=c;}
        @JavascriptInterface public void logFeature(String feature){
            if(feature==null)return;
            String f=feature.trim().toLowerCase(java.util.Locale.US);
            if(f.length()==0)return;
            if(f.length()>40)f=f.substring(0,40);
            Bundle params=new Bundle();
            params.putString("feature_name", f);
            firebaseAnalytics.logEvent("feature_used", params);
        }
        @JavascriptInterface public void logAction(String action){
            if(action==null)return;
            String a=action.trim().toLowerCase(java.util.Locale.US);
            if(a.length()==0)return;
            if(a.length()>40)a=a.substring(0,40);
            Bundle params=new Bundle();
            params.putString("action_name", a);
            firebaseAnalytics.logEvent("app_action", params);
        }
    }

    public class BioBridge {
        private final Context ctx;
        BioBridge(Context c){ctx=c;}
        @JavascriptInterface public boolean isAvailable(){
            if (android.os.Build.VERSION.SDK_INT < 28) return false;
            BiometricManager bm=(BiometricManager)ctx.getSystemService(Context.BIOMETRIC_SERVICE);
            if(bm==null)return false;
            int r=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
            return r==BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public void authenticate(final String callback){
            if(android.os.Build.VERSION.SDK_INT<28){logBiometric("biometric_unavailable");send(callback,false);return;}
            if(!isAvailable()){logBiometric("biometric_unavailable");send(callback,false);return;}
            BiometricPrompt prompt=new BiometricPrompt.Builder(MainActivity.this)
                .setTitle("Money Flow")
                .setSubtitle("Verify your identity")
                .setDescription("Use your registered fingerprint or biometric to continue.")
                .setNegativeButton("Use PIN", executor, (d,w)->{logBiometric("biometric_fallback_pin");send(callback,false);})
                .build();
            CancellationSignal cs=new CancellationSignal();
            prompt.authenticate(cs, executor, new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){logBiometric("biometric_success");send(callback,true);}
                @Override public void onAuthenticationFailed(){ /* keep prompt open */ }
                @Override public void onAuthenticationError(int e, CharSequence msg){logBiometric("biometric_error");send(callback,false);}
            });
        }
        private void logBiometric(String event){
            try{Bundle p=new Bundle();p.putString("action_name",event);firebaseAnalytics.logEvent("app_action",p);}catch(Exception ignored){}
        }
        private void send(String cb, boolean ok){
            final String js="window."+cb+"("+(ok?"true":"false")+")";
            handler.post(()->webView.evaluateJavascript(js,null));
        }
    }
}
