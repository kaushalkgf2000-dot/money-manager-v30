# MoneyFlow V26 — GitHub Workflow Fix

## Actual root cause
The repository's OUTER `.github/workflows/main.yml` was still using:
`android-actions/setup-android@v3`

That action requests the legacy SDK package `tools` by default. The current runner cannot find that package, causing:
`Warning: Failed to find package 'tools'`

The embedded workflow inside the project ZIP is not the workflow that GitHub is executing. The outer repository workflow runs first, extracts the project ZIP, and fails at Android SDK setup.

## What to replace
Replace the repository's existing:
`.github/workflows/main.yml`

with the included:
`.github/workflows/main.yml`

Do NOT modify MoneyFlow app source files for this build fix.

The fixed workflow:
- does not use setup-android
- does not request `tools`
- uses the runner's sdkmanager
- installs platform-tools, Android 35 and build-tools 35.0.0
- uses JDK 17 and Gradle 8.11.1
- prefers a MoneyFlow ZIP and avoids the old PaisaFlow filename
- builds and uploads `MoneyFlow-debug.apk`
